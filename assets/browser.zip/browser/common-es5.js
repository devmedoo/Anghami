(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/gift-block/gift-block.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/gift-block/gift-block.component.html ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"gift-wrap flexbox\">\n  <img\n    class=\"gift\"\n    [lazyLoad]=\"'https://anghamiwebcdn.akamaized.net/web/assets/img/redeem/gift-updated.png'\"/>\n  <div class=\"w-5\"></div>\n  <div class=\"flexbox cols align-end w-30\">\n    <div class=\"title\" i18n=\"@@subscreen_gift_title\">Give the gift of music</div>\n    <div\n      class=\"subtitle my-2\"\n      i18n=\"@@subscreen_gift_subtitle\">\n      Be special, send to your loved ones music with no limits & no restrictions</div>\n<anghami-button class=\"mt-3\" label=\"giftAnghamiPlus\" link=\"/gifts\" layout=\"blue\" target=\"router\">\n</anghami-button>\n\n  </div>\n</div>\n<!-- TODO: check with Rashel how to put this link -->\n<!-- <div\n  class=\"footer\"\n  (click)=\"goToRedeem()\"\n  i18n=\"@@subscreen_gift_f1\"\n>Add promocode to redeem your gift</div> -->"

/***/ }),

/***/ "./src/app/core/components/gift-block/gift-block.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/core/components/gift-block/gift-block.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .flexbox {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .flexbox.cols {\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (min-width: 769px) {\n  :host .flexbox.align-end {\n    -webkit-box-align: end;\n        -ms-flex-align: end;\n            align-items: flex-end;\n  }\n}\n@media (max-width: 768px) {\n  :host .flexbox {\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: reverse;\n        -ms-flex-direction: column-reverse;\n            flex-direction: column-reverse;\n  }\n}\n:host .w-30 {\n  max-width: 30em;\n}\n:host .w-5 {\n  width: 5em;\n}\n@media (max-width: 768px) {\n  :host .w-5 {\n    height: 2em;\n  }\n}\n:host .title {\n  font-weight: bold;\n  font-size: 1.4rem;\n}\n:host .subtitle {\n  color: #A5AEB5;\n  font-size: 0.9rem;\n  text-align: right;\n  max-width: 25em;\n}\n@media (max-width: 768px) {\n  :host .subtitle {\n    text-align: center;\n  }\n}\n:host img {\n  max-width: 35em;\n}\n@media (max-width: 768px) {\n  :host img {\n    max-width: 28em;\n  }\n}\n:host .footer {\n  text-decoration: underline;\n  cursor: pointer;\n  font-weight: 500;\n  font-size: 0.9rem;\n}\nhtml[lang=ar] :host .gift-wrap {\n  direction: ltr !important;\n}"

/***/ }),

/***/ "./src/app/core/components/gift-block/gift-block.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/core/components/gift-block/gift-block.component.ts ***!
  \********************************************************************/
/*! exports provided: GiftBlockComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GiftBlockComponent", function() { return GiftBlockComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var GiftBlockComponent = /** @class */ (function () {
    function GiftBlockComponent(_router) {
        this._router = _router;
    }
    GiftBlockComponent.prototype.ngOnInit = function () {
    };
    GiftBlockComponent.prototype.goToRedeem = function () {
        this._router.navigate(['/redeem']);
    };
    GiftBlockComponent.prototype.goToGiftland = function () {
        this._router.navigate(['/gifts']);
    };
    GiftBlockComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-gift-block',
            template: __webpack_require__(/*! raw-loader!./gift-block.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/gift-block/gift-block.component.html"),
            styles: [__webpack_require__(/*! ./gift-block.component.scss */ "./src/app/core/components/gift-block/gift-block.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], GiftBlockComponent);
    return GiftBlockComponent;
}());



/***/ }),

/***/ "./src/app/core/components/gift-block/gift-block.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/core/components/gift-block/gift-block.module.ts ***!
  \*****************************************************************/
/*! exports provided: GiftBlockModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GiftBlockModule", function() { return GiftBlockModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _gift_block_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./gift-block.component */ "./src/app/core/components/gift-block/gift-block.component.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _button_button_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../button/button.module */ "./src/app/core/components/button/button.module.ts");







var GiftBlockModule = /** @class */ (function () {
    function GiftBlockModule() {
    }
    GiftBlockModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], ng_lazyload_image__WEBPACK_IMPORTED_MODULE_5__["LazyLoadImageModule"], _button_button_module__WEBPACK_IMPORTED_MODULE_6__["ButtonModule"]],
            declarations: [_gift_block_component__WEBPACK_IMPORTED_MODULE_4__["GiftBlockComponent"]],
            exports: [_gift_block_component__WEBPACK_IMPORTED_MODULE_4__["GiftBlockComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], GiftBlockModule);
    return GiftBlockModule;
}());



/***/ }),

/***/ "./src/app/core/redux/effects/layout.effects.ts":
/*!******************************************************!*\
  !*** ./src/app/core/redux/effects/layout.effects.ts ***!
  \******************************************************/
/*! exports provided: LayoutEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LayoutEffects", function() { return LayoutEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _actions_settings_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../actions/settings.actions */ "./src/app/core/redux/actions/settings.actions.ts");
/* harmony import */ var _actions_layout_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../actions/layout.actions */ "./src/app/core/redux/actions/layout.actions.ts");
/* harmony import */ var _anghami_services_layout_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/layout.service */ "./src/app/core/services/layout.service.ts");








var LayoutEffects = /** @class */ (function () {
    function LayoutEffects(actions$, store, _layoutService) {
        var _this = this;
        this.actions$ = actions$;
        this.store = store;
        this._layoutService = _layoutService;
        this.DarkModeEffects$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_layout_actions__WEBPACK_IMPORTED_MODULE_6__["LayoutActionTypes"].ToggleDarkmode), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (data) {
            _this._layoutService.ToggleDarkmode(data.payload);
            if (!data.payload.fromAuth) {
                _this.store.dispatch(new _actions_settings_actions__WEBPACK_IMPORTED_MODULE_5__["PostUserPreferences"]({
                    'appSettings': {
                        'darkmode': {
                            type: 'POSTuserpreferences',
                            darkmode: data.payload.value ? 1 : 0,
                            silent: true
                        }
                    }
                }));
            }
        }));
    }
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], LayoutEffects.prototype, "DarkModeEffects$", void 0);
    LayoutEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
            _anghami_services_layout_service__WEBPACK_IMPORTED_MODULE_7__["LayoutService"]])
    ], LayoutEffects);
    return LayoutEffects;
}());



/***/ }),

/***/ "./src/app/core/services/copy-to-clipboard.service.ts":
/*!************************************************************!*\
  !*** ./src/app/core/services/copy-to-clipboard.service.ts ***!
  \************************************************************/
/*! exports provided: CopyToClipboardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CopyToClipboardService", function() { return CopyToClipboardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");

// Based on https://gist.github.com/rproenca/64781c6a1329b48a455b645d361a9aa3

var CopyToClipboardService = /** @class */ (function () {
    function CopyToClipboardService() {
    }
    CopyToClipboardService.prototype.isOS = function () {
        return navigator.userAgent.match(/ipad|iphone/i);
    };
    CopyToClipboardService.prototype.createTextArea = function (text) {
        this.textArea = document.createElement('textArea');
        this.textArea.value = text;
        document.body.appendChild(this.textArea);
    };
    CopyToClipboardService.prototype.selectText = function () {
        var range, selection;
        if (this.isOS()) {
            range = document.createRange();
            range.selectNodeContents(this.textArea);
            selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(range);
            this.textArea.setSelectionRange(0, 999999);
        }
        else {
            this.textArea.select();
        }
    };
    CopyToClipboardService.prototype.copyToClipboard = function () {
        document.execCommand('copy');
        document.body.removeChild(this.textArea);
    };
    CopyToClipboardService.prototype.copy = function (text) {
        this.createTextArea(text);
        this.selectText();
        this.copyToClipboard();
    };
    CopyToClipboardService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], CopyToClipboardService);
    return CopyToClipboardService;
}());



/***/ }),

/***/ "./src/app/core/services/import-music.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/core/services/import-music.service.ts ***!
  \*******************************************************/
/*! exports provided: ImportMusicService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportMusicService", function() { return ImportMusicService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/settings.actions */ "./src/app/core/redux/actions/settings.actions.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");














var ImportMusicService = /** @class */ (function () {
    function ImportMusicService(_actionsSubject, _store, _translateService, _utilService, _router) {
        this._actionsSubject = _actionsSubject;
        this._store = _store;
        this._translateService = _translateService;
        this._utilService = _utilService;
        this._router = _router;
        this.deviceName = this._utilService.getOSName();
    }
    ImportMusicService.prototype.handleImportMusic = function (type, code) {
        var _this = this;
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_4__["SettingsActionTypes"].ImportMusicFromSourceSuccess))
            .subscribe(function (action) {
            var response = action.payload;
            if (response && response !== null) {
                _this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_5__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_6__["AmplitudeEvents"]["connectTo" + response.type],
                    props: {
                        source: 'settings',
                        action: response.redirectUrl ? 'tap' : 'connected'
                    }
                }));
                if (response.redirectUrl) {
                    _this._store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_9__["AuthRedirect"](response.redirectUrl));
                }
                else {
                    _this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_5__["LogAmplitudeEvent"]({
                        name: _enums_enums__WEBPACK_IMPORTED_MODULE_6__["AmplitudeEvents"]["connect" + response.type],
                        props: {
                            source: _this.deviceName
                        }
                    }));
                    _this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["OpenDialog"]({
                        title: response.message || _this._translateService.instant('preferences_updated_success'),
                        displaymode: 'toast'
                    }));
                    if (_this.deviceName === 'web') {
                        _this._router.navigate(['settings'], { queryParams: {
                                code: true
                            } });
                    }
                    else {
                        window.location.href = 'anghami://settings';
                    }
                }
            }
        });
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_4__["SettingsActionTypes"].ImportMusicFromSourceError))
            .subscribe(function (action) {
            var payloadErr = action.payload && action.payload.error
                ? action.payload.error
                : null;
            var error = payloadErr && payloadErr !== null
                ? payloadErr['_attributes']
                    ? payloadErr['_attributes']
                    : payloadErr
                : {};
            _this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["OpenDialog"]({
                title: error.message || _this._translateService.instant('oops'),
                displaymode: 'toast'
            }));
        });
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_5__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_6__["AmplitudeEvents"].importMusic,
            props: { appsource: type }
        }));
        this._store.dispatch(new _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_4__["ImportMusicFromSource"]({
            type: type,
            code: code
        }));
    };
    ImportMusicService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateService"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_11__["UtilService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"]])
    ], ImportMusicService);
    return ImportMusicService;
}());



/***/ }),

/***/ "./src/app/core/services/layout.service.ts":
/*!*************************************************!*\
  !*** ./src/app/core/services/layout.service.ts ***!
  \*************************************************/
/*! exports provided: LayoutService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LayoutService", function() { return LayoutService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");



var LayoutService = /** @class */ (function () {
    function LayoutService(_utilService) {
        this._utilService = _utilService;
    }
    LayoutService.prototype.ToggleDarkmode = function (params) {
        var val = params.value ? 'dark' : 'light';
        this._utilService.setCookie('theme', val, 365);
    };
    LayoutService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilService"]])
    ], LayoutService);
    return LayoutService;
}());



/***/ }),

/***/ "./src/app/modules/base/view/view.resolver.ts":
/*!****************************************************!*\
  !*** ./src/app/modules/base/view/view.resolver.ts ***!
  \****************************************************/
/*! exports provided: ViewResolver */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewResolver", function() { return ViewResolver; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _app_core_services_extras_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../app/core/services/extras.service */ "./src/app/core/services/extras.service.ts");






var ViewResolver = /** @class */ (function () {
    function ViewResolver(store, platformId, _extrasService) {
        this.store = store;
        this.platformId = platformId;
        this._extrasService = _extrasService;
    }
    ViewResolver.prototype.resolve = function (route, state) {
        var routeType = state.url.split('/')[1];
        var routeId = state.url.split('/')[2];
        if (routeType === 'likes' || routeType === 'downloads' || routeType === 'desktop-downloads') {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["empty"])();
        }
        else {
            var params = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, route.params);
            if (params.collectionId) {
                params = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, params, { collectionId: route.params.collectionId.indexOf('?') === -1
                        ? route.params.collectionId
                        : route.params.collectionId.slice(0, route.params.collectionId.indexOf('?')), extras: route.params.collectionId.indexOf('extras=') === -1
                        ? undefined
                        : route.params.collectionId.slice(route.params.collectionId.indexOf('extras=') + 7, route.params.collectionId.length) });
            }
            if (params.extras) {
                this._extrasService.setExtras(params.extras);
            }
            this.initViewData(params);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["empty"])();
        }
    };
    ViewResolver.prototype.initViewData = function (params) {
        var _this = this;
        setTimeout(function () {
            _this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetCollectionDataNew"](tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, params, { librarySection: null })));
        });
    };
    ViewResolver = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
            Object,
            _app_core_services_extras_service__WEBPACK_IMPORTED_MODULE_5__["ExtrasService"]])
    ], ViewResolver);
    return ViewResolver;
}());



/***/ }),

/***/ "./src/app/modules/landing/plus/plus-internal.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/modules/landing/plus/plus-internal.component.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .pluslogo {\n  text-align: center;\n  font-size: 1.7em;\n  font-weight: 500;\n  padding: 0.5em 0;\n}\n:host .pluslogo .highlight {\n  background-color: #3666CD !important;\n  color: #FFFFFF !important;\n  padding: 0.02em 0.2em;\n  font-weight: 600;\n  border-radius: 0.1em;\n  font-size: 0.9em;\n}"

/***/ }),

/***/ "./src/environments/environment.prod.ts":
/*!**********************************************!*\
  !*** ./src/environments/environment.prod.ts ***!
  \**********************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
var environment = {
    production: true,
    hmr: false,
    appName: 'web-v2',
    API_URL: 'https://api.anghami.com/gateway.php',
    API_URL_SERVER: 'http://web2api.anghami.com/gateway.php',
    gtagKey: 'UA-38735485-5',
    fbkKey: '1515610861829408',
    fbSDK: '299953330100883',
    twtConsumerApiKey: '1xUfTfzRrfgTY6isqPsQRA',
    twtConsumerSecretKey: 'GErqoPXUKV1fv8tgBjS0c7zMmyVJeCFmApDNn8BJEc',
    amplitudeKey: '7a16172fd03f9288cc765d3224675bbe',
    raygun: 'hZfi504KWHraiA3vcwk5w',
    webpUrl: 'https://angartwork.akamaized.net/webp/',
    akamizedUrl: 'https://angartwork.akamaized.net/',
    LANDING_API: 'https://lab.anghami.com/rest/v1/GETLandingpagev2.view',
    assetsCDN: 'https://anghamiwebcdn.akamaized.net/web/assets/',
    domain: '.anghami.com',
    recaptchaKey: '6LcsnakUAAAAAOi6tEpMkI3IQmHJ03hEEq1zEB9v',
    sentry_dsn: 'https://651700c084cd44959101bc66f79e14ab@sentry.io/1760742',
    AE_merchant_info: {
        checkout_public_key: 'pk_a5ab5910-0b91-4f9f-935b-7404e8629f39',
        merchant_id: 'merchant.com.ae.anghami'
    },
    checkout_public_key: 'pk_7a642e0d-5152-4f74-b19a-0974b14ddef8',
    merchant_id: 'merchant.com.anghami',
    checkout_url: 'https://api2.checkout.com/v2/tokens/card',
    checkout_applePay_url: 'https://api.checkout.com/tokens',
};


/***/ })

}]);