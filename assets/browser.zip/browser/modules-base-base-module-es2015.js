(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modules-base-base-module"],{

/***/ "./node_modules/@ngx-progressbar/core/fesm2015/ngx-progressbar-core.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@ngx-progressbar/core/fesm2015/ngx-progressbar-core.js ***!
  \*****************************************************************************/
/*! exports provided: NgProgressModule, NgProgressComponent, NgProgressRef, NgProgress, NG_PROGRESS_CONFIG */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgProgressModule", function() { return NgProgressModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgProgressComponent", function() { return NgProgressComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgProgressRef", function() { return NgProgressRef; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgProgress", function() { return NgProgress; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NG_PROGRESS_CONFIG", function() { return NG_PROGRESS_CONFIG; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");





/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgProgressRef {
    /**
     * @param {?} customConfig
     * @param {?} _onDestroyCallback
     */
    constructor(customConfig, _onDestroyCallback) {
        this._onDestroyCallback = _onDestroyCallback;
        /**
         * Stream that increments and updates progress state
         */
        this._trickling = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        /**
         * Stream that combines "_trickling" and "config" streams
         */
        this._worker = rxjs__WEBPACK_IMPORTED_MODULE_1__["Subscription"].EMPTY;
        this._state = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({ active: false, value: 0 });
        this._config = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](customConfig);
        this.state = this._state.asObservable();
        this.config = this._state.asObservable();
        this._worker = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["combineLatest"])(this._trickling, this._config).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["debounce"])((/**
         * @param {?} __0
         * @return {?}
         */
        ([start, config]) => Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["timer"])(start ? config.debounceTime : 0))), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])((/**
         * @param {?} __0
         * @return {?}
         */
        ([start, config]) => start ? this.onTrickling(config) : this.onComplete(config)))).subscribe();
    }
    /**
     * Get current progress state
     * @private
     * @return {?}
     */
    get currState() {
        return this._state.value;
    }
    /**
     * Check if progress has started
     * @return {?}
     */
    get isStarted() {
        return this.currState.active;
    }
    /**
     * Progress start event
     * @return {?}
     */
    get started() {
        return this._state.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((/**
         * @param {?} state
         * @return {?}
         */
        (state) => state.active)), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["distinctUntilChanged"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["filter"])((/**
         * @param {?} active
         * @return {?}
         */
        active => active)));
    }
    /**
     * Progress ended event
     * @return {?}
     */
    get completed() {
        return this._state.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((/**
         * @param {?} state
         * @return {?}
         */
        (state) => state.active)), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["distinctUntilChanged"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["filter"])((/**
         * @param {?} active
         * @return {?}
         */
        active => !active)), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["skip"])(1));
    }
    /**
     * Start the progress
     * @return {?}
     */
    start() {
        this._trickling.next(true);
    }
    /**
     * Complete the progress
     * @return {?}
     */
    complete() {
        this._trickling.next(false);
    }
    /**
     * Increment the progress
     * @param {?=} amount
     * @return {?}
     */
    inc(amount) {
        /** @type {?} */
        const n = this.currState.value;
        if (!this.isStarted) {
            this.start();
        }
        else {
            if (typeof amount !== 'number') {
                amount = this._config.value.trickleFunc(n);
            }
            this.set(n + amount);
        }
    }
    /**
     * Set the progress
     * @param {?} n
     * @return {?}
     */
    set(n) {
        this.setState({ value: this.clamp(n), active: true });
    }
    /**
     * Set config
     * @param {?} config
     * @return {?}
     */
    setConfig(config) {
        this._config.next(Object.assign({}, this._config.value, config));
    }
    /**
     * Destroy progress reference
     * @return {?}
     */
    destroy() {
        this._worker.unsubscribe();
        this._trickling.complete();
        this._state.complete();
        this._config.complete();
        this._onDestroyCallback();
    }
    /**
     * Set progress state
     * @private
     * @param {?} state
     * @return {?}
     */
    setState(state) {
        this._state.next(Object.assign({}, this.currState, state));
    }
    /**
     * Clamps a value to be between min and max
     * @private
     * @param {?} n
     * @return {?}
     */
    clamp(n) {
        return Math.max(this._config.value.min, Math.min(this._config.value.max, n));
    }
    /**
     * Keeps incrementing the progress
     * @private
     * @param {?} config
     * @return {?}
     */
    onTrickling(config) {
        if (!this.isStarted) {
            this.set(this._config.value.min);
        }
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["timer"])(0, config.trickleSpeed).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])((/**
         * @return {?}
         */
        () => this.inc())));
    }
    /**
     * Completes then resets the progress
     * @private
     * @param {?} config
     * @return {?}
     */
    onComplete(config) {
        return !this.isStarted ? Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({}) : Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({}).pipe(
        // Completes the progress
        Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])((/**
         * @return {?}
         */
        () => this.setState({ value: 100 }))), 
        // Hides the progress bar after a tiny delay
        Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["delay"])(config.speed * 1.7), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])((/**
         * @return {?}
         */
        () => this.setState({ active: false }))), 
        // Resets the progress state
        Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["delay"])(config.speed), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])((/**
         * @return {?}
         */
        () => this.setState({ value: 0 }))));
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const NG_PROGRESS_CONFIG = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["InjectionToken"]('ngProgressConfig');

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
const ɵ0 = /**
 * @param {?} n
 * @return {?}
 */
(n) => {
    if (n >= 0 && n < 20)
        return 10;
    if (n >= 20 && n < 50)
        return 4;
    if (n >= 50 && n < 80)
        return 2;
    if (n >= 80 && n < 99)
        return 0.5;
    return 0;
};
/** @type {?} */
const defaultConfig = {
    min: 8,
    max: 100,
    speed: 200,
    debounceTime: 0,
    trickleSpeed: 300,
    fixed: true,
    meteor: true,
    thick: false,
    spinner: true,
    ease: 'linear',
    color: '#1B95E0',
    direction: 'ltr+',
    spinnerPosition: 'right',
    trickleFunc: (ɵ0)
};
class NgProgress {
    /**
     * @param {?} config
     */
    constructor(config) {
        /**
         * Store progress bar instances
         */
        this._instances = new Map();
        this.config = config ? Object.assign({}, defaultConfig, config) : defaultConfig;
    }
    /**
     * Get or Create progress bar by ID
     * @param {?=} id
     * @param {?=} config
     * @return {?}
     */
    ref(id = 'root', config) {
        if (this._instances.has(id)) {
            // Get ProgressRef instance
            /** @type {?} */
            const progressRef = this._instances.get(id);
            if (config) {
                progressRef.setConfig(Object.assign({}, this.config, config));
            }
            return progressRef;
        }
        else {
            // Create new ProgressRef instance
            /** @type {?} */
            const progressRef = new NgProgressRef(Object.assign({}, this.config, config), this.deleteInstance(id));
            return this._instances.set(id, progressRef).get(id);
        }
    }
    /**
     * Destroy all progress bar instances
     * @return {?}
     */
    destroyAll() {
        this._instances.forEach((/**
         * @param {?} ref
         * @return {?}
         */
        (ref) => ref.destroy()));
    }
    /**
     * A destroyer function for each progress bar instance
     * @private
     * @param {?} id
     * @return {?}
     */
    deleteInstance(id) {
        return (/**
         * @return {?}
         */
        () => {
            this._instances.delete(id);
        });
    }
}
NgProgress.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"], args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
NgProgress.ctorParameters = () => [
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Inject"], args: [NG_PROGRESS_CONFIG,] }] }
];
/** @nocollapse */ NgProgress.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["defineInjectable"])({ factory: function NgProgress_Factory() { return new NgProgress(Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["inject"])(NG_PROGRESS_CONFIG, 8)); }, token: NgProgress, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgProgressComponent {
    /**
     * @param {?} _ngProgress
     */
    constructor(_ngProgress) {
        this._ngProgress = _ngProgress;
        this._started = rxjs__WEBPACK_IMPORTED_MODULE_1__["Subscription"].EMPTY;
        this._completed = rxjs__WEBPACK_IMPORTED_MODULE_1__["Subscription"].EMPTY;
        /**
         * Creates a new instance if id is not already exists
         */
        this.id = 'root';
        /**
         * Initializes inputs from the global config
         */
        this.min = this._ngProgress.config.min;
        this.max = this._ngProgress.config.max;
        this.ease = this._ngProgress.config.ease;
        this.color = this._ngProgress.config.color;
        this.speed = this._ngProgress.config.speed;
        this.thick = this._ngProgress.config.thick;
        this.fixed = this._ngProgress.config.fixed;
        this.meteor = this._ngProgress.config.meteor;
        this.spinner = this._ngProgress.config.spinner;
        this.trickleSpeed = this._ngProgress.config.trickleSpeed;
        this.debounceTime = this._ngProgress.config.debounceTime;
        this.trickleFunc = this._ngProgress.config.trickleFunc;
        this.spinnerPosition = this._ngProgress.config.spinnerPosition;
        this.direction = this._ngProgress.config.direction;
        this.started = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.completed = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
    }
    /**
     * @return {?}
     */
    get isStarted() {
        return this.progressRef.isStarted;
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        if (this.progressRef instanceof NgProgressRef) {
            // Update progress bar config when inputs change
            this.progressRef.setConfig({
                max: (this.max > 0 && this.max <= 100) ? this.max : 100,
                min: (this.min < 100 && this.min >= 0) ? this.min : 0,
                speed: this.speed,
                trickleSpeed: this.trickleSpeed,
                trickleFunc: this.trickleFunc,
                debounceTime: this.debounceTime
            });
        }
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        // Get progress bar service instance
        this.progressRef = this._ngProgress.ref(this.id, {
            max: this.max,
            min: this.min,
            speed: this.speed,
            trickleSpeed: this.trickleSpeed,
            debounceTime: this.debounceTime
        });
        // Subscribe to progress state
        this.state$ = this.progressRef.state.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((/**
         * @param {?} state
         * @return {?}
         */
        (state) => ({
            active: state.active,
            transform: `translate3d(${state.value}%,0,0)`
        }))));
        // Subscribes to started and completed events on deman
        if (this.started.observers.length) {
            this._started = this.progressRef.started.subscribe((/**
             * @return {?}
             */
            () => this.started.emit()));
        }
        if (this.completed.observers.length) {
            this._completed = this.progressRef.completed.subscribe((/**
             * @return {?}
             */
            () => this.completed.emit()));
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this._started.unsubscribe();
        this._completed.unsubscribe();
        if (this.progressRef instanceof NgProgressRef) {
            this.progressRef.destroy();
        }
    }
    /**
     * @return {?}
     */
    start() {
        this.progressRef.start();
    }
    /**
     * @return {?}
     */
    complete() {
        this.progressRef.complete();
    }
    /**
     * @param {?=} n
     * @return {?}
     */
    inc(n) {
        this.progressRef.inc(n);
    }
    /**
     * @param {?} n
     * @return {?}
     */
    set(n) {
        this.progressRef.set(n);
    }
}
NgProgressComponent.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"], args: [{
                selector: 'ng-progress',
                host: {
                    'role': 'progressbar',
                    '[attr.spinnerPosition]': 'spinnerPosition',
                    '[attr.dir]': 'direction',
                    '[attr.thick]': 'thick',
                    '[attr.fixed]': 'fixed'
                },
                template: `
    <ng-container *ngIf="state$ | async; let state">
      <div class="ng-progress-bar"
            [class.-active]="state.active"
            [style.transition]="'opacity ' + speed + 'ms ' + ease">
        <div class="ng-bar-placeholder">
          <div class="ng-bar"
                [style.transform]="state.transform"
                [style.backgroundColor]="color"
                [style.transition]="state.active ? 'all ' + speed + 'ms ' + ease : 'none'">
            <div *ngIf="meteor" class="ng-meteor" [style.boxShadow]="'0 0 10px '+ color + ', 0 0 5px ' + color"></div>
          </div>
        </div>
        <div *ngIf="spinner" class="ng-spinner">
          <div class="ng-spinner-icon"
                [style.borderTopColor]="color"
                [style.borderLeftColor]="color"></div>
        </div>
      </div>
    </ng-container>
  `,
                encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewEncapsulation"].None,
                changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
                preserveWhitespaces: false,
                styles: ["ng-progress{z-index:999999;pointer-events:none}ng-progress[fixed=true] .ng-progress-bar,ng-progress[fixed=true] .ng-spinner{position:fixed}ng-progress[fixed=true] .ng-spinner{top:15px}ng-progress[fixed=true][spinnerPosition=left] .ng-spinner{left:15px}ng-progress[fixed=true][spinnerPosition=right] .ng-spinner{right:15px}ng-progress[thick=true] .ng-spinner-icon{width:24px;height:24px;border-width:3px}ng-progress[thick=true] .ng-bar-placeholder{height:3px!important}ng-progress[dir='ltr+'] .ng-meteor,ng-progress[dir=ltr-] .ng-meteor{-webkit-transform:rotate(3deg);transform:rotate(3deg)}ng-progress[dir='ltr+'][thick=true] .ng-meteor,ng-progress[dir=ltr-][thick=true] .ng-meteor{-webkit-transform:rotate(4deg);transform:rotate(4deg)}ng-progress[dir='ltr+'] .ng-bar,ng-progress[dir='rtl+'] .ng-bar{margin-left:-100%}ng-progress[dir='ltr+'] .ng-meteor,ng-progress[dir='rtl+'] .ng-meteor{right:0}ng-progress[dir='ltr+'] .ng-meteor,ng-progress[dir=rtl-] .ng-meteor{top:-3px}ng-progress[dir='ltr+'][thick=true] .ng-meteor,ng-progress[dir=rtl-][thick=true] .ng-meteor{top:-4px}ng-progress[dir='rtl+'] .ng-meteor,ng-progress[dir=ltr-] .ng-meteor{bottom:-3px}ng-progress[dir='rtl+'][thick=true] .ng-meteor,ng-progress[dir=ltr-][thick=true] .ng-meteor{bottom:-4px}ng-progress[dir='rtl+'] .ng-bar-placeholder,ng-progress[dir=ltr-] .ng-bar-placeholder{-webkit-transform:rotate(180deg);transform:rotate(180deg)}ng-progress[dir='rtl+'] .ng-spinner-icon,ng-progress[dir=ltr-] .ng-spinner-icon{animation-direction:reverse}ng-progress[dir='rtl+'] .ng-meteor,ng-progress[dir=rtl-] .ng-meteor{-webkit-transform:rotate(-3deg);transform:rotate(-3deg)}ng-progress[dir='rtl+'][thick=true] .ng-meteor,ng-progress[dir=rtl-][thick=true] .ng-meteor{-webkit-transform:rotate(-4deg);transform:rotate(-4deg)}ng-progress[spinnerPosition=left] .ng-spinner{left:10px}ng-progress[spinnerPosition=right] .ng-spinner{right:10px}.ng-progress-bar{position:relative;z-index:999999;top:0;left:0;width:100%;zoom:1;opacity:0}.ng-progress-bar.-active{opacity:1;transition:none}.ng-bar-placeholder{position:absolute;height:2px;width:100%}.ng-bar{width:100%;height:100%;-webkit-transform:translate(-100%,0,0);transform:translate(-100%,0,0)}.ng-meteor{display:block;position:absolute;width:100px;height:100%;opacity:1}.ng-spinner{position:absolute;display:block;z-index:1031;top:10px}.ng-spinner-icon{width:18px;height:18px;box-sizing:border-box;-webkit-animation:250ms linear infinite spinner-animation;animation:250ms linear infinite spinner-animation;border:2px solid transparent;border-radius:50%}@-webkit-keyframes spinner-animation{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes spinner-animation{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}"]
            }] }
];
/** @nocollapse */
NgProgressComponent.ctorParameters = () => [
    { type: NgProgress }
];
NgProgressComponent.propDecorators = {
    id: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    min: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    max: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    ease: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    color: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    speed: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    thick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    fixed: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    meteor: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    spinner: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    trickleSpeed: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    debounceTime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    trickleFunc: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    spinnerPosition: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    direction: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    started: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    completed: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgProgressModule {
    /**
     * @param {?} config
     * @return {?}
     */
    static withConfig(config) {
        return {
            ngModule: NgProgressModule,
            providers: [
                { provide: NG_PROGRESS_CONFIG, useValue: config }
            ]
        };
    }
}
NgProgressModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"], args: [{
                declarations: [NgProgressComponent],
                exports: [NgProgressComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"]]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */



//# sourceMappingURL=ngx-progressbar-core.js.map

/***/ }),

/***/ "./node_modules/@ngx-progressbar/http/fesm2015/ngx-progressbar-http.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@ngx-progressbar/http/fesm2015/ngx-progressbar-http.js ***!
  \*****************************************************************************/
/*! exports provided: NgProgressHttpModule, ɵc, ɵa */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgProgressHttpModule", function() { return NgProgressHttpModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵc", function() { return NG_PROGRESS_HTTP_CONFIG; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵa", function() { return NgProgressInterceptor; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-progressbar/core */ "./node_modules/@ngx-progressbar/core/fesm2015/ngx-progressbar-core.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");





/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const NG_PROGRESS_HTTP_CONFIG = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["InjectionToken"]('ngProgressHttpConfig');

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgProgressInterceptor {
    /**
     * @param {?} ngProgress
     * @param {?=} config
     */
    constructor(ngProgress, config) {
        this._inProgressCount = 0;
        this._config = {
            id: 'root',
            silentApis: []
        };
        this._config = config ? Object.assign({}, this._config, config) : this._config;
        this._progressRef = ngProgress.ref(this._config.id);
    }
    /**
     * @param {?} req
     * @param {?} next
     * @return {?}
     */
    intercept(req, next) {
        // Ignore by request headers
        if (req.headers.has('ignoreProgressBar')) {
            return next.handle(req.clone({ headers: req.headers.delete('ignoreProgressBar') }));
        }
        // Ignore silent api requests
        if (this.checkUrl(req)) {
            return next.handle(req);
        }
        this._inProgressCount++;
        if (!this._progressRef.isStarted) {
            this._progressRef.start();
        }
        return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["finalize"])((/**
         * @return {?}
         */
        () => {
            this._inProgressCount--;
            if (this._inProgressCount === 0) {
                this._progressRef.complete();
            }
        })));
    }
    /**
     * Check if request is silent.
     * @private
     * @param {?} req request
     * @return {?}
     */
    checkUrl(req) {
        /** @type {?} */
        const url = req.url.toLowerCase();
        /** @type {?} */
        const found = this._config.silentApis.find((/**
         * @param {?} u
         * @return {?}
         */
        (u) => url.startsWith(u)));
        return !!found;
    }
}
NgProgressInterceptor.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"] }
];
/** @nocollapse */
NgProgressInterceptor.ctorParameters = () => [
    { type: _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_2__["NgProgress"] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Inject"], args: [NG_PROGRESS_HTTP_CONFIG,] }] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgProgressHttpModule {
    /**
     * @param {?} config
     * @return {?}
     */
    static withConfig(config) {
        return {
            ngModule: NgProgressHttpModule,
            providers: [
                { provide: NG_PROGRESS_HTTP_CONFIG, useValue: config }
            ]
        };
    }
}
NgProgressHttpModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"], args: [{
                providers: [
                    { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HTTP_INTERCEPTORS"], useClass: NgProgressInterceptor, multi: true }
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */



//# sourceMappingURL=ngx-progressbar-http.js.map

/***/ }),

/***/ "./node_modules/@ngx-progressbar/router/fesm2015/ngx-progressbar-router.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@ngx-progressbar/router/fesm2015/ngx-progressbar-router.js ***!
  \*********************************************************************************/
/*! exports provided: NgProgressRouterModule, ɵc, ɵa */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgProgressRouterModule", function() { return NgProgressRouterModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵc", function() { return NG_PROGRESS_ROUTER_CONFIG; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵa", function() { return NgProgressRouter; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-progressbar/core */ "./node_modules/@ngx-progressbar/core/fesm2015/ngx-progressbar-core.js");






/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const NG_PROGRESS_ROUTER_CONFIG = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('ngProgressRouterConfig');

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Check if a router event type exists in an array of router event types
 * @param {?} routerEvent
 * @param {?} events
 * @return {?}
 */
function eventExists(routerEvent, events) {
    /** @type {?} */
    let res = false;
    events.map((/**
     * @param {?} event
     * @return {?}
     */
    (event) => res = res || routerEvent instanceof event));
    return res;
}
class NgProgressRouter {
    /**
     * @param {?} progress
     * @param {?} router
     * @param {?} config
     */
    constructor(progress, router, config) {
        this._config = {
            id: 'root',
            delay: 0,
            startEvents: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["NavigationStart"]],
            completeEvents: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["NavigationEnd"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["NavigationCancel"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["NavigationError"]]
        };
        this._config = config ? Object.assign({}, this._config, config) : this._config;
        /** @type {?} */
        const progressRef = progress.ref(this._config.id);
        /** @type {?} */
        const startProgress = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])({}).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((/**
         * @return {?}
         */
        () => progressRef.start())));
        /** @type {?} */
        const completeProgress = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])({}).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["delay"])(this._config.delay), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((/**
         * @return {?}
         */
        () => progressRef.complete())));
        /** @type {?} */
        const filterEvents = [...this._config.startEvents, ...this._config.completeEvents];
        router.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["filter"])((/**
         * @param {?} event
         * @return {?}
         */
        (event) => eventExists(event, filterEvents))), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])((/**
         * @param {?} event
         * @return {?}
         */
        (event) => eventExists(event, this._config.startEvents) ? startProgress : completeProgress))).subscribe();
    }
}
NgProgressRouter.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"], args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
NgProgressRouter.ctorParameters = () => [
    { type: _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_4__["NgProgress"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [NG_PROGRESS_ROUTER_CONFIG,] }] }
];
/** @nocollapse */ NgProgressRouter.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["defineInjectable"])({ factory: function NgProgressRouter_Factory() { return new NgProgressRouter(Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["inject"])(_ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_4__["NgProgress"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["inject"])(_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["inject"])(NG_PROGRESS_ROUTER_CONFIG, 8)); }, token: NgProgressRouter, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgProgressRouterModule {
    // Inject the service to activate it
    /**
     * @param {?} ngProgressRouter
     */
    constructor(ngProgressRouter) {
    }
    /**
     * @param {?} config
     * @return {?}
     */
    static withConfig(config) {
        return {
            ngModule: NgProgressRouterModule,
            providers: [
                { provide: NG_PROGRESS_ROUTER_CONFIG, useValue: config }
            ]
        };
    }
}
NgProgressRouterModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"], args: [{},] }
];
/** @nocollapse */
NgProgressRouterModule.ctorParameters = () => [
    { type: NgProgressRouter }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */



//# sourceMappingURL=ngx-progressbar-router.js.map

/***/ }),

/***/ "./node_modules/compare-versions/index.js":
/*!************************************************!*\
  !*** ./node_modules/compare-versions/index.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/* global define */
(function (root, factory) {
  /* istanbul ignore next */
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else {}
}(this, function () {

  var semver = /^v?(?:\d+)(\.(?:[x*]|\d+)(\.(?:[x*]|\d+)(\.(?:[x*]|\d+))?(?:-[\da-z\-]+(?:\.[\da-z\-]+)*)?(?:\+[\da-z\-]+(?:\.[\da-z\-]+)*)?)?)?$/i;

  function indexOrEnd(str, q) {
    return str.indexOf(q) === -1 ? str.length : str.indexOf(q);
  }

  function split(v) {
    var c = v.replace(/^v/, '').replace(/\+.*$/, '');
    var patchIndex = indexOrEnd(c, '-');
    var arr = c.substring(0, patchIndex).split('.');
    arr.push(c.substring(patchIndex + 1));
    return arr;
  }

  function tryParse(v) {
    return isNaN(Number(v)) ? v : Number(v);
  }

  function validate(version) {
    if (typeof version !== 'string') {
      throw new TypeError('Invalid argument expected string');
    }
    if (!semver.test(version)) {
      throw new Error('Invalid argument not valid semver (\''+version+'\' received)');
    }
  }

  function compareVersions(v1, v2) {
    [v1, v2].forEach(validate);

    var s1 = split(v1);
    var s2 = split(v2);

    for (var i = 0; i < Math.max(s1.length - 1, s2.length - 1); i++) {
      var n1 = parseInt(s1[i] || 0, 10);
      var n2 = parseInt(s2[i] || 0, 10);

      if (n1 > n2) return 1;
      if (n2 > n1) return -1;
    }

    var sp1 = s1[s1.length - 1];
    var sp2 = s2[s2.length - 1];

    if (sp1 && sp2) {
      var p1 = sp1.split('.').map(tryParse);
      var p2 = sp2.split('.').map(tryParse);

      for (i = 0; i < Math.max(p1.length, p2.length); i++) {
        if (p1[i] === undefined || typeof p2[i] === 'string' && typeof p1[i] === 'number') return -1;
        if (p2[i] === undefined || typeof p1[i] === 'string' && typeof p2[i] === 'number') return 1;

        if (p1[i] > p2[i]) return 1;
        if (p2[i] > p1[i]) return -1;
      }
    } else if (sp1 || sp2) {
      return sp1 ? -1 : 1;
    }

    return 0;
  };

  var allowedOperators = [
    '>',
    '>=',
    '=',
    '<',
    '<='
  ];

  var operatorResMap = {
    '>': [1],
    '>=': [0, 1],
    '=': [0],
    '<=': [-1, 0],
    '<': [-1]
  };

  function validateOperator(op) {
    if (typeof op !== 'string') {
      throw new TypeError('Invalid operator type, expected string but got ' + typeof op);
    }
    if (allowedOperators.indexOf(op) === -1) {
      throw new TypeError('Invalid operator, expected one of ' + allowedOperators.join('|'));
    }
  }

  compareVersions.compare = function (v1, v2, operator) {
    // Validate operator
    validateOperator(operator);

    // since result of compareVersions can only be -1 or 0 or 1
    // a simple map can be used to replace switch
    var res = compareVersions(v1, v2);
    return operatorResMap[operator].indexOf(res) > -1;
  }

  return compareVersions;
}));


/***/ }),

/***/ "./node_modules/ngx-dfp/fesm2015/ngx-dfp.js":
/*!**************************************************!*\
  !*** ./node_modules/ngx-dfp/fesm2015/ngx-dfp.js ***!
  \**************************************************/
/*! exports provided: DfpModule, DFP_CONFIG, IdleService, HttpErrorService, ParseDurationService, ScriptInjectorService, DfpService, DfpIDGeneratorService, DfpRefreshService, DfpAdDirective, DfpAdResponsiveDirective, DfpResponsiveDirective, DfpSizeDirective, DfpTargetingDirective, DfpExclusionDirective, DfpValueDirective, DfpAudiencePixelDirective, ɵe, ɵm, ɵa, ɵq, ɵo, ɵl, ɵk, ɵn, ɵp, ɵh, ɵi, ɵc, ɵg, ɵd, ɵb, ɵj, ɵf */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpModule", function() { return DfpModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DFP_CONFIG", function() { return DFP_CONFIG; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IdleService", function() { return IdleService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpErrorService", function() { return HttpErrorService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ParseDurationService", function() { return ParseDurationService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScriptInjectorService", function() { return ScriptInjectorService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpService", function() { return DfpService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpIDGeneratorService", function() { return DfpIDGeneratorService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpRefreshService", function() { return DfpRefreshService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpAdDirective", function() { return DfpAdDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpAdResponsiveDirective", function() { return DfpAdResponsiveDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpResponsiveDirective", function() { return DfpResponsiveDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpSizeDirective", function() { return DfpSizeDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpTargetingDirective", function() { return DfpTargetingDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpExclusionDirective", function() { return DfpExclusionDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpValueDirective", function() { return DfpValueDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DfpAudiencePixelDirective", function() { return DfpAudiencePixelDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵe", function() { return DfpConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵm", function() { return DfpAdResponsiveDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵa", function() { return DfpAdDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵq", function() { return DfpAudiencePixelDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵo", function() { return DfpExclusionDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵl", function() { return DfpResponsiveDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵk", function() { return DfpSizeDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵn", function() { return DfpTargetingDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵp", function() { return DfpValueDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵh", function() { return DfpIDGeneratorService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵi", function() { return DfpRefreshService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵc", function() { return DfpService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵg", function() { return HttpErrorService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵd", function() { return IdleService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵb", function() { return DFP_CONFIG; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵj", function() { return ParseDurationService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵf", function() { return ScriptInjectorService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");






/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @type {?} */
const DFP_CONFIG = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('dfpConfig');

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class IdleService {
    /**
     * @param {?} platformId
     * @param {?} zone
     */
    constructor(platformId, zone) {
        /** @type {?} */
        const win = Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(platformId) ? window : {};
        if (win.requestIdleCallback) {
            this.requestIdleCallback = (fun) => {
                return win.requestIdleCallback(fun);
            };
        }
        else {
            this.requestIdleCallback = (fun) => {
                return zone.runOutsideAngular(() => win.setTimeout(fun, 50));
            };
        }
    }
    /**
     * @param {?} fun
     * @return {?}
     */
    request(fun) {
        this.requestIdleCallback(fun);
    }
}
IdleService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"] }
];
/** @nocollapse */
IdleService.ctorParameters = () => [
    { type: Object, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"],] }] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class HttpErrorService {
    constructor() {
        this.isErrorCode = function (code) {
            if (typeof code === 'number') {
                return !(code >= 200 && code < 300);
            }
            return code[0] !== '2';
        };
    }
    /**
     * @param {?} response
     * @param {?} message
     * @return {?}
     */
    httpError(response, message) {
        console.log(`Error (${response.status}) ${message ? message : ''}`);
    }
}
HttpErrorService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DFPDurationError extends Error {
    /**
     * @param {?} interval
     */
    constructor(interval) {
        super(`Invalid interval: '${interval}'ls`);
    }
}
class ParseDurationService {
    /**
     * @param {?} time
     * @param {?} unit
     * @return {?}
     */
    convertToMilliseconds(time, unit) {
        console.assert(/^(m?s|min|h)$/g.test(unit));
        if (unit === 'ms') {
            return time;
        }
        if (unit === 's') {
            return time * 1000;
        }
        if (unit === 'min') {
            return time * 60 * 1000;
        }
        return time * 60 * 60 * 1000;
    }
    /**
     * @param {?} match
     * @return {?}
     */
    convert(match) {
        /** @type {?} */
        const time = parseFloat(match[1]);
        if (match.length === 2) {
            return time;
        }
        return this.convertToMilliseconds(time, match[2]);
    }
    /**
     * @param {?} interval
     * @return {?}
     */
    parseDuration(interval) {
        if (interval === undefined || interval === null) {
            throw new DFPDurationError(interval);
        }
        if (typeof interval === 'number') {
            return interval;
        }
        if (typeof interval !== 'string') {
            throw new TypeError(`'${interval}' must be of number or string type`);
        }
        /** @type {?} */
        const match = interval.match(/((?:\d+)?.?\d+)(m?s|min|h)?/);
        if (!match) {
            throw new DFPDurationError(interval);
        }
        return this.convert(match);
    }
}
ParseDurationService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class ScriptInjectorService {
    /**
     * @param {?} httpError
     */
    constructor(httpError) {
        this.httpError = httpError;
    }
    /**
     * @param {?} url
     * @return {?}
     */
    completeURL(url) {
        /** @type {?} */
        const ssl = document.location.protocol === 'https:';
        return (ssl ? 'https:' : 'http:') + url;
    }
    /**
     * @param {?} url
     * @return {?}
     */
    createScript(url) {
        /** @type {?} */
        const script = document.createElement('script');
        script.async = true;
        script.type = 'text/javascript';
        script.src = this.completeURL(url);
        return script;
    }
    /**
     * @param {?} script
     * @param {?} url
     * @return {?}
     */
    promiseScript(script, url) {
        /** @type {?} */
        const promise = new Promise((resolve, reject) => {
            script.onload = () => {
                resolve(script);
            };
            script.onerror = () => {
                reject({
                    path: url,
                    loaded: false
                });
            };
        });
        promise.catch(response => {
            this.httpError.httpError({ status: 400 }, `loading script "${url}"`);
        });
        return promise;
    }
    /**
     * @param {?} script
     * @return {?}
     */
    injectScript(script) {
        /** @type {?} */
        const head = document.head || document.querySelector('head');
        head.appendChild(script);
    }
    /**
     * @param {?} url
     * @return {?}
     */
    scriptInjector(url) {
        /** @type {?} */
        const script = this.createScript(url);
        this.injectScript(script);
        return this.promiseScript(script, url);
    }
}
ScriptInjectorService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"] }
];
/** @nocollapse */
ScriptInjectorService.ctorParameters = () => [
    { type: HttpErrorService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DFPIncompleteError extends Error {
    /**
     * @param {?} directiveName
     * @param {?} missingName
     * @param {?=} isAttribute
     */
    constructor(directiveName, missingName, isAttribute) {
        super(`Incomplete definition of '${directiveName}': ` +
            `Missing ${isAttribute ? 'attribute' : 'child directive'} ` +
            `'${missingName}'.`);
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpConfig {
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @type {?} */
const GPT_LIBRARY_URL = '//www.googletagservices.com/tag/js/gpt.js';
class DFPConfigurationError extends Error {
}
class DfpService {
    /**
     * @param {?} platformId
     * @param {?} idleLoad
     * @param {?} config
     * @param {?} scriptInjector
     */
    constructor(platformId, idleLoad, config, scriptInjector) {
        this.platformId = platformId;
        this.config = config;
        this.scriptInjector = scriptInjector;
        this.enableVideoAds = false;
        this.personalizedAds = true;
        this.collapseIfEmpty = true;
        this.centering = false;
        this.location = null;
        this.ppid = null;
        this.globalTargeting = null;
        this.forceSafeFrame = false;
        this.safeFrameConfig = null;
        this.loadGPT = true;
        this.loaded = false;
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(this.platformId)) {
            /** @type {?} */
            const win = window;
            /** @type {?} */
            const googletag = win.googletag || {};
            this.dfpConfig();
            googletag.cmd = googletag.cmd || [];
            googletag.cmd.push(() => {
                this.setup();
            });
            win.googletag = googletag;
            if (this.loadGPT) {
                /** @type {?} */
                const loadScript = () => {
                    this.scriptInjector.scriptInjector(GPT_LIBRARY_URL).then((script) => {
                        this.loaded = true;
                    });
                };
                if (idleLoad) {
                    idleLoad.request(loadScript);
                }
                else {
                    loadScript();
                }
            }
        }
    }
    /**
     * @return {?}
     */
    dfpConfig() {
        for (const key in this.config) {
            if (this.hasOwnProperty(key)) {
                this[key] = this.config[key];
            }
        }
    }
    /**
     * @param {?} pubads
     * @return {?}
     */
    addSafeFrameConfig(pubads) {
        if (!this.safeFrameConfig) {
            return false;
        }
        if (typeof this.safeFrameConfig !== 'object') {
            throw new DFPConfigurationError('FrameConfig must be an object');
        }
        pubads.setSafeFrameConfig(this.safeFrameConfig);
    }
    /**
     * @param {?} pubads
     * @return {?}
     */
    addTargeting(pubads) {
        if (!this.globalTargeting) {
            return false;
        }
        if (typeof this.globalTargeting !== 'object') {
            throw new DFPConfigurationError('Targeting must be an object');
        }
        for (const key in this.globalTargeting) {
            if (this.globalTargeting.hasOwnProperty(key)) {
                pubads.setTargeting(key, this.globalTargeting[key]);
            }
        }
    }
    /**
     * @param {?} pubads
     * @return {?}
     */
    addLocation(pubads) {
        if (!this.location) {
            return false;
        }
        if (typeof this.location === 'string') {
            pubads.setLocation(this.location);
            return;
        }
        if (!Array.isArray(this.location)) {
            throw new DFPConfigurationError('Location must be an ' +
                'array or string');
        }
        pubads.setLocation.apply(pubads, this.location);
    }
    /**
     * @param {?} pubads
     * @return {?}
     */
    addPPID(pubads) {
        if (!this.ppid) {
            return false;
        }
        if (typeof this.ppid !== 'string') {
            throw new DFPConfigurationError('PPID must be a string');
        }
        pubads.setPublisherProvidedId(this.ppid);
    }
    /**
     * @return {?}
     */
    setup() {
        /** @type {?} */
        const win = window;
        /** @type {?} */
        const googletag = win.googletag;
        /** @type {?} */
        const pubads = googletag.pubads();
        if (this.enableVideoAds) {
            pubads.enableVideoAds();
        }
        // personalizedAds is default
        if (this.personalizedAds === false) {
            pubads.setRequestNonPersonalizedAds(1);
        }
        if (this.collapseIfEmpty) {
            pubads.collapseEmptyDivs();
        }
        // We always refresh ourselves
        pubads.disableInitialLoad();
        pubads.setForceSafeFrame(this.forceSafeFrame);
        pubads.setCentering(this.centering);
        this.addLocation(pubads);
        this.addPPID(pubads);
        this.addTargeting(pubads);
        this.addSafeFrameConfig(pubads);
        // pubads.enableSyncRendering();
        pubads.enableAsyncRendering();
        if (this.config.singleRequestMode !== true) {
            if (this.config.enableVideoAds) {
                pubads.enableVideoAds();
            }
            googletag.enableServices();
        }
    }
    /**
     * @return {?}
     */
    hasLoaded() {
        return this.loaded;
    }
    /**
     * @param {?} task
     * @return {?}
     */
    defineTask(task) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(this.platformId)) {
            /** @type {?} */
            const win = window;
            /** @type {?} */
            const googletag = win.googletag;
            googletag.cmd.push(task);
        }
    }
}
DfpService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"] }
];
/** @nocollapse */
DfpService.ctorParameters = () => [
    { type: Object, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"],] }] },
    { type: IdleService, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }] },
    { type: DfpConfig, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [DFP_CONFIG,] }] },
    { type: ScriptInjectorService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpIDGeneratorService {
    constructor() {
        this.generatedIDs = {};
    }
    /**
     * @param {?=} type
     * @return {?}
     */
    generateID(type = 'dfp-ad') {
        /** @type {?} */
        let id = null;
        do {
            /** @type {?} */
            const number = Math.random().toString().slice(2);
            id = type + '-' + number;
        } while (id in this.generatedIDs);
        this.generatedIDs[id] = true;
        return id;
    }
    /**
     * @param {?} element
     * @return {?}
     */
    dfpIDGenerator(element) {
        if (element && element.id && !(element.id in this.generatedIDs)) {
            return element.id;
        }
        /** @type {?} */
        const id = this.generateID(element.tagName.toLowerCase());
        if (element) {
            element.id = id;
        }
        return id;
    }
    /**
     * @param {?} id
     * @return {?}
     */
    isTaken(id) {
        return id in this.generatedIDs;
    }
    /**
     * @param {?} id
     * @return {?}
     */
    isUnique(id) {
        return !this.isTaken(id);
    }
}
DfpIDGeneratorService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DFPRefreshError extends Error {
}
class DfpRefreshService {
    /**
     * @param {?} config
     * @param {?} inject
     * @param {?} parseDuration
     */
    constructor(config, inject, parseDuration) {
        this.config = config;
        this.inject = inject;
        this.parseDuration = parseDuration;
        this.refreshEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.refreshSlots = [];
        this.intervals = {};
    }
    /**
     * @param {?} slot
     * @param {?=} refreshInterval
     * @param {?=} initRefresh
     * @return {?}
     */
    slotRefresh(slot, refreshInterval, initRefresh = false) {
        /** @type {?} */
        const deferred = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["from"])([slot]).toPromise();
        /** @type {?} */
        const task = { slot: slot, deferred: deferred };
        deferred.then(() => {
            if (this.hasSlotInterval(slot)) {
                this.cancelInterval(slot);
            }
            if (refreshInterval) {
                this.addSlotInterval(task, refreshInterval);
            }
        });
        if (this.config.singleRequestMode === true && initRefresh) {
            // Use a timer to handle refresh of a single request mode
            this.refreshSlots.push(slot);
            if (this.singleRequest && !this.singleRequest.closed) {
                this.singleRequest.unsubscribe();
            }
            this.singleRequest = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["timer"])(100).subscribe(() => {
                /** @type {?} */
                const pubads = googletag.pubads();
                pubads.enableSingleRequest();
                googletag.enableServices();
                this.refreshSlots.forEach(s => {
                    googletag.display(s.getSlotElementId());
                });
                pubads.refresh(this.refreshSlots);
                this.refreshSlots = [];
            });
        }
        else {
            googletag.display(slot.getSlotElementId());
            this.refresh([task]);
        }
        return deferred;
    }
    /**
     * @param {?} slot
     * @return {?}
     */
    cancelInterval(slot) {
        if (!this.hasSlotInterval(slot)) {
            throw new DFPRefreshError('No interval for given slot');
        }
        /** @type {?} */
        const interval = this.intervals[this.slotIntervalKey(slot)];
        interval.unsubscribe();
        delete this.intervals[slot];
        return this;
    }
    /**
     * @param {?} slot
     * @return {?}
     */
    hasSlotInterval(slot) {
        return this.slotIntervalKey(slot) in this.intervals;
    }
    /**
     * @param {?=} tasks
     * @return {?}
     */
    refresh(tasks) {
        if (tasks === undefined) {
            googletag.cmd.push(() => {
                googletag.pubads().refresh();
            });
            return;
        }
        if (tasks.length === 0) {
            return false;
        }
        googletag.cmd.push(() => {
            googletag.pubads().refresh(tasks.map(task => task.slot));
            tasks.forEach(task => {
                Promise.resolve(task.slot);
            });
        });
    }
    /**
     * @param {?} task
     * @param {?} interval
     * @return {?}
     */
    addSlotInterval(task, interval) {
        /** @type {?} */
        const parsedInterval = this.parseDuration.parseDuration(interval);
        this.validateInterval(parsedInterval, interval);
        /** @type {?} */
        const refresh = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["timer"])(parsedInterval, parsedInterval).subscribe(() => {
            /** @type {?} */
            const doc = this.inject.get(_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"]);
            if (!this.hiddenCheck(doc.getElementById(task.slot.getSlotElementId()))) {
                this.refresh([task]);
                this.refreshEvent.emit(task.slot);
            }
        });
        this.intervals[this.slotIntervalKey(task.slot)] = refresh;
        return refresh;
    }
    /**
     * @param {?} slot
     * @return {?}
     */
    slotIntervalKey(slot) {
        return slot.getSlotId().getDomId();
    }
    /**
     * @param {?} milliseconds
     * @param {?} beforeParsing
     * @return {?}
     */
    validateInterval(milliseconds, beforeParsing) {
        if (milliseconds < 1000) {
            console.warn('Careful: ${beforeParsing} is quite a low interval!');
        }
    }
    /**
     * @param {?} element
     * @return {?}
     */
    hiddenCheck(element) {
        if (typeof (window) !== 'undefined') {
            /** @type {?} */
            const css = window.getComputedStyle(element);
            if (css.display === 'none') {
                return true;
            }
            else if (element.parentElement) {
                return this.hiddenCheck(element.parentElement);
            }
        }
        return false;
    }
}
DfpRefreshService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"] }
];
/** @nocollapse */
DfpRefreshService.ctorParameters = () => [
    { type: DfpConfig, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [DFP_CONFIG,] }] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"] },
    { type: ParseDurationService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpAdDirective {
    /**
     * @param {?} platformId
     * @param {?} elementRef
     * @param {?} dfp
     * @param {?} dfpIDGenerator
     * @param {?} dfpRefresh
     * @param {?} config
     * @param {?} router
     */
    constructor(platformId, elementRef, dfp, dfpIDGenerator, dfpRefresh, config, router) {
        this.platformId = platformId;
        this.elementRef = elementRef;
        this.dfp = dfp;
        this.dfpIDGenerator = dfpIDGenerator;
        this.dfpRefresh = dfpRefresh;
        this.config = config;
        this.afterRefresh = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.sizes = [];
        this.responsiveMapping = [];
        this.targetings = [];
        this.exclusions = [];
        this.scripts = [];
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(this.platformId)) {
            this.dfpRefresh.refreshEvent.subscribe(slot => {
                if (slot === this.slot) {
                    this.afterRefresh.emit({ type: 'refresh', slot: slot });
                }
            });
            if (router) {
                this.onSameNavigation = router.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["filter"])(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_3__["NavigationEnd"]))
                    .subscribe((event) => {
                    if (this.slot && !this.refresh && this.config.onSameNavigation === 'refresh') {
                        this.refreshContent.call(this);
                    }
                });
            }
        }
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(this.platformId)) {
            this.dfpIDGenerator.dfpIDGenerator(this.elementRef.nativeElement);
        }
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(this.platformId)) {
            this.dfp.defineTask(() => {
                this.defineSlot();
            });
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.slot) {
            googletag.destroySlots([this.slot]);
        }
        if (this.onSameNavigation) {
            this.onSameNavigation.unsubscribe();
        }
    }
    /**
     * @param {?} slot
     * @return {?}
     */
    setResponsiveMapping(slot) {
        /** @type {?} */
        const ad = this.getState();
        if (ad.responsiveMapping.length === 0) {
            return;
        }
        /** @type {?} */
        const sizeMapping = googletag.sizeMapping();
        ad.responsiveMapping.forEach(mapping => {
            sizeMapping.addSize(mapping.viewportSize, mapping.adSizes);
        });
        slot.defineSizeMapping(sizeMapping.build());
    }
    /**
     * @return {?}
     */
    defineSlot() {
        /** @type {?} */
        const ad = this.getState();
        /** @type {?} */
        const element = this.elementRef.nativeElement;
        this.slot = googletag.defineSlot(ad.adUnit, ad.sizes, element.id);
        if (this.forceSafeFrame !== undefined && ad.forceSafeFrame === !this.config.forceSafeFrame) {
            this.slot.setForceSafeFrame(ad.forceSafeFrame);
        }
        if (ad.clickUrl) {
            this.slot.setClickUrl(ad.clickUrl);
        }
        if (ad.collapseIfEmpty) {
            this.slot.setCollapseEmptyDiv(true, true);
        }
        if (ad.safeFrameConfig) {
            this.slot.setSafeFrameConfig((JSON.parse(ad.safeFrameConfig)));
        }
        googletag.pubads().addEventListener('slotRenderEnded', (event) => {
            if (event.slot === this.slot) {
                this.afterRefresh.emit({ type: 'renderEnded', slot: this.slot, data: event });
            }
        });
        this.setResponsiveMapping(this.slot);
        ad.targetings.forEach(targeting => {
            this.slot.setTargeting(targeting.key, targeting.values);
        });
        ad.exclusions.forEach(exclusion => {
            this.slot.setCategoryExclusion(exclusion);
        });
        ad.scripts.forEach(script => { script(this.slot); });
        if (this.config.enableVideoAds) {
            this.slot.addService(googletag.companionAds());
        }
        this.slot.addService(googletag.pubads());
        this.refreshContent();
    }
    /**
     * @return {?}
     */
    refreshContent() {
        this.dfpRefresh.slotRefresh(this.slot, this.refresh, true).then(slot => {
            this.afterRefresh.emit({ type: 'init', slot: slot });
        });
    }
    /**
     * @return {?}
     */
    checkValid() {
        if (this.sizes.length === 0) {
            throw new DFPIncompleteError('dfp-ad', 'dfp-size');
        }
        if (!this.adUnit) {
            throw new DFPIncompleteError('dfp-ad', 'ad-unit', true);
        }
    }
    /**
     * @return {?}
     */
    get isHidden() {
        return this.dfpRefresh.hiddenCheck(this.elementRef.nativeElement);
    }
    /**
     * @return {?}
     */
    getState() {
        this.checkValid();
        return Object.freeze({
            sizes: this.sizes,
            responsiveMapping: this.responsiveMapping,
            targetings: this.targetings,
            exclusions: this.exclusions,
            adUnit: this.adUnit,
            forceSafeFrame: this.forceSafeFrame === true,
            safeFrameConfig: this.safeFrameConfig,
            clickUrl: this.clickUrl,
            refresh: this.refresh,
            scripts: this.scripts,
            collapseIfEmpty: this.collapseIfEmpty === true
        });
    }
    /**
     * @param {?} size
     * @return {?}
     */
    addSize(size) {
        this.sizes.push(size);
    }
    /**
     * @param {?} mapping
     * @return {?}
     */
    addResponsiveMapping(mapping) {
        this.responsiveMapping.push(mapping);
    }
    /**
     * @param {?} targeting
     * @return {?}
     */
    addTargeting(targeting) {
        this.targetings.push(targeting);
    }
    /**
     * @param {?} exclusion
     * @return {?}
     */
    addExclusion(exclusion) {
        this.exclusions.push(exclusion);
    }
    /**
     * @param {?} script
     * @return {?}
     */
    addScript(script) {
        this.scripts.push(script);
    }
}
DfpAdDirective.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"], args: [{
                selector: 'dfp-ad'
            },] }
];
/** @nocollapse */
DfpAdDirective.ctorParameters = () => [
    { type: Object, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"],] }] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: DfpService },
    { type: DfpIDGeneratorService },
    { type: DfpRefreshService },
    { type: DfpConfig, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [DFP_CONFIG,] }] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }] }
];
DfpAdDirective.propDecorators = {
    adUnit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    clickUrl: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    forceSafeFrame: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    safeFrameConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    refresh: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    collapseIfEmpty: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    afterRefresh: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpAdResponsiveDirective {
    /**
     * @param {?} elementRef
     * @param {?} ad
     * @param {?} dfpRefresh
     */
    constructor(elementRef, ad, dfpRefresh) {
        this.elementRef = elementRef;
        this.ad = ad;
        this.dfpRefresh = dfpRefresh;
        this.ad.afterRefresh.subscribe(event => {
            this.slot = event.slot;
        });
    }
    /**
     * @return {?}
     */
    normalizeIframe() {
        if (this.ad.isHidden) {
            return false;
        }
        this.iframe = this.iframe || this.getIframe();
        if (!this.iframe) {
            return false;
        }
        this.iframeWidth = this.iframeWidth || +this.iframe.width;
        /** @type {?} */
        const winWidth = window.innerWidth;
        /** @type {?} */
        let state = this.ad.getState();
        /** @type {?} */
        let width = 0;
        state.sizes.forEach(size => {
            if (size[0] < winWidth) {
                width = Math.max(width, size[0]);
            }
        });
        if (state.sizes.length > 1 && width !== this.iframeWidth) {
            state = this.ad.getState();
            this.iframeWidth = width;
            this.iframe.setAttribute('width', width + '');
            this.dfpRefresh.slotRefresh(this.slot, state.refresh).then(slot => {
                this.ad.afterRefresh.emit({ type: 'resize', slot: slot });
                this.iframe = this.getIframe();
            });
        }
    }
    /**
     * @return {?}
     */
    getIframe() {
        /** @type {?} */
        const ad = this.elementRef.nativeElement;
        /** @type {?} */
        const iframe = ad.querySelector('iframe');
        if (iframe && +iframe.width > 0) {
            return iframe;
        }
    }
}
DfpAdResponsiveDirective.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"], args: [{
                selector: 'dfp-ad[responsive]'
            },] }
];
/** @nocollapse */
DfpAdResponsiveDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: DfpAdDirective, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(() => DfpAdDirective),] }] },
    { type: DfpRefreshService }
];
DfpAdResponsiveDirective.propDecorators = {
    normalizeIframe: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"], args: ['window:resize',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpResponsiveDirective {
    /**
     * @param {?} ad
     */
    constructor(ad) {
        this.ad = ad;
        this.viewport = [0, 0];
        this.adSizes = [];
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.ad.addResponsiveMapping(this.getState());
    }
    /**
     * @param {?} val
     * @return {?}
     */
    set viewWidth(val) {
        if (val > 0) {
            this.viewport[0] = val;
        }
    }
    /**
     * @param {?} val
     * @return {?}
     */
    set viewHeight(val) {
        if (val > 0) {
            this.viewport[1] = val;
        }
    }
    /**
     * @param {?} size
     * @return {?}
     */
    addSize(size) {
        this.adSizes.push(size);
    }
    /**
     * @return {?}
     */
    getState() {
        return Object.freeze({
            viewportSize: this.viewport,
            adSizes: this.adSizes
        });
    }
}
DfpResponsiveDirective.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"], args: [{
                selector: 'dfp-responsive'
            },] }
];
/** @nocollapse */
DfpResponsiveDirective.ctorParameters = () => [
    { type: DfpAdDirective, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(() => DfpAdDirective),] }] }
];
DfpResponsiveDirective.propDecorators = {
    viewport: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    adSizes: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    viewWidth: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    viewHeight: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpSizeDirective {
    /**
     * @param {?} elementRef
     * @param {?} ad
     * @param {?} resp
     */
    constructor(elementRef, ad, resp) {
        this.elementRef = elementRef;
        this.ad = ad;
        this.resp = resp;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        /** @type {?} */
        const target = this.resp || this.ad;
        /** @type {?} */
        const innerText = this.elementRef.nativeElement.innerText;
        if (this.width && this.height) {
            target.addSize([this.width, this.height]);
        }
        else if (innerText.trim() !== '') {
            target.addSize(innerText);
        }
    }
}
DfpSizeDirective.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"], args: [{
                selector: 'dfp-size'
            },] }
];
/** @nocollapse */
DfpSizeDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: DfpAdDirective, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(() => DfpAdDirective),] }] },
    { type: DfpResponsiveDirective, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(() => DfpResponsiveDirective),] }] }
];
DfpSizeDirective.propDecorators = {
    width: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    height: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpTargetingDirective {
    /**
     * @param {?} ad
     */
    constructor(ad) {
        this.ad = ad;
        this.values = [];
    }
    /**
     * @param {?} val
     * @return {?}
     */
    set value(val) {
        if (val instanceof Array) {
            val.forEach(v => this.addValue(v));
        }
        else {
            this.addValue(val);
        }
    }
    /**
     * @return {?}
     */
    ngAfterContentInit() {
        /** @type {?} */
        const targeting = this.getState();
        this.ad.addTargeting(targeting);
    }
    /**
     * @return {?}
     */
    checkValid() {
        if (this.key === undefined) {
            throw new DFPIncompleteError('dfp-targeting', 'key', true);
        }
        if (this.values.length === 0) {
            throw new DFPIncompleteError('dfp-targeting', 'value', true);
        }
    }
    /**
     * @return {?}
     */
    getState() {
        this.checkValid();
        return Object.freeze({
            key: this.key,
            values: this.values
        });
    }
    /**
     * @param {?} value
     * @return {?}
     */
    addValue(value) {
        if (value && !this.values.find(item => item === value)) {
            this.values.push(value);
        }
    }
}
DfpTargetingDirective.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"], args: [{
                selector: 'dfp-targeting'
            },] }
];
/** @nocollapse */
DfpTargetingDirective.ctorParameters = () => [
    { type: DfpAdDirective, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(() => DfpAdDirective),] }] }
];
DfpTargetingDirective.propDecorators = {
    key: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    value: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpExclusionDirective {
    /**
     * @param {?} elementRef
     * @param {?} ad
     */
    constructor(elementRef, ad) {
        this.elementRef = elementRef;
        this.ad = ad;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.ad.addExclusion(this.elementRef.nativeElement.innerText);
    }
}
DfpExclusionDirective.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"], args: [{
                selector: 'dfp-exclusion'
            },] }
];
/** @nocollapse */
DfpExclusionDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: DfpAdDirective, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(() => DfpAdDirective),] }] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpValueDirective {
    /**
     * @param {?} elementRef
     * @param {?} targeting
     */
    constructor(elementRef, targeting) {
        this.elementRef = elementRef;
        this.targeting = targeting;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.targeting.addValue(this.elementRef.nativeElement.innerText);
    }
}
DfpValueDirective.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"], args: [{
                selector: 'dfp-value'
            },] }
];
/** @nocollapse */
DfpValueDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: DfpTargetingDirective, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(() => DfpTargetingDirective),] }] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class DfpAudiencePixelDirective {
    /**
     * @param {?} platformId
     * @param {?} elementRef
     */
    constructor(platformId, elementRef) {
        this.platformId = platformId;
        this.elementRef = elementRef;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(this.platformId)) {
            /** @type {?} */
            const axel = Math.random();
            /** @type {?} */
            const random = axel * 10000000000000;
            /** @type {?} */
            let adUnit = '';
            if (this.adUnit) {
                adUnit = `dc_iu=${this.adUnit}`;
            }
            /** @type {?} */
            let ppid = '';
            if (this.ppid) {
                ppid = `ppid=${this.ppid}`;
            }
            /** @type {?} */
            const pixel = document.createElement('img');
            pixel.src = 'https://pubads.g.doubleclick.net/activity;ord=';
            pixel.src += `${random};dc_seg=${this.segmentId};${adUnit}${ppid}`;
            pixel.width = 1;
            pixel.height = 1;
            pixel.border = '0';
            pixel.style.visibility = 'hidden';
            this.elementRef.nativeElement.append(pixel);
        }
    }
}
DfpAudiencePixelDirective.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"], args: [{
                selector: 'dfp-audience-pixel'
            },] }
];
/** @nocollapse */
DfpAudiencePixelDirective.ctorParameters = () => [
    { type: Object, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"],] }] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }
];
DfpAudiencePixelDirective.propDecorators = {
    adUnit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    segmentId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    ppid: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @type {?} */
const DIRECTIVES = [
    DfpAdDirective,
    DfpSizeDirective,
    DfpResponsiveDirective,
    DfpAdResponsiveDirective,
    DfpTargetingDirective, DfpExclusionDirective, DfpValueDirective,
    DfpAudiencePixelDirective
];
/** @type {?} */
const SERVICES = [
    HttpErrorService,
    ParseDurationService,
    ScriptInjectorService,
    DfpService, DfpIDGeneratorService, DfpRefreshService
];
class DfpModule {
    /**
     * @param {?=} config
     * @return {?}
     */
    static forRoot(config) {
        return {
            ngModule: DfpModule,
            providers: [
                ...(config && config.idleLoad === true ? [IdleService] : []),
                { provide: DFP_CONFIG, useValue: config || {} }
            ]
        };
    }
}
DfpModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"], args: [{
                imports: [],
                declarations: [
                    ...DIRECTIVES
                ],
                providers: [
                    ...SERVICES
                ],
                exports: [
                    ...DIRECTIVES
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */



//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmd4LWRmcC5qcy5tYXAiLCJzb3VyY2VzIjpbIm5nOi8vbmd4LWRmcC9zZXJ2aWNlL2luamVjdGlvbl90b2tlbi50cyIsIm5nOi8vbmd4LWRmcC9zZXJ2aWNlL2lkbGUuc2VydmljZS50cyIsIm5nOi8vbmd4LWRmcC9zZXJ2aWNlL2h0dHAtZXJyb3Iuc2VydmljZS50cyIsIm5nOi8vbmd4LWRmcC9zZXJ2aWNlL3BhcnNlLWR1cmF0aW9uLnNlcnZpY2UudHMiLCJuZzovL25neC1kZnAvc2VydmljZS9zY3JpcHQtaW5qZWN0b3Iuc2VydmljZS50cyIsIm5nOi8vbmd4LWRmcC9jbGFzcy9kZnAtZXJyb3JzLmNsYXNzLnRzIiwibmc6Ly9uZ3gtZGZwL2NsYXNzL2RmcC1jb25maWcuY2xhc3MudHMiLCJuZzovL25neC1kZnAvc2VydmljZS9kZnAuc2VydmljZS50cyIsIm5nOi8vbmd4LWRmcC9zZXJ2aWNlL2RmcC1pZC1nZW5lcmF0b3Iuc2VydmljZS50cyIsIm5nOi8vbmd4LWRmcC9zZXJ2aWNlL2RmcC1yZWZyZXNoLnNlcnZpY2UudHMiLCJuZzovL25neC1kZnAvZGlyZWN0aXZlL2RmcC1hZC5kaXJlY3RpdmUudHMiLCJuZzovL25neC1kZnAvZGlyZWN0aXZlL2RmcC1hZC1yZXNwb25zaXZlLmRpcmVjdGl2ZS50cyIsIm5nOi8vbmd4LWRmcC9kaXJlY3RpdmUvZGZwLXJlc3BvbnNpdmUuZGlyZWN0aXZlLnRzIiwibmc6Ly9uZ3gtZGZwL2RpcmVjdGl2ZS9kZnAtc2l6ZS5kaXJlY3RpdmUudHMiLCJuZzovL25neC1kZnAvZGlyZWN0aXZlL2RmcC10YXJnZXRpbmcuZGlyZWN0aXZlLnRzIiwibmc6Ly9uZ3gtZGZwL2RpcmVjdGl2ZS9kZnAtZXhjbHVzaW9uLmRpcmVjdGl2ZS50cyIsIm5nOi8vbmd4LWRmcC9kaXJlY3RpdmUvZGZwLXZhbHVlLmRpcmVjdGl2ZS50cyIsIm5nOi8vbmd4LWRmcC9kaXJlY3RpdmUvZGZwLWF1ZGllbmNlLXBpeGVsLmRpcmVjdGl2ZS50cyIsIm5nOi8vbmd4LWRmcC9kZnAubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGlvblRva2VuIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IERmcENvbmZpZyAgfSBmcm9tICcuLi9jbGFzcyc7XG5cbmV4cG9ydCBjb25zdCBERlBfQ09ORklHID0gbmV3IEluamVjdGlvblRva2VuPERmcENvbmZpZz4oJ2RmcENvbmZpZycpO1xuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgTmdab25lLCBJbmplY3QsIFBMQVRGT1JNX0lEIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBpc1BsYXRmb3JtQnJvd3NlciB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBJZGxlU2VydmljZSB7XG5cbiAgcHJpdmF0ZSByZXF1ZXN0SWRsZUNhbGxiYWNrOiBhbnk7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgQEluamVjdChQTEFURk9STV9JRCkgcGxhdGZvcm1JZDogT2JqZWN0LFxuICAgIHpvbmU6IE5nWm9uZVxuICApIHtcbiAgICBjb25zdCB3aW46IGFueSA9IGlzUGxhdGZvcm1Ccm93c2VyKHBsYXRmb3JtSWQpID8gd2luZG93IDoge307XG4gICAgaWYgKHdpbi5yZXF1ZXN0SWRsZUNhbGxiYWNrKSB7XG4gICAgICB0aGlzLnJlcXVlc3RJZGxlQ2FsbGJhY2sgPSAoZnVuKSA9PiB7XG4gICAgICAgIHJldHVybiB3aW4ucmVxdWVzdElkbGVDYWxsYmFjayhmdW4pO1xuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5yZXF1ZXN0SWRsZUNhbGxiYWNrID0gKGZ1bikgPT4ge1xuICAgICAgICByZXR1cm4gem9uZS5ydW5PdXRzaWRlQW5ndWxhcigoKSA9PiB3aW4uc2V0VGltZW91dChmdW4sIDUwKSk7XG4gICAgICB9O1xuICAgIH1cbiAgfVxuXG4gIHJlcXVlc3QoZnVuKSB7XG4gICAgdGhpcy5yZXF1ZXN0SWRsZUNhbGxiYWNrKGZ1bik7XG4gIH1cblxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgSHR0cEVycm9yU2VydmljZSB7XG5cbiAgaHR0cEVycm9yKHJlc3BvbnNlLCBtZXNzYWdlKSB7XG4gICAgY29uc29sZS5sb2coYEVycm9yICgke3Jlc3BvbnNlLnN0YXR1c30pICR7bWVzc2FnZSA/IG1lc3NhZ2UgOiAnJ31gKTtcbiAgfVxuXG4gIGlzRXJyb3JDb2RlID0gZnVuY3Rpb24gKGNvZGUpIHtcbiAgICBpZiAodHlwZW9mIGNvZGUgPT09ICdudW1iZXInKSB7XG4gICAgICByZXR1cm4gIShjb2RlID49IDIwMCAmJiBjb2RlIDwgMzAwKTtcbiAgICB9XG4gICAgcmV0dXJuIGNvZGVbMF0gIT09ICcyJztcbiAgfTtcblxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5jbGFzcyBERlBEdXJhdGlvbkVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihpbnRlcnZhbCkge1xuICAgIHN1cGVyKGBJbnZhbGlkIGludGVydmFsOiAnJHtpbnRlcnZhbH0nbHNgKTtcbiAgfVxufVxuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgUGFyc2VEdXJhdGlvblNlcnZpY2Uge1xuXG4gIGNvbnZlcnRUb01pbGxpc2Vjb25kcyh0aW1lLCB1bml0KSB7XG4gICAgY29uc29sZS5hc3NlcnQoL14obT9zfG1pbnxoKSQvZy50ZXN0KHVuaXQpKTtcblxuICAgIGlmICh1bml0ID09PSAnbXMnKSB7IHJldHVybiB0aW1lOyB9XG4gICAgaWYgKHVuaXQgPT09ICdzJykgeyByZXR1cm4gdGltZSAqIDEwMDA7IH1cbiAgICBpZiAodW5pdCA9PT0gJ21pbicpIHsgcmV0dXJuIHRpbWUgKiA2MCAqIDEwMDA7IH1cblxuICAgIHJldHVybiB0aW1lICogNjAgKiA2MCAqIDEwMDA7XG4gIH1cblxuICBjb252ZXJ0KG1hdGNoKSB7XG4gICAgY29uc3QgdGltZSA9IHBhcnNlRmxvYXQobWF0Y2hbMV0pO1xuXG4gICAgaWYgKG1hdGNoLmxlbmd0aCA9PT0gMikgeyByZXR1cm4gdGltZTsgfVxuXG4gICAgcmV0dXJuIHRoaXMuY29udmVydFRvTWlsbGlzZWNvbmRzKHRpbWUsIG1hdGNoWzJdKTtcbiAgfVxuXG4gIHBhcnNlRHVyYXRpb24oaW50ZXJ2YWwpIHtcblxuICAgIGlmIChpbnRlcnZhbCA9PT0gdW5kZWZpbmVkIHx8IGludGVydmFsID09PSBudWxsKSB7XG4gICAgICB0aHJvdyBuZXcgREZQRHVyYXRpb25FcnJvcihpbnRlcnZhbCk7XG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBpbnRlcnZhbCA9PT0gJ251bWJlcicpIHtcbiAgICAgIHJldHVybiBpbnRlcnZhbDtcbiAgICB9XG5cbiAgICBpZiAodHlwZW9mIGludGVydmFsICE9PSAnc3RyaW5nJykge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgJyR7aW50ZXJ2YWx9JyBtdXN0IGJlIG9mIG51bWJlciBvciBzdHJpbmcgdHlwZWApO1xuICAgIH1cblxuICAgIGNvbnN0IG1hdGNoID0gaW50ZXJ2YWwubWF0Y2goLygoPzpcXGQrKT8uP1xcZCspKG0/c3xtaW58aCk/Lyk7XG5cbiAgICBpZiAoIW1hdGNoKSB7XG4gICAgICB0aHJvdyBuZXcgREZQRHVyYXRpb25FcnJvcihpbnRlcnZhbCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuY29udmVydChtYXRjaCk7XG4gIH1cblxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBIdHRwRXJyb3JTZXJ2aWNlIH0gZnJvbSAnLi9odHRwLWVycm9yLnNlcnZpY2UnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgU2NyaXB0SW5qZWN0b3JTZXJ2aWNlIHtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHBFcnJvcjogSHR0cEVycm9yU2VydmljZSkgeyB9XG5cbiAgcHJpdmF0ZSBjb21wbGV0ZVVSTCh1cmwpIHtcbiAgICBjb25zdCBzc2wgPSBkb2N1bWVudC5sb2NhdGlvbi5wcm90b2NvbCA9PT0gJ2h0dHBzOic7XG4gICAgcmV0dXJuIChzc2wgPyAnaHR0cHM6JyA6ICdodHRwOicpICsgdXJsO1xuICB9XG5cbiAgcHJpdmF0ZSBjcmVhdGVTY3JpcHQodXJsKSB7XG4gICAgY29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG5cbiAgICBzY3JpcHQuYXN5bmMgPSB0cnVlO1xuICAgIHNjcmlwdC50eXBlID0gJ3RleHQvamF2YXNjcmlwdCc7XG4gICAgc2NyaXB0LnNyYyA9IHRoaXMuY29tcGxldGVVUkwodXJsKTtcblxuICAgIHJldHVybiBzY3JpcHQ7XG4gIH1cblxuICBwcml2YXRlIHByb21pc2VTY3JpcHQoc2NyaXB0LCB1cmwpIHtcbiAgICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgc2NyaXB0Lm9ubG9hZCA9ICgpID0+IHtcbiAgICAgICAgcmVzb2x2ZShzY3JpcHQpO1xuICAgICAgfTtcbiAgICAgIHNjcmlwdC5vbmVycm9yID0gKCkgPT4ge1xuICAgICAgICByZWplY3Qoe1xuICAgICAgICAgIHBhdGg6IHVybCxcbiAgICAgICAgICBsb2FkZWQ6IGZhbHNlXG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICB9KTtcblxuICAgIHByb21pc2UuY2F0Y2gocmVzcG9uc2UgPT4ge1xuICAgICAgdGhpcy5odHRwRXJyb3IuaHR0cEVycm9yKHsgc3RhdHVzOiA0MDAgfSwgYGxvYWRpbmcgc2NyaXB0IFwiJHt1cmx9XCJgKTtcbiAgICB9KTtcblxuICAgIHJldHVybiBwcm9taXNlO1xuICB9XG5cbiAgaW5qZWN0U2NyaXB0KHNjcmlwdCkge1xuICAgIGNvbnN0IGhlYWQgPSBkb2N1bWVudC5oZWFkIHx8IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2hlYWQnKTtcbiAgICBoZWFkLmFwcGVuZENoaWxkKHNjcmlwdCk7XG4gIH1cblxuICBzY3JpcHRJbmplY3Rvcih1cmwpIHtcbiAgICBjb25zdCBzY3JpcHQgPSB0aGlzLmNyZWF0ZVNjcmlwdCh1cmwpO1xuICAgIHRoaXMuaW5qZWN0U2NyaXB0KHNjcmlwdCk7XG4gICAgcmV0dXJuIHRoaXMucHJvbWlzZVNjcmlwdChzY3JpcHQsIHVybCk7XG4gIH1cblxufVxuIiwiXG5cbmV4cG9ydCBjbGFzcyBERlBJbmNvbXBsZXRlRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gICAgY29uc3RydWN0b3IoZGlyZWN0aXZlTmFtZSwgbWlzc2luZ05hbWUsIGlzQXR0cmlidXRlPykge1xuICAgICAgICBzdXBlcihgSW5jb21wbGV0ZSBkZWZpbml0aW9uIG9mICcke2RpcmVjdGl2ZU5hbWV9JzogYCArXG4gICAgICAgICAgICBgTWlzc2luZyAke2lzQXR0cmlidXRlID8gJ2F0dHJpYnV0ZScgOiAnY2hpbGQgZGlyZWN0aXZlJ30gYCArXG4gICAgICAgICAgICBgJyR7bWlzc2luZ05hbWV9Jy5gKTtcbiAgICB9XG59XG5cbmV4cG9ydCBjbGFzcyBERlBUeXBlRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gICAgY29uc3RydWN0b3IoZGlyZWN0aXZlTmFtZSwgYXR0cmlidXRlTmFtZSwgd3JvbmdWYWx1ZSwgZXhwZWN0ZWRUeXBlKSB7XG4gICAgICAgIHN1cGVyKFxuICAgICAgICAgICAgYFdyb25nIHR5cGUgZm9yIGF0dHJpYnV0ZSAnJHthdHRyaWJ1dGVOYW1lfScgb24gYCArXG4gICAgICAgICAgICBgZGlyZWN0aXZlICcke2RpcmVjdGl2ZU5hbWV9JzogRXhwZWN0ZWQgJHtleHBlY3RlZFR5cGV9YCArXG4gICAgICAgICAgICBgLCBnb3QgJHt0eXBlb2Ygd3JvbmdWYWx1ZX1gXG4gICAgICAgICk7XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgREZQTWlzc2luZ1BhcmVudEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKGRpcmVjdGl2ZU5hbWUsIC4uLnBhcmVudHMpIHtcbiAgICAgICAgY29uc29sZS5hc3NlcnQocGFyZW50cyAmJiBwYXJlbnRzLmxlbmd0aCA+IDApO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShwYXJlbnRzWzBdKSkge1xuICAgICAgICAgICAgcGFyZW50cyA9IHBhcmVudHNbMF07XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgcGFyZW50TWVzc2FnZTtcbiAgICAgICAgaWYgKHBhcmVudHMubGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgcGFyZW50cyA9IHBhcmVudHMubWFwKHAgPT4gYCcke3B9J2ApO1xuICAgICAgICAgICAgcGFyZW50TWVzc2FnZSA9ICcsIHdoaWNoIG11c3QgYmUgJztcbiAgICAgICAgICAgIHBhcmVudE1lc3NhZ2UgKz0gcGFyZW50cy5zbGljZSgwLCAtMSkuam9pbignLCAnKTtcbiAgICAgICAgICAgIHBhcmVudE1lc3NhZ2UgKz0gYCBvciAke3BhcmVudHNbcGFyZW50cy5sZW5ndGggLSAxXX1gO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcGFyZW50TWVzc2FnZSA9IGAgJyR7cGFyZW50c1swXX0nYDtcbiAgICAgICAgfVxuXG4gICAgICAgIHN1cGVyKFxuICAgICAgICAgICAgYEludmFsaWQgdXNlIG9mICcke2RpcmVjdGl2ZU5hbWV9JyBkaXJlY3RpdmUuIGAgK1xuICAgICAgICAgICAgYE1pc3NpbmcgcGFyZW50IGRpcmVjdGl2ZSR7cGFyZW50TWVzc2FnZX0uYFxuICAgICAgICApO1xuICAgIH1cbn1cbiIsImV4cG9ydCBjbGFzcyBEZnBUYXJnZXRpbmcge1xuICBba2V5OiBzdHJpbmddOiBBcnJheTxzdHJpbmc+O1xufVxuXG5leHBvcnQgY2xhc3MgRGZwQ29uZmlnIHtcbiAgaWRsZUxvYWQ/OiBib29sZWFuO1xuICBvblNhbWVOYXZpZ2F0aW9uPzogJ3JlZnJlc2gnIHwgJ2lnbm9yZSc7XG4gIHNpbmdsZVJlcXVlc3RNb2RlPzogYm9vbGVhbjtcbiAgZW5hYmxlVmlkZW9BZHM/OiBib29sZWFuO1xuICBwZXJzb25hbGl6ZWRBZHM/OiBib29sZWFuO1xuICBjb2xsYXBzZUlmRW1wdHk/OiBib29sZWFuO1xuICBjZW50ZXJpbmc/OiBib29sZWFuO1xuICBsb2NhdGlvbj86IHN0cmluZyB8IEFycmF5PHN0cmluZz47XG4gIHBwaWQ/OiBzdHJpbmc7XG4gIGdsb2JhbFRhcmdldGluZz86IERmcFRhcmdldGluZztcbiAgZm9yY2VTYWZlRnJhbWU/OiBib29sZWFuO1xuICBzYWZlRnJhbWVDb25maWc/OiBvYmplY3Q7XG4gIGxvYWRHUFQ/OiBib29sZWFuO1xufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgT3B0aW9uYWwsIFBMQVRGT1JNX0lELCBJbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGlzUGxhdGZvcm1Ccm93c2VyIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuaW1wb3J0IHsgREZQX0NPTkZJRyB9IGZyb20gJy4vaW5qZWN0aW9uX3Rva2VuJztcbmltcG9ydCB7IERmcENvbmZpZyB9IGZyb20gJy4uL2NsYXNzJztcbmltcG9ydCB7IElkbGVTZXJ2aWNlIH0gZnJvbSAnLi9pZGxlLnNlcnZpY2UnO1xuaW1wb3J0IHsgU2NyaXB0SW5qZWN0b3JTZXJ2aWNlIH0gZnJvbSAnLi9zY3JpcHQtaW5qZWN0b3Iuc2VydmljZSc7XG5cbmV4cG9ydCBjb25zdCBHUFRfTElCUkFSWV9VUkwgPSAnLy93d3cuZ29vZ2xldGFnc2VydmljZXMuY29tL3RhZy9qcy9ncHQuanMnO1xuXG5jbGFzcyBERlBDb25maWd1cmF0aW9uRXJyb3IgZXh0ZW5kcyBFcnJvciB7IH1cblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIERmcFNlcnZpY2Uge1xuXG4gIHByaXZhdGUgZW5hYmxlVmlkZW9BZHMgPSBmYWxzZTtcblxuICBwcml2YXRlIHBlcnNvbmFsaXplZEFkcyA9IHRydWU7XG5cbiAgcHJpdmF0ZSBjb2xsYXBzZUlmRW1wdHkgPSB0cnVlO1xuXG4gIHByaXZhdGUgY2VudGVyaW5nID0gZmFsc2U7XG5cbiAgcHJpdmF0ZSBsb2NhdGlvbiA9IG51bGw7XG5cbiAgcHJpdmF0ZSBwcGlkID0gbnVsbDtcblxuICBwcml2YXRlIGdsb2JhbFRhcmdldGluZyA9IG51bGw7XG5cbiAgcHJpdmF0ZSBmb3JjZVNhZmVGcmFtZSA9IGZhbHNlO1xuXG4gIHByaXZhdGUgc2FmZUZyYW1lQ29uZmlnID0gbnVsbDtcblxuICBwcml2YXRlIGxvYWRHUFQgPSB0cnVlO1xuXG4gIHByaXZhdGUgbG9hZGVkID0gZmFsc2U7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgQEluamVjdChQTEFURk9STV9JRCkgcHJpdmF0ZSBwbGF0Zm9ybUlkOiBPYmplY3QsXG4gICAgQE9wdGlvbmFsKCkgaWRsZUxvYWQ6IElkbGVTZXJ2aWNlLFxuICAgIEBJbmplY3QoREZQX0NPTkZJRykgcHJpdmF0ZSBjb25maWc6IERmcENvbmZpZyxcbiAgICBwcml2YXRlIHNjcmlwdEluamVjdG9yOiBTY3JpcHRJbmplY3RvclNlcnZpY2VcbiAgKSB7XG4gICAgaWYgKGlzUGxhdGZvcm1Ccm93c2VyKHRoaXMucGxhdGZvcm1JZCkpIHtcbiAgICAgIGNvbnN0IHdpbjogYW55ID0gd2luZG93LFxuICAgICAgICBnb29nbGV0YWcgPSB3aW4uZ29vZ2xldGFnIHx8IHt9O1xuXG4gICAgICB0aGlzLmRmcENvbmZpZygpO1xuXG4gICAgICBnb29nbGV0YWcuY21kID0gZ29vZ2xldGFnLmNtZCB8fCBbXTtcbiAgICAgIGdvb2dsZXRhZy5jbWQucHVzaCgoKSA9PiB7XG4gICAgICAgIHRoaXMuc2V0dXAoKTtcbiAgICAgIH0pO1xuICAgICAgd2luLmdvb2dsZXRhZyA9IGdvb2dsZXRhZztcblxuICAgICAgaWYgKHRoaXMubG9hZEdQVCkge1xuICAgICAgICBjb25zdCBsb2FkU2NyaXB0ID0gKCkgPT4ge1xuICAgICAgICAgIHRoaXMuc2NyaXB0SW5qZWN0b3Iuc2NyaXB0SW5qZWN0b3IoR1BUX0xJQlJBUllfVVJMKS50aGVuKChzY3JpcHQpID0+IHtcbiAgICAgICAgICAgIHRoaXMubG9hZGVkID0gdHJ1ZTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKGlkbGVMb2FkKSB7XG4gICAgICAgICAgaWRsZUxvYWQucmVxdWVzdChsb2FkU2NyaXB0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsb2FkU2NyaXB0KCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGRmcENvbmZpZygpIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiB0aGlzLmNvbmZpZykge1xuICAgICAgaWYgKHRoaXMuaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICB0aGlzW2tleV0gPSB0aGlzLmNvbmZpZ1trZXldO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYWRkU2FmZUZyYW1lQ29uZmlnKHB1YmFkcykge1xuICAgIGlmICghdGhpcy5zYWZlRnJhbWVDb25maWcpIHsgcmV0dXJuIGZhbHNlOyB9XG4gICAgaWYgKHR5cGVvZiB0aGlzLnNhZmVGcmFtZUNvbmZpZyAhPT0gJ29iamVjdCcpIHtcbiAgICAgIHRocm93IG5ldyBERlBDb25maWd1cmF0aW9uRXJyb3IoJ0ZyYW1lQ29uZmlnIG11c3QgYmUgYW4gb2JqZWN0Jyk7XG4gICAgfVxuICAgIHB1YmFkcy5zZXRTYWZlRnJhbWVDb25maWcodGhpcy5zYWZlRnJhbWVDb25maWcpO1xuICB9XG5cbiAgcHJpdmF0ZSBhZGRUYXJnZXRpbmcocHViYWRzKSB7XG4gICAgaWYgKCF0aGlzLmdsb2JhbFRhcmdldGluZykgeyByZXR1cm4gZmFsc2U7IH1cbiAgICBpZiAodHlwZW9mIHRoaXMuZ2xvYmFsVGFyZ2V0aW5nICE9PSAnb2JqZWN0Jykge1xuICAgICAgdGhyb3cgbmV3IERGUENvbmZpZ3VyYXRpb25FcnJvcignVGFyZ2V0aW5nIG11c3QgYmUgYW4gb2JqZWN0Jyk7XG4gICAgfVxuXG4gICAgZm9yIChjb25zdCBrZXkgaW4gdGhpcy5nbG9iYWxUYXJnZXRpbmcpIHtcbiAgICAgIGlmICh0aGlzLmdsb2JhbFRhcmdldGluZy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICAgIHB1YmFkcy5zZXRUYXJnZXRpbmcoa2V5LCB0aGlzLmdsb2JhbFRhcmdldGluZ1trZXldKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFkZExvY2F0aW9uKHB1YmFkcykge1xuICAgIGlmICghdGhpcy5sb2NhdGlvbikgeyByZXR1cm4gZmFsc2U7IH1cblxuICAgIGlmICh0eXBlb2YgdGhpcy5sb2NhdGlvbiA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHB1YmFkcy5zZXRMb2NhdGlvbih0aGlzLmxvY2F0aW9uKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkodGhpcy5sb2NhdGlvbikpIHtcbiAgICAgIHRocm93IG5ldyBERlBDb25maWd1cmF0aW9uRXJyb3IoJ0xvY2F0aW9uIG11c3QgYmUgYW4gJyArXG4gICAgICAgICdhcnJheSBvciBzdHJpbmcnKTtcbiAgICB9XG5cbiAgICBwdWJhZHMuc2V0TG9jYXRpb24uYXBwbHkocHViYWRzLCB0aGlzLmxvY2F0aW9uKTtcbiAgfVxuXG4gIHByaXZhdGUgYWRkUFBJRChwdWJhZHMpIHtcbiAgICBpZiAoIXRoaXMucHBpZCkgeyByZXR1cm4gZmFsc2U7IH1cbiAgICBpZiAodHlwZW9mIHRoaXMucHBpZCAhPT0gJ3N0cmluZycpIHtcbiAgICAgIHRocm93IG5ldyBERlBDb25maWd1cmF0aW9uRXJyb3IoJ1BQSUQgbXVzdCBiZSBhIHN0cmluZycpO1xuICAgIH1cblxuICAgIHB1YmFkcy5zZXRQdWJsaXNoZXJQcm92aWRlZElkKHRoaXMucHBpZCk7XG4gIH1cblxuICBwcml2YXRlIHNldHVwKCkge1xuICAgIGNvbnN0IHdpbjogYW55ID0gd2luZG93LFxuICAgICAgZ29vZ2xldGFnID0gd2luLmdvb2dsZXRhZyxcbiAgICAgIHB1YmFkcyA9IGdvb2dsZXRhZy5wdWJhZHMoKTtcblxuICAgIGlmICh0aGlzLmVuYWJsZVZpZGVvQWRzKSB7XG4gICAgICBwdWJhZHMuZW5hYmxlVmlkZW9BZHMoKTtcbiAgICB9XG5cbiAgICAvLyBwZXJzb25hbGl6ZWRBZHMgaXMgZGVmYXVsdFxuICAgIGlmICh0aGlzLnBlcnNvbmFsaXplZEFkcyA9PT0gZmFsc2UpIHtcbiAgICAgIHB1YmFkcy5zZXRSZXF1ZXN0Tm9uUGVyc29uYWxpemVkQWRzKDEpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLmNvbGxhcHNlSWZFbXB0eSkge1xuICAgICAgcHViYWRzLmNvbGxhcHNlRW1wdHlEaXZzKCk7XG4gICAgfVxuXG4gICAgLy8gV2UgYWx3YXlzIHJlZnJlc2ggb3Vyc2VsdmVzXG4gICAgcHViYWRzLmRpc2FibGVJbml0aWFsTG9hZCgpO1xuXG4gICAgcHViYWRzLnNldEZvcmNlU2FmZUZyYW1lKHRoaXMuZm9yY2VTYWZlRnJhbWUpO1xuICAgIHB1YmFkcy5zZXRDZW50ZXJpbmcodGhpcy5jZW50ZXJpbmcpO1xuXG4gICAgdGhpcy5hZGRMb2NhdGlvbihwdWJhZHMpO1xuICAgIHRoaXMuYWRkUFBJRChwdWJhZHMpO1xuICAgIHRoaXMuYWRkVGFyZ2V0aW5nKHB1YmFkcyk7XG4gICAgdGhpcy5hZGRTYWZlRnJhbWVDb25maWcocHViYWRzKTtcblxuICAgIC8vIHB1YmFkcy5lbmFibGVTeW5jUmVuZGVyaW5nKCk7XG4gICAgcHViYWRzLmVuYWJsZUFzeW5jUmVuZGVyaW5nKCk7XG5cbiAgICBpZiAodGhpcy5jb25maWcuc2luZ2xlUmVxdWVzdE1vZGUgIT09IHRydWUpIHtcbiAgICAgIGlmICh0aGlzLmNvbmZpZy5lbmFibGVWaWRlb0Fkcykge1xuICAgICAgICBwdWJhZHMuZW5hYmxlVmlkZW9BZHMoKTtcbiAgICAgIH1cbiAgICAgIGdvb2dsZXRhZy5lbmFibGVTZXJ2aWNlcygpO1xuICAgIH1cblxuICB9XG5cbiAgaGFzTG9hZGVkKCkge1xuICAgIHJldHVybiB0aGlzLmxvYWRlZDtcbiAgfVxuXG4gIGRlZmluZVRhc2sodGFzaykge1xuICAgIGlmIChpc1BsYXRmb3JtQnJvd3Nlcih0aGlzLnBsYXRmb3JtSWQpKSB7XG4gICAgICBjb25zdCB3aW46IGFueSA9IHdpbmRvdyxcbiAgICAgICAgZ29vZ2xldGFnID0gd2luLmdvb2dsZXRhZztcbiAgICAgIGdvb2dsZXRhZy5jbWQucHVzaCh0YXNrKTtcbiAgICB9XG4gIH1cblxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgRGZwSURHZW5lcmF0b3JTZXJ2aWNlIHtcblxuICBwcml2YXRlIGdlbmVyYXRlZElEcyA9IHt9O1xuXG4gIGdlbmVyYXRlSUQodHlwZSA9ICdkZnAtYWQnKSB7XG4gICAgbGV0IGlkID0gbnVsbDtcblxuICAgIGRvIHtcbiAgICAgIGNvbnN0IG51bWJlciA9IE1hdGgucmFuZG9tKCkudG9TdHJpbmcoKS5zbGljZSgyKTtcbiAgICAgIGlkID0gdHlwZSArICctJyArIG51bWJlcjtcbiAgICB9IHdoaWxlIChpZCBpbiB0aGlzLmdlbmVyYXRlZElEcyk7XG5cbiAgICB0aGlzLmdlbmVyYXRlZElEc1tpZF0gPSB0cnVlO1xuXG4gICAgcmV0dXJuIGlkO1xuICB9XG5cbiAgZGZwSURHZW5lcmF0b3IoZWxlbWVudDogSFRNTEVsZW1lbnQpIHtcbiAgICBpZiAoZWxlbWVudCAmJiBlbGVtZW50LmlkICYmICEoZWxlbWVudC5pZCBpbiB0aGlzLmdlbmVyYXRlZElEcykpIHtcbiAgICAgIHJldHVybiBlbGVtZW50LmlkO1xuICAgIH1cblxuICAgIGNvbnN0IGlkID0gdGhpcy5nZW5lcmF0ZUlEKGVsZW1lbnQudGFnTmFtZS50b0xvd2VyQ2FzZSgpKTtcbiAgICBpZiAoZWxlbWVudCkgeyBlbGVtZW50LmlkID0gaWQ7IH1cblxuICAgIHJldHVybiBpZDtcbiAgfVxuXG4gIGlzVGFrZW4oaWQpIHtcbiAgICByZXR1cm4gaWQgaW4gdGhpcy5nZW5lcmF0ZWRJRHM7XG4gIH1cblxuICBpc1VuaXF1ZShpZCkge1xuICAgIHJldHVybiAhdGhpcy5pc1Rha2VuKGlkKTtcbiAgfVxuXG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBFdmVudEVtaXR0ZXIsIE9wdGlvbmFsLCBJbmplY3RvciwgSW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBET0NVTUVOVCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5cbmltcG9ydCB7IFN1YnNjcmlwdGlvbiwgdGltZXIsIGZyb20gfSBmcm9tICdyeGpzJztcblxuaW1wb3J0IHsgRGZwQ29uZmlnIH0gZnJvbSAnLi4vY2xhc3MnO1xuaW1wb3J0IHsgREZQX0NPTkZJRyB9IGZyb20gJy4vaW5qZWN0aW9uX3Rva2VuJztcbmltcG9ydCB7IFBhcnNlRHVyYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9wYXJzZS1kdXJhdGlvbi5zZXJ2aWNlJztcblxuY2xhc3MgREZQUmVmcmVzaEVycm9yIGV4dGVuZHMgRXJyb3IgeyB9XG5cbmRlY2xhcmUgdmFyIGdvb2dsZXRhZztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIERmcFJlZnJlc2hTZXJ2aWNlIHtcblxuICByZWZyZXNoRXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICBwcml2YXRlIHJlZnJlc2hTbG90cyA9IFtdO1xuICBwcml2YXRlIHNpbmdsZVJlcXVlc3Q6IFN1YnNjcmlwdGlvbjtcbiAgcHJpdmF0ZSBpbnRlcnZhbHMgPSB7fTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBAT3B0aW9uYWwoKSBASW5qZWN0KERGUF9DT05GSUcpXG4gICAgcHJpdmF0ZSBjb25maWc6IERmcENvbmZpZyxcbiAgICBwcml2YXRlIGluamVjdDogSW5qZWN0b3IsXG4gICAgcHJpdmF0ZSBwYXJzZUR1cmF0aW9uOiBQYXJzZUR1cmF0aW9uU2VydmljZVxuICApIHsgfVxuXG4gIHNsb3RSZWZyZXNoKHNsb3QsIHJlZnJlc2hJbnRlcnZhbD8sIGluaXRSZWZyZXNoID0gZmFsc2UpIHtcbiAgICBjb25zdCBkZWZlcnJlZDogUHJvbWlzZTxhbnk+ID0gZnJvbShbc2xvdF0pLnRvUHJvbWlzZSgpLFxuICAgICAgdGFzayA9IHsgc2xvdDogc2xvdCwgZGVmZXJyZWQ6IGRlZmVycmVkIH07XG5cbiAgICBkZWZlcnJlZC50aGVuKCgpID0+IHtcbiAgICAgIGlmICh0aGlzLmhhc1Nsb3RJbnRlcnZhbChzbG90KSkge1xuICAgICAgICB0aGlzLmNhbmNlbEludGVydmFsKHNsb3QpO1xuICAgICAgfVxuICAgICAgaWYgKHJlZnJlc2hJbnRlcnZhbCkge1xuICAgICAgICB0aGlzLmFkZFNsb3RJbnRlcnZhbCh0YXNrLCByZWZyZXNoSW50ZXJ2YWwpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgaWYgKHRoaXMuY29uZmlnLnNpbmdsZVJlcXVlc3RNb2RlID09PSB0cnVlICYmIGluaXRSZWZyZXNoKSB7XG4gICAgICAvLyBVc2UgYSB0aW1lciB0byBoYW5kbGUgcmVmcmVzaCBvZiBhIHNpbmdsZSByZXF1ZXN0IG1vZGVcbiAgICAgIHRoaXMucmVmcmVzaFNsb3RzLnB1c2goc2xvdCk7XG4gICAgICBpZiAodGhpcy5zaW5nbGVSZXF1ZXN0ICYmICF0aGlzLnNpbmdsZVJlcXVlc3QuY2xvc2VkKSB7XG4gICAgICAgIHRoaXMuc2luZ2xlUmVxdWVzdC51bnN1YnNjcmliZSgpO1xuICAgICAgfVxuICAgICAgdGhpcy5zaW5nbGVSZXF1ZXN0ID0gdGltZXIoMTAwKS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICBjb25zdCBwdWJhZHMgPSBnb29nbGV0YWcucHViYWRzKCk7XG4gICAgICAgIHB1YmFkcy5lbmFibGVTaW5nbGVSZXF1ZXN0KCk7XG4gICAgICAgIGdvb2dsZXRhZy5lbmFibGVTZXJ2aWNlcygpO1xuICAgICAgICB0aGlzLnJlZnJlc2hTbG90cy5mb3JFYWNoKHMgPT4ge1xuICAgICAgICAgIGdvb2dsZXRhZy5kaXNwbGF5KHMuZ2V0U2xvdEVsZW1lbnRJZCgpKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHB1YmFkcy5yZWZyZXNoKHRoaXMucmVmcmVzaFNsb3RzKTtcbiAgICAgICAgdGhpcy5yZWZyZXNoU2xvdHMgPSBbXTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBnb29nbGV0YWcuZGlzcGxheShzbG90LmdldFNsb3RFbGVtZW50SWQoKSk7XG4gICAgICB0aGlzLnJlZnJlc2goW3Rhc2tdKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZGVmZXJyZWQ7XG4gIH1cblxuICBjYW5jZWxJbnRlcnZhbChzbG90KSB7XG4gICAgaWYgKCF0aGlzLmhhc1Nsb3RJbnRlcnZhbChzbG90KSkge1xuICAgICAgdGhyb3cgbmV3IERGUFJlZnJlc2hFcnJvcignTm8gaW50ZXJ2YWwgZm9yIGdpdmVuIHNsb3QnKTtcbiAgICB9XG5cbiAgICBjb25zdCBpbnRlcnZhbDogU3Vic2NyaXB0aW9uID0gdGhpcy5pbnRlcnZhbHNbdGhpcy5zbG90SW50ZXJ2YWxLZXkoc2xvdCldO1xuICAgIGludGVydmFsLnVuc3Vic2NyaWJlKCk7XG4gICAgZGVsZXRlIHRoaXMuaW50ZXJ2YWxzW3Nsb3RdO1xuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICBwcml2YXRlIGhhc1Nsb3RJbnRlcnZhbChzbG90KSB7XG4gICAgcmV0dXJuIHRoaXMuc2xvdEludGVydmFsS2V5KHNsb3QpIGluIHRoaXMuaW50ZXJ2YWxzO1xuICB9XG5cbiAgcHJpdmF0ZSByZWZyZXNoKHRhc2tzPykge1xuICAgIGlmICh0YXNrcyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBnb29nbGV0YWcuY21kLnB1c2goKCkgPT4ge1xuICAgICAgICBnb29nbGV0YWcucHViYWRzKCkucmVmcmVzaCgpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHRhc2tzLmxlbmd0aCA9PT0gMCkgeyByZXR1cm4gZmFsc2U7IH1cblxuICAgIGdvb2dsZXRhZy5jbWQucHVzaCgoKSA9PiB7XG4gICAgICBnb29nbGV0YWcucHViYWRzKCkucmVmcmVzaCh0YXNrcy5tYXAodGFzayA9PiB0YXNrLnNsb3QpKTtcbiAgICAgIHRhc2tzLmZvckVhY2godGFzayA9PiB7XG4gICAgICAgIFByb21pc2UucmVzb2x2ZSh0YXNrLnNsb3QpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGFkZFNsb3RJbnRlcnZhbCh0YXNrLCBpbnRlcnZhbCkge1xuICAgIGNvbnN0IHBhcnNlZEludGVydmFsID0gdGhpcy5wYXJzZUR1cmF0aW9uLnBhcnNlRHVyYXRpb24oaW50ZXJ2YWwpO1xuICAgIHRoaXMudmFsaWRhdGVJbnRlcnZhbChwYXJzZWRJbnRlcnZhbCwgaW50ZXJ2YWwpO1xuXG4gICAgY29uc3QgcmVmcmVzaCA9IHRpbWVyKHBhcnNlZEludGVydmFsLCBwYXJzZWRJbnRlcnZhbCkuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgIGNvbnN0IGRvYyA9IHRoaXMuaW5qZWN0LmdldChET0NVTUVOVCk7XG4gICAgICBpZiAoIXRoaXMuaGlkZGVuQ2hlY2soZG9jLmdldEVsZW1lbnRCeUlkKHRhc2suc2xvdC5nZXRTbG90RWxlbWVudElkKCkpKSkge1xuICAgICAgICB0aGlzLnJlZnJlc2goW3Rhc2tdKTtcbiAgICAgICAgdGhpcy5yZWZyZXNoRXZlbnQuZW1pdCh0YXNrLnNsb3QpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgdGhpcy5pbnRlcnZhbHNbdGhpcy5zbG90SW50ZXJ2YWxLZXkodGFzay5zbG90KV0gPSByZWZyZXNoO1xuXG4gICAgcmV0dXJuIHJlZnJlc2g7XG4gIH1cblxuICBwcml2YXRlIHNsb3RJbnRlcnZhbEtleShzbG90KSB7XG4gICAgcmV0dXJuIHNsb3QuZ2V0U2xvdElkKCkuZ2V0RG9tSWQoKTtcbiAgfVxuXG4gIHByaXZhdGUgdmFsaWRhdGVJbnRlcnZhbChtaWxsaXNlY29uZHMsIGJlZm9yZVBhcnNpbmcpIHtcbiAgICBpZiAobWlsbGlzZWNvbmRzIDwgMTAwMCkge1xuICAgICAgY29uc29sZS53YXJuKCdDYXJlZnVsOiAke2JlZm9yZVBhcnNpbmd9IGlzIHF1aXRlIGEgbG93IGludGVydmFsIScpO1xuICAgIH1cbiAgfVxuXG4gIGhpZGRlbkNoZWNrKGVsZW1lbnQ6IEVsZW1lbnQpIHtcbiAgICBpZiAodHlwZW9mICh3aW5kb3cpICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgY29uc3QgY3NzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gICAgICBpZiAoY3NzLmRpc3BsYXkgPT09ICdub25lJykge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0gZWxzZSBpZiAoZWxlbWVudC5wYXJlbnRFbGVtZW50KSB7XG4gICAgICAgIHJldHVybiB0aGlzLmhpZGRlbkNoZWNrKGVsZW1lbnQucGFyZW50RWxlbWVudCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuIiwiaW1wb3J0IHtcbiAgRGlyZWN0aXZlLCBFbGVtZW50UmVmLFxuICBJbnB1dCwgT3V0cHV0LCBFdmVudEVtaXR0ZXIsXG4gIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95LCBJbmplY3QsIFBMQVRGT1JNX0lELCBPcHRpb25hbFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGlzUGxhdGZvcm1Ccm93c2VyIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IFJvdXRlciwgTmF2aWdhdGlvbkVuZCB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5cbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgZmlsdGVyIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuXG5pbXBvcnQgeyBEZnBTZXJ2aWNlLCB9IGZyb20gJy4uL3NlcnZpY2UvZGZwLnNlcnZpY2UnO1xuaW1wb3J0IHsgRGZwSURHZW5lcmF0b3JTZXJ2aWNlLCB9IGZyb20gJy4uL3NlcnZpY2UvZGZwLWlkLWdlbmVyYXRvci5zZXJ2aWNlJztcbmltcG9ydCB7IERmcFJlZnJlc2hTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZS9kZnAtcmVmcmVzaC5zZXJ2aWNlJztcblxuaW1wb3J0IHsgREZQSW5jb21wbGV0ZUVycm9yLCBHb29nbGVTbG90LCBEZnBDb25maWcgfSBmcm9tICcuLi9jbGFzcyc7XG5pbXBvcnQgeyBERlBfQ09ORklHIH0gZnJvbSAnLi4vc2VydmljZS9pbmplY3Rpb25fdG9rZW4nO1xuXG5kZWNsYXJlIHZhciBnb29nbGV0YWc7XG5cbmV4cG9ydCBjbGFzcyBEZnBSZWZyZXNoRXZlbnQge1xuICB0eXBlOiBzdHJpbmc7XG4gIHNsb3Q6IGFueTtcbiAgZGF0YT86IGFueTtcbn1cblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnZGZwLWFkJ1xufSlcbmV4cG9ydCBjbGFzcyBEZnBBZERpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcblxuICBASW5wdXQoKSBhZFVuaXQ6IHN0cmluZztcbiAgQElucHV0KCkgY2xpY2tVcmw6IHN0cmluZztcbiAgQElucHV0KCkgZm9yY2VTYWZlRnJhbWU6IGJvb2xlYW47XG4gIEBJbnB1dCgpIHNhZmVGcmFtZUNvbmZpZzogc3RyaW5nO1xuICBASW5wdXQoKSByZWZyZXNoOiBzdHJpbmc7XG4gIEBJbnB1dCgpIGNvbGxhcHNlSWZFbXB0eTogYm9vbGVhbjtcblxuICBAT3V0cHV0KCkgYWZ0ZXJSZWZyZXNoOiBFdmVudEVtaXR0ZXI8RGZwUmVmcmVzaEV2ZW50PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICBwcml2YXRlIHNpemVzID0gW107XG5cbiAgcHJpdmF0ZSByZXNwb25zaXZlTWFwcGluZyA9IFtdO1xuXG4gIHByaXZhdGUgdGFyZ2V0aW5ncyA9IFtdO1xuXG4gIHByaXZhdGUgZXhjbHVzaW9ucyA9IFtdO1xuXG4gIHByaXZhdGUgc2NyaXB0cyA9IFtdO1xuXG4gIHByaXZhdGUgc2xvdDogR29vZ2xlU2xvdDtcblxuICBwcml2YXRlIG9uU2FtZU5hdmlnYXRpb246IFN1YnNjcmlwdGlvbjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBASW5qZWN0KFBMQVRGT1JNX0lEKSBwcml2YXRlIHBsYXRmb3JtSWQ6IE9iamVjdCxcbiAgICBwcml2YXRlIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXG4gICAgcHJpdmF0ZSBkZnA6IERmcFNlcnZpY2UsXG4gICAgcHJpdmF0ZSBkZnBJREdlbmVyYXRvcjogRGZwSURHZW5lcmF0b3JTZXJ2aWNlLFxuICAgIHByaXZhdGUgZGZwUmVmcmVzaDogRGZwUmVmcmVzaFNlcnZpY2UsXG4gICAgQEluamVjdChERlBfQ09ORklHKSBwcml2YXRlIGNvbmZpZzogRGZwQ29uZmlnLFxuICAgIEBPcHRpb25hbCgpIHJvdXRlcjogUm91dGVyXG4gICkge1xuICAgIGlmIChpc1BsYXRmb3JtQnJvd3Nlcih0aGlzLnBsYXRmb3JtSWQpKSB7XG4gICAgICB0aGlzLmRmcFJlZnJlc2gucmVmcmVzaEV2ZW50LnN1YnNjcmliZShzbG90ID0+IHtcbiAgICAgICAgaWYgKHNsb3QgPT09IHRoaXMuc2xvdCkge1xuICAgICAgICAgIHRoaXMuYWZ0ZXJSZWZyZXNoLmVtaXQoeyB0eXBlOiAncmVmcmVzaCcsIHNsb3Q6IHNsb3QgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgaWYgKHJvdXRlcikge1xuICAgICAgICB0aGlzLm9uU2FtZU5hdmlnYXRpb24gPSByb3V0ZXIuZXZlbnRzLnBpcGUoZmlsdGVyKGV2ZW50ID0+IGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkpXG4gICAgICAgICAgLnN1YnNjcmliZSgoZXZlbnQ6IE5hdmlnYXRpb25FbmQpID0+IHtcbiAgICAgICAgICAgIGlmICh0aGlzLnNsb3QgJiYgIXRoaXMucmVmcmVzaCAmJiB0aGlzLmNvbmZpZy5vblNhbWVOYXZpZ2F0aW9uID09PSAncmVmcmVzaCcpIHtcbiAgICAgICAgICAgICAgdGhpcy5yZWZyZXNoQ29udGVudC5jYWxsKHRoaXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIG5nT25Jbml0KCkge1xuICAgIGlmIChpc1BsYXRmb3JtQnJvd3Nlcih0aGlzLnBsYXRmb3JtSWQpKSB7XG4gICAgICB0aGlzLmRmcElER2VuZXJhdG9yLmRmcElER2VuZXJhdG9yKHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50KTtcbiAgICB9XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgaWYgKGlzUGxhdGZvcm1Ccm93c2VyKHRoaXMucGxhdGZvcm1JZCkpIHtcbiAgICAgIHRoaXMuZGZwLmRlZmluZVRhc2soKCkgPT4ge1xuICAgICAgICB0aGlzLmRlZmluZVNsb3QoKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIG5nT25EZXN0cm95KCkge1xuICAgIGlmICh0aGlzLnNsb3QpIHtcbiAgICAgIGdvb2dsZXRhZy5kZXN0cm95U2xvdHMoW3RoaXMuc2xvdF0pO1xuICAgIH1cbiAgICBpZiAodGhpcy5vblNhbWVOYXZpZ2F0aW9uKSB7XG4gICAgICB0aGlzLm9uU2FtZU5hdmlnYXRpb24udW5zdWJzY3JpYmUoKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHNldFJlc3BvbnNpdmVNYXBwaW5nKHNsb3QpIHtcbiAgICBjb25zdCBhZCA9IHRoaXMuZ2V0U3RhdGUoKTtcblxuICAgIGlmIChhZC5yZXNwb25zaXZlTWFwcGluZy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBzaXplTWFwcGluZyA9IGdvb2dsZXRhZy5zaXplTWFwcGluZygpO1xuXG4gICAgYWQucmVzcG9uc2l2ZU1hcHBpbmcuZm9yRWFjaChtYXBwaW5nID0+IHtcbiAgICAgIHNpemVNYXBwaW5nLmFkZFNpemUobWFwcGluZy52aWV3cG9ydFNpemUsIG1hcHBpbmcuYWRTaXplcyk7XG4gICAgfSk7XG5cbiAgICBzbG90LmRlZmluZVNpemVNYXBwaW5nKHNpemVNYXBwaW5nLmJ1aWxkKCkpO1xuICB9XG5cbiAgcHJpdmF0ZSBkZWZpbmVTbG90KCkge1xuICAgIGNvbnN0IGFkID0gdGhpcy5nZXRTdGF0ZSgpLFxuICAgICAgZWxlbWVudCA9IHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50O1xuXG4gICAgdGhpcy5zbG90ID0gZ29vZ2xldGFnLmRlZmluZVNsb3QoYWQuYWRVbml0LCBhZC5zaXplcywgZWxlbWVudC5pZCk7XG5cbiAgICBpZiAodGhpcy5mb3JjZVNhZmVGcmFtZSAhPT0gdW5kZWZpbmVkICYmIGFkLmZvcmNlU2FmZUZyYW1lID09PSAhdGhpcy5jb25maWcuZm9yY2VTYWZlRnJhbWUpIHtcbiAgICAgIHRoaXMuc2xvdC5zZXRGb3JjZVNhZmVGcmFtZShhZC5mb3JjZVNhZmVGcmFtZSk7XG4gICAgfVxuXG4gICAgaWYgKGFkLmNsaWNrVXJsKSB7XG4gICAgICB0aGlzLnNsb3Quc2V0Q2xpY2tVcmwoYWQuY2xpY2tVcmwpO1xuICAgIH1cblxuICAgIGlmIChhZC5jb2xsYXBzZUlmRW1wdHkpIHtcbiAgICAgIHRoaXMuc2xvdC5zZXRDb2xsYXBzZUVtcHR5RGl2KHRydWUsIHRydWUpO1xuICAgIH1cblxuICAgIGlmIChhZC5zYWZlRnJhbWVDb25maWcpIHtcbiAgICAgIHRoaXMuc2xvdC5zZXRTYWZlRnJhbWVDb25maWcoXG4gICAgICAgIChKU09OLnBhcnNlKGFkLnNhZmVGcmFtZUNvbmZpZykpXG4gICAgICApO1xuICAgIH1cblxuICAgIGdvb2dsZXRhZy5wdWJhZHMoKS5hZGRFdmVudExpc3RlbmVyKCdzbG90UmVuZGVyRW5kZWQnLCAoZXZlbnQpID0+IHtcbiAgICAgIGlmIChldmVudC5zbG90ID09PSB0aGlzLnNsb3QpIHtcbiAgICAgICAgdGhpcy5hZnRlclJlZnJlc2guZW1pdCh7IHR5cGU6ICdyZW5kZXJFbmRlZCcsIHNsb3Q6IHRoaXMuc2xvdCwgZGF0YTogZXZlbnQgfSk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICB0aGlzLnNldFJlc3BvbnNpdmVNYXBwaW5nKHRoaXMuc2xvdCk7XG5cbiAgICBhZC50YXJnZXRpbmdzLmZvckVhY2godGFyZ2V0aW5nID0+IHtcbiAgICAgIHRoaXMuc2xvdC5zZXRUYXJnZXRpbmcodGFyZ2V0aW5nLmtleSwgdGFyZ2V0aW5nLnZhbHVlcyk7XG4gICAgfSk7XG5cbiAgICBhZC5leGNsdXNpb25zLmZvckVhY2goZXhjbHVzaW9uID0+IHtcbiAgICAgIHRoaXMuc2xvdC5zZXRDYXRlZ29yeUV4Y2x1c2lvbihleGNsdXNpb24pO1xuICAgIH0pO1xuXG4gICAgYWQuc2NyaXB0cy5mb3JFYWNoKHNjcmlwdCA9PiB7IHNjcmlwdCh0aGlzLnNsb3QpOyB9KTtcblxuICAgIGlmICh0aGlzLmNvbmZpZy5lbmFibGVWaWRlb0Fkcykge1xuICAgICAgdGhpcy5zbG90LmFkZFNlcnZpY2UoZ29vZ2xldGFnLmNvbXBhbmlvbkFkcygpKTtcbiAgICB9XG5cbiAgICB0aGlzLnNsb3QuYWRkU2VydmljZShnb29nbGV0YWcucHViYWRzKCkpO1xuXG4gICAgdGhpcy5yZWZyZXNoQ29udGVudCgpO1xuICB9XG5cbiAgcHJpdmF0ZSByZWZyZXNoQ29udGVudCgpIHtcbiAgICB0aGlzLmRmcFJlZnJlc2guc2xvdFJlZnJlc2godGhpcy5zbG90LCB0aGlzLnJlZnJlc2gsIHRydWUpLnRoZW4oc2xvdCA9PiB7XG4gICAgICB0aGlzLmFmdGVyUmVmcmVzaC5lbWl0KHsgdHlwZTogJ2luaXQnLCBzbG90OiBzbG90IH0pO1xuICAgIH0pO1xuICB9XG5cbiAgY2hlY2tWYWxpZCgpIHtcbiAgICBpZiAodGhpcy5zaXplcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBERlBJbmNvbXBsZXRlRXJyb3IoJ2RmcC1hZCcsICdkZnAtc2l6ZScpO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuYWRVbml0KSB7XG4gICAgICB0aHJvdyBuZXcgREZQSW5jb21wbGV0ZUVycm9yKCdkZnAtYWQnLCAnYWQtdW5pdCcsIHRydWUpO1xuICAgIH1cbiAgfVxuXG4gIGdldCBpc0hpZGRlbigpIHtcbiAgICByZXR1cm4gdGhpcy5kZnBSZWZyZXNoLmhpZGRlbkNoZWNrKHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50KTtcbiAgfVxuXG4gIGdldFN0YXRlKCkge1xuICAgIHRoaXMuY2hlY2tWYWxpZCgpO1xuICAgIHJldHVybiBPYmplY3QuZnJlZXplKHtcbiAgICAgIHNpemVzOiB0aGlzLnNpemVzLFxuICAgICAgcmVzcG9uc2l2ZU1hcHBpbmc6IHRoaXMucmVzcG9uc2l2ZU1hcHBpbmcsXG4gICAgICB0YXJnZXRpbmdzOiB0aGlzLnRhcmdldGluZ3MsXG4gICAgICBleGNsdXNpb25zOiB0aGlzLmV4Y2x1c2lvbnMsXG4gICAgICBhZFVuaXQ6IHRoaXMuYWRVbml0LFxuICAgICAgZm9yY2VTYWZlRnJhbWU6IHRoaXMuZm9yY2VTYWZlRnJhbWUgPT09IHRydWUsXG4gICAgICBzYWZlRnJhbWVDb25maWc6IHRoaXMuc2FmZUZyYW1lQ29uZmlnLFxuICAgICAgY2xpY2tVcmw6IHRoaXMuY2xpY2tVcmwsXG4gICAgICByZWZyZXNoOiB0aGlzLnJlZnJlc2gsXG4gICAgICBzY3JpcHRzOiB0aGlzLnNjcmlwdHMsXG4gICAgICBjb2xsYXBzZUlmRW1wdHk6IHRoaXMuY29sbGFwc2VJZkVtcHR5ID09PSB0cnVlXG4gICAgfSk7XG4gIH1cblxuICBhZGRTaXplKHNpemUpIHtcbiAgICB0aGlzLnNpemVzLnB1c2goc2l6ZSk7XG4gIH1cblxuICBhZGRSZXNwb25zaXZlTWFwcGluZyhtYXBwaW5nKSB7XG4gICAgdGhpcy5yZXNwb25zaXZlTWFwcGluZy5wdXNoKG1hcHBpbmcpO1xuICB9XG5cbiAgYWRkVGFyZ2V0aW5nKHRhcmdldGluZykge1xuICAgIHRoaXMudGFyZ2V0aW5ncy5wdXNoKHRhcmdldGluZyk7XG4gIH1cblxuICBhZGRFeGNsdXNpb24oZXhjbHVzaW9uKSB7XG4gICAgdGhpcy5leGNsdXNpb25zLnB1c2goZXhjbHVzaW9uKTtcbiAgfVxuXG4gIGFkZFNjcmlwdChzY3JpcHQpIHtcbiAgICB0aGlzLnNjcmlwdHMucHVzaChzY3JpcHQpO1xuICB9XG5cbn1cbiIsImltcG9ydCB7XG4gICAgRGlyZWN0aXZlLCBFbGVtZW50UmVmLFxuICAgIEluamVjdCwgZm9yd2FyZFJlZixcbiAgICBIb3N0TGlzdGVuZXJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IERmcEFkRGlyZWN0aXZlIH0gZnJvbSAnLi9kZnAtYWQuZGlyZWN0aXZlJztcbmltcG9ydCB7IERmcFJlZnJlc2hTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZS9kZnAtcmVmcmVzaC5zZXJ2aWNlJztcblxuQERpcmVjdGl2ZSh7XG4gICAgc2VsZWN0b3I6ICdkZnAtYWRbcmVzcG9uc2l2ZV0nXG59KVxuZXhwb3J0IGNsYXNzIERmcEFkUmVzcG9uc2l2ZURpcmVjdGl2ZSB7XG5cbiAgICBwcml2YXRlIGlmcmFtZTogSFRNTElGcmFtZUVsZW1lbnQ7XG4gICAgcHJpdmF0ZSBpZnJhbWVXaWR0aDogbnVtYmVyO1xuICAgIHByaXZhdGUgc2xvdDogYW55O1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgICAgICAgQEluamVjdChmb3J3YXJkUmVmKCgpID0+IERmcEFkRGlyZWN0aXZlKSlcbiAgICAgICAgcHJpdmF0ZSBhZDogRGZwQWREaXJlY3RpdmUsXG4gICAgICAgIHByaXZhdGUgZGZwUmVmcmVzaDogRGZwUmVmcmVzaFNlcnZpY2VcbiAgICApIHtcbiAgICAgICAgdGhpcy5hZC5hZnRlclJlZnJlc2guc3Vic2NyaWJlKGV2ZW50ID0+IHtcbiAgICAgICAgICAgIHRoaXMuc2xvdCA9IGV2ZW50LnNsb3Q7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnKVxuICAgIG5vcm1hbGl6ZUlmcmFtZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuYWQuaXNIaWRkZW4pIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmlmcmFtZSA9IHRoaXMuaWZyYW1lIHx8IHRoaXMuZ2V0SWZyYW1lKCk7XG4gICAgICAgIGlmICghdGhpcy5pZnJhbWUpIHsgcmV0dXJuIGZhbHNlOyB9XG5cbiAgICAgICAgdGhpcy5pZnJhbWVXaWR0aCA9IHRoaXMuaWZyYW1lV2lkdGggfHwgK3RoaXMuaWZyYW1lLndpZHRoO1xuXG4gICAgICAgIGNvbnN0IHdpbldpZHRoID0gd2luZG93LmlubmVyV2lkdGg7XG5cbiAgICAgICAgbGV0IHN0YXRlID0gdGhpcy5hZC5nZXRTdGF0ZSgpLFxuICAgICAgICAgICAgd2lkdGggPSAwO1xuXG4gICAgICAgIHN0YXRlLnNpemVzLmZvckVhY2goc2l6ZSA9PiB7XG4gICAgICAgICAgICBpZiAoc2l6ZVswXSA8IHdpbldpZHRoKSB7XG4gICAgICAgICAgICAgICAgd2lkdGggPSBNYXRoLm1heCh3aWR0aCwgc2l6ZVswXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChzdGF0ZS5zaXplcy5sZW5ndGggPiAxICYmIHdpZHRoICE9PSB0aGlzLmlmcmFtZVdpZHRoKSB7XG4gICAgICAgICAgICBzdGF0ZSA9IHRoaXMuYWQuZ2V0U3RhdGUoKTtcbiAgICAgICAgICAgIHRoaXMuaWZyYW1lV2lkdGggPSB3aWR0aDtcbiAgICAgICAgICAgIHRoaXMuaWZyYW1lLnNldEF0dHJpYnV0ZSgnd2lkdGgnLCB3aWR0aCArICcnKTtcbiAgICAgICAgICAgIHRoaXMuZGZwUmVmcmVzaC5zbG90UmVmcmVzaCh0aGlzLnNsb3QsIHN0YXRlLnJlZnJlc2gpLnRoZW4oc2xvdCA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5hZC5hZnRlclJlZnJlc2guZW1pdCh7IHR5cGU6ICdyZXNpemUnLCBzbG90OiBzbG90IH0pO1xuICAgICAgICAgICAgICAgIHRoaXMuaWZyYW1lID0gdGhpcy5nZXRJZnJhbWUoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0SWZyYW1lKCkge1xuICAgICAgICBjb25zdCBhZDogRWxlbWVudCA9IHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LFxuICAgICAgICAgICAgaWZyYW1lID0gYWQucXVlcnlTZWxlY3RvcignaWZyYW1lJyk7XG4gICAgICAgIGlmIChpZnJhbWUgJiYgK2lmcmFtZS53aWR0aCA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiBpZnJhbWU7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBEaXJlY3RpdmUsIEluamVjdCwgZm9yd2FyZFJlZiwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBEZnBBZERpcmVjdGl2ZSB9IGZyb20gJy4vZGZwLWFkLmRpcmVjdGl2ZSc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ2RmcC1yZXNwb25zaXZlJ1xufSlcbmV4cG9ydCBjbGFzcyBEZnBSZXNwb25zaXZlRGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0IHtcblxuICBASW5wdXQoKSB2aWV3cG9ydCA9IFswLCAwXTtcbiAgQElucHV0KCkgYWRTaXplcyA9IFtdO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIEBJbmplY3QoZm9yd2FyZFJlZigoKSA9PiBEZnBBZERpcmVjdGl2ZSkpXG4gICAgcHJpdmF0ZSBhZDogRGZwQWREaXJlY3RpdmVcbiAgKSB7IH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLmFkLmFkZFJlc3BvbnNpdmVNYXBwaW5nKHRoaXMuZ2V0U3RhdGUoKSk7XG4gIH1cblxuICBASW5wdXQoKVxuICBzZXQgdmlld1dpZHRoKHZhbDogbnVtYmVyKSB7XG4gICAgaWYgKHZhbCA+IDApIHtcbiAgICAgIHRoaXMudmlld3BvcnRbMF0gPSB2YWw7XG4gICAgfVxuICB9XG5cbiAgQElucHV0KClcbiAgc2V0IHZpZXdIZWlnaHQodmFsOiBudW1iZXIpIHtcbiAgICBpZiAodmFsID4gMCkge1xuICAgICAgdGhpcy52aWV3cG9ydFsxXSA9IHZhbDtcbiAgICB9XG4gIH1cblxuICBhZGRTaXplKHNpemUpIHtcbiAgICB0aGlzLmFkU2l6ZXMucHVzaChzaXplKTtcbiAgfVxuXG4gIGdldFN0YXRlKCkge1xuICAgIHJldHVybiBPYmplY3QuZnJlZXplKHtcbiAgICAgIHZpZXdwb3J0U2l6ZTogdGhpcy52aWV3cG9ydCxcbiAgICAgIGFkU2l6ZXM6IHRoaXMuYWRTaXplc1xuICAgIH0pO1xuICB9XG59XG4iLCJpbXBvcnQgeyBEaXJlY3RpdmUsIEVsZW1lbnRSZWYsIElucHV0LCBJbmplY3QsIGZvcndhcmRSZWYsIE9uSW5pdCwgT3B0aW9uYWwgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgRGZwQWREaXJlY3RpdmUgfSBmcm9tICcuL2RmcC1hZC5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgRGZwUmVzcG9uc2l2ZURpcmVjdGl2ZSB9IGZyb20gJy4vZGZwLXJlc3BvbnNpdmUuZGlyZWN0aXZlJztcblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnZGZwLXNpemUnXG59KVxuZXhwb3J0IGNsYXNzIERmcFNpemVEaXJlY3RpdmUgaW1wbGVtZW50cyBPbkluaXQge1xuXG4gIEBJbnB1dCgpIHdpZHRoOiBudW1iZXI7XG4gIEBJbnB1dCgpIGhlaWdodDogbnVtYmVyO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgICBASW5qZWN0KGZvcndhcmRSZWYoKCkgPT4gRGZwQWREaXJlY3RpdmUpKVxuICAgIHByaXZhdGUgYWQ6IERmcEFkRGlyZWN0aXZlLFxuICAgIEBPcHRpb25hbCgpIEBJbmplY3QoZm9yd2FyZFJlZigoKSA9PiBEZnBSZXNwb25zaXZlRGlyZWN0aXZlKSlcbiAgICBwcml2YXRlIHJlc3A6IERmcFJlc3BvbnNpdmVEaXJlY3RpdmVcbiAgKSB7IH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICBjb25zdCB0YXJnZXQgPSB0aGlzLnJlc3AgfHwgdGhpcy5hZCxcbiAgICAgIGlubmVyVGV4dDogc3RyaW5nID0gdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuaW5uZXJUZXh0O1xuXG4gICAgaWYgKHRoaXMud2lkdGggJiYgdGhpcy5oZWlnaHQpIHtcbiAgICAgIHRhcmdldC5hZGRTaXplKFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0pO1xuICAgIH0gZWxzZSBpZiAoaW5uZXJUZXh0LnRyaW0oKSAhPT0gJycpIHtcbiAgICAgIHRhcmdldC5hZGRTaXplKGlubmVyVGV4dCk7XG4gICAgfVxuICB9XG5cbn1cbiIsImltcG9ydCB7IERpcmVjdGl2ZSwgQWZ0ZXJDb250ZW50SW5pdCwgSW5wdXQsIEluamVjdCwgZm9yd2FyZFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBERlBJbmNvbXBsZXRlRXJyb3IgfSBmcm9tICcuLi9jbGFzcyc7XG5pbXBvcnQgeyBEZnBBZERpcmVjdGl2ZSB9IGZyb20gJy4vZGZwLWFkLmRpcmVjdGl2ZSc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ2RmcC10YXJnZXRpbmcnXG59KVxuZXhwb3J0IGNsYXNzIERmcFRhcmdldGluZ0RpcmVjdGl2ZSBpbXBsZW1lbnRzIEFmdGVyQ29udGVudEluaXQge1xuXG4gIEBJbnB1dCgpIGtleTogc3RyaW5nO1xuXG4gIEBJbnB1dCgpXG4gIHNldCB2YWx1ZSh2YWw6IHN0cmluZyB8IEFycmF5PHN0cmluZz4pIHtcbiAgICBpZiAodmFsIGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICAgIHZhbC5mb3JFYWNoKHYgPT4gdGhpcy5hZGRWYWx1ZSh2KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuYWRkVmFsdWUodmFsKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHZhbHVlcyA9IFtdO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIEBJbmplY3QoZm9yd2FyZFJlZigoKSA9PiBEZnBBZERpcmVjdGl2ZSkpXG4gICAgcHJpdmF0ZSBhZDogRGZwQWREaXJlY3RpdmVcbiAgKSB7IH1cblxuICBuZ0FmdGVyQ29udGVudEluaXQoKSB7XG4gICAgY29uc3QgdGFyZ2V0aW5nID0gdGhpcy5nZXRTdGF0ZSgpO1xuICAgIHRoaXMuYWQuYWRkVGFyZ2V0aW5nKHRhcmdldGluZyk7XG4gIH1cblxuICBjaGVja1ZhbGlkKCkge1xuICAgIGlmICh0aGlzLmtleSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aHJvdyBuZXcgREZQSW5jb21wbGV0ZUVycm9yKCdkZnAtdGFyZ2V0aW5nJywgJ2tleScsIHRydWUpO1xuICAgIH1cbiAgICBpZiAodGhpcy52YWx1ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgREZQSW5jb21wbGV0ZUVycm9yKCdkZnAtdGFyZ2V0aW5nJywgJ3ZhbHVlJywgdHJ1ZSk7XG4gICAgfVxuICB9XG5cbiAgZ2V0U3RhdGUoKSB7XG4gICAgdGhpcy5jaGVja1ZhbGlkKCk7XG4gICAgcmV0dXJuIE9iamVjdC5mcmVlemUoe1xuICAgICAga2V5OiB0aGlzLmtleSxcbiAgICAgIHZhbHVlczogdGhpcy52YWx1ZXNcbiAgICB9KTtcbiAgfVxuXG4gIGFkZFZhbHVlKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlICYmICF0aGlzLnZhbHVlcy5maW5kKGl0ZW0gPT4gaXRlbSA9PT0gdmFsdWUpKSB7XG4gICAgICB0aGlzLnZhbHVlcy5wdXNoKHZhbHVlKTtcbiAgICB9XG4gIH1cblxufVxuIiwiaW1wb3J0IHtcbiAgRGlyZWN0aXZlLCBFbGVtZW50UmVmLFxuICBJbmplY3QsIGZvcndhcmRSZWYsXG4gIE9uSW5pdFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgRGZwQWREaXJlY3RpdmUgfSBmcm9tICcuL2RmcC1hZC5kaXJlY3RpdmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdkZnAtZXhjbHVzaW9uJ1xufSlcbmV4cG9ydCBjbGFzcyBEZnBFeGNsdXNpb25EaXJlY3RpdmUgaW1wbGVtZW50cyBPbkluaXQge1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgICBASW5qZWN0KGZvcndhcmRSZWYoKCkgPT4gRGZwQWREaXJlY3RpdmUpKVxuICAgIHByaXZhdGUgYWQ6IERmcEFkRGlyZWN0aXZlXG4gICkge31cblxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLmFkLmFkZEV4Y2x1c2lvbih0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5pbm5lclRleHQpO1xuICB9XG5cbn1cbiIsImltcG9ydCB7XG4gIERpcmVjdGl2ZSwgRWxlbWVudFJlZixcbiAgSW5qZWN0LCBmb3J3YXJkUmVmLFxuICBPbkluaXRcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IERmcFRhcmdldGluZ0RpcmVjdGl2ZSB9IGZyb20gJy4vZGZwLXRhcmdldGluZy5kaXJlY3RpdmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdkZnAtdmFsdWUnXG59KVxuZXhwb3J0IGNsYXNzIERmcFZhbHVlRGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0IHtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXG4gICAgQEluamVjdChmb3J3YXJkUmVmKCgpID0+IERmcFRhcmdldGluZ0RpcmVjdGl2ZSkpXG4gICAgcHJpdmF0ZSB0YXJnZXRpbmc6IERmcFRhcmdldGluZ0RpcmVjdGl2ZVxuICApIHsgfVxuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMudGFyZ2V0aW5nLmFkZFZhbHVlKHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmlubmVyVGV4dCk7XG4gIH1cblxufVxuIiwiaW1wb3J0IHtcbiAgRGlyZWN0aXZlLCBFbGVtZW50UmVmLFxuICBJbnB1dCxcbiAgT25Jbml0LFxuICBJbmplY3QsXG4gIFBMQVRGT1JNX0lEXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgaXNQbGF0Zm9ybUJyb3dzZXIgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdkZnAtYXVkaWVuY2UtcGl4ZWwnXG59KVxuZXhwb3J0IGNsYXNzIERmcEF1ZGllbmNlUGl4ZWxEaXJlY3RpdmUgaW1wbGVtZW50cyBPbkluaXQge1xuXG4gIEBJbnB1dCgpIGFkVW5pdDogc3RyaW5nO1xuICBASW5wdXQoKSBzZWdtZW50SWQ6IG51bWJlcjtcbiAgQElucHV0KCkgcHBpZDogbnVtYmVyO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIEBJbmplY3QoUExBVEZPUk1fSUQpIHByaXZhdGUgcGxhdGZvcm1JZDogT2JqZWN0LFxuICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZlxuICApIHsgfVxuXG4gIG5nT25Jbml0KCkge1xuICAgIGlmIChpc1BsYXRmb3JtQnJvd3Nlcih0aGlzLnBsYXRmb3JtSWQpKSB7XG4gICAgICBjb25zdCBheGVsID0gTWF0aC5yYW5kb20oKSxcbiAgICAgICAgcmFuZG9tID0gYXhlbCAqIDEwMDAwMDAwMDAwMDAwO1xuXG4gICAgICBsZXQgYWRVbml0ID0gJyc7XG4gICAgICBpZiAodGhpcy5hZFVuaXQpIHtcbiAgICAgICAgYWRVbml0ID0gYGRjX2l1PSR7dGhpcy5hZFVuaXR9YDtcbiAgICAgIH1cblxuICAgICAgbGV0IHBwaWQgPSAnJztcbiAgICAgIGlmICh0aGlzLnBwaWQpIHtcbiAgICAgICAgcHBpZCA9IGBwcGlkPSR7dGhpcy5wcGlkfWA7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHBpeGVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW1nJyk7XG5cbiAgICAgIHBpeGVsLnNyYyA9ICdodHRwczovL3B1YmFkcy5nLmRvdWJsZWNsaWNrLm5ldC9hY3Rpdml0eTtvcmQ9JztcbiAgICAgIHBpeGVsLnNyYyArPSBgJHtyYW5kb219O2RjX3NlZz0ke3RoaXMuc2VnbWVudElkfTske2FkVW5pdH0ke3BwaWR9YDtcblxuICAgICAgcGl4ZWwud2lkdGggPSAxO1xuICAgICAgcGl4ZWwuaGVpZ2h0ID0gMTtcbiAgICAgIHBpeGVsLmJvcmRlciA9ICcwJztcblxuICAgICAgcGl4ZWwuc3R5bGUudmlzaWJpbGl0eSA9ICdoaWRkZW4nO1xuXG4gICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5hcHBlbmQocGl4ZWwpO1xuICAgIH1cbiAgfVxufVxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE1vZHVsZVdpdGhQcm92aWRlcnMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgRGZwQ29uZmlnLCB9IGZyb20gJy4vY2xhc3MnO1xuaW1wb3J0IHsgREZQX0NPTkZJRyB9IGZyb20gJy4vc2VydmljZS9pbmplY3Rpb25fdG9rZW4nO1xuXG5pbXBvcnQgeyBJZGxlU2VydmljZSB9IGZyb20gJy4vc2VydmljZS9pZGxlLnNlcnZpY2UnO1xuaW1wb3J0IHsgSHR0cEVycm9yU2VydmljZSB9IGZyb20gJy4vc2VydmljZS9odHRwLWVycm9yLnNlcnZpY2UnO1xuaW1wb3J0IHsgUGFyc2VEdXJhdGlvblNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2UvcGFyc2UtZHVyYXRpb24uc2VydmljZSc7XG5pbXBvcnQgeyBTY3JpcHRJbmplY3RvclNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2Uvc2NyaXB0LWluamVjdG9yLnNlcnZpY2UnO1xuaW1wb3J0IHsgRGZwU2VydmljZSB9IGZyb20gJy4vc2VydmljZS9kZnAuc2VydmljZSc7XG5pbXBvcnQgeyBEZnBJREdlbmVyYXRvclNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2UvZGZwLWlkLWdlbmVyYXRvci5zZXJ2aWNlJztcbmltcG9ydCB7IERmcFJlZnJlc2hTZXJ2aWNlIH0gZnJvbSAnLi9zZXJ2aWNlL2RmcC1yZWZyZXNoLnNlcnZpY2UnO1xuXG5pbXBvcnQgeyBEZnBBZERpcmVjdGl2ZSB9IGZyb20gJy4vZGlyZWN0aXZlL2RmcC1hZC5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgRGZwU2l6ZURpcmVjdGl2ZSB9IGZyb20gJy4vZGlyZWN0aXZlL2RmcC1zaXplLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBEZnBSZXNwb25zaXZlRGlyZWN0aXZlIH0gZnJvbSAnLi9kaXJlY3RpdmUvZGZwLXJlc3BvbnNpdmUuZGlyZWN0aXZlJztcbmltcG9ydCB7IERmcEFkUmVzcG9uc2l2ZURpcmVjdGl2ZSB9IGZyb20gJy4vZGlyZWN0aXZlL2RmcC1hZC1yZXNwb25zaXZlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBEZnBUYXJnZXRpbmdEaXJlY3RpdmUgfSBmcm9tICcuL2RpcmVjdGl2ZS9kZnAtdGFyZ2V0aW5nLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBEZnBFeGNsdXNpb25EaXJlY3RpdmUgfSBmcm9tICcuL2RpcmVjdGl2ZS9kZnAtZXhjbHVzaW9uLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBEZnBWYWx1ZURpcmVjdGl2ZSB9IGZyb20gJy4vZGlyZWN0aXZlL2RmcC12YWx1ZS5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgRGZwQXVkaWVuY2VQaXhlbERpcmVjdGl2ZSB9IGZyb20gJy4vZGlyZWN0aXZlL2RmcC1hdWRpZW5jZS1waXhlbC5kaXJlY3RpdmUnO1xuXG5jb25zdCBESVJFQ1RJVkVTID0gW1xuICBEZnBBZERpcmVjdGl2ZSxcbiAgRGZwU2l6ZURpcmVjdGl2ZSxcbiAgRGZwUmVzcG9uc2l2ZURpcmVjdGl2ZSxcbiAgRGZwQWRSZXNwb25zaXZlRGlyZWN0aXZlLFxuICBEZnBUYXJnZXRpbmdEaXJlY3RpdmUsIERmcEV4Y2x1c2lvbkRpcmVjdGl2ZSwgRGZwVmFsdWVEaXJlY3RpdmUsXG4gIERmcEF1ZGllbmNlUGl4ZWxEaXJlY3RpdmVcbl07XG5cbmNvbnN0IFNFUlZJQ0VTID0gW1xuICBIdHRwRXJyb3JTZXJ2aWNlLFxuICBQYXJzZUR1cmF0aW9uU2VydmljZSxcbiAgU2NyaXB0SW5qZWN0b3JTZXJ2aWNlLFxuICBEZnBTZXJ2aWNlLCBEZnBJREdlbmVyYXRvclNlcnZpY2UsIERmcFJlZnJlc2hTZXJ2aWNlXG5dO1xuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG5cbiAgXSxcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgLi4uRElSRUNUSVZFU1xuICBdLFxuICBwcm92aWRlcnM6IFtcbiAgICAuLi5TRVJWSUNFU1xuICBdLFxuICBleHBvcnRzOiBbXG4gICAgLi4uRElSRUNUSVZFU1xuICBdXG59KVxuZXhwb3J0IGNsYXNzIERmcE1vZHVsZSB7XG4gIHN0YXRpYyBmb3JSb290KGNvbmZpZz86IERmcENvbmZpZyk6IE1vZHVsZVdpdGhQcm92aWRlcnMge1xuICAgIHJldHVybiB7XG4gICAgICBuZ01vZHVsZTogRGZwTW9kdWxlLFxuICAgICAgcHJvdmlkZXJzOiBbXG4gICAgICAgIC4uLihjb25maWcgJiYgY29uZmlnLmlkbGVMb2FkID09PSB0cnVlID8gW0lkbGVTZXJ2aWNlXSA6IFtdKSxcbiAgICAgICAgeyBwcm92aWRlOiBERlBfQ09ORklHLCB1c2VWYWx1ZTogY29uZmlnIHx8IHt9IH1cbiAgICAgIF1cbiAgICB9O1xuICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBSUEsTUFBYSxVQUFVLEdBQUcsSUFBSSxjQUFjLENBQVksV0FBVyxDQUFDOzs7Ozs7QUNKcEU7Ozs7O0lBUUUsWUFDdUIsVUFBa0IsRUFDdkMsSUFBWTs7UUFFWixNQUFNLEdBQUcsR0FBUSxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsR0FBRyxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQzdELElBQUksR0FBRyxDQUFDLG1CQUFtQixFQUFFO1lBQzNCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLEdBQUc7Z0JBQzdCLE9BQU8sR0FBRyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQ3JDLENBQUM7U0FDSDthQUFNO1lBQ0wsSUFBSSxDQUFDLG1CQUFtQixHQUFHLENBQUMsR0FBRztnQkFDN0IsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQzlELENBQUM7U0FDSDtLQUNGOzs7OztJQUVELE9BQU8sQ0FBQyxHQUFHO1FBQ1QsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQy9COzs7WUF2QkYsVUFBVTs7OztZQU0wQixNQUFNLHVCQUF0QyxNQUFNLFNBQUMsV0FBVztZQVRGLE1BQU07Ozs7Ozs7QUNBM0I7OzJCQVNnQixVQUFVLElBQUk7WUFDMUIsSUFBSSxPQUFPLElBQUksS0FBSyxRQUFRLEVBQUU7Z0JBQzVCLE9BQU8sRUFBRSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQzthQUNyQztZQUNELE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQztTQUN4Qjs7Ozs7OztJQVRELFNBQVMsQ0FBQyxRQUFRLEVBQUUsT0FBTztRQUN6QixPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsUUFBUSxDQUFDLE1BQU0sS0FBSyxPQUFPLEdBQUcsT0FBTyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7S0FDckU7OztZQUxGLFVBQVU7Ozs7Ozs7QUNGWCxBQUVBLHNCQUF1QixTQUFRLEtBQUs7Ozs7SUFDbEMsWUFBWSxRQUFRO1FBQ2xCLEtBQUssQ0FBQyxzQkFBc0IsUUFBUSxLQUFLLENBQUMsQ0FBQztLQUM1QztDQUNGO0FBR0Q7Ozs7OztJQUVFLHFCQUFxQixDQUFDLElBQUksRUFBRSxJQUFJO1FBQzlCLE9BQU8sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFNUMsSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFO1lBQUUsT0FBTyxJQUFJLENBQUM7U0FBRTtRQUNuQyxJQUFJLElBQUksS0FBSyxHQUFHLEVBQUU7WUFBRSxPQUFPLElBQUksR0FBRyxJQUFJLENBQUM7U0FBRTtRQUN6QyxJQUFJLElBQUksS0FBSyxLQUFLLEVBQUU7WUFBRSxPQUFPLElBQUksR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDO1NBQUU7UUFFaEQsT0FBTyxJQUFJLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7S0FDOUI7Ozs7O0lBRUQsT0FBTyxDQUFDLEtBQUs7O1FBQ1gsTUFBTSxJQUFJLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWxDLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFBRSxPQUFPLElBQUksQ0FBQztTQUFFO1FBRXhDLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNuRDs7Ozs7SUFFRCxhQUFhLENBQUMsUUFBUTtRQUVwQixJQUFJLFFBQVEsS0FBSyxTQUFTLElBQUksUUFBUSxLQUFLLElBQUksRUFBRTtZQUMvQyxNQUFNLElBQUksZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDdEM7UUFFRCxJQUFJLE9BQU8sUUFBUSxLQUFLLFFBQVEsRUFBRTtZQUNoQyxPQUFPLFFBQVEsQ0FBQztTQUNqQjtRQUVELElBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxFQUFFO1lBQ2hDLE1BQU0sSUFBSSxTQUFTLENBQUMsSUFBSSxRQUFRLG9DQUFvQyxDQUFDLENBQUM7U0FDdkU7O1FBRUQsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBRTVELElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDVixNQUFNLElBQUksZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDdEM7UUFFRCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDNUI7OztZQTFDRixVQUFVOzs7Ozs7O0FDUlg7Ozs7SUFPRSxZQUFvQixTQUEyQjtRQUEzQixjQUFTLEdBQVQsU0FBUyxDQUFrQjtLQUFLOzs7OztJQUU1QyxXQUFXLENBQUMsR0FBRzs7UUFDckIsTUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEtBQUssUUFBUSxDQUFDO1FBQ3BELE9BQU8sQ0FBQyxHQUFHLEdBQUcsUUFBUSxHQUFHLE9BQU8sSUFBSSxHQUFHLENBQUM7Ozs7OztJQUdsQyxZQUFZLENBQUMsR0FBRzs7UUFDdEIsTUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVoRCxNQUFNLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUNwQixNQUFNLENBQUMsSUFBSSxHQUFHLGlCQUFpQixDQUFDO1FBQ2hDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVuQyxPQUFPLE1BQU0sQ0FBQzs7Ozs7OztJQUdSLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRzs7UUFDL0IsTUFBTSxPQUFPLEdBQUcsSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTTtZQUMxQyxNQUFNLENBQUMsTUFBTSxHQUFHO2dCQUNkLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUNqQixDQUFDO1lBQ0YsTUFBTSxDQUFDLE9BQU8sR0FBRztnQkFDZixNQUFNLENBQUM7b0JBQ0wsSUFBSSxFQUFFLEdBQUc7b0JBQ1QsTUFBTSxFQUFFLEtBQUs7aUJBQ2QsQ0FBQyxDQUFDO2FBQ0osQ0FBQztTQUNILENBQUMsQ0FBQztRQUVILE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUTtZQUNwQixJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsR0FBRyxHQUFHLENBQUMsQ0FBQztTQUN0RSxDQUFDLENBQUM7UUFFSCxPQUFPLE9BQU8sQ0FBQzs7Ozs7O0lBR2pCLFlBQVksQ0FBQyxNQUFNOztRQUNqQixNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUMxQjs7Ozs7SUFFRCxjQUFjLENBQUMsR0FBRzs7UUFDaEIsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN0QyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7S0FDeEM7OztZQWpERixVQUFVOzs7O1lBRkYsZ0JBQWdCOzs7Ozs7O0FDQXpCLHdCQUFnQyxTQUFRLEtBQUs7Ozs7OztJQUN6QyxZQUFZLGFBQWEsRUFBRSxXQUFXLEVBQUUsV0FBWTtRQUNoRCxLQUFLLENBQUMsNkJBQTZCLGFBQWEsS0FBSztZQUNqRCxXQUFXLFdBQVcsR0FBRyxXQUFXLEdBQUcsaUJBQWlCLEdBQUc7WUFDM0QsSUFBSSxXQUFXLElBQUksQ0FBQyxDQUFDO0tBQzVCO0NBQ0o7Ozs7OztBQ1JEO0NBa0JDOzs7Ozs7Ozs7OztBQ2xCRDtBQVFBLE1BQWEsZUFBZSxHQUFHLDJDQUEyQyxDQUFDO0FBRTNFLDJCQUE0QixTQUFRLEtBQUs7Q0FBSTtBQUc3Qzs7Ozs7OztJQXdCRSxZQUMrQixVQUFrQixFQUNuQyxRQUFxQixFQUNMLE1BQWlCLEVBQ3JDO1FBSHFCLGVBQVUsR0FBVixVQUFVLENBQVE7UUFFbkIsV0FBTSxHQUFOLE1BQU0sQ0FBVztRQUNyQyxtQkFBYyxHQUFkLGNBQWM7OEJBMUJDLEtBQUs7K0JBRUosSUFBSTsrQkFFSixJQUFJO3lCQUVWLEtBQUs7d0JBRU4sSUFBSTtvQkFFUixJQUFJOytCQUVPLElBQUk7OEJBRUwsS0FBSzsrQkFFSixJQUFJO3VCQUVaLElBQUk7c0JBRUwsS0FBSztRQVFwQixJQUFJLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTs7WUFDdEMsTUFBTSxHQUFHLEdBQVEsTUFBTSxDQUNXOztZQURsQyxNQUNFLFNBQVMsR0FBRyxHQUFHLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQztZQUVsQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFFakIsU0FBUyxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQztZQUNwQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztnQkFDakIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ2QsQ0FBQyxDQUFDO1lBQ0gsR0FBRyxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7WUFFMUIsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFOztnQkFDaEIsTUFBTSxVQUFVLEdBQUc7b0JBQ2pCLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU07d0JBQzlELElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO3FCQUNwQixDQUFDLENBQUM7aUJBQ0osQ0FBQztnQkFDRixJQUFJLFFBQVEsRUFBRTtvQkFDWixRQUFRLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2lCQUM5QjtxQkFBTTtvQkFDTCxVQUFVLEVBQUUsQ0FBQztpQkFDZDthQUNGO1NBQ0Y7S0FDRjs7OztJQUVPLFNBQVM7UUFDZixLQUFLLE1BQU0sR0FBRyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDN0IsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUM1QixJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUM5QjtTQUNGOzs7Ozs7SUFHSyxrQkFBa0IsQ0FBQyxNQUFNO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQUUsT0FBTyxLQUFLLENBQUM7U0FBRTtRQUM1QyxJQUFJLE9BQU8sSUFBSSxDQUFDLGVBQWUsS0FBSyxRQUFRLEVBQUU7WUFDNUMsTUFBTSxJQUFJLHFCQUFxQixDQUFDLCtCQUErQixDQUFDLENBQUM7U0FDbEU7UUFDRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDOzs7Ozs7SUFHMUMsWUFBWSxDQUFDLE1BQU07UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFBRSxPQUFPLEtBQUssQ0FBQztTQUFFO1FBQzVDLElBQUksT0FBTyxJQUFJLENBQUMsZUFBZSxLQUFLLFFBQVEsRUFBRTtZQUM1QyxNQUFNLElBQUkscUJBQXFCLENBQUMsNkJBQTZCLENBQUMsQ0FBQztTQUNoRTtRQUVELEtBQUssTUFBTSxHQUFHLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUN0QyxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUM1QyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDckQ7U0FDRjs7Ozs7O0lBR0ssV0FBVyxDQUFDLE1BQU07UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFBRSxPQUFPLEtBQUssQ0FBQztTQUFFO1FBRXJDLElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFFBQVEsRUFBRTtZQUNyQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNsQyxPQUFPO1NBQ1I7UUFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDakMsTUFBTSxJQUFJLHFCQUFxQixDQUFDLHNCQUFzQjtnQkFDcEQsaUJBQWlCLENBQUMsQ0FBQztTQUN0QjtRQUVELE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Ozs7OztJQUcxQyxPQUFPLENBQUMsTUFBTTtRQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtZQUFFLE9BQU8sS0FBSyxDQUFDO1NBQUU7UUFDakMsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFO1lBQ2pDLE1BQU0sSUFBSSxxQkFBcUIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzFEO1FBRUQsTUFBTSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzs7Ozs7SUFHbkMsS0FBSzs7UUFDWCxNQUFNLEdBQUcsR0FBUSxNQUFNLENBRU87O1FBRjlCLE1BQ0UsU0FBUyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQ0c7O1FBRjlCLE1BRUUsTUFBTSxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUU5QixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDdkIsTUFBTSxDQUFDLGNBQWMsRUFBRSxDQUFDO1NBQ3pCOztRQUdELElBQUksSUFBSSxDQUFDLGVBQWUsS0FBSyxLQUFLLEVBQUU7WUFDbEMsTUFBTSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3hDO1FBRUQsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQ3hCLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1NBQzVCOztRQUdELE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBRTVCLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDOUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFcEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN6QixJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDOztRQUdoQyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUU5QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEtBQUssSUFBSSxFQUFFO1lBQzFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUU7Z0JBQzlCLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQzthQUN6QjtZQUNELFNBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztTQUM1Qjs7Ozs7SUFJSCxTQUFTO1FBQ1AsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO0tBQ3BCOzs7OztJQUVELFVBQVUsQ0FBQyxJQUFJO1FBQ2IsSUFBSSxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7O1lBQ3RDLE1BQU0sR0FBRyxHQUFRLE1BQU0sQ0FDSzs7WUFENUIsTUFDRSxTQUFTLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztZQUM1QixTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMxQjtLQUNGOzs7WUFuS0YsVUFBVTs7OztZQTBCa0MsTUFBTSx1QkFBOUMsTUFBTSxTQUFDLFdBQVc7WUFqQ2QsV0FBVyx1QkFrQ2YsUUFBUTtZQW5DSixTQUFTLHVCQW9DYixNQUFNLFNBQUMsVUFBVTtZQWxDYixxQkFBcUI7Ozs7Ozs7QUNOOUI7OzRCQUt5QixFQUFFOzs7Ozs7SUFFekIsVUFBVSxDQUFDLElBQUksR0FBRyxRQUFROztRQUN4QixJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFFZCxHQUFHOztZQUNELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakQsRUFBRSxHQUFHLElBQUksR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDO1NBQzFCLFFBQVEsRUFBRSxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7UUFFbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUM7UUFFN0IsT0FBTyxFQUFFLENBQUM7S0FDWDs7Ozs7SUFFRCxjQUFjLENBQUMsT0FBb0I7UUFDakMsSUFBSSxPQUFPLElBQUksT0FBTyxDQUFDLEVBQUUsSUFBSSxFQUFFLE9BQU8sQ0FBQyxFQUFFLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQy9ELE9BQU8sT0FBTyxDQUFDLEVBQUUsQ0FBQztTQUNuQjs7UUFFRCxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUMxRCxJQUFJLE9BQU8sRUFBRTtZQUFFLE9BQU8sQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO1NBQUU7UUFFakMsT0FBTyxFQUFFLENBQUM7S0FDWDs7Ozs7SUFFRCxPQUFPLENBQUMsRUFBRTtRQUNSLE9BQU8sRUFBRSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUM7S0FDaEM7Ozs7O0lBRUQsUUFBUSxDQUFDLEVBQUU7UUFDVCxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMxQjs7O1lBbkNGLFVBQVU7Ozs7Ozs7QUNGWCxBQVNBLHFCQUFzQixTQUFRLEtBQUs7Q0FBSTtBQUt2Qzs7Ozs7O0lBT0UsWUFFVSxNQUFpQixFQUNqQixRQUNBO1FBRkEsV0FBTSxHQUFOLE1BQU0sQ0FBVztRQUNqQixXQUFNLEdBQU4sTUFBTTtRQUNOLGtCQUFhLEdBQWIsYUFBYTs0QkFUVyxJQUFJLFlBQVksRUFBRTs0QkFDN0IsRUFBRTt5QkFFTCxFQUFFO0tBT2pCOzs7Ozs7O0lBRUwsV0FBVyxDQUFDLElBQUksRUFBRSxlQUFnQixFQUFFLFdBQVcsR0FBRyxLQUFLOztRQUNyRCxNQUFNLFFBQVEsR0FBaUIsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FDWDs7UUFENUMsTUFDRSxJQUFJLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsQ0FBQztRQUU1QyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBQ1osSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUM5QixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzNCO1lBQ0QsSUFBSSxlQUFlLEVBQUU7Z0JBQ25CLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLGVBQWUsQ0FBQyxDQUFDO2FBQzdDO1NBQ0YsQ0FBQyxDQUFDO1FBRUgsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixLQUFLLElBQUksSUFBSSxXQUFXLEVBQUU7O1lBRXpELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdCLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFO2dCQUNwRCxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ2xDO1lBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDOztnQkFDeEMsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNsQyxNQUFNLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztnQkFDN0IsU0FBUyxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUMzQixJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUN6QixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLENBQUM7aUJBQ3pDLENBQUMsQ0FBQztnQkFDSCxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDbEMsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7YUFDeEIsQ0FBQyxDQUFDO1NBQ0o7YUFBTTtZQUNMLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN0QjtRQUVELE9BQU8sUUFBUSxDQUFDO0tBQ2pCOzs7OztJQUVELGNBQWMsQ0FBQyxJQUFJO1FBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQy9CLE1BQU0sSUFBSSxlQUFlLENBQUMsNEJBQTRCLENBQUMsQ0FBQztTQUN6RDs7UUFFRCxNQUFNLFFBQVEsR0FBaUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDMUUsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUU1QixPQUFPLElBQUksQ0FBQztLQUNiOzs7OztJQUVPLGVBQWUsQ0FBQyxJQUFJO1FBQzFCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDOzs7Ozs7SUFHOUMsT0FBTyxDQUFDLEtBQU07UUFDcEIsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQ3ZCLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO2dCQUNqQixTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDOUIsQ0FBQyxDQUFDO1lBQ0gsT0FBTztTQUNSO1FBRUQsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUFFLE9BQU8sS0FBSyxDQUFDO1NBQUU7UUFFekMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDakIsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUN6RCxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUk7Z0JBQ2hCLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzVCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQzs7Ozs7OztJQUdHLGVBQWUsQ0FBQyxJQUFJLEVBQUUsUUFBUTs7UUFDcEMsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDbEUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQzs7UUFFaEQsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLGNBQWMsRUFBRSxjQUFjLENBQUMsQ0FBQyxTQUFTLENBQUM7O1lBQzlELE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsRUFBRTtnQkFDdkUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNuQztTQUNGLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUM7UUFFMUQsT0FBTyxPQUFPLENBQUM7Ozs7OztJQUdULGVBQWUsQ0FBQyxJQUFJO1FBQzFCLE9BQU8sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDOzs7Ozs7O0lBRzdCLGdCQUFnQixDQUFDLFlBQVksRUFBRSxhQUFhO1FBQ2xELElBQUksWUFBWSxHQUFHLElBQUksRUFBRTtZQUN2QixPQUFPLENBQUMsSUFBSSxDQUFDLG9EQUFvRCxDQUFDLENBQUM7U0FDcEU7Ozs7OztJQUdILFdBQVcsQ0FBQyxPQUFnQjtRQUMxQixJQUFJLFFBQVEsTUFBTSxDQUFDLEtBQUssV0FBVyxFQUFFOztZQUNuQyxNQUFNLEdBQUcsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0MsSUFBSSxHQUFHLENBQUMsT0FBTyxLQUFLLE1BQU0sRUFBRTtnQkFDMUIsT0FBTyxJQUFJLENBQUM7YUFDYjtpQkFBTSxJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUU7Z0JBQ2hDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDaEQ7U0FDRjtRQUNELE9BQU8sS0FBSyxDQUFDO0tBQ2Q7OztZQTNIRixVQUFVOzs7O1lBUkYsU0FBUyx1QkFpQmIsUUFBUSxZQUFJLE1BQU0sU0FBQyxVQUFVO1lBdEJXLFFBQVE7WUFPNUMsb0JBQW9COzs7Ozs7Ozs7Ozs7QUNQN0I7Ozs7Ozs7Ozs7SUFzREUsWUFDK0IsVUFBa0IsRUFDdkMsWUFDQSxLQUNBLGdCQUNBLFlBQ29CLE1BQWlCLEVBQ2pDLE1BQWM7UUFORyxlQUFVLEdBQVYsVUFBVSxDQUFRO1FBQ3ZDLGVBQVUsR0FBVixVQUFVO1FBQ1YsUUFBRyxHQUFILEdBQUc7UUFDSCxtQkFBYyxHQUFkLGNBQWM7UUFDZCxlQUFVLEdBQVYsVUFBVTtRQUNVLFdBQU0sR0FBTixNQUFNLENBQVc7NEJBdEJTLElBQUksWUFBWSxFQUFFO3FCQUUxRCxFQUFFO2lDQUVVLEVBQUU7MEJBRVQsRUFBRTswQkFFRixFQUFFO3VCQUVMLEVBQUU7UUFlbEIsSUFBSSxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ3pDLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUU7b0JBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztpQkFDekQ7YUFDRixDQUFDLENBQUM7WUFDSCxJQUFJLE1BQU0sRUFBRTtnQkFDVixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxLQUFLLFlBQVksYUFBYSxDQUFDLENBQUM7cUJBQ3hGLFNBQVMsQ0FBQyxDQUFDLEtBQW9CO29CQUM5QixJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEtBQUssU0FBUyxFQUFFO3dCQUM1RSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDaEM7aUJBQ0YsQ0FBQyxDQUFDO2FBQ047U0FDRjtLQUNGOzs7O0lBRUQsUUFBUTtRQUNOLElBQUksaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDbkU7S0FDRjs7OztJQUVELGVBQWU7UUFDYixJQUFJLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUN0QyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztnQkFDbEIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2FBQ25CLENBQUMsQ0FBQztTQUNKO0tBQ0Y7Ozs7SUFFRCxXQUFXO1FBQ1QsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFO1lBQ2IsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ3JDO1FBQ0QsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDekIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3JDO0tBQ0Y7Ozs7O0lBRU8sb0JBQW9CLENBQUMsSUFBSTs7UUFDL0IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRTNCLElBQUksRUFBRSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDckMsT0FBTztTQUNSOztRQUVELE1BQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUU1QyxFQUFFLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLE9BQU87WUFDbEMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUM1RCxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7Ozs7O0lBR3RDLFVBQVU7O1FBQ2hCLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FDZ0I7O1FBRDFDLE1BQ0UsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1FBRTFDLElBQUksQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRWxFLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxTQUFTLElBQUksRUFBRSxDQUFDLGNBQWMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFO1lBQzFGLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1NBQ2hEO1FBRUQsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO1lBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3BDO1FBRUQsSUFBSSxFQUFFLENBQUMsZUFBZSxFQUFFO1lBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzNDO1FBRUQsSUFBSSxFQUFFLENBQUMsZUFBZSxFQUFFO1lBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQ3pCLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLGVBQWUsQ0FBQyxFQUNoQyxDQUFDO1NBQ0g7UUFFRCxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxLQUFLO1lBQzNELElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUM1QixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7YUFDL0U7U0FDRixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXJDLEVBQUUsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVM7WUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDekQsQ0FBQyxDQUFDO1FBRUgsRUFBRSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUztZQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQzNDLENBQUMsQ0FBQztRQUVILEVBQUUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sTUFBTSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXJELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUU7WUFDOUIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUM7U0FDaEQ7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUV6QyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7Ozs7O0lBR2hCLGNBQWM7UUFDcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJO1lBQ2xFLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztTQUN0RCxDQUFDLENBQUM7Ozs7O0lBR0wsVUFBVTtRQUNSLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzNCLE1BQU0sSUFBSSxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDcEQ7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixNQUFNLElBQUksa0JBQWtCLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUN6RDtLQUNGOzs7O0lBRUQsSUFBSSxRQUFRO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0tBQ25FOzs7O0lBRUQsUUFBUTtRQUNOLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUM7WUFDbkIsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ2pCLGlCQUFpQixFQUFFLElBQUksQ0FBQyxpQkFBaUI7WUFDekMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQzNCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtZQUMzQixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsY0FBYyxFQUFFLElBQUksQ0FBQyxjQUFjLEtBQUssSUFBSTtZQUM1QyxlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWU7WUFDckMsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO1lBQ3ZCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztZQUNyQixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87WUFDckIsZUFBZSxFQUFFLElBQUksQ0FBQyxlQUFlLEtBQUssSUFBSTtTQUMvQyxDQUFDLENBQUM7S0FDSjs7Ozs7SUFFRCxPQUFPLENBQUMsSUFBSTtRQUNWLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3ZCOzs7OztJQUVELG9CQUFvQixDQUFDLE9BQU87UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUN0Qzs7Ozs7SUFFRCxZQUFZLENBQUMsU0FBUztRQUNwQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUNqQzs7Ozs7SUFFRCxZQUFZLENBQUMsU0FBUztRQUNwQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUNqQzs7Ozs7SUFFRCxTQUFTLENBQUMsTUFBTTtRQUNkLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0tBQzNCOzs7WUF0TUYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxRQUFRO2FBQ25COzs7O1lBMkI0QyxNQUFNLHVCQUE5QyxNQUFNLFNBQUMsV0FBVztZQXREVixVQUFVO1lBVWQsVUFBVTtZQUNWLHFCQUFxQjtZQUNyQixpQkFBaUI7WUFFZSxTQUFTLHVCQTZDN0MsTUFBTSxTQUFDLFVBQVU7WUF0RGIsTUFBTSx1QkF1RFYsUUFBUTs7O3FCQTlCVixLQUFLO3VCQUNMLEtBQUs7NkJBQ0wsS0FBSzs4QkFDTCxLQUFLO3NCQUNMLEtBQUs7OEJBQ0wsS0FBSzsyQkFFTCxNQUFNOzs7Ozs7O0FDdENUOzs7Ozs7SUFrQkksWUFDWSxZQUVBLEVBQWtCLEVBQ2xCO1FBSEEsZUFBVSxHQUFWLFVBQVU7UUFFVixPQUFFLEdBQUYsRUFBRSxDQUFnQjtRQUNsQixlQUFVLEdBQVYsVUFBVTtRQUVsQixJQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsS0FBSztZQUNoQyxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7U0FDMUIsQ0FBQyxDQUFDO0tBQ047Ozs7SUFHRCxlQUFlO1FBQ1gsSUFBSSxJQUFJLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRTtZQUNsQixPQUFPLEtBQUssQ0FBQztTQUNoQjtRQUNELElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDOUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFBRSxPQUFPLEtBQUssQ0FBQztTQUFFO1FBRW5DLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDOztRQUUxRCxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDOztRQUVuQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUNoQjs7UUFEZCxJQUNJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFFZCxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3BCLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsRUFBRTtnQkFDcEIsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3BDO1NBQ0osQ0FBQyxDQUFDO1FBRUgsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksS0FBSyxLQUFLLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDdEQsS0FBSyxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDM0IsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDekIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLEtBQUssR0FBRyxFQUFFLENBQUMsQ0FBQztZQUM5QyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSTtnQkFDM0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDMUQsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7YUFDbEMsQ0FBQyxDQUFDO1NBQ047S0FDSjs7OztJQUVELFNBQVM7O1FBQ0wsTUFBTSxFQUFFLEdBQVksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQ1Q7O1FBRHhDLE1BQ0ksTUFBTSxHQUFHLEVBQUUsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDeEMsSUFBSSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTtZQUM3QixPQUFPLE1BQU0sQ0FBQztTQUNqQjtLQUNKOzs7WUExREosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxvQkFBb0I7YUFDakM7Ozs7WUFWYyxVQUFVO1lBS2hCLGNBQWMsdUJBY2QsTUFBTSxTQUFDLFVBQVUsQ0FBQyxNQUFNLGNBQWMsQ0FBQztZQWJ2QyxpQkFBaUI7Ozs4QkFzQnJCLFlBQVksU0FBQyxlQUFlOzs7Ozs7O0FDN0JqQzs7OztJQVlFLFlBRVUsRUFBa0I7UUFBbEIsT0FBRSxHQUFGLEVBQUUsQ0FBZ0I7d0JBTFIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO3VCQUNQLEVBQUU7S0FLaEI7Ozs7SUFFTCxRQUFRO1FBQ04sSUFBSSxDQUFDLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztLQUMvQzs7Ozs7SUFFRCxJQUNJLFNBQVMsQ0FBQyxHQUFXO1FBQ3ZCLElBQUksR0FBRyxHQUFHLENBQUMsRUFBRTtZQUNYLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1NBQ3hCO0tBQ0Y7Ozs7O0lBRUQsSUFDSSxVQUFVLENBQUMsR0FBVztRQUN4QixJQUFJLEdBQUcsR0FBRyxDQUFDLEVBQUU7WUFDWCxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUN4QjtLQUNGOzs7OztJQUVELE9BQU8sQ0FBQyxJQUFJO1FBQ1YsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDekI7Ozs7SUFFRCxRQUFRO1FBQ04sT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDO1lBQ25CLFlBQVksRUFBRSxJQUFJLENBQUMsUUFBUTtZQUMzQixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87U0FDdEIsQ0FBQyxDQUFDO0tBQ0o7OztZQXhDRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLGdCQUFnQjthQUMzQjs7OztZQUpRLGNBQWMsdUJBV2xCLE1BQU0sU0FBQyxVQUFVLENBQUMsTUFBTSxjQUFjLENBQUM7Ozt1QkFKekMsS0FBSztzQkFDTCxLQUFLO3dCQVdMLEtBQUs7eUJBT0wsS0FBSzs7Ozs7OztBQzVCUjs7Ozs7O0lBYUUsWUFDVSxZQUVBLEVBQWtCLEVBRWxCLElBQTRCO1FBSjVCLGVBQVUsR0FBVixVQUFVO1FBRVYsT0FBRSxHQUFGLEVBQUUsQ0FBZ0I7UUFFbEIsU0FBSSxHQUFKLElBQUksQ0FBd0I7S0FDakM7Ozs7SUFFTCxRQUFROztRQUNOLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLEVBQUUsQ0FDMkI7O1FBRDlELE1BQ0UsU0FBUyxHQUFXLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQztRQUU5RCxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUM3QixNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztTQUMzQzthQUFNLElBQUksU0FBUyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUNsQyxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQzNCO0tBQ0Y7OztZQXpCRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLFVBQVU7YUFDckI7Ozs7WUFQbUIsVUFBVTtZQUVyQixjQUFjLHVCQWFsQixNQUFNLFNBQUMsVUFBVSxDQUFDLE1BQU0sY0FBYyxDQUFDO1lBWm5DLHNCQUFzQix1QkFjMUIsUUFBUSxZQUFJLE1BQU0sU0FBQyxVQUFVLENBQUMsTUFBTSxzQkFBc0IsQ0FBQzs7O29CQVA3RCxLQUFLO3FCQUNMLEtBQUs7Ozs7Ozs7QUNYUjs7OztJQXVCRSxZQUVVLEVBQWtCO1FBQWxCLE9BQUUsR0FBRixFQUFFLENBQWdCO3NCQUpYLEVBQUU7S0FLZDs7Ozs7SUFkTCxJQUNJLEtBQUssQ0FBQyxHQUEyQjtRQUNuQyxJQUFJLEdBQUcsWUFBWSxLQUFLLEVBQUU7WUFDeEIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3BDO2FBQU07WUFDTCxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3BCO0tBQ0Y7Ozs7SUFTRCxrQkFBa0I7O1FBQ2hCLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNsQyxJQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUNqQzs7OztJQUVELFVBQVU7UUFDUixJQUFJLElBQUksQ0FBQyxHQUFHLEtBQUssU0FBUyxFQUFFO1lBQzFCLE1BQU0sSUFBSSxrQkFBa0IsQ0FBQyxlQUFlLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzVEO1FBQ0QsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDNUIsTUFBTSxJQUFJLGtCQUFrQixDQUFDLGVBQWUsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDOUQ7S0FDRjs7OztJQUVELFFBQVE7UUFDTixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDO1lBQ25CLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRztZQUNiLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtTQUNwQixDQUFDLENBQUM7S0FDSjs7Ozs7SUFFRCxRQUFRLENBQUMsS0FBSztRQUNaLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksS0FBSyxLQUFLLENBQUMsRUFBRTtZQUN0RCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUN6QjtLQUNGOzs7WUFqREYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxlQUFlO2FBQzFCOzs7O1lBSlEsY0FBYyx1QkFxQmxCLE1BQU0sU0FBQyxVQUFVLENBQUMsTUFBTSxjQUFjLENBQUM7OztrQkFkekMsS0FBSztvQkFFTCxLQUFLOzs7Ozs7O0FDWlI7Ozs7O0lBYUUsWUFDVSxZQUVBLEVBQWtCO1FBRmxCLGVBQVUsR0FBVixVQUFVO1FBRVYsT0FBRSxHQUFGLEVBQUUsQ0FBZ0I7S0FDeEI7Ozs7SUFFSixRQUFRO1FBQ04sSUFBSSxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7S0FDL0Q7OztZQWJGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsZUFBZTthQUMxQjs7OztZQVRZLFVBQVU7WUFLZCxjQUFjLHVCQVNsQixNQUFNLFNBQUMsVUFBVSxDQUFDLE1BQU0sY0FBYyxDQUFDOzs7Ozs7O0FDZjVDOzs7OztJQWFFLFlBQ1UsWUFFQSxTQUFnQztRQUZoQyxlQUFVLEdBQVYsVUFBVTtRQUVWLGNBQVMsR0FBVCxTQUFTLENBQXVCO0tBQ3JDOzs7O0lBRUwsUUFBUTtRQUNOLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0tBQ2xFOzs7WUFiRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLFdBQVc7YUFDdEI7Ozs7WUFUWSxVQUFVO1lBS2QscUJBQXFCLHVCQVN6QixNQUFNLFNBQUMsVUFBVSxDQUFDLE1BQU0scUJBQXFCLENBQUM7Ozs7Ozs7QUNmbkQ7Ozs7O0lBa0JFLFlBQytCLFVBQWtCLEVBQ3ZDO1FBRHFCLGVBQVUsR0FBVixVQUFVLENBQVE7UUFDdkMsZUFBVSxHQUFWLFVBQVU7S0FDZjs7OztJQUVMLFFBQVE7UUFDTixJQUFJLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTs7WUFDdEMsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUNPOztZQURqQyxNQUNFLE1BQU0sR0FBRyxJQUFJLEdBQUcsY0FBYyxDQUFDOztZQUVqQyxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7WUFDaEIsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNmLE1BQU0sR0FBRyxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUNqQzs7WUFFRCxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7WUFDZCxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUU7Z0JBQ2IsSUFBSSxHQUFHLFFBQVEsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQzVCOztZQUVELE1BQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFNUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxnREFBZ0QsQ0FBQztZQUM3RCxLQUFLLENBQUMsR0FBRyxJQUFJLEdBQUcsTUFBTSxXQUFXLElBQUksQ0FBQyxTQUFTLElBQUksTUFBTSxHQUFHLElBQUksRUFBRSxDQUFDO1lBRW5FLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1lBQ2hCLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBQ2pCLEtBQUssQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO1lBRW5CLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQztZQUVsQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDN0M7S0FDRjs7O1lBMUNGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsb0JBQW9CO2FBQy9COzs7O1lBUTRDLE1BQU0sdUJBQTlDLE1BQU0sU0FBQyxXQUFXO1lBbEJWLFVBQVU7OztxQkFhcEIsS0FBSzt3QkFDTCxLQUFLO21CQUNMLEtBQUs7Ozs7Ozs7Ozs7OztBQ2hCUjtBQXVCQSxNQUFNLFVBQVUsR0FBRztJQUNqQixjQUFjO0lBQ2QsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0Qix3QkFBd0I7SUFDeEIscUJBQXFCLEVBQUUscUJBQXFCLEVBQUUsaUJBQWlCO0lBQy9ELHlCQUF5QjtDQUMxQixDQUFDOztBQUVGLE1BQU0sUUFBUSxHQUFHO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixxQkFBcUI7SUFDckIsVUFBVSxFQUFFLHFCQUFxQixFQUFFLGlCQUFpQjtDQUNyRCxDQUFDO0FBZ0JGOzs7OztJQUNFLE9BQU8sT0FBTyxDQUFDLE1BQWtCO1FBQy9CLE9BQU87WUFDTCxRQUFRLEVBQUUsU0FBUztZQUNuQixTQUFTLEVBQUU7Z0JBQ1QsSUFBSSxNQUFNLElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxJQUFJLEdBQUcsQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQzVELEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsTUFBTSxJQUFJLEVBQUUsRUFBRTthQUNoRDtTQUNGLENBQUM7S0FDSDs7O1lBdkJGLFFBQVEsU0FBQztnQkFDUixPQUFPLEVBQUUsRUFFUjtnQkFDRCxZQUFZLEVBQUU7b0JBQ1osR0FBRyxVQUFVO2lCQUNkO2dCQUNELFNBQVMsRUFBRTtvQkFDVCxHQUFHLFFBQVE7aUJBQ1o7Z0JBQ0QsT0FBTyxFQUFFO29CQUNQLEdBQUcsVUFBVTtpQkFDZDthQUNGOzs7Ozs7Ozs7Ozs7Ozs7In0=

/***/ }),

/***/ "./node_modules/ngx-popper/fesm2015/ngx-popper.js":
/*!********************************************************!*\
  !*** ./node_modules/ngx-popper/fesm2015/ngx-popper.js ***!
  \********************************************************/
/*! exports provided: Triggers, Placements, PopperController, PopperContent, NgxPopperModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Triggers", function() { return Triggers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Placements", function() { return Placements; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopperController", function() { return PopperController; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopperContent", function() { return PopperContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxPopperModule", function() { return NgxPopperModule; });
/* harmony import */ var popper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! popper.js */ "./node_modules/popper.js/dist/esm/popper.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");




/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class Triggers {
}
Triggers.CLICK = 'click';
Triggers.HOVER = 'hover';
Triggers.MOUSEDOWN = 'mousedown';
Triggers.NONE = 'none';
class Placements {
}
Placements.Top = 'top';
Placements.Bottom = 'bottom';
Placements.Left = 'left';
Placements.Right = 'right';
Placements.TopStart = 'top-start';
Placements.BottomStart = 'bottom-start';
Placements.LeftStart = 'left-start';
Placements.RightStart = 'right-start';
Placements.TopEnd = 'top-end';
Placements.BottomEnd = 'bottom-end';
Placements.LeftEnd = 'left-end';
Placements.RightEnd = 'right-end';
Placements.Auto = 'auto';
Placements.AutoStart = 'auto-start';
Placements.AutoEnd = 'auto-end';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PopperContent {
    /**
     * @param {?} elemRef
     * @param {?} renderer
     * @param {?} viewRef
     * @param {?} CDR
     */
    constructor(elemRef, renderer, viewRef, CDR) {
        this.elemRef = elemRef;
        this.renderer = renderer;
        this.viewRef = viewRef;
        this.CDR = CDR;
        this.popperOptions = (/** @type {?} */ ({
            disableAnimation: false,
            disableDefaultStyling: false,
            placement: Placements.Auto,
            boundariesElement: '',
            trigger: Triggers.HOVER,
            positionFixed: false,
            appendToBody: false,
            popperModifiers: {}
        }));
        this.isMouseOver = false;
        this.onHidden = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.displayType = "none";
        this.opacity = 0;
        this.ariaHidden = 'true';
        this.arrowColor = null;
        this.state = true;
    }
    /**
     * @return {?}
     */
    onMouseOver() {
        this.isMouseOver = true;
    }
    /**
     * @return {?}
     */
    showOnLeave() {
        this.isMouseOver = false;
        if (this.popperOptions.trigger !== Triggers.HOVER && !this.popperOptions.hideOnMouseLeave) {
            return;
        }
        this.hide();
    }
    /**
     * @return {?}
     */
    onDocumentResize() {
        this.update();
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.clean();
        if (this.popperOptions.appendTo && this.elemRef && this.elemRef.nativeElement && this.elemRef.nativeElement.parentNode) {
            this.viewRef.detach();
            this.elemRef.nativeElement.parentNode.removeChild(this.elemRef.nativeElement);
        }
    }
    /**
     * @return {?}
     */
    clean() {
        this.toggleVisibility(false);
        if (!this.popperInstance) {
            return;
        }
        ((/** @type {?} */ (this.popperInstance))).disableEventListeners();
        this.popperInstance.destroy();
    }
    /**
     * @return {?}
     */
    show() {
        if (!this.referenceObject) {
            return;
        }
        /** @type {?} */
        const appendToParent = this.popperOptions.appendTo && document.querySelector(this.popperOptions.appendTo);
        if (appendToParent && this.elemRef.nativeElement.parentNode !== appendToParent) {
            this.elemRef.nativeElement.parentNode && this.elemRef.nativeElement.parentNode.removeChild(this.elemRef.nativeElement);
            appendToParent.appendChild(this.elemRef.nativeElement);
        }
        /** @type {?} */
        let popperOptions = (/** @type {?} */ ({
            placement: this.popperOptions.placement,
            positionFixed: this.popperOptions.positionFixed,
            modifiers: {
                arrow: {
                    element: this.popperViewRef.nativeElement.querySelector('.ngxp__arrow')
                }
            }
        }));
        if (this.onUpdate) {
            popperOptions.onUpdate = (/** @type {?} */ (this.onUpdate));
        }
        /** @type {?} */
        let boundariesElement = this.popperOptions.boundariesElement && document.querySelector(this.popperOptions.boundariesElement);
        if (popperOptions.modifiers && boundariesElement) {
            popperOptions.modifiers.preventOverflow = { boundariesElement };
        }
        if (popperOptions.modifiers && this.popperOptions.preventOverflow !== undefined) {
            popperOptions.modifiers.preventOverflow = popperOptions.modifiers.preventOverflow || {};
            popperOptions.modifiers.preventOverflow.enabled = this.popperOptions.preventOverflow;
            if (!popperOptions.modifiers.preventOverflow.enabled) {
                popperOptions.modifiers.hide = { enabled: false };
            }
        }
        this.determineArrowColor();
        popperOptions.modifiers = Object.assign(popperOptions.modifiers, this.popperOptions.popperModifiers);
        this.popperInstance = new popper_js__WEBPACK_IMPORTED_MODULE_0__["default"](this.referenceObject, this.popperViewRef.nativeElement, popperOptions);
        ((/** @type {?} */ (this.popperInstance))).enableEventListeners();
        this.scheduleUpdate();
        this.toggleVisibility(true);
        this.globalResize = this.renderer.listen('document', 'resize', this.onDocumentResize.bind(this));
    }
    /**
     * @private
     * @return {?}
     */
    determineArrowColor() {
        ['background-color', 'backgroundColor'].some((clr) => {
            if (!this.popperOptions.styles) {
                return false;
            }
            if (this.popperOptions.styles.hasOwnProperty(clr)) {
                this.arrowColor = this.popperOptions.styles[clr];
                return true;
            }
            return false;
        });
    }
    /**
     * @return {?}
     */
    update() {
        this.popperInstance && ((/** @type {?} */ (this.popperInstance))).update();
    }
    /**
     * @return {?}
     */
    scheduleUpdate() {
        this.popperInstance && ((/** @type {?} */ (this.popperInstance))).scheduleUpdate();
    }
    /**
     * @return {?}
     */
    hide() {
        if (this.popperInstance) {
            this.popperInstance.destroy();
        }
        this.toggleVisibility(false);
        this.onHidden.emit();
    }
    /**
     * @param {?} state
     * @return {?}
     */
    toggleVisibility(state) {
        if (!state) {
            this.opacity = 0;
            this.displayType = "none";
            this.ariaHidden = 'true';
        }
        else {
            this.opacity = 1;
            this.displayType = "block";
            this.ariaHidden = 'false';
        }
        if (!this.CDR['destroyed']) {
            this.CDR.detectChanges();
        }
    }
    /**
     * @param {?=} classList
     * @return {?}
     */
    extractAppliedClassListExpr(classList) {
        if (!classList || typeof classList !== 'string') {
            return null;
        }
        try {
            return classList
                .replace(/ /, '')
                .split(',')
                .reduce((acc, clss) => {
                acc[clss] = true;
                return acc;
            }, {});
        }
        catch (e) {
            return null;
        }
    }
    /**
     * @private
     * @return {?}
     */
    clearGlobalResize() {
        this.globalResize && typeof this.globalResize === 'function' && this.globalResize();
    }
}
PopperContent.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"], args: [{
                selector: "popper-content",
                encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewEncapsulation"].None,
                changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ChangeDetectionStrategy"].OnPush,
                template: `
    <div #popperViewRef
         [class.ngxp__container]="!popperOptions.disableDefaultStyling"
         [class.ngxp__animation]="!popperOptions.disableAnimation"
         [style.display]="displayType"
         [style.opacity]="opacity"
         [ngStyle]="popperOptions.styles"
         [ngClass]="extractAppliedClassListExpr(popperOptions.applyClass)"
         attr.aria-hidden="{{ariaHidden}}"
         [attr.aria-describedby]="popperOptions.ariaDescribe || null"
         attr.role="{{popperOptions.ariaRole}}">
      <div class="ngxp__inner" *ngIf="text" [innerHTML]="text">
        <ng-content></ng-content>
      </div>
      <div class="ngxp__inner" *ngIf="!text">
        <ng-content></ng-content>
      </div>
      <div class="ngxp__arrow" [style.border-color]="arrowColor" [class.__force-arrow]="arrowColor"
           [ngClass]="extractAppliedClassListExpr(popperOptions.applyArrowClass)"></div>

    </div>
  `,
                styles: [".ngxp__container{display:none;position:absolute;border-radius:3px;border:1px solid grey;box-shadow:0 0 2px rgba(0,0,0,.5);padding:10px}.ngxp__container.ngxp__animation{-webkit-animation:150ms ease-out ngxp-fadeIn;animation:150ms ease-out ngxp-fadeIn}.ngxp__container>.ngxp__arrow{border-color:grey;width:0;height:0;border-style:solid;position:absolute;margin:5px}.ngxp__container[x-placement^=bottom],.ngxp__container[x-placement^=left],.ngxp__container[x-placement^=right],.ngxp__container[x-placement^=top]{display:block}.ngxp__container[x-placement^=top]{margin-bottom:5px}.ngxp__container[x-placement^=top]>.ngxp__arrow{border-width:5px 5px 0;border-right-color:transparent;border-bottom-color:transparent;border-left-color:transparent;bottom:-5px;left:calc(50% - 5px);margin-top:0;margin-bottom:0}.ngxp__container[x-placement^=top]>.ngxp__arrow.__force-arrow{border-right-color:transparent!important;border-bottom-color:transparent!important;border-left-color:transparent!important}.ngxp__container[x-placement^=bottom]{margin-top:5px}.ngxp__container[x-placement^=bottom]>.ngxp__arrow{border-width:0 5px 5px;border-top-color:transparent;border-right-color:transparent;border-left-color:transparent;top:-5px;left:calc(50% - 5px);margin-top:0;margin-bottom:0}.ngxp__container[x-placement^=bottom]>.ngxp__arrow.__force-arrow{border-top-color:transparent!important;border-right-color:transparent!important;border-left-color:transparent!important}.ngxp__container[x-placement^=right]{margin-left:5px}.ngxp__container[x-placement^=right]>.ngxp__arrow{border-width:5px 5px 5px 0;border-top-color:transparent;border-bottom-color:transparent;border-left-color:transparent;left:-5px;top:calc(50% - 5px);margin-left:0;margin-right:0}.ngxp__container[x-placement^=right]>.ngxp__arrow.__force-arrow{border-top-color:transparent!important;border-bottom-color:transparent!important;border-left-color:transparent!important}.ngxp__container[x-placement^=left]{margin-right:5px}.ngxp__container[x-placement^=left]>.ngxp__arrow{border-width:5px 0 5px 5px;border-top-color:transparent;border-bottom-color:transparent;border-right-color:transparent;right:-5px;top:calc(50% - 5px);margin-left:0;margin-right:0}.ngxp__container[x-placement^=left]>.ngxp__arrow.__force-arrow{border-top-color:transparent!important;border-bottom-color:transparent!important;border-right-color:transparent!important}@-webkit-keyframes ngxp-fadeIn{0%{display:none;opacity:0}1%{display:block;opacity:0}100%{display:block;opacity:1}}@keyframes ngxp-fadeIn{0%{display:none;opacity:0}1%{display:block;opacity:0}100%{display:block;opacity:1}}"]
            }] }
];
/** @nocollapse */
PopperContent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Renderer2"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewContainerRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ChangeDetectorRef"] }
];
PopperContent.propDecorators = {
    popperViewRef: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"], args: ["popperViewRef",] }],
    onMouseOver: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["HostListener"], args: ['mouseover',] }],
    showOnLeave: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["HostListener"], args: ['mouseleave',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PopperController {
    /**
     * @param {?} viewContainerRef
     * @param {?} changeDetectorRef
     * @param {?} resolver
     * @param {?} elementRef
     * @param {?} renderer
     * @param {?=} popperDefaults
     */
    constructor(viewContainerRef, changeDetectorRef, resolver, elementRef, renderer, popperDefaults = {}) {
        this.viewContainerRef = viewContainerRef;
        this.changeDetectorRef = changeDetectorRef;
        this.resolver = resolver;
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.popperDefaults = popperDefaults;
        this.popperContentClass = PopperContent;
        this.shown = false;
        this.subscriptions = [];
        this.eventListeners = [];
        this.globalEventListeners = [];
        this.hideTimeout = 0;
        this.timeoutAfterShow = 0;
        this.popperOnShown = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.popperOnHidden = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.popperOnUpdate = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        PopperController.baseOptions = Object.assign({}, PopperController.baseOptions, this.popperDefaults);
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    hideOnClickOutsideHandler($event) {
        if (this.disabled || !this.hideOnClickOutside || $event.srcElement &&
            $event.srcElement === this.popperContent.elemRef.nativeElement ||
            this.popperContent.elemRef.nativeElement.contains($event.srcElement)) {
            return;
        }
        this.scheduledHide($event, this.hideTimeout);
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    hideOnScrollHandler($event) {
        if (this.disabled || !this.hideOnScroll) {
            return;
        }
        this.scheduledHide($event, this.hideTimeout);
    }
    /**
     * @return {?}
     */
    applyTriggerListeners() {
        switch (this.showTrigger) {
            case Triggers.CLICK:
                this.eventListeners.push(this.renderer.listen(this.elementRef.nativeElement, 'click', this.toggle.bind(this)));
                break;
            case Triggers.MOUSEDOWN:
                this.eventListeners.push(this.renderer.listen(this.elementRef.nativeElement, 'mousedown', this.toggle.bind(this)));
                break;
            case Triggers.HOVER:
                this.eventListeners.push(this.renderer.listen(this.elementRef.nativeElement, 'mouseenter', this.scheduledShow.bind(this, this.showDelay)));
                this.eventListeners.push(this.renderer.listen(this.elementRef.nativeElement, 'touchend', this.scheduledHide.bind(this, null, this.hideTimeout)));
                this.eventListeners.push(this.renderer.listen(this.elementRef.nativeElement, 'touchcancel', this.scheduledHide.bind(this, null, this.hideTimeout)));
                this.eventListeners.push(this.renderer.listen(this.elementRef.nativeElement, 'mouseleave', this.scheduledHide.bind(this, null, this.hideTimeout)));
                break;
        }
        if (this.showTrigger !== Triggers.HOVER && this.hideOnMouseLeave) {
            this.eventListeners.push(this.renderer.listen(this.elementRef.nativeElement, 'touchend', this.scheduledHide.bind(this, null, this.hideTimeout)));
            this.eventListeners.push(this.renderer.listen(this.elementRef.nativeElement, 'touchcancel', this.scheduledHide.bind(this, null, this.hideTimeout)));
            this.eventListeners.push(this.renderer.listen(this.elementRef.nativeElement, 'mouseleave', this.scheduledHide.bind(this, null, this.hideTimeout)));
        }
    }
    /**
     * @param {?} target
     * @param {...?} sources
     * @return {?}
     */
    static assignDefined(target, ...sources) {
        for (const source of sources) {
            for (const key of Object.keys(source)) {
                /** @type {?} */
                const val = source[key];
                if (val !== undefined) {
                    target[key] = val;
                }
            }
        }
        return target;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        //Support legacy prop
        this.hideOnClickOutside = typeof this.hideOnClickOutside === 'undefined' ?
            this.closeOnClickOutside : this.hideOnClickOutside;
        if (typeof this.content === 'string') {
            /** @type {?} */
            const text = this.content;
            this.popperContent = this.constructContent();
            this.popperContent.text = text;
        }
        else {
            this.popperContent = this.content;
        }
        /** @type {?} */
        const popperRef = this.popperContent;
        popperRef.referenceObject = this.getRefElement();
        this.setContentProperties(popperRef);
        this.setDefaults();
        this.applyTriggerListeners();
        if (this.showOnStart) {
            this.scheduledShow();
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes['popperDisabled'] && changes['popperDisabled'].currentValue) {
            this.hide();
        }
        if (changes['content']
            && !changes['content'].firstChange
            && typeof changes['content'].currentValue === 'string') {
            this.popperContent.text = changes['content'].currentValue;
        }
        if (changes['applyClass']
            && !changes['applyClass'].firstChange
            && typeof changes['applyClass'].currentValue === 'string') {
            this.popperContent.popperOptions.applyClass = changes['applyClass'].currentValue;
        }
        if (changes['applyArrowClass']
            && !changes['applyArrowClass'].firstChange
            && typeof changes['applyArrowClass'].currentValue === 'string') {
            this.popperContent.popperOptions.applyArrowClass = changes['applyArrowClass'].currentValue;
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.subscriptions.forEach(sub => sub.unsubscribe && sub.unsubscribe());
        this.subscriptions.length = 0;
        this.clearEventListeners();
        this.clearGlobalEventListeners();
        clearTimeout(this.scheduledShowTimeout);
        clearTimeout(this.scheduledHideTimeout);
        this.popperContent && this.popperContent.clean();
    }
    /**
     * @return {?}
     */
    toggle() {
        if (this.disabled) {
            return;
        }
        this.shown ? this.scheduledHide(null, this.hideTimeout) : this.scheduledShow();
    }
    /**
     * @return {?}
     */
    show() {
        if (this.shown) {
            this.overrideHideTimeout();
            return;
        }
        this.shown = true;
        /** @type {?} */
        const popperRef = this.popperContent;
        /** @type {?} */
        const element = this.getRefElement();
        if (popperRef.referenceObject !== element) {
            popperRef.referenceObject = element;
        }
        this.setContentProperties(popperRef);
        popperRef.show();
        this.popperOnShown.emit(this);
        if (this.timeoutAfterShow > 0) {
            this.scheduledHide(null, this.timeoutAfterShow);
        }
        this.globalEventListeners.push(this.renderer.listen('document', 'touchend', this.hideOnClickOutsideHandler.bind(this)));
        this.globalEventListeners.push(this.renderer.listen('document', 'click', this.hideOnClickOutsideHandler.bind(this)));
        this.globalEventListeners.push(this.renderer.listen(this.getScrollParent(this.getRefElement()), 'scroll', this.hideOnScrollHandler.bind(this)));
    }
    /**
     * @return {?}
     */
    hide() {
        if (this.disabled) {
            return;
        }
        if (!this.shown) {
            this.overrideShowTimeout();
            return;
        }
        this.shown = false;
        if (this.popperContentRef) {
            this.popperContentRef.instance.hide();
        }
        else {
            this.popperContent.hide();
        }
        this.popperOnHidden.emit(this);
        this.clearGlobalEventListeners();
    }
    /**
     * @param {?=} delay
     * @return {?}
     */
    scheduledShow(delay = this.showDelay) {
        if (this.disabled) {
            return;
        }
        this.overrideHideTimeout();
        this.scheduledShowTimeout = setTimeout(() => {
            this.show();
            this.applyChanges();
        }, delay);
    }
    /**
     * @param {?=} $event
     * @param {?=} delay
     * @return {?}
     */
    scheduledHide($event = null, delay = this.hideTimeout) {
        if (this.disabled) {
            return;
        }
        this.overrideShowTimeout();
        this.scheduledHideTimeout = setTimeout(() => {
            /** @type {?} */
            const toElement = $event ? $event.toElement : null;
            /** @type {?} */
            const popperContentView = this.popperContent.popperViewRef ? this.popperContent.popperViewRef.nativeElement : false;
            if (!popperContentView || popperContentView === toElement || popperContentView.contains(toElement) || ((/** @type {?} */ (this.content))).isMouseOver) {
                return;
            }
            this.hide();
            this.applyChanges();
        }, delay);
    }
    /**
     * @return {?}
     */
    getRefElement() {
        return this.targetElement || this.viewContainerRef.element.nativeElement;
    }
    /**
     * @private
     * @return {?}
     */
    applyChanges() {
        this.changeDetectorRef.markForCheck();
        this.changeDetectorRef.detectChanges();
    }
    /**
     * @private
     * @return {?}
     */
    setDefaults() {
        this.showDelay = typeof this.showDelay === 'undefined' ? PopperController.baseOptions.showDelay : this.showDelay;
        this.showTrigger = typeof this.showTrigger === 'undefined' ? PopperController.baseOptions.trigger : this.showTrigger;
        this.hideOnClickOutside = typeof this.hideOnClickOutside === 'undefined' ? PopperController.baseOptions.hideOnClickOutside : this.hideOnClickOutside;
        this.hideOnScroll = typeof this.hideOnScroll === 'undefined' ? PopperController.baseOptions.hideOnScroll : this.hideOnScroll;
        this.hideOnMouseLeave = typeof this.hideOnMouseLeave === 'undefined' ? PopperController.baseOptions.hideOnMouseLeave : this.hideOnMouseLeave;
        this.ariaRole = typeof this.ariaRole === 'undefined' ? PopperController.baseOptions.ariaRole : this.ariaRole;
        this.ariaDescribe = typeof this.ariaDescribe === 'undefined' ? PopperController.baseOptions.ariaDescribe : this.ariaDescribe;
        this.styles = typeof this.styles === 'undefined' ? Object.assign({}, PopperController.baseOptions.styles) : this.styles;
    }
    /**
     * @private
     * @return {?}
     */
    clearEventListeners() {
        this.eventListeners.forEach(evt => {
            evt && typeof evt === 'function' && evt();
        });
        this.eventListeners.length = 0;
    }
    /**
     * @private
     * @return {?}
     */
    clearGlobalEventListeners() {
        this.globalEventListeners.forEach(evt => {
            evt && typeof evt === 'function' && evt();
        });
        this.globalEventListeners.length = 0;
    }
    /**
     * @private
     * @return {?}
     */
    overrideShowTimeout() {
        if (this.scheduledShowTimeout) {
            clearTimeout(this.scheduledShowTimeout);
            this.scheduledHideTimeout = 0;
        }
    }
    /**
     * @private
     * @return {?}
     */
    overrideHideTimeout() {
        if (this.scheduledHideTimeout) {
            clearTimeout(this.scheduledHideTimeout);
            this.scheduledHideTimeout = 0;
        }
    }
    /**
     * @private
     * @return {?}
     */
    constructContent() {
        /** @type {?} */
        const factory = this.resolver.resolveComponentFactory(this.popperContentClass);
        this.popperContentRef = this.viewContainerRef.createComponent(factory);
        return (/** @type {?} */ (this.popperContentRef.instance));
    }
    /**
     * @private
     * @param {?} popperRef
     * @return {?}
     */
    setContentProperties(popperRef) {
        popperRef.popperOptions = PopperController.assignDefined(popperRef.popperOptions, PopperController.baseOptions, {
            showDelay: this.showDelay,
            disableAnimation: this.disableAnimation,
            disableDefaultStyling: this.disableStyle,
            placement: this.placement,
            boundariesElement: this.boundariesElement,
            trigger: this.showTrigger,
            positionFixed: this.positionFixed,
            popperModifiers: this.popperModifiers,
            ariaDescribe: this.ariaDescribe,
            ariaRole: this.ariaRole,
            applyClass: this.applyClass,
            applyArrowClass: this.applyArrowClass,
            hideOnMouseLeave: this.hideOnMouseLeave,
            styles: this.styles,
            appendTo: this.appendTo,
            preventOverflow: this.preventOverflow,
        });
        popperRef.onUpdate = this.onPopperUpdate.bind(this);
        this.subscriptions.push(popperRef.onHidden.subscribe(this.hide.bind(this)));
    }
    /**
     * @private
     * @param {?} node
     * @return {?}
     */
    getScrollParent(node) {
        /** @type {?} */
        const isElement = node instanceof HTMLElement;
        /** @type {?} */
        const overflowY = isElement && window.getComputedStyle(node).overflowY;
        /** @type {?} */
        const isScrollable = overflowY !== 'visible' && overflowY !== 'hidden';
        if (!node) {
            return null;
        }
        else if (isScrollable && node.scrollHeight >= node.clientHeight) {
            return node;
        }
        return this.getScrollParent(node.parentNode) || document;
    }
    /**
     * @private
     * @param {?} event
     * @return {?}
     */
    onPopperUpdate(event) {
        this.popperOnUpdate.emit(event);
    }
}
PopperController.baseOptions = (/** @type {?} */ ({
    showDelay: 0,
    placement: Placements.Auto,
    hideOnClickOutside: true,
    hideOnMouseLeave: false,
    hideOnScroll: false,
    showTrigger: Triggers.HOVER,
    appendTo: undefined,
    ariaRole: 'popper',
    ariaDescribe: '',
    styles: {}
}));
PopperController.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Directive"], args: [{
                selector: '[popper]',
                exportAs: 'popper'
            },] }
];
/** @nocollapse */
PopperController.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewContainerRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ChangeDetectorRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ComponentFactoryResolver"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Renderer2"] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"], args: ['popperDefaults',] }] }
];
PopperController.propDecorators = {
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popper',] }],
    disabled: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperDisabled',] }],
    placement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperPlacement',] }],
    showTrigger: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperTrigger',] }],
    targetElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperTarget',] }],
    showDelay: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperDelay',] }],
    hideTimeout: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperTimeout',] }],
    timeoutAfterShow: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperTimeoutAfterShow',] }],
    boundariesElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperBoundaries',] }],
    showOnStart: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperShowOnStart',] }],
    closeOnClickOutside: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperCloseOnClickOutside',] }],
    hideOnClickOutside: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperHideOnClickOutside',] }],
    hideOnScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperHideOnScroll',] }],
    hideOnMouseLeave: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperHideOnMouseLeave',] }],
    positionFixed: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperPositionFixed',] }],
    popperModifiers: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperModifiers',] }],
    disableStyle: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperDisableStyle',] }],
    disableAnimation: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperDisableAnimation',] }],
    applyClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperApplyClass',] }],
    applyArrowClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperApplyArrowClass',] }],
    ariaDescribe: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperAriaDescribeBy',] }],
    ariaRole: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperAriaRole',] }],
    styles: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperStyles',] }],
    appendTo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperAppendTo',] }],
    preventOverflow: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['popperPreventOverflow',] }],
    popperOnShown: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"] }],
    popperOnHidden: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"] }],
    popperOnUpdate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
const ɵ0 = {};
class NgxPopperModule {
    /**
     * @return {?}
     */
    ngDoBootstrap() {
    }
    /**
     * @param {?=} popperBaseOptions
     * @return {?}
     */
    static forRoot(popperBaseOptions = {}) {
        return { ngModule: NgxPopperModule, providers: [{ provide: 'popperDefaults', useValue: popperBaseOptions }] };
    }
}
NgxPopperModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"], args: [{
                imports: [
                    _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]
                ],
                declarations: [
                    PopperController,
                    PopperContent
                ],
                exports: [
                    PopperController,
                    PopperContent
                ],
                entryComponents: [
                    PopperContent
                ],
                providers: [
                    {
                        provide: 'popperDefaults', useValue: ɵ0
                    }
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */



//# sourceMappingURL=ngx-popper.js.map

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/ang-ads/ang-ads.component.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/ang-ads/ang-ads.component.html ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"(state.hasAds$ | async) as hasAds\">\n  <ng-container *ngIf=\"hasAds\">\n    <div\n      class=\"adsbox bottom-margin\"\n      [ngClass]=\"{\n        adsleaderboard: type === 'leaderboard',\n        adsmpu: type === 'mpu'\n      }\"\n    >\n      <div\n        class=\"ads\"\n        [ngClass]=\"{\n          leaderboard: type === 'leaderboard',\n          mpu: type === 'mpu'\n        }\"\n      >\n        <div [id]=\"type === 'leaderboard' ? 'adunitH' : 'adunitP'\"></div>\n      </div>\n    </div>\n  </ng-container>\n</ng-container>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/ang-aside/ang-aside.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/ang-aside/ang-aside.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<aside >\n  <div class=\"ang-aside-inner\" id=\"sticky_aside\" >\n    <anghami-ads [type]=\"'mpu'\"></anghami-ads>\n    <anghami-story-list-wrapper [placement]=\"'sidebar'\"></anghami-story-list-wrapper>\n    <div class=\"aside-nav\">\n      <ul>\n        <li><a i18n=\"@@About\" target=\"_blank\" href=\"https://www.anghami.com/about\">About</a></li>\n        <li><a i18n=\"@@products\" target=\"_blank\" href=\"https://www.anghami.com/products\">Products</a></li>\n        <li><a i18n=\"@@Team\" target=\"_blank\" href=\"https://www.anghami.com/team\">Team</a></li>\n        <li><a i18n=\"@@Careers\" target=\"_blank\" href=\"https://www.anghami.com/careers\">Careers</a></li>\n        <li><a i18n=\"@@Help\" target=\"_blank\" href=\"https://www.anghami.com/help\">Help</a></li>\n      </ul>\n      <p>&copy; {{year}} <span i18n=\"@@Anghami\">Anghami</span> </p>\n    </div>\n  </div>\n</aside>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/banner-button/banner-button.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/banner-button/banner-button.component.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"type === 'top'; else bottom\">\n  <div class='subscribe-banner' *ngIf=\"!topHidden\">\n    <div class='text-part'>\n      <span class='big-title' i18n=\"@@no_restrictions_plus\">\n        Enjoy music without restrictions with Anghami Plus      \n      </span>\n      <span i18n=\"@@no_ads_offline_music\">\n        Ad-free. High-quality. Offline music.\n      </span>\n    </div>\n    <div class='buttons-part'>\n      <button class=\"subscribe-btn\" (click)=\"subscribe()\" i18n=\"@@staticlanding_button\">\n        Subscribe Now\n      </button>\n      <span class='close-span' (click)=\"close(0)\">&times;</span>\n    </div>\n  </div>\n</ng-container>\n<ng-template #bottom>\n    <div class='register-banner' *ngIf=\"!bottomHidden\">\n      <div class='flex-container'>\n        <div class='text-part'>\n          <span class='big-title' i18n=\"@@create_your_account\">\n            Sign up to enjoy all the music you want for free.\n          </span>\n          <span i18n=\"@@no_card_needed\">\n            No credit cards needed.\n          </span>\n        </div>\n        <div class='buttons-part'>\n          <button class=\"register-btn\" (click)=\"register()\" i18n=\"@@sign_up_now_for_free\">\n            Sign up for free\n          </button>\n          <span class='close-span' (click)=\"close(1)\">&times;</span>\n        </div>\n      </div>\n    </div>\n</ng-template>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/navbar/navbar.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/navbar/navbar.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"nav-content\">\n  <ul>\n    <li [routerLinkActive]=\"'active'\" >\n      <a class=\"logo-anchor\" [routerLink]=\"['/home']\">\n      </a>\n    </li>\n    <li [routerLinkActive]=\"'active'\">\n      <a [routerLink]=\"['/home']\" (click)=\"trackAmplitudeEvents('Home')\">\n        <anghami-icon class=\"icon off\" [data]=\"'home'\"></anghami-icon>\n        <anghami-icon class=\"icon on\" [data]=\"'home-selected'\"></anghami-icon>\n        <span i18n=\"@@home\">Home</span>\n      </a>\n    </li>\n    <li [routerLinkActive]=\"'active'\">\n      <a [routerLink]=\"['/personal-dj']\" (click)=\"trackAmplitudeEvents('Personal DJ')\">\n        <anghami-icon class=\"icon off\" [data]=\"'pdj'\"></anghami-icon>\n        <anghami-icon class=\"icon on\" [data]=\"'pdj-on'\"></anghami-icon>\n        <span i18n=\"@@Personal DJ\">Personal DJ</span>\n      </a>\n    </li>\n    <li [routerLinkActive]=\"'active'\">\n      <a [routerLink]=\"['/tag/127']\" (click)=\"trackAmplitudeEvents('Podcasts')\">\n        <anghami-icon class=\"icon off\" [data]=\"'podcast-notselected'\"></anghami-icon>\n        <anghami-icon class=\"icon on\" [data]=\"'podcast-selected'\"></anghami-icon>\n        <span i18n=\"@@Podcasts\">Podcasts</span>\n      </a>\n    </li>\n    <li [routerLinkActive]=\"'active'\" [routerLinkActiveOptions]=\"{ exact: true }\" class=\"mymusic-compact-menu\">\n      <a [routerLink]=\"['/mymusic']\" (click)=\"trackAmplitudeEvents('My Music')\">\n        <anghami-icon class=\"icon off\" [data]=\"'mymusic-nav'\"></anghami-icon>\n        <anghami-icon class=\"icon on\" [data]=\"'mymusic-selected'\"></anghami-icon>\n        <span i18n=\"@@My Music\">My Music</span>\n      </a>\n    </li>\n    <li [routerLinkActive]=\"'active'\">\n      <a [routerLink]=\"['/likes']\" (click)=\"trackAmplitudeEvents('Likes')\">\n        <anghami-icon class=\"icon off\" [data]=\"'like'\"></anghami-icon>\n        <anghami-icon class=\"icon on\" [data]=\"'liked'\"></anghami-icon>\n        <span i18n=\"@@Likes\">Likes</span>\n      </a>\n    </li>\n    <li title=\"My Downloads\" [routerLinkActive]=\"'active'\">\n      <a [routerLink]=\"[downloadsPageLink]\" (click)=\"trackAmplitudeEvents('Downloads')\">\n        <anghami-icon class=\"icon off\" [data]=\"'download'\"></anghami-icon>\n        <anghami-icon class=\"icon on\" [data]=\"'downloaded'\"></anghami-icon>\n        <span i18n=\"@@My Downloads\">Downloads</span>\n      </a>\n    </li>\n    <li [routerLinkActive]=\"'active'\" class=\"playlist-compact-menu\">\n      <a [routerLink]=\"['/mymusic/playlists']\" (click)=\"trackAmplitudeEvents('Playlists')\">\n        <anghami-icon class=\"icon off\" [data]=\"'playlist-nav'\"></anghami-icon>\n        <anghami-icon class=\"icon on\" [data]=\"'playlist-selected'\"></anghami-icon>\n        <span i18n=\"@@Playlists\">Playlists</span>\n      </a>\n    </li>\n    <li [routerLinkActive]=\"'active'\">\n      <a [routerLink]=\"['/upload-music']\" (click)=\"trackAmplitudeEvents('Upload Music')\">\n        <anghami-icon class=\"icon off\" [data]=\"'upload'\"></anghami-icon>\n        <anghami-icon class=\"icon on\" [data]=\"'upload-selected'\"></anghami-icon>\n        <span i18n=\"@@upload_your_music\">Upload your music</span>\n      </a>\n    </li>\n  </ul>\n  <div class=\"bottom-links\">\n    <div class=\"link\">\n      <a href=\"https://support.anghami.com/hc/{{selectedLang}}\" target=\"_blank\" (click)=\"trackAmplitudeEvents('Help')\">\n        <anghami-icon class=\"icon\" [data]=\"'help'\"></anghami-icon>\n      </a>\n    </div>\n    <div class=\"link\">\n      <a [routerLink]=\"['/settings']\" (click)=\"trackAmplitudeEvents('Settings')\">\n        <anghami-icon class=\"icon\" [data]=\"'settings'\"></anghami-icon>\n      </a>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/onboarding/onboarding.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/onboarding/onboarding.component.html ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"onboarding-modal-parent\" *ngIf=\"!!onboardingPageID\">\n  <div class=\"onboarding-modal\">\n    <div class=\"navigation-dots-parent\">\n      <div\n        *ngFor=\"let pageID of onboarding_pages; let idx = index\"\n        class=\"navigation-dot\"\n        [ngClass]=\"{\n          clickable: pagesFilled[idx] || pageID === onboardingPageID\n        }\"\n        (click)=\"goToPageFromNavigation(pageID, idx)\"\n      ></div>\n    </div>\n    <ng-container *ngIf=\"isNewUser && onboardingPageID === 1\">\n      <div class=\"onboarding-title\" i18n=\"@@onboarding_welcome_title\">\n        Welcome to Anghami!\n      </div>\n      <div class=\"onboarding-subtitle\" i18n=\"@@onboarding_welcome_subtitle\">\n        We’re happy to see you here. Tell us a bit about yourself.\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"isOldUser && onboardingPageID === 1\">\n      <div\n        class=\"onboarding-title\"\n        i18n=\"@@onboarding_welcome_olduser_title\"\n        id=\"username-title\"\n      >\n        Hey, #username#!\n      </div>\n      <div\n        class=\"onboarding-subtitle\"\n        i18n=\"@@onboarding_welcome_olduser_subtitle\"\n      >\n        We’re happy to see you here. We already filled your info but you can\n        always edit them.\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 2\">\n      <div class=\"onboarding-title\" i18n=\"@@onboarding_birthday_title\">\n        When is your birthday?\n      </div>\n      <div class=\"onboarding-subtitle\" i18n=\"@@onboarding_birthday_subtitle\">\n        A very special surprise will be awaiting you on that day\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 3\">\n      <div class=\"onboarding-title\" i18n=\"@@onboarding_favorite_music_title\">\n        What music do you like the most?\n      </div>\n      <div\n        class=\"onboarding-subtitle\"\n        i18n=\"@@onboarding_favorite_music_subtitle\"\n      >\n        We’ll recommend songs that suit your taste\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 4\">\n      <div class=\"onboarding-title\" i18n=\"@@onboarding_favorite_music_title\">\n        What music do you like the most?\n      </div>\n      <div\n        class=\"onboarding-subtitle\"\n        i18n=\"@@onboarding_favourite_music_subtitle\"\n      >\n        We’ll recommend songs that suit your taste\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 5\">\n      <div class=\"onboarding-title\" i18n=\"@@onboarding_favorite_music_title\">\n        What kind of music do you like?\n      </div>\n      <div\n        class=\"onboarding-subtitle\"\n        i18n=\"@@onboarding_pick_genre\"\n      >\n        Pick one as a start\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 6\">\n      <div class=\"onboarding-title\" i18n=\"@@onboarding_theme_title\">\n        Choose your theme\n      </div>\n      <div class=\"onboarding-subtitle\" i18n=\"@@onboarding_theme_subtitle\">\n        Pick a theme that works for you. You can always change themes from\n        settings\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 7\">\n      <div class=\"onboarding-title\" i18n=\"@@onboarding_last_step_title\">\n        One last step!\n      </div>\n      <div class=\"onboarding-subtitle\" i18n=\"@@onboarding_last_step_subtitle\">\n        Why keep your songs elsewhere when you can bring them to Anghami too\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 8\">\n      <div class=\"onboarding-title\" i18n=\"@@onboarding_wrap_up_title\">\n        Here’s an extra tip!\n      </div>\n      <div class=\"onboarding-subtitle\" i18n=\"@@onboarding_wrap_up_subtitle\">\n        Play music from the comfort of your desktop, get Anghami for mac and\n        windows…\n      </div>\n    </ng-container>\n    <div class=\"onboarding-content-1\" *ngIf=\"onboardingPageID === 1\">\n      <div class=\"d-flex\">\n        <anghami-upload-cover-art\n          class=\"d-none\"\n          (uploadedImage)=\"handleImageUpload($event)\"\n        ></anghami-upload-cover-art>\n        <div class=\"col-6\">\n          <img\n            class=\"profile-pic-camera\"\n            [src]=\"onboardingAssetsEnv + 'camera@2x.png'\"\n            (click)=\"uploadImage()\"\n          />\n          <img\n            class=\"profile-pic\"\n            [src]=\"!!picture ? picture : onboardingAssetsEnv + 'NoGender.jpg'\"\n          />\n        </div>\n        <div class=\"col-6\">\n          <div\n            class=\"input-label\"\n            i18n=\"@@onboarding_welcome_firstname_placeholder\"\n          >\n            Enter your first name\n          </div>\n          <input\n            class=\"name-input\"\n            [placeholder]=\"firstNamePlaceholder\"\n            [(ngModel)]=\"firstName\"\n            [ngClass]=\"{ 'name-input-error': isFirstNameEmpty }\"\n          />\n          <div\n            class=\"input-label\"\n            i18n=\"@@onboarding_welcome_lastname_placeholder\"\n            style=\"margin-top:2rem;\"\n          >\n            Enter your last name\n          </div>\n          <input\n            class=\"name-input\"\n            [placeholder]=\"lastNamePlaceholder\"\n            [(ngModel)]=\"lastName\"\n            [ngClass]=\"{ 'name-input-error': isLastNameEmpty }\"\n          />\n        </div>\n      </div>\n      <div\n        class=\"error-msg\"\n        [ngClass]=\"isFirstNameEmpty ? 'visible' : 'invisible'\"\n        i18n=\"@@onboarding_welcome_firstname_placeholder\"\n      >\n        Enter your first name\n      </div>\n      <div\n        class=\"error-msg\"\n        [ngClass]=\"isLastNameEmpty ? 'visible' : 'invisible'\"\n        i18n=\"@@onboarding_welcome_lastname_placeholder\"\n      >\n        Enter your last name\n      </div>\n    </div>\n    <div class=\"onboarding-content-2\" *ngIf=\"onboardingPageID === 2\">\n      <div class=\"col-6\">\n        <img [src]=\"onboardingAssetsEnv + 'DOB@2x.png'\" />\n      </div>\n      <div class=\"col-6\">\n        <div class=\"input-label\" style=\"margin-top: 3rem;\"  i18n=\"@@Your date of birth\">\n          Your Date Of Birth\n        </div>\n        <div class=\"flex\">\n          <input\n            class=\"dob-input\"\n            [(ngModel)]=\"dob.day\"\n            placeholder=\"DD\"\n            [ngClass]=\"{ 'dob-input-error': isDOBDayEmpty }\"\n            (change)=\"setDOB($event)\"\n          />\n          <input\n            class=\"dob-input\"\n            [(ngModel)]=\"dob.month\"\n            placeholder=\"MM\"\n            [ngClass]=\"{ 'dob-input-error': isDOBMonthEmpty }\"\n            (change)=\"setDOB($event)\"\n          />\n          <input\n            class=\"dob-input\"\n            [(ngModel)]=\"dob.year\"\n            placeholder=\"YYYY\"\n            [ngClass]=\"{ 'dob-input-error': isDOBYearEmpty }\"\n            (change)=\"setDOB($event)\"\n          />\n        </div>\n      </div>\n    </div>\n    <div class=\"onboarding-content-3\" *ngIf=\"onboardingPageID === 3\">\n      <div class=\"col-6\">\n        <img [src]=\"onboardingAssetsEnv + 'music language@2x.png'\" />\n      </div>\n      <div class=\"col-6\">\n        <div class=\"radio-btn-container\">\n          <label class=\"container input-label\">\n            <ng-container i18n=\"@@Arabic Music\"> Arabic music </ng-container>\n            <input type=\"radio\" value=\"1\" name=\"radio\" [(ngModel)]=\"musiclanguage\" [checked]=\"true\" />\n            <span class=\"checkmark\"></span>\n          </label>\n          <label class=\"container input-label\">\n            <ng-container i18n=\"@@International Music\" >International Music</ng-container>\n            <input type=\"radio\" value=\"2\" name=\"radio\" [(ngModel)]=\"musiclanguage\" />\n            <span class=\"checkmark\"></span>\n          </label>\n          <label class=\"container input-label\">\n            <ng-container i18n=\"@@Arabic & International Music\">Arabic and International Music</ng-container>\n            <input type=\"radio\" value=\"0\" name=\"radio\" [(ngModel)]=\"musiclanguage\" />\n            <span class=\"checkmark\"></span>\n          </label>\n        </div>\n      </div>\n    </div>\n    <div class=\"onboarding-content-4\" *ngIf=\"onboardingPageID === 4\">\n      <div class=\"search-artists-container\">\n        <input\n          (keyup)=\"searchArtist($event)\"\n          [(ngModel)]=\"searchQuery\"\n          placeholder=\"Search for artists...\"\n        />\n      </div>\n      <div class=\"d-flex flex-column justify-content-center align-items-center\">\n        <anghami-loading\n          class=\"loader\"\n          *ngIf=\"suggestedArtists.length === 0\"\n        ></anghami-loading>\n      </div>\n      <div class=\"onboarding-artists-container\">\n        <div\n          *ngFor=\"let item of suggestedArtists\"\n          class=\"onboarding-artists\"\n          (click)=\"selectArtist(item)\"\n          [ngClass]=\"{ 'cursor-pointer': !followedArtistsObject[item.id] }\"\n        >\n          <div\n            class=\"onboarding-artists-img\"\n            [ngStyle]=\"{\n              'background-image':\n                'url(https://angartwork.akamaized.net/?id=' +\n                item.CoverArt +\n                '&size=100\n                )'\n            }\"\n          >\n            <img\n              *ngIf=\"!!followedArtistsObject[item.id]\"\n              class=\"onboarding-artists-img-check\"\n              [src]=\"onboardingAssetsEnv + 'check@2x.png'\"\n            />\n          </div>\n          <div class=\"onboarding-artists-name\">\n            {{ item.Name | ellipsis: 23 }}\n          </div>\n        </div>\n        <div>\n          <button\n            *ngIf=\"suggestedArtists.length !== 0 && moreSuggestedArtists\"\n            class=\"anghami-default-btn\"\n            i18n=\"@@more\"\n            (click)=\"showMoreSuggestedArtists()\"\n          >\n            More\n          </button>\n        </div>\n      </div>\n      <div class=\"onboarding-selected-artists-parent\">\n        <div\n          class=\"onboarding-selected-artists\"\n          *ngFor=\"let item of selectedArtists\"\n        >\n          {{ item.name ? item.name : (item.Name | ellipsis) }}\n          <div class=\"close-icon-parent\" (click)=\"unfollowArtist(item)\">\n            <img\n              class=\"close-icon\"\n              [src]=\"onboardingAssetsEnv + 'close-icon.svg'\"\n            />\n          </div>\n        </div>\n      </div>\n      <div\n        class=\"error-msg\"\n        [ngClass]=\"!isSelectedArtistsValid ? 'visible' : 'invisible'\"\n      >\n        Please select at least three artists\n      </div>\n    </div>\n    <div class=\"onboarding-content-5\" *ngIf=\"onboardingPageID === 5\">\n      <div class=\"d-flex flex-column justify-content-center align-items-center\">\n        <anghami-loading\n          class=\"loader\"\n          *ngIf=\"!suggestedGenres\"\n        ></anghami-loading>\n      </div>\n      <div\n        *ngFor=\"let item of suggestedGenres\"\n        class=\"onboarding-genres-parent\"\n      >\n        <img\n          [src]=\"onboardingAssetsEnv + 'check@2x.png'\"\n          class=\"onboarding-genres-check\"\n          *ngIf=\"item.followed === 1\"\n        />\n        <div\n          class=\"onboarding-genres\"\n          (click)=\"selectGenre(item)\"\n          [ngStyle]=\"{\n            'background-image':\n              'url(https://angartwork.akamaized.net/?id=' +\n              item.CoverArt +\n              '&size=170\n              )'\n          }\"\n        >\n          {{ item.name }}\n        </div>\n      </div>\n    </div>\n    <div\n      class=\"error-msg\"\n      [ngClass]=\"\n        !isSelectedGenresValid && onboardingPageID === 5\n          ? 'visible'\n          : 'invisible'\n      \"\n    >\n      Please select at least one genre\n    </div>\n    <div class=\"onboarding-content-6\" *ngIf=\"onboardingPageID === 6\">\n      <div class=\"onboarding-display-mode\">\n        <img\n          *ngIf=\"darkmode === '0'\"\n          class=\"onboarding-display-check\"\n          [src]=\"onboardingAssetsEnv + 'check@2x.png'\"\n        />\n        <img\n          class=\"onboarding-display-img\"\n          [src]=\"onboardingAssetsEnv + 'light-mode@2x.png'\"\n          (click)=\"toggleDarkMode(false)\"\n        />\n      </div>\n      <div class=\"onboarding-display-mode\">\n        <img\n          *ngIf=\"darkmode === '1'\"\n          class=\"onboarding-display-check\"\n          [src]=\"onboardingAssetsEnv + 'check@2x.png'\"\n        />\n        <img\n          class=\"onboarding-display-img\"\n          [src]=\"onboardingAssetsEnv + 'dark-mode@2x.png'\"\n          (click)=\"toggleDarkMode(true)\"\n        />\n      </div>\n    </div>\n    <div class=\"onboarding-content-7\" *ngIf=\"onboardingPageID === 7\">\n      <div class=\"col-6\">\n        <img [src]=\"onboardingAssetsEnv + 'import songs@2x.png'\" />\n      </div>\n      <div class=\"col-6\" style=\"margin-top: 1rem;\">\n        <div class=\"import-container cursor-pointer\" (click)=\"import('device')\">\n          <img\n            [src]=\"onboardingAssetsEnv + 'device@2x.png'\"\n            class=\"import-icon\"\n          />\n          <span i18n=\"@@import_from_device\">Import from device</span>\n        </div>\n        <div\n          class=\"import-container cursor-pointer\"\n          (click)=\"import('spotify')\"\n        >\n          <img\n            [src]=\"onboardingAssetsEnv + 'spotify@2x.png'\"\n            class=\"import-icon\"\n          />\n          <span i18n=\"@@onboarding_last_step_importspotify\"\n            >Import from Spotify</span\n          >\n        </div>\n        <div\n          class=\"import-container cursor-pointer\"\n          (click)=\"import('youtube')\"\n        >\n          <img\n            [src]=\"onboardingAssetsEnv + 'youtube@2x.png'\"\n            class=\"import-icon\"\n          />\n          <span i18n=\"@@onboarding_last_step_importyoutube\"\n            >Import from Youtube</span\n          >\n        </div>\n      </div>\n    </div>\n    <div class=\"onboarding-content-8\" *ngIf=\"onboardingPageID === 8\">\n      <img\n        class=\"onboarding-install-img\"\n        [src]=\"onboardingAssetsEnv + 'install@2x.png'\"\n      />\n    </div>\n    <div class=\"onboarding-line\"></div>\n    <ng-container *ngIf=\"onboardingPageID === 1\">\n      <button class=\"onboarding-next-btn\" (click)=\"nextPage()\">\n        <span i18n=\"@@onboarding_welcome_button\">Get started</span>\n      </button>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 2\">\n      <button class=\"onboarding-next-btn\" (click)=\"nextPage()\">\n        <span i18n=\"@@next\">Next</span>\n      </button>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 3\">\n      <button class=\"onboarding-next-btn\" (click)=\"nextPage()\">\n        <span i18n=\"@@next\">\n          Next</span\n        >\n      </button>\n    </ng-container>\n    <ng-container\n      *ngIf=\"onboardingPageID === 4 && remainingArtistsRequired > 0\"\n    >\n      <button class=\"onboarding-next-btn\" disabled>\n        <span\n          id=\"follow-artists-btn\">\n          {{ remainingArtistsRequiredString }} </span>\n      </button>\n    </ng-container>\n    <ng-container\n      *ngIf=\"onboardingPageID === 4 && remainingArtistsRequired <= 0\"\n    >\n      <button class=\"onboarding-next-btn\" (click)=\"nextPage()\">\n        <span\n          i18n=\"@@onboarding_favorite_artists_button_done\"\n          id=\"follow-artists-btn\"\n        >\n          Continue</span\n        >\n      </button>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 5\">\n      <button class=\"onboarding-next-btn\" (click)=\"nextPage()\">\n        <span i18n=\"@@next\">Next</span>\n      </button>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 6\">\n      <button class=\"onboarding-next-btn\" (click)=\"nextPage()\">\n        <span i18n=\"@@next\">Next</span>\n      </button>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 7\">\n      <button class=\"onboarding-next-btn\" (click)=\"nextPage()\">\n        <span i18n=\"@@Done_onboarding\">Done</span>\n      </button>\n    </ng-container>\n    <ng-container *ngIf=\"onboardingPageID === 8\">\n      <anghami-download-app\n        type=\"dialog\"\n        onboarding=\"true\">\n      </anghami-download-app>\n    </ng-container>\n    <div class=\"onboarding-skip\" *ngIf=\"onboardingPageID !== 7 && onboardingPageID !== 8\" (click)=\"skipStep()\" i18n=\"@@Skip for now\">Skip for now</div>\n    <div class=\"onboarding-skip\" *ngIf=\"onboardingPageID === 8\" (click)=\"skipStep()\" i18n=\"@@Skip for now\">Close</div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/buffer/buffer.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/modules/player/buffer/buffer.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  class=\"cont\"\n  #parentDiv\n  [class.disabled]=\"currentTrack?.disable_video_scrub\"\n  (mousedown)=\"onMouseClick($event)\"\n>\n  <ng-container *ngIf=\"progress\">\n    <div class=\"bar fullsize\"></div>\n    <div\n      class=\"fullsize stream-controls play\"\n      [ngStyle]=\"{ width: (isMouseClicked ? seekedPercentage : progress.percentage) + '%' }\"\n    ></div>\n    <span\n      class=\"stream-controls indicator\"\n      [style.right]=\"locale === 'ar' ? (isMouseClicked ? seekedPercentage : progress.percentage) + '%' : 'unset'\"\n      [style.left]=\"locale !== 'ar' ? (isMouseClicked ? seekedPercentage : progress.percentage) + '%' : 'unset'\"\n      #streamIndicator\n    >\n    </span>\n  </ng-container>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/player.component.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/modules/player/player.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"miniplayer-container\" id=\"miniplayer_container\" #videoPlayerContainer\n  *ngIf=\"videoOn\">\n  <div class=\"mini-player-controls\" *ngIf=\"currentTrack\" [class.force]=\"!(playstate$ | async)\">\n    <anghami-icon class=\"icon expand\" ngbTooltip=\"{{ 'expand' | translate }}\" [data]=\"'expand'\"\n      [routerLink]=\"['/video/' + currentTrack.id]\"></anghami-icon>\n    <anghami-icon class=\"icon close\" ngbTooltip=\"{{ 'close' | translate }}\" (click)=\"NEWstopVideo()\" [data]=\"'close'\"></anghami-icon>\n    <ng-container *ngIf=\"!(buffering$ | async)\">\n      <anghami-icon class=\"icon play\" (click)=\"NEWplaypause()\" [data]=\"'play-shape'\" *ngIf=\"!(playstate$ | async)\">\n      </anghami-icon>\n      <anghami-icon class=\"icon pause\" (click)=\"NEWplaypause()\" [data]=\"'pause-shape'\" *ngIf=\"playstate$ | async\">\n      </anghami-icon>\n    </ng-container>\n  </div>\n</div>\n<div class=\"player-wrapper\" *ngIf=\"currentTrack\">\n  <div class=\"player-leaderboard\" *ngIf=\"AdsState.visible\">\n    <div class=\"close\" (click)=\"closeLeaderBoard()\">\n      &times;\n    </div>\n    <anghami-ads [type]=\"'leaderboard'\" [source]=\"'player'\"></anghami-ads>\n  </div>\n  <anghami-buffer *ngIf=\"progress$ | async as progress\" [progress]=\"progress\"></anghami-buffer>\n  <ng-container>\n    <div class=\"player-content d-flex justify-content-start\" (click)=\"NEWLeaderboardVisibility()\"\n      *ngIf=\"currentTrack?.id\">\n      <ng-container *ngIf=\"currentTrack.is_podcast; else elseTemplate\">\n        <div class=\"player-section player-controls podcast d-flex align-items-center\">\n          <anghami-selector-sheet type=\"sleep\" [sheetOptions]=\"podcastSleepOptions\"\n            [selectedOption]=\"podcastSleepSelected\" (itemClick)=\"sleepTimerChange($event)\">\n          </anghami-selector-sheet>\n          <div class=\"d-flex align-items-center play-prev-next\">\n            <anghami-icon class=\"icon seekButt\" [data]=\"'Backword15'\" (click)=\"seekPlayer(false, 15)\"></anghami-icon>\n\n            <div class=\"play-pause-cont\" (click)=\"NEWplaypause()\">\n              <anghami-loading [white]=\"'true'\" *ngIf=\"buffering$ | async\" class=\"loader\"></anghami-loading>\n              <ng-container *ngIf=\"!(buffering$ | async)\">\n                <anghami-icon class=\"icon play\" [data]=\"'play-shape'\" *ngIf=\"!(playstate$ | async)\"></anghami-icon>\n                <anghami-icon class=\"icon pause\" [data]=\"'pause-shape'\" *ngIf=\"playstate$ | async\"></anghami-icon>\n              </ng-container>\n            </div>\n\n            <anghami-icon class=\"icon seekButt\" [data]=\"'Forward15'\" (click)=\"seekPlayer(true, 15)\"></anghami-icon>\n          </div>\n          <anghami-selector-sheet type=\"speed\" [sheetOptions]=\"podcastSpeeds\" [selectedOption]=\"podcastSelectedSpeed\"\n            (itemClick)=\"speedRateChange($event)\">\n          </anghami-selector-sheet>\n        </div>\n      </ng-container>\n      <ng-template #elseTemplate>\n        <div class=\"player-section player-controls d-flex align-items-center\">\n          <anghami-icon class=\"icon\" [data]=\"'repeat'\" [class.active]=\"repeatOn$ | async\" (click)=\"NEWtoggleRepeat()\"\n            ngbTooltip=\"{{ 'repeat' | translate }}\"></anghami-icon>\n          <div class=\"d-flex align-items-center play-prev-next\">\n            <anghami-icon class=\"icon prev\" [data]=\"'previous'\" (click)=\"NEWprevious()\"></anghami-icon>\n\n            <div class=\"play-pause-cont\" (click)=\"NEWplaypause()\">\n              <anghami-loading [white]=\"'true'\" *ngIf=\"buffering$ | async\" class=\"loader\"></anghami-loading>\n              <ng-container *ngIf=\"!(buffering$ | async)\">\n                <anghami-icon class=\"icon play\" [data]=\"'play-shape'\" *ngIf=\"!(playstate$ | async)\"></anghami-icon>\n                <anghami-icon class=\"icon pause\" [data]=\"'pause-shape'\" *ngIf=\"playstate$ | async\"></anghami-icon>\n              </ng-container>\n            </div>\n\n            <anghami-icon class=\"icon next\" [data]=\"'next'\" (click)=\"NEWnext()\"></anghami-icon>\n          </div>\n          <anghami-icon class=\"icon shuffle\" [data]=\"'scrub'\" [class.active]=\"shuffleOn$ | async\"\n            (click)=\"NEWtoggleShuffle()\" ngbTooltip=\"{{ 'shuffle' | translate }}\"></anghami-icon>\n        </div>\n      </ng-template>\n      <div class=\"player-section track-info d-flex align-items-center\">\n        <div class=\"track-img-cntr\">\n          <div class=\"track-coverart\" [ngStyle]=\"{\n              'background-image': 'url(' + currentTrack?.coverArtImage + ')'\n            }\"></div>\n          <div class=\"explicit\" *ngIf=\"currentTrack?.explicit == '1'\">\n            <span class=\"e-block\">e</span>\n          </div>\n        </div>\n        <div class=\"info\" [class.gray-scale-disabled]=\"!(online$ | async)\">\n          <a class=\"d-block action-title\" anghamiExtras [extras]=\"currentTrack?.extras\"\n            [routerLink]=\"['/song/' + currentTrack.id]\" dir=\"auto\">\n            <div class=\"trim\">{{ currentTrack.title }}</div>\n          </a>\n\n          <a class=\"d-block action-artist\" [routerLink]=\"['/artist/' + currentTrack?.artistID]\" anghamiExtras\n            [extras]=\"currentTrack?.extras\" dir=\"auto\" [class.disabled]=\"currentTrack?.artistID == '414'\">\n            <div class=\"trim\">{{ currentTrack.artist }}</div>\n          </a>\n          <div></div>\n        </div>\n        <div class=\"p-2\" *ngIf=\"progress$ | async as progress\">\n          {{ progress.progress | convertDuration }} /\n          {{ currentTrack.duration | convertDuration }}\n        </div>\n      </div>\n      <div class=\"player-section player-actions d-flex align-items-center\"\n        >\n        <div class=\"vl\"></div>\n        <anghami-icon class=\"icon\" [data]=\"'lyrics'\" placement=\"top\" [class.disabled]=\"!currentTrack.lyrics\"\n          ngbTooltip=\"{{ 'lyrics' | translate }}\" (click)=\"openLyricsModal()\" [class.gray-scale-disabled]=\"!(online$ | async)\"></anghami-icon>\n\n        <anghami-icon class=\"icon\" [data]=\"'music-videos'\" placement=\"top\" ngbTooltip=\"{{ 'video' | translate }}\"\n          (click)=\"NEWtoggleVideoMode(true)\" [class.disabled]=\"!currentTrack?.videoid || videoOn\" [class.gray-scale-disabled]=\"!(online$ | async)\"></anghami-icon>\n\n        <anghami-icon class=\"icon\" [data]=\"'mymusic-selected'\" placement=\"top\" ngbTooltip=\"{{ 'song' | translate }}\"\n          (click)=\"NEWtoggleVideoMode(false)\" [class.disabled]=\"!videoOn || currentTrack.videoonly\" [class.gray-scale-disabled]=\"!(online$ | async)\"></anghami-icon>\n\n        <anghami-icon class=\"icon\" (click)=\"likeTrack(currentTrack)\" [ngClass]=\"{ liked: currentTrack?.liked }\"\n          [data]=\"currentTrack?.liked ? 'liked' : 'like'\" placement=\"top\" anghamiExtras [extras]=\"currentTrack?.extras\"\n          ngbTooltip=\"{{ (currentTrack?.liked ? 'Liked' : 'Like') | translate }}\" [class.gray-scale-disabled]=\"!(online$ | async)\">\n        </anghami-icon>\n        <anghami-icon class=\"icon\" (click)=\"dislikeTrack(currentTrack)\" [data]=\"'dislike-icon'\" placement=\"top\"\n          ngbTooltip=\"{{ 'dislike' | translate }}\" anghamiExtras [extras]=\"currentTrack?.extras\" [class.gray-scale-disabled]=\"!(online$ | async)\">\n        </anghami-icon>\n        <anghami-icon class=\"icon\" [data]=\"'share'\" (click)=\"share(currentTrack)\" placement=\"top\"\n          ngbTooltip=\"{{ 'share' | translate }}\"\n          anghamiExtras [extras]=\"currentTrack?.extras\" [class.gray-scale-disabled]=\"!(online$ | async)\"></anghami-icon>\n        <anghami-context-sheet-new [type]=\"currentTrack.is_podcast ? 'podcast' : 'song'\" [data]=\"currentTrack\"\n          source=\"player\" [currentList]=\"currentList$ | async\" [placement]=\"['top', 'auto']\"\n          ngbTooltip=\"{{ 'more' | translate }}\"\n          [disablePopover]=\"currentPlayerOptions?.ads\">\n        </anghami-context-sheet-new>\n        <div class=\"vl\"></div>\n        <div class=\"device-list-trigger\" [class.gray-scale-disabled]=\"!(online$ | async)\">\n          <div [ngbPopover]=\"devices\" [placement]=\"['top']\" class=\"more-context\" (hidden)=\"devicepopoverShown = false\"\n            (shown)=\"devicepopoverShown = true\">\n            <anghami-icon class=\"icon\" [data]=\"'connect-device'\" [ngClass]=\"{ highlighted: devicepopoverShown }\"\n              placement=\"top\" ngbTooltip=\"{{ 'devices' | translate }}\"></anghami-icon>\n          </div>\n        </div>\n        <div class=\"vl\"></div>\n        <anghami-volume></anghami-volume>\n        <div class=\"vl\" *ngIf=\"isDesktopClient && miniPlayerSupported && showMiniPlayerButton\"></div>\n\n        <anghami-icon class=\"icon\" *ngIf=\"isDesktopClient && miniPlayerSupported && showMiniPlayerButton\"\n          (click)=\"switchToMiniPlayer()\" [data]=\"'smaller'\" placement=\"top\"\n          ngbTooltip=\"{{ 'mini_player' | translate }}\"></anghami-icon>\n        <div class=\"vl\"></div>\n      </div>\n      <div class=\"queue-toggle\" (click)=\"toggleQueue()\" [ngClass]=\"{ highlighted: isQueueToggled }\">\n        <div class=\"queue-toggle-wrapper\">\n          <anghami-icon class=\"icon\" [data]=\"'queue'\" placement=\"top\"></anghami-icon>\n          <span i18n=\"@@queue\">Queue</span>\n        </div>\n      </div>\n      <ng-template #devices>\n        <div class=\"devices-list\">\n          <div class=\"top\" i18n=\"@@connect_toadevice\">Connect to a device</div>\n          <ul class=\"list\" *ngIf=\"devicesList\">\n            <li *ngIf=\"!devicesList.length\">\n              <span>\n                <anghami-icon class=\"icon\" [data]=\"'desktop'\"></anghami-icon>\n              </span>\n              <span class=\"device-name\">\n                <div class=\"nowplaying\">No connected devices</div>\n              </span>\n            </li>\n            <li (click)=\"NEWchangeSOD(item.socket_id)\" *ngFor=\"let item of devicesList\" [ngClass]=\"{ sod: item.sod }\">\n              <span>\n                <anghami-icon class=\"icon\" [data]=\"item.device\"></anghami-icon>\n              </span>\n              <span class=\"device-name\">\n                <div class=\"nowplaying\" *ngIf=\"item.sod\" i18n=\"@@now playing from\">\n                  Now playing from\n                </div>\n                <ng-container *ngIf=\"item.current && !isDesktopClient\" i18n=\"@@current_tab\">\n                  Current Tab\n                </ng-container>\n                <ng-container *ngIf=\"!item.current || (item.current && isDesktopClient)\">\n                  {{ item.name }}\n                </ng-container>\n              </span>\n              <span class=\"tick\" *ngIf=\"item.sod\">\n                <anghami-icon class=\"icon\" [data]=\"'check'\"></anghami-icon>\n              </span>\n            </li>\n          </ul>\n        </div>\n      </ng-template>\n    </div>\n  </ng-container>\n\n  <ng-container *ngIf='!anghRemote.isSOD && getSODName() !== \"\"'>\n    <div class=\"player-not-sod-container d-flex justify-content-end\">\n      <div class=\"player-not-sod\">\n        <span i18n=\"@@listening_on\">You're listening on</span> \n        <strong> {{ getSODName() }}</strong>\n      </div>\n    </div>\n  </ng-container>\n</div>\n\n<div *ngIf=\"isQueueToggled\">\n  <anghami-queue [queue]=\"queue$ | async\" [playqueue]=\"queue\" (closeQueue)=\"toggleQueue(false)\"></anghami-queue>\n  <div class=\"queue-closing-background\" (click)=\"toggleQueue(false)\"></div>\n</div>\n\n\n  <ng-container *ngIf=\"currentTrack?.dropimage && !videoOn\">\n    \t<div class=\"snowisfalling\">\n\t\t<span *ngFor=\"let number of [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]\" [ngStyle]=\"{'background-image': 'url(' + currentTrack?.dropimage + ')'}\"></span>\n\t</div>\n  </ng-container>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/queue/queue.component.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/modules/player/queue/queue.component.html ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"list && (list.list_type == 'playlist' || list.list_type == 'album') ;else elseTemplate\">\n  <div class=\"queue-header\">\n    <!-- <div class=\"queue-arrow\">\n       <anghami-icon class=\"icon\" [data]=\"'icon-arrow-up'\"></anghami-icon>\n  </div> -->\n    <div class=\"queue-header-inner\">\n        <div class=\"queue-cover\">\n          <img [src]=\"list?.coverart\" />\n        </div>\n        <div class=\"queue-details\">\n          <div class='title-button'>\n            <h3>\n              <a dir=\"auto\" [routerLink]=\"['/' + playqueue?.type + '/' + list?.id]\">\n                {{ list?.title }}</a>\n            </h3>\n            <div appQueueStatus [queueObject]=\"list\" [currentPlayQueueLst]=\"tracks\"></div>\n          </div>\n          <p>\n            <ng-container *ngIf=\"list?.followers && list.followers > 0\">{{ list?.followers | formatNumbers }} <ng-container i18n=\"@@followers\">\n                Followers </ng-container> | </ng-container>\n            <ng-container *ngIf=\"list?.list_type == 'album' && list.plays && list.plays > 0\">{{ list.plays | formatNumbers }} <ng-container i18n=\"@@plays\">\n                Plays </ng-container> | </ng-container>\n            <ng-container *ngIf=\"playqueue?.songs.length\">{{ playqueue.songs.length }} songs</ng-container>\n          </p>\n        </div>\n    </div>\n    <div class=\"else-header-wrap details\">\n      <h5>In the queue</h5>\n      <div class=\"close-icon\">\n        <span class='close-span' (click)=\"closeQueue.emit()\">&times;</span>\n      </div>\n    </div>\n  </div>\n</ng-container>\n<ng-template #elseTemplate>\n  <div class=\"else-header-wrap\">\n    <div class=\"queue-save-header\">\n      <h5>In the queue</h5>\n      <div appQueueStatus [queueObject]=\"list\" [currentPlayQueueLst]=\"tracks\"></div>\n    </div>\n    <div class=\"close-icon\">\n      <span class='close-span' (click)=\"closeQueue.emit()\">&times;</span>\n    </div>\n  </div>\n</ng-template>\n<div \n  class=\"queue-scroller\" \n  id=\"queue_scroller\" \n  [sortablejs]=\"tracks\" \n  [sortablejsOptions]=\"eventOptions\"\n  infiniteScroll\n  [infiniteScrollDistance]=\"5\"\n  (scrolled)=\"increaseInfiniteScroll()\"\n  [scrollWindow]=\"false\"\n  >\n  <div *ngFor=\"let item of tracks | slice: 0:infiniteScrollLimit; let i = index; trackBy: trackById\" class=\"queue-padder\">\n    <anghami-list-item [displayType]=\"'list'\" [type]=\"'queue'\" [collectionItem]=\"item\" [currentList]=\"list\"\n      (click)=\"playItem(i, $event)\" [index]=\"i\">\n    </anghami-list-item>\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/selector-sheet.component.html/selector-sheet.component.html":
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/modules/player/selector-sheet.component.html/selector-sheet.component.html ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n  <ng-container *ngIf=\"type === 'sleep'; else elseTemplate\">\n    <anghami-icon \n      class=\"icon\" \n      [data]=\"'SleepTimer'\" \n      #popover=\"ngbPopover\" \n      class=\"icon sleep\" \n      popoverClass=\"sleep-selector\" \n      placement=\"top\"\n      [ngbPopover]=\"contextsheet\"\n      container=\"body\"\n    >\n    </anghami-icon>\n  </ng-container>\n  <ng-template #elseTemplate>\n      <div #popover=\"ngbPopover\" class=\"icon speed-icon\" popoverClass=\"selector-sheet\" placement=\"top\"\n        [ngbPopover]=\"contextsheet\">\n        <span *ngIf=\"selectedOption !== undefined\"> {{selectedOption.text}} </span>\n      </div>\n  </ng-template>\n\n  \n  <ng-template #contextsheet>\n    <div class='speed-slector-container' [ngClass]=\"{'sleep-timer-sheet': type==='sleep'}\" *ngIf=\"sheetOptions !== undefined\"> \n      <div *ngFor=\"let option of sheetOptions\" (click)=\"optionClick(option)\" [ngClass]=\"{'selected': option.selected}\">\n        {{option.text}}\n      </div>\n    </div>\n  </ng-template>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/volume/volume.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/modules/player/volume/volume.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"volumePercentage == 0\"\n  ><span class=\"volume-muted\"></span\n></ng-container>\n<anghami-icon\n  [ngClass]=\"{ highlighted: volumepopoverShown }\"\n  class=\"icon volume\"\n  [data]=\"'volume-on'\"\n  (click)=\"mute()\"\n></anghami-icon>\n\n<div class=\"volume-slider-container\" #volumeSlider>\n  <div class=\"volume-bar\" (mousedown)=\"onVolumeMouseDown($event)\" #volumeBar>\n    <div\n      class=\"volume-ball-wrapper\"\n      [ngStyle]=\"{ height: volume }\"\n      #volumeBallWrapper\n    >\n      <div class=\"volume-ball\"></div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/base.component.html":
/*!****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/base.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<anghami-ie-blocking *ngIf=\"isInternetExplorer && isbrowser\"></anghami-ie-blocking>\n\n<ng-container *ngIf=\"!isInternetExplorer\">\n  <anghami-header *ngIf=\"isbrowser\"></anghami-header>\n  <div class=\"base-wrapper\" [ngClass]=\"{ extrapadding: getPlayerAdsSubs | async }\">\n    <anghami-navbar *ngIf=\"isbrowser\"></anghami-navbar>\n    <div class=\"base-content\" id=\"base_content\">\n      <div class=\"basecontent-main\">\n        <anghami-banner-button class=\"top\" type=\"top\" *ngIf=\"bannerPage && isbrowser\"></anghami-banner-button>\n        <router-outlet></router-outlet>\n      </div>\n      <anghami-aside id=\"ang-aside\" class=\"ang-side\" *ngIf=\"isbrowser\"></anghami-aside>\n    </div>\n    <anghami-banner-button *ngIf=\"!isLoggedIn && bannerPage && isbrowser\" type=\"bottom\"></anghami-banner-button>\n    <anghami-player *ngIf=\"isLoggedIn && isbrowser\"></anghami-player>\n    <anghami-onboarding *ngIf=\"isOnboarding && isLoggedIn && isbrowser\"></anghami-onboarding>\n  </div>\n  <div adBlockDetector *ngIf=\"isbrowser\"></div>\n</ng-container>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/login/components/no-internet/no-internet.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/login/components/no-internet/no-internet.component.html ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main\">\n  <anghami-empty-pages [type]=\"'no-connection'\"></anghami-empty-pages>\n</div>\n"

/***/ }),

/***/ "./node_modules/rxjs-compat/_esm2015/observable/of.js":
/*!************************************************************!*\
  !*** ./node_modules/rxjs-compat/_esm2015/observable/of.js ***!
  \************************************************************/
/*! exports provided: of */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "of", function() { return rxjs__WEBPACK_IMPORTED_MODULE_0__["of"]; });


//# sourceMappingURL=of.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/operators/withLatestFrom.js":
/*!****************************************************************!*\
  !*** ./node_modules/rxjs/internal/operators/withLatestFrom.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var OuterSubscriber_1 = __webpack_require__(/*! ../OuterSubscriber */ "./node_modules/rxjs/internal/OuterSubscriber.js");
var subscribeToResult_1 = __webpack_require__(/*! ../util/subscribeToResult */ "./node_modules/rxjs/internal/util/subscribeToResult.js");
function withLatestFrom() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    return function (source) {
        var project;
        if (typeof args[args.length - 1] === 'function') {
            project = args.pop();
        }
        var observables = args;
        return source.lift(new WithLatestFromOperator(observables, project));
    };
}
exports.withLatestFrom = withLatestFrom;
var WithLatestFromOperator = (function () {
    function WithLatestFromOperator(observables, project) {
        this.observables = observables;
        this.project = project;
    }
    WithLatestFromOperator.prototype.call = function (subscriber, source) {
        return source.subscribe(new WithLatestFromSubscriber(subscriber, this.observables, this.project));
    };
    return WithLatestFromOperator;
}());
var WithLatestFromSubscriber = (function (_super) {
    __extends(WithLatestFromSubscriber, _super);
    function WithLatestFromSubscriber(destination, observables, project) {
        var _this = _super.call(this, destination) || this;
        _this.observables = observables;
        _this.project = project;
        _this.toRespond = [];
        var len = observables.length;
        _this.values = new Array(len);
        for (var i = 0; i < len; i++) {
            _this.toRespond.push(i);
        }
        for (var i = 0; i < len; i++) {
            var observable = observables[i];
            _this.add(subscribeToResult_1.subscribeToResult(_this, observable, observable, i));
        }
        return _this;
    }
    WithLatestFromSubscriber.prototype.notifyNext = function (outerValue, innerValue, outerIndex, innerIndex, innerSub) {
        this.values[outerIndex] = innerValue;
        var toRespond = this.toRespond;
        if (toRespond.length > 0) {
            var found = toRespond.indexOf(outerIndex);
            if (found !== -1) {
                toRespond.splice(found, 1);
            }
        }
    };
    WithLatestFromSubscriber.prototype.notifyComplete = function () {
    };
    WithLatestFromSubscriber.prototype._next = function (value) {
        if (this.toRespond.length === 0) {
            var args = [value].concat(this.values);
            if (this.project) {
                this._tryProject(args);
            }
            else {
                this.destination.next(args);
            }
        }
    };
    WithLatestFromSubscriber.prototype._tryProject = function (args) {
        var result;
        try {
            result = this.project.apply(this, args);
        }
        catch (err) {
            this.destination.error(err);
            return;
        }
        this.destination.next(result);
    };
    return WithLatestFromSubscriber;
}(OuterSubscriber_1.OuterSubscriber));
//# sourceMappingURL=withLatestFrom.js.map

/***/ }),

/***/ "./src/app/core/components/ang-ads/ang-ads.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/core/components/ang-ads/ang-ads.component.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: block;\n}\n:host.mpu {\n  height: 250px;\n}\n:host .adsleaderboard,\n:host .adsmpu {\n  position: relative;\n  overflow: hidden;\n}\n:host .adsmpu {\n  margin-top: 1em;\n  margin-bottom: 1em;\n  max-width: 300px;\n  height: 250px;\n  background-color: var(--placeholder-background);\n}\n:host .adsleaderboard {\n  max-width: 728px;\n  height: 90px;\n  background-color: var(--placeholder-background);\n  margin: auto;\n}\n:host .ad-redirect {\n  color: var(--white);\n  text-decoration: none;\n  font-size: 0.8em;\n}\n:host .remove-ads {\n  text-align: center;\n  position: absolute;\n  bottom: 100%;\n  right: 0;\n  background-color: var(--brand-blue);\n  padding: 0.02em 0.3em;\n}"

/***/ }),

/***/ "./src/app/core/components/ang-ads/ang-ads.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/components/ang-ads/ang-ads.component.ts ***!
  \**************************************************************/
/*! exports provided: AngAdsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AngAdsComponent", function() { return AngAdsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_selectors_collection_selector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/selectors/collection.selector */ "./src/app/core/redux/selectors/collection.selector.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _core_services_ads_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/services/ads.service */ "./src/app/core/services/ads.service.ts");
/* harmony import */ var _refrences_WindowRef__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../refrences/WindowRef */ "./src/app/core/refrences/WindowRef.ts");
/* harmony import */ var _modules_player_selectors_player_selectors__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../modules/player/selectors/player.selectors */ "./src/app/core/modules/player/selectors/player.selectors.ts");
/* harmony import */ var _anghami_redux_selectors_router_selectors__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/redux/selectors/router.selectors */ "./src/app/core/redux/selectors/router.selectors.ts");












let AngAdsComponent = class AngAdsComponent {
    constructor(store, adsService, platformId, document, window) {
        this.store = store;
        this.adsService = adsService;
        this.platformId = platformId;
        this.document = document;
        this.window = window;
        this.hasAds = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"](false);
        this.hasAds.next(false);
        this.state = {
            routerInfo$: undefined,
            collectionId$: undefined,
            collectionType$: undefined,
            currentList$: undefined,
            currentTrack$: undefined,
            routerInfo: undefined,
            collectionId: undefined,
            collectionType: undefined,
            currentList: undefined,
            currentTrack: undefined,
            collectionTypeCap: undefined,
            adDfpId: undefined,
            adSizes: [],
            adTargetDiv: undefined,
            adSlot: undefined,
            getUser$: undefined,
            lang: 'en',
            google: {},
            refreshInterval: undefined,
            initTimer: undefined,
            hasAds$: this.hasAds.asObservable(),
            scriptRetries: 0,
            uri: 'www.googletagservices.com/tag/js/gpt.js'
        };
        this.ttags = {};
    }
    refreshCoRoutine() {
        if (this.window.nativeWindow['googletag']
            && typeof this.window.nativeWindow['googletag'].pubads === 'function') {
            this.window.nativeWindow['googletag']
                .pubads()
                .refresh([this.state.adSlot]);
        }
    }
    ngOnDestroy() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformServer"])(this.platformId)) {
            return;
        }
        if (this.state.adSlot) {
            // window['googletag'].destroySlots();
            this.window.nativeWindow['googletag'].destroySlots([this.state.adSlot]);
        }
        if (this.state.combined$) {
            this.state.combined$.unsubscribe();
        }
        if (this.state.initTimer) {
            this.state.initTimer.unsubscribe();
        }
        if (this.loaderSub$) {
            this.loaderSub$.unsubscribe();
        }
        delete this.state.routerInfo$;
        delete this.state.collectionId$;
        delete this.state.collectionType$;
        delete this.state.getUser$;
        delete this.state.currentList$;
        delete this.state.currentTrack$;
        if (this.hasAds) {
            this.hasAds.unsubscribe();
        }
    }
    ngAfterViewInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            this.state.initTimer = Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["timer"])(2000).subscribe(this.renderAds.bind(this));
            if (this.source === 'player') {
                this.SubscribeToLeaderBoardChange();
            }
        }
    }
    setExtraAdParams(track, routeInfo) {
        const tags = {};
        if (routeInfo && (routeInfo.type === 'playlist' || routeInfo.type === 'album')) {
            tags['cPlaylist'] = routeInfo.id;
            tags['cDir'] = routeInfo.id;
        }
        tags['cSong'] = (track && track !== null && track.length > 0)
            ? track.id
            : (routeInfo && routeInfo.type === 'song')
                ? routeInfo.id
                : undefined;
        this.filterParams(tags);
        return tags;
    }
    filterParams(params) {
        Object.keys(params).forEach(key => (params[key] === undefined || params[key] === null
            || (typeof params[key] === 'object' && Object.keys(params[key]).length === 0))
            && delete params[key]);
    }
    renderAds() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformServer"])(this.platformId)) {
            return;
        }
        this.state.collectionType$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_collection_selector__WEBPACK_IMPORTED_MODULE_2__["getCollectionTypeState"]));
        this.state.routerInfo$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_router_selectors__WEBPACK_IMPORTED_MODULE_11__["getRouterInfo"]));
        this.state.collectionId$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_collection_selector__WEBPACK_IMPORTED_MODULE_2__["getCollectionIdState"]));
        this.state.getUser$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_1__["getUser"]));
        this.state.currentList$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_modules_player_selectors_player_selectors__WEBPACK_IMPORTED_MODULE_10__["getCurrentList"]));
        this.state.currentTrack$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_modules_player_selectors_player_selectors__WEBPACK_IMPORTED_MODULE_10__["getCurrentTrack"]));
        this.state.combined$ = Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["combineLatest"])(this.state.routerInfo$, this.state.collectionId$, this.state.collectionType$, this.state.getUser$, this.state.currentList$, this.state.currentTrack$)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["distinctUntilChanged"])())
            .subscribe(this.combineLatestCb.bind(this));
    }
    combineLatestCb([routerInfo, collectionId, collectionType, userAuth, currentList, currentTrack]) {
        if (routerInfo && routerInfo !== null && routerInfo['params']) {
            if (Object.keys(routerInfo['params']).length > 0) {
                this.state.routerInfo = {
                    type: routerInfo['params'].collectionType,
                    id: routerInfo['params'].collectionId
                };
            }
            else {
                const type = routerInfo['url'].split('/').length > 1
                    ? routerInfo['url'].split('/')[1]
                    : null;
                this.state.routerInfo = {
                    type: type,
                    id: type !== null
                        ? '' : null
                };
            }
            collectionType = this.state.routerInfo.type;
            collectionId = this.state.routerInfo.id;
        }
        if (collectionType === this.state.collectionType) {
            return;
        }
        this.ttags = this.setExtraAdParams(currentTrack, this.state.routerInfo);
        if (userAuth && userAuth !== null && userAuth['ad-tag-params']) {
            const adparams = JSON.parse(atob(userAuth['ad-tag-params']));
            Object.assign(this.ttags, adparams);
        }
        else {
            Object.assign(this.ttags, { 'uLang': this.state.lang });
        }
        const shouldHideAd = userAuth && userAuth !== null && (userAuth.noad == true || userAuth.noad == 'true');
        if (shouldHideAd) {
            this.hasAds.next(false);
            this.ngOnDestroy();
        }
        else {
            if (this.state.adSlot) {
                this.window.nativeWindow['googletag'].destroySlots([
                    this.state.adSlot
                ]);
            }
            if (typeof collectionType !== 'undefined' && collectionType !== null) {
                if (typeof userAuth !== 'undefined' &&
                    userAuth !== null &&
                    Object.keys(userAuth).length > 0) {
                    this.state.lang = userAuth.language;
                }
                if (typeof collectionId !== 'undefined' && collectionId !== null) {
                    this.state.collectionId = collectionId.slice(0, collectionId.indexOf('?'));
                }
                this.state.collectionType = collectionType;
                this.state.collectionTypeCap = `${collectionType
                    .charAt(0)
                    .toUpperCase()}${collectionType.slice(1)}`;
            }
            this.injectScript();
        }
    }
    injectScript() {
        this.hasAds.next(true);
        this.loaderSub$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_collection_selector__WEBPACK_IMPORTED_MODULE_2__["getCollectionLoadingState"]))
            .subscribe(loading => {
            if (!loading) {
                setTimeout(() => {
                    this.setScripts();
                }, 3000);
            }
        });
    }
    setScripts() {
        this.state.google = Object.assign({}, this.state.google, { hasGoogleScript: this.document.getElementById('ang-ads') });
        if (typeof this.state.google.hasGoogleScript !== 'undefined' &&
            this.state.google.hasGoogleScript !== null) {
            this.initDFP();
        }
        else {
            this.initDOMMetaData();
        }
    }
    initDOMMetaData() {
        this.window.nativeWindow['googletag'] =
            this.window.nativeWindow['googletag'] || {};
        this.window.nativeWindow['googletag'].cmd =
            this.window.nativeWindow['googletag'].cmd || [];
        delete this.state.google;
        this.state.google = Object.assign({}, this.state.google, { gads: this.document.createElement('script'), useSSL: 'https:' === this.document.location.protocol, node: this.document.getElementsByTagName('script')[0], div: this.document.createElement('div') });
        this.state.google.gads.async = true;
        this.state.google.gads.type = 'text/javascript';
        this.state.google.gads.src = `${this.state.google.useSSL ? 'https:' : 'http:'}//${this.state.uri}`;
        this.state.google.node.parentNode.insertBefore(this.state.google.gads, this.state.google.node);
        this.state.google.div.id = 'ang-ads';
        this.document.body.appendChild(this.state.google.div);
        this.state.google.gads.onload = this.onLoad.bind(this);
        this.state.google.gads.onerror = this.onError.bind(this);
        ++this.state.scriptRetries;
    }
    onLoad() {
        this.initDFP();
    }
    onError() {
        if (this.state.scriptRetries < 3) {
            this.initDOMMetaData();
        }
    }
    initDFP() {
        if (!this.window.nativeWindow['googletag']) {
            return;
        }
        if (this.type === 'leaderboard') {
            this.state.adSizes = [728, 90];
            this.state.adTargetDiv = 'adunitH';
            this.state.adDfpId = '7229/Anghami_Mobile_App/Anghami_Web/Player';
        }
        else if (this.type === 'mpu') {
            this.state.adSizes = [300, 250];
            this.state.adTargetDiv = 'adunitP';
            this.state.adDfpId = '7229/Anghami_Mobile_App/Anghami_Web';
            // this.state.adDfpId = this.state.collectionId
            //   ? `7229/Anghami_Mobile_App/Anghami_Web/${this.state.collectionTypeCap}`
            //   : `/7229/n7729.testsite/Anghami`;
        }
        this.window.nativeWindow['googletag'].cmd.push(this.onInitDfp.bind(this));
        delete this.state.google.hasGoogleScript;
        delete this.state.google.div;
        delete this.state.google.gads;
        delete this.state.google.node;
    }
    onInitDfp() {
        this.initAd();
    }
    initAd() {
        if (!this.window.nativeWindow['googletag']) {
            return;
        }
        const slot = this.window.nativeWindow['googletag'].defineSlot(this.state.adDfpId, this.state.adSizes, this.state.adTargetDiv);
        if (slot && slot !== null) {
            this.state.adSlot = slot.set('adsense_background_color', '#FFFFFF');
        }
        if (this.state.adSlot && this.state.adSlot !== null) {
            this.state.adSlot.addService(this.window.nativeWindow['googletag'].companionAds());
            this.state.adSlot.addService(this.window.nativeWindow['googletag'].pubads());
        }
        this.window.nativeWindow['googletag'].pubads().enableVideoAds();
        if (this.ttags && Object.keys(this.ttags) && Object.keys(this.ttags).length > 0) {
            for (const key of Object.keys(this.ttags)) {
                this.window.nativeWindow['googletag']
                    .pubads()
                    .setTargeting(key, this.ttags[key]);
            }
        }
        if (this.type === 'mpu' && this.state.collectionId) {
            this.window.nativeWindow['googletag']
                .pubads()
                .setTargeting(`c${this.state.collectionTypeCap}`, this.state.collectionId);
            this.window.nativeWindow['googletag']
                .pubads()
                .set('adsense_background_color', '#ffffff');
        }
        else if (this.type === 'leaderboard' && this.state.collectionId) {
            this.window.nativeWindow['googletag']
                .pubads()
                .set('adsense_background_color', '#eff3f5');
        }
        this.window.nativeWindow['googletag'].pubads().enableAsyncRendering();
        this.window.nativeWindow['googletag'].pubads().enableSingleRequest();
        this.window.nativeWindow['googletag'].enableServices();
        this.window.nativeWindow['googletag']
            .companionAds()
            .setRefreshUnfilledSlots(true);
        this.window.nativeWindow['googletag'].display(this.state.adTargetDiv);
        // this.refreshCoRoutine();
    }
    SubscribeToLeaderBoardChange() {
        this.adsService.refreshPlayerLeaderBoard.subscribe(this.refreshCoRoutine.bind(this));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], AngAdsComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AngAdsComponent.prototype, "source", void 0);
AngAdsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'anghami-ads',
        template: __webpack_require__(/*! raw-loader!./ang-ads.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/ang-ads/ang-ads.component.html"),
        styles: [__webpack_require__(/*! ./ang-ads.component.scss */ "./src/app/core/components/ang-ads/ang-ads.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_3__["DOCUMENT"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
        _core_services_ads_service__WEBPACK_IMPORTED_MODULE_8__["AdsService"],
        Object,
        Document,
        _refrences_WindowRef__WEBPACK_IMPORTED_MODULE_9__["WindowRef"]])
], AngAdsComponent);



/***/ }),

/***/ "./src/app/core/components/ang-ads/ang-ads.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/components/ang-ads/ang-ads.module.ts ***!
  \***********************************************************/
/*! exports provided: AngAdsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AngAdsModule", function() { return AngAdsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ang_ads_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ang-ads.component */ "./src/app/core/components/ang-ads/ang-ads.component.ts");
/* harmony import */ var ngx_dfp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-dfp */ "./node_modules/ngx-dfp/fesm2015/ngx-dfp.js");
/* harmony import */ var _anghami_services_ads_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/services/ads.service */ "./src/app/core/services/ads.service.ts");






let AngAdsModule = class AngAdsModule {
};
AngAdsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            ngx_dfp__WEBPACK_IMPORTED_MODULE_4__["DfpModule"].forRoot({
                idleLoad: true,
                enableVideoAds: true,
                personalizedAds: false,
                singleRequestMode: true,
                onSameNavigation: 'refresh'
            })
        ],
        declarations: [_ang_ads_component__WEBPACK_IMPORTED_MODULE_3__["AngAdsComponent"]],
        exports: [_ang_ads_component__WEBPACK_IMPORTED_MODULE_3__["AngAdsComponent"]],
        providers: [_anghami_services_ads_service__WEBPACK_IMPORTED_MODULE_5__["AdsService"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], AngAdsModule);



/***/ }),

/***/ "./src/app/core/components/ang-aside/ang-aside.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/core/components/ang-aside/ang-aside.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  overflow: hidden;\n}\n:host aside {\n  width: 300px;\n  margin-left: auto;\n  margin-right: auto;\n}\n:host ::ng-deep .ang-aside-inner {\n  width: 100%;\n  margin-bottom: 4em;\n}\n:host ::ng-deep .aside-item-wrapper {\n  background-color: var(--main-background);\n  border-radius: 0.5em;\n  -webkit-border-radius: 0.5em;\n  -moz-border-radius: 0.5em;\n  -ms-border-radius: 0.5em;\n  -o-border-radius: 0.5em;\n  padding: 0.2em;\n  margin: 1em auto;\n  display: block;\n  width: 100%;\n}\n:host ::ng-deep .aside-item-wrapper h4 {\n  font-weight: 600;\n  font-size: 1.1em;\n  text-align: start;\n  color: var(--text-color);\n  margin: 1em 0.5em;\n}\n:host ::ng-deep .aside-item-wrapper .side-loader {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  margin-top: -2.5em;\n  margin-left: -2.5em;\n}\n:host .aside-nav {\n  padding: 0.2em;\n  margin: 1em;\n  font-size: 0.9em;\n}\n:host .aside-nav ul {\n  padding: 0;\n  margin: 0;\n}\n:host .aside-nav ul li {\n  display: inline-block;\n  margin: 0.3em;\n}\n:host .aside-nav ul li a {\n  color: #AAA;\n}\n:host .aside-nav ul li a:hover {\n  text-decoration: underline;\n}\n:host .aside-nav p {\n  color: #AAA;\n}"

/***/ }),

/***/ "./src/app/core/components/ang-aside/ang-aside.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/core/components/ang-aside/ang-aside.component.ts ***!
  \******************************************************************/
/*! exports provided: AngAsideComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AngAsideComponent", function() { return AngAsideComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var hc_sticky__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! hc-sticky */ "./node_modules/hc-sticky/dist/hc-sticky.js");
/* harmony import */ var hc_sticky__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(hc_sticky__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");




let AngAsideComponent = class AngAsideComponent {
    constructor(platformId) {
        this.platformId = platformId;
    }
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            this.initSticky();
            this.year = new Date().getFullYear();
        }
    }
    initSticky() {
        setTimeout(() => {
            const main = document.getElementById('.ang-main');
            const side = document.getElementById('sticky_aside');
            this.sticky = new hc_sticky__WEBPACK_IMPORTED_MODULE_2__(side, { stickTo: main });
            this.sticky.update({
                top: 50
            });
        }, 3000);
    }
    ngOnDestroy() {
        if (this.sticky) {
            this.sticky.destroy();
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AngAsideComponent.prototype, "eventUrl", void 0);
AngAsideComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-aside',
        template: __webpack_require__(/*! raw-loader!./ang-aside.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/ang-aside/ang-aside.component.html"),
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
        styles: [__webpack_require__(/*! ./ang-aside.component.scss */ "./src/app/core/components/ang-aside/ang-aside.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
], AngAsideComponent);



/***/ }),

/***/ "./src/app/core/components/ang-aside/ang-aside.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/components/ang-aside/ang-aside.module.ts ***!
  \***************************************************************/
/*! exports provided: AngAsideModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AngAsideModule", function() { return AngAsideModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _core_components_ang_ads_ang_ads_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/components/ang-ads/ang-ads.module */ "./src/app/core/components/ang-ads/ang-ads.module.ts");
/* harmony import */ var _core_components_ang_aside_ang_aside_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/ang-aside/ang-aside.component */ "./src/app/core/components/ang-aside/ang-aside.component.ts");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _core_components_search_input_search_input_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/search-input/search-input.module */ "./src/app/core/components/search-input/search-input.module.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _story_list_story_list_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../story-list/story-list.module */ "./src/app/core/components/story-list/story-list.module.ts");











let AngAsideModule = class AngAsideModule {
};
AngAsideModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [_core_components_ang_aside_ang_aside_component__WEBPACK_IMPORTED_MODULE_5__["AngAsideComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"],
            _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_9__["IconModule"],
            _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"],
            _core_components_ang_ads_ang_ads_module__WEBPACK_IMPORTED_MODULE_4__["AngAdsModule"],
            _core_components_search_input_search_input_module__WEBPACK_IMPORTED_MODULE_7__["SearchInputModule"],
            _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_6__["LoadingModule"],
            _story_list_story_list_module__WEBPACK_IMPORTED_MODULE_10__["StoryListModule"]
        ],
        exports: [_core_components_ang_aside_ang_aside_component__WEBPACK_IMPORTED_MODULE_5__["AngAsideComponent"]]
    })
], AngAsideModule);



/***/ }),

/***/ "./src/app/core/components/banner-button/banner-button.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/core/components/banner-button/banner-button.component.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".subscribe-banner {\n  background: url('banner1@2x.png');\n  box-shadow: 0px 0px 6px #00000029;\n  border-radius: 0px 0px 15px 15px;\n  opacity: 1;\n  width: 100%;\n  height: 10em;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center center;\n  margin-top: 0.5em;\n  display: -ms-flexbox;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  position: relative;\n}\n.subscribe-banner .text-part {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  margin-left: 2em;\n}\n.subscribe-banner .text-part span {\n  text-align: left;\n  font-size: 1em;\n  letter-spacing: 0;\n  color: #FFFFFF;\n  opacity: 1;\n  display: block;\n}\n.subscribe-banner .text-part .big-title {\n  font-weight: bold;\n  font-size: 2em;\n}\n.subscribe-banner .buttons-part .subscribe-btn {\n  margin-right: 3em;\n  height: 2.5em;\n  line-height: 2.5em;\n  width: 13em;\n  color: white;\n  border: none;\n  background: transparent -webkit-gradient(linear, left top, right top, from(#007FFE), to(#01B5FF)) 0% 0% no-repeat padding-box;\n  background: transparent linear-gradient(90deg, #007FFE 0%, #01B5FF 100%) 0% 0% no-repeat padding-box;\n  box-shadow: 0px 3px 16px #0000005D;\n  border-radius: 28px;\n  opacity: 1;\n  font-weight: 700;\n  font-size: 14px;\n}\n.subscribe-banner .buttons-part .close-span {\n  color: #fff;\n  font-size: 2em;\n  cursor: pointer;\n  position: absolute;\n  top: -0.3em;\n  right: 0.5em;\n}\n.register-banner {\n  background: #3E9BE0 0% 0% no-repeat padding-box;\n  box-shadow: 0px -8px 6px #00000029;\n  opacity: 1;\n  -webkit-transition: 2ms;\n  transition: 2ms;\n  right: 0;\n  left: 7em;\n  height: 10em;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n  margin-bottom: -2em;\n  position: fixed;\n  z-index: 10;\n  bottom: 1em;\n}\n.register-banner .flex-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n  height: 100%;\n  margin: auto;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.register-banner .flex-container .text-part {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  margin-left: 2em;\n}\n.register-banner .flex-container .text-part span {\n  text-align: left;\n  font-size: 1em;\n  letter-spacing: 0;\n  color: #FFFFFF;\n  opacity: 1;\n  display: block;\n}\n.register-banner .flex-container .text-part .big-title {\n  font-weight: bold;\n  font-size: 1.8em;\n}\n.register-banner .flex-container .buttons-part .register-btn {\n  margin-right: 4em;\n  height: 2.5em;\n  line-height: 2.5em;\n  width: 11em;\n  color: #3E9BE0;\n  border: none;\n  background: #FFFFFF 0% 0% no-repeat padding-box;\n  box-shadow: 0px 3px 16px #0000005D;\n  border-radius: 28px;\n  opacity: 1;\n  font-weight: 700;\n  font-size: 14px;\n}\n.register-banner .flex-container .buttons-part .close-span {\n  color: #fff;\n  font-size: 2em;\n  cursor: pointer;\n  position: absolute;\n  top: 0.2em;\n  right: 1.5em;\n}\n.subscribe-banner:lang(ar) {\n  background-position-y: 0em;\n}\n.subscribe-banner:lang(ar) .text-part {\n  margin-right: 2em;\n}\n.subscribe-banner:lang(ar) .text-part span {\n  text-align: right;\n}\n.subscribe-banner:lang(ar) .buttons-part .subscribe-btn {\n  margin-left: 3em;\n}\n.subscribe-banner:lang(ar) .buttons-part .close-span {\n  left: 0.5em;\n}\n.register-banner:lang(ar) {\n  right: 7em;\n  left: 0;\n}\n.register-banner:lang(ar) .text-part {\n  margin-right: 2em;\n}\n.register-banner:lang(ar) .text-part span {\n  text-align: right !important;\n}\n.register-banner:lang(ar) .buttons-part .register-btn {\n  margin-left: 4em;\n}\n.register-banner:lang(ar) .buttons-part .close-span {\n  left: 0.5em;\n}"

/***/ }),

/***/ "./src/app/core/components/banner-button/banner-button.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/banner-button/banner-button.component.ts ***!
  \**************************************************************************/
/*! exports provided: BannerButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BannerButtonComponent", function() { return BannerButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");











let BannerButtonComponent = class BannerButtonComponent {
    constructor(store, _authService, platformId) {
        this.store = store;
        this._authService = _authService;
        this.platformId = platformId;
        this.topHidden = true;
        this.bottomHidden = true;
    }
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_10__["isPlatformBrowser"])(this.platformId)) {
            this.bottomHidden = this._authService.isUserLoggedIn();
            setTimeout(() => {
                this.getUserSub = this.store
                    .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__["getUser"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(2))
                    .subscribe(data => {
                    if (data) {
                        if (Number(data.plantype) !== 3) {
                            //  Not a plus user
                            this.topHidden = false;
                        }
                    }
                    this.bottomHidden = false;
                });
            }, 3000);
        }
    }
    ngOnDestroy() {
        if (this.getUserSub) {
            this.getUserSub.unsubscribe();
        }
    }
    subscribe() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_4__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_5__["AmplitudeEvents"].topBannerSubscribeClick
        }));
        this.close(0);
        window.open('https://plus.anghami.com');
    }
    register() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_4__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_5__["AmplitudeEvents"].bottomBannerRegisterClick
        }));
        this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_1__["OpenCustomDialog"]({
            type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_6__["DIALOG_TYPES"].LOGIN
        }));
    }
    close(index) {
        if (index === 0) {
            this.topHidden = true;
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_4__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_5__["AmplitudeEvents"].topBannerClose
            }));
        }
        else {
            this.bottomHidden = true;
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_4__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_5__["AmplitudeEvents"].bottomBannerClose
            }));
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], BannerButtonComponent.prototype, "type", void 0);
BannerButtonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'anghami-banner-button',
        template: __webpack_require__(/*! raw-loader!./banner-button.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/banner-button/banner-button.component.html"),
        styles: [__webpack_require__(/*! ./banner-button.component.scss */ "./src/app/core/components/banner-button/banner-button.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"],
        Object])
], BannerButtonComponent);



/***/ }),

/***/ "./src/app/core/components/ie-blocking/ie-blocking.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/core/components/ie-blocking/ie-blocking.component.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".ie-blocking-popup {\n  text-align: center;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n      -ms-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  border-radius: 0.2em;\n  z-index: 10000;\n  padding: 4em;\n  background-color: #e8e8e8;\n}\n.ie-blocking-popup h3, .ie-blocking-popup p {\n  color: #111;\n}\n.ie-blocking-popup h3 {\n  white-space: nowrap;\n  font-size: 2.3em;\n}\n.ie-blocking-popup p {\n  font-size: 1.2em;\n  margin: 1.8em 0;\n}\n.ie-blocking-popup-logo {\n  background-image: url(\"/assets/img/anghami-logo-colored.png\");\n  background-size: contain;\n  background-repeat: no-repeat;\n  background-position: center;\n  height: 6.7em;\n  margin-bottom: 2em;\n}\n.ie-blocking-popup-link {\n  margin-top: 1.8em;\n}\n.ie-blocking-popup-download-bottom {\n  float: left;\n  padding: 0.7em 0.9em;\n  font-size: 1.45em;\n  text-transform: uppercase;\n  border-radius: 0.2em;\n  color: #e8e8e8;\n  background: -webkit-gradient(linear, left top, right top, from(#8903ff), to(#620090));\n  background: linear-gradient(to right, #8903ff 0%, #620090 100%);\n}\n.ie-blocking-popup-download-bottom.right {\n  float: right;\n}\n.ie-blocking-popup-download-bottom.none {\n  float: none;\n  margin: 0 auto;\n  display: inline-block;\n}"

/***/ }),

/***/ "./src/app/core/components/ie-blocking/ie-blocking.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/core/components/ie-blocking/ie-blocking.component.ts ***!
  \**********************************************************************/
/*! exports provided: IeBlockingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IeBlockingComponent", function() { return IeBlockingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");





let IeBlockingComponent = class IeBlockingComponent {
    constructor(store) {
        this.store = store;
    }
    ngOnInit() { }
    downloadAppClicked() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_2__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_4__["AmplitudeEvents"].IENoticeDesktopAppDownload
        }));
    }
};
IeBlockingComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-ie-blocking',
        template: `
          <div class="ie-blocking-popup">
            <div class="ie-blocking-popup-logo">
            </div>
            <h3 i18n="@@ie_notice_title">Your Internet Explorer is no longer supported.</h3>
            <p i18n="@@ie_notice_subtitle">To get the best experience using Anghami</p>
            <div>
              <a href="https://www.anghami.com/download/" (click)='downloadAppClicked()'>
                <div class="ie-blocking-popup-download-bottom none" i18n="@@Download Windows App">Download Windows App</div>
              </a>
              <a href="https://browsehappy.com/">
                <div class="ie-blocking-popup-link" i18n="@@ie_notice_upgrade">
                  Or upgrade to a newer browser
                </div>
              </a>
            </div>
          </div>`,
        styles: [__webpack_require__(/*! ./ie-blocking.component.scss */ "./src/app/core/components/ie-blocking/ie-blocking.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"]])
], IeBlockingComponent);



/***/ }),

/***/ "./src/app/core/components/navbar/navbar.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/core/components/navbar/navbar.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  background: var(--sidebar-background);\n  width: 7em;\n  z-index: 998;\n  box-sizing: border-box;\n  border-right: 1px solid var(--dark-white);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-negative: 0;\n      flex-shrink: 0;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: stretch;\n      -ms-flex-align: stretch;\n          align-items: stretch;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  top: 0;\n  bottom: 0;\n  position: fixed;\n  -webkit-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  -moz-user-select: none;\n  left: 0;\n  border-right: 1px solid var(--app-borders);\n  overflow-x: hidden;\n}\n:host .nav-content {\n  overflow-y: auto;\n  overflow-x: hidden;\n  margin-left: -25%;\n  width: 150%;\n  padding: 0 1em;\n}\n:host .logo-anchor {\n  display: block;\n  height: 8em;\n  background: var(--brand-logo);\n  background-repeat: no-repeat;\n  background-size: 5em;\n  background-position: center center;\n}\n:host .logo-anchor.christmas-logo {\n  background: url(https://anghamiwebcdn.akamaized.net/web/assets/img/logo-christmas@2x.png);\n  background-repeat: no-repeat;\n  background-size: 8em;\n}\n:host ul {\n  padding: 0;\n  margin: auto 0.8em;\n  padding-bottom: 4em;\n}\n:host ul li {\n  padding: 0.9em 0.4em;\n  display: block;\n  list-style-type: none;\n  position: relative;\n  cursor: pointer;\n  outline: none;\n  -webkit-transition: background-color 200ms linear;\n  transition: background-color 200ms linear;\n  font-size: 0.9em;\n  -webkit-transition: all 200ms linear;\n  transition: all 200ms linear;\n  width: 100%;\n  font-size: 0.83em;\n}\n@media (max-height: 690px) {\n  :host ul li {\n    padding: 0.5em 0.4em;\n  }\n}\n:host ul li .logo {\n  width: 4em;\n  height: auto;\n  margin: auto;\n}\n:host ul li:before {\n  background: #e8e8e8;\n}\n:host ul li .icon {\n  font-size: 1em;\n}\n:host ul li a {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  padding: 0.5em;\n  position: relative;\n  color: #707070;\n  text-align: center;\n  width: 100%;\n  border-radius: 8px;\n}\n:host ul li a .icon,\n:host ul li a span {\n  display: block;\n  opacity: 1;\n}\n:host ul li a .icon {\n  padding-bottom: 0.6em;\n  margin: auto;\n  width: -webkit-fit-content;\n  width: -moz-fit-content;\n  width: fit-content;\n}\n:host ul li a .icon.on {\n  display: none;\n  fill: var(--text-color);\n}\n:host ul li a .icon.of {\n  fill: #707070;\n}\n:host ul li:hover, :host ul li.active {\n  color: var(--navbar-icon-selected);\n}\n:host ul li:hover .icon, :host ul li.active .icon {\n  fill: var(--navbar-icon-selected);\n}\n:host ul li:hover span, :host ul li.active span {\n  color: var(--navbar-icon-selected);\n  font-weight: bold;\n}\n:host ul li:hover a, :host ul li.active a {\n  text-decoration: none;\n}\n:host ul li:hover a:not(.logo-anchor), :host ul li.active a:not(.logo-anchor) {\n  background: var(--navbar-selected-bg-color);\n}\n:host ul li:hover a:not(.logo-anchor) .icon, :host ul li.active a:not(.logo-anchor) .icon {\n  color: var(--text-color);\n}\n:host ul li:hover a .icon.off, :host ul li.active a .icon.off {\n  display: none;\n}\n:host ul li:hover a .icon.on, :host ul li.active a .icon.on {\n  display: inline-block;\n}\n:host ul li:hover span, :host ul li.active span {\n  color: var(--text-color);\n}\n:host ul li.active {\n  font-weight: 500;\n}\n:host .bottom-links {\n  position: absolute;\n  bottom: 0em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  left: 0;\n  right: 0;\n  margin: auto;\n  padding: 0 0.6em;\n  height: 5em;\n  background: var(--sidebar-background);\n}\n:host .bottom-links .link {\n  margin: auto;\n}\n:host .bottom-links .link .icon {\n  color: var(--text-color);\n}\nhtml[lang=ar] :host {\n  left: auto;\n  right: 0;\n  border-left: 1px solid var(--app-borders);\n}\nhtml[lang=ar] :host .nav-content {\n  margin-right: -25%;\n  margin-left: auto;\n}\nhtml[lang=ar] :host ul li {\n  font-size: 0.77em;\n}\nhtml[data-theme=dark] :host .logo-anchor.christmas-logo {\n  background: url(https://anghamiwebcdn.akamaized.net/web/assets/img/logo-christmas-dark@2x.png);\n  background-repeat: no-repeat;\n  background-size: 8em;\n}"

/***/ }),

/***/ "./src/app/core/components/navbar/navbar.component.ts":
/*!************************************************************!*\
  !*** ./src/app/core/components/navbar/navbar.component.ts ***!
  \************************************************************/
/*! exports provided: NavbarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavbarComponent", function() { return NavbarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");









let NavbarComponent = class NavbarComponent {
    constructor(myElement, store, _cookieService, cdr) {
        this.myElement = myElement;
        this.store = store;
        this._cookieService = _cookieService;
        this.cdr = cdr;
        this.isDesktopClient = false;
        this.showChristmasLogo = false;
        this.downloadsPageLink = '/downloads';
        this.imagesCdnPath = `${_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].assetsCDN}img/`;
    }
    ngOnDestroy() {
    }
    ngOnInit() {
        this.isDesktopClient = !!window['desktopClient'];
        if (this.isDesktopClient) {
            this.downloadsPageLink = '/desktop-downloads';
        }
        this.selectedLang = this._cookieService.get('userlanguageprod')
            ? this._cookieService.get('userlanguageprod')
            : 'en';
        // Keep it in case we want to add another icon
        // this.country = this._cookieService.get('country');
        // this.setChristmasHat();
        // if (this.country === undefined || this.country === null) {
        //   this.getUserInfo().subscribe(data => {
        //     if (data && data !== null && data.anid) {
        //       this.country = data.usercountry;
        //       this.setChristmasHat();
        //     }
        //   })
        // }
    }
    setChristmasHat() {
        if (this.country === "LB" || this.country === "PS" || this.country === "JO" || this.country === "SY") {
            this.showChristmasLogo = true;
        }
        else {
            this.showChristmasLogo = false;
        }
    }
    getUserInfo() {
        return this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_7__["getUser"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["filter"])(data => data !== null), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1));
    }
    trackAmplitudeEvents(pageName) {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_5__["AmplitudeEvents"].navbarOpenPage,
            props: {
                page_name: pageName ? pageName : ''
            }
        }));
    }
};
NavbarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'anghami-navbar',
        template: __webpack_require__(/*! raw-loader!./navbar.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/navbar/navbar.component.html"),
        host: { id: 'ang-nav' },
        styles: [__webpack_require__(/*! ./navbar.component.scss */ "./src/app/core/components/navbar/navbar.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
        ngx_cookie__WEBPACK_IMPORTED_MODULE_4__["CookieService"],
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ChangeDetectorRef"]])
], NavbarComponent);



/***/ }),

/***/ "./src/app/core/components/navbar/navbar.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/components/navbar/navbar.module.ts ***!
  \*********************************************************/
/*! exports provided: NavbarModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavbarModule", function() { return NavbarModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _components_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/navbar/navbar.component */ "./src/app/core/components/navbar/navbar.component.ts");
/* harmony import */ var _components_anghami_plus_button_anghami_plus_button_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/anghami-plus-button/anghami-plus-button.module */ "./src/app/core/components/anghami-plus-button/anghami-plus-button.module.ts");
/* harmony import */ var ngx_scrollbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-scrollbar */ "./node_modules/ngx-scrollbar/fesm2015/ngx-scrollbar.js");








let NavbarModule = class NavbarModule {
};
NavbarModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"],
            _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_4__["IconModule"],
            _components_anghami_plus_button_anghami_plus_button_module__WEBPACK_IMPORTED_MODULE_6__["AnghamiPlusButtonModule"],
            ngx_scrollbar__WEBPACK_IMPORTED_MODULE_7__["NgScrollbarModule"]
        ],
        declarations: [_components_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_5__["NavbarComponent"]],
        exports: [_components_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_5__["NavbarComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], NavbarModule);



/***/ }),

/***/ "./src/app/core/components/onboarding/onboarding.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/core/components/onboarding/onboarding.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".onboarding-modal-parent {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  height: 100%;\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  top: 0;\n  left: 0;\n  z-index: 1005;\n  background-color: rgba(0, 0, 0, 0.6);\n}\n\n.onboarding-modal {\n  width: 50%;\n  min-width: 50rem;\n  background-color: #fff;\n  border-radius: 12px;\n  z-index: 10001;\n  text-align: center;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  padding-bottom: 1rem;\n}\n\n.navigation-dots-parent {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-top: 21px;\n}\n\n.navigation-dots-parent .navigation-dot {\n  width: 8px;\n  height: 8px;\n  background-color: #8d00f2;\n  border-radius: 50%;\n  margin-right: 10px;\n  opacity: 0.15;\n}\n\n.navigation-dots-parent .clickable {\n  opacity: 1 !important;\n  cursor: pointer;\n}\n\n.onboarding-title {\n  font-size: 1.75rem;\n  color: #000;\n  margin-top: 1.75rem;\n}\n\n.onboarding-subtitle {\n  font-size: 1rem;\n  color: #484848;\n}\n\n.onboarding-content-1 {\n  width: 36rem;\n  margin-left: auto;\n  margin-right: auto;\n  margin-top: 6rem;\n  padding-bottom: 1rem;\n  border-bottom: solid 1px #f0f0f0;\n}\n\n.onboarding-content-1 .profile-pic-camera {\n  cursor: pointer;\n  position: absolute;\n  width: 2.3rem;\n  height: 2.3rem;\n  top: 6rem;\n  left: 11rem;\n}\n\n.onboarding-content-1 .profile-pic {\n  height: 8.75rem;\n  width: 8.75rem;\n  border-radius: 50%;\n}\n\n.onboarding-content-1 .name-input {\n  width: 19rem;\n  height: 2.875rem;\n  border-radius: 1.5rem;\n  border: solid 1px #d8d8d8;\n  text-align: center;\n}\n\n.onboarding-content-1 .name-input-error {\n  border: solid 1px #dc3545;\n}\n\n.input-label {\n  font-size: 1rem;\n  color: #000;\n  text-align: left;\n  font-weight: bold;\n}\n\n.onboarding-content-2 {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin-top: 3rem;\n}\n\n.onboarding-content-2 img {\n  width: 14rem;\n}\n\n.onboarding-content-2 .dob-input {\n  width: 5.75rem;\n  height: 3.125rem;\n  border-radius: 1.5rem;\n  border: solid 1.5px #d8d8d8;\n  margin-right: 0.75rem;\n  margin-top: 2rem;\n  text-align: center;\n}\n\n.onboarding-content-2 .dob-input-error {\n  border: solid 1.5px #dc3545;\n}\n\n.onboarding-content-3 {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin-top: 3rem;\n  margin-bottom: 3rem;\n}\n\n.onboarding-content-3 img {\n  width: 10rem;\n}\n\n.onboarding-content-3 .radio-btn-container {\n  /* The container */\n  margin-top: 3rem;\n  /* Hide the browser's default radio button */\n  /* Create a custom radio button */\n  /* On mouse-over, add a grey background color */\n  /* When the radio button is checked, add a blue background */\n  /* Create the indicator (the dot/circle - hidden when not checked) */\n  /* Show the indicator (dot/circle) when checked */\n  /* Style the indicator (dot/circle) */\n}\n\n.onboarding-content-3 .radio-btn-container .container {\n  display: block;\n  position: relative;\n  padding-left: 2rem;\n  margin-bottom: 0.75rem;\n  cursor: pointer;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n}\n\n.onboarding-content-3 .radio-btn-container .container input {\n  position: absolute;\n  opacity: 0;\n  cursor: pointer;\n}\n\n.onboarding-content-3 .radio-btn-container .checkmark {\n  position: absolute;\n  top: 0;\n  left: 0;\n  height: 1.125rem;\n  width: 1.125rem;\n  background-color: #ffffff;\n  border: solid 1px #000;\n  border-radius: 50%;\n}\n\n.onboarding-content-3 .radio-btn-container .container:hover input ~ .checkmark {\n  background-color: #ffffff;\n}\n\n.onboarding-content-3 .radio-btn-container .container input:checked ~ .checkmark {\n  background-color: #ffffff;\n}\n\n.onboarding-content-3 .radio-btn-container .checkmark:after {\n  content: \"\";\n  position: absolute;\n  display: none;\n}\n\n.onboarding-content-3 .radio-btn-container .container input:checked ~ .checkmark:after {\n  display: block;\n}\n\n.onboarding-content-3 .radio-btn-container .container .checkmark:after {\n  top: 2px;\n  left: 2px;\n  width: 0.75rem;\n  height: 0.75rem;\n  border-radius: 50%;\n  background: #8d00f2;\n}\n\n.onboarding-content-4 .search-artists-container {\n  width: 100%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n\n.onboarding-content-4 .search-artists-container input {\n  border-radius: 2.625rem;\n  border: solid 1px #d8d8d8;\n  width: 13.2rem;\n  text-align: center;\n  margin-top: 1rem;\n  margin-bottom: 1rem;\n}\n\n.onboarding-content-4 .onboarding-artists-container {\n  height: 14rem;\n  overflow-y: auto;\n  width: 100%;\n}\n\n.onboarding-content-4 .onboarding-artists-container .onboarding-artists {\n  display: inline-block;\n  margin: 0.5rem;\n}\n\n.onboarding-content-4 .onboarding-artists-container .onboarding-artists .onboarding-artists-img {\n  position: relative;\n  border-radius: 50%;\n  height: 5.75rem;\n  width: 5.75rem;\n}\n\n.onboarding-content-4 .onboarding-artists-container .onboarding-artists .onboarding-artists-img .onboarding-artists-img-check {\n  position: absolute;\n  width: 1.125rem;\n  height: 1.125rem;\n  right: 0;\n}\n\n.onboarding-content-4 .onboarding-artists-container .onboarding-artists .onboarding-artists-name {\n  font-size: 0.625rem;\n  color: #000;\n}\n\n.onboarding-content-4 .onboarding-selected-artists-parent {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n}\n\n.onboarding-content-4 .onboarding-selected-artists-parent .onboarding-selected-artists {\n  font-size: 0.625rem;\n  color: #000;\n  padding: 0.625rem;\n  background: rgba(181, 181, 181, 0.3);\n  border-radius: 0.25rem;\n  font-weight: 400;\n  margin-left: 0.25rem;\n  margin-right: 0.25rem;\n  margin-top: 0.5rem;\n}\n\n.onboarding-content-4 .onboarding-selected-artists-parent .onboarding-selected-artists .close-icon-parent {\n  height: 1.5em;\n  width: 1.5em;\n  background-color: white;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  border-radius: 50%;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  float: right;\n  margin-left: 0.5rem;\n}\n\n.onboarding-content-4 .onboarding-selected-artists-parent .onboarding-selected-artists .close-icon-parent .close-icon {\n  height: 1.5em;\n  width: 1.5em;\n}\n\n.onboarding-content-5 {\n  height: 18rem;\n  overflow-y: auto;\n  width: 100%;\n}\n\n.onboarding-content-5 .onboarding-genres-parent {\n  display: inline-block;\n  margin: 0.5rem;\n  position: relative;\n}\n\n.onboarding-content-5 .onboarding-genres-parent .onboarding-genres-check {\n  position: absolute;\n  width: 1.125rem;\n  height: 1.125rem;\n  right: -0.5rem;\n  top: -0.5rem;\n}\n\n.onboarding-content-5 .onboarding-genres-parent .onboarding-genres {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  height: 4.75rem;\n  width: 10.25rem;\n  border-radius: 0.4125rem;\n  color: #fff;\n  background-size: 100%;\n  -webkit-transition: background-size 0.5s;\n  transition: background-size 0.5s;\n}\n\n.onboarding-content-5 .onboarding-genres-parent .onboarding-genres:hover {\n  background-size: 105%;\n}\n\n.onboarding-content-6 {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin-top: 5rem;\n  margin-bottom: 4rem;\n}\n\n.onboarding-content-6 .onboarding-display-mode {\n  position: relative;\n}\n\n.onboarding-content-6 .onboarding-display-mode .onboarding-display-check {\n  position: absolute;\n  right: 0.5rem;\n  top: -0.5rem;\n  width: 1.875rem;\n  height: 1.875rem;\n}\n\n.onboarding-content-6 .onboarding-display-mode .onboarding-display-img {\n  cursor: pointer;\n  width: 12.5rem;\n  margin-right: 1rem;\n  margin-left: 1rem;\n}\n\n.onboarding-content-7 {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 32rem;\n  margin-top: 3rem;\n  margin-bottom: 3rem;\n}\n\n.onboarding-content-7 img {\n  width: 14rem;\n}\n\n.onboarding-content-7 .import-container {\n  width: 100%;\n  margin-top: 2rem;\n  padding-left: 2rem;\n  text-align: left;\n  color: #000;\n  font-size: 1rem;\n}\n\n.onboarding-content-7 .import-container .import-icon {\n  width: 1.75rem;\n  margin-right: 0.625rem;\n}\n\n.onboarding-content-8 .onboarding-install-img {\n  width: 24rem;\n}\n\n.onboarding-next-btn {\n  background-color: #8d00f2;\n  color: #fff;\n  border-radius: 1.375rem;\n  border: none;\n  width: 14rem;\n  height: 2.75rem;\n  margin-top: 2rem;\n}\n\n.onboarding-next-btn:disabled {\n  background-color: var(--disabled);\n}\n\n.onboarding-skip {\n  font-size: 0.75rem;\n  color: #707070;\n  text-decoration: underline;\n  margin-top: 0.75rem;\n  cursor: pointer;\n}\n\n.error-msg {\n  text-align: center;\n  color: #dc3545;\n  padding-top: 1rem;\n}\n\n.cursor-pointer {\n  cursor: pointer;\n}"

/***/ }),

/***/ "./src/app/core/components/onboarding/onboarding.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/core/components/onboarding/onboarding.component.ts ***!
  \********************************************************************/
/*! exports provided: OnboardingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OnboardingComponent", function() { return OnboardingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_redux_actions_layout_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/layout.actions */ "./src/app/core/redux/actions/layout.actions.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_services_onboarding_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/onboarding.service */ "./src/app/core/services/onboarding.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
















let OnboardingComponent = class OnboardingComponent {
    constructor(_onboardingService, _translationService, utils, store, changeDetectorRef) {
        this._onboardingService = _onboardingService;
        this._translationService = _translationService;
        this.utils = utils;
        this.store = store;
        this.changeDetectorRef = changeDetectorRef;
        this.onboardingPosition = 0;
        this.onboardingAssetsEnv = `${_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].assetsCDN}img/onboarding/`;
        this.suggestedArtists = [];
        this.suggestedArtistsPageNum = 0;
        this.moreSuggestedArtists = true;
        this.selectedArtists = [];
        this.isSelectedArtistsValid = true;
        this.ignoredArtists = [];
        this.selectedGenres = [];
        this.isSelectedGenresValid = true;
        this.isFirstNameEmpty = false;
        this.isLastNameEmpty = false;
        this.dob = {
            day: '',
            month: '',
            year: ''
        };
        this.isDOBDayEmpty = false;
        this.isDOBMonthEmpty = false;
        this.isDOBYearEmpty = false;
        this.amplitudePageLookup = {
            '1': {
                type: 'welcome',
                title: 'Welcome to Anghami!',
                button_text: 'Get started',
                skip_text: 'Skip for now'
            },
            '2': {
                type: 'dob',
                title: 'Welcome to Anghami!',
                button_text: 'Choose your music',
                skip_text: 'Skip for now'
            },
            '3': {
                type: 'music preferences',
                title: 'Who are you favorite artists?',
                button_text: 'Get started',
                skip_text: 'Skip for now'
            },
            '4': {
                type: 'artists',
                title: 'What music do you like the most?',
                button_text: 'Pick 3 artists',
                skip_text: 'Skip for now'
            },
            '5': {
                type: 'pdj',
                title: 'What kind of music do you like?',
                button_text: 'Next',
                skip_text: 'Skip for now'
            },
            '6': {
                type: 'theme',
                title: 'Choose your theme',
                button_text: 'Next',
                skip_text: 'Skip for now'
            },
            '7': {
                type: 'import',
                title: 'One last step',
                button_text: 'Next',
                skip_text: 'Skip for now'
            },
            '8': {
                type: 'desktop',
                title: 'Here’s an extra tip!',
                button_text: 'Download Anghami for Mac',
                skip_text: 'Skip for now'
            }
        };
    }
    ngOnInit() {
        this.isDesktopClient = !!window['desktopClient'];
        this.firstNamePlaceholder = this._translationService.instant('firstname_placeholder');
        this.lastNamePlaceholder = this._translationService.instant('lastname_placeholder');
        this.pickTranslation = this._translationService.instant('onboarding_pick');
        this.artistsTranslation = this._translationService.instant('onboarding_artists');
        this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_9__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__["getUser"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["take"])(1))
            .subscribe(res => {
            this.locale = res.language;
            this.firstName = res.fname;
            this.lastName = res.lname;
            this.musiclanguage = res.musiclanguage.toString();
            this.darkmode = res.darkmode;
            this.picture = res.picture;
            this.onboarding_pages = res.onboarding_pages ? res.onboarding_pages
                .split(',')
                .map(x => parseInt(x, 10)) : [];
            if (this.isDesktopClient || (this.utils.getOperatingSystemName() !== 'MacOS' && this.utils.getOperatingSystemName() !== 'Windows')) {
                // Removes 'Download desktop app' onboarding page for people already on the desktop app or on non-supported platforms
                this.onboarding_pages.pop();
            }
            this.pagesFilled = Array(this.onboarding_pages.length).fill(false);
            this.isNewUser = this.firstName === '';
            this.isOldUser = !this.isNewUser;
            if (res.birthdate) {
                let birthdate = res.birthdate.split('-');
                this.dob.year = birthdate[0];
                this.dob.month = birthdate[1];
                this.dob.day = birthdate[2];
            }
            this.onboardingPageID = this.onboarding_pages[this.onboardingPosition];
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
                name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_13__["AmplitudeEvents"].onboarding_started,
                props: {
                    onboarding_pages: this.onboarding_pages
                }
            }));
            this.getFollowedArtists();
            if (this.onboardingPageID === 5) {
                this.getSuggestedGenres();
            }
            if (this.onboardingPageID === 4) {
                this.grabSuggestedArtists(0);
            }
        });
    }
    ngAfterViewInit() {
        this.handleTextReplacement();
    }
    nextPage() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_13__["AmplitudeEvents"].onboarding_next,
            props: Object.assign({}, this.amplitudePageLookup[this.onboardingPageID])
        }));
        const currentPos = this.onboardingPageID;
        const nextPageExists = this.onboarding_pages[this.onboarding_pages.length - 1] != currentPos;
        this.pagesFilled[this.onboardingPosition] = true;
        if (nextPageExists) {
            if (currentPos === 1) {
                //If user is on welcome page and name input is valid move to next page
                if (this.isValid('name')) {
                    this.updateUserProfile();
                    this.handleGenresOrArtistsNextPage(this.onboarding_pages[this.onboardingPosition + 1]);
                    this.onboardingPosition++;
                }
            }
            else if (currentPos === 2) {
                //If user is on birthdate page and birthdate input is valid update profile
                if (this.isValid('birthdate')) {
                    this.updateUserProfile();
                    this.handleGenresOrArtistsNextPage(this.onboarding_pages[this.onboardingPosition + 1]);
                    this.onboardingPosition++;
                }
            }
            else if (currentPos === 3) {
                //If user is on music selection page, set musiclang to 0 or the user choice if he chooses anything
                this.musiclanguage = !!this.musiclanguage ? this.musiclanguage : '0';
                this.setMusicLanguage(this.musiclanguage);
                this.handleGenresOrArtistsNextPage(this.onboarding_pages[this.onboardingPosition + 1]);
                this.onboardingPosition++;
            }
            else if (currentPos === 5) {
                //If user is on genres page, if enough genres are followed move forward
                if (this.isValid('genres')) {
                    this.handleGenresOrArtistsNextPage(this.onboarding_pages[this.onboardingPosition + 1]);
                    this.onboardingPosition++;
                }
            }
            else if (currentPos === 4) {
                //If user is on artists page, if enough artists are followed move forward
                if (this.isValid('artists')) {
                    this.followArtists();
                    this.handleGenresOrArtistsNextPage(this.onboarding_pages[this.onboardingPosition + 1]);
                    this.onboardingPosition++;
                }
            }
            else {
                //pages 6,7, and 8 require no validation logic so we just move forward
                this.onboardingPosition++;
                this.handleGenresOrArtistsNextPage(this.onboarding_pages[this.onboardingPosition + 1]);
            }
        }
        else {
            //end onboarding
            this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_2__["UpdateOnboardingValue"](false));
        }
        this.onboardingPageID = this.onboarding_pages[this.onboardingPosition];
        //check if any PO text needs replacing, setTimeout is used so rendering occurs and the function is called at next tick
        setTimeout(() => {
            this.handleTextReplacement();
        }, 0);
    }
    goToPageFromNavigation(pageNumber, idx) {
        if (this.pagesFilled[idx]) {
            this.onboardingPageID = pageNumber;
            this.onboardingPosition = this.onboarding_pages.indexOf(this.onboardingPageID);
            setTimeout(() => {
                this.handleTextReplacement();
            }, 0);
        }
    }
    handleGenresOrArtistsNextPage(nextPage) {
        //checks if next page require an API call to grab data and sends the API call
        if (nextPage === 4) {
            this.grabSuggestedArtists(0);
        }
        else if (nextPage === 5) {
            this.getSuggestedGenres();
        }
    }
    handleTextReplacement() {
        if (this.isOldUser && this.onboardingPageID === 1) {
            this.replacei18n('#username#', this.firstName, 'username-title');
        }
    }
    setMusicLanguage(musiclang) {
        this._onboardingService
            .setMusicLanguage(musiclang)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["take"])(1))
            .subscribe(response => {
            //console.log(response);
        });
    }
    grabSuggestedArtists(pagenum) {
        if (this.moreSuggestedArtists || pagenum === 0) {
            this._onboardingService
                .getSuggestedArtists(this.musiclanguage.toString(), pagenum.toString(), this.ignoredArtists.toString(), this.selectedGenres.toString())
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["take"])(1))
                .subscribe(response => {
                if (!!response) {
                    this.suggestedArtists = this.suggestedArtists.concat(response.sections[0].data);
                    this.moreSuggestedArtists = !!response.sections[0].moreData;
                    this.changeDetectorRef.detectChanges();
                }
            });
        }
    }
    searchArtist(event) {
        clearTimeout(this.tabSearchTimeout);
        //if search item is erased reload view
        if (event.target.value === '') {
            this.suggestedArtists = [];
            this.grabSuggestedArtists(0);
        }
        else {
            this.tabSearchTimeout = setTimeout(() => {
                this._onboardingService
                    .getTabSearch(this.musiclanguage.toString(), this.searchQuery)
                    .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["take"])(1))
                    .subscribe(response => {
                    if (!!response) {
                        this.suggestedArtists = response.sections[0].data.map(section => {
                            section.Name = section.name;
                            section.CoverArt = section.ArtistArt;
                            return section;
                        });
                    }
                });
            }, 500);
        }
    }
    getFollowedArtists() {
        this._onboardingService
            .getFollowedArtists()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["take"])(1))
            .subscribe(response => {
            this.followedArtistsObject = response.sections[0].data.reduce((obj, item) => {
                obj[item.id] = item;
                return obj;
            }, {});
            this.followsEnoughArtists =
                Object.keys(this.followedArtistsObject).length >= 3;
            this.updateRemainingArtistsRequired();
        });
    }
    getSuggestedGenres() {
        this._onboardingService
            .getSuggestedGenres(this.musiclanguage)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["take"])(1))
            .subscribe(response => {
            this.suggestedGenres = response.sections[0].data;
            this.selectedGenres = this.suggestedGenres
                .filter((value, index, arr) => {
                return value.followed === 1;
            })
                .map((value, index, array) => {
                return value.id;
            });
            this.changeDetectorRef.detectChanges();
        });
    }
    setDOB(event) { }
    updateUserProfile() {
        const params = {
            firstname: this.firstName,
            lastname: this.lastName,
            birthdate: this.dob.year === '' || this.dob.month === '' || this.dob.day === ''
                ? null
                : this.dob.year + '-' + this.dob.month + '-' + this.dob.day,
            imageurl: this.pictureUploadURL ? this.pictureUploadURL : null
        };
        this._onboardingService
            .updateProfile(params)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["take"])(1))
            .subscribe(response => {
            //console.log(response);
        });
    }
    followArtists() {
        const selectedArtistIDs = this.selectedArtists.map((value, index, array) => {
            return value.id;
        });
        this._onboardingService
            .followArtists(selectedArtistIDs.toString())
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["take"])(1))
            .subscribe(response => {
            //console.log(response);
        });
    }
    selectArtist(item) {
        if (!this.followedArtistsObject[item.id]) {
            this.followedArtistsObject[item.id] = item;
            this.updateRemainingArtistsRequired();
            this.selectedArtists.push(item);
            if (Object.keys(this.followedArtistsObject).length >= 3) {
                this.isSelectedArtistsValid = true;
            }
        }
        else {
            this.unfollowArtist(item);
        }
    }
    unfollowArtist(item) {
        let artistIndex = this.selectedArtists.indexOf(item);
        if (artistIndex === -1) {
            this._onboardingService
                .unfollowArtist(item.id)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["take"])(1))
                .subscribe(response => {
                //console.log(response);
            });
        }
        else {
            this.selectedArtists.splice(artistIndex, 1);
        }
        delete this.followedArtistsObject[item.id];
        this.updateRemainingArtistsRequired();
    }
    selectGenre(item) {
        if (item.followed !== 1) {
            item.followed = 1;
            this.selectedGenres.push(item.id);
            if (this.selectedGenres.length >= 1) {
                this.isSelectedGenresValid = true;
            }
        }
        else {
            item.followed = 0;
            this.selectedGenres.splice(this.selectedGenres.indexOf(item.id), 1);
        }
    }
    toggleDarkMode(val) {
        this.darkmode = val ? '1' : '0';
        this.store.dispatch(new _anghami_redux_actions_layout_actions__WEBPACK_IMPORTED_MODULE_5__["ToggleDarkmode"]({ value: val }));
    }
    showMoreSuggestedArtists() {
        this.suggestedArtistsPageNum++;
        this.ignoredArtists = this.suggestedArtists
            .filter((value, index, arr) => {
            return this.selectedArtists.indexOf(value) === -1;
        })
            .map((value, index, array) => {
            return value.id;
        });
        this.grabSuggestedArtists(this.suggestedArtistsPageNum);
    }
    isValid(input) {
        if (input === 'name') {
            this.isFirstNameEmpty = false;
            this.isLastNameEmpty = false;
            if (this.firstName === '') {
                this.isFirstNameEmpty = true;
            }
            if (this.lastName === '') {
                this.isLastNameEmpty = true;
            }
            if (this.isLastNameEmpty || this.isFirstNameEmpty) {
                return false;
            }
            else {
                return true;
            }
        }
        if (input === 'birthdate') {
            this.isDOBDayEmpty = false;
            this.isDOBMonthEmpty = false;
            this.isDOBYearEmpty = false;
            if (this.dob.day === '') {
                this.isDOBDayEmpty = true;
            }
            if (this.dob.month === '') {
                this.isDOBMonthEmpty = true;
            }
            if (this.dob.year === '') {
                this.isDOBYearEmpty = true;
            }
            if (this.isDOBDayEmpty || this.isDOBMonthEmpty || this.isDOBYearEmpty) {
                return false;
            }
            else {
                return true;
            }
        }
        if (input === 'artists') {
            this.isSelectedArtistsValid = true;
            if (Object.keys(this.followedArtistsObject).length < 3) {
                this.isSelectedArtistsValid = false;
            }
            return this.isSelectedArtistsValid;
        }
        if (input === 'genres') {
            const genreCount = this.suggestedGenres.reduce((initialValue, currentValue) => {
                if (currentValue.followed === 1) {
                    return initialValue + 1;
                }
                else {
                    return initialValue;
                }
            }, 0);
            this.isSelectedGenresValid = true;
            if (genreCount < 1) {
                this.isSelectedGenresValid = false;
            }
            return this.isSelectedGenresValid;
        }
    }
    skipStep() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_13__["AmplitudeEvents"].onboarding_skipped,
            props: Object.assign({}, this.amplitudePageLookup[this.onboardingPageID])
        }));
        this.pagesFilled[this.onboardingPosition] = true;
        this.handleGenresOrArtistsNextPage(this.onboarding_pages[this.onboardingPosition + 1]);
        this.onboardingPosition++;
        this.onboardingPageID = this.onboarding_pages[this.onboardingPosition];
        //check if any PO text needs replacing, setTimeout is used so rendering occurs and the function is called at next tick
        setTimeout(() => {
            this.handleTextReplacement();
        }, 0);
    }
    uploadImage() {
        document.getElementById('uploadImageId').click();
    }
    handleImageUpload(event) {
        //console.log(event);
        if (event.preview && event.url) {
            this.picture = event.preview;
            this.pictureUploadURL = event.url;
        }
    }
    replacei18n(oldText, newText, element) {
        document.getElementById(element).innerText = document
            .getElementById(element)
            .innerText.replace(oldText, newText);
    }
    updateRemainingArtistsRequired() {
        this.remainingArtistsRequired =
            3 - Object.keys(this.followedArtistsObject).length;
        this.remainingArtistsRequiredString = `${this.pickTranslation} ${this.remainingArtistsRequired} ${this.artistsTranslation}`;
    }
    import(type) {
        if (type === 'youtube' || type === 'spotify') {
            this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_2__["ImportMusicFromSource"]({
                type: type
            }));
        }
        else if (type === 'device') {
            if (this.isDesktopClient) {
                this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_3__["MatchMusicOpenDialog"]());
            }
            else {
                this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_4__["OpenCustomDialog"]({
                    type: _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_12__["DIALOG_TYPES"].DESKTOP_IMPORT_DOWNLOAD
                }));
            }
        }
    }
};
OnboardingComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_8__["Component"])({
        selector: 'anghami-onboarding',
        template: __webpack_require__(/*! raw-loader!./onboarding.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/onboarding/onboarding.component.html"),
        styles: [__webpack_require__(/*! ./onboarding.component.scss */ "./src/app/core/components/onboarding/onboarding.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_onboarding_service__WEBPACK_IMPORTED_MODULE_7__["OnboardingService"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__["TranslateService"],
        _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_15__["UtilService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_9__["Store"],
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ChangeDetectorRef"]])
], OnboardingComponent);



/***/ }),

/***/ "./src/app/core/components/onboarding/onboarding.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/core/components/onboarding/onboarding.module.ts ***!
  \*****************************************************************/
/*! exports provided: OnBoardingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OnBoardingModule", function() { return OnBoardingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _download_app_download_app_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../download-app/download-app.module */ "./src/app/core/components/download-app/download-app.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _onboarding_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./onboarding.component */ "./src/app/core/components/onboarding/onboarding.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _upload_cover_art_upload_cover_art_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../upload-cover-art/upload-cover-art.module */ "./src/app/core/components/upload-cover-art/upload-cover-art.module.ts");








let OnBoardingModule = class OnBoardingModule {
};
OnBoardingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"], _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_6__["PipesModule"], _download_app_download_app_module__WEBPACK_IMPORTED_MODULE_1__["DownloadAppModule"], _upload_cover_art_upload_cover_art_module__WEBPACK_IMPORTED_MODULE_7__["UploadCoverArtModule"]],
        declarations: [_onboarding_component__WEBPACK_IMPORTED_MODULE_4__["OnboardingComponent"]],
        exports: [_onboarding_component__WEBPACK_IMPORTED_MODULE_4__["OnboardingComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], OnBoardingModule);



/***/ }),

/***/ "./src/app/core/directives/ad-block-detector.directive.ts":
/*!****************************************************************!*\
  !*** ./src/app/core/directives/ad-block-detector.directive.ts ***!
  \****************************************************************/
/*! exports provided: AdBlockDetectorDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdBlockDetectorDirective", function() { return AdBlockDetectorDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");














let AdBlockDetectorDirective = class AdBlockDetectorDirective {
    constructor(renderer, platformId, el, store, _translationService, _authService) {
        this.renderer = renderer;
        this.platformId = platformId;
        this.el = el;
        this.store = store;
        this._translationService = _translationService;
        this._authService = _authService;
    }
    ngAfterViewInit() {
        if (!Object(_angular_common__WEBPACK_IMPORTED_MODULE_13__["isPlatformBrowser"])(this.platformId)) {
            return;
        }
        // this.createTrap(); // Used For testing
        this.getUserSub = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__["getUser"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(2)).subscribe(data => {
            if (data) {
                if (Number(data.plantype) !== 3) {
                    // Not a plus user, check for adblockers
                    this.createTrap();
                }
            }
        });
    }
    ngOnDestroy() {
        if (this.getUserSub) {
            this.getUserSub.unsubscribe();
        }
    }
    createTrap() {
        // Add an element with classes detected by Ad-Blocker
        this.renderer.selectRootElement(this.el.nativeElement);
        const adBait = this.renderer.createElement('div');
        this.renderer.addClass(adBait, 'adsbox');
        this.renderer.addClass(adBait, 'adsBanner');
        // Set a height, and after 2 sec check if the offsetHeight of the parent element has changed
        this.renderer.setStyle(adBait, 'height', '3em');
        this.renderer.appendChild(this.el.nativeElement, adBait);
        setInterval(this.checkTrap.bind(this), 8000);
    }
    checkTrap() {
        // check if size, or visibility of the trap div have changed
        if (this.el.nativeElement && (this.el.nativeElement.offsetHeight === 0)) {
            const dialogConfig = {
                title: this._translationService.instant('adBlock_detected_title'),
                subtitle: this._translationService.instant('adBlock_detected_subTitle'),
                displaymode: 'white',
                buttontext: 'Reload',
                buttondeeplink: 'refresh',
                reporting_api: 'off',
                reporting_amplitude: 'off',
                image: `${_environments_environment__WEBPACK_IMPORTED_MODULE_10__["environment"].assetsCDN}img/dialogs/abWarning.png`,
                imagesize: 200,
                keyboard: false,
            };
            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__["OpenCustomDialog"]({
                type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_7__["DIALOG_TYPES"].CUSTOM_DATA_DIALOG,
                dialogConfig
            }));
            //
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_11__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_12__["AmplitudeEvents"].AdBlockDetected,
            }));
            // Logout User without redirecting to login
            // this.logoff();
        }
    }
    logoff() {
        const isloggedin = this._authService.isUserLoggedIn();
        if (isloggedin) {
            this.store.dispatch(new _redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_2__["Logoff"]());
        }
    }
};
AdBlockDetectorDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Directive"])({
        selector: '[adBlockDetector]'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_3__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_3__["Renderer2"],
        Object,
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ElementRef"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslateService"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"]])
], AdBlockDetectorDirective);



/***/ }),

/***/ "./src/app/core/directives/queue-button.directive.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/directives/queue-button.directive.ts ***!
  \***********************************************************/
/*! exports provided: QueueStatusDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QueueStatusDirective", function() { return QueueStatusDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/user.actions */ "./src/app/core/redux/actions/user.actions.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/redux/actions/library.actions */ "./src/app/core/redux/actions/library.actions.ts");












let QueueStatusDirective = class QueueStatusDirective {
    constructor(el, renderer, store, _translateService) {
        this.el = el;
        this.renderer = renderer;
        this.store = store;
        this._translateService = _translateService;
    }
    ngOnInit() {
        this.userSubscription$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_10__["getUser"]))
            .subscribe(user => {
            this.userId = user.userid || user.anid;
            this.updateView();
        });
        if (this.queueObject) {
            switch (this.queueObject.list_type) {
                case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].ALBUM: {
                    // Subscribe to liked Albums array, to when the album is liked form outside of queue
                    this.likedAlbumsSub$ = this.store
                        .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__["getLikedAlbumsHashed"]))
                        .subscribe(likedAlbumsMap => {
                        if (likedAlbumsMap) {
                            this.queueObject = Object.assign({}, this.queueObject, { liked: !!likedAlbumsMap[this.queueObject.id] });
                            this.updateView();
                        }
                    });
                    break;
                }
                case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].PLAYLIST: {
                    // Subscribe to Followed Playlists, the list is called subscribed, return only if count change
                    this.followedPlaylistsSub$ = this.store
                        .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__["getFollowedPlaylistsHashed"]))
                        .subscribe(followedPlaylistsMap => {
                        if (followedPlaylistsMap) {
                            this.queueObject = Object.assign({}, this.queueObject, { followed: !!followedPlaylistsMap[this.queueObject.id] });
                            this.updateView();
                        }
                    });
                    break;
                }
            }
        }
    }
    ngOnChanges() {
        this.updateView();
    }
    ngOnDestroy() {
        if (this.followedPlaylistsSub$) {
            this.followedPlaylistsSub$.unsubscribe();
        }
        if (this.likedAlbumsSub$) {
            this.likedAlbumsSub$.unsubscribe();
        }
        if (this.userSubscription$) {
            this.userSubscription$.unsubscribe();
        }
    }
    click() {
        if (this.queueObject) {
            if (this.queueObject.list_type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].ALBUM) {
                this.likeAlbum();
            }
            else if (this.queueObject.list_type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].PLAYLIST) {
                this.followPlaylist();
            }
        }
        else {
            this.saveCollection();
        }
    }
    updateView() {
        let newButtonText = null;
        if (this.queueObject) {
            switch (this.queueObject.list_type) {
                case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].ALBUM: {
                    newButtonText = this.queueObject.liked ? this._translateService.instant('Liked') : this._translateService.instant('Like');
                    break;
                }
                case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].PLAYLIST: {
                    if (this.queueObject.OwnerID !== this.userId) {
                        newButtonText = this.queueObject.followed
                            ? this._translateService.instant('Following')
                            : this._translateService.instant('Follow');
                    }
                    else {
                        newButtonText = null;
                    }
                    break;
                }
                default: {
                    newButtonText = this._translateService.instant('Save');
                    break;
                }
            }
        }
        else {
            newButtonText = this._translateService.instant('Save');
        }
        this.updateButton(newButtonText);
    }
    updateButton(newButtonText) {
        if (newButtonText && this.buttonText !== newButtonText) {
            this.buttonText = newButtonText;
            // removes everything inside your selected element
            this.renderer.selectRootElement(this.el.nativeElement);
            // add button text
            this.renderer.appendChild(this.el.nativeElement, this.renderer.createText(this.buttonText));
            // add css classes
            this.renderer.addClass(this.el.nativeElement, 'anghami-primary-btn');
            this.renderer.addClass(this.el.nativeElement, 'button');
            this.renderer.addClass(this.el.nativeElement, 'save');
            this.renderer.setStyle(this.el.nativeElement, 'line-height', '1em');
        }
        else if (!newButtonText) {
            // If no button to be displayed
            this.renderer.setStyle(this.el.nativeElement, 'display', 'none');
        }
    }
    followPlaylist() {
        // Optimistic Update of view
        this.queueObject = Object.assign({}, this.queueObject, { followed: !this.queueObject.followed });
        this.updateButton(this.queueObject.followed ? 'Follow' : 'Following');
        this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_11__["FollowPlaylist"]({
            item: this.queueObject
        }));
        // log action
        const eventName = this.queueObject.followed ? _enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].unfollowPlaylist : _enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].followPlaylist;
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_7__["LogAmplitudeEvent"]({
            name: eventName,
            props: {
                id: { id: this.queueObject.id }
            }
        }));
    }
    likeAlbum() {
        // Optimistic Update of view
        this.updateButton(this.queueObject.liked ? 'Like' : 'Liked');
        this.store.dispatch(new _anghami_redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_4__["LikeCollection"]({
            id: this.queueObject.id,
            type: this.queueObject.list_type,
            dislike: this.queueObject.liked ? true : false,
            extras: this.queueObject.extras,
            collection: this.queueObject
        }));
        // log action
        const eventName = this.queueObject.liked ? _enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].dislikeAlbum : _enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].likeAlbum;
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_7__["LogAmplitudeEvent"]({
            name: eventName,
            props: {
                id: { id: this.queueObject.id }
            }
        }));
    }
    saveCollection() {
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__["OpenPlaylistManager"]({
            type: 'addtoplaylist',
            tracks: this.currentPlayQueueLst
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], QueueStatusDirective.prototype, "queueObject", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], QueueStatusDirective.prototype, "currentPlayQueueLst", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('click'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", []),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
], QueueStatusDirective.prototype, "click", null);
QueueStatusDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
        selector: '[appQueueStatus]'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslateService"]])
], QueueStatusDirective);



/***/ }),

/***/ "./src/app/core/guards/auth-guard.guard.ts":
/*!*************************************************!*\
  !*** ./src/app/core/guards/auth-guard.guard.ts ***!
  \*************************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _app_core_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../app/core/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../app/core/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _app_core_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../app/core/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _app_core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../app/core/enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");








let AuthGuard = class AuthGuard {
    constructor(store, _authService) {
        this.store = store;
        this._authService = _authService;
    }
    canActivate() {
        const isLoggedin = this._authService.isUserLoggedIn();
        if (isLoggedin) {
            return true;
        }
        else {
            /*
            The purpose of this block of code is to check
            whether the user is trying to go to a login-only
            page (while logged out) from inside the player or from outside
            if the user is already in the player
            we show him a modal asking him to log in
            if the user goes straight to a login-only page
            via the URL we redirect him to our login page
            */
            this.getIsInPlayerSub$ = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__["getIsInPlayer"]))
                .subscribe(data => {
                if (data) {
                    this.store.dispatch(new _app_core_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__["OpenCustomDialog"]({
                        type: _app_core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_7__["DIALOG_TYPES"].LOGIN
                    }));
                }
                else {
                    this.store.dispatch(new _app_core_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_4__["LoginRedirect"]());
                }
                return false;
            });
        }
    }
};
AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"], _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"]])
], AuthGuard);



/***/ }),

/***/ "./src/app/core/guards/view-guard.ts":
/*!*******************************************!*\
  !*** ./src/app/core/guards/view-guard.ts ***!
  \*******************************************/
/*! exports provided: ViewGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewGuard", function() { return ViewGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _anghami_services_collection_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/collection.service */ "./src/app/core/services/collection.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");





let ViewGuard = class ViewGuard {
    constructor(router, _collectionService, platformId) {
        this.router = router;
        this._collectionService = _collectionService;
        this.platformId = platformId;
    }
    canActivate(route) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const type = route.params['collectionType'];
            const id = route.params['collectionId'];
            if (type === 'song' && Object(_angular_common__WEBPACK_IMPORTED_MODULE_4__["isPlatformBrowser"])(this.platformId)) {
                const songData = yield this._collectionService.getSongDataForReroute(id);
                if (songData.albumID && !songData.single) {
                    this.router.navigate(['/album', songData.albumID], { queryParams: Object.assign({}, route.queryParams, { songid: songData.id }) });
                }
                else {
                    return true;
                }
            }
            else {
                let canNavigate = true;
                if (type === 'artist' && id === '414') {
                    canNavigate = false;
                }
                if (id.indexOf('-') > -1 && type != "generic") {
                    const cleanId = id.split('-')[0];
                    this.router.navigate([type, cleanId], { queryParams: Object.assign({}, route.queryParams) });
                }
                if (canNavigate) {
                    return true;
                }
                else {
                    this.router.navigateByUrl('/home');
                }
            }
        });
    }
};
ViewGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _anghami_services_collection_service__WEBPACK_IMPORTED_MODULE_3__["CollectionService"],
        Object])
], ViewGuard);



/***/ }),

/***/ "./src/app/core/modules/player/buffer/buffer.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/core/modules/player/buffer/buffer.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: block;\n  width: 100%;\n  background: transparent;\n  padding-top: 1.5em;\n  position: absolute;\n  left: 0.18rem;\n  top: -1.5em;\n  -webkit-transition: 200ms all;\n  transition: 200ms all;\n}\n:host.video .cont {\n  background-color: #9ea3a5;\n}\n:host.video .cont .stream-controls.buffer {\n  background-color: #6f7171 !important;\n}\n:host .cont {\n  height: 0.2em;\n  width: 100%;\n  display: block;\n  -webkit-transition: height 200ms ease;\n  transition: height 200ms ease;\n  background: #AAA;\n  cursor: pointer;\n  position: absolute;\n  left: 0;\n  bottom: 0;\n}\n:host:hover .cont {\n  height: 0.6em;\n}\n:host:hover .cont .stream-controls.indicator {\n  width: 1.1em;\n  height: 1.1em;\n}\n:host .bar {\n  background-color: #ffffff;\n  position: relative;\n  cursor: pointer;\n}\n:host .stream-controls {\n  position: absolute;\n  right: 0em;\n  left: 0em;\n  top: 0;\n  bottom: 0;\n  user-select: none;\n  -moz-user-select: none;\n  -webkit-user-select: none;\n  -ms-user-select: none;\n  cursor: pointer;\n}\n:host .stream-controls.play {\n  background: #e1418c;\n  background: -webkit-gradient(linear, left top, right top, from(#e1418c), color-stop(45%, #92278f), to(#018af0));\n  background: linear-gradient(to right, #e1418c 0%, #92278f 45%, #018af0 100%);\n  z-index: 1;\n  -webkit-transition: width 0.1s;\n  transition: width 0.1s;\n  -webkit-transition-timing-function: linear;\n          transition-timing-function: linear;\n}\n:host .stream-controls.buffer {\n  background-color: #9ea3a5;\n}\n:host .stream-controls.indicator {\n  width: 10px;\n  height: 10px;\n  border: 1px solid #d2d0d0;\n  border-radius: 2em;\n  top: -0.3em;\n  -webkit-transform: translateX(-5px);\n      -ms-transform: translateX(-5px);\n          transform: translateX(-5px);\n  background-color: #ffffff;\n  z-index: 1;\n  cursor: pointer;\n  font-family: Arial, Helvetica, sans-serif;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s;\n  -webkit-transition-timing-function: linear;\n          transition-timing-function: linear;\n}\n:host .stream-controls.indicator .duration {\n  opacity: 0;\n}\n:host .fullsize {\n  width: 0;\n  height: 100%;\n}"

/***/ }),

/***/ "./src/app/core/modules/player/buffer/buffer.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/core/modules/player/buffer/buffer.component.ts ***!
  \****************************************************************/
/*! exports provided: BufferComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BufferComponent", function() { return BufferComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _player_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../player.service */ "./src/app/core/modules/player/player.service.ts");




let BufferComponent = class BufferComponent {
    constructor(_playingService, platformId, locale) {
        this._playingService = _playingService;
        this.platformId = platformId;
        this.locale = locale;
        this.isDragging = false;
        this.seekedPercentage = 0;
        this.isMouseClicked = false;
    }
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(this.platformId)) {
            this.isAr =
                window.document.documentElement.lang &&
                    window.document.documentElement.lang.match(/ar/i) !== null;
        }
    }
    ngOnChanges() {
        this.isVideoOrigin = (this.originType && this.originType === 'video');
    }
    doSeek(percentage) {
        if (percentage >= 0) {
            this._playingService.setNewTrackPosition(percentage);
        }
    }
    onMouseClick(eventClick) {
        this.seekedPercentage = this.progress.percentage;
        this.isMouseClicked = true;
        this.onMouseMove(eventClick);
    }
    onMouseUp() {
        if (this.isMouseClicked) {
            this.progress.percentage = this.seekedPercentage;
            this.doSeek(this.seekedPercentage);
        }
        this.isMouseClicked = false;
    }
    onMouseMove(clickEvent) {
        if (!this.isMouseClicked) {
            return;
        }
        const rect = this.parentDiv.nativeElement.getBoundingClientRect();
        if (this.locale === 'ar') {
            this.seekedPercentage = ((rect.right - clickEvent.pageX) / rect.width) * 100;
        }
        else {
            this.seekedPercentage = (clickEvent.pageX - rect.left) / rect.width * 100;
        }
        if (this.seekedPercentage > 100) {
            this.seekedPercentage = 100;
        }
        else if (this.seekedPercentage < 0) {
            this.seekedPercentage = 0;
        }
        this.progress.percentage = this.seekedPercentage;
    }
    ngOnDestroy() {
        if (this.globalListenFunc) {
            this.globalListenFunc();
        }
        if (this.globalMouseupFunc) {
            this.globalMouseupFunc();
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])('streamIndicator', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BufferComponent.prototype, "streamIndicator", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])('parentDiv', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BufferComponent.prototype, "parentDiv", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BufferComponent.prototype, "originType", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BufferComponent.prototype, "progress", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["HostBinding"])('class.video'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BufferComponent.prototype, "isVideoOrigin", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["HostListener"])('window:mouseup', ['$event']),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", []),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
], BufferComponent.prototype, "onMouseUp", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["HostListener"])('window:mousemove', ['$event']),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
], BufferComponent.prototype, "onMouseMove", null);
BufferComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'anghami-buffer',
        template: __webpack_require__(/*! raw-loader!./buffer.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/buffer/buffer.component.html"),
        styles: [__webpack_require__(/*! ./buffer.component.scss */ "./src/app/core/modules/player/buffer/buffer.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_player_service__WEBPACK_IMPORTED_MODULE_3__["PlayerService"],
        Object, String])
], BufferComponent);



/***/ }),

/***/ "./src/app/core/modules/player/buffer/buffer.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/core/modules/player/buffer/buffer.module.ts ***!
  \*************************************************************/
/*! exports provided: BufferModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BufferModule", function() { return BufferModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _buffer_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./buffer.component */ "./src/app/core/modules/player/buffer/buffer.component.ts");
/* harmony import */ var _pipes_convertDuration_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../pipes/convertDuration.pipe */ "./src/app/core/pipes/convertDuration.pipe.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");







let BufferModule = class BufferModule {
};
BufferModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModule"], _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"]],
        declarations: [_buffer_component__WEBPACK_IMPORTED_MODULE_2__["BufferComponent"]],
        exports: [_buffer_component__WEBPACK_IMPORTED_MODULE_2__["BufferComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]],
        providers: [_pipes_convertDuration_pipe__WEBPACK_IMPORTED_MODULE_3__["ConvertDurationPipe"]]
    })
], BufferModule);



/***/ }),

/***/ "./src/app/core/modules/player/effects/media.engine.effects.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/modules/player/effects/media.engine.effects.ts ***!
  \*********************************************************************/
/*! exports provided: MediaEngineEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MediaEngineEffects", function() { return MediaEngineEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");
/* harmony import */ var _player_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_services_socket_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/services/socket.service */ "./src/app/core/services/socket.service.ts");











let MediaEngineEffects = class MediaEngineEffects {
    constructor(actions$, _playerService, authService, store, socketService) {
        this.actions$ = actions$;
        this._playerService = _playerService;
        this.authService = authService;
        this.store = store;
        this.socketService = socketService;
        /**
         * To be responsable for all the media engine actions
         */
        this.removeTrackFromQueue$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].RemoveTrackFromQueue), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(action => {
            const engPlayer = this._playerService.angPlayer;
            if (!engPlayer) {
                // if the player is not initialized yet
                return;
            }
            this._playerService.angPlayer.removeFromQueue(action.payload);
        }));
        this.playTrackEngine$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].PlayTrackEngine), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((action) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const playload = action.payload;
            console.log('playload: ', playload);
            const engPlayer = this._playerService.angPlayer;
            if (!this.authService.isUserLoggedIn() && !window['desktopClient'].offlineMode) {
                this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["OpenCustomDialog"]({
                    type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_8__["DIALOG_TYPES"].LOGIN
                }));
            }
            if (!engPlayer) {
                // if the player is not initialized yet
                return;
            }
            const currentQueue = engPlayer.currentQueue;
            if (!window['desktopClient'].offlineMode && (playload.queue.type === 'queue' ||
                // To check if we still in the same queue
                ((currentQueue && currentQueue.playlist && currentQueue.playlist.id) === (playload.list && playload.list.id) &&
                    !engPlayer.shuffled) && (currentQueue.songs.length === playload.queue.data.length))) {
                yield engPlayer.playIndex(playload.index);
            }
            else {
                yield engPlayer.setQueueFromSection(playload.queue, playload.index, playload.list);
            }
            if (!window['desktopClient'].offlineMode) {
                if (engPlayer.videoOn !== !!playload.isVideo) {
                    yield engPlayer.toggleVideoOn(!!playload.isVideo);
                }
                if (engPlayer.shuffled !== !!playload.shuffle) {
                    yield engPlayer.toggleShuffle(!!playload.shuffle);
                }
            }
            yield this._playerService.loadAndPlay();
        })));
        this.playTrackByIndex$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].PlayTrackByIndex), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((pl) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            console.log('pl: ', pl);
            const index = pl.payload.index;
            const engPlayer = this._playerService.angPlayer;
            yield engPlayer.playIndex(index);
            yield this._playerService.loadAndPlay();
        })));
        this.POSTPlayQueue$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].POSTPlayQueue), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((pl) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this._playerService.NEWPOSTPlayQueue();
        })));
        this.playSongEngine$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].PlaySongEngine), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((action) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const payload = action.payload;
            const engPlayer = this._playerService.angPlayer;
            if (!engPlayer) {
                // if the player is not initialized yet
                return;
            }
            yield this._playerService.angPlayer.getSong(payload.id, payload.extras);
            yield this._playerService.loadAndPlay();
        })));
        this.PlayRadioContent$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].PlayRadioContent), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])((action) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const payload = action.payload;
            const queue = yield this._playerService.NEWgetRadio(payload);
            return new _actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["PlayTrackEngine"]({
                queue: queue['sections'][0],
                list: [],
                shuffle: false,
                index: 0
            });
        })));
        this.PlayerAction$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].PlayerAction), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(payload => payload.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((payload) => {
            switch (payload.action) {
                case 'play':
                    this._playerService.NEWplay();
                    break;
                case 'pause':
                    this._playerService.NEWpause();
                    break;
                case 'playpause':
                    this._playerService.NEWplayPause();
                    break;
                case 'previous':
                    this._playerService.NEWplayPrevious();
                    break;
                case 'next':
                    this._playerService.NEWplayNext();
                    break;
                case 'shuffle':
                    this._playerService.NEWtoggleShuffle();
                    break;
                case 'repeat':
                    this._playerService.NEWtoggleRepeat();
                    break;
                case 'seek':
                    this._playerService.setNewTrackPosition(payload.data);
                    break;
                default:
                    break;
            }
        }));
        this.PlayDownloadedSong$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].PlayDownloadedSong), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(payload => payload.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((payload) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const filePath = `file://${payload.path}?ngsw-bypass=true`;
            yield this._playerService.angPlayer.load(filePath);
            this._playerService.angPlayer.play();
        })));
        this.PlayNextEngine$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].PlayNextEngine), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((action) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const payload = action.payload;
            const engPlayer = this._playerService.angPlayer;
            if (!engPlayer) {
                // if the player is not initialized yet
                return;
            }
            yield this._playerService.angPlayer.addNextToQueue(payload.track);
        })));
        this.AddToQueueEngine$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].AddToQueueEngine), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((action) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const payload = action.payload;
            yield this._playerService.addToQueue(payload.type, payload.data);
        })));
        this.GrabSodAndPlay$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].GrabSodAndPlay), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])((action) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (!window['desktopClient'].offlineMode) {
                this._playerService.NEWsetSOD(this.socketService.getSocketId());
                yield this._playerService.angMediaEng.player.getPlayQueue();
            }
            yield this._playerService.loadAndPlay();
        })));
        this.GetDownloadError$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].GetDownloadError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(action => {
            console.log('action: ', action);
            this._playerService.handleGETdownloadError(action.payload);
        }));
        this.InitEngine$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].InitEngine), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(action => {
            console.log('action: ', action);
            if (this._playerService.angPlayer) {
                // disable engine re-initing
                return;
            }
            const user = action.payload;
            this._playerService.initPlayer();
            // init the socket after the engine inited
            const interval = setInterval(() => {
                if (this._playerService.angMediaEng && this._playerService.angMediaEng.remote) {
                    this.socketService.initializeSocket(user);
                    clearInterval(interval);
                }
            });
        }));
        this.InitEngineSocket$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_4__["MediaEngineActionTypes"].InitEngineSocket), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(action => {
            const engPlayer = this._playerService.angPlayer;
            if (!engPlayer) {
                // if the player is not initialized yet
                return;
            }
            this._playerService.initRemoteInstance(window['socket'], action.payload.udid);
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "removeTrackFromQueue$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "playTrackEngine$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "playTrackByIndex$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "POSTPlayQueue$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "playSongEngine$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "PlayRadioContent$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "PlayerAction$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "PlayDownloadedSong$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "PlayNextEngine$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "AddToQueueEngine$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "GrabSodAndPlay$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "GetDownloadError$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "InitEngine$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MediaEngineEffects.prototype, "InitEngineSocket$", void 0);
MediaEngineEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"],
        _player_service__WEBPACK_IMPORTED_MODULE_5__["PlayerService"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_9__["Store"],
        _anghami_services_socket_service__WEBPACK_IMPORTED_MODULE_10__["SocketService"]])
], MediaEngineEffects);



/***/ }),

/***/ "./src/app/core/modules/player/effects/player.effects.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/modules/player/effects/player.effects.ts ***!
  \***************************************************************/
/*! exports provided: PlayerEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlayerEffects", function() { return PlayerEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs_observable_of__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/observable/of */ "./node_modules/rxjs-compat/_esm2015/observable/of.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _services_collection_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../services/collection.service */ "./src/app/core/services/collection.service.ts");
/* harmony import */ var _actions_player_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../actions/player.actions */ "./src/app/core/modules/player/actions/player.actions.ts");
/* harmony import */ var _player_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");












let PlayerEffects = class PlayerEffects {
    constructor(actions$, _playerService, store, collectionService, locale) {
        this.actions$ = actions$;
        this._playerService = _playerService;
        this.store = store;
        this.collectionService = collectionService;
        this.locale = locale;
        /*
         * since audio ads are of type mpeg means their canPlayType() result is a string 'probably',
         * we tell the media engine to force pass the mime type check (for audio ads) so durationChange can be safely called on this mpeg type
         */
        this.toggleForceDurationChangeAudioAd$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].ToggleForceDurationChangeAudioAd), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(() => {
            this._playerService.toggleForceDurationChangeAudioAd();
        }));
        this.updateAudioQuality$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].UpdateAudioQuality), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(params => {
            this._playerService.setAudioQuality(params);
        }));
        this.initPlayTrack$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].InitPlayTrack), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])((action) => {
            const pl = action.payload;
            if (pl.queue.type === 'queue') {
                this._playerService.angPlayer.playIndex(pl.index);
            }
            else {
                this._playerService.NEWsetQueueFromSection(pl);
            }
        }));
        this.SetVolume$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].SetVolume), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(data => {
            this._playerService.setVolume(data.payload);
        }));
        this.GetCollectionAutoPlay$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].GetCollectionAutoPlay), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(payload => this.collectionService.getCollectionData(payload.type, payload.id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(data => {
            const queue = data.sections.filter(section => section.displaytype === 'list' && section.type === 'song' || section.type === 'video');
            const isVideo = queue[0].type === 'video';
            let section = queue[0];
            section = Object.assign({}, section, { data: section.data.map(item => {
                    return Object.assign({}, item, { generictype: item.generictype ? item.generictype : section.type });
                }).filter(item => item.generictype === 'song' || item.generictype === 'video') });
            return Object(rxjs_observable_of__WEBPACK_IMPORTED_MODULE_4__["of"])(new _actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_11__["PlayTrackEngine"]({
                queue: section,
                list: data,
                shuffle: false,
                index: 0,
                isVideo
            }));
        }))));
        this.GetSongInfoAndPlay$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].GetSongInfoAndPlay), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(payload => {
            this._playerService.GETsong(payload.id, true);
            return Object(rxjs_observable_of__WEBPACK_IMPORTED_MODULE_4__["of"])(new _actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["UpdateQueue"]({ list: [] }));
        }));
        this.PlayGenericContent$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].PlayGenericContent), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(payload => this.collectionService.getCollectionData(payload.type, payload.id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(data => Object(rxjs_observable_of__WEBPACK_IMPORTED_MODULE_4__["of"])(new _redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_6__["SetExtras"]({
            extras: data.extras
        }), new _actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_11__["PlaySongEngine"]({
            id: data.firstsong,
            extras: data.extras
        }))))));
        this.DownloadRegisterAction$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].DownloadRegisterAction), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(payload => {
            this._playerService.downloadRegisterAction(payload.song);
        }));
        this.SendRegisterActionBatch$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].SendRegisterActionBatch), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(payload => {
            this._playerService.sendBatchedRegisterAction(payload.documents);
        }));
        this.PlayRadioContent$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].PlayRadioContent), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])((action) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const payload = action.payload;
            yield this._playerService.NEWgetRadio(payload);
            yield this._playerService.loadAndPlay();
        })));
        this.togglePlayingstatus$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].TogglePlayingStatus), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(data => {
            this._playerService.togglePlayingStatus(data);
        }));
        this.PausePlayerEngine$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].PausePlayerEngine), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(() => {
        }));
        this.OpenMiniplayer$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_player_actions__WEBPACK_IMPORTED_MODULE_8__["PlayerActionTypes"].OpenMiniplayer), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(() => {
            this._playerService.prepareMiniplayerSubscriptions();
            setTimeout(() => {
                this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_10__["EmitMessageToDesktopClient"]({
                    message: 'miniplayer-switch',
                    payload: {}
                }));
            }, 100);
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "toggleForceDurationChangeAudioAd$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "updateAudioQuality$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "initPlayTrack$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "SetVolume$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "GetCollectionAutoPlay$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "GetSongInfoAndPlay$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "PlayGenericContent$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "DownloadRegisterAction$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "SendRegisterActionBatch$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "PlayRadioContent$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "togglePlayingstatus$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "PausePlayerEngine$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerEffects.prototype, "OpenMiniplayer$", void 0);
PlayerEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"],
        _player_service__WEBPACK_IMPORTED_MODULE_9__["PlayerService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
        _services_collection_service__WEBPACK_IMPORTED_MODULE_7__["CollectionService"], String])
], PlayerEffects);



/***/ }),

/***/ "./src/app/core/modules/player/loader/loader.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/core/modules/player/loader/loader.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@-webkit-keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n:host {\n  position: absolute;\n  top: 0.6em;\n  left: 0.6em;\n  -webkit-transform: scale3d(0.5, 0.5, 0.5);\n          transform: scale3d(0.5, 0.5, 0.5);\n  -webkit-animation-name: fadeIn;\n  animation-name: fadeIn;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.3s;\n  animation-duration: 0.3s;\n  -webkit-animation-delay: 0;\n  animation-delay: 0;\n  -webkit-animation-timing-function: ease;\n  animation-timing-function: ease;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}\n:host .lds-ellipsis {\n  display: block;\n  position: relative;\n}\n:host .lds-ellipsis div {\n  position: absolute;\n  top: 27px;\n  width: 11px;\n  height: 11px;\n  border-radius: 50%;\n  background: #fff;\n  -webkit-animation-timing-function: cubic-bezier(0, 1, 1, 0);\n          animation-timing-function: cubic-bezier(0, 1, 1, 0);\n}\n:host .lds-ellipsis div:nth-child(1) {\n  left: 6px;\n  -webkit-animation: lds-ellipsis1 0.6s infinite;\n          animation: lds-ellipsis1 0.6s infinite;\n}\n:host .lds-ellipsis div:nth-child(2) {\n  left: 6px;\n  -webkit-animation: lds-ellipsis2 0.6s infinite;\n          animation: lds-ellipsis2 0.6s infinite;\n}\n:host .lds-ellipsis div:nth-child(3) {\n  left: 26px;\n  -webkit-animation: lds-ellipsis2 0.6s infinite;\n          animation: lds-ellipsis2 0.6s infinite;\n}\n:host .lds-ellipsis div:nth-child(4) {\n  left: 45px;\n  -webkit-animation: lds-ellipsis3 0.6s infinite;\n          animation: lds-ellipsis3 0.6s infinite;\n}\n@-webkit-keyframes lds-ellipsis1 {\n  0% {\n    -webkit-transform: scale(0);\n            transform: scale(0);\n  }\n  100% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n}\n@keyframes lds-ellipsis1 {\n  0% {\n    -webkit-transform: scale(0);\n            transform: scale(0);\n  }\n  100% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n}\n@-webkit-keyframes lds-ellipsis3 {\n  0% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n  100% {\n    -webkit-transform: scale(0);\n            transform: scale(0);\n  }\n}\n@keyframes lds-ellipsis3 {\n  0% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n  100% {\n    -webkit-transform: scale(0);\n            transform: scale(0);\n  }\n}\n@-webkit-keyframes lds-ellipsis2 {\n  0% {\n    -webkit-transform: translate(0, 0);\n            transform: translate(0, 0);\n  }\n  100% {\n    -webkit-transform: translate(19px, 0);\n            transform: translate(19px, 0);\n  }\n}\n@keyframes lds-ellipsis2 {\n  0% {\n    -webkit-transform: translate(0, 0);\n            transform: translate(0, 0);\n  }\n  100% {\n    -webkit-transform: translate(19px, 0);\n            transform: translate(19px, 0);\n  }\n}"

/***/ }),

/***/ "./src/app/core/modules/player/loader/loader.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/core/modules/player/loader/loader.component.ts ***!
  \****************************************************************/
/*! exports provided: LoaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoaderComponent", function() { return LoaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LoaderComponent = class LoaderComponent {
    constructor() { }
};
LoaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-loader',
        template: `<div class="lds-ellipsis">
  <div></div>
  <div></div>
  <div></div>
  <div></div>
</div>`,
        styles: [__webpack_require__(/*! ./loader.component.scss */ "./src/app/core/modules/player/loader/loader.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], LoaderComponent);



/***/ }),

/***/ "./src/app/core/modules/player/player.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/core/modules/player/player.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n@-webkit-keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@font-face {\n  font-family: VideoJS;\n  src: url(data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAA54AAoAAAAAFmgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABPUy8yAAAA9AAAAD4AAABWUZFeBWNtYXAAAAE0AAAAOgAAAUriMBC2Z2x5ZgAAAXAAAAouAAAPUFvx6AdoZWFkAAALoAAAACsAAAA2DIPpX2hoZWEAAAvMAAAAGAAAACQOogcgaG10eAAAC+QAAAAPAAAAfNkAAABsb2NhAAAL9AAAAEAAAABAMMg06m1heHAAAAw0AAAAHwAAACABMAB5bmFtZQAADFQAAAElAAACCtXH9aBwb3N0AAANfAAAAPwAAAGBZkSN43icY2BkZ2CcwMDKwMFSyPKMgYHhF4RmjmEIZzzHwMDEwMrMgBUEpLmmMDh8ZPwoxw7iLmSHCDOCCADvEAo+AAB4nGNgYGBmgGAZBkYGEHAB8hjBfBYGDSDNBqQZGZgYGD7K/f8PUvCREUTzM0DVAwEjG8OIBwCPdwbVAAB4nI1Xe1CU1xX/zv1eLItLln0JwrIfC7sJGET2hRJ2N1GUoBJE8AESQEEhmBHjaB7UuBMTO4GMaSu7aY3RNlOdRPNqO2pqRmuTaSZtR6JJILUZk00a/4imjpmiecB303O/XUgMJOPufvd+99xzzz33nN855y4HHH7EfrGfIxwHRiANvF/sH71I9BzHszmpW+rGOQOXxXE6YhI4PoMT8zkT4cDFuf1cwMrZJI5cglM0HKVv0MaUFDgIFfg9mJJCG+kbKn1JkqBOVaFOkuhLpARq8fu0Nnc9/zdvfY9PxXW4PdH0C6N+PCejhorxFjAqRjgFRXSINEARbBGsoxcFK7IJmr4OycFJnInL59zIXwxui80fkGRbEHyosMWaATJKUfCskmwJQsAWANkmnIGOhlf514h7U8HNIv3owoHB0WMt0Eb3sx0guLi5pq/8Ny1q6969fKR9X9GBV6dPv6dp04K99SOwtmyPl47ApRa6n4ZpP1yjr5fn7MmYP/vXLUJs715UguklHBaHOZHZmG1N9FAIW2mf0MqWCIdo/8RZ1yGfxKUldDcGIbFA7ICO+vqOMSPTh/ZrSqgHi/bB/O8E8Mnzp+M+acxfpsTShBwej26TiGxBn7m4eEIO+Rueu6Hj+IFBnh88cAEUEQ//nVLx5C7kf+yIR47QEe+eMlhz9SqsGbe3hh2R03NGzoY6O42Kz8l7fB6fAk6LYnTyFo/FYyT6GGyNx2Jx2sdH4rA1Fo/HyCXaFyOp8dhYBCfJb2NIn1ImE6CYNGmgSTb52DawJR6jfXEmDU4xyTEmpgHHOIStoxfjSGdkbsK2w2jbdMQG4sgAstEONgURYCwGHhEhhscioQaAhhCf7McifEQc0l6+mxj9nI+gmSdiQ0Zbm7gZnIO7GSMEXG6UDAVocxAV8GcEXCKg1a02RcTtwANWRGIAyElor6n/+ZU2yOB3+T77Hb1MLqhn4KHVnQBjJnqe9QZSon6Kc5DxAD2vMdPL/BXSmQGwspa67z9wLUjdi9TN7QC7lyyBr9rpt7uXVC1CMpyjKRoXnGPHTuiaPLsNdc2dbAFQLAooPkXEh33FodHl4XpC6sPCIa0ftUIhHSYXVSu5iME+DIXsbZJ51BeidCgajcai43jU9nVzoSn2dPqcFvSoxSzJzgRKAx47WMRxOrIj3Wf0+hndxhJTiOkSEqxar3b3RKM9hY64oxBA64ieURLvCfpkDb8siBdUJ1bgT+urJ5PGfewQrmm5R5+0HmfyIPySD7OYkT0WxRePah8oEiyjlxIP74thVoRTURpmL6QhGuWS+QDjdANXjIM8SQa/1w128ODx0Qp4aLMNg9+JL3joUn8AMxW+aLNiuKjarn4uyyTdXjOzZTsh21uwldUvJoYza+zELALfu3p1L8/3krtyZ0Ag058J3hxHghvbGZn0dHZy6Mim/7Blre4lpHd1c28yVqRViO153F2oIWoXCIKbL4Z0cM1iaQn9mI5KuV2SzEvWXJDMNtkANpMdQoDDhIdD4A/YrP6Aye9ysxyE+uOEAcTDorgvVZJjcua043PnZ/PmdDqcbibZlXOOT8uSo7Kof0YUn9GL+Jo17ficymxiTofC6znUso0DhAxs1Fo+kF+d36vLmgZ8mk5cdGv2mwYj5k3Dm9m3LhJ1aVRNm6HrTbLgYAoWXDhDd/u4PGy5CT+xGMdiaBovewUCF/1BiWNljI9MLn7jeScpg+WyH6mfU62eVDql7hsrmvx1ezp/YldE2LhjbkiDnAn8tGy/MW3IXRMYJduvq9HpmIcKuFt+JCtgdGEGKAcF6UacVwIYbVPGfw/+YuNBS4cx/CUHcnyfc+wRDMtTr72mMSBjT/yn/GKSdeDWQUCH6Xoqq5R10RE60gV6erUL0iCti16d0hZjxut4QI/rEpgSh6WjnJXdBXRg1GKCucGJPtFqM27aD1tOqqKonsQ2KsFSSmEpmvRlsR+TcD9OFwrqXxIclL4sJTnGMSuG8KpkZvKdeVIOKDyWSyPLV16/p1QMPbP8NihwUzr47bdnXtwtjdCvqqpO0H+pOvIl3Pzv46e5CT/tQjklXCXXym1AaWY7bzHLkuDMc7ldKCvgxzLn8wYkJLBhEDyK7MT8bTbwbkxbfp+3mKAGsmTBpabSIEECzMIcQlzOPAMKsxMs7uhsnxPLuofPDTc1hkuq6MX9j16YU7CqegcYHbmWYuvAP6tCS97tgWf7dlQvnl25YPavXLVZvrzQPeHCpZmzzEUVq/xzu5sChnSTPTW7oOYmh69z4zL/gk3b+O6hoa733uviP82vnFcbqWlc9tDmZa23LVzaV1yXURi+JX+28NeBuj3+O8IrQ080Vm1eWB4OKjPmrJu7c1udWynvKF6/vs479lSW9+5gZkn+dKfellNGDPllzeULustz+A0bPvhgw7lkvEUwn/N4Ty7U7nhGsEpFkOfy+kutbOh1JQxhVDJumoW11hnkPThznh6FFlhfT+ra1x9sF56kx5YuDzVY9PQYAYA7iblw4frQ4TPCk2MK/xGU3rlmze62trHz6lsko+v+So/do74PT8KVkpJfOErKcv8znrMGsHTNxoEkWy1mYgDB6XBbPaWsuiS6CryGaL6zCjaXBgvtkuyXBua1wOKnh+k7L9AvPnYWffxK18FcJbuosGf3/Jo7amY+CE1vppzY+UTrva0FXc1i55pKQ/YjVL187N5fCn1kW5uot/1hi+DiZ+5atnJR9E+prvydJ9ZZ5mwOpU5gM4KYysMBQ71UzPuMTl9QQOyUo5nwioeYCPjFklrbK6s6X+ypUZ6rum9+CZYzWRiBJfSP0xzzSmrg7f86g0DKVj/wwFzieD9rRfPGFbeKMl05pn5j9/rsQJJ2iEgRrpohlyBo3f4QK7Kl+EcAYZgAoNVmZWXK704YAa3FwBxgSGUOs5htvGRz4Sgj3yFkSJFBuv/sxu5yk998T8WDJzvv/2RX19HtTUW1S+wpKRKRjJ6zzz/1/OPdFdWGlAKbvzS4PHOtURikg9AGz0LbIB85S/cPOpoXvuue8/iV2H1vPTy3ddvOeZ37HGmO3OmSzVzR+NS53+84dHlFhXPLqtzSO+5ruHM2vXtBdxP87LOzKAD359j/INYIbyPabIi3Cq6Wa+SaGe78diIzu7qcblcAa6/fJRvNopXFJnO+U9KKM5bqH5LM0iQSVmpPCPDu7ZT4Aoubz3709EBTyrTDjyx8MQXgUH1nqm7TWng4TzE4i4AsKskBITXfSyC4Fkl5MxnJDiKSIDSJAsGvd1y+/eNDp2e+A+5d8HeiiunrTkT6TqWLIs+/QRoWr98s0qj8uuzLuS22Ytufg3rdTaHn1m46sfgGKHXt0MGnLaRHdnwN37tvHcWKo2V6lnPxL4UvUQcRdOzmZSQs8X5CH5OxXMXpkATuDz8Et0SH4uyCRR+TjmBDP1GvsVrWEGVzEj33YVQ9jAtIKpqsl/s/0xrocwAAeJxjYGRgYADig3cEzsTz23xl4GZnAIHLRucNkWl2BrA4BwMTiAIAF4IITwB4nGNgZGBgZwCChWASxGZkQAXyABOUANh4nGNnYGBgHyAMADa8ANoAAAAAAAAOAFAAZgCyAMYA5gEeAUgBdAGcAfICLgKOAroDCgOOA7AD6gQ4BHwEuAToBQwFogXoBjYGbAbaB3IHqHicY2BkYGCQZ8hlYGcAASYg5gJCBob/YD4DABbVAaoAeJxdkE1qg0AYhl8Tk9AIoVDaVSmzahcF87PMARLIMoFAl0ZHY1BHdBJIT9AT9AQ9RQ9Qeqy+yteNMzDzfM+88w0K4BY/cNAMB6N2bUaPPBLukybCLvleeAAPj8JD+hfhMV7hC3u4wxs7OO4NzQSZcI/8Ltwnfwi75E/hAR7wJTyk/xYeY49fYQ/PztM+jbTZ7LY6OWdBJdX/pqs6NYWa+zMxa13oKrA6Uoerqi/JwtpYxZXJ1coUVmeZUWVlTjq0/tHacjmdxuL90OR8O0UEDYMNdtiSEpz5XQGqzlm30kzUdAYFFOb8R7NOZk0q2lwAyz1i7oAr1xoXvrOgtYhZx8wY5KRV269JZ5yGpmzPTjQhvY9je6vEElPOuJP3mWKnP5M3V+YAAAB4nG2P2XLCMAxFfYFspGUp3Te+IB9lHJF4cOzUS2n/voaEGR6qB+lKo+WITdhga/a/bRnDBFPMkCBFhhwF5ihxg1sssMQKa9xhg3s84BFPeMYLXvGGd3zgE9tZr/hveXKVkFYoSnoeHJXfRoWOqi54mo9ameNFdrK+dLSyaVf7oJQTlkhXpD3Z5XXhR/rUfQVuKXO91Jps4cLOS6/I5YL3XhodRRsVWZe4NnZOhWnSAWgxhMoEr6SmzZieF43Mk7ZOBdeCVGrp9Eu+54J2xhySplfB5XHwQLXUmT9KH6+kPnQ7ZYuIEzNyfs1DLU1VU4SWZ6LkXGHsD1ZKbMw=) format(\"woff\"), url(data:application/x-font-ttf;charset=utf-8;base64,AAEAAAAKAIAAAwAgT1MvMlGRXgUAAAEoAAAAVmNtYXDiMBC2AAAB/AAAAUpnbHlmW/HoBwAAA4gAAA9QaGVhZAyD6V8AAADQAAAANmhoZWEOogcgAAAArAAAACRobXR42QAAAAAAAYAAAAB8bG9jYTDINOoAAANIAAAAQG1heHABMAB5AAABCAAAACBuYW1l1cf1oAAAEtgAAAIKcG9zdGZEjeMAABTkAAABgQABAAAHAAAAAKEHAAAAAAAHAAABAAAAAAAAAAAAAAAAAAAAHwABAAAAAQAAwdxheF8PPPUACwcAAAAAANMyzzEAAAAA0zLPMQAAAAAHAAcAAAAACAACAAAAAAAAAAEAAAAfAG0ABwAAAAAAAgAAAAoACgAAAP8AAAAAAAAAAQcAAZAABQAIBHEE5gAAAPoEcQTmAAADXABXAc4AAAIABQMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUGZFZABA8QHxHgcAAAAAoQcAAAAAAAABAAAAAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAAAAAMAAAADAAAAHAABAAAAAABEAAMAAQAAABwABAAoAAAABgAEAAEAAgAA8R7//wAAAADxAf//AAAPAAABAAAAAAAAAAABBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAFAAZgCyAMYA5gEeAUgBdAGcAfICLgKOAroDCgOOA7AD6gQ4BHwEuAToBQwFogXoBjYGbAbaB3IHqAABAAAAAAWLBYsAAgAAAREBAlUDNgWL++oCCwAAAwAAAAAGawZrAAIADgAaAAAJAhMEAAMSAAUkABMCAAEmACc2ADcWABcGAALrAcD+QJX+w/5aCAgBpgE9AT0BpggI/lr+w/3+rgYGAVL9/QFSBgb+rgIwAVABUAGbCP5a/sP+w/5aCAgBpgE9AT0BpvrIBgFS/f0BUgYG/q79/f6uAAAAAgAAAAAFQAWLAAMABwAAASERKQERIREBwAEr/tUCVQErAXUEFvvqBBYAAAAEAAAAAAYgBiAABgATACQAJwAAAS4BJxUXNjcGBxc+ATUmACcVFhIBBwEhESEBEQEGBxU+ATcXNwEHFwTQAWVVuAO7AidxJSgF/t/lpc77t18BYf6fASsBdQE+TF1OijuZX/1gnJwDgGSeK6W4GBhqW3FGnFT0AWM4mjT+9AHrX/6f/kD+iwH2/sI7HZoSRDGYXwSWnJwAAAEAAAAABKsF1gAFAAABESEBEQECCwEqAXb+igRg/kD+iwSq/osAAAACAAAAAAVmBdYABgAMAAABLgEnET4BAREhAREBBWUBZVRUZfwRASsBdf6LA4Bkniv9piueAUT+QP6LBKr+iwAAAwAAAAAGIAYPAAUADAAaAAATESEBEQEFLgEnET4BAxUWEhcGAgcVNgA3JgDgASsBdf6LAsUBZVVVZbqlzgMDzqXlASEFBf7fBGD+QP6LBKr+i+Bkniv9piueAvOaNP70tbX+9DSaOAFi9fUBYgAAAAQAAAAABYsFiwAFAAsAEQAXAAABIxEhNSMDMzUzNSEBIxUhESMDFTMVMxECC5YBduCWluD+igOA4AF2luDglgLr/oqWAgrglvyAlgF2AqCW4AF2AAQAAAAABYsFiwAFAAsAEQAXAAABMxUzESETIxUhESMBMzUzNSETNSMRITUBdeCW/org4AF2lgHAluD+ipaWAXYCVeABdgHAlgF2++rglgHA4P6KlgAAAAACAAAAAAXWBdYADwATAAABIQ4BBxEeARchPgE3ES4BAyERIQVA/IA/VQEBVT8DgD9VAQFVP/yAA4AF1QFVP/yAP1UBAVU/A4A/VfvsA4AAAAYAAAAABmsGawAHAAwAEwAbACAAKAAACQEmJw4BBwElLgEnAQUhATYSNyYFAQYCBxYXIQUeARcBMwEWFz4BNwECvgFkTlSH8GEBEgOONemh/u4C5f3QAXpcaAEB/BP+3VxoAQEOAjD95DXpoQESeP7dTlSH8GH+7gPwAmgSAQFYUP4nd6X2Pv4nS/1zZAEBk01NAfhk/v+TTUhLpfY+Adn+CBIBAVhQAdkAAAAFAAAAAAZrBdYADwATABcAGwAfAAABIQ4BBxEeARchPgE3ES4BASEVIQEhNSEFITUhNSE1IQXV+1ZAVAICVEAEqkBUAgJU+xYBKv7WAur9FgLqAcD+1gEq/RYC6gXVAVU//IA/VQEBVT8DgD9V/ayV/tWVlZWWlQADAAAAAAYgBdYADwAnAD8AAAEhDgEHER4BFyE+ATcRLgEBIzUjFTM1MxUUBgcjLgEnET4BNzMeARUFIzUjFTM1MxUOAQcjLgE1ETQ2NzMeARcFi/vqP1QCAlQ/BBY/VAICVP1rcJWVcCog4CAqAQEqIOAgKgILcJWVcAEqIOAgKiog4CAqAQXVAVU//IA/VQEBVT8DgD9V/fcl4CVKICoBASogASogKgEBKiBKJeAlSiAqAQEqIAEqICoBASogAAAGAAAAAAYgBPYAAwAHAAsADwATABcAABMzNSMRMzUjETM1IwEhNSERITUhERUhNeCVlZWVlZUBKwQV++sEFfvrBBUDNZb+QJUBwJX+QJb+QJUCVZWVAAAAAQAAAAAGIAZsAC4AAAEiBgcBNjQnAR4BMz4BNy4BJw4BBxQXAS4BIw4BBx4BFzI2NwEGBx4BFz4BNy4BBUArSh797AcHAg8eTixffwICf19ffwIH/fEeTixffwICf18sTh4CFAUBA3tcXHsDA3sCTx8bATcZNhkBNB0gAn9fX38CAn9fGxn+zRwgAn9fX38CIBz+yhcaXHsCAntcXXsAAAIAAAAABlkGawBDAE8AAAE2NCc3PgEnAy4BDwEmLwEuASchDgEPAQYHJyYGBwMGFh8BBhQXBw4BFxMeAT8BFh8BHgEXIT4BPwE2NxcWNjcTNiYnBS4BJz4BNx4BFw4BBasFBZ4KBgeWBxkNujpEHAMUD/7WDxQCHEU5ug0aB5UHBQudBQWdCwUHlQcaDbo5RRwCFA8BKg8UAhxFOboNGgeVBwUL/ThvlAIClG9vlAIClAM3JEokewkaDQEDDAkFSy0cxg4RAQERDsYcLUsFCQz+/QwbCXskSiR7CRoN/v0MCQVLLRzGDhEBAREOxhwtSwUJDAEDDBsJQQKUb2+UAgKUb2+UAAAAAAEAAAAABmsGawALAAATEgAFJAATAgAlBACVCAGmAT0BPQGmCAj+Wv7D/sP+WgOA/sP+WggIAaYBPQE9AaYICP5aAAAAAgAAAAAGawZrAAsAFwAAAQQAAxIABSQAEwIAASYAJzYANxYAFwYAA4D+w/5aCAgBpgE9AT0BpggI/lr+w/3+rgYGAVL9/QFSBgb+rgZrCP5a/sP+w/5aCAgBpgE9AT0BpvrIBgFS/f0BUgYG/q79/f6uAAADAAAAAAZrBmsACwAXACMAAAEEAAMSAAUkABMCAAEmACc2ADcWABcGAAMOAQcuASc+ATceAQOA/sP+WggIAaYBPQE9AaYICP5a/sP9/q4GBgFS/f0BUgYG/q4dAn9fX38CAn9fX38Gawj+Wv7D/sP+WggIAaYBPQE9Aab6yAYBUv39AVIGBv6u/f3+rgJPX38CAn9fX38CAn8AAAAEAAAAAAYgBiAADwAbACUAKQAAASEOAQcRHgEXIT4BNxEuAQEjNSMVIxEzFTM1OwEhHgEXEQ4BByE3MzUjBYv76j9UAgJUPwQWP1QCAlT9a3CVcHCVcJYBKiAqAQEqIP7WcJWVBiACVD/76j9UAgJUPwQWP1T8gpWVAcC7uwEqIP7WICoBcOAAAgAAAAAGawZrAAsAFwAAAQQAAxIABSQAEwIAEwcJAScJATcJARcBA4D+w/5aCAgBpgE9AT0BpggI/lo4af70/vRpAQv+9WkBDAEMaf71BmsI/lr+w/7D/loICAGmAT0BPQGm/BFpAQv+9WkBDAEMaf71AQtp/vQAAQAAAAAF1ga2ABYAAAERCQERHgEXDgEHLgEnIxYAFzYANyYAA4D+iwF1vv0FBf2+vv0FlQYBUf7+AVEGBv6vBYsBKv6L/osBKgT9v779BQX9vv7+rwYGAVH+/gFRAAAAAQAAAAAFPwcAABQAAAERIyIGHQEhAyMRIREjETM1NDYzMgU/nVY8ASUn/v7O///QrZMG9P74SEi9/tj9CQL3ASjaus0AAAAABAAAAAAGjgcAADAARQBgAGwAAAEUHgMVFAcGBCMiJicmNTQ2NzYlLgE1NDcGIyImNTQ2Nz4BMyEHIx4BFRQOAycyNjc2NTQuAiMiBgcGFRQeAxMyPgI1NC4BLwEmLwImIyIOAxUUHgIBMxUjFSM1IzUzNTMDH0BbWkAwSP7qn4TlOSVZSoMBESAfFS4WlMtIP03TcAGiioNKTDFFRjGSJlAaNSI/akAqURkvFCs9WTY6a1s3Dg8THgocJU4QIDVob1M2RnF9A2vV1WnU1GkD5CRFQ1CATlpTenNTYDxHUYouUhIqQCkkMQTBlFKaNkJAWD+MWkhzRztAPiEbOWY6hn1SJyE7ZS5nZ1I0/JcaNF4+GTAkGCMLFx04Ag4kOF07Rms7HQNsbNvbbNkAAwAAAAAGgAZsAAMADgAqAAABESERARYGKwEiJjQ2MhYBESERNCYjIgYHBhURIRIQLwEhFSM+AzMyFgHd/rYBXwFnVAJSZGemZASP/rdRVj9VFQv+twIBAQFJAhQqR2c/q9AEj/whA98BMkliYpNhYfzd/cgCEml3RTMeM/3XAY8B8DAwkCAwOB/jAAABAAAAAAaUBgAAMQAAAQYHFhUUAg4BBCMgJxYzMjcuAScWMzI3LgE9ARYXLgE1NDcWBBcmNTQ2MzIXNjcGBzYGlENfAUyb1v7SrP7x4SMr4bBpph8hHCsqcJNETkJOLHkBW8YIvYaMYG1gJWldBWhiRQ4cgv797rdtkQSKAn1hBQsXsXUEJgMsjlNYS5WzCiYkhr1mFTlzPwoAAAABAAAAAAWABwAAIgAAARcOAQcGLgM1ESM1PgQ3PgE7AREhFSERFB4CNzYFMFAXsFlorXBOIahIckQwFAUBBwT0AU3+sg0gQzBOAc/tIz4BAjhceHg6AiDXGlddb1ctBQf+WPz9+h40NR4BAgABAAAAAAaABoAASgAAARQCBCMiJzY/AR4BMzI+ATU0LgEjIg4DFRQWFxY/ATY3NicmNTQ2MzIWFRQGIyImNz4CNTQmIyIGFRQXAwYXJgI1NBIkIAQSBoDO/p/Rb2s7EzYUaj15vmh34o5ptn9bK1BNHggIBgIGETPRqZepiWs9Sg4IJRc2Mj5WGWMRBM7+zgFhAaIBYc4DgNH+n84gXUfTJzmJ8JZyyH46YH2GQ2ieIAwgHxgGFxQ9WpfZpIOq7lc9I3VZHzJCclVJMf5eRmtbAXzp0QFhzs7+nwAABwAAAAAHAATPAA4AFwAqAD0AUABaAF0AAAERNh4CBw4BBwYmIycmNxY2NzYmBxEUBRY2Nz4BNy4BJyMGHwEeARcOARcWNjc+ATcuAScjBh8BHgEXFAYXFjY3PgE3LgEnIwYfAR4BFw4BBTM/ARUzESMGAyUVJwMchM2UWwgNq4JHrQgBAapUaAoJcWMBfiIhDiMrAQJLMB0BBAokNAIBPmMiIQ4iLAECSzAeAQUKJDQBP2MiIQ4iLAECSzAeAQUKJDQBAT75g+5B4arNLNIBJ44ByQL9BQ9mvYCKwA8FBQMDwwJVTGdzBf6VB8IHNR08lld9uT4LCRA/qGNxvUwHNR08lld9uT4LCRA/qGNxvUwHNR08lld9uT4LCRA/qGNxvVJkAWUDDEf+tYP5AQAAAAEAAAAABiAGtgAbAAABBAADER4BFzMRITU2ADcWABcVIREzPgE3EQIAA4D+4v6FBwJ/X+D+1QYBJ97eAScG/tXgX38CB/6FBrUH/oX+4v32X38CAlWV3gEnBgb+2d6V/asCf18CCgEeAXsAAAAAEADGAAEAAAAAAAEABwAAAAEAAAAAAAIABwAHAAEAAAAAAAMABwAOAAEAAAAAAAQABwAVAAEAAAAAAAUACwAcAAEAAAAAAAYABwAnAAEAAAAAAAoAKwAuAAEAAAAAAAsAEwBZAAMAAQQJAAEADgBsAAMAAQQJAAIADgB6AAMAAQQJAAMADgCIAAMAAQQJAAQADgCWAAMAAQQJAAUAFgCkAAMAAQQJAAYADgC6AAMAAQQJAAoAVgDIAAMAAQQJAAsAJgEeVmlkZW9KU1JlZ3VsYXJWaWRlb0pTVmlkZW9KU1ZlcnNpb24gMS4wVmlkZW9KU0dlbmVyYXRlZCBieSBzdmcydHRmIGZyb20gRm9udGVsbG8gcHJvamVjdC5odHRwOi8vZm9udGVsbG8uY29tAFYAaQBkAGUAbwBKAFMAUgBlAGcAdQBsAGEAcgBWAGkAZABlAG8ASgBTAFYAaQBkAGUAbwBKAFMAVgBlAHIAcwBpAG8AbgAgADEALgAwAFYAaQBkAGUAbwBKAFMARwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABzAHYAZwAyAHQAdABmACAAZgByAG8AbQAgAEYAbwBuAHQAZQBsAGwAbwAgAHAAcgBvAGoAZQBjAHQALgBoAHQAdABwADoALwAvAGYAbwBuAHQAZQBsAGwAbwAuAGMAbwBtAAAAAgAAAAAAAAARAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfAAABAgEDAQQBBQEGAQcBCAEJAQoBCwEMAQ0BDgEPARABEQESARMBFAEVARYBFwEYARkBGgEbARwBHQEeAR8EcGxheQtwbGF5LWNpcmNsZQVwYXVzZQt2b2x1bWUtbXV0ZQp2b2x1bWUtbG93CnZvbHVtZS1taWQLdm9sdW1lLWhpZ2gQZnVsbHNjcmVlbi1lbnRlcg9mdWxsc2NyZWVuLWV4aXQGc3F1YXJlB3NwaW5uZXIJc3VidGl0bGVzCGNhcHRpb25zCGNoYXB0ZXJzBXNoYXJlA2NvZwZjaXJjbGUOY2lyY2xlLW91dGxpbmUTY2lyY2xlLWlubmVyLWNpcmNsZQJoZAZjYW5jZWwGcmVwbGF5CGZhY2Vib29rBWdwbHVzCGxpbmtlZGluB3R3aXR0ZXIGdHVtYmxyCXBpbnRlcmVzdBFhdWRpby1kZXNjcmlwdGlvbgVhdWRpbwAAAAAA) format(\"truetype\");\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep {\n  /* If we let the font size grow as much as everything else, the current time tooltip ends up\n  ginormous. If you'd like to enable the current time tooltip all the time, this should be disabled\n  to avoid a weird hitch when you roll off the hover. */\n}\n::ng-deep .video-js .vjs-big-play-button:before,\n::ng-deep .video-js .vjs-control:before,\n::ng-deep .video-js .vjs-modal-dialog,\n::ng-deep .vjs-modal-dialog .vjs-modal-dialog-content {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n}\n::ng-deep .video-js .vjs-big-play-button:before,\n::ng-deep .video-js .vjs-control:before {\n  text-align: center;\n}\n::ng-deep .vjs-icon-play,\n::ng-deep .video-js .vjs-big-play-button,\n::ng-deep .video-js .vjs-play-control {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-play:before,\n::ng-deep .video-js .vjs-big-play-button:before,\n::ng-deep .video-js .vjs-play-control:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-play-circle {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-resize-manager {\n  display: none;\n}\n::ng-deep .vjs-icon-play-circle:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-pause,\n::ng-deep .video-js .vjs-play-control.vjs-playing {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-pause:before,\n::ng-deep .video-js .vjs-play-control.vjs-playing:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-volume-mute,\n::ng-deep .video-js .vjs-mute-control.vjs-vol-0,\n::ng-deep .video-js .vjs-volume-menu-button.vjs-vol-0 {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-volume-mute:before,\n::ng-deep .video-js .vjs-mute-control.vjs-vol-0:before,\n::ng-deep .video-js .vjs-volume-menu-button.vjs-vol-0:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-volume-low,\n::ng-deep .video-js .vjs-mute-control.vjs-vol-1,\n::ng-deep .video-js .vjs-volume-menu-button.vjs-vol-1 {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-volume-low:before,\n::ng-deep .video-js .vjs-mute-control.vjs-vol-1:before,\n::ng-deep .video-js .vjs-volume-menu-button.vjs-vol-1:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-volume-mid,\n::ng-deep .video-js .vjs-mute-control.vjs-vol-2,\n::ng-deep .video-js .vjs-volume-menu-button.vjs-vol-2 {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-volume-mid:before,\n::ng-deep .video-js .vjs-mute-control.vjs-vol-2:before,\n::ng-deep .video-js .vjs-volume-menu-button.vjs-vol-2:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-volume-high,\n::ng-deep .video-js .vjs-mute-control,\n::ng-deep .video-js .vjs-volume-menu-button {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-volume-high:before,\n::ng-deep .video-js .vjs-mute-control:before,\n::ng-deep .video-js .vjs-volume-menu-button:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-fullscreen-enter,\n::ng-deep .video-js .vjs-fullscreen-control {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-fullscreen-enter:before,\n::ng-deep .video-js .vjs-fullscreen-control:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-fullscreen-exit,\n::ng-deep .video-js.vjs-fullscreen .vjs-fullscreen-control {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-fullscreen-exit:before,\n::ng-deep .video-js.vjs-fullscreen .vjs-fullscreen-control:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-square {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-square:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-spinner {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-spinner:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-subtitles,\n::ng-deep .video-js .vjs-subtitles-button {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-subtitles:before,\n::ng-deep .video-js .vjs-subtitles-button:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-captions,\n::ng-deep .video-js .vjs-captions-button {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-captions:before,\n::ng-deep .video-js .vjs-captions-button:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-chapters,\n::ng-deep .video-js .vjs-chapters-button {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-chapters:before,\n::ng-deep .video-js .vjs-chapters-button:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-share {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-share:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-cog {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-cog:before {\n  content: \"\";\n}\n::ng-deep .vjs-subs-caps-button:before {\n  content: \"\";\n}\n::ng-deep .vjs-control.vjs-subs-caps-button {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-control.vjs-subs-caps-button:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-circle,\n::ng-deep .video-js .vjs-mouse-display,\n::ng-deep .video-js .vjs-play-progress,\n::ng-deep .video-js .vjs-volume-level {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-circle:before,\n::ng-deep .video-js .vjs-mouse-display:before,\n::ng-deep .video-js .vjs-play-progress:before,\n::ng-deep .video-js .vjs-volume-level:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-circle-outline {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-circle-outline:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-circle-inner-circle {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-circle-inner-circle:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-hd {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-hd:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-cancel,\n::ng-deep .video-js .vjs-control.vjs-close-button {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-cancel:before,\n::ng-deep .video-js .vjs-control.vjs-close-button:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-replay {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-replay:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-facebook {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-facebook:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-gplus {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-gplus:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-linkedin {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-linkedin:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-twitter {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-twitter:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-tumblr {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-tumblr:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-pinterest {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-pinterest:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-audio-description,\n::ng-deep .video-js .vjs-descriptions-button {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-audio-description:before,\n::ng-deep .video-js .vjs-descriptions-button:before {\n  content: \"\";\n}\n::ng-deep .vjs-icon-audio,\n::ng-deep .video-js .vjs-audio-button {\n  font-family: VideoJS;\n  font-weight: normal;\n  font-style: normal;\n}\n::ng-deep .vjs-icon-audio:before,\n::ng-deep .video-js .vjs-audio-button:before {\n  content: \"\";\n}\n::ng-deep .video-js {\n  display: block;\n  vertical-align: top;\n  box-sizing: border-box;\n  color: #fff;\n  background-color: #000;\n  position: relative;\n  padding: 0;\n  font-size: 10px;\n  line-height: 1;\n  font-weight: normal;\n  font-style: normal;\n  font-family: Arial, Helvetica, sans-serif;\n}\n::ng-deep .video-js:-moz-full-screen {\n  position: absolute;\n}\n::ng-deep .video-js:-webkit-full-screen {\n  width: 100% !important;\n  height: 100% !important;\n}\n::ng-deep .video-js *,\n::ng-deep .video-js *:before,\n::ng-deep .video-js *:after {\n  box-sizing: inherit;\n}\n::ng-deep .video-js ul {\n  font-family: inherit;\n  font-size: inherit;\n  line-height: inherit;\n  list-style-position: outside;\n  margin-left: 0;\n  margin-right: 0;\n  margin-top: 0;\n  margin-bottom: 0;\n}\n::ng-deep .video-js.vjs-fluid,\n::ng-deep .video-js.vjs-16-9,\n::ng-deep .video-js.vjs-4-3 {\n  width: 100%;\n  max-width: 100%;\n  height: 0;\n}\n::ng-deep .video-js.vjs-16-9 {\n  padding-top: 56.25%;\n}\n::ng-deep .video-js.vjs-4-3 {\n  padding-top: 75%;\n}\n::ng-deep .video-js.vjs-fill {\n  width: 100%;\n  height: 100%;\n}\n::ng-deep .video-js .vjs-tech {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n}\n::ng-deep body.vjs-full-window {\n  padding: 0;\n  margin: 0;\n  height: 100%;\n  overflow-y: auto;\n}\n::ng-deep .vjs-full-window .video-js.vjs-fullscreen {\n  position: fixed;\n  overflow: hidden;\n  z-index: 1000;\n  left: 0;\n  top: 0;\n  bottom: 0;\n  right: 0;\n}\n::ng-deep .video-js.vjs-fullscreen {\n  width: 100% !important;\n  height: 100% !important;\n  padding-top: 0 !important;\n}\n::ng-deep .video-js.vjs-fullscreen.vjs-user-inactive {\n  cursor: none;\n}\n::ng-deep .vjs-hidden {\n  display: none !important;\n}\n::ng-deep .vjs-disabled {\n  opacity: 0.5;\n  cursor: default;\n}\n::ng-deep .video-js .vjs-offscreen {\n  height: 1px;\n  left: -9999px;\n  position: absolute;\n  top: 0;\n  width: 1px;\n}\n::ng-deep .vjs-lock-showing {\n  display: block !important;\n  opacity: 1;\n  visibility: visible;\n}\n::ng-deep .vjs-no-js {\n  padding: 20px;\n  color: #fff;\n  background-color: #000;\n  font-size: 18px;\n  font-family: Arial, Helvetica, sans-serif;\n  text-align: center;\n  width: 300px;\n  height: 150px;\n  margin: 0px auto;\n}\n::ng-deep .vjs-no-js a,\n::ng-deep .vjs-no-js a:visited {\n  color: #66A8CC;\n}\n::ng-deep .video-js .vjs-big-play-button {\n  font-size: 3em;\n  line-height: 1.5em;\n  height: 1.5em;\n  width: 3em;\n  display: block;\n  position: absolute;\n  top: 10px;\n  left: 10px;\n  padding: 0;\n  cursor: pointer;\n  opacity: 1;\n  border: 0.06666em solid #fff;\n  background-color: #2B333F;\n  background-color: rgba(43, 51, 63, 0.7);\n  border-radius: 0.3em;\n  -webkit-transition: all 0.4s;\n  transition: all 0.4s;\n}\n::ng-deep .vjs-big-play-centered .vjs-big-play-button {\n  top: 50%;\n  left: 50%;\n  margin-top: -0.75em;\n  margin-left: -1.5em;\n}\n::ng-deep .video-js:hover .vjs-big-play-button,\n::ng-deep .video-js .vjs-big-play-button:focus {\n  outline: 0;\n  border-color: #fff;\n  background-color: #73859f;\n  background-color: rgba(115, 133, 159, 0.5);\n  -webkit-transition: all 0s;\n  transition: all 0s;\n}\n::ng-deep .vjs-controls-disabled .vjs-big-play-button,\n::ng-deep .vjs-has-started .vjs-big-play-button,\n::ng-deep .vjs-using-native-controls .vjs-big-play-button,\n::ng-deep .vjs-error .vjs-big-play-button {\n  display: none;\n}\n::ng-deep .vjs-has-started.vjs-paused.vjs-show-big-play-button-on-pause .vjs-big-play-button {\n  display: block;\n}\n::ng-deep .video-js button {\n  background: none;\n  border: none;\n  color: inherit;\n  display: inline-block;\n  overflow: visible;\n  font-size: inherit;\n  line-height: inherit;\n  text-transform: none;\n  text-decoration: none;\n  -webkit-transition: none;\n  transition: none;\n  -webkit-appearance: none;\n  -moz-appearance: none;\n  appearance: none;\n}\n::ng-deep .video-js .vjs-control.vjs-close-button {\n  cursor: pointer;\n  height: 3em;\n  position: absolute;\n  right: 0;\n  top: 0.5em;\n  z-index: 2;\n}\n::ng-deep .vjs-menu-button {\n  cursor: pointer;\n}\n::ng-deep .vjs-menu-button.vjs-disabled {\n  cursor: default;\n}\n::ng-deep .vjs-workinghover .vjs-menu-button.vjs-disabled:hover .vjs-menu {\n  display: none;\n}\n::ng-deep .vjs-menu .vjs-menu-content {\n  display: block;\n  padding: 0;\n  margin: 0;\n  overflow: auto;\n  font-family: Arial, Helvetica, sans-serif;\n}\n::ng-deep .vjs-scrubbing .vjs-menu-button:hover .vjs-menu {\n  display: none;\n}\n::ng-deep .vjs-menu li {\n  list-style: none;\n  margin: 0;\n  padding: 0.2em 0;\n  line-height: 1.4em;\n  font-size: 1.2em;\n  text-align: center;\n  text-transform: lowercase;\n}\n::ng-deep .vjs-menu li.vjs-menu-item:focus,\n::ng-deep .vjs-menu li.vjs-menu-item:hover {\n  outline: 0;\n  background-color: #73859f;\n  background-color: rgba(115, 133, 159, 0.5);\n}\n::ng-deep .vjs-menu li.vjs-selected,\n::ng-deep .vjs-menu li.vjs-selected:focus,\n::ng-deep .vjs-menu li.vjs-selected:hover {\n  background-color: #fff;\n  color: #2B333F;\n}\n::ng-deep .vjs-menu li.vjs-menu-title {\n  text-align: center;\n  text-transform: uppercase;\n  font-size: 1em;\n  line-height: 2em;\n  padding: 0;\n  margin: 0 0 0.3em 0;\n  font-weight: bold;\n  cursor: default;\n}\n::ng-deep .vjs-menu-button-popup .vjs-menu {\n  display: none;\n  position: absolute;\n  bottom: 0;\n  width: 10em;\n  left: -3em;\n  height: 0em;\n  margin-bottom: 1.5em;\n  border-top-color: rgba(43, 51, 63, 0.7);\n}\n::ng-deep .vjs-menu-button-popup .vjs-menu .vjs-menu-content {\n  background-color: #2B333F;\n  background-color: rgba(43, 51, 63, 0.7);\n  position: absolute;\n  width: 100%;\n  bottom: 1.5em;\n  max-height: 15em;\n}\n::ng-deep .vjs-workinghover .vjs-menu-button-popup:hover .vjs-menu,\n::ng-deep .vjs-menu-button-popup .vjs-menu.vjs-lock-showing {\n  display: block;\n}\n::ng-deep .video-js .vjs-menu-button-inline {\n  -webkit-transition: all 0.4s;\n  transition: all 0.4s;\n  overflow: hidden;\n}\n::ng-deep .video-js .vjs-menu-button-inline:before {\n  width: 2.222222222em;\n}\n::ng-deep .video-js .vjs-menu-button-inline:hover,\n::ng-deep .video-js .vjs-menu-button-inline:focus,\n::ng-deep .video-js .vjs-menu-button-inline.vjs-slider-active,\n::ng-deep .video-js.vjs-no-flex .vjs-menu-button-inline {\n  width: 12em;\n}\n::ng-deep .video-js .vjs-menu-button-inline.vjs-slider-active {\n  -webkit-transition: none;\n  transition: none;\n}\n::ng-deep .vjs-menu-button-inline .vjs-menu {\n  opacity: 0;\n  height: 100%;\n  width: auto;\n  position: absolute;\n  left: 4em;\n  top: 0;\n  padding: 0;\n  margin: 0;\n  -webkit-transition: all 0.4s;\n  transition: all 0.4s;\n}\n::ng-deep .vjs-menu-button-inline:hover .vjs-menu,\n::ng-deep .vjs-menu-button-inline:focus .vjs-menu,\n::ng-deep .vjs-menu-button-inline.vjs-slider-active .vjs-menu {\n  display: block;\n  opacity: 1;\n}\n::ng-deep .vjs-no-flex .vjs-menu-button-inline .vjs-menu {\n  display: block;\n  opacity: 1;\n  position: relative;\n  width: auto;\n}\n::ng-deep .vjs-no-flex .vjs-menu-button-inline:hover .vjs-menu,\n::ng-deep .vjs-no-flex .vjs-menu-button-inline:focus .vjs-menu,\n::ng-deep .vjs-no-flex .vjs-menu-button-inline.vjs-slider-active .vjs-menu {\n  width: auto;\n}\n::ng-deep .vjs-menu-button-inline .vjs-menu-content {\n  width: auto;\n  height: 100%;\n  margin: 0;\n  overflow: hidden;\n}\n::ng-deep .video-js .vjs-control-bar {\n  display: none;\n  width: 100%;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  height: 3em;\n  background-color: #2B333F;\n  background-color: rgba(43, 51, 63, 0.7);\n}\n::ng-deep .vjs-has-started .vjs-control-bar {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  visibility: visible;\n  opacity: 1;\n  -webkit-transition: visibility 0.1s, opacity 0.1s;\n  transition: visibility 0.1s, opacity 0.1s;\n}\n::ng-deep .vjs-has-started.vjs-user-inactive.vjs-playing .vjs-control-bar {\n  visibility: visible;\n  opacity: 0;\n  -webkit-transition: visibility 1s, opacity 1s;\n  transition: visibility 1s, opacity 1s;\n}\n::ng-deep .vjs-controls-disabled .vjs-control-bar,\n::ng-deep .vjs-using-native-controls .vjs-control-bar,\n::ng-deep .vjs-error .vjs-control-bar {\n  display: none !important;\n}\n::ng-deep .vjs-audio.vjs-has-started.vjs-user-inactive.vjs-playing .vjs-control-bar {\n  opacity: 1;\n  visibility: visible;\n}\n::ng-deep .vjs-has-started.vjs-no-flex .vjs-control-bar {\n  display: table;\n}\n::ng-deep .video-js .vjs-control {\n  outline: none;\n  position: relative;\n  text-align: center;\n  margin: 0;\n  padding: 0;\n  height: 100%;\n  width: 4em;\n  -webkit-box-flex: none;\n  -ms-flex: none;\n  flex: none;\n}\n::ng-deep .video-js .vjs-control:before {\n  font-size: 1.8em;\n  line-height: 1.67;\n}\n::ng-deep .video-js .vjs-control:focus:before,\n::ng-deep .video-js .vjs-control:hover:before,\n::ng-deep .video-js .vjs-control:focus {\n  text-shadow: 0em 0em 1em white;\n}\n::ng-deep .video-js .vjs-control-text {\n  border: 0;\n  clip: rect(0 0 0 0);\n  height: 1px;\n  margin: -1px;\n  overflow: hidden;\n  padding: 0;\n  position: absolute;\n  width: 1px;\n}\n::ng-deep .vjs-no-flex .vjs-control {\n  display: table-cell;\n  vertical-align: middle;\n}\n::ng-deep .video-js .vjs-custom-control-spacer {\n  display: none;\n}\n::ng-deep .video-js .vjs-progress-control {\n  -webkit-box-flex: auto;\n  -ms-flex: auto;\n  flex: auto;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n  -ms-flex-align: center;\n  align-items: center;\n  min-width: 4em;\n}\n::ng-deep .vjs-live .vjs-progress-control {\n  display: none;\n}\n::ng-deep .video-js .vjs-progress-holder {\n  -webkit-box-flex: auto;\n  -ms-flex: auto;\n  flex: auto;\n  -webkit-transition: all 0.2s;\n  transition: all 0.2s;\n  height: 0.3em;\n}\n::ng-deep .video-js .vjs-progress-control:hover .vjs-progress-holder {\n  font-size: 1.6666666667em;\n}\n::ng-deep .video-js .vjs-progress-control:hover .vjs-time-tooltip,\n::ng-deep .video-js .vjs-progress-control:hover .vjs-mouse-display:after,\n::ng-deep .video-js .vjs-progress-control:hover .vjs-play-progress:after {\n  font-family: Arial, Helvetica, sans-serif;\n  visibility: visible;\n  font-size: 0.6em;\n}\n::ng-deep .video-js .vjs-progress-holder .vjs-play-progress,\n::ng-deep .video-js .vjs-progress-holder .vjs-load-progress,\n::ng-deep .video-js .vjs-progress-holder .vjs-tooltip-progress-bar,\n::ng-deep .video-js .vjs-progress-holder .vjs-load-progress div {\n  position: absolute;\n  display: block;\n  height: 100%;\n  margin: 0;\n  padding: 0;\n  width: 0;\n  left: 0;\n  top: 0;\n}\n::ng-deep .video-js .vjs-mouse-display:before {\n  display: none;\n}\n::ng-deep .video-js .vjs-play-progress {\n  background-color: #fff;\n}\n::ng-deep .video-js .vjs-play-progress:before {\n  position: absolute;\n  top: -0.3333333333em;\n  right: -0.5em;\n  font-size: 0.9em;\n}\n::ng-deep .video-js .vjs-time-tooltip,\n::ng-deep .video-js .vjs-mouse-display:after,\n::ng-deep .video-js .vjs-play-progress:after {\n  visibility: hidden;\n  pointer-events: none;\n  position: absolute;\n  top: -3.4em;\n  right: -1.9em;\n  font-size: 0.9em;\n  color: #000;\n  content: attr(data-current-time);\n  padding: 6px 8px 8px 8px;\n  background-color: #fff;\n  background-color: rgba(255, 255, 255, 0.8);\n  border-radius: 0.3em;\n}\n::ng-deep .video-js .vjs-time-tooltip,\n::ng-deep .video-js .vjs-play-progress:before,\n::ng-deep .video-js .vjs-play-progress:after {\n  z-index: 1;\n}\n::ng-deep .video-js .vjs-progress-control .vjs-keep-tooltips-inside:after {\n  display: none;\n}\n::ng-deep .video-js .vjs-load-progress {\n  background: #bfc7d3;\n  background: rgba(115, 133, 159, 0.5);\n}\n::ng-deep .video-js .vjs-load-progress div {\n  background: white;\n  background: rgba(115, 133, 159, 0.75);\n}\n::ng-deep .video-js.vjs-no-flex .vjs-progress-control {\n  width: auto;\n}\n::ng-deep .video-js .vjs-time-tooltip {\n  display: inline-block;\n  height: 2.4em;\n  position: relative;\n  float: right;\n  right: -1.9em;\n}\n::ng-deep .vjs-tooltip-progress-bar {\n  visibility: hidden;\n}\n::ng-deep .video-js .vjs-progress-control .vjs-mouse-display {\n  display: none;\n  position: absolute;\n  width: 1px;\n  height: 100%;\n  background-color: #000;\n  z-index: 1;\n}\n::ng-deep .vjs-no-flex .vjs-progress-control .vjs-mouse-display {\n  z-index: 0;\n}\n::ng-deep .video-js .vjs-progress-control:hover .vjs-mouse-display {\n  display: block;\n}\n::ng-deep .video-js.vjs-user-inactive .vjs-progress-control .vjs-mouse-display,\n::ng-deep .video-js.vjs-user-inactive .vjs-progress-control .vjs-mouse-display:after {\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: visibility 1s, opacity 1s;\n  transition: visibility 1s, opacity 1s;\n}\n::ng-deep .video-js.vjs-user-inactive.vjs-no-flex .vjs-progress-control .vjs-mouse-display,\n::ng-deep .video-js.vjs-user-inactive.vjs-no-flex .vjs-progress-control .vjs-mouse-display:after {\n  display: none;\n}\n::ng-deep .vjs-mouse-display .vjs-time-tooltip,\n::ng-deep .video-js .vjs-progress-control .vjs-mouse-display:after {\n  color: #fff;\n  background-color: #000;\n  background-color: rgba(0, 0, 0, 0.8);\n}\n::ng-deep .video-js .vjs-slider {\n  outline: 0;\n  position: relative;\n  cursor: pointer;\n  padding: 0;\n  margin: 0 0.45em 0 0.45em;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n  background-color: #73859f;\n  background-color: rgba(115, 133, 159, 0.5);\n}\n::ng-deep .video-js .vjs-slider:focus {\n  text-shadow: 0em 0em 1em white;\n  box-shadow: 0 0 1em #fff;\n}\n::ng-deep .video-js .vjs-mute-control,\n::ng-deep .video-js .vjs-volume-menu-button {\n  cursor: pointer;\n  -webkit-box-flex: none;\n  -ms-flex: none;\n  flex: none;\n}\n::ng-deep .video-js .vjs-volume-control {\n  width: 5em;\n  -webkit-box-flex: none;\n  -ms-flex: none;\n  flex: none;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n  -ms-flex-align: center;\n  align-items: center;\n}\n::ng-deep .video-js .vjs-volume-bar {\n  margin: 1.35em 0.45em;\n}\n::ng-deep .vjs-volume-bar.vjs-slider-horizontal {\n  width: 5em;\n  height: 0.3em;\n}\n::ng-deep .vjs-volume-bar.vjs-slider-vertical {\n  width: 0.3em;\n  height: 5em;\n  margin: 1.35em auto;\n}\n::ng-deep .video-js .vjs-volume-level {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  background-color: #fff;\n}\n::ng-deep .video-js .vjs-volume-level:before {\n  position: absolute;\n  font-size: 0.9em;\n}\n::ng-deep .vjs-slider-vertical .vjs-volume-level {\n  width: 0.3em;\n}\n::ng-deep .vjs-slider-vertical .vjs-volume-level:before {\n  top: -0.5em;\n  left: -0.3em;\n}\n::ng-deep .vjs-slider-horizontal .vjs-volume-level {\n  height: 0.3em;\n}\n::ng-deep .vjs-slider-horizontal .vjs-volume-level:before {\n  top: -0.3em;\n  right: -0.5em;\n}\n::ng-deep .vjs-volume-bar.vjs-slider-vertical .vjs-volume-level {\n  height: 100%;\n}\n::ng-deep .vjs-volume-bar.vjs-slider-horizontal .vjs-volume-level {\n  width: 100%;\n}\n::ng-deep .vjs-menu-button-popup.vjs-volume-menu-button .vjs-menu {\n  display: block;\n  width: 0;\n  height: 0;\n  border-top-color: transparent;\n}\n::ng-deep .vjs-menu-button-popup.vjs-volume-menu-button-vertical .vjs-menu {\n  left: 0.5em;\n  height: 8em;\n}\n::ng-deep .vjs-menu-button-popup.vjs-volume-menu-button-horizontal .vjs-menu {\n  left: -2em;\n}\n::ng-deep .vjs-menu-button-popup.vjs-volume-menu-button .vjs-menu-content {\n  height: 0;\n  width: 0;\n  overflow-x: hidden;\n  overflow-y: hidden;\n}\n::ng-deep .vjs-volume-menu-button-vertical:hover .vjs-menu-content,\n::ng-deep .vjs-volume-menu-button-vertical:focus .vjs-menu-content,\n::ng-deep .vjs-volume-menu-button-vertical.vjs-slider-active .vjs-menu-content,\n::ng-deep .vjs-volume-menu-button-vertical .vjs-lock-showing .vjs-menu-content {\n  height: 8em;\n  width: 2.9em;\n}\n::ng-deep .vjs-volume-menu-button-horizontal:hover .vjs-menu-content,\n::ng-deep .vjs-volume-menu-button-horizontal:focus .vjs-menu-content,\n::ng-deep .vjs-volume-menu-button-horizontal .vjs-slider-active .vjs-menu-content,\n::ng-deep .vjs-volume-menu-button-horizontal .vjs-lock-showing .vjs-menu-content {\n  height: 2.9em;\n  width: 8em;\n}\n::ng-deep .vjs-volume-menu-button.vjs-menu-button-inline .vjs-menu-content {\n  background-color: transparent !important;\n}\n::ng-deep .vjs-poster {\n  display: inline-block;\n  vertical-align: middle;\n  background-repeat: no-repeat;\n  background-position: 50% 50%;\n  background-size: contain;\n  background-color: #000000;\n  cursor: pointer;\n  margin: 0;\n  padding: 0;\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  height: 100%;\n}\n::ng-deep .vjs-poster img {\n  display: block;\n  vertical-align: middle;\n  margin: 0 auto;\n  max-height: 100%;\n  padding: 0;\n  width: 100%;\n}\n::ng-deep .vjs-has-started .vjs-poster {\n  display: none;\n}\n::ng-deep .vjs-audio.vjs-has-started .vjs-poster {\n  display: block;\n}\n::ng-deep .vjs-using-native-controls .vjs-poster {\n  display: none;\n}\n::ng-deep .video-js .vjs-live-control {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: flex-start;\n  -ms-flex-align: flex-start;\n  align-items: flex-start;\n  -webkit-box-flex: auto;\n  -ms-flex: auto;\n  flex: auto;\n  font-size: 1em;\n  line-height: 3em;\n}\n::ng-deep .vjs-no-flex .vjs-live-control {\n  display: table-cell;\n  width: auto;\n  text-align: left;\n}\n::ng-deep .video-js .vjs-time-control {\n  -webkit-box-flex: none;\n  -ms-flex: none;\n  flex: none;\n  font-size: 1em;\n  line-height: 3em;\n  min-width: 2em;\n  width: auto;\n  padding-left: 1em;\n  padding-right: 1em;\n}\n::ng-deep .vjs-live .vjs-time-control {\n  display: none;\n}\n::ng-deep .video-js .vjs-current-time,\n::ng-deep .vjs-no-flex .vjs-current-time {\n  display: none;\n}\n::ng-deep .video-js .vjs-duration,\n::ng-deep .vjs-no-flex .vjs-duration {\n  display: none;\n}\n::ng-deep .vjs-time-divider {\n  display: none;\n  line-height: 3em;\n}\n::ng-deep .vjs-live .vjs-time-divider {\n  display: none;\n}\n::ng-deep .video-js .vjs-play-control {\n  cursor: pointer;\n  -webkit-box-flex: none;\n  -ms-flex: none;\n  flex: none;\n}\n::ng-deep .vjs-text-track-display {\n  position: absolute;\n  bottom: 3em;\n  left: 0;\n  right: 0;\n  top: 0;\n  pointer-events: none;\n}\n::ng-deep .video-js.vjs-user-inactive.vjs-playing .vjs-text-track-display {\n  bottom: 1em;\n}\n::ng-deep .video-js .vjs-text-track {\n  font-size: 1.4em;\n  text-align: center;\n  margin-bottom: 0.1em;\n  background-color: #000;\n  background-color: rgba(0, 0, 0, 0.5);\n}\n::ng-deep .vjs-subtitles {\n  color: #fff;\n}\n::ng-deep .vjs-captions {\n  color: #fc6;\n}\n::ng-deep .vjs-tt-cue {\n  display: block;\n}\n::ng-deep video::-webkit-media-text-track-display {\n  -ms-transform: translateY(-3em);\n  -webkit-transform: translateY(-3em);\n  transform: translateY(-3em);\n}\n::ng-deep .video-js.vjs-user-inactive.vjs-playing video::-webkit-media-text-track-display {\n  -ms-transform: translateY(-1.5em);\n  -webkit-transform: translateY(-1.5em);\n  transform: translateY(-1.5em);\n}\n::ng-deep .video-js .vjs-fullscreen-control {\n  cursor: pointer;\n  -webkit-box-flex: none;\n  -ms-flex: none;\n  flex: none;\n}\n::ng-deep .vjs-playback-rate .vjs-playback-rate-value {\n  font-size: 1.5em;\n  line-height: 2;\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  text-align: center;\n}\n::ng-deep .vjs-playback-rate .vjs-menu {\n  width: 4em;\n  left: 0em;\n}\n::ng-deep .vjs-error .vjs-error-display .vjs-modal-dialog-content {\n  font-size: 1.4em;\n  text-align: center;\n}\n::ng-deep .vjs-error .vjs-error-display:before {\n  color: #fff;\n  content: \"X\";\n  font-family: Arial, Helvetica, sans-serif;\n  font-size: 4em;\n  left: 0;\n  line-height: 1;\n  margin-top: -0.5em;\n  position: absolute;\n  text-shadow: 0.05em 0.05em 0.1em #000;\n  text-align: center;\n  top: 50%;\n  vertical-align: middle;\n  width: 100%;\n}\n::ng-deep .vjs-loading-spinner {\n  display: none;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  margin: -25px 0 0 -25px;\n  opacity: 0.85;\n  text-align: left;\n  border: 6px solid rgba(43, 51, 63, 0.7);\n  box-sizing: border-box;\n  background-clip: padding-box;\n  width: 50px;\n  height: 50px;\n  border-radius: 25px;\n}\n::ng-deep .vjs-seeking .vjs-loading-spinner,\n::ng-deep .vjs-waiting .vjs-loading-spinner {\n  display: block;\n}\n::ng-deep .vjs-loading-spinner:before,\n::ng-deep .vjs-loading-spinner:after {\n  content: \"\";\n  position: absolute;\n  margin: -6px;\n  box-sizing: inherit;\n  width: inherit;\n  height: inherit;\n  border-radius: inherit;\n  opacity: 1;\n  border: inherit;\n  border-color: transparent;\n  border-top-color: white;\n}\n::ng-deep .vjs-seeking .vjs-loading-spinner:before,\n::ng-deep .vjs-seeking .vjs-loading-spinner:after,\n::ng-deep .vjs-waiting .vjs-loading-spinner:before,\n::ng-deep .vjs-waiting .vjs-loading-spinner:after {\n  -webkit-animation: vjs-spinner-spin 1.1s cubic-bezier(0.6, 0.2, 0, 0.8) infinite, vjs-spinner-fade 1.1s linear infinite;\n  animation: vjs-spinner-spin 1.1s cubic-bezier(0.6, 0.2, 0, 0.8) infinite, vjs-spinner-fade 1.1s linear infinite;\n}\n::ng-deep .vjs-seeking .vjs-loading-spinner:before,\n::ng-deep .vjs-waiting .vjs-loading-spinner:before {\n  border-top-color: white;\n}\n::ng-deep .vjs-seeking .vjs-loading-spinner:after,\n::ng-deep .vjs-waiting .vjs-loading-spinner:after {\n  border-top-color: white;\n  -webkit-animation-delay: 0.44s;\n  animation-delay: 0.44s;\n}\n@keyframes vjs-spinner-spin {\n  100% {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n  }\n}\n@-webkit-keyframes vjs-spinner-spin {\n  100% {\n    -webkit-transform: rotate(360deg);\n  }\n}\n@keyframes vjs-spinner-fade {\n  0% {\n    border-top-color: #73859f;\n  }\n  20% {\n    border-top-color: #73859f;\n  }\n  35% {\n    border-top-color: white;\n  }\n  60% {\n    border-top-color: #73859f;\n  }\n  100% {\n    border-top-color: #73859f;\n  }\n}\n@-webkit-keyframes vjs-spinner-fade {\n  0% {\n    border-top-color: #73859f;\n  }\n  20% {\n    border-top-color: #73859f;\n  }\n  35% {\n    border-top-color: white;\n  }\n  60% {\n    border-top-color: #73859f;\n  }\n  100% {\n    border-top-color: #73859f;\n  }\n}\n::ng-deep .vjs-chapters-button .vjs-menu ul {\n  width: 24em;\n}\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-custom-control-spacer {\n  -webkit-box-flex: auto;\n  -ms-flex: auto;\n  flex: auto;\n}\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen).vjs-no-flex .vjs-custom-control-spacer {\n  width: auto;\n}\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-current-time,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-time-divider,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-duration,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-remaining-time,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-playback-rate,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-progress-control,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-mute-control,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-volume-control,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-volume-menu-button,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-chapters-button,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-descriptions-button,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-captions-button,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-subtitles-button,\n::ng-deep .video-js.vjs-layout-tiny:not(.vjs-fullscreen) .vjs-audio-button {\n  display: none;\n}\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-current-time,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-time-divider,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-duration,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-remaining-time,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-playback-rate,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-mute-control,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-volume-control,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-volume-menu-button,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-chapters-button,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-descriptions-button,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-captions-button,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-subtitles-button,\n::ng-deep .video-js.vjs-layout-x-small:not(.vjs-fullscreen) .vjs-audio-button {\n  display: none;\n}\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-current-time,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-time-divider,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-duration,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-remaining-time,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-playback-rate,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-mute-control,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-volume-control,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-chapters-button,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-descriptions-button,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-captions-button,\n::ng-deep .video-js.vjs-layout-small:not(.vjs-fullscreen) .vjs-subtitles-button .vjs-audio-button {\n  display: none;\n}\n::ng-deep .vjs-caption-settings {\n  position: relative;\n  top: 1em;\n  background-color: #2B333F;\n  background-color: rgba(43, 51, 63, 0.75);\n  color: #fff;\n  margin: 0 auto;\n  padding: 0.5em;\n  height: 16em;\n  font-size: 12px;\n  width: 40em;\n}\n::ng-deep .vjs-caption-settings .vjs-tracksettings {\n  top: 0;\n  bottom: 1em;\n  left: 0;\n  right: 0;\n  position: absolute;\n  overflow: auto;\n}\n::ng-deep .vjs-caption-settings .vjs-tracksettings-colors,\n::ng-deep .vjs-caption-settings .vjs-tracksettings-font {\n  float: left;\n}\n::ng-deep .vjs-caption-settings .vjs-tracksettings-colors:after,\n::ng-deep .vjs-caption-settings .vjs-tracksettings-font:after,\n::ng-deep .vjs-caption-settings .vjs-tracksettings-controls:after {\n  clear: both;\n}\n::ng-deep .vjs-caption-settings .vjs-tracksettings-controls {\n  position: absolute;\n  bottom: 1em;\n  right: 1em;\n}\n::ng-deep .vjs-caption-settings .vjs-tracksetting {\n  margin: 5px;\n  padding: 3px;\n  min-height: 40px;\n  border: none;\n}\n::ng-deep .vjs-caption-settings .vjs-tracksetting label,\n::ng-deep .vjs-caption-settings .vjs-tracksetting legend {\n  display: block;\n  width: 100px;\n  margin-bottom: 5px;\n}\n::ng-deep .vjs-caption-settings .vjs-tracksetting span {\n  display: inline;\n  margin-left: 5px;\n  vertical-align: top;\n  float: right;\n}\n::ng-deep .vjs-caption-settings .vjs-tracksetting > div {\n  margin-bottom: 5px;\n  min-height: 20px;\n}\n::ng-deep .vjs-caption-settings .vjs-tracksetting > div:last-child {\n  margin-bottom: 0;\n  padding-bottom: 0;\n  min-height: 0;\n}\n::ng-deep .vjs-caption-settings label > input {\n  margin-right: 10px;\n}\n::ng-deep .vjs-caption-settings fieldset {\n  margin-top: 1em;\n  margin-left: 0.5em;\n}\n::ng-deep .vjs-caption-settings fieldset .vjs-label {\n  position: absolute;\n  clip: rect(1px 1px 1px 1px);\n  /* for Internet Explorer */\n  clip: rect(1px, 1px, 1px, 1px);\n  padding: 0;\n  border: 0;\n  height: 1px;\n  width: 1px;\n  overflow: hidden;\n}\n::ng-deep .vjs-caption-settings input[type=button] {\n  width: 40px;\n  height: 40px;\n}\n::ng-deep .video-js .vjs-modal-dialog {\n  background: rgba(0, 0, 0, 0.8);\n  background: -webkit-gradient(linear, left top, left bottom, from(rgba(0, 0, 0, 0.8)), to(rgba(255, 255, 255, 0)));\n  background: linear-gradient(180deg, rgba(0, 0, 0, 0.8), rgba(255, 255, 255, 0));\n}\n::ng-deep .vjs-modal-dialog .vjs-modal-dialog-content {\n  font-size: 1.2em;\n  line-height: 1.5;\n  padding: 20px 24px;\n  z-index: 1;\n}\n@media print {\n  ::ng-deep .video-js > *:not(.vjs-tech):not(.vjs-poster) {\n    visibility: hidden;\n  }\n}\n@media \\0 screen {\n  ::ng-deep .vjs-user-inactive.vjs-playing .vjs-control-bar :before {\n    content: \"\";\n  }\n}\n@media \\0 screen {\n  ::ng-deep .vjs-has-started.vjs-user-inactive.vjs-playing .vjs-control-bar {\n    visibility: hidden;\n  }\n}\n:host {\n  left: 7em;\n  right: 0;\n}\n:host .player-wrapper {\n  -webkit-animation-name: slideInUp;\n  animation-name: slideInUp;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  -webkit-animation-delay: 0;\n  animation-delay: 0;\n  -webkit-animation-timing-function: ease;\n  animation-timing-function: ease;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}\n:host .miniplayer-container {\n  position: fixed;\n  right: 0.5em;\n  border-radius: 0.8em;\n  bottom: 5.5em;\n}\n:host .miniplayer-container .mini-poster {\n  background-size: cover;\n  background-position: center center;\n  background-repeat: no-repeat;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n}\n:host .miniplayer-container.hidden {\n  display: none;\n}\n:host ::ng-deep .video-js {\n  border-radius: 0.8em;\n  height: 25em;\n  width: 45em;\n}\n:host ::ng-deep .vjs-control-bar,\n:host ::ng-deep .vjs-big-play-button {\n  display: none;\n}\n:host ::ng-deep .mini-player-controls {\n  position: absolute;\n  background: rgba(0, 0, 0, 0.3);\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: none;\n  z-index: 1;\n  border-radius: 0.8em;\n}\n:host ::ng-deep .mini-player-controls .icon {\n  color: #fff;\n  cursor: pointer;\n}\n:host ::ng-deep .mini-player-controls .icon:hover {\n  opacity: 0.8;\n}\n:host ::ng-deep .mini-player-controls .icon.play, :host ::ng-deep .mini-player-controls .icon.pause {\n  position: absolute;\n  color: #fff;\n  z-index: 2;\n  left: 50%;\n  top: 50%;\n  font-size: 4em;\n  padding: 0;\n  margin-left: -0.8em;\n  margin-top: -0.8em;\n}\n:host ::ng-deep .mini-player-controls .icon.expand {\n  position: absolute;\n  left: 0.2em;\n  top: 0.2em;\n  color: #fff;\n}\n:host ::ng-deep .mini-player-controls .icon.close {\n  position: absolute;\n  right: 0.2em;\n  top: 0.2em;\n  color: #fff;\n  font-size: 0.7em;\n  opacity: 1;\n}\n:host ::ng-deep:hover .mini-player-controls {\n  display: block;\n}\n:host ::ng-deep .mini-player-controls.force {\n  display: block;\n}\n:host:not(.volume) {\n  position: fixed;\n  bottom: 0;\n  right: 0;\n  display: block;\n  z-index: 100;\n}\n:host .disabled {\n  display: none;\n  pointer-events: none;\n}\n:host .player-content {\n  padding: 0;\n  height: 5em;\n  background-color: var(--player-background);\n  box-shadow: 0px -2px 10px var(--player-box-shadow);\n}\n:host .player-content .player-section.player-controls {\n  width: 15em;\n}\n:host .player-content .player-section.player-controls.podcast {\n  width: 17.4em;\n}\n:host .player-content .player-section.track-info {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n}\n:host .player-content .player-section.player-actions .time {\n  font-size: 0.8em;\n}\n:host .player-content .player-section.player-actions .time span:first-child {\n  color: gray;\n}\n:host .player-content .player-section.player-actions .icon.liked {\n  color: var(--brand-purple);\n}\n:host .tooltip-container {\n  position: absolute;\n  bottom: 5em;\n  width: 15rem;\n  right: 1em;\n  z-index: 1000;\n}\n:host .tooltip-content {\n  background-color: #fff;\n  padding: 1em;\n  border-radius: 0.25rem;\n  box-shadow: 0 0 5px rgba(0, 0, 0, 0.25);\n}\n:host .tooltip-header {\n  font-size: 0.9rem;\n  color: var(--brand-purple);\n  font-weight: 600;\n}\n:host .tooltip-body {\n  font-size: 0.8rem;\n  padding-top: 0.5em;\n  padding-bottom: 0;\n  margin-bottom: 0;\n  color: #000;\n}\n:host .tooltip-arrow {\n  margin: auto;\n  width: 0;\n  height: 0;\n  border-style: solid;\n}\n:host .tooltip-arrow.bottom {\n  border-width: 1em 1em 0em 1em;\n  border-color: #fff transparent transparent transparent;\n}\n:host .tooltip-arrow.miniplayer {\n  margin: auto 72px auto auto;\n}\n:host .track-img-cntr {\n  position: relative;\n}\n:host .more-context {\n  display: table;\n  height: 100%;\n}\n:host .more-context .icon {\n  vertical-align: middle;\n  padding: 1em;\n  border-radius: 50%;\n  -webkit-transition: fill, color, background-color 200ms linear;\n  transition: fill, color, background-color 200ms linear;\n}\n:host .more-context .icon:hover, :host .more-context .icon.highlighted {\n  color: var(--brand-purple);\n  fill: var(--brand-purple);\n}\n:host .more-sheet .icon {\n  -webkit-transition: fill, color, background-color 200ms linear;\n  transition: fill, color, background-color 200ms linear;\n}\n:host .more-sheet .icon:hover, :host .more-sheet .icon.highlighted {\n  color: var(--brand-purple);\n  fill: var(--brand-purple);\n}\n@media (max-width: 991.98px) {\n  :host .hide-on-small, :host .queue-list .next {\n    display: none;\n  }\n}\n:host .toggle {\n  width: calc(100% - 13em) !important;\n}\n:host .vl {\n  border-left: 1px solid var(--player-separator);\n  height: 3em;\n}\n:host .track-coverart {\n  width: 4em;\n  height: 4em;\n  background-color: #e1e1e1;\n  background-repeat: no-repeat;\n  background-size: cover;\n  border-radius: 0.5em;\n  border: 1px solid #e1e1e1;\n}\n:host .player-controls {\n  margin: auto 1em;\n}\n:host .player-controls .icon {\n  margin: 0.25em;\n  padding: 0.5em;\n}\n:host .player-controls .icon.active {\n  background-color: #e1e1e1;\n  border-radius: 2em;\n  color: #000;\n}\n:host .player-controls.podcast .icon:not(.play):not(.pause) {\n  margin: 0.1em 0.5em !important;\n  padding: 0.3em !important;\n  font-size: 16px;\n}\n:host .icon {\n  margin: 1em;\n  font-size: 0.9em;\n  cursor: pointer;\n  color: var(--text-color);\n}\n:host .icon.speaker {\n  font-size: 0.7em;\n}\n:host .icon.prev ::ng-deep svg, :host .icon.next ::ng-deep svg {\n  width: 1.2em !important;\n  height: 1.2em !important;\n}\n:host .play-pause-cont {\n  border-radius: 50%;\n  background: var(--brand-purple);\n  width: 50px;\n  height: 50px;\n  position: relative;\n}\n:host .play-pause-cont .icon {\n  color: #d30e0e;\n  fill: #fff;\n  top: 50%;\n  margin-top: -0.78em;\n  left: 50%;\n  margin-left: -0.8em;\n  padding: 0;\n  font-size: 2em;\n  position: absolute;\n  -webkit-animation-name: fadeIn;\n  animation-name: fadeIn;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.3s;\n  animation-duration: 0.3s;\n  -webkit-animation-delay: 0;\n  animation-delay: 0;\n  -webkit-animation-timing-function: ease;\n  animation-timing-function: ease;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}\n:host .play-pause-cont .loader {\n  margin-left: -0.45em;\n  margin-top: 1.5em;\n}\n:host .nomargin {\n  margin: 0 !important;\n}\n:host .queue {\n  padding: 0.5em 0;\n}\n:host .queue img {\n  max-width: 5em;\n}\n:host .queue .header-font {\n  font-size: 1em;\n  font-weight: 400;\n  text-transform: uppercase;\n}\n:host .queue .header-font a {\n  color: var(--text-color);\n}\n:host .queue .header-font a:hover {\n  text-decoration: underline;\n}\n:host .queue .song-font {\n  font-size: 2.2em;\n}\n:host .popup-container {\n  position: relative;\n}\n:host .popup-container .popup {\n  position: absolute;\n  bottom: 100%;\n  width: 15em;\n  height: 30em;\n  background: var(--light-background);\n  left: 50%;\n  margin-left: -7.5em;\n  box-shadow: 0px -2px 10px rgba(1, 1, 1, 0.1);\n  -webkit-animation-name: slideInUp;\n  animation-name: slideInUp;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  -webkit-animation-delay: 0;\n  animation-delay: 0;\n  -webkit-animation-timing-function: ease-in-out;\n  animation-timing-function: ease-in-out;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}\n:host .queue-list {\n  margin: 1em;\n}\n:host .queue-list .next {\n  font-size: 0.9em;\n  width: 20em;\n}\n:host .nowrap {\n  white-space: nowrap;\n}\n:host .track-info {\n  height: 100%;\n  position: relative;\n  overflow: hidden;\n}\n:host .track-info .info {\n  padding: 1em;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  width: 70%;\n}\n:host .track-info .info .action-font {\n  font-size: 1em !important;\n}\n:host .track-info .info .device {\n  padding: 0 0.5em;\n}\n:host .track-info .info a {\n  font-size: 1em;\n  cursor: pointer;\n}\n:host .track-info .info a:hover {\n  text-decoration: none;\n}\n:host .track-info .info a.action-title {\n  font-weight: bold;\n  color: var(--text-color);\n}\n:host .track-info .info a.action-artist {\n  color: var(--app-secondary-grey);\n}\n:host hr {\n  border: 0.7px solid lightgray !important;\n}\n:host .width-10 {\n  width: 10em;\n}\n:host .trim {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n:host .maxwidth-15 {\n  max-width: 15em;\n}\n:host .width-15 {\n  width: 15em;\n}\n:host .width-5 {\n  width: 5em;\n}\n:host .action-button {\n  border-radius: 2em;\n  text-align: center;\n  font-size: 0.9em;\n  font-weight: 600;\n  padding: 0.2em 1em;\n  cursor: pointer;\n  color: #fff;\n}\n:host .action-font {\n  font-size: 0.9em;\n  font-weight: 400 !important;\n  color: var(--text-color);\n}\n:host .clear {\n  padding: 0 0.5em;\n  font-size: 1em;\n  cursor: pointer;\n}\n:host .clear:hover {\n  color: var(--purple-alertnate);\n}\n:host .minwidth-15 {\n  min-width: 15em;\n}\n:host .player-leaderboard {\n  left: 0;\n  right: 0;\n  bottom: 100%;\n  height: 8.2em;\n  background: var(--semi-transparent-background);\n  position: absolute;\n  box-shadow: 0px 0px 12px -1px rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  padding: 0.5em;\n  -webkit-animation-name: fadeIn;\n  animation-name: fadeIn;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.3s;\n  animation-duration: 0.3s;\n  -webkit-animation-delay: 0;\n  animation-delay: 0;\n  -webkit-animation-timing-function: ease;\n  animation-timing-function: ease;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}\n:host .player-leaderboard .close {\n  position: absolute;\n  right: 0.5em;\n  color: var(--text-color);\n  cursor: pointer;\n}\n.device-list-trigger ::ng-deep .popover-body {\n  padding: 0;\n}\n.device-list-trigger ::ng-deep .popover-body .devices-list {\n  width: 15em;\n  max-height: 40em;\n  overflow-y: auto;\n}\n.device-list-trigger ::ng-deep .popover-body .devices-list .top {\n  background: var(--dark-white);\n  border-top-left-radius: 0.3em;\n  border-top-right-radius: 0.3em;\n  color: var(--text-color);\n  font-weight: 600;\n  height: 3em;\n  padding: 0.7em 1em;\n}\n.device-list-trigger ::ng-deep .popover-body .devices-list .list {\n  padding: 0;\n  margin: 0;\n}\n.device-list-trigger ::ng-deep .popover-body .devices-list .list li {\n  list-style-type: none;\n  padding: 1em 0.5em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  cursor: pointer;\n}\n.device-list-trigger ::ng-deep .popover-body .devices-list .list li .device-name {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  font-size: 0.8em;\n}\n.device-list-trigger ::ng-deep .popover-body .devices-list .list li .nowplaying {\n  color: var(--purple-alertnate);\n}\n.device-list-trigger ::ng-deep .popover-body .devices-list .list li .tick {\n  padding: 0.3em;\n}\n.device-list-trigger ::ng-deep .popover-body .devices-list .list li .tick svg {\n  color: var(--purple-alertnate);\n  font-size: 0.7em;\n}\n.device-list-trigger ::ng-deep .popover-body .devices-list .list li:hover {\n  background: var(--dark-white);\n  color: var(--purple-alertnate);\n}\n.queue-closing-background {\n  z-index: -1;\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n}\n::ng-deep .popper-container {\n  background-color: var(--light-background);\n  height: 25em;\n  width: 35em;\n  z-index: -99999999;\n  border-top-right-radius: 0.5em;\n  border-top-left-radius: 0.5em;\n  border: 0.1px solid lightgray;\n  position: relative;\n  z-index: 2;\n  padding: 0;\n}\n::ng-deep .popper-container.ngxp__container.ngxp__animation {\n  -webkit-animation: ngxp-fadeIn 200ms ease-in;\n          animation: ngxp-fadeIn 200ms ease-in;\n}\n::ng-deep .popper-container .queue-head {\n  background: var(--light-background);\n  padding: 1em;\n  border-bottom: 1px solid var(--light-gray);\n}\n::ng-deep .popper-container .coverart {\n  max-width: 4em;\n  margin: 0.5em;\n  border-radius: 0.3em;\n}\n.save {\n  padding: 0.2em 1em !important;\n}\nhtml[lang=ar] :host {\n  left: 0;\n  right: 7em;\n}\nhtml[lang=ar] :host .player-leaderboard .close {\n  right: auto;\n  left: 0.5em;\n}\nhtml[lang=ar] :host .queue-container .track-info .info {\n  text-align: right;\n}\nhtml[lang=ar] :host .play-prev-next {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: reverse;\n      -ms-flex-direction: row-reverse;\n          flex-direction: row-reverse;\n}\nhtml[lang=ar] :host .volume-bar .volume-ball-wrapper .volume-ball {\n  -webkit-transform: none;\n      -ms-transform: none;\n          transform: none;\n}\nhtml[lang=ar] :host .tooltip-container {\n  left: 1em;\n  right: auto;\n}\nhtml[lang=ar] :host .tooltip-arrow.miniplayer {\n  margin: auto auto auto 77px;\n}\nhtml[lang=ar] :host .queue-container {\n  left: 1em;\n  right: auto;\n}\n.queue-toggle {\n  padding: 1.2em 0.5em;\n  cursor: pointer;\n}\n.queue-toggle .icon {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0.5em;\n}\n.queue-toggle span {\n  font-weight: bold;\n  display: inline-block;\n  vertical-align: middle;\n  text-transform: uppercase;\n}\n.queue-toggle .queue-toggle-wrapper {\n  border-radius: 3em;\n  padding: 0.1em 1em;\n  -webkit-transition: background-color 200ms ease;\n  transition: background-color 200ms ease;\n}\n.queue-toggle .queue-toggle-wrapper:hover {\n  background-color: #ccc;\n}\n.queue-toggle.highlighted .queue-toggle-wrapper {\n  background: rgba(150, 150, 150, 0.5);\n}\n.player-not-sod-container {\n  background: var(--brand-purple);\n  padding: 0.4em 7em;\n  position: relative;\n}\n.player-not-sod-container::after {\n  content: \"\";\n  border: 1em solid transparent;\n  border-bottom-color: var(--brand-purple);\n  position: absolute;\n  z-index: 9999;\n  top: -2em;\n  right: 14.2em;\n}\n.player-not-sod-container .player-not-sod {\n  color: #fff;\n  font-size: 0.9em;\n}\n.queue-container {\n  background: var(--light-background);\n  min-width: 45em;\n  position: absolute;\n  right: 1em;\n  bottom: 6em;\n  padding: 0.5rem 0.75rem;\n  border-radius: 4.8px;\n  border: 1px solid rgba(0, 0, 0, 0.2);\n  z-index: 3;\n}\nhtml[lang=ar] :host .trim {\n  text-align: right;\n}\nhtml[lang=ar] :host .player-not-sod-container::after {\n  content: \"\";\n  border: 1em solid transparent;\n  border-bottom-color: var(--brand-purple);\n  position: absolute;\n  z-index: 9999;\n  top: -2em;\n  left: 14em;\n  right: auto;\n}"

/***/ }),

/***/ "./src/app/core/modules/player/player.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/modules/player/player.component.ts ***!
  \*********************************************************/
/*! exports provided: PlayerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlayerComponent", function() { return PlayerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../app/core/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _core_modules_player_player_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/modules/player/player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _core_services_ads_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/services/ads.service */ "./src/app/core/services/ads.service.ts");
/* harmony import */ var _core_services_utils_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../core/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../redux/actions/user.actions */ "./src/app/core/redux/actions/user.actions.ts");
/* harmony import */ var _refrences_WindowRef__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../refrences/WindowRef */ "./src/app/core/refrences/WindowRef.ts");
/* harmony import */ var _actions_player_actions__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./actions/player.actions */ "./src/app/core/modules/player/actions/player.actions.ts");
/* harmony import */ var compare_versions__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! compare-versions */ "./node_modules/compare-versions/index.js");
/* harmony import */ var compare_versions__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(compare_versions__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @anghami/redux/actions/library.actions */ "./src/app/core/redux/actions/library.actions.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");



























let PlayerComponent = class PlayerComponent {
    constructor(store, playerservice, platformId, router, adsServce, window, cdr, _utils, _cookieService, coverartservice, authService, _translateService) {
        this.store = store;
        this.playerservice = playerservice;
        this.platformId = platformId;
        this.router = router;
        this.adsServce = adsServce;
        this.cdr = cdr;
        this._utils = _utils;
        this._cookieService = _cookieService;
        this.coverartservice = coverartservice;
        this.authService = authService;
        this._translateService = _translateService;
        this.morePopverShown = false;
        this.showMiniPlayerButton = false;
        this.miniPlayerSupported = false;
        this.progressSubject$ = new rxjs__WEBPACK_IMPORTED_MODULE_10__["Subject"]();
        this.isQueueToggled = false;
        this.sleepTimerEnd = () => {
            this.sleepTimerChange(this.podcastSleepOptions[0]);
            if (this.anghplayer.playing) {
                this.playerservice.NEWpause();
            }
        };
        this.currentPlayQueueList = [];
        this.AdsState = {
            visible: false,
            canclose: false,
            timestamp: 0,
            closetimestamp: 0
        };
        this.isDesktopClient = !!window.nativeWindow['desktopClient'];
        if (this.isDesktopClient) {
            this.miniPlayerSupported = compare_versions__WEBPACK_IMPORTED_MODULE_20__["compare"](window.nativeWindow['desktopClient'].appVersion, '2.0.4', '>=');
            this.showMiniPlayerButton = true;
        }
        if (this._utils.isBrowser()) {
            this.online$ = Object(rxjs__WEBPACK_IMPORTED_MODULE_10__["merge"])(Object(rxjs__WEBPACK_IMPORTED_MODULE_10__["of"])(navigator.onLine), Object(rxjs__WEBPACK_IMPORTED_MODULE_10__["fromEvent"])(window.nativeWindow, 'online').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["mapTo"])(true)), Object(rxjs__WEBPACK_IMPORTED_MODULE_10__["fromEvent"])(window.nativeWindow, 'offline').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["mapTo"])(false)));
        }
        this.playerservice.playerInstance$.subscribe(data => {
            if (data) {
                this.anghplayer = data['player'];
                this.anghRemote = data['remote'];
                this.anghAds = data['ads'];
                this.videoObject = this.anghplayer.videoJsVideoElement;
                this.initPlayerListeners();
            }
        });
        this.routerSub = this.router.events.subscribe(event => {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_7__["NavigationEnd"]) {
                this.isQueueToggled = false;
                if (this.videoOn) {
                    this.playerservice.NEWsetVideoPlayerVisiblity(this.videoOn);
                }
            }
        });
        window.nativeWindow.onbeforeunload = (event) => {
            if (!this.isDesktopClient && this.anghRemote.isSOD && this.anghplayer && this.anghplayer.playing) {
                event.preventDefault();
                event.returnValue = 'currently playing music';
            }
        };
    }
    get currentEngineTrack() {
        if (!this.anghplayer) {
            return null;
        }
        return this.anghplayer.currentTrack;
    }
    handleCurrentSongLikeStatus() {
        this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_23__["getLikedSongsHashed"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["take"])(1))
            .subscribe(data => {
            if (data && this.currentTrack) {
                this.currentTrack = Object.assign({}, this.currentTrack, { liked: data[this.currentTrack.id] });
                this.cdr.detectChanges();
            }
        });
    }
    initPlayerListeners() {
        this.currentTrackSub$ = this.anghplayer.currentTrack$.subscribe(data => {
            console.log('data: ', data);
            if (data && data.id) {
                const newtrack = Object.assign({}, data, { coverArtImage: this.coverartservice.getCoverArtImage(data.coverArt, 60), coverArtImageRect: this.coverartservice.getCoverArtImage(data.thumbnailid ? data.thumbnailid : data.coverArt, 640) });
                this.currentTrack = newtrack;
                this.handleCurrentSongLikeStatus();
                if (this.currentTrack.is_podcast) {
                    this.initPodcastPlayer();
                }
                else {
                    this.playerservice.setRate(1);
                }
                this.cdr.detectChanges();
            }
        });
        this.playstate$ = this.anghplayer.playstate$;
        this.shuffleOn$ = this.anghplayer.shuffle$;
        this.repeatOn$ = this.anghplayer.repeat$;
        this.buffering$ = this.anghplayer.buffering$;
        this.anghplayer.videoOn$.subscribe(data => {
            this.playerservice.NEWsetVideoPlayerVisiblity(data);
            this.videoOn = data;
            if (this.videoOn) {
                this.playerservice.NEWload();
            }
        });
        this.progress$ = this.anghplayer.progress$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["map"])((data) => {
            const duration = this.anghplayer.duration;
            const percentage = (data / duration) * 100;
            this.currentProgressPercentage = percentage;
            return {
                progress: data,
                percentage
            };
        }));
        this.queue$ = this.anghplayer.queue$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["map"])((data) => {
            if (!data) {
                return null;
            }
            this.queue = data;
            const sections = [];
            sections[0] = { data: data.songs, type: 'queue' };
            this.currentPlayQueueList = sections;
            return this.currentPlayQueueList;
        }));
        this.anghplayer.trackEnd$.subscribe(data => {
            if (this.sleepTimer === 'end') {
                this.sleepTimerEnd();
            }
            else {
                this.NEWnext();
            }
        });
        this.anghRemote.devices$.subscribe(data => {
            this.NEWsetDeviceList(data);
        });
        this.anghAds.AD$.subscribe(data => {
            if (data !== null) {
                const newdata = Object.assign({}, data, { type: 'audio' });
                this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__["OpenAdsModal"](newdata));
            }
        });
        this.likedSongsSubscription = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_23__["getLikedSongsHashed"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["delay"])(200))
            .subscribe(data => {
            if (data && this.currentTrack) {
                this.currentTrack = Object.assign({}, this.currentTrack, { liked: data[this.currentTrack.id] });
                this.cdr.detectChanges();
            }
        });
    }
    initPodcastPlayer() {
        // Init speed rate
        this.podcastSpeeds = [
            { text: '1x', value: 1.0, selected: true },
            { text: '1.25x', value: 1.25 },
            { text: '1.5x', value: 1.5 },
            { text: '1.75x', value: 1.75 },
            { text: '2x', value: 2 }
        ];
        const foundSpeed = this.podcastSpeeds.find(sp => sp.value === this.playerservice.getRate());
        this.podcastSelectedSpeed =
            foundSpeed && foundSpeed.value ? foundSpeed : { text: '1x', value: 1.0 };
        this.playerservice.setRate(this.podcastSelectedSpeed.value);
        // Init Sleep Timer
        this.podcastSleepOptions = [
            {
                text: this._translateService.instant('Sleep timer'),
                value: 0,
                selected: true
            },
            { text: this._translateService.instant('Sleep in 30 minutes'), value: 1 },
            { text: this._translateService.instant('Sleep in 1 hour'), value: 2 },
            { text: this._translateService.instant('Sleep in 3 hours'), value: 3 },
            { text: this._translateService.instant('sleep_timer_stop'), value: 4 }
        ];
        this.podcastSleepSelected = this.podcastSleepOptions[0];
    }
    speedRateChange(speed) {
        this.playerservice.setRate(speed.value);
        this.podcastSelectedSpeed = speed;
    }
    sleepTimerChange(stimer) {
        this.podcastSleepSelected = stimer;
        switch (stimer.value) {
            case 0: {
                if (this.sleepTimer) {
                    clearTimeout(this.sleepTimer);
                    this.sleepTimer = null;
                }
                break;
            }
            case 1: {
                this.sleepTimer = setTimeout(this.NEWplaypause, 1800000);
                break;
            }
            case 2: {
                this.sleepTimer = setTimeout(this.sleepTimerEnd, 3600000);
                break;
            }
            case 3: {
                this.sleepTimer = setTimeout(this.sleepTimerEnd, 10800000);
                break;
            }
            case 4: {
                this.sleepTimer = 'end';
                break;
            }
            default: {
                clearTimeout(this.sleepTimer);
                break;
            }
        }
    }
    NEWsetDeviceList(data) {
        this.devicesList = new Array();
        const sod = this.anghRemote.SOD;
        const udid = this.anghRemote.currentUDID;
        data.forEach(item => {
            item = Object.assign({}, item, { sod: item.socket_id === sod, current: item.udid === udid, device: item.platform === 'ios' || item.platform === 'android'
                    ? 'mobile'
                    : 'desktop' });
            this.devicesList.push(item);
        });
    }
    NEWtoggleShuffle() {
        this.playerservice.NEWtoggleShuffle();
    }
    NEWtoggleRepeat() {
        this.playerservice.NEWtoggleRepeat();
    }
    NEWnext() {
        this.playerservice.NEWplayNext();
    }
    NEWprevious() {
        this.playerservice.NEWplayPrevious();
    }
    NEWstopVideo() {
        this.playerservice.NEWToggleVideoMode(false);
    }
    seekPlayer(isForward, time) {
        const duration = this.anghplayer.duration;
        const seekPercentage = (time * 100) / duration;
        const newPercentage = isForward
            ? this.currentProgressPercentage + seekPercentage
            : this.currentProgressPercentage - seekPercentage < 0
                ? 0
                : this.currentProgressPercentage - seekPercentage;
        this.playerservice.setNewTrackPosition(newPercentage);
    }
    NEWplaypause() {
        if (this.anghplayer.playing) {
            this.playerservice.NEWpause();
        }
        else {
            if (!this.anghplayer.currentTime) {
                this.playerservice.loadAndPlay(); // First load
            }
            else {
                this.playerservice.NEWplay();
            }
        }
    }
    NEWchangeSOD(socketid) {
        this.playerservice.NEWsetSOD(socketid);
    }
    NEWtoggleVideoMode(force) {
        this.playerservice.NEWToggleVideoMode(force);
    }
    checkQueuePopover() {
        return this.queuepopoverShown;
    }
    NEWLeaderboardVisibility() {
        const user = this.authService.userData.value;
        const canSeeLeaderboardAd = user && user.leaderboardbreak;
        if (canSeeLeaderboardAd) {
            const now = new Date().getTime();
            const diff = (now - this.AdsState.timestamp) / 1000;
            if (diff <= parseInt(this.userData.leaderboardbreak, 0)) {
                return;
            }
            if (this.AdsState.timestamp === 0) {
                this.AdsState.visible = true;
                this.AdsState.timestamp = new Date().getTime();
                this.adsServce.initPlayerLeaderBoard(true);
                setTimeout(() => {
                    this.adsServce.refreshPlayerLeaderboard();
                }, 3000);
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].show_player_leaderboard
                }));
            }
            else {
                if (diff >= parseInt(this.userData.leaderboardbreak, 0)) {
                    this.RefreshLeaderBoard();
                    this.AdsState.timestamp = new Date().getTime();
                }
            }
        }
    }
    ngAfterViewInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_5__["isPlatformBrowser"])(this.platformId)) {
            this.userSubs = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_12__["getUser"])).subscribe(user => {
                if (typeof user !== 'undefined' &&
                    user !== null &&
                    Object.keys(user).length > 0) {
                    this.userData = user;
                    if (user.plantype) {
                        this.isPlus = user.plantype.match(/3/i) ? true : false;
                    }
                    if (user.miniplayer_button == 'player') {
                        this.showMiniPlayerButton = true;
                    }
                }
            });
        }
    }
    toggleQueue(val) {
        if (val) {
            this.isQueueToggled = val;
        }
        else {
            this.isQueueToggled = !this.isQueueToggled;
        }
    }
    switchToMiniPlayer() {
        if (!!window['desktopClient']) {
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].clickSwitchToMiniPlayer,
                props: {
                    location: 'player'
                }
            }));
            this.store.dispatch(new _actions_player_actions__WEBPACK_IMPORTED_MODULE_19__["OpenMiniplayer"]());
        }
    }
    ngOnDestroy() {
        if (this.progressSubs) {
            this.progressSubs.unsubscribe();
        }
        if (this.currentPlayQueueSub$) {
            this.currentPlayQueueSub$.unsubscribe();
        }
        if (this.currentTrackSub$) {
            this.currentTrackSub$.unsubscribe();
        }
        if (this.toggleNavBarSub$) {
            this.toggleNavBarSub$.unsubscribe();
        }
        if (this.routerSub) {
            this.routerSub.unsubscribe();
        }
        if (this.currentListSub$) {
            this.currentListSub$.unsubscribe();
        }
        if (this.userSubs) {
            this.userSubs.unsubscribe();
        }
        if (this.likedSongsSubscription) {
            this.likedSongsSubscription.unsubscribe();
        }
        window.onbeforeunload = null;
    }
    playerAction(event) {
        if (this.checkQueuePopover()) {
            event.stopPropagation();
        }
    }
    RefreshLeaderBoard() {
        this.adsServce.refreshPlayerLeaderboard();
    }
    closeLeaderBoard() {
        this.AdsState.visible = false;
        this.AdsState.timestamp = 0;
        this.AdsState.canclose = false;
        this.adsServce.initPlayerLeaderBoard(false);
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].close_player_leaderboard
        }));
    }
    showSlider(type) {
        if (type === 'more') {
            this.isShowMore = !this.isShowMore;
            if (this.isShowMore) {
                this.registerWindowClickListener();
                this.isShowQueue = false;
            }
        }
        else if (type === 'queue') {
            this.isShowQueue = !this.isShowQueue;
            if (this.isShowQueue) {
                this.registerWindowClickListener();
                this.isShowMore = false;
            }
        }
        this.cdr.detectChanges();
    }
    likeTrack() {
        this.currentTrack = Object.assign({}, this.currentTrack, { liked: !this.currentTrack.liked });
        this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_21__["LikeSong"]({
            item: this.currentTrack
        }));
        this.cdr.detectChanges();
    }
    openLyricsModal() {
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__["OpenLyricsModal"]());
    }
    dislikeTrack(track) {
        let entity;
        let sourceId;
        if (!!this.currentList) {
            if (this.currentList.playlistid) {
                entity = 'playlist';
                sourceId = this.currentList.playlistid;
            }
            else if (this.currentList.albumid) {
                entity = 'album';
                sourceId = this.currentList.albumid;
            }
            else if (this.currentList['list_type'] === 'song') {
                entity = 'songbased';
                sourceId = this.currentList.id;
            }
        }
        this.store.dispatch(new _redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_17__["DislikeSong"]({
            entity: entity,
            songId: track.id,
            sourceId: sourceId,
            extras: track.extras
        }));
        this.store.dispatch(new _actions_player_actions__WEBPACK_IMPORTED_MODULE_19__["PlayerAction"]('next'));
        this.cdr.detectChanges();
    }
    share(track) {
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__["OpenShareModal"]({
            type: track && track.videoonly && track.videoonly == 1 ? 'video' : 'song',
            meta: track
        }));
    }
    downloadSong(track) {
        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_3__["DownloadSong"]({ song: track }));
    }
    registerWindowClickListener() {
        const handler = e => {
            if (!this.queueSlideUp.nativeElement.contains(e.target) &&
                !this.moreSlideUp.nativeElement.contains(e.target) &&
                !this.queueButton.nativeElement.contains(e.target) &&
                !this.moreButton.nativeElement.contains(e.target)) {
                this.isShowMore = false;
                this.isShowQueue = false;
                window.removeEventListener('click', handler);
            }
        };
        /**
         * Added the setTimeout, so that the click event that added the event
         * listener finishes before we add the listener
         */
        setTimeout(() => {
            window.addEventListener('click', handler);
        }, 0);
    }
    _remote_switchSOD(socketid) {
        this.store.dispatch(new _actions_player_actions__WEBPACK_IMPORTED_MODULE_19__["RemoteSwitchSOD"](socketid));
    }
    saveToQueue() {
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__["OpenPlaylistManager"]({
            type: 'addtoplaylist',
            tracks: this.currentPlayQueueList
        }));
        this.cdr.detectChanges();
    }
    getSODName() {
        const devices = this.anghRemote.devices;
        const sod = this.anghRemote.SOD;
        let deviceName = '';
        devices.find((dev) => {
            if (dev.socket_id === sod) {
                deviceName = dev.name;
                return true;
            }
        });
        return deviceName;
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('queueSlideUp', { read: _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"], static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"])
], PlayerComponent.prototype, "queueSlideUp", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('moreSlideUp', { read: _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"], static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"])
], PlayerComponent.prototype, "moreSlideUp", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('queueButton', { read: _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"], static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"])
], PlayerComponent.prototype, "queueButton", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('moreButton', { read: _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"], static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"])
], PlayerComponent.prototype, "moreButton", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('popover', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerComponent.prototype, "popoverElement", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('videoPlayerContainer', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], PlayerComponent.prototype, "videoPlayerContainer", void 0);
PlayerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
        selector: 'anghami-player',
        template: __webpack_require__(/*! raw-loader!./player.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/player.component.html"),
        styles: [__webpack_require__(/*! ./player.component.scss */ "./src/app/core/modules/player/player.component.scss"), __webpack_require__(/*! ./snow.scss */ "./src/app/core/modules/player/snow.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_6__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["Store"],
        _core_modules_player_player_service__WEBPACK_IMPORTED_MODULE_13__["PlayerService"],
        Object,
        _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"],
        _core_services_ads_service__WEBPACK_IMPORTED_MODULE_14__["AdsService"],
        _refrences_WindowRef__WEBPACK_IMPORTED_MODULE_18__["WindowRef"],
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ChangeDetectorRef"],
        _core_services_utils_service__WEBPACK_IMPORTED_MODULE_15__["UtilService"],
        ngx_cookie__WEBPACK_IMPORTED_MODULE_9__["CookieService"],
        _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_4__["CoverArtService"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_22__["AuthService"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_24__["TranslateService"]])
], PlayerComponent);



/***/ }),

/***/ "./src/app/core/modules/player/player.module.ts":
/*!******************************************************!*\
  !*** ./src/app/core/modules/player/player.module.ts ***!
  \******************************************************/
/*! exports provided: PlayerModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlayerModule", function() { return PlayerModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _selector_sheet_component_html_selector_sheet_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./selector-sheet.component.html/selector-sheet.component */ "./src/app/core/modules/player/selector-sheet.component.html/selector-sheet.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
/* harmony import */ var ngx_popper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-popper */ "./node_modules/ngx-popper/fesm2015/ngx-popper.js");
/* harmony import */ var _core_components_ang_ads_ang_ads_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/ang-ads/ang-ads.module */ "./src/app/core/components/ang-ads/ang-ads.module.ts");
/* harmony import */ var _core_directives_extras_extras_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/directives/extras/extras.module */ "./src/app/core/directives/extras/extras.module.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _components_context_sheet_new_context_sheet_new_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/context-sheet-new/context-sheet-new.module */ "./src/app/core/components/context-sheet-new/context-sheet-new.module.ts");
/* harmony import */ var _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _components_loading_loading_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _pipes_convertDuration_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../pipes/convertDuration.pipe */ "./src/app/core/pipes/convertDuration.pipe.ts");
/* harmony import */ var _buffer_buffer_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./buffer/buffer.module */ "./src/app/core/modules/player/buffer/buffer.module.ts");
/* harmony import */ var _loader_loader_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./loader/loader.component */ "./src/app/core/modules/player/loader/loader.component.ts");
/* harmony import */ var _player_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./player.component */ "./src/app/core/modules/player/player.component.ts");
/* harmony import */ var _volume_volume_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./volume/volume.component */ "./src/app/core/modules/player/volume/volume.component.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");
/* harmony import */ var _directives_queue_button_directive__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../directives/queue-button.directive */ "./src/app/core/directives/queue-button.directive.ts");
/* harmony import */ var _queue_queue_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./queue/queue.component */ "./src/app/core/modules/player/queue/queue.component.ts");
/* harmony import */ var _components_new_section_builder_list_item_list_item_module__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../components/new-section-builder/list-item/list-item.module */ "./src/app/core/components/new-section-builder/list-item/list-item.module.ts");
/* harmony import */ var ngx_infinite_scroll__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ngx-infinite-scroll */ "./node_modules/ngx-infinite-scroll/modules/ngx-infinite-scroll.js");
/* harmony import */ var ngx_sortablejs__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ngx-sortablejs */ "./node_modules/ngx-sortablejs/fesm2015/ngx-sortablejs.js");
/* harmony import */ var _player_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _effects_media_engine_effects__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./effects/media.engine.effects */ "./src/app/core/modules/player/effects/media.engine.effects.ts");
/* harmony import */ var _effects_player_effects__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./effects/player.effects */ "./src/app/core/modules/player/effects/player.effects.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");





























let PlayerModule = class PlayerModule {
};
PlayerModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_11__["IconModule"],
            ngx_popper__WEBPACK_IMPORTED_MODULE_6__["NgxPopperModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
            _components_loading_loading_module__WEBPACK_IMPORTED_MODULE_12__["LoadingModule"],
            _buffer_buffer_module__WEBPACK_IMPORTED_MODULE_14__["BufferModule"],
            _core_components_ang_ads_ang_ads_module__WEBPACK_IMPORTED_MODULE_7__["AngAdsModule"],
            _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__["PipesModule"],
            ngx_infinite_scroll__WEBPACK_IMPORTED_MODULE_22__["InfiniteScrollModule"],
            _core_directives_extras_extras_module__WEBPACK_IMPORTED_MODULE_8__["ExtrasModule"],
            _components_context_sheet_new_context_sheet_new_module__WEBPACK_IMPORTED_MODULE_10__["ContextSheetNewModule"],
            _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_18__["NewSectionBuilderModule"],
            _components_new_section_builder_list_item_list_item_module__WEBPACK_IMPORTED_MODULE_21__["ListItemModule"],
            ngx_sortablejs__WEBPACK_IMPORTED_MODULE_23__["SortablejsModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_28__["TranslateModule"],
            _ngrx_effects__WEBPACK_IMPORTED_MODULE_25__["EffectsModule"].forFeature([
                _effects_media_engine_effects__WEBPACK_IMPORTED_MODULE_26__["MediaEngineEffects"],
                _effects_player_effects__WEBPACK_IMPORTED_MODULE_27__["PlayerEffects"]
            ])
        ],
        declarations: [_player_component__WEBPACK_IMPORTED_MODULE_16__["PlayerComponent"], _volume_volume_component__WEBPACK_IMPORTED_MODULE_17__["VolumeComponent"], _loader_loader_component__WEBPACK_IMPORTED_MODULE_15__["LoaderComponent"], _directives_queue_button_directive__WEBPACK_IMPORTED_MODULE_19__["QueueStatusDirective"], _selector_sheet_component_html_selector_sheet_component__WEBPACK_IMPORTED_MODULE_1__["SelectorSheetComponent"], _queue_queue_component__WEBPACK_IMPORTED_MODULE_20__["QueueComponent"]],
        exports: [_player_component__WEBPACK_IMPORTED_MODULE_16__["PlayerComponent"], _volume_volume_component__WEBPACK_IMPORTED_MODULE_17__["VolumeComponent"], _selector_sheet_component_html_selector_sheet_component__WEBPACK_IMPORTED_MODULE_1__["SelectorSheetComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["CUSTOM_ELEMENTS_SCHEMA"]],
        providers: [_pipes_convertDuration_pipe__WEBPACK_IMPORTED_MODULE_13__["ConvertDurationPipe"], _player_service__WEBPACK_IMPORTED_MODULE_24__["PlayerService"]]
    })
], PlayerModule);



/***/ }),

/***/ "./src/app/core/modules/player/queue/queue.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/core/modules/player/queue/queue.component.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@-webkit-keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideOutDown {\n  0% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n}\n@keyframes slideOutDown {\n  0% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n}\n@-webkit-keyframes slideOutLeft {\n  0% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n}\n@keyframes slideOutLeft {\n  0% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n}\n@-webkit-keyframes slideOutRight {\n  0% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n}\n@keyframes slideOutRight {\n  0% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n}\n@-webkit-keyframes slideOutUp {\n  0% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n}\n@keyframes slideOutUp {\n  0% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n}\n:host {\n  position: fixed;\n  width: 60%;\n  bottom: 5em;\n  background-color: var(--main-background);\n  border-top-left-radius: 1em;\n  box-shadow: -10px -8px 12px -12px #616161;\n  right: 0;\n  padding: 1em 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  max-height: 35em;\n  padding-right: 1em;\n}\n:host .queue-padder {\n  padding-right: 1em;\n}\n:host:not(.queueclosed) {\n  -webkit-animation-name: slideInUp;\n  animation-name: slideInUp;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.3s;\n  animation-duration: 0.3s;\n  -webkit-animation-delay: 0;\n  animation-delay: 0;\n  -webkit-animation-timing-function: ease;\n  animation-timing-function: ease;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}\n:host.queueclosed {\n  -webkit-animation-name: slideOutDown;\n  animation-name: slideOutDown;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.3s;\n  animation-duration: 0.3s;\n  -webkit-animation-delay: 0;\n  animation-delay: 0;\n  -webkit-animation-timing-function: ease;\n  animation-timing-function: ease;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}\n:host .else-header-wrap {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n:host .else-header-wrap.details {\n  -webkit-box-align: start !important;\n      -ms-flex-align: start !important;\n          align-items: flex-start !important;\n}\n:host .else-header-wrap.details .close-icon {\n  position: absolute;\n  right: 0.5em;\n  top: 0;\n}\n:host .else-header-wrap .close-icon {\n  font-size: 3em;\n  cursor: pointer;\n  color: rgba(150, 150, 150, 0.5);\n}\n:host .else-header-wrap .close-icon:hover {\n  opacity: 0.5;\n}\n:host .queue-header {\n  padding: 0 6em;\n  width: 100%;\n}\n:host .queue-header .queue-header-inner {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n}\n:host .queue-header .queue-header-inner .button {\n  height: 2em;\n}\n:host .queue-header .queue-cover {\n  width: 5em;\n  height: 5em;\n  border-radius: 0.3em;\n}\n:host .queue-header .queue-cover img {\n  width: 100%;\n  display: block;\n  margin: auto;\n  border-radius: 0.3em;\n}\n:host .queue-header .queue-details {\n  margin: 0 1em;\n}\n:host .queue-header .queue-details .title-button {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin-bottom: 0.3em;\n}\n:host .queue-header .queue-details .title-button h3 {\n  font-size: 1.3em;\n  text-align: start;\n  margin-right: 0.8em;\n}\n:host .queue-header .queue-details .title-button h3 a {\n  text-decoration: none;\n  color: var(--text-color);\n}\n:host .queue-header .queue-details p {\n  font-size: 0.9em;\n}\n:host .queue-header h5 {\n  color: #AAA;\n  font-size: 1em;\n  font-weight: bold;\n  text-align: start;\n  text-transform: uppercase;\n  margin: 1em 0;\n}\n:host .queue-save-header {\n  padding: 0 6em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n:host .queue-save-header h5 {\n  color: #AAA;\n  font-size: 1em;\n  font-weight: bold;\n  text-align: start;\n  text-transform: uppercase;\n  margin: 1em 0.8em 1em 0em;\n}\n:host .queue-scroller {\n  position: relative;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  width: 100%;\n  overflow: auto;\n}\n:host .queue-scroller::-webkit-scrollbar {\n  width: 0.3em;\n}\n:host .queue-scroller::-webkit-scrollbar-track {\n  background: #DDD;\n  border-radius: 0.3em;\n}\n:host .queue-scroller::-webkit-scrollbar-thumb {\n  background: #8d00f2;\n  border-radius: 0.3em;\n}\nhtml[lang=ar] :host {\n  right: auto;\n  left: 0;\n  padding-right: 0;\n  padding-left: 1em;\n}\nhtml[lang=ar] :host .queue-padder {\n  padding-left: 1em;\n  padding-right: 0;\n}\nhtml[lang=ar] :host .else-header-wrap.details .close-icon {\n  right: 0 !important;\n  left: 0.5em;\n}"

/***/ }),

/***/ "./src/app/core/modules/player/queue/queue.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/modules/player/queue/queue.component.ts ***!
  \**************************************************************/
/*! exports provided: QueueComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QueueComponent", function() { return QueueComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../modules/player/actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _player_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../player.service */ "./src/app/core/modules/player/player.service.ts");






let QueueComponent = class QueueComponent {
    constructor(coverartService, playerService, store, cdr, _playerService) {
        this.coverartService = coverartService;
        this.playerService = playerService;
        this.store = store;
        this.cdr = cdr;
        this._playerService = _playerService;
        this.closeQueue = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.infiniteScrollLimit = 20;
        this.isPlaying = false;
    }
    ngOnInit() {
        this.eventOptions = {
            handle: '.handle',
            animation: 150,
            onUpdate: (event) => {
                this._playerService.NEWUpdateQueue(this.tracks);
            }
        };
        setTimeout(() => {
            document.getElementById("queue_scroller").dispatchEvent(new CustomEvent('scroll'));
        }, 400);
        this.currentTrackSubscription = this.playerService.angPlayer.currentTrack$.subscribe(data => {
            if (!data) {
                return;
            }
            this.currentTrackId = data.id;
            if (this.isPlaying) {
                this.updateQueuePlayingSong();
            }
        });
        this.playstateSubscription = this.playerService.angPlayer.playstate$.subscribe(data => {
            this.isPlaying = data;
            if (this.isPlaying) {
                this.updateQueuePlayingSong();
            }
        });
    }
    updateQueuePlayingSong() {
        this.tracks = this.tracks.map(song => {
            if (song.id === this.currentTrackId && this.isPlaying) {
                return Object.assign({}, song, { selectedSongId: true, isPlaying: true });
            }
            else {
                return Object.assign({}, song, { selectedSongId: false, isPlaying: false });
            }
        });
        this.cdr.detectChanges();
    }
    increaseInfiniteScroll() {
        if (this.infiniteScrollLimit < this.queue[0].data.length) {
            this.infiniteScrollLimit = this.infiniteScrollLimit + 20;
        }
    }
    ngOnChanges() {
        this.tracks = this.playqueue.songs.slice();
        this.list = this.playqueue[this.playqueue.type];
        if (this.list) {
            const thumbid = this.list.coverArt ||
                this.list.coverArtImage ||
                this.list.coverArtId;
            this.list['coverart'] = this.coverartService.getCoverArtImage(thumbid, 120);
        }
    }
    trackById(index, item) {
        return item.id;
    }
    playItem(index, $event) {
        this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_3__["PlayTrackByIndex"]({
            index: index,
        }));
        $event.stopPropagation();
        $event.preventDefault();
    }
    ngOnDestroy() {
        if (this.currentTrackSubscription) {
            this.currentTrackSubscription.unsubscribe();
        }
        if (this.playstateSubscription) {
            this.playstateSubscription.unsubscribe();
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], QueueComponent.prototype, "queue", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], QueueComponent.prototype, "playqueue", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], QueueComponent.prototype, "closeQueue", void 0);
QueueComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-queue',
        template: __webpack_require__(/*! raw-loader!./queue.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/queue/queue.component.html"),
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
        styles: [__webpack_require__(/*! ./queue.component.scss */ "./src/app/core/modules/player/queue/queue.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_2__["CoverArtService"], _player_service__WEBPACK_IMPORTED_MODULE_5__["PlayerService"], _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], _player_service__WEBPACK_IMPORTED_MODULE_5__["PlayerService"]])
], QueueComponent);



/***/ }),

/***/ "./src/app/core/modules/player/selector-sheet.component.html/selector-sheet.component.scss":
/*!*************************************************************************************************!*\
  !*** ./src/app/core/modules/player/selector-sheet.component.html/selector-sheet.component.scss ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".icon {\n  cursor: pointer;\n}\n.icon.speed-icon {\n  background: var(--text-color);\n  color: var(--gray-light-background);\n  padding: 0em 0.8em;\n  text-align: center;\n  border-radius: 10px;\n}\n.icon.sleep {\n  font-size: 15px;\n}\n.speed-slector-container.sleep-timer-sheet div {\n  padding: 0.4em 0.5em;\n  font-size: 0.9em;\n}\n.speed-slector-container div {\n  text-align: center;\n  cursor: pointer;\n}\n.speed-slector-container div.selected {\n  background: var(--light-gray);\n}\n.speed-slector-container div:hover {\n  background: var(--light-gray);\n}"

/***/ }),

/***/ "./src/app/core/modules/player/selector-sheet.component.html/selector-sheet.component.ts":
/*!***********************************************************************************************!*\
  !*** ./src/app/core/modules/player/selector-sheet.component.html/selector-sheet.component.ts ***!
  \***********************************************************************************************/
/*! exports provided: SelectorSheetComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectorSheetComponent", function() { return SelectorSheetComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let SelectorSheetComponent = class SelectorSheetComponent {
    constructor() {
        this.itemClick = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    ngOnChanges() {
        this.sheetOptions = (this.sheetOptions && this.selectedOption) ? this.sheetOptions.map(sp => {
            if (sp.value === this.selectedOption.value) {
                return Object.assign({}, sp, { selected: true });
            }
            else {
                return Object.assign({}, sp, { selected: false });
            }
        }) : [];
    }
    optionClick(speed) {
        this.itemClick.emit(speed);
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
], SelectorSheetComponent.prototype, "sheetOptions", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], SelectorSheetComponent.prototype, "selectedOption", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], SelectorSheetComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], SelectorSheetComponent.prototype, "itemClick", void 0);
SelectorSheetComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-selector-sheet',
        template: __webpack_require__(/*! raw-loader!./selector-sheet.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/selector-sheet.component.html/selector-sheet.component.html"),
        styles: [__webpack_require__(/*! ./selector-sheet.component.scss */ "./src/app/core/modules/player/selector-sheet.component.html/selector-sheet.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], SelectorSheetComponent);



/***/ }),

/***/ "./src/app/core/modules/player/snow.scss":
/*!***********************************************!*\
  !*** ./src/app/core/modules/player/snow.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .snowisfalling {\n  position: fixed;\n  top: 0;\n}\n:host .snowisfalling span {\n  display: inline-block;\n  width: 60px;\n  height: 60px;\n  margin: -280px 100px 54px -10px;\n  background-size: cover !important;\n  background-position: center center !important;\n  -webkit-animation: snowsnowisfalling 15s infinite linear;\n  -moz-animation: snowsnowisfalling 15s infinite linear;\n}\n:host .snowisfalling span:nth-child(odd) {\n  width: 40px;\n  height: 40px;\n  -webkit-animation: snowsnowisfalling2 15s infinite linear;\n  -moz-animation: snowsnowisfalling2 15s infinite linear;\n}\n:host .snowisfalling span:nth-child(3n+0) {\n  width: 20px;\n  height: 20px;\n  -webkit-animation: snowsnowisfalling2 15s infinite linear;\n  -moz-animation: snowsnowisfalling2 15s infinite linear;\n}\n:host .snowisfalling span:nth-child(5n+5) {\n  -webkit-animation-delay: 1.3s;\n  -moz-animation-delay: 1.3s;\n}\n:host .snowisfalling span:nth-child(3n+2) {\n  -webkit-animation-delay: 1.5s;\n  -moz-animation-delay: 1.5s;\n}\n:host .snowisfalling span:nth-child(2n+5) {\n  -webkit-animation-delay: 1.7s;\n  -moz-animation-delay: 1.7s;\n}\n:host .snowisfalling span:nth-child(3n+10) {\n  -webkit-animation-delay: 2.7s;\n  -moz-animation-delay: 2.7s;\n}\n:host .snowisfalling span:nth-child(7n+2) {\n  -webkit-animation-delay: 3.5s;\n  -moz-animation-delay: 3.5s;\n}\n:host .snowisfalling span:nth-child(4n+5) {\n  -webkit-animation-delay: 5.5s;\n  -moz-animation-delay: 5.5s;\n}\n:host .snowisfalling span:nth-child(3n+7) {\n  -webkit-animation-delay: 8s;\n  -moz-animation-delay: 8s;\n}\n@-webkit-keyframes snowsnowisfalling {\n  0% {\n    opacity: 1;\n    -webkit-transform: translate(0, 0px) rotateZ(0deg);\n  }\n  75% {\n    opacity: 1;\n    -webkit-transform: translate(100px, 600px) rotateZ(270deg);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translate(150px, 800px) rotateZ(360deg);\n  }\n}\n@-webkit-keyframes snowsnowisfalling2 {\n  0% {\n    opacity: 1;\n    -webkit-transform: translate(0, 0px) rotateZ(0deg);\n  }\n  75% {\n    opacity: 1;\n    -webkit-transform: translate(100px, 600px) rotateZ(-270deg);\n  }\n  100% {\n    opacity: 0;\n    -webkit-transform: translate(150px, 800px) rotateZ(-360deg);\n  }\n}"

/***/ }),

/***/ "./src/app/core/modules/player/volume/volume.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/core/modules/player/volume/volume.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  position: relative;\n  width: 4em;\n  height: 3em;\n  padding-top: 0.7em;\n  z-index: 1;\n}\n:host .icon {\n  margin: auto;\n  cursor: pointer;\n}\n:host:hover .volume-slider-container {\n  display: block;\n}\n:host .volume-bar {\n  width: 100%;\n  background-color: var(--bg-white-secondary);\n  height: 11em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: end;\n      -ms-flex-align: end;\n          align-items: flex-end;\n  width: 0.5em;\n  left: 50%;\n  position: relative;\n  -webkit-transform: translate3d(0, 0, 0);\n          transform: translate3d(0, 0, 0);\n  vertical-align: bottom;\n  cursor: pointer;\n  margin-left: -0.2em;\n}\n:host .volume-bar,\n:host .volume-bar .volume-ball-wrapper {\n  border-radius: 1em;\n}\n:host .volume-bar .volume-ball-wrapper {\n  position: absolute;\n  max-width: 0.5em;\n  height: 0px;\n  vertical-align: bottom;\n  will-change: height;\n  background: -webkit-gradient(linear, left top, left bottom, color-stop(0, var(--brand-purple)), to(var(--brand-purple-light)));\n  background: linear-gradient(var(--brand-purple) 0, var(--brand-purple-light));\n}\n:host .volume-bar .volume-ball-wrapper .volume-ball {\n  border-radius: 50%;\n  width: 15px;\n  height: 15px;\n  background-color: var(--white);\n  position: relative;\n  cursor: pointer;\n  box-shadow: 0px 0px 7px 1px var(--login-btn-small);\n  left: 53.5%;\n  -webkit-transform: translate(-50%, -50%);\n      -ms-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n:host .volume-slider-container {\n  z-index: 1;\n  position: absolute;\n  bottom: 100%;\n  width: 3em;\n  margin-left: 0.2em;\n  height: 13em;\n  background: var(--app-background);\n  border: 1px solid lightgray;\n  padding: 1em;\n  border-radius: 0.3em;\n  display: none;\n  direction: ltr;\n}\n:host .volume-muted {\n  width: 0.111em;\n  height: 1.8em;\n  background-color: var(--black);\n  -webkit-transform: rotate(45deg);\n      -ms-transform: rotate(45deg);\n          transform: rotate(45deg);\n  position: absolute;\n  top: 0;\n  right: 0;\n  left: 0;\n  bottom: 0;\n  margin: auto;\n}"

/***/ }),

/***/ "./src/app/core/modules/player/volume/volume.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/core/modules/player/volume/volume.component.ts ***!
  \****************************************************************/
/*! exports provided: VolumeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VolumeComponent", function() { return VolumeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _player_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");




let VolumeComponent = class VolumeComponent {
    constructor(_playerService, platformId, cdr, document) {
        this._playerService = _playerService;
        this.platformId = platformId;
        this.cdr = cdr;
        this.document = document;
        this.isVolumeHostComponent = true;
        this.checkLocalStorageVolume();
    }
    preventClick(event) {
        event.preventDefault();
        event.stopPropagation();
    }
    ngOnDestroy() {
        window.document.onmousemove = null;
        window.document.onmouseup = null;
        if (this.volumeSliderCloseTimer) {
            this.volumeSliderCloseTimer.unsubscribe();
        }
    }
    ngAfterViewInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            setTimeout(() => {
                this.checkLocalStorageVolume();
            }, 2000);
        }
    }
    onVolumeMouseDown(event) {
        event.preventDefault();
        window.document.onmousemove = null;
        window.document.onmouseup = null;
        window.document.onmousemove = this.onVolumeMouseMove.bind(this);
        window.document.onmouseup = this.onVolumeMouseUp.bind(this);
    }
    onVolumeMouseMove(event) {
        event.preventDefault();
        this.setProps(event);
    }
    onVolumeMouseUp(event) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            event.preventDefault();
            this.setProps(event);
            setTimeout(() => {
                window.document.onmousemove = null;
                window.document.onmouseup = null;
            }, 5);
        }
    }
    setProps(event) {
        if (this.volumeBar.nativeElement) {
            const clientRect = this.volumeBar.nativeElement.getBoundingClientRect();
            const percentage = 100 -
                Math.round(((event.clientY - clientRect.top) / clientRect.height) * 100);
            if (!isFinite(percentage)) {
                // When the panel get closed
                return;
            }
            if (percentage >= 0 && percentage <= 100) {
                this.volumePercentage = percentage;
            }
            else if (percentage < 0) {
                this.volumePercentage = 0;
            }
            else if (percentage > 100) {
                this.volumePercentage = 100;
            }
            this.changeVolume(true);
        }
    }
    changeVolume(detectChanges) {
        if (this.volumePercentage >= 0 && this.volumePercentage <= 100) {
            this.volume = `${this.volumePercentage}%`;
            window.localStorage.setItem('ang-volume', this.volumePercentage.toString());
            this._playerService.setVolume(this.volumePercentage / 100);
            if (detectChanges) {
                this.cdr.detectChanges();
            }
        }
    }
    mute() {
        if (this.volumePercentage != 0) {
            this.lastVolumePercentage = this.volumePercentage;
        }
        this.volumePercentage =
            this.volumePercentage === 0 ? this.lastVolumePercentage : 0;
        this.changeVolume();
    }
    checkLocalStorageVolume() {
        if (window.localStorage && window.localStorage.getItem('ang-volume')) {
            this.volumePercentage = Number(window.localStorage.getItem('ang-volume'));
        }
        else {
            window.localStorage.setItem('ang-volume', '75');
            this.volumePercentage = 75;
        }
        this.changeVolume();
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('volumeBallWrapper', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], VolumeComponent.prototype, "volumeBallWrapper", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('volumeBar', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], VolumeComponent.prototype, "volumeBar", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('volumeSliderPopover', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], VolumeComponent.prototype, "volumeSliderPopover", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class.volume'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], VolumeComponent.prototype, "isVolumeHostComponent", void 0);
VolumeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-volume',
        template: __webpack_require__(/*! raw-loader!./volume.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/modules/player/volume/volume.component.html"),
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
        styles: [__webpack_require__(/*! ./volume.component.scss */ "./src/app/core/modules/player/volume/volume.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_3__["DOCUMENT"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_player_service__WEBPACK_IMPORTED_MODULE_2__["PlayerService"],
        Object,
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], Object])
], VolumeComponent);



/***/ }),

/***/ "./src/app/core/redux/effects/collection.effects.ts":
/*!**********************************************************!*\
  !*** ./src/app/core/redux/effects/collection.effects.ts ***!
  \**********************************************************/
/*! exports provided: CollectionEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CollectionEffects", function() { return CollectionEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _anghami_services_collection_helper_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/collection-helper.service */ "./src/app/core/services/collection-helper.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_add_observable_forkJoin__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/add/observable/forkJoin */ "./node_modules/rxjs-compat/_esm2015/add/observable/forkJoin.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../modules/player/actions/player.actions */ "./src/app/core/modules/player/actions/player.actions.ts");
/* harmony import */ var _services_collection_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../services/collection.service */ "./src/app/core/services/collection.service.ts");
/* harmony import */ var _services_extras_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../services/extras.service */ "./src/app/core/services/extras.service.ts");
/* harmony import */ var _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../actions/error-handling.actions */ "./src/app/core/redux/actions/error-handling.actions.ts");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm2015/add/operator/map.js");
/* harmony import */ var is_base64__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! is-base64 */ "./node_modules/is-base64/is-base64.js");
/* harmony import */ var is_base64__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(is_base64__WEBPACK_IMPORTED_MODULE_17__);

/*
 * Created Date: Friday October 19th 2018
 * Author: Siraj Tahra
 * Email: siraj.tahra@anghami.com
 * -----
 * Copyright (c) 2018 Anghami
 */

















// TODO: add utils enhancer service, and apply it on this.store.select.pipe level (like a selector redux) in some case
/*
  previewCustomImage is added here as a hack
    cause currently there's no way of optimizing api's response
    when uploading a cover art,
    the solution was to set the image locally (like apps)
*/
let CollectionEffects = class CollectionEffects {
    constructor(actions$, store$, collectionService, sectionService, router, _extrasService, _collectionHelper, coverartservice, locale) {
        this.actions$ = actions$;
        this.store$ = store$;
        this.collectionService = collectionService;
        this.sectionService = sectionService;
        this.router = router;
        this._extrasService = _extrasService;
        this._collectionHelper = _collectionHelper;
        this.coverartservice = coverartservice;
        this.locale = locale;
        this.getCollectionData$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["CollectionActionTypes"].GetCollectionData), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["exhaustMap"])(({ collectionId, collectionType, librarySection, previewCustomImage }) => {
            return this.collectionService
                .getCollectionData(collectionType, collectionId)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(response => {
                return this._collectionHelper.buildCollectionData(response, collectionId, collectionType, librarySection);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(err => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_13__["ErrorWithRedirect"](err));
            }));
        }));
        //Commenting the below out until gateway issue is resolved
        /*  @Effect()
          getCollectionDataNew$ = this.actions$.pipe(
            ofType<GetCollectionDataNew>(CollectionActionTypes.GetCollectionDataNew),
            map(action => action.payload),
            mergeMap(
              params => {
                const response = this.collectionService.getCollectionDataPromise(params.collectionType, params.collectionId).then((response) => {
                  const builtCollection =
                    this._collectionHelper.buildCollectionDataNew(
                      response, params.collectionId, params.collectionType, params.librarySection
                    );
                  if (params && params.previewCustomImage
                    && builtCollection.collectionMeta && builtCollection.collectionMeta !== null) {
                    builtCollection.collectionMeta = {
                      ...builtCollection.collectionMeta,
                      coverArtImage: isBase64(params.previewCustomImage)
                        ? atob(params.previewCustomImage)
                        : params.previewCustomImage
                    };
                  }
        
                  this.store$.dispatch(
                    new GetCollectionSuccessNew({
                      sections: builtCollection.sections,
                      collectionId: builtCollection.collectionId,
                      collectionType: params.collectionType,
                      librarySection: builtCollection.librarySection,
                      collectionMeta: builtCollection.collectionMeta,
                      collectionRoute: '/' + params.collectionType + '/' + params.collectionId,
                    })
                  );
                })
                return empty();
        
              }
            )
          );*/
        this.getCollectionDataNew$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["CollectionActionTypes"].GetCollectionDataNew), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["exhaustMap"])(params => {
            return this.collectionService
                .getCollectionData(params.collectionType, params.collectionId)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(response => {
                const builtCollection = this._collectionHelper.buildCollectionDataNew(response, params.collectionId, params.collectionType, params.librarySection);
                if (params && params.previewCustomImage
                    && builtCollection.collectionMeta && builtCollection.collectionMeta !== null) {
                    builtCollection.collectionMeta = Object.assign({}, builtCollection.collectionMeta, { coverArtImage: is_base64__WEBPACK_IMPORTED_MODULE_17__(params.previewCustomImage)
                            ? atob(params.previewCustomImage)
                            : params.previewCustomImage });
                }
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetCollectionSuccessNew"]({
                    sections: builtCollection.sections,
                    collectionId: builtCollection.collectionId,
                    collectionType: params.collectionType,
                    librarySection: builtCollection.librarySection,
                    collectionMeta: builtCollection.collectionMeta,
                    collectionRoute: '/' + params.collectionType + '/' + params.collectionId,
                }));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(err => {
                if (err.error) {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetCollectionError"](err.error));
                }
                else {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetCollectionError"](err));
                }
            }));
        }));
        this.extractSubSection$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["CollectionActionTypes"].ExtractSubSection), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(params => {
            return this.sectionService.extractSubSection(params).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(sideSectionQueue => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_10__["UpdateSideQueue"](sideSectionQueue));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(err => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetCollectionError"](err));
            }));
        }));
        this.setExtras$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["CollectionActionTypes"].SetExtras), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["tap"])(data => {
            this._extrasService.setExtras(data.extras);
        }));
        this.getPaginatedViewPage$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["CollectionActionTypes"].GetPaginatedViewPage), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["exhaustMap"])(payload => {
            return this.collectionService
                .getCollectionData(payload.type, payload.id, payload.page, payload.sectionId)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(response => {
                const { sections } = response, sectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"](response, ["sections"]);
                const thumb = sectionMeta.coverArtImage || sectionMeta.coverArt || 0;
                const newSectionMeta = Object.assign({}, sectionMeta, { coverArtImage: this.coverartservice.getCoverArtImage(thumb, 296), ArtistArt: this.coverartservice.getCoverArtImage(sectionMeta.ArtistArt, 296), sections: sections });
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["from"])([
                    new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetCollectionSuccessNew"]({
                        sections: this.sectionService.enhanceSections(response),
                        fromPaginatedRequest: true,
                        collectionMeta: newSectionMeta
                    }),
                    new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["SetCollectionMeta"](newSectionMeta)
                ]);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(err => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_13__["ErrorWithRedirect"](err));
            }));
        }));
        //THIS NEEDS TO BE TESTED WITH ONBOARDING
        this.searchArtist$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["CollectionActionTypes"].SearchArtist), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["mergeMap"])(payload => {
            if (!!payload.query) {
                return this.collectionService
                    .searchArtistSections(payload.artistId, payload.query)
                    .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["debounceTime"])(1000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["distinctUntilChanged"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(data => {
                    const sections = this.sectionService.enhanceSections(data);
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetFilteredArtistSuccess"]({
                        sections
                    }));
                }));
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["empty"])();
            }
            //TODO: figure out how to debounce this
            /*if (!!payload.query) {
              this.collectionService.searchArtistSectionsPromise(payload.artistId, payload.query).then((data) => {
                const sections = this.sectionService.enhanceSections(data);
                this.store$.dispatch(
                  new GetFilteredArtistSuccess({
                    sections
                  })
                )
              })
            }
            return empty();*/
        }));
        /*@Effect()
        getSongTags$ = this.actions$.pipe(
          ofType<GetSongTags>(CollectionActionTypes.GetSongTags),
          map(action => action.payload),
          mergeMap(payload => {
              this.collectionService.getSongTagsPromise({songids: payload.playlistItemsIDs.toString()}).then(data => {
                const tags: any[] = Object.values(data);
                let flattenedSongTags = tags
                  .map(array => array.map(entry => parseInt(entry)))
                  .reduce(
                  (accumulator, currentValue) => accumulator.concat(currentValue),
                  []
                  )
                  .map(item => parseInt(item));
                flattenedSongTags = Array.from(new Set(flattenedSongTags));
      
                this.collectionService.getTagInfoPromise({tagids: flattenedSongTags}).then((response) => {
                  this.store$.dispatch(new GetVibesSuccess({ res: response, flattenedSongTags: flattenedSongTags, unflattenedSongTags: data }))
                })
              })
              return empty();
          })
        );*/
        this.getSongTags$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["CollectionActionTypes"].GetSongTags), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(payload => {
            return this.collectionService
                .getSongTags({ songids: payload.playlistItemsIDs })
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(data => {
                const tags = Object.values(data);
                let flattenedSongTags = tags
                    .map(array => array.map(entry => parseInt(entry)))
                    .reduce((accumulator, currentValue) => accumulator.concat(currentValue), [])
                    .map(item => parseInt(item));
                flattenedSongTags = Array.from(new Set(flattenedSongTags));
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetTagInfo"]({
                    flattenedSongTags: flattenedSongTags,
                    unflattenedSongTags: data
                }));
            }));
        }));
        this.getTagInfo$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["CollectionActionTypes"].GetTagInfo), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(params => {
            return this.collectionService
                .getTagInfo({ tagids: params.flattenedSongTags })
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["switchMap"])(response => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetVibesSuccess"](Object.assign({ res: response }, params)));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(error => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_13__["EffectError"]());
            }));
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionEffects.prototype, "getCollectionData$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionEffects.prototype, "getCollectionDataNew$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionEffects.prototype, "extractSubSection$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionEffects.prototype, "setExtras$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionEffects.prototype, "getPaginatedViewPage$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionEffects.prototype, "searchArtist$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionEffects.prototype, "getSongTags$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionEffects.prototype, "getTagInfo$", void 0);
CollectionEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](8, Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_3__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Actions"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"],
        _services_collection_service__WEBPACK_IMPORTED_MODULE_11__["CollectionService"],
        _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_15__["SectionService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _services_extras_service__WEBPACK_IMPORTED_MODULE_12__["ExtrasService"],
        _anghami_services_collection_helper_service__WEBPACK_IMPORTED_MODULE_2__["CollectionHelperService"],
        _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_14__["CoverArtService"], String])
], CollectionEffects);



/***/ }),

/***/ "./src/app/core/redux/effects/dialogs-modals.effects.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/redux/effects/dialogs-modals.effects.ts ***!
  \**************************************************************/
/*! exports provided: DialogsModalsEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DialogsModalsEffects", function() { return DialogsModalsEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _components_confirmation_modal_confirmation_modal_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/confirmation-modal/confirmation-modal.component */ "./src/app/core/components/confirmation-modal/confirmation-modal.component.ts");
/* harmony import */ var _components_cropper_modal_cropper_modal_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/cropper-modal/cropper-modal.component */ "./src/app/core/components/cropper-modal/cropper-modal.component.ts");
/* harmony import */ var _components_lyrics_modal_lyrics_modal_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/lyrics-modal/lyrics-modal.component */ "./src/app/core/components/lyrics-modal/lyrics-modal.component.ts");
/* harmony import */ var _components_playlist_manager_playlist_manager_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../components/playlist-manager/playlist-manager.component */ "./src/app/core/components/playlist-manager/playlist-manager.component.ts");
/* harmony import */ var _components_redeem_modal_redeem_modal_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../components/redeem-modal/redeem-modal.component */ "./src/app/core/components/redeem-modal/redeem-modal.component.ts");
/* harmony import */ var _components_share_modal_share_modal_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../components/share-modal/share-modal.component */ "./src/app/core/components/share-modal/share-modal.component.ts");
/* harmony import */ var _components_users_list_modal_users_list_modal_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../components/users-list-modal/users-list-modal.component */ "./src/app/core/components/users-list-modal/users-list-modal.component.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _components_ads_modal_ads_modal_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../components/ads-modal/ads-modal.component */ "./src/app/core/components/ads-modal/ads-modal.component.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _core_refrences_WindowRef__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../core/refrences/WindowRef */ "./src/app/core/refrences/WindowRef.ts");




















let DialogsModalsEffects = class DialogsModalsEffects {
    constructor(actions$, modalService, store, coverartservice, _utilsService, window) {
        this.actions$ = actions$;
        this.modalService = modalService;
        this.store = store;
        this.coverartservice = coverartservice;
        this._utilsService = _utilsService;
        this.window = window;
        this.OpenAdsModal$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["DialogsActionTypes"].OpenAdsModal), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(payload => {
            this.modalService.dismissAll();
            const modalRef = this.modalService.open(_components_ads_modal_ads_modal_component__WEBPACK_IMPORTED_MODULE_17__["AdsModalComponent"], {
                backdrop: 'static',
                keyboard: false,
                windowClass: payload.type + '-dfp-ad-modal-holder'
            });
            modalRef.componentInstance.data = payload;
        }));
        this.openShareModal$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["DialogsActionTypes"].OpenShareModal), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])((payload) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (!this.window.nativeWindow['branchLoaded']) {
                yield this._utilsService.loadBranch({ _q: [], _v: 1 }, 'addListener applyCode autoAppIndex banner closeBanner closeJourney creditHistory credits data ' +
                    'deepview deepviewCta first getCode init link logout redeem referrals removeListener sendSMS ' +
                    'setBranchViewData setIdentity track validateCode trackCommerceEvent logEvent disableTracking'.split(' '), 0);
            }
            const modalRef = this.modalService.open(_components_share_modal_share_modal_component__WEBPACK_IMPORTED_MODULE_13__["ShareModalComponent"], {
                size: 'lg',
                windowClass: 'modal-holder modal-share'
            });
            const { coverArtImage, ArtistArt, title, id, artistID, coverArt, name, url, genericid, generictype, href, deeplink } = payload.meta;
            const type = payload.type;
            const realId = !!genericid ? genericid : id;
            let realUrl;
            switch (type) {
                case 'link':
                case 'deeplink': {
                    realUrl = !!url ? url : `https://play.anghami.com${href}`;
                    break;
                }
                default: {
                    realUrl = `https://play.anghami.com/${type}/${realId}`;
                }
            }
            modalRef.componentInstance.type = payload.type;
            modalRef.componentInstance.meta = Object.assign({}, payload.meta, { coverArt: type === 'artist'
                    ? this.coverartservice.getCoverArtImage(ArtistArt)
                    : coverArtImage || coverArt, title: type === 'artist' ? name : title, url: realUrl, id: realId, artistID: artistID || null });
        })));
        this.OpenUsersModal$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["DialogsActionTypes"].OpenUsersModal), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(payload => {
            const modalRef = this.modalService.open(_components_users_list_modal_users_list_modal_component__WEBPACK_IMPORTED_MODULE_14__["AnghamiUsersListModalComponent"], {
                windowClass: 'users-modal'
            });
            modalRef.componentInstance.section = payload.section;
            modalRef.componentInstance.type = payload.type;
        }));
        // @Effect({ dispatch: false })
        // openOwlModal$ = this.actions$.pipe(
        //   ofType<OpenOwlModal>(DialogsActionTypes.OpenOwlModal),
        //   map(action => action.payload),
        //   tap(payload => {
        //     const modalRef = this.modalService.open(OwlAnimationComponent, {
        //       windowClass: 'no-music-animation'
        //     });
        //     modalRef.componentInstance.callbacks = payload.callbacks;
        //   })4
        // );
        // @Effect({ dispatch: false })
        // openUploadMyMusicModal$ = this.actions$.pipe(
        //   ofType<OpenUploadMyMusicModal>(DialogsActionTypes.OpenUploadMyMusicModal),
        //   map(action => action.payload),
        //   tap(payload => {
        //     const modalRef = this.modalService.open(UploadMyMusicModalComponent, {
        //       size: 'lg',
        //       windowClass: 'modal-holder'
        //     });
        //   })
        // );
        this.openPlaylistManager$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["DialogsActionTypes"].OpenPlaylistManager), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(payload => {
            const ngbModalOptions = {
                backdrop: 'static',
                size: 'lg',
                windowClass: 'playlist-manager'
            };
            const modalRef = this.modalService.open(_components_playlist_manager_playlist_manager_component__WEBPACK_IMPORTED_MODULE_11__["PlaylistManagerComponent"], ngbModalOptions);
            modalRef.componentInstance.data = payload;
        }));
        this.openCropperModal$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["DialogsActionTypes"].OpenCropperModal), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(payload => {
            const ngbModalOptions = {
                backdrop: 'static',
                size: 'lg',
                windowClass: 'modal-holder'
            };
            const modalRef = this.modalService.open(_components_cropper_modal_cropper_modal_component__WEBPACK_IMPORTED_MODULE_9__["CropperModalComponent"], ngbModalOptions);
        }));
        this.openConfirmationModal$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["DialogsActionTypes"].OpenConfirmationModal), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(payload => {
            const ngbModalOptions = {
                backdrop: 'static',
                size: 'sm',
                windowClass: 'confirm'
            };
            const modalRef = this.modalService.open(_components_confirmation_modal_confirmation_modal_component__WEBPACK_IMPORTED_MODULE_8__["ConfirmationModalComponent"], ngbModalOptions);
            modalRef.componentInstance.data = payload;
        }));
        this.confirmationModalAnswer$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["DialogsActionTypes"].ConfirmationModalAnswer), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => {
            return action;
        }));
        this.openLyricsModal$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["DialogsActionTypes"].OpenLyricsModal), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["withLatestFrom"])(this.store.select(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_1__["getUser"])), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(([action, userdata]) => {
            if (userdata && userdata.plantype === '3') {
                // Is plus
                const modalRef = this.modalService.open(_components_lyrics_modal_lyrics_modal_component__WEBPACK_IMPORTED_MODULE_10__["LyricsModalComponent"], {
                    size: "sm",
                    windowClass: 'modal-lyrics'
                });
            }
            else {
                this.store.dispatch(new _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["OpenCustomDialog"]({
                    type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_15__["DIALOG_TYPES"].PLUS_FEATURE_WEB
                }));
            }
        }));
        this.OpenRedeemModal$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["DialogsActionTypes"].OpenRedeemModal), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(payload => {
            const ngbModalOptions = {
                size: 'lg',
                windowClass: payload && payload != null ? payload.class : ''
            };
            const modalRef = this.modalService.open(_components_redeem_modal_redeem_modal_component__WEBPACK_IMPORTED_MODULE_12__["RedeemModalComponent"], ngbModalOptions);
            modalRef.componentInstance.data = payload;
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsModalsEffects.prototype, "OpenAdsModal$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsModalsEffects.prototype, "openShareModal$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsModalsEffects.prototype, "OpenUsersModal$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsModalsEffects.prototype, "openPlaylistManager$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsModalsEffects.prototype, "openCropperModal$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsModalsEffects.prototype, "openConfirmationModal$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsModalsEffects.prototype, "confirmationModalAnswer$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsModalsEffects.prototype, "openLyricsModal$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsModalsEffects.prototype, "OpenRedeemModal$", void 0);
DialogsModalsEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Actions"],
        _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["NgbModal"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"],
        _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_2__["CoverArtService"],
        _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_18__["UtilService"],
        _core_refrences_WindowRef__WEBPACK_IMPORTED_MODULE_19__["WindowRef"]])
], DialogsModalsEffects);



/***/ }),

/***/ "./src/app/core/redux/effects/library.effects.ts":
/*!*******************************************************!*\
  !*** ./src/app/core/redux/effects/library.effects.ts ***!
  \*******************************************************/
/*! exports provided: LibraryEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LibraryEffects", function() { return LibraryEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/library.actions */ "./src/app/core/redux/actions/library.actions.ts");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _modules_player_player_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../modules/player/player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _services_collection_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/collection.service */ "./src/app/core/services/collection.service.ts");
/* harmony import */ var _services_library_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../services/library.service */ "./src/app/core/services/library.service.ts");
/* harmony import */ var _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../actions/error-handling.actions */ "./src/app/core/redux/actions/error-handling.actions.ts");
/* harmony import */ var _actions_user_actions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../actions/user.actions */ "./src/app/core/redux/actions/user.actions.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_services_socket_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/services/socket.service */ "./src/app/core/services/socket.service.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../enums/special-playlist-names.enum */ "./src/app/core/enums/special-playlist-names.enum.ts");
/* harmony import */ var _selectors_library_selector__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var rxjs_internal_operators_withLatestFrom__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs/internal/operators/withLatestFrom */ "./node_modules/rxjs/internal/operators/withLatestFrom.js");
/* harmony import */ var rxjs_internal_operators_withLatestFrom__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(rxjs_internal_operators_withLatestFrom__WEBPACK_IMPORTED_MODULE_23__);
























let LibraryEffects = class LibraryEffects {
    constructor(actions$, libraryService, collectionService, playerService, coverartservice, sectionService, locale, http, socketService, authService, store) {
        this.actions$ = actions$;
        this.libraryService = libraryService;
        this.collectionService = collectionService;
        this.playerService = playerService;
        this.coverartservice = coverartservice;
        this.sectionService = sectionService;
        this.locale = locale;
        this.http = http;
        this.socketService = socketService;
        this.authService = authService;
        this.store = store;
        this.getLibraryInfo$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].GetLibraryInfo), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(() => this.libraryService.getUserLibrary().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(data => {
            const enhancedSections = this.sectionService.enhanceSections(data);
            const linkIndex = enhancedSections.findIndex(section => section.type == 'link');
            const newsections = enhancedSections.filter(section => section.type != 'link');
            return Object.assign({}, enhancedSections, { headerLinks: enhancedSections[linkIndex], sections: newsections.map(elt => {
                    elt.initialNumItems = 5;
                    return elt;
                }) });
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(data => {
            return Object.assign({}, data, { headerLinks: Object.assign({}, data.headerLinks, { data: data.headerLinks.data.map(elt => {
                        elt.image = elt.image
                            .replace('local://', '')
                            .replace('-library', '');
                        elt.deeplink = elt.deeplink.replace('anghami:/', '/mymusic');
                        if (elt.deeplink.indexOf('downloads') > -1 && !!window['desktopClient']) {
                            elt.deeplink = elt.deeplink.replace('downloads', 'desktop-downloads');
                        }
                        return elt;
                    }) }) });
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(response => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLibraryInfoSuccess"](response));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_12__["EffectError"]());
        }))));
        this.getLikedSongs$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].GetLikedSongs), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(payload => {
            return this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_20__["select"])(_selectors_library_selector__WEBPACK_IMPORTED_MODULE_22__["getFollowedPlaylistsState"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])((followedPlaylists) => {
                if (followedPlaylists && followedPlaylists.length > 0) {
                    const likesPlaylist = followedPlaylists[0].data.find(playlist => {
                        return playlist.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_21__["SPECIAL_PLAYLIST_NAMES"].LIKES;
                    });
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(likesPlaylist);
                }
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
            }));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(likesPlaylist => {
            return this.collectionService
                .getCollectionData(_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_8__["CollectionTypes"].PLAYLIST, likesPlaylist.id)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(response => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLikedSongsSuccess"](response));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_12__["EffectError"]());
            }));
        }));
        this.getLikedSongsLoop$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].GetLikedSongsLoop), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(payload => {
            this.libraryService.getLikedOrDownloadedSongsLoop(payload.id, payload.page.toString()).then((response) => {
                response = this.libraryService.formatLikesAndDownloadsResponse(response);
                const sections = response.sections;
                const likedSongsSection = sections.filter(section => section.type === 'song')[0];
                const likedSongsHash = likedSongsSection.data.reduce((map, song) => {
                    map[song.id] = true;
                    return map;
                }, {});
                this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLikedSongsLoopSuccess"]({ likedSongsHash: likedSongsHash, likedSongsSection: response }));
                if (likedSongsSection.moreData) {
                    setTimeout(() => {
                        this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLikedSongsLoop"]({ id: payload.id, page: payload.page + 1 }));
                    }, 1000);
                }
            });
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
        }));
        this.getDownloadedSongsLoop$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].GetDownloadedSongsLoop), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(payload => {
            this.libraryService.getLikedOrDownloadedSongsLoop(payload.id, payload.page.toString()).then((response) => {
                response = this.libraryService.formatLikesAndDownloadsResponse(response);
                const sections = response.sections;
                const donwloadedSongsSection = sections.filter(section => section.type === 'song')[0];
                this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetDownloadedSongsLoopSuccess"]({ downloadedSongsSection: response }));
                if (donwloadedSongsSection.moreData) {
                    setTimeout(() => {
                        this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetDownloadedSongsLoop"]({ id: payload.id, page: payload.page + 1 }));
                    }, 1000);
                }
            });
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
        }));
        this.GetLikedSongsHashed$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].GetLikedSongsHashed), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(payload => {
            return this.libraryService.getLikedSongsPlaylist().switchMap(resp => {
                let songList = resp.sections[0].data;
                let songListHashed = {};
                songList.forEach(element => {
                    songListHashed[element.id] = true;
                });
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLikedSongsHashedSuccess"](songListHashed));
            });
        }));
        this.getLikedAlbums$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].GetLikedAlbums), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(() => this.libraryService.getLikedAlbums().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(response => response.sections[0]['data']), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(data => {
            data.forEach(album => {
                album.coverArtImage = this.coverartservice.getCoverArtImage(album.coverArt, 296);
                album.isContextSheet = true;
                album.href = '/album/' + album.id;
            });
            return data;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(response => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLikedAlbumsSuccess"](response));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_12__["EffectError"]());
        }))));
        this.getFollowedArtists$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].GetFollowedArtists), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(() => this.libraryService.getFollowedArtists().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(response => response.sections), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(sections => {
            if (!sections.find(elt => elt.group == 'hidden')) {
                let hiddenSection = {
                    group: 'hidden',
                    data: []
                };
                sections.push(hiddenSection);
            }
            return sections;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(sections => sections.map(section => {
            return Object.assign({}, section, { name: section.group, text: section && section.group
                    ? section.group == 'hidden'
                        ? 'Muted'
                        : section.group.charAt(0).toUpperCase() +
                            section.group.slice(1)
                    : undefined, title: undefined, data: section.data.map(artist => {
                    if (artist && artist.id) {
                        artist.coverArtImage = this.coverartservice.getCoverArtImage(artist.coverArt, 296);
                        artist.title = artist.name;
                        artist.err =
                            'https://anghamiwebcdn.akamaized.net/assets/img/artistholder_large.jpg';
                        artist.href = '/artist/' + artist.id;
                        artist.forceshow = true;
                        return artist;
                    }
                }) });
        })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(response => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetFollowedArtistsSuccess"](response));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_12__["EffectError"]());
        }))));
        this.getDownloads$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].GetDownloads), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(data => {
            const playlists = data.filter(elt => elt.displaytype === 'list' && elt.name === 'playlists');
            let downloads = {};
            if (playlists && playlists !== null && playlists.length > 0) {
                const downloadsObject = playlists[0].data &&
                    playlists[0].data !== null &&
                    playlists[0].data.length > 0
                    ? playlists[0].data.find(elt => elt.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_21__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS)
                    : {};
                if (downloadsObject &&
                    downloadsObject !== null &&
                    Object.keys(downloadsObject).length > 0) {
                    downloads = JSON.parse(JSON.stringify(downloadsObject));
                    downloads['list_type'] = 'playlist';
                    downloads['playlistid'] = downloadsObject.id;
                }
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetDownloadsSuccess"](downloads));
        }));
        this.getFollowedPlaylists$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].GetfollowedPlaylists), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(() => this.libraryService.getFollowedPlaylists().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(response => response['sections']), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(sections => {
            const newsections = sections.map(elt => {
                elt.initialNumItems = 12;
                elt.morebtn = 'More';
                return elt;
            });
            return newsections;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(sections => {
            return sections.map(section => {
                const buttons = !section.buttons || section.buttons == null
                    ? []
                    : section.buttons;
                return Object.assign({}, section, { isHidden: section.name === 'shared', text: section.name === 'playlists'
                        ? this.locale == 'ar'
                            ? ' قوائمي الموسيقيّة'
                            : this.locale == 'fr'
                                ? 'Mes Playlists'
                                : 'My Playlists'
                        : section.name === 'subscribed'
                            ? this.locale == 'ar'
                                ? 'القوائم المُتابَعة'
                                : this.locale == 'fr'
                                    ? 'Playlists Suivies'
                                    : 'My Followed Playlists'
                            : undefined, data: section.data.map(playlist => {
                        if (playlist && playlist.id) {
                            const thumb = playlist.coverArtImage || playlist.coverArt;
                            const coverArt = this.coverartservice.getCoverArtImage(thumb, 296);
                            const playlistObject = Object.assign({}, playlist, { coverArt });
                            playlistObject.isHidden =
                                playlist.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_21__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS ||
                                    playlist.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_21__["SPECIAL_PLAYLIST_NAMES"].LIKES;
                            playlistObject.isContextSheet = true;
                            playlistObject.err =
                                'https://anghamiwebcdn.akamaized.net/assets/img/trackholder.jpg';
                            playlistObject.href = '/playlist/' + playlist.id;
                            return playlistObject;
                        }
                    }), buttons: section.name === 'playlists'
                        ? buttons.concat([
                            {
                                deeplink: null,
                                text: this.locale === 'ar'
                                    ? '+ إنشاء قائمة موسيقية'
                                    : this.locale === 'fr'
                                        ? '+ Créer une playlist'
                                        : '+ Create Playlist',
                                type: 'create',
                                main: true
                            }
                        ])
                        : section.buttons });
            });
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(sections => {
            sections.forEach(section => {
                section.data.forEach(playlist => {
                    playlist.title = playlist.name;
                    playlist.coverArtImage = playlist.coverArt;
                    if (this.locale === 'ar') {
                        playlist.details = playlist.count + ((playlist.count >= 2 && playlist.count < 11) ? ' أغاني' : ' أغنية');
                    }
                    else {
                        playlist.details =
                            playlist.count +
                                ' song' +
                                (playlist.count > 1 || playlist.count == 0 ? 's' : '');
                    }
                });
                section.data.sort((a, b) => b.timestamp - a.timestamp);
            });
            return sections;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(response => {
            // get liked songs sections
            let likedSongsPlaylist = null;
            let downloadedSongsPlaylist = null;
            response.forEach(s => {
                if (s.name === 'playlists') {
                    likedSongsPlaylist = s.data.find(d => d.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_21__["SPECIAL_PLAYLIST_NAMES"].LIKES);
                    downloadedSongsPlaylist = s.data.find(d => d.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_21__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS);
                }
            });
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetFollowedPlaylistsSuccess"](response), new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLikedSongsLoop"]({ id: likedSongsPlaylist.id, page: 0 }), new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetDownloadedSongsLoop"]({ id: downloadedSongsPlaylist.id, page: 0 }));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_12__["EffectError"]());
        }))));
        this.LikeCollectionSuccess$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_actions_user_actions__WEBPACK_IMPORTED_MODULE_13__["UserActionTypes"].LikeCollectionSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(payload => {
            switch (payload.type) {
                case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_8__["CollectionTypes"].SONG: {
                    if (payload.dislike) {
                        return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["UpdateLikedSongsPlaylist"]({
                            collection: {
                                id: payload.id
                            },
                            disliked: payload.dislike
                        }));
                    }
                    else {
                        // return this.playerService.GetSongDataById(payload.id, false).pipe(
                        //   switchMap(track => {
                        //     return of(
                        //       new UpdateLikedSongsPlaylist({
                        //         collection: track,
                        //         disliked: payload.dislike
                        //       })
                        //     );
                        //   })
                        // );
                    }
                }
                case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_8__["CollectionTypes"].ALBUM: {
                    if (payload.dislike) {
                        return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["UpdateLikedAlbumsList"]({
                            collection: {
                                id: payload.id
                            },
                            disliked: payload.dislike
                        }));
                    }
                    else {
                        return this.playerService.getAlbumDataById(payload.id, false).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(album => {
                            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["UpdateLikedAlbumsList"]({
                                collection: album,
                                disliked: payload.dislike
                            }));
                        }));
                    }
                }
                default: {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
                }
            }
        }));
        this.likeSong$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].LikeSong), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(payload => payload.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])((payload) => {
            if (!this.authService.isUserLoggedIn()) {
                this.store.dispatch(new _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_18__["OpenCustomDialog"]({
                    type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_19__["DIALOG_TYPES"].LOGIN
                }));
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
            }
            const item = payload.item;
            this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["AddOrRemoveLikedSong"](item));
            let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpParams"]()
                .set('type', 'PUTplaylist')
                .set('name', _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_21__["SPECIAL_PLAYLIST_NAMES"].LIKES)
                .set('songid', item.id)
                .set('action', item.liked ? 'append' : 'delete')
                .set('extras', item.extras || '')
                .set('x-socket-id', this.socketService.socket.id);
            this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_15__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(data => {
                if (data.error) {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])({ error: true });
                }
                else {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(data);
                }
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])({ error: true }))).subscribe(result => {
                if (result && !result.error) {
                }
            });
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
        }));
        this.addOrRemoveLikedSong$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].AddOrRemoveLikedSong), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_internal_operators_withLatestFrom__WEBPACK_IMPORTED_MODULE_23__["withLatestFrom"])(this.store.select(_selectors_library_selector__WEBPACK_IMPORTED_MODULE_22__["getLikedSongsState"])), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(([song, likedSongs]) => {
            const newLikedSongs = Object.assign({}, likedSongs, { sections: likedSongs.sections.map(section => {
                    if (section.type === 'song') {
                        let found = false;
                        let newSection = Object.assign({}, section, { data: section.data.filter(item => {
                                if (item.id !== song.id) {
                                    return item;
                                }
                                else {
                                    found = true;
                                }
                            }) });
                        if (!found) {
                            //If song is not in likes add it
                            newSection.data.unshift(song);
                        }
                        return newSection;
                    }
                    else {
                        return section;
                    }
                }) });
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["SetLikesState"](newLikedSongs));
        }));
        this.likeAlbum$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].LikeAlbum), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(payload => payload.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])((payload) => {
            if (!this.authService.isUserLoggedIn()) {
                this.store.dispatch(new _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_18__["OpenCustomDialog"]({
                    type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_19__["DIALOG_TYPES"].LOGIN
                }));
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
            }
            const item = payload.item;
            let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpParams"]()
                .set('type', 'LIKEalbum')
                .set('albumid', item.id)
                .set('action', item.liked ? 'like' : 'unlike')
                .set('extras', item.extras || '')
                .set('x-socket-id', this.socketService.socket.id);
            this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_15__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(data => {
                if (data.error) {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])({ error: true });
                }
                else {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(data);
                }
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])({ error: true }))).subscribe(result => {
                if (result && !result.error) {
                    new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["UpdateLikedAlbumsList"]({
                        collection: item,
                        disliked: !item.liked
                    });
                }
            });
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
        }));
        this.FollowPlaylist$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].FollowPlaylist), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(payload => payload.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])((payload) => {
            if (!this.authService.isUserLoggedIn()) {
                this.store.dispatch(new _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_18__["OpenCustomDialog"]({
                    type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_19__["DIALOG_TYPES"].LOGIN
                }));
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
            }
            const item = payload.item;
            let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpParams"]()
                .set('type', 'UPDATEplaylist')
                .set('action', item.followed ? 'subscribe' : 'unsubscribe')
                .set('playlistid', item.id)
                .set('extras', item.extras || '')
                .set('x-socket-id', this.socketService.socket.id);
            this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_15__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(data => {
                if (data.error) {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])({ error: true });
                }
                else {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(data);
                }
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])({ error: true }))).subscribe(result => {
                if (result && !result.error) {
                }
            });
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
        }));
        this.FollowArtist$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].FollowArtist), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(payload => payload.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])((payload) => {
            if (!this.authService.isUserLoggedIn()) {
                this.store.dispatch(new _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_18__["OpenCustomDialog"]({
                    type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_19__["DIALOG_TYPES"].LOGIN
                }));
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
            }
            const item = payload.item;
            let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpParams"]()
                .set('type', 'followARTIST')
                .set('action', item.followed ? 'follow' : 'unfollow')
                .set('artistid', item.id)
                .set('extras', item.extras || '')
                .set('x-socket-id', this.socketService.socket.id);
            this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_15__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(data => {
                if (data.error) {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])({ error: true });
                }
                else {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(data);
                }
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])({ error: true }))).subscribe(result => {
                if (result && !result.error) {
                }
            });
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "getLibraryInfo$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "getLikedSongs$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "getLikedSongsLoop$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "getDownloadedSongsLoop$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "GetLikedSongsHashed$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "getLikedAlbums$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "getFollowedArtists$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "getDownloads$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "getFollowedPlaylists$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "LikeCollectionSuccess$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "likeSong$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "addOrRemoveLikedSong$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "likeAlbum$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "FollowPlaylist$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Effect"])({ dispatch: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LibraryEffects.prototype, "FollowArtist$", void 0);
LibraryEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](6, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["Actions"],
        _services_library_service__WEBPACK_IMPORTED_MODULE_11__["LibraryService"],
        _services_collection_service__WEBPACK_IMPORTED_MODULE_10__["CollectionService"],
        _modules_player_player_service__WEBPACK_IMPORTED_MODULE_9__["PlayerService"],
        _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_2__["CoverArtService"],
        _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_3__["SectionService"], String, _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClient"],
        _anghami_services_socket_service__WEBPACK_IMPORTED_MODULE_16__["SocketService"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_17__["AuthService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_20__["Store"]])
], LibraryEffects);



/***/ }),

/***/ "./src/app/core/redux/effects/search.effects.ts":
/*!******************************************************!*\
  !*** ./src/app/core/redux/effects/search.effects.ts ***!
  \******************************************************/
/*! exports provided: SearchEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchEffects", function() { return SearchEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _services_search_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/search.service */ "./src/app/core/services/search.service.ts");
/* harmony import */ var _actions_search_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../actions/search.actions */ "./src/app/core/redux/actions/search.actions.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");










let SearchEffects = class SearchEffects {
    constructor(actions$, searchService, sectionService, coverartService) {
        this.actions$ = actions$;
        this.searchService = searchService;
        this.sectionService = sectionService;
        this.coverartService = coverartService;
        /**
         * @description actions to dispatch when actions related to search are fired
         */
        this.search$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_actions_search_actions__WEBPACK_IMPORTED_MODULE_8__["SearchActionTypes"].Search), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["debounceTime"])(300, rxjs__WEBPACK_IMPORTED_MODULE_4__["asyncScheduler"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(searchPayload => {
            if (searchPayload.query === '') {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["empty"])();
            }
            const nextSearch$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_actions_search_actions__WEBPACK_IMPORTED_MODULE_8__["SearchActionTypes"].Search), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["skip"])(1));
            return this.searchService
                .performSearch(searchPayload.query, searchPayload.searchType, searchPayload.edge)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["takeUntil"])(nextSearch$), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(searchResponse => {
                let enhancedSections = this.sectionService.enhanceSections(searchResponse);
                enhancedSections = enhancedSections.map(s => {
                    if (s.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_6__["CollectionTypes"].SONG ||
                        s.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_6__["CollectionTypes"].GENRIC_ITEM) {
                        return Object.assign({}, s, { playmode: 'related' });
                    }
                    else {
                        if (s.displaytype === 'card') {
                            return Object.assign({}, s, { displaytype: 'bigimages', initialNumItems: 30 });
                        }
                        else {
                        }
                        return s;
                    }
                });
                enhancedSections = enhancedSections.filter(section => !(section.count == 0 && !section.text));
                const payload = {
                    query: searchPayload.query,
                    sections: enhancedSections,
                    refreshgroups: searchResponse.refreshgroups
                };
                return new _actions_search_actions__WEBPACK_IMPORTED_MODULE_8__["SearchComplete"](payload);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _actions_search_actions__WEBPACK_IMPORTED_MODULE_8__["SearchError"](err))));
        }));
        this.LoadSearchTags$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_actions_search_actions__WEBPACK_IMPORTED_MODULE_8__["SearchActionTypes"].LoadSearchTags), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(action => {
            return this.searchService.getTags().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((response) => {
                let tags = [];
                response.sections.forEach(tagGroup => {
                    if (tagGroup.type === 'tag') {
                        tags = tags.concat(tagGroup.data);
                    }
                });
                return new _actions_search_actions__WEBPACK_IMPORTED_MODULE_8__["GotTags"]({ tags: tags });
            }));
        }));
        this.searchSugestions$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_actions_search_actions__WEBPACK_IMPORTED_MODULE_8__["SearchActionTypes"].GetSearchSuggestions), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(searchPayload => {
            return this.searchService.getSearchSuggestions().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(searchResponse => {
                let item = [];
                item = searchResponse.map(item => {
                    return Object.assign({}, item, { name: item.title, image: this.coverartService.getCoverArtImage(item.coverArtID, 600), href: '/playlist/' + item.id });
                });
                var collection = {
                    alltitle: 'recomendedplaylists',
                    count: item.length,
                    data: item,
                    displaytype: 'card',
                    group: 'playlists',
                    type: 'playlist',
                    name: 'recomendedplaylists',
                    sectionid: 9999,
                    initialNumItems: 4,
                    searchgroup: 'recomendedplaylists'
                };
                return new _actions_search_actions__WEBPACK_IMPORTED_MODULE_8__["GotSearchSuggestions"](collection);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _actions_search_actions__WEBPACK_IMPORTED_MODULE_8__["SearchError"](err))));
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], SearchEffects.prototype, "search$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], SearchEffects.prototype, "LoadSearchTags$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], SearchEffects.prototype, "searchSugestions$", void 0);
SearchEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["Actions"],
        _services_search_service__WEBPACK_IMPORTED_MODULE_7__["SearchService"],
        _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_9__["SectionService"],
        _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_1__["CoverArtService"]])
], SearchEffects);



/***/ }),

/***/ "./src/app/core/redux/selectors/router.selectors.ts":
/*!**********************************************************!*\
  !*** ./src/app/core/redux/selectors/router.selectors.ts ***!
  \**********************************************************/
/*! exports provided: selectReducerState, getRouterInfo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectReducerState", function() { return selectReducerState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRouterInfo", function() { return getRouterInfo; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");

// Reducer selectors
const selectReducerState = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createFeatureSelector"])('router');
const getRouterInfo = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(selectReducerState, state => state.state);


/***/ }),

/***/ "./src/app/core/services/ads.service.ts":
/*!**********************************************!*\
  !*** ./src/app/core/services/ads.service.ts ***!
  \**********************************************/
/*! exports provided: AdsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdsService", function() { return AdsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AdsService = class AdsService {
    constructor() {
        this.refreshPlayerLeaderBoard = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.PlayerleaderboardInitialized = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.videoParams = [];
        this.videoParams = ['uAge', 'uLang', 'uGender', 'musicPref', 'genre'];
    }
    refreshPlayerLeaderboard() {
        this.refreshPlayerLeaderBoard.emit(true);
    }
    initPlayerLeaderBoard(val) {
        this.PlayerleaderboardInitialized.emit(val);
    }
    buildDfpttags(params) {
        let ttags = '';
        let videoTags = '';
        let genre = '';
        const adParamsKeys = Object.keys(params);
        if (adParamsKeys &&
            params &&
            params.constructor === Object &&
            adParamsKeys.length > 0) {
            adParamsKeys.forEach((key) => {
                if (params.hasOwnProperty(key)) {
                    ttags += `&ttag=${key}:${params[key]}`;
                    if (this.videoParams.indexOf(key) > -1 || key.includes('genre')) {
                        if (key.includes('genre')) {
                            genre += `,${params[key]}`;
                        }
                        else if (this.videoParams.indexOf(key) > -1) {
                            if (key === 'uGender') {
                                const genderEnums = {
                                    'male': 1,
                                    'female': 2
                                };
                                videoTags += `&${key}=${genderEnums[key] && genderEnums[key] !== null ? genderEnums[key] : 0}`;
                            }
                            else if (key === 'musicPref') {
                                videoTags += `&${key}=${decodeURIComponent(params[key])}`;
                            }
                            else {
                                videoTags += `&${this.videoParams[this.videoParams.indexOf(key)]}=${params[key]}`;
                            }
                        }
                    }
                }
            });
            if (genre && genre !== '') {
                videoTags += `&genre=${genre.slice(1)}`;
            }
        }
        return {
            'ttags': ttags,
            'videoTags': (videoTags.length > 0 ? videoTags.slice(1) : videoTags)
        };
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], AdsService.prototype, "refreshPlayerLeaderBoard", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], AdsService.prototype, "PlayerleaderboardInitialized", void 0);
AdsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], AdsService);



/***/ }),

/***/ "./src/app/core/services/collection-helper.service.ts":
/*!************************************************************!*\
  !*** ./src/app/core/services/collection-helper.service.ts ***!
  \************************************************************/
/*! exports provided: CollectionHelperService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CollectionHelperService", function() { return CollectionHelperService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../enums/special-playlist-names.enum */ "./src/app/core/enums/special-playlist-names.enum.ts");













let CollectionHelperService = class CollectionHelperService {
    constructor(_utilsService, sectionService, locale, store, _authService, coverartservice) {
        this._utilsService = _utilsService;
        this.sectionService = sectionService;
        this.locale = locale;
        this.store = store;
        this._authService = _authService;
        this.coverartservice = coverartservice;
        // we use take (1) to automatically unsubscribe
        this.store
            .select(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_2__["getUser"])
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe(user => {
            this.user = user;
        });
    }
    buildCollectionData(data, collectionId, collectionType, librarySection) {
        const isloggedin = this._authService.isUserLoggedIn();
        const sectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"](data, []);
        const thumb = sectionMeta.coverArtImage || sectionMeta.coverArt || 0;
        let newbuttons = sectionMeta.buttons && sectionMeta.buttons != null
            ? JSON.parse(JSON.stringify(sectionMeta.buttons))
            : [];
        this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_3__["getFollowedPlaylistsState"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])((data) => {
            let playlists = [];
            if (data && data !== null && data.length > 0) {
                data = data.filter(elt => elt.name === 'playlists');
                data.forEach(elt => {
                    if (elt.data) {
                        playlists.push(...elt.data);
                    }
                });
                playlists = playlists.filter(elt => elt.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_12__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS ||
                    elt.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_12__["SPECIAL_PLAYLIST_NAMES"].LIKES);
            }
            return playlists;
        }))
            .subscribe(data => {
            this.disabledPlaylists = data;
            const iscollab = !!(sectionMeta.collaborative && sectionMeta.collaborative === 1);
            const canedit = !!sectionMeta.canedit;
            const isfeatured = !!sectionMeta.isfeatured && sectionMeta.isfeatured == 'true';
            if (this.disabledPlaylists &&
                this.disabledPlaylists != null &&
                this.disabledPlaylists.length > 0) {
                this.disabled =
                    isfeatured ||
                        !canedit || // iscollab && !canedit
                        (this.disabledPlaylists &&
                            this.disabledPlaylists.find(elt => elt.id == sectionMeta.id)
                            ? true
                            : false);
            }
            else {
                this.disabled = !canedit || isfeatured;
            }
            if (collectionType === 'playlist') {
                if (sectionMeta.canedit) {
                    if (newbuttons && newbuttons != null) {
                        newbuttons = newbuttons.concat([
                            {
                                deeplink: null,
                                text: this.locale === 'ar'
                                    ? 'تعديل القائمة الموسيقية'
                                    : this.locale === 'fr'
                                        ? 'Modifier la Playlist'
                                        : 'Edit Playlist',
                                type: 'edit'
                            }
                        ]);
                    }
                }
                if (!this.disabled) {
                    newbuttons = newbuttons.concat([
                        {
                            deeplink: null,
                            text: this.locale === 'ar'
                                ? 'حذف قائمة الموسيقى'
                                : this.locale === 'fr'
                                    ? 'Supprimer la Playlist'
                                    : 'Delete Playlist',
                            type: 'delete'
                        }
                    ]);
                }
                if (!sectionMeta.collaborative || sectionMeta.collaborative !== 1) {
                    newbuttons = newbuttons.filter(elt => elt.type !== 'invite');
                }
            }
            if (collectionType === 'song') {
                const btnsArr = [
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'أضف الى قائمة الموسيقى'
                            : this.locale === 'fr'
                                ? 'Ajouter à une playlist'
                                : 'Add to Playlist',
                        type: 'add_to_playlist'
                    },
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'الإضافة إلى قائمة الاستماع'
                            : this.locale === 'fr'
                                ? 'Ajouter à la file'
                                : 'Add to Queue',
                        type: 'AddToQueue'
                    },
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'الاستماع تالياً'
                            : this.locale === 'fr'
                                ? 'Écouter juste après'
                                : 'Play next',
                        type: 'playnext'
                    },
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'اذهب الى الفنان'
                            : this.locale === 'fr'
                                ? "Voir l'artiste"
                                : 'Go To Artist',
                        type: 'artist'
                    },
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'اذهب الى الألبوم'
                            : this.locale === 'fr'
                                ? "Voir l'album"
                                : 'Go To Album',
                        type: 'albums'
                    }
                ];
                if (this.user && this.user.plantype !== '3') {
                    btnsArr.splice(1, 1);
                }
                newbuttons = newbuttons.concat(btnsArr);
            }
            if (collectionType === 'artist') {
                const muteText = {
                    mute: {
                        ar: 'حجب هذا الفنان',
                        en: 'Mute artist',
                        fr: 'Masquer cet artiste'
                    },
                    unmute: {
                        ar: 'إظهار هذا الفنان',
                        en: 'Unmute artist',
                        fr: 'Afficher cet artiste'
                    }
                };
                if (sectionMeta && sectionMeta != null) {
                    newbuttons = newbuttons.concat([
                        {
                            deeplink: null,
                            text: sectionMeta.hidden
                                ? muteText['unmute'][this.locale.split('-')[0]]
                                : muteText['mute'][this.locale.split('-')[0]],
                            type: 'mute_artist'
                        }
                    ]);
                }
            }
        });
        // if (!isloggedin) {
        //   newbuttons = newbuttons.filter(elt => elt.type !== 'follow');
        // }
        let lstSection;
        let duration = sectionMeta.duration || 0;
        if (sectionMeta && sectionMeta.sections && sectionMeta.sections !== null) {
            if (sectionMeta.list_type !== 'song' && collectionType !== 'video') {
                lstSection = sectionMeta.sections.find(elt => elt.displaytype === 'list' && elt.type === 'song');
                if (lstSection && lstSection !== null) {
                    duration = this._utilsService.getListDuration(lstSection.data);
                }
            }
            else {
                duration = sectionMeta.duration;
            }
            sectionMeta.sections.forEach(section => {
                if (section.displaytype === 'widenew') {
                    section.data.forEach(elt => {
                        elt.details =
                            elt.details && elt.details !== null ? elt.details : elt.artist;
                    });
                }
            });
        }
        const newSectionMeta = Object.assign({}, sectionMeta, { coverArtImage: this.coverartservice.getCoverArtImage(thumb, 296), ArtistArt: this.coverartservice.getCoverArtImage(sectionMeta.ArtistArt, 296), buttons: newbuttons, numsongs: collectionType === 'playlist'
                ? !sectionMeta.numsongs || sectionMeta.numsongs == null
                    ? '0'
                    : sectionMeta.numsongs
                : sectionMeta.numsongs, duration: duration });
        const filtered = this.sectionService.filterSections(data, {
            type: ['placeholder', 'story'],
            group: ['editorial', 'requests_preview', 'uservideos', 'uservideos_old']
        });
        data = Object.assign({}, filtered.response);
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["from"])([
            new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["SetExtras"]({ extras: data.extras }),
            new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["SetCollectionMeta"](newSectionMeta),
            new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["GetCollectionSuccess"]({
                sections: this.sectionService.enhanceSections(data, librarySection)
            }),
            new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["SetCollectionInfo"]({
                type: collectionType,
                id: collectionId.indexOf('?') === -1
                    ? collectionId
                    : collectionId.slice(0, collectionId.indexOf('?')),
                librarySection: librarySection
            }),
            new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_1__["ExtractSubSection"]({
                // type: 'question',
                group: 'editorial',
                sections: this.sectionService.enhanceSections(filtered.sideSections)
            })
        ]);
    }
    buildCollectionDataNew(data, collectionId, collectionType, librarySection) {
        const isloggedin = this._authService.isUserLoggedIn();
        const sectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"](data, []);
        const thumb = sectionMeta.coverArtImage || sectionMeta.coverArt || 0;
        let newbuttons = sectionMeta.buttons && sectionMeta.buttons != null
            ? JSON.parse(JSON.stringify(sectionMeta.buttons))
            : [];
        this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_3__["getFollowedPlaylistsState"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])((data) => {
            let playlists = [];
            if (data && data !== null && data.length > 0) {
                data = data.filter(elt => elt.name === 'playlists');
                data.forEach(elt => {
                    if (elt.data) {
                        playlists.push(...elt.data);
                    }
                });
                playlists = playlists.filter(elt => elt.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_12__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS ||
                    elt.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_12__["SPECIAL_PLAYLIST_NAMES"].LIKES);
            }
            return playlists;
        }))
            .subscribe(data => {
            this.disabledPlaylists = data;
            const iscollab = !!(sectionMeta.collaborative && sectionMeta.collaborative === 1);
            const canedit = !!sectionMeta.canedit;
            const isfeatured = !!sectionMeta.isfeatured && sectionMeta.isfeatured == 'true';
            if (this.disabledPlaylists &&
                this.disabledPlaylists != null &&
                this.disabledPlaylists.length > 0) {
                this.disabled =
                    isfeatured ||
                        !canedit || // iscollab && !canedit
                        (this.disabledPlaylists &&
                            this.disabledPlaylists.find(elt => elt.id == sectionMeta.id)
                            ? true
                            : false);
            }
            else {
                this.disabled = !canedit || isfeatured;
            }
            if (collectionType === 'playlist') {
                if (sectionMeta.canedit) {
                    if (newbuttons && newbuttons != null) {
                        newbuttons = newbuttons.concat([
                            {
                                deeplink: null,
                                text: this.locale === 'ar'
                                    ? 'تعديل القائمة الموسيقية'
                                    : this.locale === 'fr'
                                        ? 'Modifier la Playlist'
                                        : 'Edit Playlist',
                                type: 'edit'
                            }
                        ]);
                    }
                }
                if (!this.disabled) {
                    newbuttons = newbuttons.concat([
                        {
                            deeplink: null,
                            text: this.locale === 'ar'
                                ? 'حذف قائمة الموسيقى'
                                : this.locale === 'fr'
                                    ? 'Supprimer la Playlist'
                                    : 'Delete Playlist',
                            type: 'delete'
                        }
                    ]);
                }
                if (!sectionMeta.collaborative || sectionMeta.collaborative !== 1) {
                    newbuttons = newbuttons.filter(elt => elt.type !== 'invite');
                }
            }
            if (collectionType === 'song') {
                const btnsArr = [
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'أضف الى قائمة الموسيقى'
                            : this.locale === 'fr'
                                ? 'Ajouter à une playlist'
                                : 'Add to Playlist',
                        type: 'add_to_playlist'
                    },
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'الإضافة إلى قائمة الاستماع'
                            : this.locale === 'fr'
                                ? 'Ajouter à la file'
                                : 'Add to Queue',
                        type: 'AddToQueue'
                    },
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'الاستماع تالياً'
                            : this.locale === 'fr'
                                ? 'Écouter juste après'
                                : 'Play next',
                        type: 'playnext'
                    },
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'اذهب الى الفنان'
                            : this.locale === 'fr'
                                ? "Voir l'artiste"
                                : 'Go To Artist',
                        type: 'artist'
                    },
                    {
                        deeplink: null,
                        text: this.locale === 'ar'
                            ? 'اذهب الى الألبوم'
                            : this.locale === 'fr'
                                ? "Voir l'album"
                                : 'Go To Album',
                        type: 'albums'
                    }
                ];
                if (this.user && this.user.plantype !== '3') {
                    btnsArr.splice(1, 1);
                }
                newbuttons = newbuttons.concat(btnsArr);
            }
            if (collectionType === 'artist') {
                const muteText = {
                    mute: {
                        ar: 'حجب هذا الفنان',
                        en: 'Mute artist',
                        fr: 'Masquer cet artiste'
                    },
                    unmute: {
                        ar: 'إظهار هذا الفنان',
                        en: 'Unmute artist',
                        fr: 'Afficher cet artiste'
                    }
                };
                if (sectionMeta && sectionMeta != null) {
                    newbuttons = newbuttons.concat([
                        {
                            deeplink: null,
                            text: sectionMeta.hidden
                                ? muteText['unmute'][this.locale.split('-')[0]]
                                : muteText['mute'][this.locale.split('-')[0]],
                            type: 'mute_artist'
                        }
                    ]);
                }
            }
        });
        let lstSection;
        let duration = sectionMeta.duration || 0;
        if (sectionMeta && sectionMeta.sections && sectionMeta.sections !== null) {
            if (sectionMeta.list_type !== 'song' && collectionType !== 'video') {
                lstSection = sectionMeta.sections.find(elt => elt.displaytype === 'list' && elt.type === 'song');
                if (lstSection && lstSection !== null) {
                    duration = this._utilsService.getListDuration(lstSection.data);
                }
            }
            else {
                duration = sectionMeta.duration;
            }
            sectionMeta.sections.forEach(section => {
                if (section.displaytype === 'widenew') {
                    section.data.forEach(elt => {
                        elt.details =
                            elt.details && elt.details !== null ? elt.details : elt.artist;
                    });
                }
            });
        }
        const newSectionMeta = Object.assign({}, sectionMeta, { coverArtImage: this.coverartservice.getCoverArtImage(thumb, 296), ArtistArt: this.coverartservice.getCoverArtImage(sectionMeta.ArtistArt, 296), buttons: newbuttons, numsongs: collectionType === 'playlist'
                ? !sectionMeta.numsongs || sectionMeta.numsongs == null
                    ? '0'
                    : sectionMeta.numsongs
                : sectionMeta.numsongs, duration: duration });
        const filtered = this.sectionService.filterSections(data, {
            type: ['placeholder', 'story'],
            group: ['editorial', 'requests_preview', 'uservideos', 'uservideos_old']
        });
        data = Object.assign({}, filtered.response);
        let enhancedSections = this.sectionService.enhanceSections(data, librarySection);
        enhancedSections = enhancedSections.map(section => {
            return Object.assign({}, section, { initialNumItems: parseInt(section.initialNumItems) });
        });
        return {
            sections: enhancedSections,
            collectionType: collectionType,
            collectionId: collectionId.indexOf('?') === -1
                ? collectionId
                : collectionId.slice(0, collectionId.indexOf('?')),
            librarySection: librarySection,
            collectionMeta: newSectionMeta
        };
    }
};
CollectionHelperService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_6__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilService"],
        _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_11__["SectionService"], String, _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
        _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_10__["CoverArtService"]])
], CollectionHelperService);



/***/ }),

/***/ "./src/app/core/services/library.service.ts":
/*!**************************************************!*\
  !*** ./src/app/core/services/library.service.ts ***!
  \**************************************************/
/*! exports provided: LibraryService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LibraryService", function() { return LibraryService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../enums/special-playlist-names.enum */ "./src/app/core/enums/special-playlist-names.enum.ts");
/* harmony import */ var _anghami_services_gateway_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/gateway.service */ "./src/app/core/services/gateway.service.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _coverart_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./coverart.service */ "./src/app/core/services/coverart.service.ts");










var OUTPUTS;
(function (OUTPUTS) {
    OUTPUTS["JSONHP"] = "jsonhp";
    OUTPUTS["JSON"] = "json";
})(OUTPUTS || (OUTPUTS = {}));
/**
 * Library Service to retrieve user related albums, playlists, artists
 */
let LibraryService = class LibraryService {
    constructor(http, _gatewayService, sectionService, covertArtService) {
        this.http = http;
        this._gatewayService = _gatewayService;
        this.sectionService = sectionService;
        this.covertArtService = covertArtService;
    }
    getUserLibrary() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETlibrary');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getLikedOrDownloadedSongsLoop(playlistId, page) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const body = {
                playlistId: playlistId,
                page: page,
                reverse: true,
                output: OUTPUTS.JSONHP
            };
            const res = yield this._gatewayService.gateway.getPlaylistData(body);
            return res;
        });
    }
    getLikedSongsPlaylist() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETplaylist')
            .set('nopaging', '1')
            .set('playlistname', _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_6__["SPECIAL_PLAYLIST_NAMES"].LIKES);
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    formatLikesAndDownloadsResponse(collection) {
        if (collection.coverArt) {
            if (this.covertArtService.supportsWebP) {
                collection.coverArt = "https://angartwork.akamaized.net//webp/?id=" + collection.coverArt + "&size=296";
            }
            else {
                collection.coverArt = "https://angartwork.akamaized.net/?id=" + collection.coverArt + "&size=296";
            }
        }
        if (collection.coverArtImage) {
            if (this.covertArtService.supportsWebP) {
                collection.coverArtImage = "https://angartwork.akamaized.net//webp/?id=" + collection.coverArtImage + "&size=296";
            }
            else {
                collection.coverArtImage = "https://angartwork.akamaized.net/?id=" + collection.coverArtImage + "&size=296";
            }
        }
        return Object.assign({}, collection, { sections: collection.sections.map(section => {
                return Object.assign({}, section, { data: section.data.map(item => {
                        if (item.thumbnailid) {
                            if (this.covertArtService.supportsWebP) {
                                item.coverArtImage = "https://angartwork.akamaized.net//webp/?id=" + item.thumbnailid + "&size=296";
                            }
                            else {
                                item.coverArtImage = "https://angartwork.akamaized.net/?id=" + item.thumbnailid + "&size=296";
                            }
                        }
                        if (item.ArtistArt) {
                            if (this.covertArtService.supportsWebP) {
                                item.coverArtImage = "https://angartwork.akamaized.net//webp/?id=" + item.ArtistArt + "&size=296";
                            }
                            else {
                                item.coverArtImage = "https://angartwork.akamaized.net/?id=" + item.ArtistArt + "&size=296";
                            }
                        }
                        if (section.type) {
                            item.href = this.sectionService.getItemHref(item, section.type);
                        }
                        return item;
                    }) });
            }) });
    }
    getLikedAlbums() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETlikedalbums');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getFollowedArtists() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETfollowArtistList');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getFollowedPlaylists() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETplaylists');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
};
LibraryService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _anghami_services_gateway_service__WEBPACK_IMPORTED_MODULE_7__["GatewayService"],
        _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_8__["SectionService"], _coverart_service__WEBPACK_IMPORTED_MODULE_9__["CoverArtService"]])
], LibraryService);



/***/ }),

/***/ "./src/app/core/services/onboarding.service.ts":
/*!*****************************************************!*\
  !*** ./src/app/core/services/onboarding.service.ts ***!
  \*****************************************************/
/*! exports provided: OnboardingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OnboardingService", function() { return OnboardingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");







let OnboardingService = class OnboardingService {
    constructor(http, _cookieService) {
        this.http = http;
        this._cookieService = _cookieService;
    }
    getSuggestedArtists(musiclang = '0', page = '0', ignoredartists, chosenGenres) {
        const fp = this._cookieService.get('fingerprint');
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('type', 'GETsuggestedArtists')
            .set('sid', fp)
            .set('musiclang', musiclang)
            .set('output', 'jsonhp')
            .set('source', 'onboarding')
            .set('page', page)
            .set('ignoredartists', ignoredartists)
            .set('chosenGenres', chosenGenres);
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getTabSearch(musiclang, query) {
        const fp = this._cookieService.get('fingerprint');
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('type', 'GETtabsearch')
            .set('sid', fp)
            .set('musiclang', musiclang)
            .set('output', 'jsonhp')
            .set('source', 'onboarding')
            .set('searchtype', 'artist')
            .set('query', query);
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getFollowedArtists() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('type', 'GETfollowArtistList');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getSuggestedGenres(musiclang = '0') {
        const fp = this._cookieService.get('fingerprint');
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('type', 'GETsuggestedgenres')
            .set('output', 'jsonhp')
            .set('sid', fp)
            .set('musiclang', musiclang);
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    updateProfile(params) {
        const fp = this._cookieService.get('fingerprint');
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('type', 'UPDATEprofile')
            .set('ouput', 'jsonhp')
            .set('sid', fp)
            .set('firstname', params.firstname)
            .set('lastname', params.lastname)
            .set('birthdate', params.birthdate)
            .set('imageurl', params.imageurl ? params.imageurl.toString() : '');
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                    title: data.error.message || 'An error has occured',
                    displaymode: 'toast'
                });
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    followArtists(artists) {
        const fp = this._cookieService.get('fingerprint');
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('type', 'followARTIST')
            .set('ouput', 'jsonhp')
            .set('sid', fp)
            .set('action', 'follow')
            .set('artistID', artists);
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                    title: data.error.message || 'An error has occured',
                    displaymode: 'toast'
                });
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    unfollowArtist(artistID) {
        const fp = this._cookieService.get('fingerprint');
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('type', 'followARTIST')
            .set('ouput', 'jsonhp')
            .set('sid', fp)
            .set('action', 'unfollow')
            .set('artistID', artistID);
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                    title: data.error.message || 'An error has occured',
                    displaymode: 'toast'
                });
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    setMusicLanguage(musiclang) {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('type', 'POSTuserpreferences')
            .set('musiclang', musiclang);
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                    title: data.error.message || 'An error has occured',
                    displaymode: 'toast'
                });
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
};
OnboardingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
        ngx_cookie__WEBPACK_IMPORTED_MODULE_6__["CookieService"]])
], OnboardingService);



/***/ }),

/***/ "./src/app/modules/base/base-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/modules/base/base-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: matcherFunction, matcherFunctionMore, BaseRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "matcherFunction", function() { return matcherFunction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "matcherFunctionMore", function() { return matcherFunctionMore; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseRoutingModule", function() { return BaseRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _core_guards_auth_guard_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../core/guards/auth-guard.guard */ "./src/app/core/guards/auth-guard.guard.ts");
/* harmony import */ var _core_guards_view_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core/guards/view-guard */ "./src/app/core/guards/view-guard.ts");
/* harmony import */ var _login_components_no_internet_no_internet_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../login/components/no-internet/no-internet.component */ "./src/app/modules/login/components/no-internet/no-internet.component.ts");
/* harmony import */ var _base_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./base.component */ "./src/app/modules/base/base.component.ts");



// import { ErrorPageComponent } from '../../core/components/error-page/error-page.component';




const routes = [
    {
        path: '',
        component: _base_component__WEBPACK_IMPORTED_MODULE_6__["BaseComponent"],
        children: [
            {
                path: 'home',
                loadChildren: './explore/explore.module#ExploreModule',
                pathMatch: 'full'
            },
            {
                path: 'settings',
                loadChildren: './settings/settings.module#SettingsModule',
                pathMatch: 'full'
            },
            {
                path: 'preferences',
                loadChildren: './settings/settings.module#SettingsModule',
                pathMatch: 'full'
            },
            {
                path: 'mymusic/likes',
                redirectTo: '/likes',
                pathMatch: 'prefix'
            },
            {
                path: 'mymusic/downloads',
                redirectTo: '/downloads',
                pathMatch: 'prefix'
            },
            {
                path: 'personal-dj',
                loadChildren: './pdj/pdj.module#PDJModule',
                pathMatch: 'full'
            },
            {
                path: 'mymusic',
                loadChildren: './mymusic/mymusic.module#MymusicModule',
                pathMatch: 'prefix',
                canActivate: [_core_guards_auth_guard_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
                data: { preload: true, delay: true }
            },
            {
                path: 'uservideo/:id',
                redirectTo: '/story/:id',
                pathMatch: 'full'
            },
            {
                path: 'tags/:id',
                redirectTo: '/tag/:id',
                pathMatch: 'full'
            },
            {
                path: 'search/:query/:searchGroup',
                loadChildren: './search/search.module#SearchModule',
                pathMatch: 'full'
            },
            {
                path: 'search/:query',
                loadChildren: './search/search.module#SearchModule',
                pathMatch: 'full'
            },
            {
                path: 'search',
                redirectTo: 'home',
                pathMatch: 'full'
            },
            {
                path: 'upload-music',
                loadChildren: '../../core/components/upload-music/upload-music.module#UploadMusicModule'
            },
            {
                path: 'download-queue',
                loadChildren: './download-queue/download-queue.module#DownloadQueueModule',
                pathMatch: 'full'
            },
            {
                path: 'no-internet',
                component: _login_components_no_internet_no_internet_component__WEBPACK_IMPORTED_MODULE_5__["NoInternetComponent"]
            },
            {
                path: 'likes',
                loadChildren: './view/view.module#ViewModule',
                canActivate: [_core_guards_auth_guard_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
            {
                path: 'downloads',
                loadChildren: './view/view.module#ViewModule',
                canActivate: [_core_guards_auth_guard_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
            {
                path: 'desktop-downloads',
                loadChildren: './view/view.module#ViewModule',
            },
            {
                matcher: matcherFunction,
                loadChildren: './view/view.module#ViewModule',
                pathMatch: 'full',
                canActivate: [_core_guards_view_guard__WEBPACK_IMPORTED_MODULE_4__["ViewGuard"]]
            },
            {
                matcher: matcherFunctionMore,
                loadChildren: './view/view.module#ViewModule',
                pathMatch: 'full'
            }, {
                path: 'discover',
                loadChildren: './discover-page/discover-page.module#DiscoverPageModule',
                pathMatch: 'full',
                canActivate: [_core_guards_auth_guard_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            }, {
                path: 'friends',
                loadChildren: './discover-page/discover-page.module#DiscoverPageModule',
                pathMatch: 'full',
                canActivate: [_core_guards_auth_guard_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
        ]
    }
];
function matcherFunction(url) {
    // TODO: check how many params can be added
    if (url.length === 2) {
        if (url[0].path.match(/^song|album|podcaster|podcast|episode|playlist|tag|profile|tags|generic|artist|qarii|video|friends$/)) {
            let newUrl = url[0];
            if (url[0].path.match(/^podcast$/)) {
                newUrl = new _angular_router__WEBPACK_IMPORTED_MODULE_2__["UrlSegment"]('album', {});
            }
            else if (url[0].path.match(/^episode$/)) {
                newUrl = new _angular_router__WEBPACK_IMPORTED_MODULE_2__["UrlSegment"]('song', {});
            }
            else if (url[0].path.match(/^podcaster|qarii$/)) {
                newUrl = new _angular_router__WEBPACK_IMPORTED_MODULE_2__["UrlSegment"]('artist', {});
            }
            return {
                consumed: url,
                posParams: {
                    collectionId: url[1],
                    collectionType: newUrl
                }
            };
        }
        else {
            return null;
        }
    }
    else {
        return null;
    }
}
function matcherFunctionMore(url) {
    // TODO: check how many params can be added
    if (url.length === 3) {
        if (url[0].path.match(/^song|album|podcaster|podcast|episode|playlist|tag|profile|tags|generic|artist|video|friends$/)) {
            let urlType = url[0];
            if (url[0].path.match(/^podcast$/)) {
                urlType = new _angular_router__WEBPACK_IMPORTED_MODULE_2__["UrlSegment"]('album', {});
            }
            else if (url[0].path.match(/^episode$/)) {
                urlType = new _angular_router__WEBPACK_IMPORTED_MODULE_2__["UrlSegment"]('song', {});
            }
            else if (url[0].path.match(/^podcaster$/)) {
                urlType = new _angular_router__WEBPACK_IMPORTED_MODULE_2__["UrlSegment"]('artist', {});
            }
            return {
                consumed: url,
                posParams: {
                    collectionId: url[1],
                    collectionType: urlType,
                    sectionId: url[2]
                }
            };
        }
        else {
            return null;
        }
    }
    else {
        return null;
    }
}
let BaseRoutingModule = class BaseRoutingModule {
};
BaseRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        providers: [
            _core_guards_auth_guard_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"],
            _core_guards_view_guard__WEBPACK_IMPORTED_MODULE_4__["ViewGuard"],
        ]
    })
], BaseRoutingModule);



/***/ }),

/***/ "./src/app/modules/base/base.component.scss":
/*!**************************************************!*\
  !*** ./src/app/modules/base/base.component.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  padding: 3.5em 0 0 7em;\n  display: block;\n  height: 100vh;\n  min-width: 600px;\n}\n\n.base-wrapper.extrapadding {\n  padding-bottom: 8em;\n}\n\n.base-content {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n}\n\n.basecontent-main {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  overflow: hidden;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n\n::ng-deep .ang-view {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  overflow: hidden;\n  min-height: 100vh;\n}\n\n::ng-deep .ang-main {\n  padding: 1em 1.5em 7em 1.5em;\n  background: var(--main-background);\n  border-right: 1px solid var(--app-borders);\n  height: 100%;\n  width: 100%;\n  max-width: 1500px;\n  margin: auto;\n}\n\n.ang-side {\n  width: 330px;\n  padding: 0 0.5em;\n  box-sizing: border-box;\n  min-height: 100vh;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  background: var(--sidebar-background);\n}\n\nhtml[lang=ar] :host {\n  padding: 3.5em 7em 0 0;\n}\n\nhtml[lang=ar] ::ng-deep .ang-main {\n  border-right: none;\n  border-left: 1px solid var(--app-borders);\n}"

/***/ }),

/***/ "./src/app/modules/base/base.component.ts":
/*!************************************************!*\
  !*** ./src/app/modules/base/base.component.ts ***!
  \************************************************/
/*! exports provided: BaseComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseComponent", function() { return BaseComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _anghami_redux_actions_init_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/init.actions */ "./src/app/core/redux/actions/init.actions.ts");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/library.actions */ "./src/app/core/redux/actions/library.actions.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../app/core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../app/core/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _app_core_redux_selectors_layout_selector__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../app/core/redux/selectors/layout.selector */ "./src/app/core/redux/selectors/layout.selector.ts");
/* harmony import */ var _app_core_services_ads_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../app/core/services/ads.service */ "./src/app/core/services/ads.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_services_service_worker_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/services/service-worker.service */ "./src/app/core/services/service-worker.service.ts");
/* harmony import */ var _app_core_modules_player_player_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../app/core/modules/player/player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _anghami_services_gateway_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @anghami/services/gateway.service */ "./src/app/core/services/gateway.service.ts");



















let BaseComponent = class BaseComponent {
    constructor(store, platformId, renderer, adsService, router, elRef, document, serviceWorkerService, playerService, _gatewayService) {
        this.store = store;
        this.platformId = platformId;
        this.renderer = renderer;
        this.adsService = adsService;
        this.router = router;
        this.elRef = elRef;
        this.document = document;
        this.serviceWorkerService = serviceWorkerService;
        this.playerService = playerService;
        this._gatewayService = _gatewayService;
        this.navToggleState = false;
        this.imgAssetsEnv = `${_environments_environment__WEBPACK_IMPORTED_MODULE_15__["environment"].assetsCDN}img/`;
        this.bannerPage = true;
        this.elRef.nativeElement.ownerDocument.body.style.minWidth = '1000px';
        this.routeSub$ = this.router.events
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["filter"])(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_7__["NavigationEnd"]))
            .subscribe((event) => {
            if (event) {
                this.eventUrl = String(event.url);
                this.bannerPage = !(this.eventUrl.search('/search') >= 0 || this.eventUrl.search('/settings') >= 0);
            }
        });
    }
    ngOnDestroy() {
        if (this.darkModeSub$) {
            this.darkModeSub$.unsubscribe();
        }
        if (this.getLoggedInSub$) {
            this.getLoggedInSub$.unsubscribe();
        }
        if (this.getOnboardingValueSub$) {
            this.getOnboardingValueSub$.unsubscribe();
        }
        if (this.routeSub$) {
            this.routeSub$.unsubscribe();
        }
        this.elRef.nativeElement.ownerDocument.body.style.minWidth = null;
        this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_3__["UpdateIsInPlayer"](false));
    }
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_5__["isPlatformBrowser"])(this.platformId)) {
            this.isbrowser = true;
            this.isInternetExplorer =
                window.navigator.userAgent.toLowerCase().indexOf('msie') > -1 ||
                    window.navigator.userAgent.toLocaleLowerCase().indexOf('trident') > -1;
            this.initBaseModule();
            this.listenToThemeChange();
            this.getPlayerAdsSubs = this.adsService.PlayerleaderboardInitialized;
            this.store.dispatch(new _anghami_redux_actions_init_actions__WEBPACK_IMPORTED_MODULE_2__["InitKeyboardControls"]());
            this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_3__["UpdateIsInPlayer"](true));
            this.online$ = Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["merge"])(Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["of"])(navigator.onLine), Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["fromEvent"])(window, 'online').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["mapTo"])(true)), Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["fromEvent"])(window, 'offline').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["mapTo"])(false)));
            if (!!window['desktopClient']) {
                document
                    .getElementsByTagName('html')[0]
                    .setAttribute('data-client', 'desktop');
                const props = {
                    operatingSystem: window['desktopClient'].platform.name,
                    version: window['desktopClient'].appVersion,
                    platformVersion: window['desktopClient'].platform.osReleaseVersion
                };
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
                    name: _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].desktopAppOnload,
                    props: props
                }));
                setTimeout(() => {
                    this.serviceWorkerService.setConnectionListener();
                }, 2600);
            }
        }
    }
    listenToThemeChange() {
        this.darkModeSub$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_app_core_redux_selectors_layout_selector__WEBPACK_IMPORTED_MODULE_13__["getDarkmodeState"]))
            .subscribe(data => {
            const themeValue = data ? 'dark' : 'light';
            this.renderer.setAttribute(this.document.documentElement, 'data-theme', themeValue);
        });
    }
    initBaseModule() {
        this.getLoggedInSub$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_12__["getLoggedIn"]))
            .subscribe(data => {
            if (data) {
                //this.store.dispatch(new GetLikedSongsHashed());
                this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_4__["GetLikedAlbums"]());
                this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_4__["GetFollowedPlaylists"]());
                this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_4__["GetFollowedArtists"]());
                this.isLoggedIn = true;
            }
        });
        this.getOnboardingValueSub$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_12__["getOnboardingValue"]))
            .subscribe(data => {
            this.isOnboarding = data;
        });
    }
};
BaseComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
        selector: 'anghami-base',
        template: __webpack_require__(/*! raw-loader!./base.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/base.component.html"),
        styles: [__webpack_require__(/*! ./base.component.scss */ "./src/app/modules/base/base.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_6__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](6, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_5__["DOCUMENT"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["Store"],
        Object,
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["Renderer2"],
        _app_core_services_ads_service__WEBPACK_IMPORTED_MODULE_14__["AdsService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"],
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"], Object, _anghami_services_service_worker_service__WEBPACK_IMPORTED_MODULE_16__["ServiceWorkerService"],
        _app_core_modules_player_player_service__WEBPACK_IMPORTED_MODULE_17__["PlayerService"],
        _anghami_services_gateway_service__WEBPACK_IMPORTED_MODULE_18__["GatewayService"]])
], BaseComponent);



/***/ }),

/***/ "./src/app/modules/base/base.module.ts":
/*!*********************************************!*\
  !*** ./src/app/modules/base/base.module.ts ***!
  \*********************************************/
/*! exports provided: BaseModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseModule", function() { return BaseModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-progressbar/core */ "./node_modules/@ngx-progressbar/core/fesm2015/ngx-progressbar-core.js");
/* harmony import */ var _ngx_progressbar_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-progressbar/http */ "./node_modules/@ngx-progressbar/http/fesm2015/ngx-progressbar-http.js");
/* harmony import */ var _ngx_progressbar_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-progressbar/router */ "./node_modules/@ngx-progressbar/router/fesm2015/ngx-progressbar-router.js");
/* harmony import */ var _core_components_header_header_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../core/components/header/header.module */ "./src/app/core/components/header/header.module.ts");
/* harmony import */ var _core_components_navbar_navbar_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../core/components/navbar/navbar.module */ "./src/app/core/components/navbar/navbar.module.ts");
/* harmony import */ var _core_modules_player_player_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../core/modules/player/player.module */ "./src/app/core/modules/player/player.module.ts");
/* harmony import */ var _login_components_no_internet_no_internet_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../login/components/no-internet/no-internet.module */ "./src/app/modules/login/components/no-internet/no-internet.module.ts");
/* harmony import */ var _base_routing_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./base-routing.module */ "./src/app/modules/base/base-routing.module.ts");
/* harmony import */ var _base_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./base.component */ "./src/app/modules/base/base.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _core_components_search_input_search_input_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../core/components/search-input/search-input.module */ "./src/app/core/components/search-input/search-input.module.ts");
/* harmony import */ var _core_components_ang_aside_ang_aside_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../core/components/ang-aside/ang-aside.module */ "./src/app/core/components/ang-aside/ang-aside.module.ts");
/* harmony import */ var _core_components_download_app_download_app_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../core/components/download-app/download-app.module */ "./src/app/core/components/download-app/download-app.module.ts");
/* harmony import */ var ngx_sortablejs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ngx-sortablejs */ "./node_modules/ngx-sortablejs/fesm2015/ngx-sortablejs.js");
/* harmony import */ var _core_components_onboarding_onboarding_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../core/components/onboarding/onboarding.module */ "./src/app/core/components/onboarding/onboarding.module.ts");
/* harmony import */ var _core_directives_ad_block_detector_directive__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../core/directives/ad-block-detector.directive */ "./src/app/core/directives/ad-block-detector.directive.ts");
/* harmony import */ var _core_components_banner_button_banner_button_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../core/components/banner-button/banner-button.component */ "./src/app/core/components/banner-button/banner-button.component.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _anghami_redux_effects_collection_effects__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @anghami/redux/effects/collection.effects */ "./src/app/core/redux/effects/collection.effects.ts");
/* harmony import */ var _anghami_redux_effects_library_effects__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @anghami/redux/effects/library.effects */ "./src/app/core/redux/effects/library.effects.ts");
/* harmony import */ var _anghami_services_collection_helper_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @anghami/services/collection-helper.service */ "./src/app/core/services/collection-helper.service.ts");
/* harmony import */ var _anghami_services_collection_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @anghami/services/collection.service */ "./src/app/core/services/collection.service.ts");
/* harmony import */ var _anghami_services_library_service__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @anghami/services/library.service */ "./src/app/core/services/library.service.ts");
/* harmony import */ var _anghami_services_lyrics_service__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @anghami/services/lyrics.service */ "./src/app/core/services/lyrics.service.ts");
/* harmony import */ var _anghami_redux_effects_search_effects__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @anghami/redux/effects/search.effects */ "./src/app/core/redux/effects/search.effects.ts");
/* harmony import */ var _core_components_context_sheet_context_sheet_service__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../../core/components/context-sheet/context-sheet.service */ "./src/app/core/components/context-sheet/context-sheet.service.ts");
/* harmony import */ var _anghami_redux_effects_dialogs_effects__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @anghami/redux/effects/dialogs.effects */ "./src/app/core/redux/effects/dialogs.effects.ts");
/* harmony import */ var _anghami_redux_effects_dialogs_modals_effects__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @anghami/redux/effects/dialogs-modals.effects */ "./src/app/core/redux/effects/dialogs-modals.effects.ts");
/* harmony import */ var _core_components_ie_blocking_ie_blocking_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ../../core/components/ie-blocking/ie-blocking.component */ "./src/app/core/components/ie-blocking/ie-blocking.component.ts");
/* harmony import */ var _anghami_redux_effects_layout_effects__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @anghami/redux/effects/layout.effects */ "./src/app/core/redux/effects/layout.effects.ts");
/* harmony import */ var _anghami_services_layout_service__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @anghami/services/layout.service */ "./src/app/core/services/layout.service.ts");



































let BaseModule = class BaseModule {
};
BaseModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _base_routing_module__WEBPACK_IMPORTED_MODULE_10__["BaseRoutingModule"],
            _core_components_navbar_navbar_module__WEBPACK_IMPORTED_MODULE_7__["NavbarModule"],
            _core_modules_player_player_module__WEBPACK_IMPORTED_MODULE_8__["PlayerModule"],
            _core_components_header_header_module__WEBPACK_IMPORTED_MODULE_6__["HeaderModule"],
            _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_3__["NgProgressModule"],
            _ngx_progressbar_http__WEBPACK_IMPORTED_MODULE_4__["NgProgressHttpModule"],
            _ngx_progressbar_router__WEBPACK_IMPORTED_MODULE_5__["NgProgressRouterModule"],
            _login_components_no_internet_no_internet_module__WEBPACK_IMPORTED_MODULE_9__["NoInternetModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormsModule"],
            _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_13__["PipesModule"],
            _core_components_search_input_search_input_module__WEBPACK_IMPORTED_MODULE_14__["SearchInputModule"],
            _core_components_ang_aside_ang_aside_module__WEBPACK_IMPORTED_MODULE_15__["AngAsideModule"],
            _core_components_download_app_download_app_module__WEBPACK_IMPORTED_MODULE_16__["DownloadAppModule"],
            _core_components_onboarding_onboarding_module__WEBPACK_IMPORTED_MODULE_18__["OnBoardingModule"],
            ngx_sortablejs__WEBPACK_IMPORTED_MODULE_17__["SortablejsModule"].forRoot({ animation: 150 }),
            _ngrx_effects__WEBPACK_IMPORTED_MODULE_21__["EffectsModule"].forFeature([
                _anghami_redux_effects_library_effects__WEBPACK_IMPORTED_MODULE_23__["LibraryEffects"],
                _anghami_redux_effects_collection_effects__WEBPACK_IMPORTED_MODULE_22__["CollectionEffects"],
                _anghami_redux_effects_search_effects__WEBPACK_IMPORTED_MODULE_28__["SearchEffects"],
                _anghami_redux_effects_dialogs_effects__WEBPACK_IMPORTED_MODULE_30__["DialogsEffects"],
                _anghami_redux_effects_dialogs_modals_effects__WEBPACK_IMPORTED_MODULE_31__["DialogsModalsEffects"],
                _anghami_redux_effects_layout_effects__WEBPACK_IMPORTED_MODULE_33__["LayoutEffects"]
            ])
        ],
        declarations: [_base_component__WEBPACK_IMPORTED_MODULE_11__["BaseComponent"], _core_directives_ad_block_detector_directive__WEBPACK_IMPORTED_MODULE_19__["AdBlockDetectorDirective"], _core_components_banner_button_banner_button_component__WEBPACK_IMPORTED_MODULE_20__["BannerButtonComponent"], _core_components_ie_blocking_ie_blocking_component__WEBPACK_IMPORTED_MODULE_32__["IeBlockingComponent"]],
        exports: [],
        providers: [
            _anghami_services_library_service__WEBPACK_IMPORTED_MODULE_26__["LibraryService"],
            _anghami_services_collection_service__WEBPACK_IMPORTED_MODULE_25__["CollectionService"],
            _anghami_services_collection_helper_service__WEBPACK_IMPORTED_MODULE_24__["CollectionHelperService"],
            _anghami_services_lyrics_service__WEBPACK_IMPORTED_MODULE_27__["LyricsService"],
            _core_components_context_sheet_context_sheet_service__WEBPACK_IMPORTED_MODULE_29__["ContextSheetService"],
            _anghami_services_layout_service__WEBPACK_IMPORTED_MODULE_34__["LayoutService"]
        ]
    })
], BaseModule);



/***/ }),

/***/ "./src/app/modules/login/components/no-internet/no-internet.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/modules/login/components/no-internet/no-internet.component.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host anghami-empty-pages {\n  width: 100%;\n  height: 82%;\n}"

/***/ }),

/***/ "./src/app/modules/login/components/no-internet/no-internet.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/modules/login/components/no-internet/no-internet.component.ts ***!
  \*******************************************************************************/
/*! exports provided: NoInternetComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoInternetComponent", function() { return NoInternetComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let NoInternetComponent = class NoInternetComponent {
    constructor() {
        this.hostClass = 'ang-view';
    }
    ngOnInit() { }
    ngOnDestroy() { }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NoInternetComponent.prototype, "hostClass", void 0);
NoInternetComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-no-internet',
        template: __webpack_require__(/*! raw-loader!./no-internet.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/login/components/no-internet/no-internet.component.html"),
        styles: [__webpack_require__(/*! ./no-internet.component.scss */ "./src/app/modules/login/components/no-internet/no-internet.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], NoInternetComponent);



/***/ }),

/***/ "./src/app/modules/login/components/no-internet/no-internet.module.ts":
/*!****************************************************************************!*\
  !*** ./src/app/modules/login/components/no-internet/no-internet.module.ts ***!
  \****************************************************************************/
/*! exports provided: NoInternetModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoInternetModule", function() { return NoInternetModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _core_components_empty_pages_empty_pages_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/components/empty-pages/empty-pages.module */ "./src/app/core/components/empty-pages/empty-pages.module.ts");
/* harmony import */ var _no_internet_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./no-internet.component */ "./src/app/modules/login/components/no-internet/no-internet.component.ts");





let NoInternetModule = class NoInternetModule {
};
NoInternetModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _core_components_empty_pages_empty_pages_module__WEBPACK_IMPORTED_MODULE_3__["EmptyPagesModule"]],
        declarations: [_no_internet_component__WEBPACK_IMPORTED_MODULE_4__["NoInternetComponent"]],
        providers: [_no_internet_component__WEBPACK_IMPORTED_MODULE_4__["NoInternetComponent"]],
        exports: [_no_internet_component__WEBPACK_IMPORTED_MODULE_4__["NoInternetComponent"]]
    })
], NoInternetModule);



/***/ })

}]);