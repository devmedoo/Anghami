(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~library-library-module~view-view-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/ang-video/ang-video.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/ang-video/ang-video.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  class=\"video-wrapper\"\n  id=\"full_video_wrapper\"\n>\n  <div *ngIf=\"showCover\" class=\"cover\" (click)=\"playQueue()\" [ngStyle]=\"{\n      'background-image': 'url(' + poster + ')'\n    }\">\n    <anghami-icon\n      class=\"icon playicon\"\n      [data]=\"'play'\"\n    ></anghami-icon>\n  </div>\n\n</div>\n<div class=\"video-details\" *ngIf=\"collectionMeta\">\n  <div>\n    <h1 class=\"video-title\" dir=\"auto\">\n      {{ collectionMeta.title }}\n    </h1>\n    <div class=\"video-img-artist\">\n      <img\n        [src]=\"\n          collectionMeta.VideoArtistArt ||\n          collectionMeta.image ||\n          collectionMeta.ArtistArt\n        \"\n      />\n      <h3 class=\"video-artist\">\n        <ng-container i18n=\"@@by\">by</ng-container>\n        <a\n          [routerLink]=\"['/artist/' + collectionMeta?.artistID]\"\n          [class.disabled]=\"videoData?.artistID == '414'\"\n        >\n          {{ collectionMeta.artist || collectionMeta.title }}\n          <span>&#9002;</span>\n        </a>\n      </h3>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/collection-header-buttons/collection-header-buttons.component.html":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/collection-header-buttons/collection-header-buttons.component.html ***!
  \******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"d-flex align-items-center flex-wrap\">\n  <ng-container *ngFor=\"let button of (buttons | orderByMain: 'main' | slice: 0:2)\">\n    <ng-container [ngSwitch]=\"button.type\">\n      <ng-container *ngSwitchCase=\"\n          button.type === 'follow' || button.type === 'profilefollow'\n            ? button.type\n            : ''\n        \">\n        <ng-container *ngIf=\"collectionType === 'profile'\">\n          <ng-container>\n            <ng-container *ngIf=\"\n                  (collectionMeta.following === 1 ||\n                  collectionMeta.following === true ||\n                  collectionMeta.following === '1') &&\n                  collectionMeta.requeststatus === 'Accepted'\n                \">\n                <button (click)=\"fireCollectionAction(button.type)\" class=\"anghami-default-btn\" i18n=\"@@Following\">following</button>\n            </ng-container>\n            <ng-container *ngIf=\"\n                  (collectionMeta.following === 0 ||\n                    collectionMeta.following === false ||\n                    collectionMeta.following === '0') &&\n                  (collectionMeta.requeststatus === 'None' || collectionMeta.requeststatus === 'Cancelled') &&\n                  collectionMeta.ispublic === 1\n                \">\n                <button (click)=\"fireCollectionAction(button.type)\" class=\"anghami-primary-btn\" i18n=\"@@Follow\">follow</button>\n            </ng-container>\n            <ng-container *ngIf=\"\n                    (collectionMeta.following === 0 ||\n                      collectionMeta.following === false ||\n                      collectionMeta.following === '0') &&\n                    (collectionMeta.requeststatus === 'None' || collectionMeta.requeststatus === 'Cancelled') &&\n                    collectionMeta.ispublic === 0\n                  \">\n                  <button (click)=\"fireCollectionAction(button.type)\" class=\"anghami-primary-btn\" i18n=\"@@Follow\">follow</button>\n            </ng-container>\n            <ng-container *ngIf=\"collectionMeta.following === undefined && collectionMeta.requeststatus === undefined\"><button (click)=\"fireCollectionAction(button.type)\" class=\"anghami-primary-btn\" i18n=\"@@Follow\">follow</button></ng-container>\n            <ng-container *ngIf=\"\n                (collectionMeta.following === 0 ||\n                  collectionMeta.following === false ||\n                  collectionMeta.following === '0') &&\n                collectionMeta.requeststatus === 'Pending'\n              \">\n              <button (click)=\"fireCollectionAction(button.type)\" class=\"anghami-default-btn\" i18n=\"@@follow_requested\">Requested</button>\n            </ng-container>\n          </ng-container>\n        </ng-container>\n        <ng-container *ngIf=\"collectionType !== 'profile'\">\n          <button (click)=\"fireCollectionAction(button.type)\" class=\"anghami-default-btn\">\n            <ng-container *ngIf=\"\n                collectionMeta.followed === 1 ||\n                collectionMeta.followed === true ||\n                collectionMeta.followed === '1'\n              \" i18n=\"@@Following\">\n                following\n            </ng-container>\n            <ng-container *ngIf=\"\n                !(\n                  collectionMeta.followed === 1 ||\n                  collectionMeta.followed === true ||\n                  collectionMeta.followed === '1'\n                )\n              \">{{ button.text }}</ng-container>\n          </button>\n        </ng-container>\n      </ng-container>\n      <ng-container *ngSwitchCase=\"'like'\">\n        <button (click)=\"fireCollectionAction(button.type)\" [class.anghami-primary-btn]=\"\n            collectionMeta.liked === 1 || collectionMeta.liked === true\n          \" [class.anghami-default-btn]=\"\n            collectionMeta.liked === 0 ||\n            collectionMeta.liked === false ||\n            collectionMeta.liked === undefined\n          \">\n          <ng-container *ngIf=\"\n              collectionMeta?.liked === 1 || collectionMeta?.liked === true\n            \" i18n=\"@@Liked\">liked</ng-container>\n          <ng-container *ngIf=\"\n              !(collectionMeta?.liked === 1 || collectionMeta?.liked === true)\n            \">{{ button.text }}</ng-container>\n        </button>\n      </ng-container>\n      <ng-container *ngSwitchCase=\"'play'\">\n        <ng-container *ngIf=\"!(collectionMeta?.is_premium_content === true)\">\n          <button (click)=\"fireCollectionAction(button.type)\" [class.anghami-primary-btn]=\"true\">\n            {{ button.text }}\n          </button>\n        </ng-container>\n      </ng-container>\n      <ng-container *ngSwitchCase=\"'deeplink'\">\n        <button (click)=\"handleDeeplink(button.deeplink)\" [class.anghami-default-btn]=\"true\" [class.anghami-primary-btn]=\"button.main\">\n          {{ button.text }}\n        </button>\n      </ng-container>\n      <ng-container *ngSwitchDefault>\n        <button *ngSwitchDefault (click)=\"fireCollectionAction(button.type)\" [class.anghami-default-btn]=\"!button.main\" [class.anghami-primary-btn]=\"button.main\">\n          {{ button.text }}\n        </button>\n      </ng-container>\n    </ng-container>\n  </ng-container>\n\n  <div *ngIf=\"buttons?.length > 2\" class=\"anghami-default-btn\" [ngbPopover]=\"contextsheet\" [placement]=\"['bottom', 'auto']\"\n    (hidden)=\"popoverShown = false\" (shown)=\"popoverShown = true\">\n    <anghami-icon class=\"icon more\" [data]=\"'more'\"></anghami-icon>\n\n  </div>\n  <ng-template #contextsheet>\n    <ng-container *ngFor=\"let button of (buttons | slice: 2 : (buttons?.length || 2))\">\n      <div *ngIf=\"\n          button.type !== 'filter' &&\n          button.type !== 'deeplink' &&\n          button.type !== 'toggle' &&\n          button.type !== 'radio'\n        \" (click)=\"fireCollectionAction(button.type)\" class=\"flex flex-row item\">\n        <anghami-icon class=\"icon\" [data]=\"button.type\"></anghami-icon>\n        <span class=\"text\"> {{ button.text }}</span>\n      </div>\n      <div *ngIf=\"\n          button.type === 'radio' && collectionMeta.isPodcaster !== 1\n        \" (click)=\"fireCollectionAction(button.type)\" class=\"flex flex-row item\">\n        <anghami-icon class=\"icon\" [data]=\"button.type\"></anghami-icon>\n        <span class=\"text\" i18n=\"@@Play Radio\">Play Radio</span>\n      </div>\n      <div *ngIf=\"button.type === 'deeplink'\" (click)=\"handleDeeplink(button.deeplink)\" class=\"flex flex-row item\">\n        <anghami-icon class=\"icon\" [data]=\"button.icon\"></anghami-icon>\n        <span class=\"text\"> {{ button.text }}</span>\n      </div>\n      <div *ngIf=\"button.type === 'toggle'\" class=\"flex flex-row item\">\n        <anghami-icon class=\"icon\" [data]=\"button.icon\"></anghami-icon>\n        <span class=\"text\">\n          {{ button.value ? button.enabled_text : button.disabled_text }}</span>\n        <div class=\"login-gender-item\">\n          <label class=\"switch\" (click)=\"toggleSwitchValue(button)\">\n            <input type=\"checkbox\" [(ngModel)]=\"button.value\" disabled=\"{{ button.value }}\" />\n            <span class=\"slider round\"></span>\n          </label>\n        </div>\n      </div>\n    </ng-container>\n  </ng-template>\n\n\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/collection-header-side/collection-header-side.component.html":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/collection-header-side/collection-header-side.component.html ***!
  \************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"collection-header\" #asideWrapper>\n  <div class=\"collection-sticky\">\n    <ng-container *ngIf=\"collectionMeta; else loading\">\n      <ng-container *ngIf=\"collectionType\">\n        <ng-container *ngIf=\"collectionSections\">\n          <ng-container [ngSwitch]=\"collectionType\">\n            <ng-container *ngSwitchCase=\"'video'\">\n              <ng-container *ngTemplateOutlet=\"\n              videoTemplate;\n              context: { id: collectionMeta.id }\n            \"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"'artist'\">\n              <ng-container *ngTemplateOutlet=\"\n              artistHeader;\n              context: { $implicit: collectionMeta, type: collectionType }\n            \"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"'album'\">\n              <ng-container *ngTemplateOutlet=\"\n              albumHeader;\n              context: { $implicit: collectionMeta, type: collectionType }\n            \"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"'podcast'\">\n              <ng-container *ngTemplateOutlet=\"\n              albumHeader;\n              context: { $implicit: collectionMeta, type: collectionType }\n            \"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"'song'\">\n              <ng-container *ngTemplateOutlet=\"\n              songHeader;\n              context: { $implicit: collectionMeta, type: collectionType }\n            \"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"'generic'\">\n              <ng-container *ngTemplateOutlet=\"\n              genericHeader;\n              context: { $implicit: collectionMeta, type: collectionType }\n            \"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"'profile'\">\n              <ng-container *ngTemplateOutlet=\"\n              profileHeader;\n              context: { $implicit: collectionMeta, type: collectionType }\n            \"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"'hashtag'\">\n              <ng-container *ngTemplateOutlet=\"\n              hashTagHeader;\n              context: { $implicit: collectionMeta, type: collectionType }\n            \"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchDefault>\n              <ng-container *ngTemplateOutlet=\"\n              collectionTemplate;\n              context: { $implicit: collectionMeta, type: collectionType }\n            \"></ng-container>\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </ng-container>\n    </ng-container>\n  </div>\n</div>\n<!-- ========== TEMPLATES =============== -->\n<!-- ADD AS MANY TEMPLATES AS YOU NEED HERE -->\n<ng-template #loading> </ng-template>\n\n<ng-template let-id=\"id\" #videoTemplate>\n  <anghami-video [collectionMeta]=\"collectionMeta\" [collectionSections]=\"collectionSections\"></anghami-video>\n</ng-template>\n\n<ng-template let-collectionMeta let-collectionType=\"type\" #artistHeader>\n  <div class=\"header-img rounded-circle artist-img\">\n    <anghami-story-list-wrapper [placement]=\"'header'\" [userData]=\"collectionMeta\"></anghami-story-list-wrapper>\n  </div>\n\n\n  <ng-container *ngTemplateOutlet=\"\n            collectionMetaGeneral;\n            context: { $implicit: collectionMeta, type: collectionType }\n          \"></ng-container>\n  <anghami-collection-header-buttons (collectionHeaderAction)=\"dispatchHeaderAction($event)\"\n    [buttons]=\"collectionMeta.buttons\" [collectionType]=\"collectionType\" [collectionMeta]=\"collectionMeta\"\n    [collectionPlayableSection]=\"collectionPlayableSection\"></anghami-collection-header-buttons>\n\n</ng-template>\n\n<ng-template let-collectionMeta let-collectionType=\"type\" #collectionTemplate>\n  <div class=\"header-img\" *ngIf=\"collectionMeta.coverArtImage\">\n    <img [src]=\"collectionMeta.coverArtImage\" [alt]=\"collectionMeta.title\" class=\"img-fluid collection-cover-img\" />\n  </div>\n\n  <ng-container *ngTemplateOutlet=\"\n            collectionMetaGeneral;\n            context: { $implicit: collectionMeta, type: collectionType }\n          \"></ng-container>\n  <anghami-collection-header-buttons (collectionHeaderAction)=\"dispatchHeaderAction($event)\"\n    [buttons]=\"collectionMeta.buttons\" [collectionType]=\"collectionType\" [collectionMeta]=\"collectionMeta\"\n    [collectionPlayableSection]=\"collectionPlayableSection\"></anghami-collection-header-buttons>\n\n</ng-template>\n\n<ng-template let-collectionMeta let-collectionType=\"type\" #songHeader>\n\n\n  <div class=\"header-img\">\n    <a [routerLink]=\"['/video', collectionMeta?.id]\" *ngIf=\"collectionMeta.videoid\" class=\"video-icon-link\">\n      <anghami-icon class=\"icon\" [data]=\"'videoicon'\"></anghami-icon>\n    </a>\n    <img [src]=\"collectionMeta.coverArtImage\" [attr.alt]=\"collectionMeta.title\"\n      class=\"img-fluid collection-cover-img\" />\n    <span class=\"explicit cover-art-e\" [hidden]=\"collectionMeta?.explicit !== '1'\">e</span>\n    <span class=\"exclusive-badge\" [hidden]=\"collectionMeta?.exclusive !== '1'\" i18n=\"@@exclusive\">\n      Exclusive\n    </span>\n  </div>\n\n\n\n  <ng-container *ngTemplateOutlet=\"\n            collectionMetaGeneral;\n            context: { $implicit: collectionMeta, type: collectionType }\n          \"></ng-container>\n  <anghami-collection-header-buttons (collectionHeaderAction)=\"dispatchHeaderAction($event)\"\n    [buttons]=\"collectionMeta.buttons\" [collectionType]=\"collectionType\" [collectionMeta]=\"collectionMeta\"\n    [collectionPlayableSection]=\"collectionPlayableSection\"></anghami-collection-header-buttons>\n\n</ng-template>\n\n<ng-template let-collectionMeta let-collectionType=\"type\" #albumHeader>\n  <div class=\"header-img\">\n    <img [src]=\"collectionMeta.coverArtImage\" [attr.alt]=\"collectionMeta.title\"\n      class=\"img-fluid collection-cover-img\" />\n    <span class=\"exclusive-badge\" [hidden]=\"collectionMeta?.exclusive !== 1\" i18n=\"@@exclusive\">\n      Exclusive\n    </span>\n  </div>\n\n  <ng-container *ngTemplateOutlet=\"\n            collectionMetaGeneral;\n            context: { $implicit: collectionMeta, type: collectionType }\n          \"></ng-container>\n  <anghami-collection-header-buttons (collectionHeaderAction)=\"dispatchHeaderAction($event)\"\n    [buttons]=\"collectionMeta.buttons\" [collectionType]=\"collectionType\" [collectionMeta]=\"collectionMeta\"\n    [collectionPlayableSection]=\"collectionPlayableSection\"></anghami-collection-header-buttons>\n</ng-template>\n\n<ng-template let-collectionMeta let-collectionType=\"type\" #genericHeader>\n\n\n  <div class=\"header-img\">\n    <img [src]=\"collectionMeta.coverArtImage\" [attr.alt]=\"collectionMeta.title\"\n      class=\"img-fluid collection-cover-img\" />\n  </div>\n  <anghami-collection-header-buttons (collectionHeaderAction)=\"dispatchHeaderAction($event)\"\n    [buttons]=\"collectionMeta.buttons\" [collectionType]=\"collectionType\" [collectionMeta]=\"collectionMeta\"\n    [collectionPlayableSection]=\"collectionPlayableSection\"></anghami-collection-header-buttons>\n\n</ng-template>\n\n<ng-template let-collectionMeta let-collectionType=\"type\" #profileHeader>\n  <div class=\"header-img rounded-circle\">\n    <anghami-story-list-wrapper [placement]=\"'header'\" [userData]=\"collectionMeta\"></anghami-story-list-wrapper>\n    <div *ngIf=\"collectionMeta.isplus\" class=\"plus-badge\">Plus</div>\n  </div>\n\n  <ng-container *ngTemplateOutlet=\"\n            collectionMetaGeneral;\n            context: { $implicit: collectionMeta, type: collectionType }\n          \"></ng-container>\n  <anghami-collection-header-buttons (collectionHeaderAction)=\"dispatchHeaderAction($event)\"\n    [buttons]=\"collectionMeta.buttons\" [collectionType]=\"collectionType\" [collectionMeta]=\"collectionMeta\"\n    [collectionPlayableSection]=\"collectionPlayableSection\"></anghami-collection-header-buttons>\n\n\n</ng-template>\n\n<ng-template let-collectionMeta let-collectionType=\"type\" #hashTagHeader>\n  <p *ngIf=\"collectionMeta.description || collectionMeta.subtitle\">\n    {{ collectionMeta.description || collectionMeta.subtitle }}\n  </p>\n</ng-template>\n\n<ng-template let-collectionMeta let-collectionType=\"type\" #collectionMetaGeneral>\n  <ng-container [ngSwitch]=\"collectionType\">\n    <ng-container *ngSwitchCase=\"'artist'\">\n      <div class=\"section-details flex\">\n        <span class=\"vertical-line flex flwrs\" (click)=\"displayUsersModal('artist')\"\n          *ngIf=\"collectionMeta.numFollowers > 0\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.numFollowers | formatNumbers }}\n            </div>\n            {{ collectionMeta.numFollowers | i18nPlural: followerMapping }}\n          </div>\n        </span>\n\n        <span class=\"vertical-line flex \" *ngIf=\"collectionMeta.artistPlays && collectionMeta.artistPlays > 0\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.artistPlays | formatNumbers }}\n            </div>\n            {{ collectionMeta.artistPlays | i18nPlural: playsMapping }}\n          </div>\n        </span>\n\n      </div>\n    </ng-container>\n\n    <ng-container *ngSwitchCase=\"'playlist'\">\n      <div class=\"section-details flex\">\n        <span class=\"vertical-line flex\" *ngIf=\"collectionMeta.numsongs && collectionMeta.numsongs > 0\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.PlaylistCount | formatNumbers }}\n            </div>\n            {{ collectionMeta.PlaylistCount | i18nPlural: songMapping }}\n          </div>\n        </span>\n\n        <span class=\"vertical-line flex flwrs\" (click)=\"displayUsersModal('playlist')\"\n          *ngIf=\"collectionMeta.followers > 0\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.followers | formatNumbers }}\n            </div>\n            {{ collectionMeta.followers | i18nPlural: followerMapping }}\n          </div>\n        </span>\n      </div>\n    </ng-container>\n\n    <ng-container *ngSwitchCase=\"'desktop-downloads'\">\n      <div class=\"section-details flex\">\n        <span class=\"vertical-line flex\" *ngIf=\"collectionMeta.numsongs && collectionMeta.numsongs > 0\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.PlaylistCount | formatNumbers }}\n            </div>\n            {{ collectionMeta.PlaylistCount | i18nPlural: songMapping }}\n          </div>\n        </span>\n      </div>\n    </ng-container>\n\n    <ng-container *ngSwitchCase=\"'album'\">\n      <div class=\"section-details flex\">\n        <span class=\"vertical-line flex\" *ngIf=\"collectionMeta.nbrsongs && !collectionMeta.hide_info\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.nbrsongs | formatNumbers }}\n            </div>\n            {{ collectionMeta.nbrsongs | i18nPlural: songMapping }}\n          </div>\n        </span>\n\n        <!-- <span\n          class=\"vertical-line flex\"\n          *ngIf=\"\n            collectionMeta.duration &&\n            collectionMeta.duration > 0 &&\n            !collectionMeta.hide_info\n          \"\n        >\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.duration | convertDuration }}\n            </div>\n            <ng-container i18n=\"@@duration\">\n              Duration\n            </ng-container>\n          </div>\n        </span> -->\n\n        <span class=\"vertical-line flex date-format\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.releasedate | formatDate }}\n            </div>\n            <ng-container i18n=\"@@Release Date\">\n              Release Date\n            </ng-container>\n          </div>\n        </span>\n      </div>\n    </ng-container>\n    <ng-container *ngSwitchCase=\"'podcast'\">\n      <div class=\"by\">\n        <ng-container *ngIf=\"collectionMeta?.OwnerName && collectionMeta?.OwnerID != userData?.anid\">\n          <div class=\"mt-1 mb-1\">\n            <img *ngIf=\"collectionMeta.OwnerPicture !== undefined\" [src]=\"collectionMeta.OwnerPicture\"\n              [attr.alt]=\"collectionMeta.OwnerName\" />\n            <a [routerLink]=\"['/profile', collectionMeta.OwnerID]\">{{ collectionMeta.OwnerName }}\n            </a>\n          </div>\n        </ng-container>\n        <div class=\"mt-1 mb-1\">\n          <img *ngIf=\"collectionMeta.ArtistArt !== 'undefined' && collectionMeta?.artistID\" [src]=\"collectionMeta.ArtistArt\"\n            [attr.alt]=\"collectionMeta.artist\" />\n          <a *ngIf=\"collectionMeta?.artistID\" [routerLink]=\"['/podcaster', collectionMeta?.artistID]\"\n            [class.disabled]=\"collectionMeta?.artistID == '414'\">{{ collectionMeta.artist }}\n          </a>\n        </div>\n      </div>\n      <div class=\"section-details flex\">\n        <span class=\"vertical-line flex\" *ngIf=\"collectionMeta.nbrsongs\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.nbrsongs | formatNumbers }}\n            </div>\n            {{ collectionMeta.nbrsongs | i18nPlural: episodesMapping }}\n          </div>\n        </span>\n\n        <span class=\"vertical-line flex date-format\">\n          <div>\n            <div class=\"font-weight-bold value\" *ngIf=\"collectionMeta.plays\">\n              {{ collectionMeta.plays | formatNumbers }}\n            </div>\n            {{ collectionMeta.plays | i18nPlural: playsMapping }}\n          </div>\n        </span>\n      </div>\n    </ng-container>\n\n    <ng-container *ngSwitchCase=\"'song'\">\n      <div class=\"section-details flex\">\n        <span class=\"vertical-line flex\" *ngIf=\"collectionMeta.likes > 0 && collectionMeta.likes\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.likes | formatNumbers }}\n            </div>\n            {{ collectionMeta.likes | i18nPlural: likesMapping }}\n          </div>\n        </span>\n\n        <span class=\"vertical-line flex\" *ngIf=\"collectionMeta.plays && collectionMeta.plays > 0\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.plays | formatNumbers }}\n            </div>\n            {{ collectionMeta.plays | i18nPlural: playsMapping }}\n          </div>\n        </span>\n\n        <span class=\"vertical-line flex\">\n          <div>\n            <div class=\"font-weight-bold value date-format\">\n              {{ collectionMeta.releasedate | formatDate }}\n            </div>\n            <ng-container i18n=\"@@Release Date\">\n              Release Date\n            </ng-container>\n          </div>\n        </span>\n      </div>\n    </ng-container>\n\n    <ng-container *ngSwitchCase=\"'profile'\">\n      <div class=\"section-details flex\">\n        <span class=\"vertical-line flex flwrs\" (click)=\"displayUsersModal('Followers')\"\n          *ngIf=\"collectionMeta.numFollowers > 0 && collectionMeta.numFollowers\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.numFollowers | formatNumbers }}\n            </div>\n            {{ collectionMeta.numFollowers | i18nPlural: followerMapping }}\n          </div>\n        </span>\n\n        <span class=\"vertical-line flex flwrs\" (click)=\"displayUsersModal('following')\"\n          *ngIf=\"collectionMeta.numfollowing > 0 && collectionMeta.numfollowing\">\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ collectionMeta.numfollowing | formatNumbers }}\n            </div>\n            {{ collectionMeta.numfollowing | i18nPlural: followingMapping }}\n          </div>\n        </span>\n      </div>\n    </ng-container>\n  </ng-container>\n</ng-template>"

/***/ }),

/***/ "./src/app/core/components/ang-header-stories/ang-header-stories.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/core/components/ang-header-stories/ang-header-stories.component.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .story-wrapper {\n  pointer-events: none;\n  -webkit-transition: padding 200ms ease;\n  transition: padding 200ms ease;\n}\n:host .story-wrapper.hasstory {\n  cursor: pointer;\n  pointer-events: all;\n  background: #92278f;\n  background: -webkit-gradient(linear, left top, left bottom, from(#92278f), to(#a700ff));\n  background: linear-gradient(to bottom, #92278f 0%, #a700ff 100%);\n  padding: 4px;\n  display: block;\n  border-radius: 50%;\n}\n:host .story-wrapper.hasstory .collection-cover-img {\n  border: 4px solid var(--app-background);\n}\n:host .collection-cover-img {\n  border-radius: 0.3em;\n  box-shadow: var(--gray-shadow);\n  display: block;\n  margin: auto;\n  max-width: 100%;\n}"

/***/ }),

/***/ "./src/app/core/components/ang-header-stories/ang-header-stories.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/core/components/ang-header-stories/ang-header-stories.component.ts ***!
  \************************************************************************************/
/*! exports provided: AngHeaderStoriesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AngHeaderStoriesComponent", function() { return AngHeaderStoriesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _services_story_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/story.service */ "./src/app/core/services/story.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/core/services/utils.service.ts");





let AngHeaderStoriesComponent = class AngHeaderStoriesComponent {
    constructor(_storyService, _utils) {
        this._storyService = _storyService;
        this._utils = _utils;
    }
    ngOnChanges() {
        this.getStory(this.type, this.data.id);
    }
    getStory(type, id) {
        if (this._utils.isBrowser()) {
            this._storyService
                .getArtistStory(id)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["take"])(1))
                .subscribe(data => {
                if (data.data) {
                    if (data.data.deeplink) {
                        data.data.href = data.data.deeplink
                            .replace('anghami://', '/')
                            .replace('uservideo', 'story');
                    }
                    setTimeout(() => {
                        this.storydata = data.data;
                    }, 1000);
                }
                else {
                    this.storydata = undefined;
                }
            });
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('type'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AngHeaderStoriesComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('data'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AngHeaderStoriesComponent.prototype, "data", void 0);
AngHeaderStoriesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-header-stories',
        template: `
    <a
      class="story-wrapper"
      [ngClass]="{ hasstory: storydata?.href }"
      [routerLink]="storydata?.href"
    >
      <img
        [src]="data.ArtistArt"
        [attr.alt]="data.name"
        class="img-fluid rounded-circle collection-cover-img"
      />
    </a>
  `,
        styles: [__webpack_require__(/*! ./ang-header-stories.component.scss */ "./src/app/core/components/ang-header-stories/ang-header-stories.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_story_service__WEBPACK_IMPORTED_MODULE_3__["StoryService"],
        _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
], AngHeaderStoriesComponent);



/***/ }),

/***/ "./src/app/core/components/ang-header-stories/ang-header-stories.module.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/core/components/ang-header-stories/ang-header-stories.module.ts ***!
  \*********************************************************************************/
/*! exports provided: AngHeaderStoriesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AngHeaderStoriesModule", function() { return AngHeaderStoriesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ang_header_stories_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ang-header-stories.component */ "./src/app/core/components/ang-header-stories/ang-header-stories.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");





let AngHeaderStoriesModule = class AngHeaderStoriesModule {
};
AngHeaderStoriesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"]],
        declarations: [_ang_header_stories_component__WEBPACK_IMPORTED_MODULE_3__["AngHeaderStoriesComponent"]],
        exports: [_ang_header_stories_component__WEBPACK_IMPORTED_MODULE_3__["AngHeaderStoriesComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], AngHeaderStoriesModule);



/***/ }),

/***/ "./src/app/core/components/ang-video/ang-video.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/core/components/ang-video/ang-video.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".video-wrapper {\n  position: relative;\n  background: #000;\n  min-height: 28em;\n  background-repeat: no-repeat;\n  background-position: center center;\n  margin: 1em auto;\n  background-size: contain;\n  cursor: pointer;\n}\n.video-wrapper ::ng-deep .video-js {\n  position: static;\n  padding-top: 0;\n  height: 100%;\n}\n.video-wrapper ::ng-deep .video-js video {\n  border-radius: 0;\n  max-width: 100% !important;\n  height: 100% !important;\n  margin: auto;\n}\n.video-wrapper ::ng-deep .video-js .video-js .vjs-text-track-display > div > div > div {\n  font-size: 25px !important;\n  line-height: 33px !important;\n  padding: 5px !important;\n  background: transparent !important;\n  text-shadow: 1px 1px 2px #000000;\n  display: inline-block !important;\n}\n.video-wrapper ::ng-deep .video-js .vjs-picture-in-picture-control,\n.video-wrapper ::ng-deep .video-js .vjs-seek-to-live-control,\n.video-wrapper ::ng-deep .video-js .vjs-volume-panel {\n  display: none;\n}\n.video-wrapper ::ng-deep .video-js .vjs-http-source-selector .vjs-menu-button {\n  font-size: 1.8em;\n  margin: 0.3em;\n}\n.video-wrapper ::ng-deep .video-js .vjs-control-bar {\n  background: none;\n}\n.video-wrapper ::ng-deep .video-js .vjs-big-play-button {\n  top: 50%;\n  left: 50%;\n  margin-top: -35px;\n  margin-left: -60px;\n  border-radius: 50%;\n  line-height: 3em;\n  height: 3em;\n}\n.video-wrapper ::ng-deep .video-js .vjs-big-play-button:before {\n  font-size: 1.8em;\n}\n.video-wrapper .cover {\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center center;\n}\n.video-wrapper .playicon {\n  position: absolute;\n  font-size: 4em;\n  color: #FFF;\n  left: 50%;\n  top: 50%;\n  margin-top: -1em;\n  margin-left: -1em;\n  opacity: 0.8;\n  -webkit-transition: opacity 200ms ease;\n  transition: opacity 200ms ease;\n}\n.video-wrapper:hover .playicon {\n  opacity: 1;\n}\n.video-wrapper video {\n  width: 100%;\n}\n.video-details {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  padding: 1em 0;\n}\n.video-details .video-title {\n  font-size: 1.5em;\n  color: var(--text-color-light);\n}\n.video-details .video-info {\n  color: grey;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n}\n.video-details .video-info h4 {\n  font-size: 1em;\n  margin: 0 0.5em;\n}\n.video-details .video-img-artist img {\n  border-radius: 50%;\n  display: inline-block;\n  vertical-align: middle;\n  width: 3em;\n}\n.video-details .video-img-artist .video-artist {\n  color: grey;\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0 1em;\n  font-size: 1.2em;\n}\n.video-details .video-img-artist .video-artist a {\n  color: grey;\n}"

/***/ }),

/***/ "./src/app/core/components/ang-video/ang-video.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/core/components/ang-video/ang-video.component.ts ***!
  \******************************************************************/
/*! exports provided: AngVideoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AngVideoComponent", function() { return AngVideoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _modules_player_player_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../modules/player/player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../modules/player/actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");







let AngVideoComponent = class AngVideoComponent {
    constructor(_playerService, _coverartService, store, _router) {
        this._playerService = _playerService;
        this._coverartService = _coverartService;
        this.store = store;
        this._router = _router;
        this.showCover = true;
    }
    get player() {
        return this._playerService.angPlayer || null;
    }
    ngOnInit() {
    }
    ngOnChanges() {
        this.prepareQueue();
        this.poster = this._coverartService.getCoverArtImage(this.collectionMeta.thumbnailid, 640);
        if (this.player) {
            if (this.player.playing) {
                if (this.collectionMeta.id !== this._playerService.currentTrack.id) {
                    this.playQueue();
                }
            }
        }
    }
    // TODO Move this code ngDoCheck
    ngDoCheck() {
        if (this.player !== null) {
            this._playerService.NEWsetVideoPlayerVisiblity(this.player.videoOn);
            if (!this.currentItemSubscription) {
                this.currentItemSubscription = this.player.currentTrack$.subscribe(trackItem => {
                    if (this._playerService.miniVideoPlayer) {
                        return;
                    }
                    if (!trackItem || !Object.keys(trackItem).length) {
                        return;
                    }
                    if (!this.currentTrackItem) {
                        this.currentTrackItem = trackItem;
                        return;
                    }
                    if (this.currentTrackItem.id !== trackItem.id) {
                        this._router.navigate(['/video/', trackItem.id]);
                    }
                    this.currentTrackItem = trackItem;
                });
            }
            // Remove the poster when the video is playing
            const videoElement = document.querySelector('video-js');
            const fullPlayer = document.querySelector('#full_video_wrapper');
            if (this._playerService.angPlayer.videoOn && fullPlayer && fullPlayer.contains(videoElement)) {
                this.showCover = false;
            }
        }
    }
    ngOnDestroy() {
        if (this.initializationObservableSubscription) {
            this.initializationObservableSubscription.unsubscribe();
        }
        if (this.currentItemSubscription) {
            this.currentItemSubscription.unsubscribe();
        }
    }
    prepareQueue() {
        const newdata = [];
        this.collectionSections.forEach(element => {
            if (element.type === 'video' && element.data && !this.videosQueue) {
                this.videosQueue = element;
                newdata.push(this.collectionMeta);
                element.data.forEach(video => {
                    newdata.push(video);
                });
            }
        });
        this.videosQueue = Object.assign({}, this.videosQueue, { data: newdata });
    }
    playQueue() {
        this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_6__["PlayTrackEngine"]({
            queue: this.videosQueue,
            list: this.collectionMeta,
            index: 0,
            isVideo: true,
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('videoPlayerContainer', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AngVideoComponent.prototype, "videoPlayerContainer", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('collectionMeta'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AngVideoComponent.prototype, "collectionMeta", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('collectionSections'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AngVideoComponent.prototype, "collectionSections", void 0);
AngVideoComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-video',
        template: __webpack_require__(/*! raw-loader!./ang-video.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/ang-video/ang-video.component.html"),
        styles: [__webpack_require__(/*! ./ang-video.component.scss */ "./src/app/core/components/ang-video/ang-video.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_modules_player_player_service__WEBPACK_IMPORTED_MODULE_2__["PlayerService"],
        _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_3__["CoverArtService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
], AngVideoComponent);



/***/ }),

/***/ "./src/app/core/components/ang-video/ang-video.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/components/ang-video/ang-video.module.ts ***!
  \***************************************************************/
/*! exports provided: AngVideoModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AngVideoModule", function() { return AngVideoModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_ang_video_ang_video_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/components/ang-video/ang-video.component */ "./src/app/core/components/ang-video/ang-video.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _icon_icon_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");







let AngVideoModule = class AngVideoModule {
};
AngVideoModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_5__["PipesModule"], _icon_icon_module__WEBPACK_IMPORTED_MODULE_6__["IconModule"]],
        declarations: [_core_components_ang_video_ang_video_component__WEBPACK_IMPORTED_MODULE_4__["AngVideoComponent"],],
        exports: [_core_components_ang_video_ang_video_component__WEBPACK_IMPORTED_MODULE_4__["AngVideoComponent"],],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], AngVideoModule);



/***/ }),

/***/ "./src/app/core/components/collection-header-buttons/collection-header-buttons.component.scss":
/*!****************************************************************************************************!*\
  !*** ./src/app/core/components/collection-header-buttons/collection-header-buttons.component.scss ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* The switch - the box around the slider */\n.switch {\n  position: relative;\n  display: inline-block;\n  width: 35px;\n  height: 16px;\n  /* Hide default HTML checkbox */\n  /* The slider */\n}\n.switch input {\n  opacity: 0;\n  width: 0;\n  height: 0;\n  background: var(--light-background);\n  color: var(--text-color);\n}\n.switch input:checked + .slider {\n  background: var(--checkbox-checked-background);\n}\n.switch input:checked + .slider:before {\n  -webkit-transform: translateX(17px);\n  -ms-transform: translateX(17px);\n  transform: translateX(17px);\n  left: 2.5px;\n}\n.switch .slider {\n  position: absolute;\n  cursor: pointer;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  margin: auto !important;\n  border: var(--checkbox-border);\n  background-color: var(--checkbox-unchecked-background);\n  /* Rounded sliders */\n}\n.switch .slider.round {\n  border-radius: 20px;\n}\n.switch .slider.round:before {\n  border-radius: 50%;\n}\n.switch .slider:before {\n  position: absolute;\n  content: \"\";\n  height: 14px;\n  width: 14px;\n  left: 0;\n  bottom: 0;\n  top: 0;\n  margin: auto;\n  background-color: var(--checkbox-circle-background);\n  -webkit-transition: 0.4s;\n  transition: 0.4s;\n}\n.anghami-primary-btn,\n.anghami-default-btn {\n  margin-right: 0.5em;\n  margin-top: 0.5rem;\n  -webkit-box-flex: 1;\n      -ms-flex-positive: 1;\n          flex-grow: 1;\n}\n.anghami-default-btn {\n  border: none;\n  background: var(--app-borders);\n}\n.more {\n  cursor: pointer;\n  padding: 0;\n  font-size: 0.9em;\n  fill: var(--text-color-light);\n  color: var(--text-color-light);\n}\n.item {\n  padding: 0 0.5em;\n  cursor: pointer;\n  -webkit-transition: all 200ms linear;\n  transition: all 200ms linear;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: start;\n}\n.item:hover {\n  background-color: var(--light-gray);\n  border-radius: 0.3em;\n}\n.item .text {\n  text-transform: capitalize;\n}\n.item .icon {\n  cursor: pointer;\n}\n.item .icon ::ng-deep svg {\n  width: 1em !important;\n  height: 1em !important;\n  font-size: 0.9em !important;\n}\n.icon.arrow-down ::ng-deep svg {\n  width: 0.8em !important;\n  height: 0.8em !important;\n}\n::ng-deep .popover-body {\n  padding: 0.5em;\n}\n::ng-deep .popover.bs-popover-bottom,\n::ng-deep .popover .bs-popover-auto {\n  margin-top: 0.3rem !important;\n}\n::ng-deep .popover .arrow {\n  display: none;\n}\n.text {\n  padding: 0.5em 1em;\n  font-size: 0.9em;\n}"

/***/ }),

/***/ "./src/app/core/components/collection-header-buttons/collection-header-buttons.component.ts":
/*!**************************************************************************************************!*\
  !*** ./src/app/core/components/collection-header-buttons/collection-header-buttons.component.ts ***!
  \**************************************************************************************************/
/*! exports provided: CollectionHeaderButtonsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CollectionHeaderButtonsComponent", function() { return CollectionHeaderButtonsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/services/desktop-download.service */ "./src/app/core/services/desktop-download.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _services_deeplinks_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/deeplinks.service */ "./src/app/core/services/deeplinks.service.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _anghami_redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/actions/user.actions */ "./src/app/core/redux/actions/user.actions.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");














let CollectionHeaderButtonsComponent = class CollectionHeaderButtonsComponent {
    constructor(deeplinkService, desktopDownloadsService, _actionsSubject, store, _router, locale) {
        this.deeplinkService = deeplinkService;
        this.desktopDownloadsService = desktopDownloadsService;
        this._actionsSubject = _actionsSubject;
        this.store = store;
        this._router = _router;
        this.locale = locale;
        this.collectionHeaderAction = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.isDesktpClient = !!window['desktopClient'];
        this.toggleState = {};
    }
    ngOnInit() {
        if (this.isDesktpClient) {
            this.downloadsListSubscription = this.desktopDownloadsService.desktopDownloads$.subscribe(response => {
                this.handleDownloadChanges();
            });
            this.downloadQueueSubscription = this.desktopDownloadsService.downloadQueue$.subscribe(response => {
                this.handleDownloadChanges();
            });
        }
        this.actionsSubjectSubscription = this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_7__["ofType"])(_anghami_redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_8__["UserActionTypes"].FollowProfileSuccess))
            .subscribe(res => {
            const userID = res.payload.profileId;
            this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_10__["GetCollectionDataNew"]({ collectionType: 'profile', collectionId: userID, librarySection: null }));
        });
        this.getUserSub = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_11__["getUser"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe(data => {
            if (data && data.anid) {
                this.userId = data.anid;
            }
        });
    }
    // TODO: needs to be updated to match all views
    // TODO: if more then 3 buttons show drop down
    ngOnChanges(changes) {
        if (changes.buttons) {
            if (changes.buttons.currentValue === undefined ||
                changes.buttons.currentValue.length === 0) {
                this.initDefaultButtons();
                if (this.isDesktpClient) {
                    this.handleDownloadChanges();
                }
            }
        }
    }
    fireCollectionAction(type) {
        const songid = this._router.snapshot.queryParams.songid;
        let songIndexInAlbum;
        if (songid && location.href.indexOf('album') >= 0) {
            songIndexInAlbum = this.collectionPlayableSection.data.map(obj => obj.id).indexOf(songid);
        }
        this.collectionHeaderAction.emit({
            actionType: type,
            collectionType: this.collectionType,
            index: songIndexInAlbum
        });
    }
    toggleSwitchValue(button) {
        button.value = !button.value;
        this.collectionHeaderAction.emit({
            actionType: button.type,
            toggleType: button.toggleType,
            toggleValue: button.value
        });
    }
    initDefaultButtons() {
        let playText = 'Play';
        let downloadText = 'Download';
        let shuffleText = 'Shuffle';
        let saveText = 'Save';
        let followText = 'Follow';
        let likeText = 'Like';
        let shareText = 'Share';
        if (this.locale === 'ar') {
            playText = _enums_enums__WEBPACK_IMPORTED_MODULE_4__["HeaderDefaultButtonsAr"].PLAY;
            downloadText = _enums_enums__WEBPACK_IMPORTED_MODULE_4__["HeaderDefaultButtonsAr"].DOWNLOAD;
            shuffleText = _enums_enums__WEBPACK_IMPORTED_MODULE_4__["HeaderDefaultButtonsAr"].SHUFFLE;
            saveText = _enums_enums__WEBPACK_IMPORTED_MODULE_4__["HeaderDefaultButtonsAr"].SAVE;
            followText = _enums_enums__WEBPACK_IMPORTED_MODULE_4__["HeaderDefaultButtonsAr"].FOLLOW;
            likeText = _enums_enums__WEBPACK_IMPORTED_MODULE_4__["HeaderDefaultButtonsAr"].LIKE;
            shareText = _enums_enums__WEBPACK_IMPORTED_MODULE_4__["HeaderDefaultButtonsAr"].SHARE;
        }
        switch (this.collectionType) {
            case 'artist': {
                this.buttons = [
                    {
                        deeplink: '',
                        text: playText,
                        type: 'play',
                        main: true
                    },
                    {
                        deeplink: '',
                        text: followText,
                        type: 'follow'
                    }
                ];
                break;
            }
            case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_3__["CollectionTypes"].ALBUM: {
                this.buttons = [
                    {
                        deeplink: '',
                        text: playText,
                        type: 'play',
                        main: true
                    },
                    {
                        deeplink: '',
                        text: likeText,
                        type: 'like'
                    },
                    {
                        deeplink: '',
                        text: shuffleText,
                        type: 'shuffle'
                    },
                    {
                        deeplink: '',
                        text: shareText,
                        type: 'share'
                    },
                    {
                        deeplink: '',
                        text: downloadText,
                        type: 'download'
                    }
                ];
                break;
            }
            case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_3__["CollectionTypes"].SONG: {
                this.buttons = [
                    {
                        deeplink: '',
                        text: playText,
                        type: 'play',
                        main: true
                    },
                    {
                        deeplink: '',
                        text: likeText,
                        type: 'like'
                    },
                    {
                        deeplink: '',
                        text: downloadText,
                        type: 'download'
                    }
                ];
                break;
            }
            case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_3__["CollectionTypes"].PLAYLIST: {
                if (this.collectionMeta['nofollow'] === '1' ||
                    this.collectionMeta['nofollow'] === true) {
                    this.buttons = [
                        {
                            deeplink: '',
                            text: playText,
                            type: 'play',
                            main: true
                        },
                        {
                            deeplink: '',
                            text: shuffleText,
                            type: 'shuffle'
                        },
                        {
                            deeplink: '',
                            text: downloadText,
                            type: 'download'
                        },
                        {
                            deeplink: '',
                            text: shareText,
                            type: 'share'
                        }
                    ];
                }
                else {
                    this.buttons = [
                        {
                            deeplink: '',
                            text: playText,
                            type: 'play',
                            main: true
                        },
                        {
                            deeplink: '',
                            text: shuffleText,
                            type: 'shuffle'
                        },
                        {
                            deeplink: '',
                            text: followText,
                            type: 'follow'
                        },
                        {
                            deeplink: '',
                            text: downloadText,
                            type: 'download'
                        },
                        {
                            deeplink: '',
                            text: shareText,
                            type: 'share'
                        }
                    ];
                }
                break;
            }
            case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_3__["CollectionTypes"].GENERIC: {
                this.buttons = [
                    {
                        deeplink: '',
                        text: playText,
                        type: 'play',
                        main: true
                    },
                    {
                        deeplink: '',
                        text: downloadText,
                        type: 'download'
                    },
                    {
                        deeplink: '',
                        text: shuffleText,
                        type: 'shuffle'
                    },
                    {
                        deeplink: '',
                        text: saveText,
                        type: 'save'
                    },
                    {
                        deeplink: '',
                        text: shareText,
                        type: 'share'
                    }
                ];
                break;
            }
            default: {
                break;
            }
        }
    }
    handleDownloadChanges() {
        let downloadedSongs = 0;
        let downloadingSongs = 0;
        let pristineSongs = 0;
        const playlistIsStillLoading = this.collectionMeta.list_type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_3__["CollectionTypes"].PLAYLIST &&
            this.collectionMeta.PlaylistCount > this.collectionPlayableSection.data.length;
        if (this.collectionPlayableSection && !playlistIsStillLoading) {
            const section = this.collectionPlayableSection;
            section.data.forEach(element => {
                if (this.desktopDownloadsService.isSongDownloaded(element)) {
                    downloadedSongs++;
                }
                else if (this.desktopDownloadsService.isSongInDownloadQueue(element)) {
                    downloadingSongs++;
                }
                else {
                    pristineSongs++;
                    return;
                }
            });
            this.buttons = this.buttons.map(button => {
                let newButton = button;
                if (button.type === 'download') {
                    if (pristineSongs > 0) {
                        newButton = Object.assign({}, button, { text: 'Download' });
                    }
                    else if (downloadingSongs > 0) {
                        newButton = Object.assign({}, button, { text: 'Downloading' });
                    }
                    else if (downloadedSongs > 0) {
                        newButton = Object.assign({}, button, { text: 'Downloaded' });
                    }
                }
                return newButton;
            });
        }
    }
    /**
     *
     * @param deeplink
     * @description Helper function that sets extra missing params to be sent through the deeplink
     */
    setDeeplinkExtras(deeplink) {
        let url = atob(deeplink);
        const parsedUrl = this.deeplinkService.getParsedDeeplinkObject(url);
        const params = parsedUrl.queryStrings && parsedUrl.queryStrings.individualStrings
            ? parsedUrl.queryStrings.individualStrings
            : undefined;
        if (this.collectionMeta && this.collectionMeta.list_type === 'generic') {
            url += `&generic=true`;
        }
        if (params && !params['image']) {
            url += `&image=${this.collectionMeta.coverArtImage}`;
        }
        return btoa(url);
    }
    handleDeeplink(deeplink) {
        const newdeeplink = this.setDeeplinkExtras(deeplink);
        try {
            this.deeplinkService.handleDeeplink(atob(newdeeplink));
        }
        catch (exception) {
            this.deeplinkService.handleDeeplink(newdeeplink);
        }
    }
    ngOnDestroy() {
        if (this.downloadsListSubscription) {
            this.downloadsListSubscription.unsubscribe();
        }
        if (this.downloadQueueSubscription) {
            this.downloadQueueSubscription.unsubscribe();
        }
        if (this.actionsSubjectSubscription) {
            this.actionsSubjectSubscription.unsubscribe();
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionHeaderButtonsComponent.prototype, "buttons", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionHeaderButtonsComponent.prototype, "collectionType", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionHeaderButtonsComponent.prototype, "collectionMeta", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionHeaderButtonsComponent.prototype, "collectionPlayableSection", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"])
], CollectionHeaderButtonsComponent.prototype, "collectionHeaderAction", void 0);
CollectionHeaderButtonsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'anghami-collection-header-buttons',
        template: __webpack_require__(/*! raw-loader!./collection-header-buttons.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/collection-header-buttons/collection-header-buttons.component.html"),
        styles: [__webpack_require__(/*! ./collection-header-buttons.component.scss */ "./src/app/core/components/collection-header-buttons/collection-header-buttons.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](5, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_5__["DeeplinksService"],
        _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_1__["DesktopDownloadService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_6__["ActionsSubject"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"],
        _angular_router__WEBPACK_IMPORTED_MODULE_12__["ActivatedRoute"], String])
], CollectionHeaderButtonsComponent);



/***/ }),

/***/ "./src/app/core/components/collection-header-side/collection-header-side.component.scss":
/*!**********************************************************************************************!*\
  !*** ./src/app/core/components/collection-header-side/collection-header-side.component.scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n:host {\n  display: block;\n}\n:host .collection-sticky {\n  width: 17em;\n}\n:host .collection-sticky.sticky {\n  top: 4em !important;\n}\n:host .header-img {\n  position: relative;\n  margin: 1em 0 0.5em 0;\n  border-radius: 0.8em;\n  width: 17em;\n}\n:host .header-img .collection-cover-img {\n  border-radius: 0.8em;\n  box-shadow: var(--gray-shadow);\n  display: block;\n  width: 17em;\n  height: 17em;\n}\n:host .collection-subtitle {\n  margin-top: 0.5em;\n}\n:host .collection-subtitle:hover {\n  text-decoration: underline;\n}\n:host .artist-img {\n  background: none !important;\n  padding-bottom: 0 !important;\n}\n:host .by {\n  margin-top: 0.8em;\n}\n:host .by img {\n  width: 1.5em;\n  border-radius: 50%;\n}\n:host .by a {\n  color: var(--text-color);\n  margin: 0 0.5em;\n  position: relative;\n  font-weight: 500;\n}\n:host .by a:after {\n  content: \"〉\";\n  font-weight: bolder;\n  margin: 0.1em 0.2em;\n  font-size: 0.7em;\n}\n:host .by:lang(ar) {\n  text-align: right;\n}\n:host .section-details {\n  color: var(--grey-text-color);\n  padding: 0.5em;\n}\n:host h2.artist {\n  margin: 0 !important;\n}\n:host .flwrs {\n  cursor: pointer;\n}\n:host .margin0 {\n  margin: 0 !important;\n}\n:host .private-padding {\n  padding: 0 0.5em;\n  font-size: 1em;\n}\n:host .badge {\n  position: absolute;\n}\n:host .plus-badge {\n  background: -webkit-gradient(linear, left top, right top, from(#e13f8c), color-stop(46%, #9d2ad5), to(#517bdd));\n  background: linear-gradient(to right, #e13f8c 0%, #9d2ad5 46%, #517bdd 100%);\n  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=\"#e13f8c\", endColorstr=\"#27aae1\", GradientType=1);\n  width: 50%;\n  position: absolute;\n  bottom: -0.4em;\n  color: #fff;\n  text-align: center;\n  border-radius: 3em;\n  text-transform: uppercase;\n  font-size: 1.5em;\n  left: 0;\n  right: 0;\n  margin: auto;\n  line-height: 1.4em;\n  z-index: 1;\n  margin-left: 2.2em;\n}\n:host .vertical-line::before {\n  content: \"\";\n  width: 1px;\n  height: 2em;\n  margin: 1em;\n  background: var(--grey-text-color);\n  opacity: 0.25;\n}\n:host .vertical-line:first-child:before {\n  content: \"\";\n  width: 0;\n  height: 0;\n  margin: 0;\n}\n:host .value {\n  font-size: 1.07em;\n  line-height: 1em;\n  color: var(--text-color);\n}\n:host .date-format {\n  text-transform: capitalize;\n}\n:host .video-icon-link {\n  position: absolute;\n  right: -1em;\n  top: 1em;\n  padding: 0.5em;\n  border-radius: 50%;\n  background: #fff;\n  border: 1px solid lightgray;\n  z-index: 1;\n}\n:host .video-icon-link .icon {\n  color: #000;\n}\n:host ::ng-deep .stories {\n  width: 16em;\n  height: 16em;\n  overflow: hidden !important;\n  margin: auto;\n}\n:host ::ng-deep .stories .story {\n  width: 100% !important;\n  height: 100%;\n  margin: 0 !important;\n  padding: 0 !important;\n}\n:host ::ng-deep .stories .story a {\n  height: 100%;\n  width: 100%;\n}\n:host ::ng-deep .stories .story a .img {\n  width: 16em !important;\n  height: 16em !important;\n  max-width: 16em !important;\n  margin: 0 !important;\n  padding: 0 !important;\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n  font-size: unset !important;\n}\n:host ::ng-deep .stories .story a .img u {\n  width: 15.5em;\n  height: 15.5em;\n  background-size: cover;\n  margin: auto;\n  padding: 0;\n  background-position: center center;\n}"

/***/ }),

/***/ "./src/app/core/components/collection-header-side/collection-header-side.component.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/core/components/collection-header-side/collection-header-side.component.ts ***!
  \********************************************************************************************/
/*! exports provided: CollectionHeaderSideComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CollectionHeaderSideComponent", function() { return CollectionHeaderSideComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_redux_actions_playlist_manager_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/playlist-manager.actions */ "./src/app/core/redux/actions/playlist-manager.actions.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../modules/player/actions/player.actions */ "./src/app/core/modules/player/actions/player.actions.ts");
/* harmony import */ var _redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../redux/actions/user.actions */ "./src/app/core/redux/actions/user.actions.ts");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @anghami/redux/actions/library.actions */ "./src/app/core/redux/actions/library.actions.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var hc_sticky__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! hc-sticky */ "./node_modules/hc-sticky/dist/hc-sticky.js");
/* harmony import */ var hc_sticky__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(hc_sticky__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../modules/player/actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");






















let CollectionHeaderSideComponent = class CollectionHeaderSideComponent {
    constructor(locale, store, _actionsSubject, _router, changeDetector, authService, platformId) {
        this.locale = locale;
        this.store = store;
        this._actionsSubject = _actionsSubject;
        this._router = _router;
        this.changeDetector = changeDetector;
        this.authService = authService;
        this.platformId = platformId;
        this.userData = null;
        this.sectionTrackLst = [];
        this.isDesktopClient = !!window['desktopClient'];
        this.songMapping = {
            '=0': 'No Songs',
            '=1': 'Song',
            other: 'Songs'
        };
        this.episodesMapping = {
            '=0': 'No Episodes',
            '=1': 'Episode',
            other: 'Episodes'
        };
        this.followerMapping = {
            '=0': 'No followers',
            '=1': 'Follower',
            other: 'Followers'
        };
        this.followingMapping = {
            '=0': 'No following',
            '=1': 'Following',
            other: 'Following'
        };
        this.playsMapping = {
            '=0': 'No Plays',
            '=1': 'Play',
            other: 'Plays'
        };
        this.likesMapping = {
            '=0': 'No Likes',
            '=1': 'Like',
            other: 'Likes'
        };
    }
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_20__["isPlatformBrowser"])(this.platformId)) {
            this.initSticky();
            this.initMappingLocale();
            this.setFollowersList();
            this.setCollectionPlayableSection();
            this.initializeLikesListeners();
            if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].ARTIST) {
                this.collectionMeta.buttons = [
                    ...this.collectionMeta.buttons,
                    {
                        deeplink: null,
                        text: "Play artist radio",
                        type: "radio",
                    }
                ];
            }
            if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].ALBUM && this.collectionMeta.isPodcast === 1) {
                this.collectionType = _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].PODCAST;
            }
        }
    }
    ngAfterViewInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_20__["isPlatformBrowser"])(this.platformId)) {
            this.refreshSticky();
        }
    }
    refreshSticky() {
        this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_3__["getUser"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1))
            .subscribe(data => {
            if (data) {
                setTimeout(() => {
                    this.initSticky();
                }, 1000);
            }
        });
    }
    initSticky() {
        if (this.sticky) {
            this.sticky.destroy();
        }
        const main = document.getElementById('.ang-main');
        const side = document.querySelector('.view-side');
        this.sticky = new hc_sticky__WEBPACK_IMPORTED_MODULE_19__(side, { top: 45, stickTo: main });
    }
    setFollowersList() {
        this.followersList$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_3__["getFollowers"]))
            .subscribe(data => {
            if (this.modalType &&
                typeof data !== 'undefined' &&
                data !== null &&
                Object.keys(data).length > 0) {
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenUsersModal"]({
                    type: this.modalType,
                    section: data
                }));
                this.modalType = null;
            }
        });
    }
    setCollectionPlayableSection() {
        this.collectionPlayableSection = undefined;
        this.collectionSections.forEach((element) => {
            if ((element.type === 'song' || element.type === 'video' || element.type === 'genericitem') &&
                (element.displaytype === 'list' || element.displaytype === 'progress_card') &&
                element.group !== 'latestsong' &&
                !this.collectionPlayableSection) {
                this.collectionPlayableSection = element;
            }
        });
        if (this.collectionSections && this.collectionSections.find(elt => elt.type === 'song')) {
            this.sectionTrackLst = this.collectionSections.find(elt => elt.type === 'song').data;
        }
    }
    displayUsersModal(type) {
        this.store.dispatch(new _redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_15__["GetFollowers"]({
            id: this.collectionMeta.id,
            followersType: this.handleRequestType(type),
            page: '0'
        }));
    }
    // Handles determining the corresponding api call parameter
    // since they use the same api call
    handleRequestType(type) {
        if (type == 'Followers') {
            this.modalType = 'followers';
            return 'profile';
        }
        else if (type == 'following') {
            this.modalType = 'Following';
            return 'friends';
        }
        else if (type == 'playlist') {
            this.modalType = 'Followers';
            return 'playlist';
        }
        else if (type == 'artist') {
            this.modalType = 'Followers';
            return 'artist';
        }
    }
    dispatchHeaderAction($event) {
        let eventName;
        let props;
        switch ($event.actionType) {
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].SHARE: {
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenShareModal"]({
                    type: $event.collectionType,
                    meta: this.collectionMeta
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].LIKE: {
                if (!this.authService.isUserLoggedIn()) {
                    this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenCustomDialog"]({
                        type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_10__["DIALOG_TYPES"].LOGIN
                    }));
                    break;
                }
                if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].ALBUM || this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].PODCAST) {
                    this.collectionMeta = Object.assign({}, this.collectionMeta, { liked: !this.collectionMeta.liked });
                    this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_17__["LikeAlbum"]({
                        item: this.collectionMeta
                    }));
                }
                else if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].SONG) {
                    this.collectionMeta = Object.assign({}, this.collectionMeta, { liked: !this.collectionMeta.liked });
                    this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_17__["LikeSong"]({
                        item: this.collectionMeta
                    }));
                }
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].FOLLOW: {
                if (!this.authService.isUserLoggedIn()) {
                    this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenCustomDialog"]({
                        type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_10__["DIALOG_TYPES"].LOGIN
                    }));
                    return;
                }
                if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].ARTIST) {
                    eventName = _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].followArtist;
                    props = {
                        id: this.collectionMeta.id
                    };
                    this.collectionMeta = Object.assign({}, this.collectionMeta, { followed: !this.collectionMeta.followed });
                    this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_17__["FollowArtist"]({
                        item: this.collectionMeta
                    }));
                }
                if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].PLAYLIST) {
                    props = {
                        id: this.collectionMeta.id
                    };
                    if (this.collectionMeta.following) {
                        eventName = _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].unfollowPlaylist;
                    }
                    else {
                        eventName = _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].followPlaylist;
                    }
                    this.collectionMeta = Object.assign({}, this.collectionMeta, { followed: !this.collectionMeta.followed });
                    this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_17__["FollowPlaylist"]({
                        item: this.collectionMeta
                    }));
                    this.changeDetector.detectChanges();
                }
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].UPLOAD_MY_MUSIC: {
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenUploadMyMusicModal"]({}));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].PLAY: {
                switch (this.collectionType) {
                    case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].PLAYLIST: {
                        this.playDefaultBehaviour();
                        break;
                    }
                    case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].SONG: {
                        this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_21__["PlaySongEngine"]({
                            id: this.collectionMeta.id
                        }));
                        break;
                    }
                    case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].GENERIC: {
                        this.store.dispatch(new _modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_12__["PlayGenericContent"]({
                            id: this.collectionMeta.id,
                            type: _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].GENERIC
                        }));
                        break;
                    }
                    case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].ALBUM: {
                        this.playDefaultBehaviour($event.index);
                        break;
                    }
                    default: {
                        this.playDefaultBehaviour();
                    }
                }
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].SHUFFLE: {
                const sectionToPlay = Object.assign({}, this.collectionPlayableSection, { data: this.collectionPlayableSection.type.indexOf('generic') === -1 ? this.collectionPlayableSection.data :
                        this.collectionPlayableSection.data.filter(item => item.generictype === 'song') });
                const randomIndexFromQueue = Math.floor((Math.random() * sectionToPlay.data.length));
                this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_21__["PlayTrackEngine"]({
                    queue: sectionToPlay,
                    list: this.collectionMeta,
                    index: randomIndexFromQueue,
                    click: true,
                    shuffle: true,
                    isVideo: this.collectionPlayableSection.type === 'video'
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].FOLLOWPROFILE: {
                this.store.dispatch(new _redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_15__["FollowProfile"]({
                    profileId: this.collectionMeta.id,
                    isPrivate: this.collectionMeta.ispublic === 0 ||
                        this.collectionMeta.ispublic === false
                        ? true
                        : false,
                    requestStatus: this.collectionMeta.requeststatus,
                    extras: this.collectionMeta.extras,
                    unfollow: this.collectionMeta.following === true ||
                        this.collectionMeta.following === 1
                        ? true
                        : false
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].EDITPLAYLIST: {
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenPlaylistManager"]({
                    type: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].EDITPLAYLIST,
                    section: this.collectionSections,
                    meta: this.collectionMeta
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].DOWNLOAD: {
                if (this.collectionType === 'album' ||
                    this.collectionType === 'playlist' ||
                    this.collectionType === 'generic') {
                    let sectionData = this.collectionPlayableSection.data;
                    if (this.collectionType === 'generic') {
                        sectionData = sectionData.filter(item => item.generictype === 'song');
                    }
                    if (this.collectionMeta.PlaylistCount && this.collectionMeta.PlaylistCount > this.collectionMeta.count) {
                        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__["DownloadListByID"]({
                            id: this.collectionMeta.id,
                            type: 'playlist'
                        }));
                    }
                    else {
                        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__["DownloadList"]({ songList: sectionData }));
                    }
                }
                else if (this.collectionType === 'song') {
                    this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__["DownloadSong"]({ song: this.collectionMeta }));
                }
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].MANAGEPLAYLIST: {
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenPlaylistManager"]({
                    type: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].MANAGEPLAYLIST
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].SAVE: {
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenPlaylistManager"]({
                    type: 'addtoplaylist',
                    tracks: this.sectionTrackLst,
                    savePlaylist: true
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].DELETE_PLAYLIST: {
                this.store.dispatch(new _redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].tapdeletePlaylist,
                    props: {
                        playlistid: this.collectionMeta.id
                    }
                }));
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenConfirmationModal"]({
                    type: 'confirm',
                    question: this.locale === 'ar'
                        ? 'هل أنت متأكد من أنك ترغب بحذف هذه القائمة الموسيقية؟'
                        : this.locale === 'fr'
                            ? 'Êtes-vous sûr de vouloir supprimer cette playlist?'
                            : 'Are you sure you want to delete this playlist?'
                }));
                if (this.confirmationModalSub$) {
                    this.confirmationModalSub$.unsubscribe();
                }
                this.confirmationModalSub$ = this._actionsSubject
                    .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["DialogsActionTypes"].ConfirmationModalAnswer), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1))
                    .subscribe(action => {
                    const response = action.payload;
                    if (response && response != null) {
                        if (response.type === 'confirm') {
                            let params = {
                                type: 'UPDATEplaylist',
                                playlistid: this.collectionMeta.id,
                                action: 'delete'
                            };
                            this.store.dispatch(new _anghami_redux_actions_playlist_manager_actions__WEBPACK_IMPORTED_MODULE_2__["DeletePlaylist"](params));
                            if (this.deletePlaylistSuccSub$) {
                                this.deletePlaylistSuccSub$.unsubscribe();
                            }
                            this.deletePlaylistSuccSub$ = this._actionsSubject
                                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_playlist_manager_actions__WEBPACK_IMPORTED_MODULE_2__["PlaylistManagerActionTypes"].DeletePlaylistSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["filter"])(action => action.payload.playlist === this.collectionMeta.id), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1))
                                .subscribe(action => {
                                const response = action.payload;
                                if (!response.responseData.error) {
                                    this.store.dispatch(new _redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                                        name: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].deletePlaylist,
                                        props: {
                                            playlistid: this.collectionMeta.id
                                        }
                                    }));
                                    this._router.navigate(['/mymusic/playlists']);
                                }
                                else {
                                    //TODO: handle error
                                }
                            });
                        }
                    }
                });
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].ADD_TO_PLAYLIST: {
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenPlaylistManager"]({
                    type: 'addtoplaylist',
                    tracks: [this.collectionMeta]
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].ADD_TO_QUEUE: {
                this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_21__["PlayNextEngine"]({
                    track: this.collectionMeta
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].PLAY_NEXT: {
                this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_21__["PlayNextEngine"]({
                    track: this.collectionMeta
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].GO_TO_ARTIST: {
                if (this.collectionMeta && this.collectionMeta != null) {
                    this._router.navigate(['/artist/' + this.collectionMeta.artistID]);
                }
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].GO_TO_ALBUM: {
                if (this.collectionMeta && this.collectionMeta != null) {
                    this._router.navigate(['/album/' + this.collectionMeta.albumID]);
                }
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].MUTE_ARTIST: {
                const hiddenArtist = this.collectionMeta.hidden && this.collectionMeta.hidden == true;
                this.store.dispatch(new _redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                    name: hiddenArtist
                        ? _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].unmuteartist
                        : _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].muteartist,
                    props: {
                        artistid: this.collectionMeta.id
                    }
                }));
                this.store.dispatch(new _redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_15__["MuteArtist"]({
                    type: 'followARTIST',
                    action: hiddenArtist ? 'unhide' : 'hide',
                    artistid: this.collectionMeta.id
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].INVITE_PLAYLIST: {
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenShareModal"]({
                    type: $event.collectionType,
                    meta: this.collectionMeta
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].RADIO: {
                this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_21__["PlayRadioContent"]({
                    id: this.collectionMeta.id,
                    type: this.collectionType
                }));
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].REMOVE_DOWNLOADS: {
                this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["OpenConfirmationModal"]({
                    type: 'confirm',
                    question: 'Are you sure you want to remove all downloads?'
                }));
                this._actionsSubject
                    .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_14__["DialogsActionTypes"].ConfirmationModalAnswer), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1))
                    .subscribe(action => {
                    const response = action.payload;
                    if (response && response.type === 'confirm') {
                        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__["EmitMessageToDesktopClient"]({
                            message: 'download-remove-all',
                            payload: {}
                        }));
                    }
                });
                break;
            }
            case _enums_enums__WEBPACK_IMPORTED_MODULE_11__["collectionActionsEnums"].TOGGLE: {
                switch ($event.toggleType) {
                    case 'auto_downloads':
                        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__["SetAutoDownloadsState"]({
                            enabled: $event.toggleValue
                        }));
                        break;
                    default:
                        break;
                }
                break;
            }
            default: {
                alert($event.actionType);
            }
        }
        if (eventName) {
            this.store.dispatch(new _redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                name: eventName,
                props: {
                    id: props
                }
            }));
        }
    }
    playDefaultBehaviour(index) {
        this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_21__["PlayTrackEngine"]({
            queue: this.collectionPlayableSection,
            list: this.collectionMeta,
            click: true,
            shuffle: false,
            index: index ? index : 0,
            isVideo: this.collectionPlayableSection.type === 'video',
        }));
    }
    initializeLikesListeners() {
        if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].SONG) {
            this.likedSongsSubscription = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_16__["getLikedSongsHashed"]))
                .subscribe(likesMap => {
                if (likesMap) {
                    this.collectionMeta = Object.assign({}, this.collectionMeta, { liked: !!likesMap[this.collectionMeta.id] });
                }
            });
        }
        if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].ALBUM) {
            this.likedAlbumsSubscription = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_16__["getLikedAlbumsHashed"]))
                .subscribe(likedAlbumsMap => {
                if (likedAlbumsMap) {
                    this.collectionMeta = Object.assign({}, this.collectionMeta, { liked: !!likedAlbumsMap[this.collectionMeta.id] });
                }
            });
        }
        if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].ARTIST) {
            this.followedArtistsSubscription = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_16__["getFollowedArtistsHashed"]))
                .subscribe(followedArtistsMap => {
                if (followedArtistsMap) {
                    this.collectionMeta = Object.assign({}, this.collectionMeta, { followed: !!followedArtistsMap[this.collectionMeta.id] });
                }
            });
        }
        if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].PLAYLIST) {
            this.followedPlaylistsSubscription = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_16__["getFollowedPlaylistsHashed"]))
                .subscribe(followedPlaylistsMap => {
                if (followedPlaylistsMap) {
                    this.collectionMeta = Object.assign({}, this.collectionMeta, { followed: !!followedPlaylistsMap[this.collectionMeta.id] });
                }
            });
        }
    }
    ngOnDestroy() {
        if (this.followersList$) {
            this.followersList$.unsubscribe();
        }
        if (this.confirmationModalSub$) {
            this.confirmationModalSub$.unsubscribe();
        }
        if (this.deletePlaylistSuccSub$) {
            this.deletePlaylistSuccSub$.unsubscribe();
        }
        if (this.likedSongsSubscription) {
            this.likedSongsSubscription.unsubscribe();
        }
        if (this.likedAlbumsSubscription) {
            this.likedAlbumsSubscription.unsubscribe();
        }
        if (this.followedArtistsSubscription) {
            this.followedArtistsSubscription.unsubscribe();
        }
        if (this.followedPlaylistsSubscription) {
            this.followedPlaylistsSubscription.unsubscribe();
        }
        if (this.sticky) {
            this.sticky.destroy();
        }
    }
    initMappingLocale() {
        if (this.locale === 'ar') {
            this.followerMapping = {
                '=0': 'No followers',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].FOLLOWER,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].FOLLOWERS
            };
            this.followingMapping = {
                '=0': 'No followers',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].FOLLOWING,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].FOLLOWING
            };
            this.songMapping = {
                '=0': 'No Songs',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].SONG,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].SONGS
            };
            this.episodesMapping = {
                '=0': 'No Episodes',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].EPISODE,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].EPISODES
            };
            this.playsMapping = {
                '=0': 'No Plays',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].PLAY,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].PLAYS
            };
            this.likesMapping = {
                '=0': 'No Plays',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].LIKE,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoAR"].LIKES
            };
        }
        else if (this.locale === 'fr') {
            this.followerMapping = {
                '=0': 'No followers',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].FOLLOWER,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].FOLLOWERS
            };
            this.followingMapping = {
                '=0': 'No followers',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].FOLLOWING,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].FOLLOWING
            };
            this.songMapping = {
                '=0': 'No Songs',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].SONG,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].SONGS
            };
            this.episodesMapping = {
                '=0': 'No Episodes',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].EPISODE,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].EPISODES
            };
            this.playsMapping = {
                '=0': 'No Plays',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].PLAY,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].PLAYS
            };
            this.likesMapping = {
                '=0': 'No Plays',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].LIKE,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["HeaderCollectionInfoFR"].LIKES
            };
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionHeaderSideComponent.prototype, "collectionMeta", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionHeaderSideComponent.prototype, "collectionSections", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CollectionHeaderSideComponent.prototype, "collectionType", void 0);
CollectionHeaderSideComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'anghami-collection-header-side',
        template: __webpack_require__(/*! raw-loader!./collection-header-side.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/collection-header-side/collection-header-side.component.html"),
        styles: [__webpack_require__(/*! ./collection-header-side.component.scss */ "./src/app/core/components/collection-header-side/collection-header-side.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](6, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String, _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["ActionsSubject"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ChangeDetectorRef"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_18__["AuthService"],
        Object])
], CollectionHeaderSideComponent);



/***/ }),

/***/ "./src/app/core/components/collection-header-side/collection-header-side.module.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/core/components/collection-header-side/collection-header-side.module.ts ***!
  \*****************************************************************************************/
/*! exports provided: CollectionHeaderSideModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CollectionHeaderSideModule", function() { return CollectionHeaderSideModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ang_header_stories_ang_header_stories_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../ang-header-stories/ang-header-stories.module */ "./src/app/core/components/ang-header-stories/ang-header-stories.module.ts");
/* harmony import */ var _collection_header_side_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./collection-header-side.component */ "./src/app/core/components/collection-header-side/collection-header-side.component.ts");
/* harmony import */ var _collection_header_buttons_collection_header_buttons_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../collection-header-buttons/collection-header-buttons.component */ "./src/app/core/components/collection-header-buttons/collection-header-buttons.component.ts");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _icon_icon_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _ang_video_ang_video_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../ang-video/ang-video.module */ "./src/app/core/components/ang-video/ang-video.module.ts");
/* harmony import */ var _story_list_story_list_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../story-list/story-list.module */ "./src/app/core/components/story-list/story-list.module.ts");













let CollectionHeaderSideModule = class CollectionHeaderSideModule {
};
CollectionHeaderSideModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _ang_header_stories_ang_header_stories_module__WEBPACK_IMPORTED_MODULE_4__["AngHeaderStoriesModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"],
            _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_7__["PipesModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbModule"],
            _icon_icon_module__WEBPACK_IMPORTED_MODULE_10__["IconModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormsModule"],
            _ang_video_ang_video_module__WEBPACK_IMPORTED_MODULE_11__["AngVideoModule"],
            _story_list_story_list_module__WEBPACK_IMPORTED_MODULE_12__["StoryListModule"]
        ],
        declarations: [
            _collection_header_side_component__WEBPACK_IMPORTED_MODULE_5__["CollectionHeaderSideComponent"],
            _collection_header_buttons_collection_header_buttons_component__WEBPACK_IMPORTED_MODULE_6__["CollectionHeaderButtonsComponent"]
        ],
        exports: [_collection_header_side_component__WEBPACK_IMPORTED_MODULE_5__["CollectionHeaderSideComponent"], _collection_header_buttons_collection_header_buttons_component__WEBPACK_IMPORTED_MODULE_6__["CollectionHeaderButtonsComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], CollectionHeaderSideModule);



/***/ })

}]);