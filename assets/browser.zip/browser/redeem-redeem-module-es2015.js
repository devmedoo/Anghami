(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["redeem-redeem-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/sponsored-partners/sponsored-partners.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/sponsored-partners/sponsored-partners.component.html ***!
  \****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"full-row-layout\">\n  <div class=\"container\">\n    <div class=\"row flippable\">\n      <div class=\"column primary col-sm-3\">\n        <div class=\"onsided-title\">\n          <p i18n=\"@@activationcode_partners\">Get an activation code through our partners</p>\n        </div>\n      </div>\n      <div class=\"column secondary col-sm-9\">\n        <div class=\"img-container\">\n          <div class=\"swiper-button-prev\" #prev></div>\n          <div class=\"swiper-container\" #carouselContainer>\n            <div class=\"swiper-wrapper d-flex align-items-center\">\n              <img class=\"swiper-slide\" *ngFor=\"let partner of partners\" [src]=\"partner.image\">\n            </div>\n          </div>\n          <div class=\"swiper-button-next\" #next></div>\n        </div>\n      </div>\n    </div>\n  </div>\n</section>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/terms-and-conditions/terms-and-conditions.component.html":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/terms-and-conditions/terms-and-conditions.component.html ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h2 class=\"py-2\">{{ title }}</h2>\n<ul class=\"white-box\" [ngClass]=\"type\">\n  <li *ngFor=\"let term of terms\">\n    <span class=\"px-1\">{{ term }}</span>\n  </li>\n</ul>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/redeem/redeem.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/redeem/redeem.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<anghami-inner-header [backgroundHeader]=\"innerHeader\"></anghami-inner-header>\n<ng-container *ngIf=\"showSteps\">\n  <section class=\"full-row-layout steps\">\n    <div class=\"container\">\n      <div class=\"row margin-bottom-2\">\n        <div class=\"column text-center fill-col\">\n          <h4 i18n=\"@@addpromocode_steps\">\n            Follow the below steps to use your promocode\n          </h4>\n          <h6 i18n=\"@@addpromocode_alreadyonanghami\" class=\"py-2\">\n            If you already have an Anghami account, go to step 3\n          </h6>\n        </div>\n      </div>\n      <div class=\"row\">\n        <div class=\"col-sm-4 d-flex\">\n          <div class=\"step\">1</div>\n          <div class=\"desc\">\n            <a href=\"https://www.anghami.com/getapp\">\n              <span i18n=\"@@download_anghami\">Download Anghami</span>\n            </a>\n            <br />\n            <span i18n=\"@@on_your_device\">on your device</span>\n          </div>\n        </div>\n        <div class=\"col-sm-4 d-flex\">\n          <div class=\"step\">2</div>\n          <div class=\"desc\">\n            <span i18n=\"@@addpromocode_steptwo_1\">Open the app</span>\n            <br />\n            <span i18n=\"@@addpromocode_steptwo_2\">& create an account</span>\n          </div>\n        </div>\n        <div class=\"col-sm-4 d-flex\">\n          <div class=\"step\">3</div>\n          <div class=\"desc\">\n            <span i18n=\"@@tap\">Tap</span>&nbsp;\n            <a (click)=\"openDeeplink()\">\n              <span i18n=\"@@here\">here</span>\n            </a>\n            <br />\n            <span i18n=\"@@apply_promo\">to apply your promocode</span>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>\n</ng-container>\n<ng-container *ngIf=\"!showSteps\">\n  <anghami-white-box\n    [notice]=\"isNotice || initialLoading\"\n    [loading]=\"initialLoading\"\n    [brand]=\"innerHeader?.type === 'pringles'\"\n  >\n    <ng-container *ngIf=\"!initialLoading\">\n      <!-- <ng-container *ngIf=\"!isplus\"> -->\n      <ng-container *ngIf=\"!autoActivate\">\n        <ng-container *ngIf=\"!showWeblNotif\">\n          <anghami-activation-code\n            (submit)=\"redeem()\"\n            [displaytype]=\"'redeem'\"\n            [activation]=\"activation\"\n            (clearError)=\"resetErrorMsg()\"\n            [loading]=\"isloading\"\n            class=\"redeem-activation-code\"\n          ></anghami-activation-code>\n          <div class=\"err px-1\" *ngIf=\"errorMsg\">\n            {{ errorMsg | translateInstant }}\n          </div>\n          <div class=\"err px-1\" *ngIf=\"apiErrorMsg\">{{ apiErrorMsg }}</div>\n        </ng-container>\n        <ng-container *ngIf=\"showWeblNotif\">\n          <div i18n=\"@@redeem_options_text\" class=\"option-title\">You can proceed from the app or login to your account and continue here</div>\n          <div class=\"flexbox\">\n            <anghami-button\n              class=\"d-block\" label=\"haveApp\"\n              (click)=\"redirectWebl()\"\n              layout=\"blue\" target=\"none\" size=\"narrow\"\n            ></anghami-button>\n            <div\n              i18n=\"@@redeem_options_button2\"\n              (click)=\"redeem(true)\"\n              class=\"option-link\"\n            >\n              Login & continue here\n            </div>\n          </div>\n        </ng-container>\n      </ng-container>\n      <ng-container *ngIf=\"autoActivate\">\n        <div class=\"autoActivate\">\n          <ng-container\n            *ngIf=\"\n              !errorMsg || errorMsg == '' || !apiErrorMsg || apiErrorMsg == ''\n            \"\n          >\n            <anghami-payment-form\n              [selectedPlan]=\"autoActivationObject\"\n              [submitText]=\"'Redeem Your Voucher'\"\n            ></anghami-payment-form>\n          </ng-container>\n          <ng-container\n            *ngIf=\"\n              (errorMsg && errorMsg != '') || (apiErrorMsg && apiErrorMsg != '')\n            \"\n          >\n            <h5 *ngIf=\"errorMsg && errorMsg != ''\">\n              {{ errorMsg | translateInstant }}\n            </h5>\n            <h5 *ngIf=\"apiErrorMsg && apiErrorMsg != ''\">{{ apiErrorMsg }}</h5>\n          </ng-container>\n        </div>\n      </ng-container>\n      <!-- </ng-container> -->\n      <ng-container *ngIf=\"noticeDtls && noticeDtls !== null\">\n        <!-- (isLoggedIn && isplus) || !isLoggedIn -->\n        <anghami-notice\n          [type]=\"'notice'\"\n          [notice]=\"noticeDtls\"\n          (submit)=\"handleNoticeAction($event)\"\n        ></anghami-notice>\n      </ng-container>\n    </ng-container>\n    <ng-container *ngIf=\"initialLoading\">\n      <anghami-loading class=\"loader\"></anghami-loading>\n    </ng-container>\n  </anghami-white-box>\n  <ng-container\n    *ngIf=\"!autoActivate && (!brandedActivation || brandedActivation === '')\"\n  >\n    <div class=\"space-3\"></div>\n    <anghami-sponsored-partners></anghami-sponsored-partners>\n  </ng-container>\n</ng-container>\n<div class=\"space-3\" [ngClass]=\"{ hide: showSteps }\"></div>\n<ng-container *ngIf=\"!brandedActivation || brandedActivation === ''\">\n  <anghami-gift-block></anghami-gift-block>\n</ng-container>\n<ng-container *ngIf=\"conditionsLst && conditionsLst.length > 0\">\n  <div class=\"space-3\"></div>\n  <anghami-terms-and-conditions\n    [terms]=\"conditionsLst\"\n    [title]=\"conditionsTitlte\"\n    [type]=\"brandedActivation\"\n  ></anghami-terms-and-conditions>\n</ng-container>\n<ng-container *ngIf=\"termsLst && termsLst.length > 0\">\n  <div class=\"space-3\"></div>\n  <anghami-terms-and-conditions\n    [terms]=\"termsLst\"\n    title=\"{{'terms_conditions_title' | translate}}\"\n  ></anghami-terms-and-conditions>\n</ng-container>\n<div class=\"space-3\"></div>\n<anghami-faq [showHelpCenter]=\"true\" [showQuestions]=\"showfaq\"></anghami-faq>\n"

/***/ }),

/***/ "./src/app/core/components/sponsored-partners/sponsored-partners.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/core/components/sponsored-partners/sponsored-partners.component.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/**\n * Swiper 4.5.1\n * Most modern mobile touch slider and framework with hardware accelerated transitions\n * http://www.idangero.us/swiper/\n *\n * Copyright 2014-2019 Vladimir Kharlampidi\n *\n * Released under the MIT License\n *\n * Released on: September 13, 2019\n */\n.swiper-container{margin-left:auto;margin-right:auto;position:relative;overflow:hidden;list-style:none;padding:0;z-index:1}\n.swiper-container-no-flexbox .swiper-slide{float:left}\n.swiper-container-vertical>.swiper-wrapper{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}\n.swiper-wrapper{position:relative;width:100%;height:100%;z-index:1;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-transition-property:-webkit-transform;transition-property:-webkit-transform;transition-property:transform;transition-property:transform, -webkit-transform;transition-property:transform,-webkit-transform;box-sizing:content-box}\n.swiper-container-android .swiper-slide,.swiper-wrapper{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}\n.swiper-container-multirow>.swiper-wrapper{-ms-flex-wrap:wrap;flex-wrap:wrap}\n.swiper-container-free-mode>.swiper-wrapper{-webkit-transition-timing-function:ease-out;transition-timing-function:ease-out;margin:0 auto}\n.swiper-slide{-ms-flex-negative:0;flex-shrink:0;width:100%;height:100%;position:relative;-webkit-transition-property:-webkit-transform;transition-property:-webkit-transform;transition-property:transform;transition-property:transform, -webkit-transform;transition-property:transform,-webkit-transform}\n.swiper-slide-invisible-blank{visibility:hidden}\n.swiper-container-autoheight,.swiper-container-autoheight .swiper-slide{height:auto}\n.swiper-container-autoheight .swiper-wrapper{-webkit-box-align:start;-ms-flex-align:start;align-items:flex-start;-webkit-transition-property:height,-webkit-transform;transition-property:height,-webkit-transform;transition-property:transform,height;transition-property:transform,height,-webkit-transform}\n.swiper-container-3d{-webkit-perspective:1200px;perspective:1200px}\n.swiper-container-3d .swiper-cube-shadow,.swiper-container-3d .swiper-slide,.swiper-container-3d .swiper-slide-shadow-bottom,.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top,.swiper-container-3d .swiper-wrapper{-webkit-transform-style:preserve-3d;transform-style:preserve-3d}\n.swiper-container-3d .swiper-slide-shadow-bottom,.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:10}\n.swiper-container-3d .swiper-slide-shadow-left{background-image:-webkit-gradient(linear,right top, left top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:linear-gradient(to left,rgba(0,0,0,.5),rgba(0,0,0,0))}\n.swiper-container-3d .swiper-slide-shadow-right{background-image:-webkit-gradient(linear,left top, right top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:linear-gradient(to right,rgba(0,0,0,.5),rgba(0,0,0,0))}\n.swiper-container-3d .swiper-slide-shadow-top{background-image:-webkit-gradient(linear,left bottom, left top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:linear-gradient(to top,rgba(0,0,0,.5),rgba(0,0,0,0))}\n.swiper-container-3d .swiper-slide-shadow-bottom{background-image:-webkit-gradient(linear,left top, left bottom,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:linear-gradient(to bottom,rgba(0,0,0,.5),rgba(0,0,0,0))}\n.swiper-container-wp8-horizontal,.swiper-container-wp8-horizontal>.swiper-wrapper{-ms-touch-action:pan-y;touch-action:pan-y}\n.swiper-container-wp8-vertical,.swiper-container-wp8-vertical>.swiper-wrapper{-ms-touch-action:pan-x;touch-action:pan-x}\n.swiper-button-next,.swiper-button-prev{position:absolute;top:50%;width:27px;height:44px;margin-top:-22px;z-index:10;cursor:pointer;background-size:27px 44px;background-position:center;background-repeat:no-repeat}\n.swiper-button-next.swiper-button-disabled,.swiper-button-prev.swiper-button-disabled{opacity:.35;cursor:auto;pointer-events:none}\n.swiper-button-prev,.swiper-container-rtl .swiper-button-next{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M0%2C22L22%2C0l2.1%2C2.1L4.2%2C22l19.9%2C19.9L22%2C44L0%2C22L0%2C22L0%2C22z'%20fill%3D'%23007aff'%2F%3E%3C%2Fsvg%3E\");left:10px;right:auto}\n.swiper-button-next,.swiper-container-rtl .swiper-button-prev{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M27%2C22L27%2C22L5%2C44l-2.1-2.1L22.8%2C22L2.9%2C2.1L5%2C0L27%2C22L27%2C22z'%20fill%3D'%23007aff'%2F%3E%3C%2Fsvg%3E\");right:10px;left:auto}\n.swiper-button-prev.swiper-button-white,.swiper-container-rtl .swiper-button-next.swiper-button-white{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M0%2C22L22%2C0l2.1%2C2.1L4.2%2C22l19.9%2C19.9L22%2C44L0%2C22L0%2C22L0%2C22z'%20fill%3D'%23ffffff'%2F%3E%3C%2Fsvg%3E\")}\n.swiper-button-next.swiper-button-white,.swiper-container-rtl .swiper-button-prev.swiper-button-white{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M27%2C22L27%2C22L5%2C44l-2.1-2.1L22.8%2C22L2.9%2C2.1L5%2C0L27%2C22L27%2C22z'%20fill%3D'%23ffffff'%2F%3E%3C%2Fsvg%3E\")}\n.swiper-button-prev.swiper-button-black,.swiper-container-rtl .swiper-button-next.swiper-button-black{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M0%2C22L22%2C0l2.1%2C2.1L4.2%2C22l19.9%2C19.9L22%2C44L0%2C22L0%2C22L0%2C22z'%20fill%3D'%23000000'%2F%3E%3C%2Fsvg%3E\")}\n.swiper-button-next.swiper-button-black,.swiper-container-rtl .swiper-button-prev.swiper-button-black{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M27%2C22L27%2C22L5%2C44l-2.1-2.1L22.8%2C22L2.9%2C2.1L5%2C0L27%2C22L27%2C22z'%20fill%3D'%23000000'%2F%3E%3C%2Fsvg%3E\")}\n.swiper-button-lock{display:none}\n.swiper-pagination{position:absolute;text-align:center;-webkit-transition:.3s opacity;transition:.3s opacity;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0);z-index:10}\n.swiper-pagination.swiper-pagination-hidden{opacity:0}\n.swiper-container-horizontal>.swiper-pagination-bullets,.swiper-pagination-custom,.swiper-pagination-fraction{bottom:10px;left:0;width:100%}\n.swiper-pagination-bullets-dynamic{overflow:hidden;font-size:0}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{-webkit-transform:scale(.33);-ms-transform:scale(.33);transform:scale(.33);position:relative}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-main{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-prev{-webkit-transform:scale(.66);-ms-transform:scale(.66);transform:scale(.66)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-prev-prev{-webkit-transform:scale(.33);-ms-transform:scale(.33);transform:scale(.33)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-next{-webkit-transform:scale(.66);-ms-transform:scale(.66);transform:scale(.66)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-next-next{-webkit-transform:scale(.33);-ms-transform:scale(.33);transform:scale(.33)}\n.swiper-pagination-bullet{width:8px;height:8px;display:inline-block;border-radius:100%;background:#000;opacity:.2}\nbutton.swiper-pagination-bullet{border:none;margin:0;padding:0;box-shadow:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}\n.swiper-pagination-clickable .swiper-pagination-bullet{cursor:pointer}\n.swiper-pagination-bullet-active{opacity:1;background:#007aff}\n.swiper-container-vertical>.swiper-pagination-bullets{right:10px;top:50%;-webkit-transform:translate3d(0,-50%,0);transform:translate3d(0,-50%,0)}\n.swiper-container-vertical>.swiper-pagination-bullets .swiper-pagination-bullet{margin:6px 0;display:block}\n.swiper-container-vertical>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic{top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);width:8px}\n.swiper-container-vertical>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{display:inline-block;-webkit-transition:.2s top,.2s -webkit-transform;transition:.2s top,.2s -webkit-transform;-webkit-transition:.2s transform,.2s top;transition:.2s transform,.2s top;-webkit-transition:.2s transform,.2s top,.2s -webkit-transform;transition:.2s transform,.2s top,.2s -webkit-transform}\n.swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet{margin:0 4px}\n.swiper-container-horizontal>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic{left:50%;-webkit-transform:translateX(-50%);-ms-transform:translateX(-50%);transform:translateX(-50%);white-space:nowrap}\n.swiper-container-horizontal>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{-webkit-transition:.2s left,.2s -webkit-transform;transition:.2s left,.2s -webkit-transform;-webkit-transition:.2s transform,.2s left;transition:.2s transform,.2s left;-webkit-transition:.2s transform,.2s left,.2s -webkit-transform;transition:.2s transform,.2s left,.2s -webkit-transform}\n.swiper-container-horizontal.swiper-container-rtl>.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{-webkit-transition:.2s right,.2s -webkit-transform;transition:.2s right,.2s -webkit-transform;-webkit-transition:.2s transform,.2s right;transition:.2s transform,.2s right;-webkit-transition:.2s transform,.2s right,.2s -webkit-transform;transition:.2s transform,.2s right,.2s -webkit-transform}\n.swiper-pagination-progressbar{background:rgba(0,0,0,.25);position:absolute}\n.swiper-pagination-progressbar .swiper-pagination-progressbar-fill{background:#007aff;position:absolute;left:0;top:0;width:100%;height:100%;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);-webkit-transform-origin:left top;-ms-transform-origin:left top;transform-origin:left top}\n.swiper-container-rtl .swiper-pagination-progressbar .swiper-pagination-progressbar-fill{-webkit-transform-origin:right top;-ms-transform-origin:right top;transform-origin:right top}\n.swiper-container-horizontal>.swiper-pagination-progressbar,.swiper-container-vertical>.swiper-pagination-progressbar.swiper-pagination-progressbar-opposite{width:100%;height:4px;left:0;top:0}\n.swiper-container-horizontal>.swiper-pagination-progressbar.swiper-pagination-progressbar-opposite,.swiper-container-vertical>.swiper-pagination-progressbar{width:4px;height:100%;left:0;top:0}\n.swiper-pagination-white .swiper-pagination-bullet-active{background:#fff}\n.swiper-pagination-progressbar.swiper-pagination-white{background:rgba(255,255,255,.25)}\n.swiper-pagination-progressbar.swiper-pagination-white .swiper-pagination-progressbar-fill{background:#fff}\n.swiper-pagination-black .swiper-pagination-bullet-active{background:#000}\n.swiper-pagination-progressbar.swiper-pagination-black{background:rgba(0,0,0,.25)}\n.swiper-pagination-progressbar.swiper-pagination-black .swiper-pagination-progressbar-fill{background:#000}\n.swiper-pagination-lock{display:none}\n.swiper-scrollbar{border-radius:10px;position:relative;-ms-touch-action:none;background:rgba(0,0,0,.1)}\n.swiper-container-horizontal>.swiper-scrollbar{position:absolute;left:1%;bottom:3px;z-index:50;height:5px;width:98%}\n.swiper-container-vertical>.swiper-scrollbar{position:absolute;right:3px;top:1%;z-index:50;width:5px;height:98%}\n.swiper-scrollbar-drag{height:100%;width:100%;position:relative;background:rgba(0,0,0,.5);border-radius:10px;left:0;top:0}\n.swiper-scrollbar-cursor-drag{cursor:move}\n.swiper-scrollbar-lock{display:none}\n.swiper-zoom-container{width:100%;height:100%;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;text-align:center}\n.swiper-zoom-container>canvas,.swiper-zoom-container>img,.swiper-zoom-container>svg{max-width:100%;max-height:100%;-o-object-fit:contain;object-fit:contain}\n.swiper-slide-zoomed{cursor:move}\n.swiper-lazy-preloader{width:42px;height:42px;position:absolute;left:50%;top:50%;margin-left:-21px;margin-top:-21px;z-index:10;-webkit-transform-origin:50%;-ms-transform-origin:50%;transform-origin:50%;-webkit-animation:swiper-preloader-spin 1s steps(12,end) infinite;animation:swiper-preloader-spin 1s steps(12,end) infinite}\n.swiper-lazy-preloader:after{display:block;content:'';width:100%;height:100%;background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%236c6c6c'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E\");background-position:50%;background-size:100%;background-repeat:no-repeat}\n.swiper-lazy-preloader-white:after{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%23fff'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E\")}\n@-webkit-keyframes swiper-preloader-spin{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}\n@keyframes swiper-preloader-spin{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}\n.swiper-container .swiper-notification{position:absolute;left:0;top:0;pointer-events:none;opacity:0;z-index:-1000}\n.swiper-container-fade.swiper-container-free-mode .swiper-slide{-webkit-transition-timing-function:ease-out;transition-timing-function:ease-out}\n.swiper-container-fade .swiper-slide{pointer-events:none;-webkit-transition-property:opacity;transition-property:opacity}\n.swiper-container-fade .swiper-slide .swiper-slide{pointer-events:none}\n.swiper-container-fade .swiper-slide-active,.swiper-container-fade .swiper-slide-active .swiper-slide-active{pointer-events:auto}\n.swiper-container-cube{overflow:visible}\n.swiper-container-cube .swiper-slide{pointer-events:none;-webkit-backface-visibility:hidden;backface-visibility:hidden;z-index:1;visibility:hidden;-webkit-transform-origin:0 0;-ms-transform-origin:0 0;transform-origin:0 0;width:100%;height:100%}\n.swiper-container-cube .swiper-slide .swiper-slide{pointer-events:none}\n.swiper-container-cube.swiper-container-rtl .swiper-slide{-webkit-transform-origin:100% 0;-ms-transform-origin:100% 0;transform-origin:100% 0}\n.swiper-container-cube .swiper-slide-active,.swiper-container-cube .swiper-slide-active .swiper-slide-active{pointer-events:auto}\n.swiper-container-cube .swiper-slide-active,.swiper-container-cube .swiper-slide-next,.swiper-container-cube .swiper-slide-next+.swiper-slide,.swiper-container-cube .swiper-slide-prev{pointer-events:auto;visibility:visible}\n.swiper-container-cube .swiper-slide-shadow-bottom,.swiper-container-cube .swiper-slide-shadow-left,.swiper-container-cube .swiper-slide-shadow-right,.swiper-container-cube .swiper-slide-shadow-top{z-index:0;-webkit-backface-visibility:hidden;backface-visibility:hidden}\n.swiper-container-cube .swiper-cube-shadow{position:absolute;left:0;bottom:0;width:100%;height:100%;background:#000;opacity:.6;-webkit-filter:blur(50px);filter:blur(50px);z-index:0}\n.swiper-container-flip{overflow:visible}\n.swiper-container-flip .swiper-slide{pointer-events:none;-webkit-backface-visibility:hidden;backface-visibility:hidden;z-index:1}\n.swiper-container-flip .swiper-slide .swiper-slide{pointer-events:none}\n.swiper-container-flip .swiper-slide-active,.swiper-container-flip .swiper-slide-active .swiper-slide-active{pointer-events:auto}\n.swiper-container-flip .swiper-slide-shadow-bottom,.swiper-container-flip .swiper-slide-shadow-left,.swiper-container-flip .swiper-slide-shadow-right,.swiper-container-flip .swiper-slide-shadow-top{z-index:0;-webkit-backface-visibility:hidden;backface-visibility:hidden}\n.swiper-container-coverflow .swiper-wrapper{-ms-perspective:1200px}\n.container {\n  max-width: 700px !important;\n}\n.container .row {\n  margin-bottom: 0 !important;\n  -webkit-box-pack: justify !important;\n      -ms-flex-pack: justify !important;\n          justify-content: space-between !important;\n}\n.container .col-sm-3 {\n  max-width: 25% !important;\n}\n@media (max-width: 768px) {\n  .container .col-sm-3 {\n    max-width: 100% !important;\n  }\n}\n.container .col-sm-9 {\n  max-width: 75% !important;\n  -webkit-box-flex: 0 !important;\n      -ms-flex: 0 0 60% !important;\n          flex: 0 0 60% !important;\n}\n.container .onsided-title {\n  text-align: start !important;\n}\n.container .onsided-title p {\n  margin: auto;\n  font-size: 1.1em;\n}\n@media (max-width: 768px) {\n  .container .onsided-title p {\n    padding: 1em 0;\n  }\n}\n@media (max-width: 768px) {\n  .container .onsided-title {\n    text-align: center !important;\n  }\n}\n.swiper-container {\n  width: 80%;\n}\nimg.swiper-slide {\n  max-width: 6em;\n  max-height: 6em;\n  width: inherit !important;\n  margin: 0 1em !important;\n}\n.swiper-button-next, .swiper-button-prev {\n  -webkit-transform: scale(1.5);\n      -ms-transform: scale(1.5);\n          transform: scale(1.5);\n  outline: none;\n  opacity: 0.1;\n}\n.swiper-button-prev {\n  background-image: url(\"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/PjwhRE9DVFlQRSBzdmcgIFBVQkxJQyAnLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4nICAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkJz48c3ZnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDMyIDMyIiBoZWlnaHQ9IjMycHgiIGlkPSLQodC70L7QuV8xIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMycHgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxwYXRoIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTExLjI2MiwxNi43MTRsOS4wMDIsOC45OTkgIGMwLjM5NSwwLjM5NCwxLjAzNSwwLjM5NCwxLjQzMSwwYzAuMzk1LTAuMzk0LDAuMzk1LTEuMDM0LDAtMS40MjhMMTMuNDA3LDE2bDguMjg3LTguMjg1YzAuMzk1LTAuMzk0LDAuMzk1LTEuMDM0LDAtMS40MjkgIGMtMC4zOTUtMC4zOTQtMS4wMzYtMC4zOTQtMS40MzEsMGwtOS4wMDIsOC45OTlDMTAuODcyLDE1LjY3NSwxMC44NzIsMTYuMzI1LDExLjI2MiwxNi43MTR6IiBmaWxsPSIjMTIxMzEzIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGlkPSJDaGV2cm9uX1JpZ2h0Ii8+PGcvPjxnLz48Zy8+PGcvPjxnLz48Zy8+PC9zdmc+\");\n  left: -0.5em !important;\n}\n.swiper-button-next {\n  background-image: url(\"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/PjwhRE9DVFlQRSBzdmcgIFBVQkxJQyAnLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4nICAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkJz48c3ZnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDMyIDMyIiBoZWlnaHQ9IjMycHgiIGlkPSLQodC70L7QuV8xIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMycHgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxwYXRoIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTIxLjY5OCwxNS4yODZsLTkuMDAyLTguOTk5ICBjLTAuMzk1LTAuMzk0LTEuMDM1LTAuMzk0LTEuNDMxLDBjLTAuMzk1LDAuMzk0LTAuMzk1LDEuMDM0LDAsMS40MjhMMTkuNTUzLDE2bC04LjI4Nyw4LjI4NWMtMC4zOTUsMC4zOTQtMC4zOTUsMS4wMzQsMCwxLjQyOSAgYzAuMzk1LDAuMzk0LDEuMDM2LDAuMzk0LDEuNDMxLDBsOS4wMDItOC45OTlDMjIuMDg4LDE2LjMyNSwyMi4wODgsMTUuNjc1LDIxLjY5OCwxNS4yODZ6IiBmaWxsPSIjMTIxMzEzIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGlkPSJDaGV2cm9uX1JpZ2h0Ii8+PGcvPjxnLz48Zy8+PGcvPjxnLz48Zy8+PC9zdmc+\");\n  right: -0.5em !important;\n}"

/***/ }),

/***/ "./src/app/core/components/sponsored-partners/sponsored-partners.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/core/components/sponsored-partners/sponsored-partners.component.ts ***!
  \************************************************************************************/
/*! exports provided: SponsoredPartnersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SponsoredPartnersComponent", function() { return SponsoredPartnersComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/services/promo.service */ "./src/app/core/services/promo.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swiper/dist/js/swiper.min.js */ "./node_modules/swiper/dist/js/swiper.min.js");
/* harmony import */ var swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_4__);





let SponsoredPartnersComponent = class SponsoredPartnersComponent {
    constructor(_promoService, platformId) {
        this._promoService = _promoService;
        this.platformId = platformId;
    }
    ngOnInit() {
        this.partners = this._promoService.getPartnersList();
    }
    ngAfterViewInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["isPlatformBrowser"])(this.platformId)) {
            this.initCarousel();
        }
    }
    initCarousel() {
        const config = {
            spaceBetween: 10,
            direction: 'horizontal',
            loop: true,
            watchOverflow: true,
            watchSlidesVisibility: true,
            slidesPerView: 3,
            navigation: {
                nextEl: this.next.nativeElement,
                prevEl: this.prev.nativeElement
            }
        };
        new swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_4__(this.carouselContainer.nativeElement, config);
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"])('carouselContainer', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ElementRef"])
], SponsoredPartnersComponent.prototype, "carouselContainer", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"])('prev', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ElementRef"])
], SponsoredPartnersComponent.prototype, "prev", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"])('next', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ElementRef"])
], SponsoredPartnersComponent.prototype, "next", void 0);
SponsoredPartnersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'anghami-sponsored-partners',
        template: __webpack_require__(/*! raw-loader!./sponsored-partners.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/sponsored-partners/sponsored-partners.component.html"),
        styles: [__webpack_require__(/*! ./sponsored-partners.component.scss */ "./src/app/core/components/sponsored-partners/sponsored-partners.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_3__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_1__["PromoService"],
        Object])
], SponsoredPartnersComponent);



/***/ }),

/***/ "./src/app/core/components/terms-and-conditions/terms-and-conditions.component.scss":
/*!******************************************************************************************!*\
  !*** ./src/app/core/components/terms-and-conditions/terms-and-conditions.component.scss ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  -webkit-box-pack: center !important;\n      -ms-flex-pack: center !important;\n          justify-content: center !important;\n  width: 80%;\n  margin: auto;\n}\n@media (max-width: 768px) {\n  :host {\n    width: 100%;\n    margin-top: 2em;\n  }\n}\n:host h2 {\n  text-align: center;\n}\nul {\n  width: 75%;\n  font-size: 1.1em;\n  line-height: 1.7em;\n}\n@media (max-width: 768px) {\n  ul {\n    width: 80%;\n  }\n}\nul.white-box {\n  margin: auto;\n  min-width: 5em;\n  border: 1px solid #EEEEEE;\n  border-radius: 0.5em;\n  box-shadow: 5px 5px 30px -5px lightgrey;\n  padding: 1.5em 5em;\n  display: block;\n  background-color: white;\n  position: relative;\n  max-width: 55em;\n}\n@media (max-width: 768px) {\n  ul.white-box {\n    padding: 1.5em 3em !important;\n  }\n}\n@media (min-width: 769px) {\n  ul.white-box.pringles {\n    width: 50%;\n  }\n}\nli {\n  padding-left: 1em;\n  text-indent: -3em;\n  margin: 1em 0;\n}\nli:before {\n  border-style: solid;\n  border-width: 0 2px 2px 0;\n  content: \"\";\n  display: inline-block;\n  padding: 3px;\n  -webkit-transform: rotate(315deg) !important;\n  -ms-transform: rotate(315deg) !important;\n      transform: rotate(315deg) !important;\n  color: #0099f5;\n  margin: 0 1em;\n}\nhtml[lang=ar] :host li {\n  padding-left: 0em !important;\n  padding-right: 1em;\n  text-align: right;\n}\nhtml[lang=ar] :host li:before {\n  -webkit-transform: rotate(135deg) !important;\n      -ms-transform: rotate(135deg) !important;\n          transform: rotate(135deg) !important;\n}"

/***/ }),

/***/ "./src/app/core/components/terms-and-conditions/terms-and-conditions.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/core/components/terms-and-conditions/terms-and-conditions.component.ts ***!
  \****************************************************************************************/
/*! exports provided: TermsAndConditionsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsAndConditionsComponent", function() { return TermsAndConditionsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let TermsAndConditionsComponent = class TermsAndConditionsComponent {
    constructor(locale) {
        this.locale = locale;
        this.inlinebox = true;
        this.col = true;
    }
    ngOnInit() {
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], TermsAndConditionsComponent.prototype, "title", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], TermsAndConditionsComponent.prototype, "terms", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], TermsAndConditionsComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class.inline-box'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], TermsAndConditionsComponent.prototype, "inlinebox", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class.col'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], TermsAndConditionsComponent.prototype, "col", void 0);
TermsAndConditionsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-terms-and-conditions',
        template: __webpack_require__(/*! raw-loader!./terms-and-conditions.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/terms-and-conditions/terms-and-conditions.component.html"),
        styles: [__webpack_require__(/*! ./terms-and-conditions.component.scss */ "./src/app/core/components/terms-and-conditions/terms-and-conditions.component.scss"), __webpack_require__(/*! ../../../modules/landing/redeem/promo.component.scss */ "./src/app/modules/landing/redeem/promo.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
], TermsAndConditionsComponent);



/***/ }),

/***/ "./src/app/modules/landing/redeem/redeem-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/modules/landing/redeem/redeem-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: routes, RedeemRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RedeemRoutingModule", function() { return RedeemRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _redeem_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./redeem.component */ "./src/app/modules/landing/redeem/redeem.component.ts");




const routes = [
    {
        path: '',
        component: _redeem_component__WEBPACK_IMPORTED_MODULE_3__["RedeemComponent"]
    }, {
        path: '/:promo',
        component: _redeem_component__WEBPACK_IMPORTED_MODULE_3__["RedeemComponent"]
    }
];
let RedeemRoutingModule = class RedeemRoutingModule {
};
RedeemRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], RedeemRoutingModule);



/***/ }),

/***/ "./src/app/modules/landing/redeem/redeem.component.ts":
/*!************************************************************!*\
  !*** ./src/app/modules/landing/redeem/redeem.component.ts ***!
  \************************************************************/
/*! exports provided: RedeemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RedeemComponent", function() { return RedeemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../app/core/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/plus.actions */ "./src/app/core/redux/actions/plus.actions.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/promo.service */ "./src/app/core/services/promo.service.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
















let RedeemComponent = class RedeemComponent {
    constructor(store, _actionSubject, cookieService, locale, _route, _router, _authService, _promoService, _translate, _utilService) {
        this.store = store;
        this._actionSubject = _actionSubject;
        this.cookieService = cookieService;
        this.locale = locale;
        this._route = _route;
        this._router = _router;
        this._authService = _authService;
        this._promoService = _promoService;
        this._translate = _translate;
        this._utilService = _utilService;
        this.innerHeader = {
            isbox: true
        };
        this.autoActivationObject = {};
        this.issuccess = false;
        this.autoActivate = false;
        this.isloading = false;
        this.showSteps = false;
        this.isNotice = false;
        /**
         * TODO: add metas
         * */
        this.metas = 'metas_redeem_activation';
        this.initialLoading = true;
        this.showfaq = true;
        this.showWeblNotif = false;
        this.isAutoPromo = false;
    }
    ngOnInit() {
        if (this._utilService.isBrowser()) {
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_3__["LogAmplitudeEvent"]({
                name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["AmplitudeEvents"].redeem_landing
            }));
            const pathname = window.location.pathname;
            if (pathname && pathname !== null && pathname.indexOf('redeem') === -1) {
                const activation = pathname.split('/');
                if (activation && activation !== null && activation.length > 1) {
                    this.brandedActivation = activation[1];
                }
            }
            this.isDeviceMobile = this._promoService.isDeviceMobile;
            this.isLoggedIn = this._authService.isUserLoggedIn();
            this.promoCodeCached = this.cookieService.get('redeemCode');
            this.redeemPromo = this._route.snapshot.params['promo'];
            this.activationCode = this._route.snapshot.queryParams['promocode'];
            this.activationType = this._route.snapshot.queryParams['type'];
            this.isAutoPromo = this._route.snapshot.queryParams['auto'] == 1 ? true : false;
            const code = this.redeemPromo && this.redeemPromo !== null && this.redeemPromo !== ''
                ? this.redeemPromo
                : this.activationCode &&
                    this.activationCode !== null &&
                    this.activationCode !== ''
                    ? this.activationCode
                    : this.promoCodeCached &&
                        this.promoCodeCached !== null &&
                        this.promoCodeCached !== ''
                        ? this.promoCodeCached
                        : '';
            this.urlqueryparams = this._route.snapshot['queryParams'];
            this.hideStepsCookie = this.cookieService.get('hidesteps');
            if (this.brandedActivation &&
                this.brandedActivation !== null &&
                this.brandedActivation !== '') {
                this._promoService
                    .getTermsAndConditions(this.brandedActivation)
                    .subscribe(res => {
                    if (res && res !== null) {
                        this.termsLst = res;
                        this.showfaq = false;
                    }
                });
                this._promoService
                    .getTermsAndConditions(this.brandedActivation, 'conditions')
                    .subscribe(res => {
                    if (res && res !== null) {
                        const key = _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["conditionsTitleKeys"][this.brandedActivation]
                            ? _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["conditionsTitleKeys"][this.brandedActivation].title
                            : '';
                        if (key && key !== null && key !== '') {
                            this.conditionsTitlte = this._translate.instant(key);
                        }
                        this.conditionsLst = res;
                    }
                });
            }
            this.activation = {
                action: 'redeemActivationAction',
                inputLst: [
                    {
                        placeholder: 'redeemActivationPlaceholder',
                        label: 'redeemActivationLabel',
                        model: code
                    }
                ]
            };
            this.userAuth$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__["getUser"]));
            this.handleRedeemActivation();
            if (code && code !== null && code !== '') {
                const queryparams = this.getUrlParams();
                this.promcodehref =
                    'anghami://promocode/' +
                        code +
                        (queryparams !== '' ? '?' + queryparams : '');
            }
            this.getInnerHeader();
            this.redeemModalDetails = this.getRedeemModalText();
            this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_6__["PlusActionTypes"].POSTPromocodeSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
                .subscribe((data) => {
                // if (data.payload['error']) {
                //   this.cardErrMsg = data.payload['error']['message'];
                // } else {
                //   this.success.emit(data.payload);
                // }
            });
            this.checkAutoPromo();
        }
    }
    /**
     * @description Calls redeem() in case page is comign through webl
     * User already had the promocode inserted earlier before switching to app web view
     */
    checkAutoPromo() {
        if (this.isAutoPromo && this.activationCode) {
            this.redeem();
        }
    }
    getUrlParams() {
        let str = '';
        if (this.urlqueryparams &&
            this.urlqueryparams !== null &&
            Object.keys(this.urlqueryparams).length > 0) {
            for (const key of Object.keys(this.urlqueryparams)) {
                if (key !== 'promocode') {
                    str += '&' + key + '=' + this.urlqueryparams[key];
                }
            }
            str = str.slice(1);
        }
        return str;
    }
    handleRedeemActivation() {
        if (this.promoCodeCached) {
            this._promoService
                .redeemPromocode({ promocode: this.promoCodeCached })
                .subscribe(result => {
                this.handlingResponse(result);
            });
        }
        const autoCode = this.activationCode && this.activationCode !== null
            ? this.activationCode.toLowerCase()
            : '';
        if (this.activationCode &&
            this.activationCode !== null &&
            autoCode.startsWith('vsa1')) {
            this.autoActivate = true;
            /**
             * TODO: check that this.redeem(this.activationCode); is not affected
             */
            this.redeem();
        }
        else {
            this._promoService.getPartnersList();
            this.initialLoading = false;
        }
        this.showSteps =
            (this.promoCodeCached || this.activationCode || this.redeemPromo) &&
                !this.autoActivate &&
                this.isDeviceMobile &&
                this.hideStepsCookie === undefined;
        this.cookieService.remove('hidesteps');
    }
    getInnerHeader() {
        const type = this.brandedActivation || this.activationType;
        if (this.showSteps) {
            this.innerHeader = Object.assign({}, this.innerHeader, { isbox: false });
        }
        if (type !== undefined) {
            this.innerHeader = Object.assign({}, _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["redeemActivationsHeader"][type.toLowerCase()], { type: type });
            if (this.innerHeader && this.innerHeader !== null) {
                if (this.innerHeader.mainimage &&
                    this.innerHeader.mainimage !== null &&
                    typeof this.innerHeader.mainimage === 'object') {
                    const lang = this.locale.indexOf('en') > -1 ? 'en' : this.locale;
                    this.innerHeader.mainimage = this.innerHeader.mainimage[lang];
                }
            }
            if (type === 'mcdonaldsarabia') {
                this.innerHeader = Object.assign({}, this.innerHeader, { extra: true });
            }
        }
        else if (this.redeemPromo &&
            this.redeemPromo !== null &&
            this.redeemPromo !== '') {
            this.innerHeader = Object.assign({}, _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["redeemActivationsHeader"][this.redeemPromo]);
        }
        if (this.innerHeader && this.innerHeader !== null) {
            if (this.innerHeader.title === undefined) {
                this.innerHeader.title = 'redeem_innerHeader_title';
            }
            if (this.innerHeader.subtitle === undefined) {
                this.innerHeader.subtitle = 'redeem_innerHeader_subtitle';
            }
        }
    }
    getRedeemModalText() {
        let modalText = {};
        const type = this.brandedActivation || this.activationType;
        if (type !== undefined) {
            modalText = _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["redeemModalText"][type];
        }
        else if (this.redeemPromo &&
            this.redeemPromo !== null &&
            this.redeemPromo !== '') {
            modalText = _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["redeemModalText"][this.redeemPromo];
        }
        if (!modalText ||
            modalText === null ||
            Object.keys(modalText).length === 0) {
            modalText = _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["redeemModalText"]['default'];
        }
        return modalText;
    }
    resetErrorMsg() {
        this.errorMsg = undefined;
        this.apiErrorMsg = undefined;
    }
    redeem(proceed) {
        this.isloading = true;
        this.resetErrorMsg();
        const promocode = this.activation &&
            this.activation.inputLst &&
            this.activation.inputLst.length > 0
            ? this.activation.inputLst[0].model
            : '';
        if (promocode && promocode != null) {
            if (!this.isLoggedIn && this.isDeviceMobile && !proceed) {
                this.showWeblNotif = true;
            }
            else {
                this._promoService
                    .redeemPromocode({ promocode: promocode })
                    .subscribe(result => {
                    this.handlingResponse(result);
                });
            }
        }
        else {
            if (this.autoActivate) {
                this.initialLoading = false;
            }
            this.isloading = false;
            this.errorMsg = 'activation_code_err';
            this.isNotice = JSON.parse(JSON.stringify(this.autoActivate));
        }
    }
    handlingResponse(result) {
        if (this._utilService.isBrowser()) {
            if (result && result !== null) {
                const response = result.res;
                const params = result.params;
                this.initialLoading = false;
                this.isloading = false;
                let activationObject = Object.assign({}, params);
                if (response.error) {
                    if (response['error'].code === 12) {
                        Object.assign(activationObject, {
                            isPaymentForm: false,
                            details: {
                                title: response['error'].message,
                                action: 'redeem_action_12'
                            },
                            class: 'age-dialog'
                        });
                        if (!this.autoActivate) {
                            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_10__["OpenRedeemModal"](activationObject));
                        }
                    }
                    else {
                        this.showWeblNotif = false;
                        this.apiErrorMsg = response['error'].message;
                        this.isNotice = JSON.parse(JSON.stringify(this.autoActivate));
                    }
                    // Not needed anymore but kept as logs - might be useful later in case of missing scenario
                    // if (response['error'].code === 35) {
                    //   Object.assign(activationObject, {
                    //     isPaymentForm: true,
                    //     details: this.redeemModalDetails,
                    //     type: 'POSTpromocode'
                    //   });
                    //   if (this.autoActivate) {
                    //     this.autoActivationObject = JSON.parse(
                    //       JSON.stringify(activationObject)
                    //     );
                    //   } else {
                    //     this.store.dispatch(new OpenRedeemModal(activationObject));
                    //   }
                    // } else if (response['error'].code === 36) {
                    //   Object.assign(activationObject, {
                    //     isPaymentForm: true,
                    //     details: {
                    //       title: response['error'].message,
                    //       action: 'redeem_action_36'
                    //     },
                    //     code: response['error'].code,
                    //     type: 'POSTpromocode'
                    //   });
                    //   if (this.autoActivate) {
                    //     this.autoActivationObject = JSON.parse(
                    //       JSON.stringify(activationObject)
                    //     );
                    //   } else {
                    //     this.store.dispatch(new OpenRedeemModal(activationObject));
                    //   }
                    // }
                }
                else {
                    if (response.creditcard_info) {
                        const plan = Object.assign({}, response.plan, { type: 'POSTpromocode', promocode: activationObject && activationObject.promocode
                                ? activationObject.promocode
                                : undefined });
                        const promocode = JSON.parse(JSON.stringify(response.promocode));
                        Object.assign(activationObject, {
                            plan: plan,
                            coupon: promocode,
                            isPaymentForm: true,
                            isPaymentRequired: ((response.creditcard_info).toLowerCase() === 'required'),
                            details: {}
                        });
                        if (this.autoActivate) {
                            this.autoActivationObject = JSON.parse(JSON.stringify(activationObject));
                        }
                        else {
                            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_10__["OpenRedeemModal"](activationObject));
                        }
                    }
                    else {
                        if (response.isplus ||
                            (response['_attributes'] && response['_attributes'].isplus)) {
                            this.issuccess = true;
                            this.promoMsg =
                                response.message ||
                                    (response['_attributes'] && response['_attributes'].message);
                            setTimeout(() => {
                                this._router.navigate(['/subscriptioncheck'], { queryParams: { success: 1 } });
                            }, 2000);
                        }
                    }
                }
            }
        }
    }
    handleNoticeAction(type) {
        if (type === 'login') {
            this._promoService.login('redeem', 'redeemAction');
        }
    }
    goToGift() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_3__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["AmplitudeEvents"].goto_gift
        }));
        window.location.href = 'https://www.anghami.com/gifts';
    }
    openDeeplink() {
        if (this._utilService.isBrowser()) {
            setTimeout(() => {
                window.location.href = this.promcodehref;
            });
        }
    }
    redirectWebl() {
        const promocode = this.activation &&
            this.activation.inputLst &&
            this.activation.inputLst.length > 0
            ? this.activation.inputLst[0].model
            : '';
        const params = this.getUrlParams();
        const url = `anghami://promocode/${promocode}${params !== '' ? `?${params}` : ''}`;
        window.location.href = url;
    }
};
RedeemComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-redeem',
        template: __webpack_require__(/*! raw-loader!./redeem.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/redeem/redeem.component.html"),
        styles: [__webpack_require__(/*! ./redeem.component.scss */ "./src/app/modules/landing/redeem/redeem.component.scss"), __webpack_require__(/*! ../../../core/components/activation-code/activation-code.component.scss */ "./src/app/core/components/activation-code/activation-code.component.scss"), __webpack_require__(/*! ./promo.component.scss */ "./src/app/modules/landing/redeem/promo.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
        ngx_cookie__WEBPACK_IMPORTED_MODULE_9__["CookieService"], Object, _angular_router__WEBPACK_IMPORTED_MODULE_11__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_11__["Router"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_12__["AuthService"],
        _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_13__["PromoService"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__["TranslateService"],
        _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_15__["UtilService"]])
], RedeemComponent);



/***/ }),

/***/ "./src/app/modules/landing/redeem/redeem.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/modules/landing/redeem/redeem.module.ts ***!
  \*********************************************************/
/*! exports provided: RedeemModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RedeemModule", function() { return RedeemModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _redeem_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./redeem.component */ "./src/app/modules/landing/redeem/redeem.component.ts");
/* harmony import */ var _redeem_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./redeem-routing.module */ "./src/app/modules/landing/redeem/redeem-routing.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/footer/footer.module */ "./src/app/core/components/footer/footer.module.ts");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _core_components_sponsored_partners_sponsored_partners_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/components/sponsored-partners/sponsored-partners.component */ "./src/app/core/components/sponsored-partners/sponsored-partners.component.ts");
/* harmony import */ var _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.module */ "./src/app/core/components/inner-header/inner-header.module.ts");
/* harmony import */ var _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.module */ "./src/app/core/components/white-box/white-box.module.ts");
/* harmony import */ var _core_components_faq_faq_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/components/faq/faq.module */ "./src/app/core/components/faq/faq.module.ts");
/* harmony import */ var _core_components_terms_and_conditions_terms_and_conditions_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/components/terms-and-conditions/terms-and-conditions.component */ "./src/app/core/components/terms-and-conditions/terms-and-conditions.component.ts");
/* harmony import */ var _core_components_notice_notice_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/components/notice/notice.module */ "./src/app/core/components/notice/notice.module.ts");
/* harmony import */ var _core_components_activation_code_activivaton_code_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../core/components/activation-code/activivaton-code.module */ "./src/app/core/components/activation-code/activivaton-code.module.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../core/components/payment-form/payment-form.module */ "./src/app/core/components/payment-form/payment-form.module.ts");
/* harmony import */ var _core_components_gift_block_gift_block_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../core/components/gift-block/gift-block.module */ "./src/app/core/components/gift-block/gift-block.module.ts");
/* harmony import */ var _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../core/components/button/button.module */ "./src/app/core/components/button/button.module.ts");




















let RedeemModule = class RedeemModule {
};
RedeemModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _redeem_routing_module__WEBPACK_IMPORTED_MODULE_4__["RedeemRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_6__["FooterModule"],
            _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_7__["LoadingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"],
            _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_10__["InnerHeaderModule"],
            _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_11__["WhiteBoxModule"],
            _core_components_faq_faq_module__WEBPACK_IMPORTED_MODULE_12__["FaqModule"],
            _core_components_notice_notice_module__WEBPACK_IMPORTED_MODULE_14__["NoticeModule"],
            _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_17__["PaymentFormModule"],
            _core_components_activation_code_activivaton_code_module__WEBPACK_IMPORTED_MODULE_15__["ActivationCodeModule"],
            _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_16__["PipesModule"],
            _core_components_gift_block_gift_block_module__WEBPACK_IMPORTED_MODULE_18__["GiftBlockModule"],
            _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_19__["ButtonModule"]
        ],
        declarations: [
            _redeem_component__WEBPACK_IMPORTED_MODULE_3__["RedeemComponent"],
            _core_components_sponsored_partners_sponsored_partners_component__WEBPACK_IMPORTED_MODULE_9__["SponsoredPartnersComponent"],
            _core_components_terms_and_conditions_terms_and_conditions_component__WEBPACK_IMPORTED_MODULE_13__["TermsAndConditionsComponent"]
        ],
        exports: [_redeem_component__WEBPACK_IMPORTED_MODULE_3__["RedeemComponent"]]
    })
], RedeemModule);



/***/ })

}]);