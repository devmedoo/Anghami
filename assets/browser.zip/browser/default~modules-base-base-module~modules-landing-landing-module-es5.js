(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~modules-base-base-module~modules-landing-landing-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/button/button.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "  <a \n  class=\"anghami_btn {{layout}} {{size}}\"\n  (click)=\"clickHandler($event)\"\n  [href]=\"link\"\n  [attr.target]=\"target\"\n  [class.loading]=\"loading\">\n  <span *ngIf=\"!loading\">\n    {{label_locale}}\n  </span>\n    \n    <div class=\"spinner-border text-light\" role=\"status\" *ngIf=\"loading\">\n      <span class=\"sr-only\">Loading...</span>\n    </div>\n  </a>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/download-app/download-app.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/download-app/download-app.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"os\">\n  <button #button [class.solid]=\"solid\" [ngClass]=\"{ onboarding: onboarding }\" (click)=\"downloadDesktopApp()\">\n    <ng-container *ngIf=\"os === 'mac'\" i18n=\"@@landing_bar_macapp\">Get Anghami for Mac</ng-container>\n    <ng-container *ngIf=\"os === 'windows'\" i18n=\"@@landing_bar_windowsapp\">Get Anghami for Windows</ng-container>\n  </button>\n</ng-container>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/header/header.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/header/header.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  class=\"header-container d-flex justify-content-start align-items-center\"\n  *ngIf=\"isPlatformBrowser\"\n>\n  <div class=\"desktop-navigation-container\" *ngIf=\"isDesktopClient\">\n    <button\n      (click)=\"onNavigationClick('backward')\"\n      [ngClass]=\"{ disabled: !navigationState.backward }\"\n    >\n      <anghami-icon class=\"icon\" [data]=\"'arrow-left'\"></anghami-icon>\n    </button>\n    <button\n      (click)=\"onNavigationClick('forward')\"\n      [ngClass]=\"{ disabled: !navigationState.forward }\"\n    >\n      <anghami-icon\n        class=\"icon\"\n        [data]=\"'arrow-left'\"\n        class=\"rotate-180\"\n      ></anghami-icon>\n    </button>\n  </div>\n  <div class=\"header-search\">\n    <anghami-main-search-input></anghami-main-search-input>\n  </div>\n  <div class=\"header-actions flex-grow-1 flex justify-content-between\">\n    <anghami-download-app [type]=\"'header'\"></anghami-download-app>\n    <div>\n      <div *ngIf=\"isloggedin\"  (click)=\"openDiscoverPopover()\" class=\"inbox\">\n          <div class=\"dot follow-dot\" *ngIf=\"showFollowNotification\"></div>\n        <div\n          #p=\"ngbPopover\"\n          [ngbPopover]=\"discover\"\n          autoClose=\"outside\"\n          [placement]=\"['bottom-right']\"\n          class=\"notif-context\"\n          [ngClass]=\"{ highlighted: inboxPopoverShown }\"\n          (hidden)=\"inboxPopoverShown = false\"\n          (shown)=\"inboxPopoverShown = true\"\n          popoverClass=\"notif-sheet discover-sheet\"\n        >\n          <anghami-icon\n            class=\"icon\"\n            [data]=\"'friends-icon'\"\n            [ngClass]=\"{ highlighted: inboxPopoverShown }\"\n          ></anghami-icon>\n        </div>\n        <ng-template #discover>\n          <anghami-discover\n            (closeModal)=\"closePopover(p)\"\n            [fromPopover]=\"true\"\n          ></anghami-discover>\n        </ng-template>\n      </div>\n      <div class=\"inbox\" *ngIf=\"isloggedin\">\n        <div class=\"dot\" *ngIf=\"showNotification\"></div>\n        <div\n          #p=\"ngbPopover\"\n          [ngbPopover]=\"notification\"\n          autoClose=\"outside\"\n          [placement]=\"['bottom-right']\"\n          class=\"notif-context\"\n          [ngClass]=\"{ highlighted: discoverPopoverShown }\"\n          (hidden)=\"discoverPopoverShown = false\"\n          (shown)=\"discoverPopoverShown = true\"\n          popoverClass=\"notif-sheet\"\n        >\n          <anghami-icon\n            class=\"icon\"\n            [data]=\"'notification'\"\n            [ngClass]=\"{ highlighted: discoverPopoverShown }\"\n          ></anghami-icon>\n        </div>\n        <ng-template #notification>\n          <anghami-inbox-sheet\n            (closeModal)=\"closePopover(p)\"\n          ></anghami-inbox-sheet>\n        </ng-template>\n      </div>\n    </div>\n  </div>\n  <anghami-user-navigation></anghami-user-navigation>\n</div>\n<div class=\"overlay\"></div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/inbox-sheet/inbox-sheet.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/inbox-sheet/inbox-sheet.component.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header\" i18n=\"@@Notifications\">Notifications</div>\n<div class=\"notif-container\" [ngClass]=\"{ loading: loading }\" #scrollTarget>\n  <ng-container *ngIf=\"loading\">\n    <anghami-loading class=\"loader\"></anghami-loading>\n  </ng-container>\n  <ng-container *ngIf=\"!loading\">\n    <div\n      *ngFor=\"let notification of (notificationsLst | slice: 0:currentNum)\"\n      class=\"d-flex justify-content-between\"\n    >\n      <a\n        class=\"d-flex align-items-start\"\n        [routerLink]=\"'/' + notification?.href\"\n      >\n        <img\n          class=\"coverart lazy-image\"\n          [src]=\"notification.data[0].covertArtImageSmall\"\n        />\n        <div class=\"flex-column px-2\">\n          <div class=\"title\" dir=\"auto\">{{ notification.data[0].title }}</div>\n          <div class=\"message\">{{ notification.message }}</div>\n          <div class=\"flex sender\">\n            <img\n              class=\"ownerimg lazy-image\"\n              [src]=\"\n                'https://api.anghami.com/rest/v1/GETcoverart.view?anid=' +\n                notification.anid\n              \"\n            />\n            <!-- <span class=\"px-2\">{{ notification.ownername }}</span> -->\n            <span>{{ notification.date | formatDate}}</span>\n          </div>\n        </div>\n      </a>\n    </div>\n    <div class=\"inbox-footer\"> \n      <button\n        *ngIf=\"currentNum < notificationsLst.length\"\n        class=\"my-2 anghami-default-btn\"\n        (click)=\"showMore()\"\n        i18n=\"@@more\"\n      >\n        More\n      </button>\n    </div>\n  </ng-container>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/main-search-input/main-search-input.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/main-search-input/main-search-input.component.html ***!
  \**************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"search\" #searchElement>\n  <form name=\"search-form\">\n    <div class=\"search-input-container\">\n      <div class=\"d-flex align-items-center search-box\">\n        <input #searchInput type=\"text\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\"\n          placeholder=\"Search for songs, artists, lyrics, playlists...\" i18n-placeholder=\"@@search_placeholder\"\n          [(ngModel)]=\"searchModel\" [ngModelOptions]=\"{ standalone: true }\" [ngbTypeahead]=\"typeaheadSearch\"\n          [resultTemplate]=\"rt\" #instance=\"ngbTypeahead\" [inputFormatter]=\"formatter\"  (keyup.escape)=\"close()\"\n          (keyup.enter)=\"onSearchEnter($event)\" (selectItem)=\"itemSelected($event)\" [focusFirst]=\"false\" (focus)=\"focus$.next($event.target.value)\"   (click)=\"click$.next($event.target.value)\"\n          />\n        <div class=\"search-cancel\" (click)=\"clearSearch()\" *ngIf=\"searchModel\">\n          &times;\n        </div>\n        <anghami-icon *ngIf=\"!searchLoading\" class=\"icon search-icon\" [data]=\"'search'\"\n          (click)=\"handleSearchIconClick()\"></anghami-icon>\n        <anghami-icon *ngIf=\"searchLoading\" class=\"icon search-icon\" [data]=\"'loading-search'\"></anghami-icon>\n      </div>\n    </div>\n\n    <ng-template #rt let-item=\"result\" let-t=\"term\">\n      <anghami-list-item \n        displayType=\"bigrow\" \n        type=\"genericitem\" \n        [class.unmatched]=\"item.unmatched\"\n        (listItemClickEvent)=\"itemSelected($event)\"\n        [collectionItem]=\"item\" \n        [fromSearch]=\"true\"\n        [index]=\"item.id\"\n        [fromSearchEdgeContainer]=\"true\"\n        ></anghami-list-item>\n    </ng-template>\n    <search-edge-container\n      *ngIf=\"searchEdgeContainer && searchModel.length <= 1\"\n      [searchQuery]=\"searchModel\"\n      (closeModal)=\"close()\"\n      (loadingToggle)=\"changeSearchLoading()\"\n    ></search-edge-container>\n  </form>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/search-edge-container/search-edge-container.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/search-edge-container/search-edge-container.html ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [ngClass]=\"positionClass\" class=\"search-edge-container\">\n  <ng-container *ngIf=\"searchQuery.length <= 1\">\n    <div class=\"empty-search-edge\">\n      <div class=\"search-edge-headers flex\" i18n=\"@@mood_genre\">\n        Mood & Genre\n      </div>\n      <div class=\"tag-container\">\n        <a\n          *ngFor=\"let tagItem of searchTags\"\n          class=\"tag\"\n          [routerLink]=\"['/tag/' + tagItem?.id]\"\n          >{{ tagItem.name }}</a\n        >\n      </div>\n      <div class=\"flex\" style=\"justify-content:space-between; margin-bottom:'1em'\">\n        <div class=\"search-edge-headers\" i18n=\"@@recent_searches\">\n          Recent searches\n        </div>\n        <div\n          (click)=\"clearRecentSearchDb()\"\n          class=\"clear\"\n          i18n=\"@@clear\"\n          *ngIf=\"recentSearches?.length >= 1\"\n        >\n          Clear\n        </div>\n      </div>\n      <a\n        [routerLink]=\"['/' + recentItem?.href]\"\n        class=\"recent-search-item flex-common\"\n        *ngFor=\"let recentItem of recentSearches\"\n      >\n        <anghami-icon class=\"icon off\" [data]=\"recentItem.icon\"></anghami-icon>\n        <div class=\"recent-search-item-details flex-common\">\n          <span class=\"recent-search-item-type\">\n            {{ recentItem.supertitle | translateInstant | uppercase }}\n          </span>\n          <span class=\"recent-search-item-title\">\n            {{ recentItem.title }}\n          </span>\n        </div>\n      </a>\n      <div *ngIf=\"!(recentSearches?.length >= 1)\" class=\"no-recent-search\">\n        <anghami-icon\n          class=\"icon recent-icon \"\n          [data]=\"'recent-search'\"\n        ></anghami-icon>\n        <div class=\"recent-icon\" i18n=\"@@no_recent_searches\">\n          No recent searches\n        </div>\n      </div>\n    </div>\n  </ng-container>\n\n  <!-- the below part was used when instant search was performed in search edge (kept if it might be used in the future) -->\n  <!-- <ng-container *ngIf=\"searchQuery.length > 1  && searchCompleted\">\n    <ng-container *ngIf=\"sections[0].data.length != 0\">\n      <div class=\"search-edge-results-container\">\n        <anghami-new-section-builder\n          (click)=\"destroySearchEdge(event)\"\n          [sections]=\"sections\"\n          [type]=\"'search'\"\n          [fromSearch]=\"true\"\n          [fromSearchEdgeContainer]=\"true\"\n          (onEnterKeyPress)=\"onMoreClick()\"\n        ></anghami-new-section-builder>\n      </div>\n      <div class=\"search-view-all button-view\">\n      <button class=\"anghami-default-btn\" (click)=\"onMoreClick()\" i18n=\"@@more\">\n        More\n      </button>\n    </div>\n    </ng-container>\n    <ng-container *ngIf=\"sections[0].data.length == 0\">\n      <div class=\"no-recent-search padded\">\n        <anghami-icon\n          class=\"icon recent-icon \"\n          [data]=\"'recent-search'\"\n        ></anghami-icon>\n        <div class=\"recent-icon\" i18n=\"@@No results found\">\n          No results found\n        </div>\n      </div>\n    </ng-container>\n  </ng-container> -->\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/user-navigation/user-navigation.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/user-navigation/user-navigation.component.html ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  ngbDropdown\n  class=\"user-dropdown-container\"\n  #modal=\"ngbDropdown\"\n  (openChange)=\"toggled($event)\"\n>\n  <div class=\"d-flex align-items-center profile-container\" ngbDropdownToggle>\n    <ng-container *ngIf=\"user?.anid; else anon\">\n      <div\n        class=\"profile\"\n        id=\"dropdownBasic1\"\n        [ngStyle]=\"{ 'background-image': 'url(' + user?.picture + ')' }\"\n      >\n        <div class=\"plus-badge\" *ngIf=\"isPlus\" i18n=\"@@Plus\">PLUS</div>\n      </div>\n    </ng-container>\n    <anghami-icon class=\"icon more\" [data]=\"'more'\"></anghami-icon>\n  </div>\n  <ul class=\"dropdown\" ngbDropdownMenu aria-labelledby=\"dropdownBasic1\">\n    <li class=\"user-nav\" *ngIf=\"user?.anid\">\n        <span>\n          <strong>{{ user?.fullname }}</strong>\n          <a class=\"viewprofile\" i18n=\"@@view_profile\" [href]=\"'https://play.anghami.com/profile/' + user.anid\" (click)=\"goToProfile(user.anid,$event)\">View profile</a>\n        </span>\n    </li>\n    <li class=\"sep\"></li>\n    <ng-scrollbar\n      class=\"ng-scrollbar user-nav\"\n      [shown]=\"'hover'\"\n      [compact]=\"true\"\n    >\n      <div class=\"user-nav-scrollbar\">\n        <li>\n          <a href=\"https://www.anghami.com/manage-account\" target=\"_blank\">\n            <span i18n=\"@@Manage your account\">Manage Account</span>\n          </a>\n        </li>\n        <li>\n          <a href=\"https://www.anghami.com/redeem\" target=\"_blank\">\n            <span i18n=\"@@Redeem\">Redeem</span>\n          </a>\n        </li>\n        <li>\n          <a href=\"https://www.anghami.com/artist-connect\" target=\"_blank\">\n            <span i18n=\"@@Artist Connect\">Artist Connect</span>\n          </a>\n        </li>\n\n        <li>\n          <a href=\"https://support.anghami.com/hc/{{selectedLang}}\" target=\"_blank\">\n            <span i18n=\"@@Help center\">Help Center</span>\n          </a>\n        </li>\n        <li>\n          <a href=\"https://www.anghami.com/products\" target=\"_blank\">\n            <span i18n=\"@@products\">Products</span>\n          </a>\n        </li>\n        <li class=\"sep \"></li>\n        <li class=\"action \">\n          <a [href]=\"'https://play.anghami.com/settings'\" (click)=\"goToSettings($event)\">\n            <i class=\"icon \">\n              <anghami-icon [data]=\"'settings'\"></anghami-icon>\n            </i>\n            <span i18n=\"@@settings\">Settings</span>\n          </a>\n        </li>\n        <li class=\"sep \"></li>\n        <li class=\"action \">\n          <a href=\"https://www.anghami.com/gifts\" target=\"_blank\">\n            <i class=\"icon \"> <anghami-icon [data]=\"'gift'\"></anghami-icon> </i>\n            <span i18n=\"@@buy_gift\">Buy Gift</span>\n          </a>\n        </li>\n        <li class=\"sep \"></li>\n        <ng-container *ngIf=\"isLoggedIn\">\n          <li class=\"action \" (click)=\"logout()\">\n            <a>\n              <i class=\"icon \">\n                <anghami-icon [data]=\"'logout'\"></anghami-icon>\n              </i>\n              <span i18n=\"@@Logout\">Logout</span>\n            </a>\n          </li>\n        </ng-container>\n        <ng-container *ngIf=\"!isLoggedIn\">\n          <li class=\"action\">\n            <a (click)=\"openLoginDialog()\"> <span i18n=\"@@Login\">Login</span> </a>\n          </li>\n        </ng-container>\n        <li class=\"sep \"></li>\n        <li class=\"action dark\">\n          <a>\n            <i class=\"icon\">\n              <anghami-icon [data]=\"'darkmode'\"></anghami-icon>\n            </i>\n            <span i18n=\"@@dark_mode\">Dark Mode</span>\n            <label class=\"switch\">\n              <input\n                type=\"checkbox\"\n                [checked]=\"darkmode\"\n                (click)=\"toggleDarkMode()\"\n              />\n              <span class=\"slider round\"></span>\n            </label>\n          </a>\n        </li>\n      </div>\n    </ng-scrollbar>\n  </ul>\n  <ng-template #anon>\n    <a (click)=\"openLoginDialog()\" class=\"anghami-primary-btn login-btn\">\n      <ng-container i18n=\"@@Login\">Login</ng-container>\n      |\n      <ng-container i18n=\"@@landing_signup\">Signup</ng-container>\n    </a>\n  </ng-template>\n</div>\n"

/***/ }),

/***/ "./node_modules/rxjs/internal/InnerSubscriber.js":
/*!*******************************************************!*\
  !*** ./node_modules/rxjs/internal/InnerSubscriber.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Subscriber_1 = __webpack_require__(/*! ./Subscriber */ "./node_modules/rxjs/internal/Subscriber.js");
var InnerSubscriber = (function (_super) {
    __extends(InnerSubscriber, _super);
    function InnerSubscriber(parent, outerValue, outerIndex) {
        var _this = _super.call(this) || this;
        _this.parent = parent;
        _this.outerValue = outerValue;
        _this.outerIndex = outerIndex;
        _this.index = 0;
        return _this;
    }
    InnerSubscriber.prototype._next = function (value) {
        this.parent.notifyNext(this.outerValue, value, this.outerIndex, this.index++, this);
    };
    InnerSubscriber.prototype._error = function (error) {
        this.parent.notifyError(error, this);
        this.unsubscribe();
    };
    InnerSubscriber.prototype._complete = function () {
        this.parent.notifyComplete(this);
        this.unsubscribe();
    };
    return InnerSubscriber;
}(Subscriber_1.Subscriber));
exports.InnerSubscriber = InnerSubscriber;
//# sourceMappingURL=InnerSubscriber.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/OuterSubscriber.js":
/*!*******************************************************!*\
  !*** ./node_modules/rxjs/internal/OuterSubscriber.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Subscriber_1 = __webpack_require__(/*! ./Subscriber */ "./node_modules/rxjs/internal/Subscriber.js");
var OuterSubscriber = (function (_super) {
    __extends(OuterSubscriber, _super);
    function OuterSubscriber() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    OuterSubscriber.prototype.notifyNext = function (outerValue, innerValue, outerIndex, innerIndex, innerSub) {
        this.destination.next(innerValue);
    };
    OuterSubscriber.prototype.notifyError = function (error, innerSub) {
        this.destination.error(error);
    };
    OuterSubscriber.prototype.notifyComplete = function (innerSub) {
        this.destination.complete();
    };
    return OuterSubscriber;
}(Subscriber_1.Subscriber));
exports.OuterSubscriber = OuterSubscriber;
//# sourceMappingURL=OuterSubscriber.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/symbol/iterator.js":
/*!*******************************************************!*\
  !*** ./node_modules/rxjs/internal/symbol/iterator.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function getSymbolIterator() {
    if (typeof Symbol !== 'function' || !Symbol.iterator) {
        return '@@iterator';
    }
    return Symbol.iterator;
}
exports.getSymbolIterator = getSymbolIterator;
exports.iterator = getSymbolIterator();
exports.$$iterator = exports.iterator;
//# sourceMappingURL=iterator.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/isArrayLike.js":
/*!********************************************************!*\
  !*** ./node_modules/rxjs/internal/util/isArrayLike.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isArrayLike = (function (x) { return x && typeof x.length === 'number' && typeof x !== 'function'; });
//# sourceMappingURL=isArrayLike.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/isPromise.js":
/*!******************************************************!*\
  !*** ./node_modules/rxjs/internal/util/isPromise.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isPromise(value) {
    return !!value && typeof value.subscribe !== 'function' && typeof value.then === 'function';
}
exports.isPromise = isPromise;
//# sourceMappingURL=isPromise.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/subscribeTo.js":
/*!********************************************************!*\
  !*** ./node_modules/rxjs/internal/util/subscribeTo.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var subscribeToArray_1 = __webpack_require__(/*! ./subscribeToArray */ "./node_modules/rxjs/internal/util/subscribeToArray.js");
var subscribeToPromise_1 = __webpack_require__(/*! ./subscribeToPromise */ "./node_modules/rxjs/internal/util/subscribeToPromise.js");
var subscribeToIterable_1 = __webpack_require__(/*! ./subscribeToIterable */ "./node_modules/rxjs/internal/util/subscribeToIterable.js");
var subscribeToObservable_1 = __webpack_require__(/*! ./subscribeToObservable */ "./node_modules/rxjs/internal/util/subscribeToObservable.js");
var isArrayLike_1 = __webpack_require__(/*! ./isArrayLike */ "./node_modules/rxjs/internal/util/isArrayLike.js");
var isPromise_1 = __webpack_require__(/*! ./isPromise */ "./node_modules/rxjs/internal/util/isPromise.js");
var isObject_1 = __webpack_require__(/*! ./isObject */ "./node_modules/rxjs/internal/util/isObject.js");
var iterator_1 = __webpack_require__(/*! ../symbol/iterator */ "./node_modules/rxjs/internal/symbol/iterator.js");
var observable_1 = __webpack_require__(/*! ../symbol/observable */ "./node_modules/rxjs/internal/symbol/observable.js");
exports.subscribeTo = function (result) {
    if (!!result && typeof result[observable_1.observable] === 'function') {
        return subscribeToObservable_1.subscribeToObservable(result);
    }
    else if (isArrayLike_1.isArrayLike(result)) {
        return subscribeToArray_1.subscribeToArray(result);
    }
    else if (isPromise_1.isPromise(result)) {
        return subscribeToPromise_1.subscribeToPromise(result);
    }
    else if (!!result && typeof result[iterator_1.iterator] === 'function') {
        return subscribeToIterable_1.subscribeToIterable(result);
    }
    else {
        var value = isObject_1.isObject(result) ? 'an invalid object' : "'" + result + "'";
        var msg = "You provided " + value + " where a stream was expected."
            + ' You can provide an Observable, Promise, Array, or Iterable.';
        throw new TypeError(msg);
    }
};
//# sourceMappingURL=subscribeTo.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/subscribeToArray.js":
/*!*************************************************************!*\
  !*** ./node_modules/rxjs/internal/util/subscribeToArray.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.subscribeToArray = function (array) { return function (subscriber) {
    for (var i = 0, len = array.length; i < len && !subscriber.closed; i++) {
        subscriber.next(array[i]);
    }
    subscriber.complete();
}; };
//# sourceMappingURL=subscribeToArray.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/subscribeToIterable.js":
/*!****************************************************************!*\
  !*** ./node_modules/rxjs/internal/util/subscribeToIterable.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var iterator_1 = __webpack_require__(/*! ../symbol/iterator */ "./node_modules/rxjs/internal/symbol/iterator.js");
exports.subscribeToIterable = function (iterable) { return function (subscriber) {
    var iterator = iterable[iterator_1.iterator]();
    do {
        var item = iterator.next();
        if (item.done) {
            subscriber.complete();
            break;
        }
        subscriber.next(item.value);
        if (subscriber.closed) {
            break;
        }
    } while (true);
    if (typeof iterator.return === 'function') {
        subscriber.add(function () {
            if (iterator.return) {
                iterator.return();
            }
        });
    }
    return subscriber;
}; };
//# sourceMappingURL=subscribeToIterable.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/subscribeToObservable.js":
/*!******************************************************************!*\
  !*** ./node_modules/rxjs/internal/util/subscribeToObservable.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var observable_1 = __webpack_require__(/*! ../symbol/observable */ "./node_modules/rxjs/internal/symbol/observable.js");
exports.subscribeToObservable = function (obj) { return function (subscriber) {
    var obs = obj[observable_1.observable]();
    if (typeof obs.subscribe !== 'function') {
        throw new TypeError('Provided object does not correctly implement Symbol.observable');
    }
    else {
        return obs.subscribe(subscriber);
    }
}; };
//# sourceMappingURL=subscribeToObservable.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/subscribeToPromise.js":
/*!***************************************************************!*\
  !*** ./node_modules/rxjs/internal/util/subscribeToPromise.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var hostReportError_1 = __webpack_require__(/*! ./hostReportError */ "./node_modules/rxjs/internal/util/hostReportError.js");
exports.subscribeToPromise = function (promise) { return function (subscriber) {
    promise.then(function (value) {
        if (!subscriber.closed) {
            subscriber.next(value);
            subscriber.complete();
        }
    }, function (err) { return subscriber.error(err); })
        .then(null, hostReportError_1.hostReportError);
    return subscriber;
}; };
//# sourceMappingURL=subscribeToPromise.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/subscribeToResult.js":
/*!**************************************************************!*\
  !*** ./node_modules/rxjs/internal/util/subscribeToResult.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var InnerSubscriber_1 = __webpack_require__(/*! ../InnerSubscriber */ "./node_modules/rxjs/internal/InnerSubscriber.js");
var subscribeTo_1 = __webpack_require__(/*! ./subscribeTo */ "./node_modules/rxjs/internal/util/subscribeTo.js");
var Observable_1 = __webpack_require__(/*! ../Observable */ "./node_modules/rxjs/internal/Observable.js");
function subscribeToResult(outerSubscriber, result, outerValue, outerIndex, destination) {
    if (destination === void 0) { destination = new InnerSubscriber_1.InnerSubscriber(outerSubscriber, outerValue, outerIndex); }
    if (destination.closed) {
        return undefined;
    }
    if (result instanceof Observable_1.Observable) {
        return result.subscribe(destination);
    }
    return subscribeTo_1.subscribeTo(result)(destination);
}
exports.subscribeToResult = subscribeToResult;
//# sourceMappingURL=subscribeToResult.js.map

/***/ }),

/***/ "./src/app/core/components/anghami-plus-button/anghami-plus-button.component.scss":
/*!****************************************************************************************!*\
  !*** ./src/app/core/components/anghami-plus-button/anghami-plus-button.component.scss ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  list-style-type: none;\n  display: block;\n  font-size: inherit;\n  cursor: pointer;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n  padding: 1em 0.3em;\n  text-align: center;\n  position: relative;\n  border-radius: 0.3em;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n  background: -webkit-gradient(linear, left top, right top, from(#0099f5), to(#007dc7));\n  background: linear-gradient(to right, #0099f5, #007dc7);\n}\n:host.navbar {\n  margin: -0.6em 0 0 0;\n  border-radius: 0;\n}\n:host p {\n  margin: auto;\n  font-weight: 500;\n  color: var(--white);\n}\n:host a {\n  margin-top: 1em;\n  display: block;\n  color: black !important;\n}\n:host.free {\n  color: var(--light-background);\n  background: #018af0;\n  background: -webkit-gradient(linear, left top, right top, from(#018af0), to(#92278f));\n  background: linear-gradient(to right, #018af0 0%, #92278f 100%);\n}"

/***/ }),

/***/ "./src/app/core/components/anghami-plus-button/anghami-plus-button.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/core/components/anghami-plus-button/anghami-plus-button.component.ts ***!
  \**************************************************************************************/
/*! exports provided: AnghamiPlusButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AnghamiPlusButtonComponent", function() { return AnghamiPlusButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");






var AnghamiPlusButtonComponent = /** @class */ (function () {
    function AnghamiPlusButtonComponent(store) {
        this.store = store;
        this.userLoggedIn$ = this.store.select(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_2__["getLoggedIn"]);
    }
    AnghamiPlusButtonComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.loginSubscription = this.userLoggedIn$.subscribe(function (loggedIn) {
            _this.isLoggedIn = loggedIn;
        });
        this.isFree = !this.plus && this.isLoggedIn;
        this.isFromNavbar = this.navbar;
    };
    AnghamiPlusButtonComponent.prototype.ngOnDestroy = function () {
        this.loginSubscription.unsubscribe();
    };
    AnghamiPlusButtonComponent.prototype.openLoginDialog = function (e) {
        this.store.dispatch(new _redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_4__["OpenCustomDialog"]({
            type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_5__["DIALOG_TYPES"].LOGIN
        }));
        e.preventDefault();
        return;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('plus'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], AnghamiPlusButtonComponent.prototype, "plus", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('navbar'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], AnghamiPlusButtonComponent.prototype, "navbar", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class.free'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], AnghamiPlusButtonComponent.prototype, "isFree", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class.navbar'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], AnghamiPlusButtonComponent.prototype, "isFromNavbar", void 0);
    AnghamiPlusButtonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-plus-button',
            template: "\n    <ng-container *ngIf=\"!plus && (userLoggedIn$ | async)\">\n      <p i18n=\"@@enjoy_adfree\">Enjoy Anghami Ad Free</p>\n  <anghami-button\n  label='subscribe'\n  link='https://www.anghami.com/plus'\n  layout='purple_gradient'\n  target='_blank'\n  size='narrow'\n></anghami-button>\n    </ng-container>\n\n    <ng-container *ngIf=\"plus && (userLoggedIn$ | async)\">\n\n    <anghami-button\n  label='manageAccount'\n  link='https://www.anghami.com/manage-account'\n  layout='white'\n  target='_blank'\n  size = 'narrow'\n\n></anghami-button>\n\n    </ng-container>\n\n    <ng-container *ngIf=\"!(userLoggedIn$ | async)\">\n      <p\n        i18n=\"@@sidebar_login\n      \"\n      >\n        Login to keep enjoying music\n      </p>\n\n\n  <anghami-button\n  label='login'\n  class=\"mt-2 mb-1\"\n  link=''\n  layout='white'\n  target=''\n  size='narrow'\n\n  (click)='openLoginDialog($event)'\n></anghami-button>\n    </ng-container>\n  ",
            styles: [__webpack_require__(/*! ./anghami-plus-button.component.scss */ "./src/app/core/components/anghami-plus-button/anghami-plus-button.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"]])
    ], AnghamiPlusButtonComponent);
    return AnghamiPlusButtonComponent;
}());



/***/ }),

/***/ "./src/app/core/components/anghami-plus-button/anghami-plus-button.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/core/components/anghami-plus-button/anghami-plus-button.module.ts ***!
  \***********************************************************************************/
/*! exports provided: AnghamiPlusButtonModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AnghamiPlusButtonModule", function() { return AnghamiPlusButtonModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _anghami_plus_button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./anghami-plus-button.component */ "./src/app/core/components/anghami-plus-button/anghami-plus-button.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _button_button_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../button/button.module */ "./src/app/core/components/button/button.module.ts");






var AnghamiPlusButtonModule = /** @class */ (function () {
    function AnghamiPlusButtonModule() {
    }
    AnghamiPlusButtonModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"], _button_button_module__WEBPACK_IMPORTED_MODULE_5__["ButtonModule"]],
            declarations: [_anghami_plus_button_component__WEBPACK_IMPORTED_MODULE_3__["AnghamiPlusButtonComponent"]],
            exports: [_anghami_plus_button_component__WEBPACK_IMPORTED_MODULE_3__["AnghamiPlusButtonComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], AnghamiPlusButtonModule);
    return AnghamiPlusButtonModule;
}());



/***/ }),

/***/ "./src/app/core/components/button/button-labels.enum.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button-labels.enum.ts ***!
  \**************************************************************/
/*! exports provided: ButtonLabelsEN, ButtonLabelsFR, ButtonLabelsAR */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsEN", function() { return ButtonLabelsEN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsFR", function() { return ButtonLabelsFR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsAR", function() { return ButtonLabelsAR; });
var ButtonLabelsEN;
(function (ButtonLabelsEN) {
    ButtonLabelsEN["learnMore"] = "Learn more";
    ButtonLabelsEN["sendGift"] = "Send gift";
    ButtonLabelsEN["goToHelpCenter"] = "Go to help center";
    ButtonLabelsEN["getAnghamiPlus"] = "Get Anghami Plus";
    ButtonLabelsEN["giftAnghamiPlus"] = "Gift Anghami Plus";
    ButtonLabelsEN["login"] = "Login";
    ButtonLabelsEN["manageAccount"] = "Manage Account";
    ButtonLabelsEN["subscribe"] = "Subscribe";
    ButtonLabelsEN["weAreHiring"] = "We're hiring";
    ButtonLabelsEN["haveApp"] = "Continue in app";
})(ButtonLabelsEN || (ButtonLabelsEN = {}));
var ButtonLabelsFR;
(function (ButtonLabelsFR) {
    ButtonLabelsFR["learnMore"] = "Renseignez - vous";
    ButtonLabelsFR["sendGift"] = "Envoyer un cadeau";
    ButtonLabelsFR["goToHelpCenter"] = "Aller au centre d'aide";
    ButtonLabelsFR["getAnghamiPlus"] = "Obtiens Anghami Plus";
    ButtonLabelsFR["giftAnghamiPlus"] = "Offrez Anghami Plus";
    ButtonLabelsFR["subscribe"] = "S'abonner";
    ButtonLabelsFR["login"] = "Connexion";
    ButtonLabelsFR["manageAccount"] = "Gestion du compte";
    ButtonLabelsFR["weAreHiring"] = "Nous recrutons";
    ButtonLabelsFR["haveApp"] = "Continuer depuis l'appli";
})(ButtonLabelsFR || (ButtonLabelsFR = {}));
var ButtonLabelsAR;
(function (ButtonLabelsAR) {
    ButtonLabelsAR["learnMore"] = "\u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0645\u0632\u064A\u062F";
    ButtonLabelsAR["sendGift"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u062A\u0643";
    ButtonLabelsAR["goToHelpCenter"] = "\u0627\u0630\u0647\u0628 \u0627\u0644\u0649 \u0642\u0633\u0645 \u0627\u0644\u0645\u0633\u0627\u0639\u062F\u0629";
    ButtonLabelsAR["getAnghamiPlus"] = "\u0625\u062D\u0635\u0644 \u0639\u0644\u0649 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u0633";
    ButtonLabelsAR["giftAnghamiPlus"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u0629 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u064E\u0633";
    ButtonLabelsAR["subscribe"] = "\u0627\u0634\u062A\u0631\u0643";
    ButtonLabelsAR["login"] = "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644";
    ButtonLabelsAR["manageAccount"] = "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u062D\u0633\u0627\u0628";
    ButtonLabelsAR["weAreHiring"] = "\u0646\u0648\u0638\u0651\u0641 \u0627\u0644\u0622\u0646!";
    ButtonLabelsAR["haveApp"] = "\u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0645\u0646 \u0627\u0644\u062A\u0637\u0628\u064A\u0642";
})(ButtonLabelsAR || (ButtonLabelsAR = {}));


/***/ }),

/***/ "./src/app/core/components/button/button.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: inline-block;\n}\n:host a {\n  text-decoration: none;\n  cursor: pointer;\n  color: #FFF;\n  padding: 1.2em 2.5em;\n  border-radius: 3em;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n  display: inline-block;\n}\n:host a.narrow {\n  padding: 0.8em 2.5em;\n}\n:host a .spinner-border {\n  width: 1.5rem;\n  height: 1.5rem;\n  vertical-align: middle;\n  margin-top: -0.1em;\n}\n:host a.loading {\n  padding: 1.2em 4em;\n}\n:host a.purple_gradient {\n  background-image: -webkit-gradient(linear, left top, right top, from(#e1418c), color-stop(#d6379b), color-stop(#c732ab), color-stop(#b035bc), to(#913ccd));\n  background-image: linear-gradient(to right, #e1418c, #d6379b, #c732ab, #b035bc, #913ccd);\n}\n:host a.white {\n  background: #FFF;\n  color: #000;\n}\n:host a.blue_gradient {\n  background: -webkit-gradient(linear, left top, right top, from(#0093fe), to(#5fd2cb));\n  background: linear-gradient(90deg, #0093fe 0%, #5fd2cb 100%);\n}\n:host a.purple {\n  background: #8d00f2;\n}\n:host a.blue {\n  background: #007ffe;\n  background: -webkit-gradient(linear, left top, right top, from(#007ffe), to(#01b5ff));\n  background: linear-gradient(90deg, #007ffe 0%, #01b5ff 100%);\n}\n:host:hover a:not(.loading) {\n  -webkit-transform: translateY(-2px);\n      -ms-transform: translateY(-2px);\n          transform: translateY(-2px);\n  opacity: 0.9;\n  box-shadow: 0px 3px 5px 0px rgba(0, 0, 0, 0.24);\n}"

/***/ }),

/***/ "./src/app/core/components/button/button.component.ts":
/*!************************************************************!*\
  !*** ./src/app/core/components/button/button.component.ts ***!
  \************************************************************/
/*! exports provided: ButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonComponent", function() { return ButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button-labels.enum */ "./src/app/core/components/button/button-labels.enum.ts");




var ButtonComponent = /** @class */ (function () {
    function ButtonComponent(router, locale) {
        this.router = router;
        this.locale = locale;
        this.label = '';
        this.layout = '';
        this.loading = false;
        this.link = '';
        this.target = '';
        this.size = '';
        this.hidden = false;
    }
    ButtonComponent.prototype.ngOnInit = function () {
        if (!this.label.length) {
            this.hidden = true;
        }
        var pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsEN"];
        if (this.locale === "ar") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsAR"];
        }
        else if (this.locale === "fr") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsFR"];
        }
        this.label_locale = pack[this.label] || this.label;
    };
    ButtonComponent.prototype.clickHandler = function (e) {
        if (this.target === "router") {
            e.preventDefault();
            this.router.navigateByUrl(this.link);
        }
        if (this.target === "none") {
            e.preventDefault();
            return;
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "label", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "layout", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], ButtonComponent.prototype, "loading", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "link", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "target", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "size", void 0);
    ButtonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-button',
            template: __webpack_require__(/*! raw-loader!./button.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html"),
            styles: [__webpack_require__(/*! ./button.component.scss */ "./src/app/core/components/button/button.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], String])
    ], ButtonComponent);
    return ButtonComponent;
}());



/***/ }),

/***/ "./src/app/core/components/button/button.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/components/button/button.module.ts ***!
  \*********************************************************/
/*! exports provided: ButtonModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonModule", function() { return ButtonModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button.component */ "./src/app/core/components/button/button.component.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");





var ButtonModule = /** @class */ (function () {
    function ButtonModule() {
    }
    ButtonModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateModule"]],
            declarations: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
            exports: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]],
        })
    ], ButtonModule);
    return ButtonModule;
}());



/***/ }),

/***/ "./src/app/core/components/download-app/download-app.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/download-app/download-app.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  cursor: pointer;\n  display: inline-block;\n}\n:host .onboarding {\n  background-color: #8d00f2;\n  color: #fff !important;\n  border-radius: 1.375rem !important;\n  box-shadow: none !important;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  border: none;\n  width: 14rem;\n  height: 2.75rem;\n  margin-top: 2rem;\n}\n:host:not(.footer) {\n  margin: 0 0.5em;\n}\n:host.footer {\n  margin: 1em 0;\n}\n:host button {\n  margin: 0;\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n  border: none;\n  background: none;\n  min-width: 11.5em;\n}\n:host button.link {\n  color: white;\n  box-shadow: none;\n  padding: 0;\n  font-weight: 700;\n}\n:host button.link.solid {\n  color: var(--text-color);\n}\n:host button:not(.link) {\n  box-shadow: inset 0 0 0 1px var(--text-color);\n  color: var(--text-color);\n  border-radius: 3em;\n}\n:host button.header {\n  font-size: 1em;\n  box-shadow: inset 0 0 0 1px var(--brand-purple);\n  color: var(--brand-purple);\n}"

/***/ }),

/***/ "./src/app/core/components/download-app/download-app.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/download-app/download-app.component.ts ***!
  \************************************************************************/
/*! exports provided: DownloadAppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadAppComponent", function() { return DownloadAppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _anghami_services_desktop_client_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/desktop-client.service */ "./src/app/core/services/desktop-client.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../app/core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _refrences_WindowRef__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../refrences/WindowRef */ "./src/app/core/refrences/WindowRef.ts");








var DownloadAppComponent = /** @class */ (function () {
    function DownloadAppComponent(element, window, store, desktopClientService, platformId) {
        this.element = element;
        this.window = window;
        this.store = store;
        this.desktopClientService = desktopClientService;
        this.platformId = platformId;
    }
    DownloadAppComponent.prototype.ngOnInit = function () {
        if (!this.window.nativeWindow ||
            !this.window.nativeWindow.navigator ||
            this.desktopClientService.isDesktopClient) {
            this.os = null;
            return;
        }
        this.os = this.getOSName();
    };
    DownloadAppComponent.prototype.ngAfterViewInit = function () {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            if (this.type === 'footer') {
                this.element.nativeElement.classList.add(this.type);
            }
            if (this.type !== 'link' && this.button && this.button.nativeElement) {
                this.button.nativeElement.classList.add('btn');
                this.button.nativeElement.classList.add('primary');
            }
            if (this.button && this.button.nativeElement) {
                this.button.nativeElement.classList.add(this.type);
            }
        }
    };
    DownloadAppComponent.prototype.getOSName = function () {
        return this.window.nativeWindow.navigator.userAgent.indexOf('Windows') !== -1
            ? 'windows'
            : this.window.nativeWindow.navigator.userAgent.indexOf('Mac') !== -1
                ? 'mac'
                : null;
    };
    DownloadAppComponent.prototype.downloadDesktopApp = function () {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
            name: _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_6__["AmplitudeEvents"].downloadDesktopApp,
            props: { os: this.os, source: this.onboarding ? 'onboarding' : 'other' }
        }));
        this.window.nativeWindow.open("/download");
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], DownloadAppComponent.prototype, "type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], DownloadAppComponent.prototype, "solid", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], DownloadAppComponent.prototype, "onboarding", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"])('button', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"])
    ], DownloadAppComponent.prototype, "button", void 0);
    DownloadAppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'anghami-download-app',
            template: __webpack_require__(/*! raw-loader!./download-app.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/download-app/download-app.component.html"),
            styles: [__webpack_require__(/*! ./download-app.component.scss */ "./src/app/core/components/download-app/download-app.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"],
            _refrences_WindowRef__WEBPACK_IMPORTED_MODULE_7__["WindowRef"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
            _anghami_services_desktop_client_service__WEBPACK_IMPORTED_MODULE_2__["DesktopClientService"],
            Object])
    ], DownloadAppComponent);
    return DownloadAppComponent;
}());



/***/ }),

/***/ "./src/app/core/components/download-app/download-app.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/download-app/download-app.module.ts ***!
  \*********************************************************************/
/*! exports provided: DownloadAppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadAppModule", function() { return DownloadAppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _download_app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./download-app.component */ "./src/app/core/components/download-app/download-app.component.ts");




var DownloadAppModule = /** @class */ (function () {
    function DownloadAppModule() {
    }
    DownloadAppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
            declarations: [_download_app_component__WEBPACK_IMPORTED_MODULE_3__["DownloadAppComponent"]],
            exports: [_download_app_component__WEBPACK_IMPORTED_MODULE_3__["DownloadAppComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], DownloadAppModule);
    return DownloadAppModule;
}());



/***/ }),

/***/ "./src/app/core/components/header/header.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/core/components/header/header.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: block;\n  padding: 0 1em;\n  height: 4em;\n  box-sizing: border-box;\n  background: var(--light-background);\n  border-bottom: 1px solid var(--app-borders);\n  position: fixed;\n  top: 0;\n  left: 7em;\n  right: 0;\n  z-index: 1004;\n}\n:host .desktop-navigation-container {\n  -webkit-app-region: no-drag;\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  margin: 0 1em;\n}\n:host .desktop-navigation-container button {\n  font-size: 0.8em;\n  cursor: pointer;\n  background: none;\n  border: none;\n  color: var(--text-color) !important;\n}\n:host .desktop-navigation-container button .rotate-180 ::ng-deep svg {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n:host .desktop-navigation-container button.disabled {\n  color: var(--text-color-light) !important;\n  opacity: 0.5;\n}\n.header-search {\n  max-width: 40em;\n  min-width: 20em;\n  margin-left: 0em;\n  margin-right: 3em;\n}\n.header-actions div {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0 0.5em;\n}\n.header-actions .icon {\n  color: var(--text-color);\n}\n.header-actions .inbox {\n  font-size: 1em;\n  position: relative;\n}\n.header-actions .inbox .dot {\n  width: 0.5em;\n  height: 0.5em;\n  background: var(--brand-purple);\n  border-radius: 50%;\n  position: absolute;\n  top: 0.95em;\n  left: 1.15em;\n}\n.inbox {\n  font-size: 1em;\n  position: relative;\n}\n.inbox .dot {\n  width: 0.5em;\n  height: 0.5em;\n  background: var(--brand-purple);\n  border-radius: 50%;\n  position: absolute;\n  top: -0.1em;\n}\n.header-container {\n  display: block;\n  height: 100%;\n  width: 100%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n}\n.header-container .logo {\n  width: 9em;\n  min-width: 9em;\n  height: 100%;\n  position: relative;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  background-image: var(--brand-logo);\n  background-repeat: no-repeat;\n  background-size: contain;\n  background-position-y: center;\n}\n::ng-deep .notif-sheet {\n  max-width: 40em;\n  left: 2.25em !important;\n  top: 0.2em !important;\n}\n::ng-deep .notif-sheet .popover-body {\n  width: 33em;\n  padding: 0 !important;\n  box-shadow: 0px 0px 6px #00000029;\n}\n::ng-deep .notif-sheet .arrow:after {\n  border-bottom-color: var(--light-gray) !important;\n}\n::ng-deep .discover-sheet .arrow:after {\n  border-bottom-color: var(--light-gray) !important;\n}\n::ng-deep .more-contextsheet {\n  max-width: 40em;\n  left: 50% !important;\n}\n::ng-deep .more-contextsheet .popover-body {\n  min-width: 15em;\n  width: unset;\n  padding: 0 !important;\n}\n::ng-deep .more-contextsheet .arrow:after {\n  border-bottom-color: var(--light-gray) !important;\n}\n.notif-context {\n  display: table !important;\n  height: 100%;\n  margin: 0 !important;\n}\n.notif-context .icon {\n  vertical-align: middle;\n  border-radius: 50%;\n  -webkit-transition: fill, color, background-color 200ms linear;\n  transition: fill, color, background-color 200ms linear;\n  cursor: pointer;\n}\n.notif-context .icon:hover, .notif-context .icon.highlighted {\n  color: var(--brand-purple);\n  fill: var(--brand-purple);\n}\n.backdrop {\n  content: \"\";\n  position: fixed;\n  top: 4em;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: rgba(0, 0, 0, 0.5);\n  width: 100vw;\n  height: 100vh;\n  opacity: 1;\n  -webkit-animation-name: fadeInOpacity;\n          animation-name: fadeInOpacity;\n  -webkit-animation-iteration-count: 1;\n          animation-iteration-count: 1;\n  -webkit-animation-timing-function: ease-in;\n          animation-timing-function: ease-in;\n  -webkit-animation-duration: 0.07s;\n          animation-duration: 0.07s;\n}\n@-webkit-keyframes fadeInOpacity {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@keyframes fadeInOpacity {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\nhtml[lang=ar] :host {\n  left: 0;\n  right: 7em;\n}\nhtml[lang=ar] :host .desktop-navigation-container {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: reverse;\n      -ms-flex-direction: row-reverse;\n          flex-direction: row-reverse;\n}\nhtml[lang=ar] :host ::ng-deep .arrow {\n  left: 2.3em !important;\n  right: auto !important;\n}\nhtml[lang=ar] :host ::ng-deep .notif-sheet {\n  left: 30em !important;\n}\nhtml[lang=ar] :host .header-search {\n  margin-right: 0em;\n  margin-left: 3em;\n}\n/****Popover override****/\n/**Push the popover to the center instead of the edge.**/\n.popover.top-right {\n  margin-left: 5px;\n  margin-top: -15px;\n}\n/**Push the popover to the center instead of the edge.**/\n.popover.top-left {\n  margin-left: -5px;\n  margin-top: -15px;\n}\n/**Push the popover to the center instead of the edge.**/\n.popover.bottom-right {\n  margin-left: 5px;\n  margin-top: 15px;\n}\n/**Push the popover to the center instead of the edge.**/\n.popover.bottom-left {\n  margin-left: -5px;\n  margin-top: 15px;\n}\n.follow-dot {\n  top: 0 !important;\n}"

/***/ }),

/***/ "./src/app/core/components/header/header.component.ts":
/*!************************************************************!*\
  !*** ./src/app/core/components/header/header.component.ts ***!
  \************************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/search.actions */ "./src/app/core/redux/actions/search.actions.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_services_desktop_client_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/desktop-client.service */ "./src/app/core/services/desktop-client.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _anghami_redux_actions_follow_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/actions/follow.actions */ "./src/app/core/redux/actions/follow.actions.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");











var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(store, _authService, desktopClientService, _actionSubject, platformId) {
        var _this = this;
        this.store = store;
        this._authService = _authService;
        this.desktopClientService = desktopClientService;
        this._actionSubject = _actionSubject;
        this.platformId = platformId;
        this.role = "ang-header";
        this.isDesktopClient = window["desktopClient"];
        this.showFollowNotification = false;
        this.isPlatformBrowser = Object(_angular_common__WEBPACK_IMPORTED_MODULE_7__["isPlatformBrowser"])(this.platformId);
        this.store.dispatch(new _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_1__["LoadSearchTags"]());
        // Actions bellow get information for discover page/tab
        if (this._authService.isUserLoggedIn()) {
            this.store.dispatch(new _anghami_redux_actions_follow_actions__WEBPACK_IMPORTED_MODULE_8__["GetFollowRequests"]({}));
            this.store.dispatch(new _anghami_redux_actions_follow_actions__WEBPACK_IMPORTED_MODULE_8__["GetSuggestedFollowersList"]({}));
            this.followNotificationSub$ = this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_follow_actions__WEBPACK_IMPORTED_MODULE_8__["FriendsRequestActionTypes"].ShowFollowerNotification))
                .subscribe(function (res) {
                _this.showFollowNotification = true;
            });
        }
    }
    HeaderComponent.prototype.ngOnDestroy = function () {
        if (this.followNotificationSub$) {
            this.followNotificationSub$.unsubscribe();
        }
    };
    HeaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.isloggedin = this._authService.isUserLoggedIn();
        if (this.isDesktopClient) {
            this.desktopClientService.navigationRelay.subscribe(function (message) {
                _this.navigationState = message;
            });
        }
    };
    HeaderComponent.prototype.onNavigationClick = function (direction) {
        this.desktopClientService.emitMessageToDesktopClient("navigate", {
            direction: direction
        });
    };
    HeaderComponent.prototype.closePopover = function (p) {
        p.close();
    };
    HeaderComponent.prototype.openDiscoverPopover = function () {
        if (this.showFollowNotification == true) {
            this.showFollowNotification = false;
        }
        if (!this.discoverPopoverShown) {
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_9__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_10__["AmplitudeEvents"].openFriendsRequestTab
            }));
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["HostBinding"])("id"),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], HeaderComponent.prototype, "role", void 0);
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: "anghami-header",
            template: __webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.scss */ "./src/app/core/components/header/header.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"],
            _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"],
            _anghami_services_desktop_client_service__WEBPACK_IMPORTED_MODULE_3__["DesktopClientService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_6__["ActionsSubject"],
            Object])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/core/components/header/header.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/components/header/header.module.ts ***!
  \*********************************************************/
/*! exports provided: HeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderModule", function() { return HeaderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _main_search_input_main_search_input_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../main-search-input/main-search-input.module */ "./src/app/core/components/main-search-input/main-search-input.module.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _components_inbox_sheet_inbox_sheet_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/inbox-sheet/inbox-sheet.module */ "./src/app/core/components/inbox-sheet/inbox-sheet.module.ts");
/* harmony import */ var _components_user_navigation_user_navigation_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/user-navigation/user-navigation.module */ "./src/app/core/components/user-navigation/user-navigation.module.ts");
/* harmony import */ var _header_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./header.component */ "./src/app/core/components/header/header.component.ts");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _components_download_app_download_app_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../components/download-app/download-app.module */ "./src/app/core/components/download-app/download-app.module.ts");
/* harmony import */ var _components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");
/* harmony import */ var _discover_discover_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../discover/discover.module */ "./src/app/core/components/discover/discover.module.ts");
/* harmony import */ var _anghami_services_search_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/services/search.service */ "./src/app/core/services/search.service.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _anghami_redux_effects_db_effects__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @anghami/redux/effects/db.effects */ "./src/app/core/redux/effects/db.effects.ts");


















var HeaderModule = /** @class */ (function () {
    function HeaderModule() {
    }
    HeaderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"],
                _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_7__["IconModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbDropdownModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbTypeaheadModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModule"],
                _components_inbox_sheet_inbox_sheet_module__WEBPACK_IMPORTED_MODULE_8__["InboxSheetModule"],
                _components_user_navigation_user_navigation_module__WEBPACK_IMPORTED_MODULE_9__["UserNavigationModule"],
                _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_11__["PipesModule"],
                _components_download_app_download_app_module__WEBPACK_IMPORTED_MODULE_12__["DownloadAppModule"],
                _components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_13__["NewSectionBuilderModule"],
                _discover_discover_module__WEBPACK_IMPORTED_MODULE_14__["DiscoverModule"],
                _main_search_input_main_search_input_module__WEBPACK_IMPORTED_MODULE_1__["MainSearchInputModule"],
                _ngrx_effects__WEBPACK_IMPORTED_MODULE_16__["EffectsModule"].forFeature([
                    _anghami_redux_effects_db_effects__WEBPACK_IMPORTED_MODULE_17__["DBEffects"],
                ])
            ],
            declarations: [
                _header_component__WEBPACK_IMPORTED_MODULE_10__["HeaderComponent"],
            ],
            exports: [_header_component__WEBPACK_IMPORTED_MODULE_10__["HeaderComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["CUSTOM_ELEMENTS_SCHEMA"]],
            providers: [_anghami_services_search_service__WEBPACK_IMPORTED_MODULE_15__["SearchService"]]
        })
    ], HeaderModule);
    return HeaderModule;
}());



/***/ }),

/***/ "./src/app/core/components/inbox-sheet/inbox-sheet.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/core/components/inbox-sheet/inbox-sheet.component.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".notif-container {\n  max-height: 30em;\n  overflow: auto;\n  min-height: 15em;\n}\n.notif-container.loading {\n  min-height: 4em;\n}\n.header {\n  background-color: var(--light-gray);\n  padding: 0.5em 1em;\n  font-size: 1.2em;\n  font-weight: 600;\n  border-top-left-radius: 0.3em;\n  border-top-right-radius: 0.3em;\n}\n.coverart {\n  max-width: 3.5em;\n  border-radius: 0.3em;\n}\n.title {\n  font-size: 1em;\n  font-weight: 600;\n  line-height: 1.5em;\n  margin-bottom: 0.2em;\n}\n.message {\n  font-size: 0.8em;\n  color: var(--inbox-message);\n}\n.sender {\n  font-size: 0.8em;\n  padding-top: 0.3em;\n  width: 100%;\n}\n.sender span {\n  color: var(--date-info);\n}\n.icon.more svg {\n  fill: color(--alternate-purple);\n}\n.ownerimg {\n  border-radius: 15%;\n  width: 1.5em;\n  height: 1.5em;\n  margin-right: 0.8em;\n}\n.lazy-image {\n  background-size: 100em;\n  position: relative;\n  background: -webkit-gradient(linear, left top, right top, color-stop(10%, #eeeeee), color-stop(18%, #dddddd), color-stop(33%, #eeeeee));\n  background: linear-gradient(to right, #eeeeee 10%, #dddddd 18%, #eeeeee 33%);\n}\na {\n  color: inherit;\n  text-decoration: none;\n  padding: 0.75em 1em;\n  width: 100%;\n}\na:hover {\n  border-radius: 0.3em;\n  box-shadow: var(--track-shadow);\n  background: var(--track-hover);\n}\nimg {\n  width: 100%;\n}\n.loader {\n  height: 3em;\n  margin: auto;\n  display: block;\n  position: relative !important;\n  top: unset !important;\n  left: unset !important;\n}\n.loader ::ng-deep .lds-ellipsis {\n  display: block;\n  height: 100%;\n  margin: auto;\n  width: 4.5em;\n}\n.loader ::ng-deep .lds-ellipsis div {\n  background: -webkit-gradient(linear, left top, right top, from(#e1418c), to(#913ccd)) !important;\n  background: linear-gradient(to right, #e1418c, #913ccd) !important;\n  top: 1.5em !important;\n}\n.inbox-footer {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}"

/***/ }),

/***/ "./src/app/core/components/inbox-sheet/inbox-sheet.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/core/components/inbox-sheet/inbox-sheet.component.ts ***!
  \**********************************************************************/
/*! exports provided: InboxSheetComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InboxSheetComponent", function() { return InboxSheetComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");











var InboxSheetComponent = /** @class */ (function () {
    function InboxSheetComponent(store, _actionSubject, platformId, router) {
        var _this = this;
        this.store = store;
        this._actionSubject = _actionSubject;
        this.platformId = platformId;
        this.router = router;
        this.closeModal = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.loading = true;
        setTimeout(function () {
            _this.detectNavigation();
        });
    }
    InboxSheetComponent.prototype.ngOnDestroy = function () {
        if (this.sub$) {
            this.sub$.unsubscribe();
        }
        if (this.routeSub$) {
            this.routeSub$.unsubscribe();
        }
    };
    InboxSheetComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (!Object(_angular_common__WEBPACK_IMPORTED_MODULE_9__["isPlatformBrowser"])(this.platformId)) {
            return;
        }
        this.currentNum = 20;
        this.notificationsLst = [];
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_7__["AmplitudeEvents"].openInbox
        }));
        this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_3__["GetUserInbox"]());
        this.sub$ = this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_3__["AuthActionTypes"].GetUserInboxSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(function (action) {
            if (action && action.payload && action.payload != null) {
                _this.loading = false;
                _this.notificationsLst = action.payload.sections;
            }
        });
        if (this.scrollTarget) {
            this.scroll$ = Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["merge"])(Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["fromEvent"])(window, 'scroll'), Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["fromEvent"])(this.scrollTarget.nativeElement, 'scroll'));
        }
        else {
            this.scroll$ = Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["fromEvent"])(window, 'scroll');
        }
    };
    InboxSheetComponent.prototype.showMore = function () {
        var _this = this;
        // so that we are not deleteing the button in its own click event (when we reach the last batch)
        setTimeout(function () {
            _this.currentNum += 20;
        });
    };
    InboxSheetComponent.prototype.detectNavigation = function () {
        var _this = this;
        this.routeSub$ = this.router.events.subscribe(function (val) {
            if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_10__["NavigationStart"]) {
                _this.destroyPopover();
            }
        });
    };
    InboxSheetComponent.prototype.destroyPopover = function () {
        this.closeModal.emit();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('scrollTarget', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], InboxSheetComponent.prototype, "scrollTarget", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InboxSheetComponent.prototype, "closeModal", void 0);
    InboxSheetComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-inbox-sheet',
            template: __webpack_require__(/*! raw-loader!./inbox-sheet.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/inbox-sheet/inbox-sheet.component.html"),
            styles: [__webpack_require__(/*! ./inbox-sheet.component.scss */ "./src/app/core/components/inbox-sheet/inbox-sheet.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
            Object,
            _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"]])
    ], InboxSheetComponent);
    return InboxSheetComponent;
}());



/***/ }),

/***/ "./src/app/core/components/inbox-sheet/inbox-sheet.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/core/components/inbox-sheet/inbox-sheet.module.ts ***!
  \*******************************************************************/
/*! exports provided: InboxSheetModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InboxSheetModule", function() { return InboxSheetModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _inbox_sheet_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./inbox-sheet.component */ "./src/app/core/components/inbox-sheet/inbox-sheet.component.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _icon_icon_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _loading_loading_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");










var InboxSheetModule = /** @class */ (function () {
    function InboxSheetModule() {
    }
    InboxSheetModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModule"], _icon_icon_module__WEBPACK_IMPORTED_MODULE_6__["IconModule"], _loading_loading_module__WEBPACK_IMPORTED_MODULE_7__["LoadingModule"], ng_lazyload_image__WEBPACK_IMPORTED_MODULE_8__["LazyLoadImageModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__["PipesModule"]],
            declarations: [_inbox_sheet_component__WEBPACK_IMPORTED_MODULE_4__["InboxSheetComponent"]],
            exports: [_inbox_sheet_component__WEBPACK_IMPORTED_MODULE_4__["InboxSheetComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]],
            providers: []
        })
    ], InboxSheetModule);
    return InboxSheetModule;
}());



/***/ }),

/***/ "./src/app/core/components/main-search-input/main-search-input.component.scss":
/*!************************************************************************************!*\
  !*** ./src/app/core/components/main-search-input/main-search-input.component.scss ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .search {\n  margin: 0 2em;\n  max-width: 25em;\n  min-width: 20em;\n  width: 100%;\n  position: relative;\n}\n:host .search form {\n  display: block;\n}\n:host .search form .search-box {\n  border: 1px solid var(--search-border);\n  border-radius: 2em;\n  width: 100%;\n  background-color: var(--search-background);\n}\n:host .search form .search-icon {\n  padding: 0 1em;\n  cursor: pointer;\n  color: var(--search-color);\n}\n:host .search form .search-icon ::ng-deep svg {\n  width: 1.1em !important;\n  height: 1.1em !important;\n}\n:host .search form input[type=text] {\n  display: block;\n  max-width: 30em;\n  border-radius: 2em;\n  background: var(--search-background);\n  border: none;\n  padding: 0.5em 1em 0.3em 1em;\n  width: 100%;\n  max-width: 25em;\n  outline: none;\n  font-weight: normal;\n  color: var(--text-color);\n}\n:host .search form input[type=text]::-webkit-input-placeholder {\n  font-weight: normal;\n  color: var(--search-placeholder);\n}\n:host .search form input[type=text]::-moz-placeholder {\n  font-weight: normal;\n  color: var(--search-placeholder);\n}\n:host .search form input[type=text]:-ms-input-placeholder {\n  font-weight: normal;\n  color: var(--search-placeholder);\n}\n:host .search form input[type=text]::-ms-input-placeholder {\n  font-weight: normal;\n  color: var(--search-placeholder);\n}\n:host .search form input[type=text]::placeholder {\n  font-weight: normal;\n  color: var(--search-placeholder);\n}\n:host .search .search-input-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .search .search-input-container input {\n  display: inline-block;\n}\n:host .search .search-input-container .search-cancel {\n  position: relative;\n  right: 0;\n  cursor: pointer;\n}\n:host input[type=search]::-webkit-search-cancel-button {\n  -webkit-appearance: none;\n}"

/***/ }),

/***/ "./src/app/core/components/main-search-input/main-search-input.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/core/components/main-search-input/main-search-input.component.ts ***!
  \**********************************************************************************/
/*! exports provided: MainSearchInputComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainSearchInputComponent", function() { return MainSearchInputComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/db.actions */ "./src/app/core/redux/actions/db.actions.ts");
/* harmony import */ var _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/search.actions */ "./src/app/core/redux/actions/search.actions.ts");
/* harmony import */ var _anghami_redux_selectors_search_selector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/selectors/search.selector */ "./src/app/core/redux/selectors/search.selector.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _anghami_services_search_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/search.service */ "./src/app/core/services/search.service.ts");
/* harmony import */ var _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../modules/player/actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");














var MainSearchInputComponent = /** @class */ (function () {
    function MainSearchInputComponent(store, router, utilityService, cdr, searchService, platformId) {
        var _this = this;
        this.store = store;
        this.router = router;
        this.utilityService = utilityService;
        this.cdr = cdr;
        this.searchService = searchService;
        this.platformId = platformId;
        this.showSearch = false;
        this.searchEdgeContainer = false;
        this.searchModel = '';
        this.isDesktopClient = window['desktopClient'];
        this.searchLoading = false;
        this.focus$ = new rxjs__WEBPACK_IMPORTED_MODULE_8__["Subject"]();
        this.click$ = new rxjs__WEBPACK_IMPORTED_MODULE_8__["Subject"]();
        // function used by ngbtypeahead, to perform live search
        this.typeaheadSearch = function (text$) {
            var debouncedText$ = text$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["debounceTime"])(100), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["distinctUntilChanged"])());
            var clicksWithClosedPopup$ = _this.click$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["filter"])(function () { return !_this.instance.isPopupOpen(); }));
            var inputFocus$ = _this.focus$;
            // merge search term change + input click + focus
            // on event, perform search if term exist, and open search edge if no
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["merge"])(debouncedText$, inputFocus$, clicksWithClosedPopup$)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["tap"])(function () { return _this.searchLoading = true; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["switchMap"])(function (term) { return term === '' ? rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"].defer(function () { return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"].of(_this.openSearchEdge()); }) :
                _this.searchService
                    .getEdgeSearchResults({
                    query: term,
                    edge: '1',
                    searchType: 'top'
                }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["tap"])(function () { return _this.searchLoading = false; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["catchError"])(function () {
                    _this.searchLoading = false;
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["of"])([]);
                })); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["tap"])(function () { return _this.searchLoading = false; }));
        };
        this.formatter = function (x) { return x.name || x.title; };
        this.isPlatformBrowser = Object(_angular_common__WEBPACK_IMPORTED_MODULE_9__["isPlatformBrowser"])(this.platformId);
        this.store.dispatch(new _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_2__["LoadSearchTags"]());
        // Router sub below covers all cases except initial launch,
        // the below call handles it
        this.handleInitialSearchBoxContent();
        this.routeSub$ = this.router.events.subscribe(function (val) {
            if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_6__["NavigationStart"]) {
                // on navige away from page should stay here
                _this.close();
            }
        });
    }
    MainSearchInputComponent.prototype.ngOnDestroy = function () {
        if (this.routeSub$) {
            this.routeSub$.unsubscribe();
        }
        if (this.tagsSubscription$) {
            this.tagsSubscription$.unsubscribe();
        }
        if (this.getTagSubscription$) {
            this.getTagSubscription$.unsubscribe();
        }
    };
    MainSearchInputComponent.prototype.ngOnInit = function () {
        this.checkForTags();
    };
    MainSearchInputComponent.prototype.checkForTags = function () {
        var _this = this;
        if (this.utilityService.isBrowser()) {
            setTimeout(function () {
                _this.tagsSubscription$ = _this.store
                    .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_search_selector__WEBPACK_IMPORTED_MODULE_3__["GetSearchTags"]))
                    .subscribe(function (tags) {
                    _this.store.dispatch(new _anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_1__["BulkPutInTable"]({
                        table: 'searchTags',
                        entry: tags
                    }));
                });
            }, 8000);
        }
    };
    MainSearchInputComponent.prototype.handleInitialSearchBoxContent = function () {
        /**
         * The below logic fills the search box when search page
         * is accessed through a link and not a normal search operation
         * within the player
         * https://anghami.workplace.com/groups/1869246206665881/permalink/2362929503964213/
         */
        if (this.router.url.indexOf('search') > -1) {
            var urlSplit = this.router.url.split('/');
            var searchQuery = urlSplit[2];
            if (this.searchModel.length === 0) {
                this.searchModel = this.utilityService.decodeSearchQuery(searchQuery);
            }
        }
    };
    MainSearchInputComponent.prototype.search = function (searchQuery) {
        if (searchQuery.length === 0) {
            this.clearSearch();
        }
        else {
            this.showSearch = true;
            this.registerWindowClickListener();
        }
        var searchPayload = {
            query: searchQuery,
            edge: 1,
            searchType: 'top'
        };
        this.store.dispatch(new _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_2__["Search"](searchPayload));
    };
    // search edge contain tags and recent searches
    MainSearchInputComponent.prototype.openSearchEdge = function () {
        if (this.searchModel.replace(/\s/g, '').length < 1) {
            this.registerWindowClickListener();
            this.searchEdgeContainer = true;
            this.cdr.detectChanges();
        }
    };
    // perform search, in a new page
    MainSearchInputComponent.prototype.goToSearchPage = function () {
        var encodedModel = this.utilityService.encodeSearchQuery(this.searchModel);
        this.router.navigateByUrl("/search/" + encodedModel + "/top", {});
        this.close();
    };
    MainSearchInputComponent.prototype.handleSearchIconClick = function () {
        if (this.searchModel && this.searchModel.length > 1) {
            this.goToSearchPage();
        }
        else {
            this.openSearchEdge();
        }
    };
    MainSearchInputComponent.prototype.onSearchEnter = function ($event) {
        if (this.searchModel.length > 1) {
            this.goToSearchPage();
            if ($event && $event.srcElement) {
                $event.srcElement.blur();
            }
        }
    };
    // add event listener to everything except search edge, to close on click
    MainSearchInputComponent.prototype.registerWindowClickListener = function () {
        var _this = this;
        var handler = function (e) {
            // TODO: clean the window click detection
            if (e &&
                (e.target.classList[0] === 'backdrop' || _this.searchElement &&
                    !_this.searchElement.nativeElement.contains(e.target)) &&
                e.target.className !== 'search-cancel' &&
                e.target.className !== 'clear') {
                window.removeEventListener('click', handler);
                _this.close();
            }
        };
        /**
         * Added the setTimeout, so that the click event that added the event
         * listener finishes before we add the listener
         */
        if (this.utilityService.isBrowser()) {
            setTimeout(function () {
                window.addEventListener('click', handler);
            }, 0);
        }
    };
    MainSearchInputComponent.prototype.itemSelected = function (e) {
        if (e.item.generictype === 'song') {
            this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_12__["PlaySongEngine"]({
                id: e.item.id,
                extras: e.item.extras
            }));
        }
        this.router.navigate([e.item.href]);
        // save collection item to recent search
        this.store.dispatch(new _anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_1__["PutInTable"]({
            entry: e.item,
            type: e.item.generictype,
            table: 'recentSearches'
        }));
        setTimeout(this.clearSearch, 2);
    };
    MainSearchInputComponent.prototype.clearSearch = function () {
        // TODO: fix clear search, this is not working
        this.searchModel = '';
    };
    MainSearchInputComponent.prototype.close = function () {
        this.searchEdgeContainer = false;
        this.searchLoading = false;
        this.cdr.detectChanges();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewChild"])('searchElement', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ElementRef"])
    ], MainSearchInputComponent.prototype, "searchElement", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewChild"])('searchInput', { read: _angular_core__WEBPACK_IMPORTED_MODULE_5__["ElementRef"], static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ElementRef"])
    ], MainSearchInputComponent.prototype, "searchInput", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewChild"])('instance', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_13__["NgbTypeahead"])
    ], MainSearchInputComponent.prototype, "instance", void 0);
    MainSearchInputComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
            selector: 'anghami-main-search-input',
            template: __webpack_require__(/*! raw-loader!./main-search-input.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/main-search-input/main-search-input.component.html"),
            styles: [__webpack_require__(/*! ./main-search-input.component.scss */ "./src/app/core/components/main-search-input/main-search-input.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](5, Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_5__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_5__["ChangeDetectorRef"],
            _anghami_services_search_service__WEBPACK_IMPORTED_MODULE_11__["SearchService"],
            Object])
    ], MainSearchInputComponent);
    return MainSearchInputComponent;
}());



/***/ }),

/***/ "./src/app/core/components/main-search-input/main-search-input.module.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/core/components/main-search-input/main-search-input.module.ts ***!
  \*******************************************************************************/
/*! exports provided: MainSearchInputModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainSearchInputModule", function() { return MainSearchInputModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _components_new_section_builder_list_item_list_item_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../components/new-section-builder/list-item/list-item.module */ "./src/app/core/components/new-section-builder/list-item/list-item.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _icon_icon_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _main_search_input_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./main-search-input.component */ "./src/app/core/components/main-search-input/main-search-input.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _search_edge_container_search_edge_container_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../search-edge-container/search-edge-container.component */ "./src/app/core/components/search-edge-container/search-edge-container.component.ts");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");











var MainSearchInputModule = /** @class */ (function () {
    function MainSearchInputModule() {
    }
    MainSearchInputModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [_main_search_input_component__WEBPACK_IMPORTED_MODULE_7__["MainSearchInputComponent"], _search_edge_container_search_edge_container_component__WEBPACK_IMPORTED_MODULE_9__["SearchEdgeComponent"]],
            entryComponents: [_main_search_input_component__WEBPACK_IMPORTED_MODULE_7__["MainSearchInputComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
                _icon_icon_module__WEBPACK_IMPORTED_MODULE_6__["IconModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbTypeaheadModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModule"],
                _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_10__["PipesModule"],
                _components_new_section_builder_list_item_list_item_module__WEBPACK_IMPORTED_MODULE_1__["ListItemModule"],
            ],
            exports: [_main_search_input_component__WEBPACK_IMPORTED_MODULE_7__["MainSearchInputComponent"], _search_edge_container_search_edge_container_component__WEBPACK_IMPORTED_MODULE_9__["SearchEdgeComponent"]],
        })
    ], MainSearchInputModule);
    return MainSearchInputModule;
}());



/***/ }),

/***/ "./src/app/core/components/search-edge-container/search-edge-container.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/core/components/search-edge-container/search-edge-container.component.ts ***!
  \******************************************************************************************/
/*! exports provided: SearchEdgeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchEdgeComponent", function() { return SearchEdgeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/db.actions */ "./src/app/core/redux/actions/db.actions.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");







// import { SearchService } from '../../../core/services/search.service';
// const SEARCH_MODEL_TIMEOUT_VALUE = 300;
var SearchEdgeComponent = /** @class */ (function () {
    // private sections: any[];
    // private searchTimeoutHandler: any;
    function SearchEdgeComponent(store, router, _actionsSubject, _utilService) {
        this.store = store;
        this.router = router;
        this._actionsSubject = _actionsSubject;
        this._utilService = _utilService;
        this.closeModal = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.loadingToggle = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.searchCompleted = false;
    }
    SearchEdgeComponent.prototype.ngOnInit = function () {
        this.positionClass = 'hidden';
        this.getTags();
        this.getRecentSearches();
        this.detectNavigation();
        // this.handleSearch(this.searchQuery);
    };
    // ngOnChanges(changes) {
    //   const newValue = changes.searchQuery.currentValue;
    //   if (newValue.length > 1 ) {
    //     if (this.searchTimeoutHandler) {
    //       clearTimeout(this.searchTimeoutHandler);
    //     }
    //     if (this._utilService.isBrowser()) {
    //       this.searchTimeoutHandler = setTimeout(() => {
    //         this.handleSearch(newValue);
    //       }, SEARCH_MODEL_TIMEOUT_VALUE);
    //     }
    //   }
    // }
    SearchEdgeComponent.prototype.ngOnDestroy = function () {
        if (this.getSearchResultsSubscription$) {
            this.getSearchResultsSubscription$.unsubscribe();
        }
        if (this.getRecentSearchesSubscription$) {
            this.getRecentSearchesSubscription$.unsubscribe();
        }
        if (this.getTagSubscription$) {
            this.getTagSubscription$.unsubscribe();
        }
        if (this.routeSub$) {
            this.routeSub$.unsubscribe();
        }
    };
    // handleSearch(searchQuery: any): any {
    //   this.searchCompleted = false;
    //   this.loadingToggle.emit();
    //   const searchPayload = {
    //     query: searchQuery,
    //     edge: '1',
    //     searchType: 'top'
    //   };
    //   this.searchService
    //     .getEdgeSearchResults(searchPayload)
    //     .pipe()
    //     .subscribe(resp => {
    //       this.searchCompleted = true;
    //       this.loadingToggle.emit();
    //       this.sections = resp;
    //     });
    // }
    SearchEdgeComponent.prototype.getTags = function () {
        var _this = this;
        this.store.dispatch(new _anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_1__["GetTagTableEntries"]());
        this.getTagSubscription$ = this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_1__["DBActionTypes"].GotTagTableEntries))
            .subscribe(function (action) {
            if (action.payload.entries.length > 0) {
                _this.positionClass = 'appear';
            }
            _this.searchTags = _this._utilService.shuffleArray(action.payload.entries);
        });
    };
    SearchEdgeComponent.prototype.getRecentSearches = function () {
        var _this = this;
        this.store.dispatch(new _anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_1__["GetRecentSearchTableEntries"]());
        this.getRecentSearchesSubscription$ = this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_1__["DBActionTypes"].GotRecentSearchTableEntries))
            .subscribe(function (action) {
            var new_arr = JSON.parse(JSON.stringify(action.payload.entries));
            _this.recentSearches = new_arr.reverse();
        });
    };
    SearchEdgeComponent.prototype.detectNavigation = function () {
        var _this = this;
        this.routeSub$ = this.router.events.subscribe(function (val) {
            if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_4__["NavigationStart"]) {
                _this.destroySearchEdge();
            }
        });
    };
    // onMoreClick() {
    //   if (this.searchQuery && this.searchQuery.length !== 0) {
    //     const encodedModel = encodeURIComponent(this.searchQuery);
    //     this.router.navigateByUrl(`/search/${encodedModel}/top`, {});
    //   }
    // }
    SearchEdgeComponent.prototype.clearRecentSearchDb = function () {
        this.recentSearches = null;
        this.store.dispatch(new _anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_1__["ClearTableEntries"]({ table: 'recentSearches' }));
    };
    SearchEdgeComponent.prototype.destroySearchEdge = function () {
        this.closeModal.emit();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SearchEdgeComponent.prototype, "searchQuery", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SearchEdgeComponent.prototype, "closeModal", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SearchEdgeComponent.prototype, "loadingToggle", void 0);
    SearchEdgeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'search-edge-container',
            template: __webpack_require__(/*! raw-loader!./search-edge-container.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/search-edge-container/search-edge-container.html"),
            styles: [__webpack_require__(/*! ./search-edge-container.scss */ "./src/app/core/components/search-edge-container/search-edge-container.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_6__["ActionsSubject"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilService"]])
    ], SearchEdgeComponent);
    return SearchEdgeComponent;
}());



/***/ }),

/***/ "./src/app/core/components/search-edge-container/search-edge-container.scss":
/*!**********************************************************************************!*\
  !*** ./src/app/core/components/search-edge-container/search-edge-container.scss ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".search-edge-container {\n  position: absolute;\n  top: 3.4em;\n  width: 200%;\n  -webkit-transition: max-height 0.1s ease-in;\n  transition: max-height 0.1s ease-in;\n  overflow: hidden;\n  max-height: 35em;\n  background: var(--search-header-bg);\n  border-radius: 5px;\n  box-shadow: 0 3px 3px 0 rgba(0, 0, 0, 0.14), 0 4px 1.5px -3px rgba(0, 0, 0, 0.12), 0 2px 6px 0 rgba(0, 0, 0, 0.2);\n}\n.search-edge-container .search-edge-results-container {\n  max-height: 30em;\n  overflow: auto;\n  padding: 0 1em;\n}\n.search-edge-container .search-edge-results-container ::ng-deep .section-wrapper .bigrow-wrapper .collection-item .exclusive-badge {\n  display: none;\n}\n.search-edge-container .empty-search-edge {\n  padding: 1em;\n}\n.search-edge-container .search-view-all {\n  max-height: 3.2em;\n  text-align: center;\n  padding: 1em;\n}\n.search-edge-container .search-view-all a:hover {\n  color: var(--btn-border-color);\n}\n.tag {\n  color: var(--search-text-color);\n  background-color: var(--search-tag-bg);\n  box-shadow: 0px 0px 6px 0px rgba(0, 0, 0, 0.14);\n  font-weight: 300;\n  border-radius: 2em;\n  border: none;\n  cursor: pointer;\n  padding: 0.3rem 1.3rem;\n  margin: 0.4em 0.7em 0.5em 0em;\n  text-decoration: none;\n}\n.tag:hover {\n  font-weight: 700;\n  color: var(--search-tag-hover);\n}\n.tag-container {\n  overflow: hidden;\n  height: 6.1em;\n  padding: 0.2em;\n  margin: 1em 0 1em 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-align: baseline;\n      -ms-flex-align: baseline;\n          align-items: baseline;\n  -ms-flex-line-pack: start;\n      align-content: flex-start;\n}\n.search-edge-headers {\n  color: var(--search-header-color);\n  font-weight: 500;\n  font-size: 1.1em;\n}\n.flex-common {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n}\n.recent-search-item {\n  color: inherit;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  text-decoration: none;\n  padding: 0.6em 0em 0.6em 0;\n  border-bottom: var(--default-item-border);\n}\n.recent-search-item:hover {\n  margin-left: -1em;\n  margin-right: -1em;\n  padding-left: 1em;\n  padding-right: 1em;\n  background-color: var(--track-hover);\n}\n.recent-search-item:last-child {\n  border-bottom: none;\n  padding: 0.6em 0 0em 0;\n}\n.recent-search-item:last-child:hover {\n  padding-left: 1em;\n  padding-right: 1em;\n  margin-bottom: -0.5em;\n  padding-bottom: 0.5em;\n}\n.recent-search-item-details {\n  text-orientation: inherit;\n  line-height: 1.2em;\n  position: relative;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  margin-left: 1.08em;\n  margin-right: 1.08em;\n}\n.clear {\n  cursor: pointer;\n  color: var(--search-text-color);\n}\n.recent-search-item-title {\n  font-weight: 500;\n  color: var(--search-header-color);\n}\n.recent-search-item-type {\n  font-size: 0.9em;\n  color: var(--search-text-color);\n}\n.icon {\n  color: var(--search-text-color);\n}\n.recent-icon {\n  padding: 0.7em;\n  display: inline-block;\n  vertical-align: middle;\n}\nanghami-icon.recent-icon {\n  border-radius: 50%;\n  background: var(--recent-search-icon-bg);\n}\n.no-recent-search {\n  text-align: center;\n  padding-top: 1em;\n  padding-bottom: 0.5em;\n}\n.button-view {\n  margin-bottom: 1.3em;\n}\n.hidden {\n  max-height: 0;\n  -webkit-transition: max-height 0.1s ease-out;\n  transition: max-height 0.1s ease-out;\n  overflow: hidden;\n}\n.padded {\n  padding: 2em;\n}"

/***/ }),

/***/ "./src/app/core/components/user-navigation/user-navigation.component.scss":
/*!********************************************************************************!*\
  !*** ./src/app/core/components/user-navigation/user-navigation.component.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* The switch - the box around the slider */\n.switch {\n  position: relative;\n  display: inline-block;\n  width: 35px;\n  height: 16px;\n  /* Hide default HTML checkbox */\n  /* The slider */\n}\n.switch input {\n  opacity: 0;\n  width: 0;\n  height: 0;\n  background: var(--light-background);\n  color: var(--text-color);\n}\n.switch input:checked + .slider {\n  background: var(--checkbox-checked-background);\n}\n.switch input:checked + .slider:before {\n  -webkit-transform: translateX(17px);\n  -ms-transform: translateX(17px);\n  transform: translateX(17px);\n  left: 2.5px;\n}\n.switch .slider {\n  position: absolute;\n  cursor: pointer;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  margin: auto !important;\n  border: var(--checkbox-border);\n  background-color: var(--checkbox-unchecked-background);\n  /* Rounded sliders */\n}\n.switch .slider.round {\n  border-radius: 20px;\n}\n.switch .slider.round:before {\n  border-radius: 50%;\n}\n.switch .slider:before {\n  position: absolute;\n  content: \"\";\n  height: 14px;\n  width: 14px;\n  left: 0;\n  bottom: 0;\n  top: 0;\n  margin: auto;\n  background-color: var(--checkbox-circle-background);\n  -webkit-transition: 0.4s;\n  transition: 0.4s;\n}\n:host {\n  -webkit-app-region: no-drag;\n}\n:host .spacing05 {\n  margin: 0.5em 0;\n}\n:host .viewprofile {\n  color: var(--app-secondary-grey) !important;\n}\n:host .viewprofile:hover {\n  background: none !important;\n}\n:host .user-dropdown-container .profile {\n  width: 3em;\n  height: 3em;\n  border-radius: 50%;\n  background: #e3e3e3;\n  border: 1px solid #e3e3e3;\n  position: relative;\n  background-repeat: no-repeat;\n  background-size: 100%;\n  cursor: pointer;\n  position: relative;\n  margin: 0 0.5em;\n}\n:host .user-dropdown-container .profile .plus-badge {\n  background: #e13f8c;\n  background: -webkit-gradient(linear, left top, right top, from(#e13f8c), color-stop(46%, #9d2ad5), to(#517bdd));\n  background: linear-gradient(to right, #e13f8c 0%, #9d2ad5 46%, #517bdd 100%);\n  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=\"#e13f8c\", endColorstr=\"#27aae1\", GradientType=1);\n  width: 85%;\n  position: absolute;\n  bottom: -0.4em;\n  color: #fff;\n  text-align: center;\n  border-radius: 3em;\n  text-transform: uppercase;\n  font-size: 0.6em;\n  left: 0;\n  right: 0;\n  margin: auto;\n  line-height: 1.4em;\n}\n:host .user-dropdown-container .profile:after {\n  display: none;\n}\n:host .user-dropdown-container .profile-container {\n  cursor: pointer;\n}\n:host .user-dropdown-container .dropdown-container {\n  cursor: pointer;\n}\n:host .user-dropdown-container .dropdown-container:after {\n  display: none;\n}\n:host .user-dropdown-container .more {\n  padding: 0 0.5em;\n}\n:host .user-dropdown-container .more ::ng-deep svg {\n  width: 1.5em;\n  height: 1.5em;\n}\n:host .user-dropdown-container .dropdown {\n  margin: 0;\n  padding: 0.5em 0 0 0;\n  border: 1px solid var(--dark-grey);\n  border-radius: 0.3em;\n  width: 14em;\n  min-height: 5em;\n  background-color: var(--user-navigation-background);\n  -moz-user-select: none;\n  user-select: none;\n  -ms-user-select: none;\n  -webkit-user-select: none;\n  left: auto;\n  right: 0;\n  top: 0.4em !important;\n  box-shadow: 0px 0px 17px -5px rgba(0, 0, 0, 0.61);\n}\n:host .user-dropdown-container .dropdown li {\n  list-style-type: none;\n  display: block;\n  font-size: 0.8em;\n  cursor: pointer;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n}\n:host .user-dropdown-container .dropdown li a {\n  display: block;\n  text-decoration: none;\n  color: var(--text-color);\n  padding: 0.5em 1em;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n}\n:host .user-dropdown-container .dropdown li a:hover {\n  background-color: var(--app-background);\n  padding: 0.5em 1.2em;\n  font-weight: bold;\n}\n:host .user-dropdown-container .dropdown li.user-nav {\n  padding: 1em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: stretch;\n      -ms-flex-align: stretch;\n          align-items: stretch;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n}\n:host .user-dropdown-container .dropdown li.user-nav a {\n  padding: 0;\n  color: var(--text-color);\n}\n:host .user-dropdown-container .dropdown li.user-nav strong {\n  font-size: 1.3em;\n  display: block;\n  color: var(--text-color);\n}\n:host .user-dropdown-container .dropdown li.user-nav span {\n  color: #656565;\n}\n:host .user-dropdown-container .dropdown li.action {\n  padding: 0.5em 0;\n}\n:host .user-dropdown-container .dropdown li.action i,\n:host .user-dropdown-container .dropdown li.action span {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0 0.5em;\n}\n:host .user-dropdown-container .dropdown li.action i {\n  font-size: 0.7em;\n}\n:host .user-dropdown-container .dropdown li.action.dark {\n  background-color: var(--user-navigation-darkmode-background);\n}\n:host .user-dropdown-container .dropdown li.action.dark .switch {\n  float: right;\n}\n:host .user-dropdown-container .dropdown li.action.dark a {\n  padding: 0.5em 1em !important;\n  font-weight: normal !important;\n}\n:host .user-dropdown-container .dropdown li.sep {\n  background: var(--context-header);\n  height: 1px;\n  padding: 0;\n  margin: 0;\n}\n:host .user-dropdown-container .dropdown li:last-child {\n  border-bottom-left-radius: 0.3em;\n  border-bottom-right-radius: 0.3em;\n}\n:host .user-dropdown-container .login-btn {\n  font-weight: lighter !important;\n  margin-right: 1em;\n  color: #fff;\n}\n:host .user-nav-scrollbar {\n  overflow-y: auto;\n  overflow-x: hidden;\n  width: calc(100% - 18px);\n}\n:host .user-nav ::ng-deep .ng-scroll-view {\n  max-height: 24em;\n}\n:host .dropdown-toggle::after {\n  display: none;\n}\nhtml[lang=ar] :host .manage-plus-account {\n  padding: 0.5em 1.2em 0.3em 1.2em !important;\n}\nhtml[lang=ar] :host ul.dropdown {\n  left: 9em !important;\n}"

/***/ }),

/***/ "./src/app/core/components/user-navigation/user-navigation.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/core/components/user-navigation/user-navigation.component.ts ***!
  \******************************************************************************/
/*! exports provided: UserNavigationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserNavigationComponent", function() { return UserNavigationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm5/ngx-cookie.js");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_redux_actions_layout_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/redux/actions/layout.actions */ "./src/app/core/redux/actions/layout.actions.ts");
/* harmony import */ var _anghami_redux_selectors_layout_selector__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/redux/selectors/layout.selector */ "./src/app/core/redux/selectors/layout.selector.ts");














var UserNavigationComponent = /** @class */ (function () {
    function UserNavigationComponent(config, store, router, _cookieService, authService) {
        this.store = store;
        this.router = router;
        this._cookieService = _cookieService;
        this.authService = authService;
        config.autoClose = 'outside';
        config.placement = 'bottom-right';
    }
    UserNavigationComponent.prototype.toggled = function (event) {
        if (event) {
            this.subscribeToRouterAndClose();
        }
        else {
            if (this.routerSubscription) {
                this.routerSubscription.unsubscribe();
            }
        }
    };
    UserNavigationComponent.prototype.ngOnDestroy = function () {
        if (this.routerSubscription) {
            this.routerSubscription.unsubscribe();
        }
        if (this.darkmodeSub$) {
            this.darkmodeSub$.unsubscribe();
        }
        if (this.user$) {
            this.user$.unsubscribe();
        }
        if (this.loggedIn$) {
            this.loggedIn$.unsubscribe();
        }
    };
    UserNavigationComponent.prototype.subscribeToRouterAndClose = function () {
        var _this = this;
        this.routerSubscription = this.router.events.subscribe(function (event) {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_3__["NavigationStart"]) {
                _this.modal.close();
                _this.routerSubscription.unsubscribe();
            }
        });
    };
    UserNavigationComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.selectedLang = this._cookieService.get('userlanguageprod')
            ? this._cookieService.get('userlanguageprod')
            : 'en';
        this.darkmodeSub$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_layout_selector__WEBPACK_IMPORTED_MODULE_12__["getDarkmodeState"]))
            .subscribe(function (data) {
            _this.darkmode = data;
        });
        this.user$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__["getUser"])).subscribe(function (user) {
            if (typeof user !== 'undefined' &&
                user !== null &&
                Object.keys(user).length > 0) {
                _this.user = user;
                if (user.plantype) {
                    _this.isPlus = user.plantype.match(/3/i) ? true : false;
                }
            }
        });
        this.isLoggedIn = this.authService.isUserLoggedIn();
        this.loggedIn$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__["getLoggedIn"])).subscribe(function (data) {
            _this.isLoggedIn = !!data;
        });
    };
    UserNavigationComponent.prototype.logout = function () {
        this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_1__["Logout"]());
        this.modal.close();
    };
    UserNavigationComponent.prototype.goToProfile = function (id, e) {
        if (id) {
            if (window && window.location.href.indexOf('play.anghami.com') == -1) {
                window.location.href = "https://play.anghami.com/profile/" + id;
            }
            else {
                this.router.navigateByUrl("/profile/" + id);
            }
        }
        e.preventDefault();
    };
    UserNavigationComponent.prototype.goToSettings = function (e) {
        if (window && window.location.href.indexOf('play.anghami.com') == -1) {
            window.location.href = "https://play.anghami.com/settings";
        }
        else {
            this.router.navigateByUrl("/settings");
        }
        e.preventDefault();
    };
    UserNavigationComponent.prototype.openLoginDialog = function () {
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["OpenCustomDialog"]({
            type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_8__["DIALOG_TYPES"].LOGIN
        }));
    };
    UserNavigationComponent.prototype.toggleDarkMode = function () {
        this.store.dispatch(new _anghami_redux_actions_layout_actions__WEBPACK_IMPORTED_MODULE_11__["ToggleDarkmode"]({ value: !this.darkmode }));
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])('modal', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], UserNavigationComponent.prototype, "modal", void 0);
    UserNavigationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'anghami-user-navigation',
            template: __webpack_require__(/*! raw-loader!./user-navigation.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/user-navigation/user-navigation.component.html"),
            providers: [_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["NgbDropdownConfig"]],
            styles: [__webpack_require__(/*! ./user-navigation.component.scss */ "./src/app/core/components/user-navigation/user-navigation.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["NgbDropdownConfig"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            ngx_cookie__WEBPACK_IMPORTED_MODULE_9__["CookieService"],
            _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_10__["AuthService"]])
    ], UserNavigationComponent);
    return UserNavigationComponent;
}());



/***/ }),

/***/ "./src/app/core/components/user-navigation/user-navigation.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/core/components/user-navigation/user-navigation.module.ts ***!
  \***************************************************************************/
/*! exports provided: UserNavigationModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserNavigationModule", function() { return UserNavigationModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _user_navigation_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-navigation.component */ "./src/app/core/components/user-navigation/user-navigation.component.ts");
/* harmony import */ var _anghami_plus_button_anghami_plus_button_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../anghami-plus-button/anghami-plus-button.module */ "./src/app/core/components/anghami-plus-button/anghami-plus-button.module.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _icon_icon_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var ngx_scrollbar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-scrollbar */ "./node_modules/ngx-scrollbar/fesm5/ngx-scrollbar.js");









var UserNavigationModule = /** @class */ (function () {
    function UserNavigationModule() {
    }
    UserNavigationModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _anghami_plus_button_anghami_plus_button_module__WEBPACK_IMPORTED_MODULE_4__["AnghamiPlusButtonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModule"],
                _icon_icon_module__WEBPACK_IMPORTED_MODULE_7__["IconModule"],
                ngx_scrollbar__WEBPACK_IMPORTED_MODULE_8__["NgScrollbarModule"]
            ],
            declarations: [_user_navigation_component__WEBPACK_IMPORTED_MODULE_3__["UserNavigationComponent"]],
            exports: [_user_navigation_component__WEBPACK_IMPORTED_MODULE_3__["UserNavigationComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], UserNavigationModule);
    return UserNavigationModule;
}());



/***/ }),

/***/ "./src/app/core/redux/effects/db.effects.ts":
/*!**************************************************!*\
  !*** ./src/app/core/redux/effects/db.effects.ts ***!
  \**************************************************/
/*! exports provided: DBEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DBEffects", function() { return DBEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _actions_db_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../actions/db.actions */ "./src/app/core/redux/actions/db.actions.ts");






var DBEffects = /** @class */ (function () {
    function DBEffects(actions$) {
        var _this = this;
        this.actions$ = actions$;
        this.PutInTable$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_db_actions__WEBPACK_IMPORTED_MODULE_5__["DBActionTypes"].PutInTable), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (action) {
            if (window.localStorage) {
                var tableName = action.payload.table;
                if (tableName === 'recentSearches') {
                    var recentSearches = JSON.parse(window.localStorage.getItem(tableName));
                    var newSearchItem_1 = _this.handleRecentSearchEntry(action.payload.entry, action.payload.type);
                    if (!recentSearches) {
                        recentSearches = [];
                    }
                    else {
                        // Remove duplicate and trim to 6 searches only
                        recentSearches = recentSearches.filter(function (elem) { return elem.href !== newSearchItem_1.href; });
                        if (recentSearches.length > 5) {
                            recentSearches.shift();
                        }
                    }
                    recentSearches.push(newSearchItem_1);
                    window.localStorage.setItem(tableName, JSON.stringify(recentSearches));
                }
                else {
                    window.localStorage.setItem(tableName, JSON.stringify(action.payload.entry));
                }
            }
        }));
        this.BulkPutInTable$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_db_actions__WEBPACK_IMPORTED_MODULE_5__["DBActionTypes"].BulkPutInTable), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (action) {
            if (window.localStorage) {
                window.localStorage.setItem(action.payload.table, JSON.stringify(action.payload.entry));
            }
        }));
        this.ClearTableEntries$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_db_actions__WEBPACK_IMPORTED_MODULE_5__["DBActionTypes"].ClearTableEntries), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (action) {
            if (window.localStorage) {
                window.localStorage.removeItem(action.payload.table);
            }
        }));
        this.GetTagTableEntries$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_db_actions__WEBPACK_IMPORTED_MODULE_5__["DBActionTypes"].GetTagTableEntries), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function () {
            if (window.localStorage) {
                var response = JSON.parse(window.localStorage.getItem('searchTags'));
                if (response) {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _actions_db_actions__WEBPACK_IMPORTED_MODULE_5__["GotTagTableEntries"]({ entries: response }));
                }
                else {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _actions_db_actions__WEBPACK_IMPORTED_MODULE_5__["GotTagTableEntries"]({ entries: [] }));
                }
            }
        }));
        this.GetRecentSearchTableEntries$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_db_actions__WEBPACK_IMPORTED_MODULE_5__["DBActionTypes"].GetRecentSearchTableEntries), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function () {
            if (window.localStorage) {
                var response = JSON.parse(window.localStorage.getItem('recentSearches'));
                if (response) {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _actions_db_actions__WEBPACK_IMPORTED_MODULE_5__["GotRecentSearchTableEntries"]({ entries: response }));
                }
                else {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _actions_db_actions__WEBPACK_IMPORTED_MODULE_5__["GotRecentSearchTableEntries"]({ entries: [] }));
                }
            }
        }));
    }
    DBEffects.prototype.handleRecentSearchEntry = function (entry, type) {
        return {
            title: entry.name ? entry.name : entry.title,
            supertitle: this.handleSupertitle(entry, type),
            icon: this.handleIcon(entry.href),
            href: entry.href
        };
    };
    DBEffects.prototype.handleSupertitle = function (entry, type) {
        if (entry.generictype) {
            if (entry.generictype === 'tag') {
                return 'personal dj';
            }
            else {
                return entry.generictype;
            }
        }
        else {
            return type; // if clicked from search
        }
    };
    DBEffects.prototype.handleIcon = function (url) {
        var icons = {
            profile: 'user',
            video: 'videoicon',
            album: 'album',
            artist: 'artist',
            song: 'song',
            tag: 'pdj',
            playlist: 'playlist'
        };
        var keys = Object.keys(icons);
        var result = '';
        keys.forEach(function (key) {
            if (url.indexOf(key) !== -1) {
                result = icons[key];
            }
        });
        return result;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DBEffects.prototype, "PutInTable$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DBEffects.prototype, "BulkPutInTable$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DBEffects.prototype, "ClearTableEntries$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DBEffects.prototype, "GetTagTableEntries$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DBEffects.prototype, "GetRecentSearchTableEntries$", void 0);
    DBEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"]])
    ], DBEffects);
    return DBEffects;
}());



/***/ }),

/***/ "./src/app/core/redux/effects/dialogs.effects.ts":
/*!*******************************************************!*\
  !*** ./src/app/core/redux/effects/dialogs.effects.ts ***!
  \*******************************************************/
/*! exports provided: DialogsEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DialogsEffects", function() { return DialogsEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _services_dialogs_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/dialogs.service */ "./src/app/core/services/dialogs.service.ts");
/* harmony import */ var _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");






var DialogsEffects = /** @class */ (function () {
    function DialogsEffects(actions$, dialogsService) {
        var _this = this;
        this.actions$ = actions$;
        this.dialogsService = dialogsService;
        /**
         * @description actions to dispatch when actions related to dialogs are fired
         */
        this.openDialog$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__["DialogsActionTypes"].Open), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (dialogData) {
            if (dialogData.payload) {
                _this.dialogsService.openDialogWithData(dialogData.payload);
            }
        }));
        this.openDialogByName$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__["DialogsActionTypes"].OpenDialogByName), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (dialogData) {
            if (dialogData.payload) {
                _this.dialogsService.openDialogByName(dialogData.payload).subscribe(function (resp) { });
            }
        }));
        this.openCustomDialog$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__["DialogsActionTypes"].OpenCustomDialog), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (data) { return data.payload; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (payload) {
            _this.dialogsService.openCustomDialog(payload.type, payload.dialogConfig);
        }));
    }
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DialogsEffects.prototype, "openDialog$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DialogsEffects.prototype, "openDialogByName$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])({ dispatch: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DialogsEffects.prototype, "openCustomDialog$", void 0);
    DialogsEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"],
            _services_dialogs_service__WEBPACK_IMPORTED_MODULE_4__["DialogsService"]])
    ], DialogsEffects);
    return DialogsEffects;
}());



/***/ }),

/***/ "./src/app/core/services/search.service.ts":
/*!*************************************************!*\
  !*** ./src/app/core/services/search.service.ts ***!
  \*************************************************/
/*! exports provided: SearchService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchService", function() { return SearchService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");







var SearchService = /** @class */ (function () {
    function SearchService(http, sectionService) {
        this.http = http;
        this.sectionService = sectionService;
        this.DEFAULT_SEARCH_ACTIVE_TAB = 'top';
    }
    SearchService.prototype.performSearch = function (query, searchType, isEdgeSearch, page, sectionid) {
        if (searchType === void 0) { searchType = this.DEFAULT_SEARCH_ACTIVE_TAB; }
        if (isEdgeSearch === void 0) { isEdgeSearch = 'false'; }
        if (page === void 0) { page = '0'; }
        if (sectionid === void 0) { sectionid = null; }
        var musiclanguage = '1';
        var count = isEdgeSearch ? '' : '18';
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETtabsearch')
            .set('output', 'jsonhp')
            .set('query', query)
            .set('edge', isEdgeSearch)
            .set('musiclanguage', musiclanguage)
            .set('searchtype', searchType)
            .set('page', page)
            .set('count', count);
        if (sectionid) {
            body = body.set('sectionid', sectionid);
        }
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    SearchService.prototype.getSearchConfig = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETsearchconfiguration')
            .set('output', 'jsonhp');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                var values = data.searchgroups.filter(function (section) { return section.searchgroup != 'userplaylist'; });
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(values);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    SearchService.prototype.getTags = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETdisplaytags');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    SearchService.prototype.getSearchSuggestions = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETplaylistrecommendations')
            .set('output', 'jsonhp');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                var recentSearches = [];
                for (var i = 0; i < 10; i++) {
                    recentSearches.push(data[i]);
                }
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(recentSearches);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    SearchService.prototype.getEdgeSearchResults = function (searchPayload) {
        var _this = this;
        return this.performSearch(searchPayload.query, searchPayload.searchType, searchPayload.edge).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (searchResponse) {
            var enhancedSections = _this.sectionService.enhanceSections(searchResponse);
            enhancedSections = enhancedSections.filter(function (section) { return section.group === 'tops'; });
            return enhancedSections[0].data.slice(0, 5);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err); }));
    };
    SearchService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_6__["SectionService"]])
    ], SearchService);
    return SearchService;
}());



/***/ })

}]);