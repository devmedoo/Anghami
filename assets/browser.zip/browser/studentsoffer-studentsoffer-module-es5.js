(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["studentsoffer-studentsoffer-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/studentsoffer/studentsoffer.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/studentsoffer/studentsoffer.component.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header\">\n  <div class=\"header-wrapper\">\n    <div class=\"artists-pics left\">\n      <span class=\"item\"></span>\n      <span class=\"item\"></span>\n    </div>\n    <div class=\"artists-pics right\">\n      <span class=\"item\"></span>\n      <span class=\"item\"></span>\n    </div>\n    <h1 class=\"title\" i18n=\"@@Landing_title_student_offer\">Music can turn students to stars</h1>\n    <h5 class=\"subtitle\" i18=\"@@Landing_title_student_offer_sub_title\">\n     Get 50% off Anghami Plus to study in music, without ads\n    </h5>\n\n  </div>\n  <img class=\"wave\" src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\" />\n</div>\n\n\n<section class=\"container-fluid\">\n  <div class=\"row\">\n    <div class=\"col-lg-3\"></div>\n    <div class=\"col-lg-6\">\n      <ng-container *ngIf=\"state.loading\">\n        <anghami-loading class=\"loader\"></anghami-loading>\n      </ng-container>\n\n\n\n      <ng-container *ngIf=\"!state.loading\">\n\n\n        <div class=\"isanon\" *ngIf=\"!state.isloggedIn\">\n          <div class=\"figure\">\n          </div>\n          <div class=\"m-3\">\n          <p i18n=\"@@Student_plan_login_title\">Get 50% off on Anghami Plus for students</p>\n          <h4 i18n=\"@@Student_plan_login_subtitle\">Please login to know more</h4>\n          <div>\n            <a (click)=\"openLoginDialog()\" class=\"btn\" i18n=\"@@Login_button\">Login</a>\n          </div>\n          </div>\n        </div>\n\n\n        <div class=\"notelligble\" *ngIf=\"state.isloggedIn && !state.ellibgle\">\n          <div class=\"figure\">\n          </div>\n          <div class=\"m-3\">\n          <p i18n=\"@@not_eligible_student_offer_title\" i18n=\"@@you_are_not_eligible_title\">You are not elligble to the Students offer plan</p>\n          <h4 i18n=\"@@you_are_not_eligible_sub_title\">Don’t worry, we have many other plans to explore</h4>\n          <div>\n            <a href=\"https://www.anghami.com/openapp?deeplink=anghami://upgrade\" class=\"btn subscribe\" i18n=\"@@Try_other_plans_button\">Try other plans!</a>\n          </div>\n          </div>\n        </div>\n\n\n\n        <div class=\"success\" *ngIf=\"state.ellibgle && !state.additionalinfo\">\n          <div class=\"figure\">\n          </div>\n          <div class=\"m-3\">\n          <p>Your account is valid!</p>\n          <h4 i18n=\"@@Get 50% off on Anghami Plus for students\">Get 50% off on Anghami Plus for students</h4>\n          <div>\n            <a [href]=\"upgradelink\" class=\"btn subscribe\" i18n=\"@@Subscribe Now\">Subscribe now</a>\n          </div>\n          </div>\n        </div>\n\n      <div class=\"steps text-center\" *ngIf=\"state.ellibgle\">\n        <form (ngSubmit)=\"validate()\">\n        <ng-container *ngIf=\"state.firstFlow; else secondFlow\">\n          <div class=\"dob\" *ngIf=\"state.birthdate\">\n            <h3 i18n=\"@@Please enter your date of birth\">Enter your date of birth</h3>\n            <input class=\"form-control\" i18n-placeholder=\"@@Please enter your date of birth\" name=\"dp\" [(ngModel)]=\"dob\"\n              ngbDatepicker #d=\"ngbDatepicker\" (click)=\"d.toggle()\" [class.error]=\"state.formValidationError\"\n              [minDate]=\"{year: 1980, month: 12, day: 30}\" [maxDate]=\"{year: 2015, month: 12, day: 30}\">\n            <div class=\"text-center\">\n              <anghami-loading class=\"loader\" *ngIf=\"state.apiLoading\"></anghami-loading>\n              <p class=\"message\" *ngIf=\"state.message.length > 0\">{{state.message}} </p>\n              <div class=\"btn\" (click)=\"validaimgte();\" *ngIf=\"!state.apiLoading\" i18n=\"@@Verify\">Verify</div>\n              <div class=\"isic-sub-button-container\">\n                <span class='sub-button' *ngIf=\"state.showIsicButton\" (click)=\"showIsicForm()\"> Or enter your ISIC </span>\n                <img [src]= \"assetsEnv + 'isic_logo.png'\" class=\"isic-small-logo\" />\n              </div>\n            </div>\n          </div>\n          <div class=\"email\" *ngIf=\"state.email\">\n            <h3 i18n=\"@@Please enter your school or university email\">Please enter your school or university email</h3>\n            <input class=\"form-control\" type=\"email\" i18n-placeholder=\"@@Please enter your school or university email\"\n              name=\"email\" [(ngModel)]=\"email\" [class.error]=\"state.formValidationError\">\n            <div><small>Ex: students@university.edu.lb</small></div>\n            <div class=\"text-center\">\n              <p class=\"message\" *ngIf=\"state.message.length > 0\">{{state.message}} </p>\n              <anghami-loading class=\"loader\" *ngIf=\"state.apiLoading\"></anghami-loading>\n              <div class=\"btn\" (click)=\"validate();\" *ngIf=\"!state.apiLoading\" i18n=\"@@confirm_your_email_button\">Confirm your\n                email</div>\n                <div class=\"isic-sub-button-container\">\n                  <span class='sub-button' *ngIf=\"state.showIsicButton\" (click)=\"showIsicForm()\"> Or enter your ISIC </span>\n                  <img [src]= \"assetsEnv + 'isic_logo.png'\" class=\"isic-small-logo\" />\n                </div>\n            </div>\n          </div>\n          <div class=\"activate\" *ngIf=\"state.activate\">\n            <div class=\"figure\">\n            </div>\n            <div>\n              <h3>An email has been sent, please verify it</h3>\n              <div class=\"text-center pt-3\">\n                <div class=\"btn subscribe\" (click)=\"forceShowEmailForm();\">Haven't receive an email yet?</div>\n              </div>\n            </div>\n            <p class=\"message\" *ngIf=\"state.message.length > 0\">{{state.message}} </p>\n          </div>\n        </ng-container>\n        <ng-template #secondFlow>\n          <div *ngIf=\"state.isic\">\n            <h3 i18n=\"@@isic_enter_card\">Enter your ISIC information</h3>\n            <img [src]= \"assetsEnv + 'isic_logo.png'\" class=\"isic-big-logo\" />\n            <input class=\"isic-input form-control\" type=\"string\" i18n-placeholder=\"@@isic_cardholder_name\"\n              placeholder=\"Cardholder name\" name=\"isicCardHolder\" [(ngModel)]=\"isicCardHolder\"\n              [class.error]=\"state.formValidationError\" />\n            <input class=\"form-control\" type=\"string\" i18n-placeholder=\"@@isic_card_num\" name=\"isicNumber\"\n              placeholder=\"ISIC number\" [(ngModel)]=\"isicNumber\" [class.error]=\"state.formValidationError\" />\n            <div class=\"text-center\">\n              <p class=\"message\" *ngIf=\"state.message.length > 0\">{{state.message}} </p>\n              <anghami-loading class=\"loader\" *ngIf=\"state.apiLoading\"></anghami-loading>\n              <div class=\"btn\" (click)=\"validate();\" *ngIf=\"!state.apiLoading\" i18n=\"@@Verify\">Verify</div>\n              <span class='sub-button' i18n=\"@@isic_email_bday_verify\" (click)=\"showBirthdayForm()\"> Or enter your birthday and\n                email </span>\n            </div>\n          </div>\n        </ng-template>\n        </form>\n      </div>\n      </ng-container>\n\n    </div>\n    <div class=\"col-lg-3\"></div>\n  </div>\n\n\n  <div class=\"row\">\n    <div class=\"col-lg-12\">\n        <hr class=\"mb-5\">\n      <div class=\"benefits-container\">\n        <h3 i18n=\"@@benefit_from_plus_features\">Benefit form all this awesome features with Anghami Plus</h3>\n        <div class=\"benefit\">\n          <div class=\"figure downloads\"></div>\n          <h5 i18n=\"@@landing_plus_downloads_title\">Unlimited Downloads</h5>\n          <p i18n=\"@@landing_plus_downloads_subtitle\">Download any song. Play it offline. Save Data.</p>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure nointerruption\"></div>\n          <h5 i18n=\"@@landing_plus_noads_title\">No more ads.</h5>\n          <p i18n=\"@@landing_plus_noads_subtitle\">Enjoy all the music you want without any interruption.</p>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure hq\"></div>\n          <h5 i18n=\"@@landing_plus_hq_title\">High quality music</h5>\n          <p i18n=\"@@landing_plus_hq_subtitle\">The sound quality is 5x better (with *Dolby 320 Kbps*)</p>\n        </div>\n\n        <div class=\"benefit\">\n          <div class=\"figure lyrics\"></div>\n          <h5 i18n=\"@@landing_plus_lyrics_title\">Unlock the Lyrics</h5>\n          <p>Sing along with your favorite songs.</p>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure skiprepeat\"></div>\n          <h5 i18n=\"@@landing_plus_restrictions_title\">Restriction-free music.</h5>\n          <p i18n=\"@@landing_plus_restrictions_subtitle\">Go to the previous song or the next one. Repeat the one you love. Scrub to your favorite part.</p>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure import\"></div>\n          <h5 i18n=\"@@landing_plus_import_title\">Bring your music to Anghami.</h5>\n          <p i18n=\"@@landing_plus_import_subtitle\">Import any song that’s not on Anghami via the desktop app.</p>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure boost\"></div>\n          <h5 i18n=\"@@landing_plus_boost_title\">Boost your sound</h5>\n          <p i18n=\"@@landing_plus_boost_subtitle\">Connect multiple devices together to play the same music at the same time.</p>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure connect\"></div>\n          <h5 i18n=\"@@landing_plus_connectphone_title\">Connect Phones. Control music.</h5>\n          <p i18n=\"@@landing_plus_connectphone_subtitle\">Connect phones remotely without bluetooth and control your music.</p>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure exclusive\"></div>\n          <h5 i18n=\"@@landing_plus_exclusive_title\">Exclusive music</h5>\n          <p i18n=\"@@landing_plus_exclusive_subtitle\">Be the first to play the latest songs of your favorite artists, exclusively.</p>\n        </div>\n      </div>\n    </div>\n  </div>\n\n</section>\n"

/***/ }),

/***/ "./node_modules/rxjs/internal/observable/empty.js":
/*!********************************************************!*\
  !*** ./node_modules/rxjs/internal/observable/empty.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Observable_1 = __webpack_require__(/*! ../Observable */ "./node_modules/rxjs/internal/Observable.js");
exports.EMPTY = new Observable_1.Observable(function (subscriber) { return subscriber.complete(); });
function empty(scheduler) {
    return scheduler ? emptyScheduled(scheduler) : exports.EMPTY;
}
exports.empty = empty;
function emptyScheduled(scheduler) {
    return new Observable_1.Observable(function (subscriber) { return scheduler.schedule(function () { return subscriber.complete(); }); });
}
//# sourceMappingURL=empty.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/operators/take.js":
/*!******************************************************!*\
  !*** ./node_modules/rxjs/internal/operators/take.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Subscriber_1 = __webpack_require__(/*! ../Subscriber */ "./node_modules/rxjs/internal/Subscriber.js");
var ArgumentOutOfRangeError_1 = __webpack_require__(/*! ../util/ArgumentOutOfRangeError */ "./node_modules/rxjs/internal/util/ArgumentOutOfRangeError.js");
var empty_1 = __webpack_require__(/*! ../observable/empty */ "./node_modules/rxjs/internal/observable/empty.js");
function take(count) {
    return function (source) {
        if (count === 0) {
            return empty_1.empty();
        }
        else {
            return source.lift(new TakeOperator(count));
        }
    };
}
exports.take = take;
var TakeOperator = (function () {
    function TakeOperator(total) {
        this.total = total;
        if (this.total < 0) {
            throw new ArgumentOutOfRangeError_1.ArgumentOutOfRangeError;
        }
    }
    TakeOperator.prototype.call = function (subscriber, source) {
        return source.subscribe(new TakeSubscriber(subscriber, this.total));
    };
    return TakeOperator;
}());
var TakeSubscriber = (function (_super) {
    __extends(TakeSubscriber, _super);
    function TakeSubscriber(destination, total) {
        var _this = _super.call(this, destination) || this;
        _this.total = total;
        _this.count = 0;
        return _this;
    }
    TakeSubscriber.prototype._next = function (value) {
        var total = this.total;
        var count = ++this.count;
        if (count <= total) {
            this.destination.next(value);
            if (count === total) {
                this.destination.complete();
                this.unsubscribe();
            }
        }
    };
    return TakeSubscriber;
}(Subscriber_1.Subscriber));
//# sourceMappingURL=take.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/ArgumentOutOfRangeError.js":
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/internal/util/ArgumentOutOfRangeError.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function ArgumentOutOfRangeErrorImpl() {
    Error.call(this);
    this.message = 'argument out of range';
    this.name = 'ArgumentOutOfRangeError';
    return this;
}
ArgumentOutOfRangeErrorImpl.prototype = Object.create(Error.prototype);
exports.ArgumentOutOfRangeError = ArgumentOutOfRangeErrorImpl;
//# sourceMappingURL=ArgumentOutOfRangeError.js.map

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: -webkit-gradient(linear, left top, right top, from(#e03f8d), color-stop(#a22ccf), to(#2fa0df));\n  background: linear-gradient(to right, #e03f8d, #a22ccf, #2fa0df);\n  height: 30em;\n  background-size: cover !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    height: auto;\n    min-height: 15em;\n  }\n}\n:host .header.pringles {\n  background-size: cover !important;\n  background-position: center !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header.extra .title {\n  width: 60%;\n  margin: auto;\n}\n:host .header .logo {\n  max-width: 5em;\n  display: block;\n  margin: 1em auto;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n  }\n}\n:host .header .subtitle {\n  font-size: 1.2rem;\n  margin: auto;\n  font-weight: 200;\n  text-align: center;\n  padding-top: 0.5em;\n}\n@media (max-width: 768px) {\n  :host .header .subtitle {\n    width: 85%;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}"

/***/ }),

/***/ "./src/app/core/redux/actions/external-pages.actions.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/redux/actions/external-pages.actions.ts ***!
  \**************************************************************/
/*! exports provided: ExternalPagesActionTypes, SubscribeCampaign, SubmitAdvertisePage, getWebPurchaseOptions, getWebPurchaseOptionsSuccess, submitStudentsOfferData, submitStudentsOfferDataSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExternalPagesActionTypes", function() { return ExternalPagesActionTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscribeCampaign", function() { return SubscribeCampaign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubmitAdvertisePage", function() { return SubmitAdvertisePage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWebPurchaseOptions", function() { return getWebPurchaseOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWebPurchaseOptionsSuccess", function() { return getWebPurchaseOptionsSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitStudentsOfferData", function() { return submitStudentsOfferData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitStudentsOfferDataSuccess", function() { return submitStudentsOfferDataSuccess; });
/*
 * Created Date: Thursday September 6th 2018
 * Author: Siraj Tahra
 * Email: siraj.tahra@anghami.com
 * -----
 * Copyright (c) 2018 Anghami
 */
var ExternalPagesActionTypes;
(function (ExternalPagesActionTypes) {
    ExternalPagesActionTypes["SubscribeCampaign"] = "[Auth] Subscribe Campaign";
    ExternalPagesActionTypes["SubmitAdvertisePage"] = "[Auth] Submit Advertise Page";
    ExternalPagesActionTypes["getWebPurchaseOptions"] = "[Landing] Get Web Purchase Options";
    ExternalPagesActionTypes["getWebPurchaseOptionsSuccess"] = "[Landing] Get Web Purchase Options Success";
    ExternalPagesActionTypes["submitStudentsOfferData"] = "[Landing] Submit Students Offer Data";
    ExternalPagesActionTypes["submitStudentsOfferDataSuccess"] = "[Landing] Submit Students Offer Success";
})(ExternalPagesActionTypes || (ExternalPagesActionTypes = {}));
var SubscribeCampaign = /** @class */ (function () {
    function SubscribeCampaign(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.SubscribeCampaign;
    }
    return SubscribeCampaign;
}());

var SubmitAdvertisePage = /** @class */ (function () {
    function SubmitAdvertisePage(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.SubmitAdvertisePage;
    }
    return SubmitAdvertisePage;
}());

var getWebPurchaseOptions = /** @class */ (function () {
    function getWebPurchaseOptions(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.getWebPurchaseOptions;
    }
    return getWebPurchaseOptions;
}());

var getWebPurchaseOptionsSuccess = /** @class */ (function () {
    function getWebPurchaseOptionsSuccess(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.getWebPurchaseOptionsSuccess;
    }
    return getWebPurchaseOptionsSuccess;
}());

var submitStudentsOfferData = /** @class */ (function () {
    function submitStudentsOfferData(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.submitStudentsOfferData;
    }
    return submitStudentsOfferData;
}());

var submitStudentsOfferDataSuccess = /** @class */ (function () {
    function submitStudentsOfferDataSuccess(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.submitStudentsOfferDataSuccess;
    }
    return submitStudentsOfferDataSuccess;
}());



/***/ }),

/***/ "./src/app/modules/landing/studentsoffer/studentsoffer.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/modules/landing/studentsoffer/studentsoffer.component.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@-webkit-keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n:host h3 {\n  max-width: 20em;\n  font-size: 1.7em;\n  margin: 1em auto;\n}\n:host .header {\n  height: 25em;\n  background: transparent -webkit-gradient(linear, left top, left bottom, from(#12BFB2), to(#177B7B)) 0% 0% no-repeat padding-box;\n  background: transparent linear-gradient(180deg, #12BFB2 0%, #177B7B 100%) 0% 0% no-repeat padding-box;\n}\n:host .header h1.title {\n  font-size: 3.25em;\n}\n@media (max-width: 768px) {\n  :host .header h1.title {\n    font-size: 2em;\n  }\n}\n:host .header .header-wrapper {\n  position: relative;\n  text-align: center;\n}\n:host .header .artists-pics {\n  position: absolute;\n  top: -50%;\n  margin-top: -1em;\n}\n:host .header .artists-pics .item {\n  width: 7em;\n  height: 10em;\n  background-size: 100%;\n  background-repeat: no-repeat;\n  background-position: center center;\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0.5em;\n  position: absolute;\n}\n:host .header .artists-pics.left {\n  left: -50%;\n}\n:host .header .artists-pics.left .item:nth-child(1) {\n  background-image: url('Image102@2x.jpg');\n  transform: rotate(-13deg);\n  -webkit-transform: rotate(-13deg);\n  -moz-transform: rotate(-13deg);\n  -ms-transform: rotate(-13deg);\n  -o-transform: rotate(-13deg);\n}\n:host .header .artists-pics.left .item:nth-child(2) {\n  background-image: url('Image103@2x.jpg');\n  transform: rotate(-6deg);\n  -webkit-transform: rotate(-6deg);\n  -moz-transform: rotate(-6deg);\n  -ms-transform: rotate(-6deg);\n  -o-transform: rotate(-6deg);\n  left: 9em;\n}\n:host .header .artists-pics.right {\n  right: -50%;\n}\n:host .header .artists-pics.right .item:nth-child(1) {\n  background-image: url('Image100@2x.jpg');\n  right: 0;\n  transform: rotate(-4deg);\n  -webkit-transform: rotate(-4deg);\n  -moz-transform: rotate(-4deg);\n  -ms-transform: rotate(-4deg);\n  -o-transform: rotate(-4deg);\n}\n:host .header .artists-pics.right .item:nth-child(2) {\n  background-image: url('Image101@2x.jpg');\n  right: 9em;\n  transform: rotate(6deg);\n  -webkit-transform: rotate(6deg);\n  -moz-transform: rotate(6deg);\n  -ms-transform: rotate(6deg);\n  -o-transform: rotate(6deg);\n}\n@media (max-width: 768px) {\n  :host .header .artists-pics {\n    position: static;\n    display: inline-block;\n    vertical-align: middle;\n    top: auto;\n    left: auto;\n    right: auto;\n  }\n  :host .header .artists-pics .item {\n    width: 4em;\n    height: 6em;\n    position: static;\n  }\n}\n:host .benefits-container {\n  text-align: center;\n  padding: 0 1em;\n}\n:host .benefits-container .benefit {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0.5em;\n  max-width: 16em;\n}\n@media (max-width: 768px) {\n  :host .benefits-container .benefit {\n    max-width: 11em;\n  }\n}\n:host .benefits-container .benefit h5 {\n  font-size: 1.2em;\n}\n:host .benefits-container .benefit .figure {\n  width: 8em;\n  height: 10em;\n  background-repeat: no-repeat;\n  background-size: 100%;\n  background-position: center center;\n}\n@media (max-width: 768px) {\n  :host .benefits-container .benefit .figure {\n    max-width: 6em;\n  }\n}\n:host .benefits-container .benefit .figure.downloads {\n  background-image: url('8992@2x.png');\n}\n:host .benefits-container .benefit .figure.nointerruption {\n  background-image: url('8993@2x.png');\n}\n:host .benefits-container .benefit .figure.hq {\n  background-image: url('8996@2x.png');\n}\n:host .benefits-container .benefit .figure.lyrics {\n  background-image: url('9002@2x.png');\n}\n:host .benefits-container .benefit .figure.skiprepeat {\n  background-image: url('8995@2x.png');\n}\n:host .benefits-container .benefit .figure.import {\n  background-image: url('8999@2x.png');\n}\n:host .benefits-container .benefit .figure.import {\n  background-image: url('8999@2x.png');\n}\n:host .benefits-container .benefit .figure.boost {\n  background-image: url('8998@2x.png');\n}\n:host .benefits-container .benefit .figure.connect {\n  background-image: url('8997@2x.png');\n}\n:host .benefits-container .benefit .figure.exclusive {\n  background-image: url('8994@2x.png');\n}\n:host .btn {\n  padding: 0.8em 1.5em;\n  margin: 1em 0;\n  border-radius: 2em;\n  padding: 0.5em 2.5em;\n  color: #FFF;\n  cursor: pointer;\n  background: #8D00F2;\n  transition: all 200ms ease;\n  -webkit-transition: all 200ms ease;\n  -moz-transition: all 200ms ease;\n  -ms-transition: all 200ms ease;\n  -o-transition: all 200ms ease;\n  box-shadow: -1px 2px 37px 1px rgba(0, 0, 0, 0.17);\n}\n:host .btn:hover {\n  background: #7001BF;\n}\n:host .btn:active {\n  background: #8D00F2;\n  padding: 0.4em 2.3em;\n}\n:host .btn.subscribe {\n  background: transparent -webkit-gradient(linear, left top, right top, from(#007FFE), to(#01B5FF)) 0% 0% no-repeat padding-box;\n  background: transparent linear-gradient(90deg, #007FFE 0%, #01B5FF 100%) 0% 0% no-repeat padding-box;\n  border: none;\n}\n:host .btn.subscribe:hover {\n  background: transparent -webkit-gradient(linear, left top, right top, from(#007FFE), to(#06A0E0)) 0% 0% no-repeat padding-box;\n  background: transparent linear-gradient(90deg, #007FFE 0%, #06A0E0 100%) 0% 0% no-repeat padding-box;\n}\n:host .btn.subscribe:active {\n  background: transparent -webkit-gradient(linear, left top, right top, from(#007FFE), to(#01B5FF)) 0% 0% no-repeat padding-box;\n  background: transparent linear-gradient(90deg, #007FFE 0%, #01B5FF 100%) 0% 0% no-repeat padding-box;\n  padding: 0.4em 2.3em;\n}\n:host .isic-sub-button-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .isic-sub-button-container .isic-small-logo {\n  width: 4em;\n  margin-left: 1em;\n}\n:host .isic-big-logo {\n  width: 8em;\n  margin: auto;\n  margin-bottom: 1em;\n}\n:host .sub-button {\n  text-decoration: underline;\n  display: block;\n  cursor: pointer;\n}\n:host .sub-button:hover {\n  font-weight: 600;\n}\n:host .steps {\n  padding: 1em;\n}\n:host .steps .form-control {\n  background-color: #EFEFEF;\n  border-radius: 0.3em;\n  -webkit-border-radius: 0.3em;\n  -moz-border-radius: 0.3em;\n  -ms-border-radius: 0.3em;\n  -o-border-radius: 0.3em;\n  font-size: 0.9em;\n  padding: 2em 1em;\n  color: #8B8B8B;\n  border: none;\n  max-width: 30em;\n  margin: auto;\n}\n:host .steps .form-control.error {\n  border: 1px solid red;\n}\n:host .steps .isic-input {\n  margin-bottom: 1.5em;\n}\n:host .success,\n:host .notelligble,\n:host .isanon,\n:host .activate {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  text-align: start;\n}\n:host .success .figure,\n:host .notelligble .figure,\n:host .isanon .figure,\n:host .activate .figure {\n  width: 22em;\n  height: 22em;\n  margin: auto;\n  background-position: center center;\n  background-repeat: no-repeat;\n  background-size: 100%;\n}\n@media (max-width: 768px) {\n  :host .success .figure,\n:host .notelligble .figure,\n:host .isanon .figure,\n:host .activate .figure {\n    width: 18em;\n    height: 18em;\n  }\n}\n:host .success.success .figure,\n:host .notelligble.success .figure,\n:host .isanon.success .figure,\n:host .activate.success .figure {\n  background-image: url('studentsoffersuccess@2x.png');\n}\n:host .success.notelligble .figure,\n:host .notelligble.notelligble .figure,\n:host .isanon.notelligble .figure,\n:host .activate.notelligble .figure {\n  background-image: url('studentsofferfail@2x.png');\n}\n:host .success.isanon .figure,\n:host .notelligble.isanon .figure,\n:host .isanon.isanon .figure,\n:host .activate.isanon .figure {\n  background-image: url('studentsofferfail@2x.png');\n}\n:host .success.activate .figure,\n:host .notelligble.activate .figure,\n:host .isanon.activate .figure,\n:host .activate.activate .figure {\n  background-image: url('studentsemail@2x.png');\n}\n:host .message {\n  color: red;\n  font-weight: bold;\n  margin: auto;\n  text-align: center;\n  margin-top: 0.5em;\n  -webkit-animation-name: fadeIn;\n  animation-name: fadeIn;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.3s;\n  animation-duration: 0.3s;\n  -webkit-animation-delay: 0.1s;\n  animation-delay: 0.1s;\n  -webkit-animation-timing-function: ease;\n  animation-timing-function: ease;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}"

/***/ }),

/***/ "./src/app/modules/landing/studentsoffer/studentsoffer.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/modules/landing/studentsoffer/studentsoffer.component.ts ***!
  \**************************************************************************/
/*! exports provided: StudentsofferComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudentsofferComponent", function() { return StudentsofferComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/external-pages.actions */ "./src/app/core/redux/actions/external-pages.actions.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var rxjs_internal_operators_take__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/internal/operators/take */ "./node_modules/rxjs/internal/operators/take.js");
/* harmony import */ var rxjs_internal_operators_take__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(rxjs_internal_operators_take__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _core_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");















var StudentsofferComponent = /** @class */ (function () {
    function StudentsofferComponent(locale, store, _actionsSubject, calendar, _authService, _utilsService) {
        this.locale = locale;
        this.store = store;
        this._actionsSubject = _actionsSubject;
        this.calendar = calendar;
        this._authService = _authService;
        this._utilsService = _utilsService;
        this.assetsEnv = _environments_environment__WEBPACK_IMPORTED_MODULE_14__["environment"].assetsCDN + "img/studentsoffer/";
        this.device = this._utilsService.getOSName();
        this.state = {
            email: false,
            birthdate: false,
            activate: false,
            error: '',
            ellibgle: false,
            loading: false,
            apiLoading: false,
            additionalinfo: false,
            message: '',
            formValidationError: false,
            isloggedIn: true,
            showIsicButton: false,
            isic: false,
            firstFlow: true
        };
    }
    StudentsofferComponent.prototype.ngOnInit = function () {
        var _this = this;
        setTimeout(function () {
            _this.state.isloggedIn = _this._authService.isUserLoggedIn();
            _this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_10__["getLoggedIn"]))
                .pipe()
                .subscribe(function (data) {
                _this.state.isloggedIn = data;
                if (data) {
                    _this.store.dispatch(new _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__["getWebPurchaseOptions"]());
                    _this.setCallbackListeners();
                    _this.state.loading = true;
                }
            });
        }, 300);
    };
    StudentsofferComponent.prototype.validate = function () {
        var _this = this;
        this.state.apiLoading = true;
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__["ExternalPagesActionTypes"].submitStudentsOfferDataSuccess), Object(rxjs_internal_operators_take__WEBPACK_IMPORTED_MODULE_6__["take"])(2))
            .subscribe(function (data) {
            _this.state.apiLoading = false;
            var pl = data.payload;
            _this.state.message = '';
            if (pl.error) {
                _this.state.message = pl.error._attributes ? pl.error._attributes.message : pl.error.message;
            }
            else {
                _this.state.message = '';
                _this.store.dispatch(new _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__["getWebPurchaseOptions"]());
            }
        });
        if (this.state.firstFlow) {
            if (this.state.email) {
                if (!this.email) {
                    this.state.formValidationError = true;
                    this.state.apiLoading = false;
                    return;
                }
                if (this.email) {
                    this.store.dispatch(new _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__["submitStudentsOfferData"]({ email: this.email }));
                }
            }
            else if (this.state.birthdate) {
                if (!this.dob) {
                    this.state.formValidationError = true;
                    this.state.apiLoading = false;
                    return;
                }
                var day = this.dob.day < 10 ? '0' + this.dob.day : this.dob.day;
                var month = this.dob.month < 10 ? '0' + this.dob.month : this.dob.month;
                var year = this.dob.year < 10 ? '0' + this.dob.year : this.dob.year;
                var fulldate = year + "-" + month + "-" + day;
                this.store.dispatch(new _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__["submitStudentsOfferData"]({ birthdate: fulldate }));
            }
            else {
                this.store.dispatch(new _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__["getWebPurchaseOptions"]());
            }
        }
        else {
            if (this.state.isic) {
                if (this.isicCardHolder && this.isicNumber) {
                    this.store.dispatch(new _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__["submitStudentsOfferData"]({ card_number: this.isicNumber, cardholder_name: this.isicCardHolder }));
                }
                else {
                    this.state.formValidationError = true;
                    this.state.apiLoading = false;
                    return;
                }
            }
            else {
                this.store.dispatch(new _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__["getWebPurchaseOptions"]());
            }
        }
        this.state.formValidationError = false;
    };
    StudentsofferComponent.prototype.setCallbackListeners = function () {
        var _this = this;
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_3__["ExternalPagesActionTypes"].getWebPurchaseOptionsSuccess))
            .subscribe(function (action) {
            var pl = action.payload;
            _this.state.activate = pl.activate;
            _this.state.email = pl.email;
            _this.state.birthdate = pl.birthdate;
            _this.state.showIsicButton = pl.isic;
            _this.state.additionalinfo = false;
            _this.state.firstFlow = true;
            _this.state.loading = false;
            _this.state.isic = false;
            _this.state.message = '';
            if (pl.error) {
                if (pl.error._attributes.code === 60) {
                    _this.state.ellibgle = false;
                }
                else {
                    _this.state.additionalinfo = true;
                    _this.state.ellibgle = true; // Account elligble but needs data validation
                }
                _this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_8__["LogAmplitudeEvent"]({
                    name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].studentOfferActivationFail,
                    props: {
                        details: pl
                    }
                }));
            }
            else {
                _this.state.ellibgle = true;
                if (pl.plans) {
                    var pId = pl.plans[0].id;
                    if (_this.device === 'web') {
                        _this.upgradelink = "https://plus.anghami.com/subscribe/" + pId;
                    }
                    else {
                        _this.upgradelink = "https://www.anghami.com/openapp?deeplink=anghami://upgrade?mainplanid=" + pId;
                    }
                }
                else {
                    if (_this.device === 'web') {
                        _this.upgradelink = "https://plus.anghami.com";
                    }
                    else {
                        _this.upgradelink = "https://www.anghami.com/openapp?deeplink=anghami://upgrade";
                    }
                }
            }
        });
    };
    StudentsofferComponent.prototype.forceShowEmailForm = function () {
        this.state.email = true;
        this.state.activate = false;
        this.state.message = '';
        this.isicCardHolder = null;
        this.isicNumber = null;
    };
    StudentsofferComponent.prototype.showIsicForm = function () {
        this.state.isic = true;
        this.state.firstFlow = false;
        this.state.message = '';
        this.dob = null;
        this.email = null;
    };
    StudentsofferComponent.prototype.showBirthdayForm = function () {
        this.state.firstFlow = true;
        this.state.message = '';
        this.isicCardHolder = null;
        this.isicNumber = null;
    };
    StudentsofferComponent.prototype.openLoginDialog = function () {
        this.store.dispatch(new _core_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_12__["OpenCustomDialog"]({
            type: _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_13__["DIALOG_TYPES"].LOGIN
        }));
    };
    StudentsofferComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-landing-home',
            template: __webpack_require__(/*! raw-loader!./studentsoffer.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/studentsoffer/studentsoffer.component.html"),
            styles: [__webpack_require__(/*! ../../../core/components/inner-header/inner-header.component.scss */ "./src/app/core/components/inner-header/inner-header.component.scss"), __webpack_require__(/*! ./studentsoffer.component.scss */ "./src/app/modules/landing/studentsoffer/studentsoffer.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String, _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["ActionsSubject"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__["NgbCalendar"],
            _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_9__["UtilService"]])
    ], StudentsofferComponent);
    return StudentsofferComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/studentsoffer/studentsoffer.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/modules/landing/studentsoffer/studentsoffer.module.ts ***!
  \***********************************************************************/
/*! exports provided: StudentsofferModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudentsofferModule", function() { return StudentsofferModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _studentsoffer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./studentsoffer.component */ "./src/app/modules/landing/studentsoffer/studentsoffer.component.ts");
/* harmony import */ var _studentsoffer_route__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./studentsoffer.route */ "./src/app/modules/landing/studentsoffer/studentsoffer.route.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");









var StudentsofferModule = /** @class */ (function () {
    function StudentsofferModule() {
    }
    StudentsofferModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
                _studentsoffer_route__WEBPACK_IMPORTED_MODULE_6__["StudentsofferRoutingModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__["NgbModule"],
                _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_8__["LoadingModule"],
            ],
            declarations: [_studentsoffer_component__WEBPACK_IMPORTED_MODULE_5__["StudentsofferComponent"]],
            exports: [_studentsoffer_component__WEBPACK_IMPORTED_MODULE_5__["StudentsofferComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], StudentsofferModule);
    return StudentsofferModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/studentsoffer/studentsoffer.route.ts":
/*!**********************************************************************!*\
  !*** ./src/app/modules/landing/studentsoffer/studentsoffer.route.ts ***!
  \**********************************************************************/
/*! exports provided: routes, StudentsofferRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudentsofferRoutingModule", function() { return StudentsofferRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _studentsoffer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./studentsoffer.component */ "./src/app/modules/landing/studentsoffer/studentsoffer.component.ts");




var routes = [
    {
        path: '',
        component: _studentsoffer_component__WEBPACK_IMPORTED_MODULE_3__["StudentsofferComponent"]
    }
];
var StudentsofferRoutingModule = /** @class */ (function () {
    function StudentsofferRoutingModule() {
    }
    StudentsofferRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
            providers: []
        })
    ], StudentsofferRoutingModule);
    return StudentsofferRoutingModule;
}());



/***/ })

}]);