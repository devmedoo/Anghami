(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["manage-account-manage-account-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/download-app/download-app.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/download-app/download-app.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"os\">\n  <button #button [class.solid]=\"solid\" [ngClass]=\"{ onboarding: onboarding }\" (click)=\"downloadDesktopApp()\">\n    <ng-container *ngIf=\"os === 'mac'\" i18n=\"@@landing_bar_macapp\">Get Anghami for Mac</ng-container>\n    <ng-container *ngIf=\"os === 'windows'\" i18n=\"@@landing_bar_windowsapp\">Get Anghami for Windows</ng-container>\n  </button>\n</ng-container>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/manage-account/manage-account.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/manage-account/manage-account.component.html ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"manage-accounts-wrapper\">\n  <div>\n    <img\n      [src]=\"manageAccountsAssetsEnv + 'Header-Manage@2x.png'\"\n      class=\"manage-accounts-header-background\"\n    />\n  </div>\n  <div class=\"manage-accounts-header-text\" i18n=\"@@Manage Account\">\n    Manage Account\n  </div>\n  <div *ngIf=\"planDevices\" class=\"user-id\">#{{ planDevices.anid }}</div>\n  <div\n    class=\"login-text\"\n    i18n=\"@@Please login again to see your plan details\"\n    *ngIf=\"!(userLoggedIn$ | async)\"\n  >\n    Please login again to see your plan details\n  </div>\n  <div *ngIf=\"!(userLoggedIn$ | async)\">\n    <a href=\"/login?redirecturl=https://www.anghami.com/manage-account\"\n      ><button class=\"login-btn\" i18n=\"@@Login\">Login Now</button></a\n    >\n  </div>\n  <ng-container *ngIf=\"(planDevices && userLoggedIn$ | async)\">\n    <div\n      class=\"manage-accounts-card mt-2pt75\"\n      *ngIf=\"planDevices.plantype !== '3'\"\n    >\n      <div class=\"card-title-container\">\n        <div>\n          <span class=\"card-title\" i18n=\"@@Anghami\">Anghami </span>\n          <span class=\"card-title\">\n            {{ planDevices.planname }}\n          </span>\n        </div>\n      </div>\n      <div class=\"card-data-container\" *ngIf=\"planDevices.planenddate\">\n        <div class=\"card-data-title\" i18n=\"@@subscription_ends_in\">\n          SUBSCRIPTION ENDS ON\n        </div>\n        <div class=\"card-data-value\">\n          {{ planDevices.planenddate }}\n        </div>\n      </div>\n      <a class=\"plus-subscribe-link\" href=\"https://www.anghami.com/subscribe\">\n        <div class=\"get-plus-btn\">\n          <div>\n            <div class=\"plus-btn-body\" i18n=\"@@Get Anghami Plus\">\n              GET ANGHAMI PLUS\n            </div>\n          </div>\n          <div class=\"arrow-container\">\n            <img [src]=\"manageAccountsAssetsEnv + 'arrow.svg'\" />\n          </div>\n        </div>\n      </a>\n    </div>\n    <div\n      class=\"manage-accounts-card mt-2pt75\"\n      *ngIf=\"planDevices.plantype === '3'\"\n    >\n      <div class=\"card-title-container\">\n        <div>\n          <span class=\"card-title\">\n            {{ planDevices.planname }}\n          </span>\n          <div *ngIf=\"planDevices.status.warning\" class=\"purchase-warning\">\n            {{ planDevices.status.warning }}\n          </div>\n        </div>\n        <div\n          class=\"card-cancel-btn\"\n          i18n=\"@@Cancel\"\n          *ngIf=\"planDevices.plancanunsubscribe\"\n          (click)=\"toggleFirstCancellationModal()\"\n        >\n          Cancel\n        </div>\n        <ng-container\n          *ngIf=\"\n            planDevices.plancanreactivate && !planDevices.plancanunsubscribe\n          \"\n        >\n          <button\n            i18n=\"@@restore_subscription_button\"\n            class=\"card-restore-btn\"\n            (click)=\"toggleRestorePlan()\"\n          >\n            Restore\n          </button>\n        </ng-container>\n      </div>\n      <div class=\"family-plan-notice\" *ngIf=\"planDevices.familyplannotice\">\n        {{ planDevices.familyplannotice }}\n      </div>\n      <div class=\"card-data-container\" *ngIf=\"planDevices.planpaymenttype\">\n        <div class=\"card-data-title\" i18n=\"@@payment_method\">\n          PAYMENT METHOD\n        </div>\n        <div class=\"card-data-value\">\n          {{ planDevices.planpaymenttype }}\n        </div>\n      </div>\n      <div class=\"card-data-container\" *ngIf=\"planDevices.plancardinfo\">\n        <div class=\"card-data-title\" i18n=\"@@Card Details\">CARD DETAILS</div>\n        <div class=\"card-data-value direction-ltr\">\n          {{ 'XXXX XXXX XXXX ' + planDevices.plancardinfo.split(' ')[0] }}\n          <span\n            class=\"card-edit-btn\"\n            i18n=\"@@Edit\"\n            *ngIf=\"planDevices.plancanupdatecard\"\n            (click)=\"toggleUpdateCreditCard()\"\n            >Edit</span\n          >\n        </div>\n      </div>\n      <div class=\"card-data-container\">\n        <div\n          class=\"card-data-title\"\n          i18n=\"@@subscription_ends_in\"\n          *ngIf=\"!planDevices.status.end_date_action\"\n        >\n          SUBSCRIPTION ENDS ON\n        </div>\n        <div class=\"card-data-title\" *ngIf=\"planDevices.status.end_date_action\">\n          {{ planDevices.status.end_date_action }}\n        </div>\n        <div class=\"card-data-value\">\n          {{ planDevices.planenddate }}\n        </div>\n      </div>\n      <div class=\"card-data-container\" *ngIf=\"planDevices.status.display_text\">\n        <div class=\"card-data-title\" i18n=\"@@status\">STATUS</div>\n        <div [style.color]=\"planDevices.status.color\">\n          <img\n            class=\"status-icon\"\n            [src]=\"statusIcons[planDevices.status.color]\"\n          />{{ planDevices.status.display_text }}\n        </div>\n      </div>\n      <ng-container *ngIf=\"planDevices.planAllowsInvite\">\n        <div class=\"family-members-title\" i18n=\"@@family_member\">\n          FAMILY MEMBER\n        </div>\n        <ng-container *ngFor=\"let member of invitees\">\n          <div class=\"d-flex\">\n            <div class=\"invitee-old\">\n              <div class=\"member-name-container\">\n                {{ member.name | ellipsis }}\n              </div>\n              <div class=\"member-email-container\">\n                <input type='text' id='text-to-copy' [value]=\"member.email\" (click)=\"copyToClip(member.email)\" />\n                <!-- <button\n                  *ngIf=\"!validateEmail(member.email)\"\n                  class=\"copy-email-btn\"\n                  (click)=\"copyToClipboard(member.email)\"\n                >\n                  <img\n                    [src]=\"manageAccountsAssetsEnv + 'link.svg'\"\n                    class=\"link-icon\"\n                  />\n                  <span i18n=\"@@Copy\">Copy</span>\n                </button> -->\n              </div>\n            </div>\n            <div class=\"remove-invitee\" (click)=\"toggleRemoveModal(member)\">\n              <img [src]=\"manageAccountsAssetsEnv + 'x-grey.svg'\" />\n            </div>\n          </div>\n        </ng-container>\n        <ng-container *ngIf=\"isAddingFamilyMember\">\n          <div class=\"d-flex\">\n            <input\n              class=\"invitee-input\"\n              [(ngModel)]=\"inviteeInput\"\n              (keydown.enter)=\"addAccount()\"\n              [placeholder]=\"translations.addPlaceholder\"\n            />\n            <div\n              class=\"d-flex flex-column justify-content-center align-items-center mt-0pt875\"\n            >\n              <button class=\"add-individual-btn d-flex\" (click)=\"addAccount()\">\n                <img\n                  [src]=\"manageAccountsAssetsEnv + 'plus.svg'\"\n                  class=\"plus-icon-individual\"\n                /><span i18n=\"@@Add\">Add</span>\n              </button>\n            </div>\n          </div>\n        </ng-container>\n        <button\n          (click)=\"addAccount()\"\n          class=\"add-family-btn\"\n          i18n=\"@@add_family_members\"\n          *ngIf=\"showAddFamilyMemberButton && !isAddingFamilyMember\"\n        >\n          <img\n            [src]=\"manageAccountsAssetsEnv + 'plus.svg'\"\n            class=\"plus-icon-family\"\n          />\n          Add Family Member\n        </button>\n      </ng-container>\n    </div>\n  </ng-container>\n  <div\n    class=\"manage-accounts-card mt-1pt375\"\n    *ngFor=\"let purchase of purchases; idx as i\"\n  >\n    <div class=\"card-title-container\">\n      <div>\n        <span class=\"card-title\">\n          {{ purchase.plan_name }}\n        </span>\n        <span class=\"card-id\"></span>\n        <div *ngIf=\"purchase.status.warning\" class=\"purchase-warning\">\n          {{ purchase.status.warning }}\n        </div>\n      </div>\n      <ng-container *ngIf=\"purchase.is_cancellable\">\n        <div\n          class=\"card-cancel-btn\"\n          (click)=\"toggleCancelPurchase(purchase)\"\n          i18n=\"@@Cancel\"\n        >\n          Cancel\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"purchase.is_restartable\">\n        <button\n          i18n=\"@@restore_subscription_button\"\n          class=\"card-restore-btn\"\n          (click)=\"toggleRestorePurchase(purchase)\"\n        >\n          Restore\n        </button>\n      </ng-container>\n    </div>\n    <div class=\"card-data-container\">\n      <div class=\"card-data-title\" i18n=\"@@payment_method\">PAYMENT METHOD</div>\n      <div class=\"card-data-value\">{{ purchase.payment_method }}</div>\n    </div>\n    <div class=\"card-data-container\">\n      <div\n        class=\"card-data-title\"\n        i18n=\"@@subscription_ends_in\"\n        *ngIf=\"!purchase.status.end_date_action\"\n      >\n        SUBSCRIPTION ENDS ON\n      </div>\n      <div\n        class=\"card-data-title\"\n        i18n=\"@@subscription_ends_in\"\n        *ngIf=\"purchase.status.end_date_action\"\n      >\n        {{ purchase.status.end_date_action }}\n      </div>\n      <div class=\"card-data-value\">\n        {{ purchase.end_date | date: 'd MMMM, y' }}\n      </div>\n    </div>\n    <div class=\"card-data-container\">\n      <div class=\"card-data-title\" i18n=\"@@status\">STATUS</div>\n      <div [style.color]=\"purchase.status.color\">\n        <img class=\"status-icon\" [src]=\"statusIcons[purchase.status.color]\" />{{\n          purchase.status.display_text\n        }}\n      </div>\n    </div>\n  </div>\n  <div class=\"center-div giftcard\">\n    <div class=\"white-bgd padding-btm\">\n      <h1 i18n=\"@@subscreen_gift_title\">Give the gift of music</h1>\n      <h3 i18n=\"@@subscreen_gift_subtitle\">Be special, send to your loved ones music with no limits & no restrictions</h3>\n      <div class=\"button button-plus mainplanaction\">\n        <a href=\"https://www.anghami.com/gifts\" i18n=\"@@subscreen_gift_action\">Gift Anghami Plus</a>\n      </div>\n    </div>\n    <div class=\"relative-pos\">\n      <img class=\"wave\" [src]=\"landingAssetsEnv + 'WEB-FOOTER@2x.png'\">\n      <img class=\"gift\" [src]=\"manageAccountsAssetsEnv + 'giftcard.png'\">\n    </div>\n    <div class=\"redeem link\">\n      <a href=\"https://www.anghami.com/redeem\" i18n=\"@@subscreen_gift_f1\">Add promocode to redeem your gift </a>\n    </div>\n  </div>\n</div>\n\n<div\n  class=\"modal-container\"\n  *ngIf=\"\n    isModalToggled.removeAccount ||\n    isModalToggled.cancelPlusFirst ||\n    isModalToggled.cancelPlusSecond ||\n    isModalToggled.updateCreditCard ||\n    isModalToggled.cancelPurchase ||\n    isModalToggled.restorePurchase ||\n    isModalToggled.restorePlan\n  \"\n>\n  <div class=\"semi-opaque-bg\" (click)=\"closeModal()\"></div>\n  <div class=\"alert-remove-modal\" *ngIf=\"isModalToggled.removeAccount\">\n    <div class=\"alert-remove-title\">\n      <img [src]=\"manageAccountsAssetsEnv + 'warning.svg'\" />\n      <span i18n=\"@@alert\" class=\"text-uppercase\">ALERT</span>\n    </div>\n    <div class=\"alert-remove-text\">\n      {{ translations.removeNameFirst }}\"{{\n        accountBeingRemoved.name\n          ? (accountBeingRemoved.name | ellipsis)\n          : accountBeingRemoved.email\n      }}\"{{ translations.removeNameSecond }}\n    </div>\n    <div class=\"alert-remove-btn-container\">\n      <button\n        class=\"alert-remove-btn yes\"\n        (click)=\"removeAccount(accountBeingRemoved.email)\"\n      >\n        <span i18n=\"@@Yes\">Yes</span>\n      </button>\n      <button class=\"alert-remove-btn no\" (click)=\"closeModal()\">\n        <span i18n=\"@@No\">No</span>\n      </button>\n    </div>\n  </div>\n  <div class=\"alert-remove-modal\" *ngIf=\"isModalToggled.cancelPlusFirst\">\n    <div class=\"cancellation-title\">\n      <span i18n=\"@@You are currently subscribed to %@\"></span>\n      <span i18n=\"@@Anghami Plus\">Anghami Plus</span>\n    </div>\n    <div\n      class=\"cancellation-text\"\n      i18n=\"@@Are you sure you want to cancel your current subscription?\"\n    >\n      Are you sure you want to cancel your current subscription?\n    </div>\n    <button\n      class=\"cancellation-stay-btn\"\n      (click)=\"closeModal()\"\n      i18n=\"@@Stay on Plus\"\n    >\n      Stay on Plus\n    </button>\n    <div\n      class=\"cancellation-cancel-btn\"\n      (click)=\"toggleSecondCancellationModal()\"\n      i18n=\"@@Cancel subscription\"\n    >\n      Cancel subscription\n    </div>\n  </div>\n  <div class=\"alert-remove-modal\" *ngIf=\"isModalToggled.cancelPlusSecond\">\n    <div class=\"cancellation-title\" i18n=\"@@Cancel subscription\">\n      Cancel Subscription\n    </div>\n    <img [src]=\"manageAccountsAssetsEnv + 'cancel-icon.png'\" class=\"mt-0pt5\" />\n    <div\n      class=\"cancellation-text\"\n      i18n=\"@@Oh no! You’ll lose all your downloads once you cancel your subscription\"\n    >\n      Oh no! You’ll lose all your downloads when you cancel your subscription\n    </div>\n    <button\n      class=\"cancellation-stay-btn\"\n      (click)=\"closeModal()\"\n      i18n=\"@@Keep my downloads\"\n    >\n      Keep my downloads\n    </button>\n    <div\n      class=\"cancellation-cancel-btn\"\n      (click)=\"goToCancel()\"\n      i18n=\"@@Proceed with cancellation\"\n    >\n      Proceed with cancellation\n    </div>\n  </div>\n  <div class=\"alert-remove-modal\" *ngIf=\"isModalToggled.cancelPurchase\">\n    <div class=\"cancellation-title\">\n      <span i18n=\"@@You are currently subscribed to %@\"\n        >You are currently subscribed to</span\n      >{{ ' ' + purchaseBeingCancelled.plan_name }}\n    </div>\n    <div\n      class=\"cancellation-text\"\n      i18n=\"@@Are you sure you want to cancel your current subscription?\"\n    >\n      Are you sure you want to cancel your current subscription?\n    </div>\n    <button\n      class=\"cancellation-stay-btn\"\n      (click)=\"closeModal()\"\n      i18n=\"@@keep_watching\"\n    >\n      Keep Watching\n    </button>\n    <div\n      class=\"cancellation-cancel-btn\"\n      (click)=\"managePurchase('cancel', purchaseBeingCancelled)\"\n      i18n=\"@@Cancel subscription\"\n    >\n      Cancel subscription\n    </div>\n  </div>\n  <div class=\"alert-remove-modal\" *ngIf=\"isModalToggled.restorePurchase\">\n    <div class=\"cancellation-title\">\n      <span i18n=\"@@restore_subscription_button\">Restore</span>?\n    </div>\n    <div class=\"cancellation-text\">\n      <span i18n=\"@@restore_subscription_desc\"\n        >Your subscription will be restored. Your next charge will be on</span\n      >\n      {{ purchaseBeingRestored.end_date | date: 'd MMMM, y' }}\n    </div>\n    <button\n      class=\"cancellation-stay-btn\"\n      (click)=\"managePurchase('restart', purchaseBeingRestored)\"\n    >\n      <span i18n=\"@@restore_subscription_button\">Restore</span>\n    </button>\n    <div\n      class=\"cancellation-cancel-btn\"\n      (click)=\"closeModal()\"\n      i18n=\"@@keep_sub_cancelled\"\n    >\n      Cancel\n    </div>\n  </div>\n  <div class=\"alert-remove-modal\" *ngIf=\"isModalToggled.restorePlan\">\n    <div class=\"cancellation-title\">\n      <span i18n=\"@@restore_subscription_button\">Restore</span>?\n    </div>\n    <div class=\"cancellation-text\">\n      <span i18n=\"@@restore_subscription_desc\"\n        >Your subscription will be restored. Your next charge will be on</span\n      >\n      {{ planDevices.planenddate }}\n    </div>\n    <button class=\"cancellation-stay-btn\" (click)=\"reactivatePlanDevices()\">\n      <span i18n=\"@@restore_subscription_button\">Restore</span>\n    </button>\n    <div\n      class=\"cancellation-cancel-btn\"\n      (click)=\"closeModal()\"\n      i18n=\"@@keep_sub_cancelled\"\n    >\n      Cancel\n    </div>\n  </div>\n  <div class=\"alert-remove-modal\" *ngIf=\"isModalToggled.updateCreditCard\">\n    <anghami-payment-form\n      [submitText]=\"'Update'\"\n      [isUpdateForm]=\"true\"\n      (success)=\"updateCreditCardSuccess($event)\"\n    ></anghami-payment-form>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/core/components/download-app/download-app.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/download-app/download-app.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  cursor: pointer;\n  display: inline-block;\n}\n:host .onboarding {\n  background-color: #8d00f2;\n  color: #fff !important;\n  border-radius: 1.375rem !important;\n  box-shadow: none !important;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  border: none;\n  width: 14rem;\n  height: 2.75rem;\n  margin-top: 2rem;\n}\n:host:not(.footer) {\n  margin: 0 0.5em;\n}\n:host.footer {\n  margin: 1em 0;\n}\n:host button {\n  margin: 0;\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n  border: none;\n  background: none;\n  min-width: 11.5em;\n}\n:host button.link {\n  color: white;\n  box-shadow: none;\n  padding: 0;\n  font-weight: 700;\n}\n:host button.link.solid {\n  color: var(--text-color);\n}\n:host button:not(.link) {\n  box-shadow: inset 0 0 0 1px var(--text-color);\n  color: var(--text-color);\n  border-radius: 3em;\n}\n:host button.header {\n  font-size: 1em;\n  box-shadow: inset 0 0 0 1px var(--brand-purple);\n  color: var(--brand-purple);\n}"

/***/ }),

/***/ "./src/app/core/components/download-app/download-app.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/download-app/download-app.component.ts ***!
  \************************************************************************/
/*! exports provided: DownloadAppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadAppComponent", function() { return DownloadAppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _anghami_services_desktop_client_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/desktop-client.service */ "./src/app/core/services/desktop-client.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../app/core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _refrences_WindowRef__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../refrences/WindowRef */ "./src/app/core/refrences/WindowRef.ts");








var DownloadAppComponent = /** @class */ (function () {
    function DownloadAppComponent(element, window, store, desktopClientService, platformId) {
        this.element = element;
        this.window = window;
        this.store = store;
        this.desktopClientService = desktopClientService;
        this.platformId = platformId;
    }
    DownloadAppComponent.prototype.ngOnInit = function () {
        if (!this.window.nativeWindow ||
            !this.window.nativeWindow.navigator ||
            this.desktopClientService.isDesktopClient) {
            this.os = null;
            return;
        }
        this.os = this.getOSName();
    };
    DownloadAppComponent.prototype.ngAfterViewInit = function () {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            if (this.type === 'footer') {
                this.element.nativeElement.classList.add(this.type);
            }
            if (this.type !== 'link' && this.button && this.button.nativeElement) {
                this.button.nativeElement.classList.add('btn');
                this.button.nativeElement.classList.add('primary');
            }
            if (this.button && this.button.nativeElement) {
                this.button.nativeElement.classList.add(this.type);
            }
        }
    };
    DownloadAppComponent.prototype.getOSName = function () {
        return this.window.nativeWindow.navigator.userAgent.indexOf('Windows') !== -1
            ? 'windows'
            : this.window.nativeWindow.navigator.userAgent.indexOf('Mac') !== -1
                ? 'mac'
                : null;
    };
    DownloadAppComponent.prototype.downloadDesktopApp = function () {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
            name: _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_6__["AmplitudeEvents"].downloadDesktopApp,
            props: { os: this.os, source: this.onboarding ? 'onboarding' : 'other' }
        }));
        this.window.nativeWindow.open("/download");
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], DownloadAppComponent.prototype, "type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], DownloadAppComponent.prototype, "solid", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], DownloadAppComponent.prototype, "onboarding", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"])('button', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"])
    ], DownloadAppComponent.prototype, "button", void 0);
    DownloadAppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'anghami-download-app',
            template: __webpack_require__(/*! raw-loader!./download-app.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/download-app/download-app.component.html"),
            styles: [__webpack_require__(/*! ./download-app.component.scss */ "./src/app/core/components/download-app/download-app.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"],
            _refrences_WindowRef__WEBPACK_IMPORTED_MODULE_7__["WindowRef"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
            _anghami_services_desktop_client_service__WEBPACK_IMPORTED_MODULE_2__["DesktopClientService"],
            Object])
    ], DownloadAppComponent);
    return DownloadAppComponent;
}());



/***/ }),

/***/ "./src/app/core/components/download-app/download-app.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/download-app/download-app.module.ts ***!
  \*********************************************************************/
/*! exports provided: DownloadAppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadAppModule", function() { return DownloadAppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _download_app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./download-app.component */ "./src/app/core/components/download-app/download-app.component.ts");




var DownloadAppModule = /** @class */ (function () {
    function DownloadAppModule() {
    }
    DownloadAppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
            declarations: [_download_app_component__WEBPACK_IMPORTED_MODULE_3__["DownloadAppComponent"]],
            exports: [_download_app_component__WEBPACK_IMPORTED_MODULE_3__["DownloadAppComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], DownloadAppModule);
    return DownloadAppModule;
}());



/***/ }),

/***/ "./src/app/core/redux/effects/manage-account.effects.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/redux/effects/manage-account.effects.ts ***!
  \**************************************************************/
/*! exports provided: ManageAccountEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageAccountEffects", function() { return ManageAccountEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _services_manage_account_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/manage-account.service */ "./src/app/core/services/manage-account.service.ts");
/* harmony import */ var _actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/manage-account.actions */ "./src/app/core/redux/actions/manage-account.actions.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _anghami_redux_actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/actions/error-handling.actions */ "./src/app/core/redux/actions/error-handling.actions.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");










var ManageAccountEffects = /** @class */ (function () {
    function ManageAccountEffects(actions$, manageAccountService, store) {
        var _this = this;
        this.actions$ = actions$;
        this.manageAccountService = manageAccountService;
        this.store = store;
        this.getPurchases$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_4__["ManageAccountActionTypes"].GetPurchases), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (action) { return action.payload; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["withLatestFrom"])(this.store.select(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_8__["getUser"])), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (_a) {
            var params = _a[0], userData = _a[1];
            var newParams = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, params, { appsid: userData.socketsessionid });
            return _this.manageAccountService.getPurchases(newParams).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (response) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_4__["GetPurchasesSuccess"](response));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_7__["EffectError"]());
            }));
        }));
        this.managePurchases$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_4__["ManageAccountActionTypes"].ManagePurchases), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (action) { return action.payload; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (params) {
            return _this.manageAccountService.managePurchases(params).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (response) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_4__["ManagePurchasesSuccess"](response));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_7__["EffectError"]());
            }));
        }));
        this.getPlanDevices$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_4__["ManageAccountActionTypes"].GetPlanDevices), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (action) { return action.payload; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["withLatestFrom"])(this.store.select(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_8__["getUser"])), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (_a) {
            var params = _a[0], userData = _a[1];
            var newParams = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, params, { appsid: userData.socketsessionid });
            return _this.manageAccountService.getPlanDevices(newParams).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (response) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_4__["GetPlanDevicesSuccess"](response));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_7__["EffectError"]());
            }));
        }));
        this.UpdateCreditCardInfo$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_4__["ManageAccountActionTypes"].UpdateCreditCardInfo), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (action) { return action.payload; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (params) {
            return _this.manageAccountService.updateCreditCardInfo(params).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (response) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_4__["UpdateCreditCardInfoSuccess"](response));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _anghami_redux_actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_7__["EffectError"]());
            }));
        }));
    }
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ManageAccountEffects.prototype, "getPurchases$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ManageAccountEffects.prototype, "managePurchases$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ManageAccountEffects.prototype, "getPlanDevices$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ManageAccountEffects.prototype, "UpdateCreditCardInfo$", void 0);
    ManageAccountEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"],
            _services_manage_account_service__WEBPACK_IMPORTED_MODULE_3__["ManageAccountService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_9__["Store"]])
    ], ManageAccountEffects);
    return ManageAccountEffects;
}());



/***/ }),

/***/ "./src/app/core/services/manage-account.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/services/manage-account.service.ts ***!
  \*********************************************************/
/*! exports provided: ManageAccountService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageAccountService", function() { return ManageAccountService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm5/ngx-cookie.js");








var ManageAccountService = /** @class */ (function () {
    function ManageAccountService(store, http, _cookieService) {
        this.store = store;
        this.http = http;
        this._cookieService = _cookieService;
    }
    //TODO: refactor this nasty piece of code
    ManageAccountService.prototype.getPlanDevices = function (params) {
        var fp = this._cookieService.get('fingerprint');
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        body = body.set('type', 'GETplandevices').set('fingerprint', fp);
        for (var _i = 0, _a = Object.keys(params); _i < _a.length; _i++) {
            var key = _a[_i];
            if (!!params[key]) {
                body = body.set(key, params[key]);
            }
        }
        return this.http.get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].API_URL, { params: body }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(err); }));
    };
    ManageAccountService.prototype.getPurchases = function (params) {
        var fp = this._cookieService.get('fingerprint');
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        body = body.set('type', 'GETpurchases').set('fingerprint', fp);
        for (var _i = 0, _a = Object.keys(params); _i < _a.length; _i++) {
            var key = _a[_i];
            if (!!params[key]) {
                body = body.set(key, params[key]);
            }
        }
        return this.http.get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].API_URL, { params: body }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(err); }));
    };
    ManageAccountService.prototype.managePurchases = function (params) {
        var fp = this._cookieService.get('fingerprint');
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        body = body
            .set('type', 'MANAGEpurchase')
            .set('fingerprint', fp)
            .set('action', params.action)
            .set('purchase_id', params.purchaseID);
        return this.http
            .put("" + _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].API_URL, {}, { params: body })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(err); }));
    };
    ManageAccountService.prototype.updateCreditCardInfo = function (params) {
        var fp = this._cookieService.get('fingerprint');
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        body = body
            .set('type', 'GETplandevices')
            .set('fingerprint', fp)
            .set('ccnumber', params.ccnumber)
            .set('ccmonth', params.ccmonth)
            .set('ccyear', params.ccyear)
            .set('cvv', params.cvv)
            .set('fullname', params.fullname)
            .set('updatecard', '1');
        return this.http.get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].API_URL, { params: body }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(err); }));
    };
    ManageAccountService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            ngx_cookie__WEBPACK_IMPORTED_MODULE_7__["CookieService"]])
    ], ManageAccountService);
    return ManageAccountService;
}());



/***/ }),

/***/ "./src/app/modules/landing/manage-account/manage-account-routing.module.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/modules/landing/manage-account/manage-account-routing.module.ts ***!
  \*********************************************************************************/
/*! exports provided: routes, ManageAccountRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageAccountRoutingModule", function() { return ManageAccountRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _manage_account_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./manage-account.component */ "./src/app/modules/landing/manage-account/manage-account.component.ts");




var routes = [
    {
        path: '',
        component: _manage_account_component__WEBPACK_IMPORTED_MODULE_3__["ManageAccountComponent"],
        children: [
            {
                path: '',
                component: _manage_account_component__WEBPACK_IMPORTED_MODULE_3__["ManageAccountComponent"]
            },
            {
                path: ':unsubscribed',
                component: _manage_account_component__WEBPACK_IMPORTED_MODULE_3__["ManageAccountComponent"]
            }
        ]
    }
];
var ManageAccountRoutingModule = /** @class */ (function () {
    function ManageAccountRoutingModule() {
    }
    ManageAccountRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], ManageAccountRoutingModule);
    return ManageAccountRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/manage-account/manage-account.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/modules/landing/manage-account/manage-account.component.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@-webkit-keyframes modal-appearance {\n  0% {\n    -webkit-transform: translateY(-25%);\n            transform: translateY(-25%);\n    opacity: 0;\n  }\n  50% {\n    opacity: 1;\n  }\n  100% {\n    -webkit-transform: translateY(0%);\n            transform: translateY(0%);\n    opacity: 1;\n  }\n}\n@keyframes modal-appearance {\n  0% {\n    -webkit-transform: translateY(-25%);\n            transform: translateY(-25%);\n    opacity: 0;\n  }\n  50% {\n    opacity: 1;\n  }\n  100% {\n    -webkit-transform: translateY(0%);\n            transform: translateY(0%);\n    opacity: 1;\n  }\n}\n.mt-2pt75 {\n  margin-top: 2.75rem;\n}\n.mt-0pt875 {\n  margin-top: 0.875rem;\n}\n.mt-1pt375 {\n  margin-top: 1.375rem;\n}\n.mt-0pt5 {\n  margin-top: 0.5rem;\n}\n.direction-ltr {\n  direction: ltr !important;\n}\n.link-icon {\n  width: 0.625rem;\n  margin-right: 0.125rem;\n  margin-left: 0.125rem;\n}\n.plus-icon-individual {\n  width: 0.5625rem;\n  margin-right: 0.25rem;\n  margin-left: 0.25rem;\n  margin-top: 0.125rem;\n}\n.plus-icon-family {\n  width: 0.5625rem;\n  margin-right: 0.6875rem;\n}\n.family-plan-notice {\n  color: #626262;\n  font-size: 1rem;\n  margin-top: 0.65rem;\n}\n.plus-subscribe-link {\n  text-decoration: none;\n}\n.plus-subscribe-link:hover {\n  text-decoration: none;\n}\n.plus-subscribe-link:focus {\n  text-decoration: none;\n}\n.user-id {\n  color: white;\n  font-size: 1.2rem;\n}\n.login-text {\n  color: white;\n  font-size: 1.2rem;\n  font-weight: lighter;\n  margin-top: 1rem;\n}\n.login-btn {\n  border-radius: 27px;\n  border: none;\n  font-weight: bold;\n  font-size: 1rem;\n  padding: 0.5em 3rem;\n  margin-top: 1.5rem;\n  color: #000;\n  background: #fff;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n}\n.semi-opaque-bg {\n  position: fixed;\n  height: 100vh;\n  width: 100%;\n  top: 0;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  z-index: 2;\n  background: #000000;\n  opacity: 0.6;\n}\n.modal-container {\n  position: absolute;\n  height: 100vh;\n  width: 100%;\n  top: 0;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  z-index: 1;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n.modal-container .alert-remove-modal {\n  width: 88%;\n  max-width: 42.625rem;\n  background-color: white;\n  border-radius: 0.5625rem;\n  padding-left: 1.5rem;\n  padding-right: 1.5rem;\n  padding-top: 1.125rem;\n  padding-bottom: 1.125rem;\n  position: relative;\n  z-index: 3;\n  text-align: center;\n  -webkit-animation: modal-appearance 0.3s ease-out forwards;\n          animation: modal-appearance 0.3s ease-out forwards;\n}\n.modal-container .alert-remove-modal .alert-remove-title {\n  color: #ff0233;\n  font-size: 1.1rem;\n  margin-top: 0.375rem;\n}\n.modal-container .alert-remove-modal .alert-remove-text {\n  font-size: 1rem;\n  margin-top: 0.5rem;\n}\n.modal-container .alert-remove-modal .alert-remove-btn-container {\n  margin-top: 1rem;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n.modal-container .alert-remove-modal .alert-remove-btn-container .alert-remove-btn {\n  border: 1px solid #8d00f5;\n  border-radius: 1.25rem;\n  font-size: 0.75rem;\n  width: 5rem;\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n  margin-left: 0.25rem;\n  margin-right: 0.25rem;\n}\n.modal-container .alert-remove-modal .alert-remove-btn-container .yes {\n  background-color: white;\n  color: #8d00f5;\n}\n.modal-container .alert-remove-modal .alert-remove-btn-container .no {\n  background-color: #8d00f5;\n  color: white;\n}\n.modal-container .alert-remove-modal .cancellation-title {\n  font-size: 1.5em;\n  font-weight: 900;\n}\n.modal-container .alert-remove-modal .cancellation-text {\n  margin-top: 1em;\n}\n.modal-container .alert-remove-modal .cancellation-stay-btn {\n  font-weight: 600;\n  border-radius: 32px;\n  background: #92278f;\n  color: #fff;\n  padding: 0.5em 1.5em;\n  font-size: 1.15em;\n  margin: 0.5em auto;\n  border: none;\n}\n.modal-container .alert-remove-modal .cancellation-cancel-btn {\n  text-decoration: underline !important;\n  font-size: 1em;\n  cursor: pointer;\n}\n.manage-accounts-wrapper {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.manage-accounts-wrapper .manage-accounts-header-background {\n  height: 20rem;\n  width: 100%;\n  overflow: hidden;\n  position: absolute;\n  width: 100%;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: -1;\n}\n.manage-accounts-wrapper .manage-accounts-header-background img {\n  position: absolute;\n  width: 100%;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: -1;\n}\n.manage-accounts-wrapper .manage-accounts-header-text {\n  margin-top: 7.5rem;\n  font-size: 2.625rem;\n  font-weight: bold;\n  color: white;\n}\n.manage-accounts-wrapper .manage-accounts-card {\n  background-color: white;\n  border-radius: 0.5625rem;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n  padding-left: 1.5rem;\n  padding-right: 1.5rem;\n  padding-top: 1.125rem;\n  padding-bottom: 1.125rem;\n  width: 88%;\n  max-width: 42.625rem;\n}\n.manage-accounts-wrapper .manage-accounts-card .card-title-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n.manage-accounts-wrapper .manage-accounts-card .card-title-container .card-title {\n  font-size: 1.3125rem;\n  color: black;\n  font-weight: 500;\n}\n@media only screen and (max-width: 400px) {\n  .manage-accounts-wrapper .manage-accounts-card .card-title-container .card-title {\n    font-size: 1.1rem;\n  }\n}\n.manage-accounts-wrapper .manage-accounts-card .card-title-container .card-id {\n  font-size: 0.75rem;\n  color: black;\n  opacity: 0.7;\n}\n.manage-accounts-wrapper .manage-accounts-card .card-title-container .purchase-warning {\n  background-color: #ff0233;\n  color: white;\n  max-width: 8rem;\n  text-align: center;\n  text-transform: uppercase;\n  border-radius: 0.25rem;\n}\n.manage-accounts-wrapper .manage-accounts-card .card-title-container .card-cancel-btn {\n  font-size: 0.75rem;\n  text-decoration: underline;\n  opacity: 0.6;\n  cursor: pointer;\n  color: #000000;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n.manage-accounts-wrapper .manage-accounts-card .card-title-container .card-restore-btn {\n  border-radius: 1.25rem;\n  background-color: #8d00f5;\n  font-size: 0.8125rem;\n  border: none;\n  color: white;\n  padding-left: 0.875rem;\n  padding-right: 0.875rem;\n  max-height: 2rem;\n}\n.manage-accounts-wrapper .manage-accounts-card .family-members-title {\n  font-size: 0.875rem;\n  color: black;\n  opacity: 0.7;\n  margin-top: 1.375rem;\n}\n.manage-accounts-wrapper .manage-accounts-card .invitee-old {\n  border-radius: 0.625rem;\n  background-color: #eaeaea;\n  padding-left: 1.25rem;\n  padding-right: 0.625rem;\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n  border: none;\n  margin-top: 0.625rem;\n  width: 95%;\n}\n@media only screen and (max-width: 400px) {\n  .manage-accounts-wrapper .manage-accounts-card .invitee-old {\n    padding-left: 0.75rem;\n  }\n}\n.manage-accounts-wrapper .manage-accounts-card .invitee-old .member-name-container {\n  font-weight: 400;\n}\n.manage-accounts-wrapper .manage-accounts-card .invitee-old .member-email-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n.manage-accounts-wrapper .manage-accounts-card .invitee-old .member-email-container input {\n  border: none;\n  background-image: none;\n  background-color: transparent;\n  box-shadow: none;\n}\n.manage-accounts-wrapper .manage-accounts-card .invitee-old .member-email-container .copy-email-btn {\n  background-color: #b2b2b2;\n  font-size: 0.625rem;\n  border: none;\n  border-radius: 1rem;\n  color: white;\n  padding-top: 6px;\n  padding-bottom: 6px;\n  padding-right: 10px;\n  padding-left: 8px;\n  -webkit-transition: all 0.3s;\n  transition: all 0.3s;\n}\n.manage-accounts-wrapper .manage-accounts-card .invitee-old .member-email-container .copy-email-btn:hover {\n  padding-top: 8px;\n  padding-bottom: 8px;\n  padding-right: 14px;\n  padding-left: 12px;\n  font-weight: 700;\n}\n.manage-accounts-wrapper .manage-accounts-card .invitee-input {\n  border-radius: 0.625rem;\n  padding-left: 1.25rem;\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n  margin-top: 0.875rem;\n  border: #dedede solid 1px;\n  width: 95%;\n}\n.manage-accounts-wrapper .manage-accounts-card .remove-invitee {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding-left: 0.75rem;\n  padding-right: 0.75rem;\n  margin-top: 0.625rem;\n}\n.manage-accounts-wrapper .manage-accounts-card .remove-invitee img {\n  width: 0.75rem;\n  cursor: pointer;\n}\n.manage-accounts-wrapper .manage-accounts-card .add-family-btn {\n  background-color: #0099f5;\n  border-radius: 1.25rem;\n  border: none;\n  color: white;\n  margin-top: 0.875rem;\n  font-size: 0.75rem;\n  padding-top: 0.75rem;\n  padding-bottom: 0.75rem;\n  padding-left: 1.5rem;\n  padding-right: 1.5rem;\n}\n.manage-accounts-wrapper .manage-accounts-card .add-individual-btn {\n  background-color: #8d00f5;\n  border-radius: 1.5rem;\n  max-height: 1.5rem;\n  border: none;\n  padding-right: 10px;\n  padding-left: 8px;\n  color: white;\n  -webkit-transform: translatex(-115%);\n      -ms-transform: translatex(-115%);\n          transform: translatex(-115%);\n  font-size: 0.625rem;\n}\n.manage-accounts-wrapper .manage-accounts-card .get-plus-btn {\n  margin-top: 1.25rem;\n  border-radius: 0.4375rem;\n  color: white;\n  padding-left: 1rem;\n  padding-right: 1rem;\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n  background-image: -webkit-gradient(linear, left top, right top, from(#007bc4), to(#0099f5));\n  background-image: linear-gradient(to right, #007bc4, #0099f5);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  cursor: pointer;\n}\n.manage-accounts-wrapper .manage-accounts-card .get-plus-btn .plus-btn-title {\n  font-size: 0.9rem;\n}\n.manage-accounts-wrapper .manage-accounts-card .get-plus-btn .plus-btn-body {\n  font-size: 0.9rem;\n}\n.manage-accounts-wrapper .manage-accounts-card .get-plus-btn .arrow-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.manage-accounts-wrapper .card-data-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  margin-top: 0.75rem;\n  padding-bottom: 0.5rem;\n}\n.manage-accounts-wrapper .card-data-container .card-data-title {\n  text-transform: uppercase;\n  font-size: 0.875rem;\n  color: black;\n  opacity: 0.7;\n}\n.manage-accounts-wrapper .card-data-container .card-data-value {\n  font-size: 0.875rem;\n  color: black;\n  font-weight: 500;\n}\n.manage-accounts-wrapper .card-data-container .card-data-value .card-edit-btn {\n  font-size: 0.6875rem;\n  text-decoration: underline;\n  opacity: 0.6;\n  cursor: pointer;\n  color: #000000;\n}\n.manage-accounts-wrapper .card-data-container .status-icon {\n  width: 0.75rem;\n  margin-right: 0.25rem;\n}\n@media only screen and (min-width: 765px) {\n  .card-data-container {\n    border-bottom: solid 1px rgba(0, 0, 0, 0.1);\n  }\n\n  .card-data-container:last-child {\n    border-bottom: none;\n  }\n}\nhtml[lang=ar] :host .status-icon {\n  width: 0.75rem;\n  margin-left: 0.25rem;\n}\nhtml[lang=ar] :host .add-family-btn {\n  float: right;\n}\nhtml[lang=ar] :host .family-members-title {\n  text-align: right;\n}\nhtml[lang=ar] :host .member-name-container {\n  text-align: right;\n}\nhtml[lang=ar] :host .card-edit-btn {\n  line-height: 1.75em;\n  padding-right: 0.5em;\n  float: left;\n}\nhtml[lang=ar] :host .add-individual-btn {\n  -webkit-transform: translatex(115%) !important;\n      -ms-transform: translatex(115%) !important;\n          transform: translatex(115%) !important;\n}\n.redeem {\n  padding: 0.5em 0 3em 0;\n}\n.center-div {\n  text-align: center;\n}\n.displayInlineBlock {\n  display: inline-block;\n}\n.height4 {\n  height: 4em;\n}\n.height2 {\n  height: 2em;\n}\n.planbenefits {\n  margin: 0 1em;\n  height: 8em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n.content .center-div {\n  margin: auto 1em;\n}\n.err {\n  font-size: 0.8em;\n  color: red;\n  margin: 0.5em 1em;\n  text-align: center;\n}\n.plan-loader {\n  max-width: 2em;\n  padding: 0.2em;\n}\n.padding0 {\n  padding: 0em !important;\n}\n.header-box {\n  height: 8em;\n}\n.margin03 {\n  margin: 0 3em;\n}\n.white-bgd {\n  background-color: #ffffff;\n}\n.padding-btm {\n  padding-bottom: 1em;\n}\n.giftcard {\n  background-color: #F2F5F7;\n  margin-top: 1em;\n  margin-bottom: 9em;\n  width: 100%;\n}\n.giftcard .relative-pos {\n  position: relative;\n  background: #ffffff;\n}\n.giftcard .relative-pos .wave {\n  width: 100%;\n  height: 18em;\n  position: absolute;\n  left: 0;\n  z-index: 0;\n}\n.giftcard .relative-pos .gift {\n  position: relative;\n  /* left: 0; */\n  /* right: 0; */\n  /* bottom: 19em; */\n  max-width: 30em;\n  margin: auto;\n}\n@media (max-width: 480px) {\n  .giftcard .relative-pos .gift {\n    max-width: 17em;\n  }\n}\n.giftcard h1 {\n  padding-top: 2em;\n  font-size: 2em !important;\n  font-weight: 600 !important;\n  margin: 0em auto !important;\n}\n.giftcard h3 {\n  color: #a5aeb5;\n  margin-right: auto;\n  margin-left: auto;\n  text-align: center;\n  margin: 0.5em auto 1em auto !important;\n  width: 40%;\n  font-size: 1.5em;\n}\n@media (max-width: 480px) {\n  .giftcard h3 {\n    width: 75%;\n  }\n}\n.giftcard .button {\n  border-radius: 2em;\n  text-align: center;\n  font-size: 1.1em;\n  font-weight: 600;\n  padding: 0.5em 1em;\n  cursor: pointer;\n}\n.giftcard .button-plus {\n  color: #007FFE;\n  display: inline-block;\n  font-weight: 500;\n  display: block;\n  max-width: 12em;\n  border: 1px solid;\n  -webkit-transition: all 200ms ease-in;\n  transition: all 200ms ease-in;\n  margin: 0 auto !important;\n}\n.giftcard .button-plus a {\n  text-decoration: none;\n  color: white;\n}\n.giftcard .button-plus:hover {\n  background: #007FFE;\n  color: #FFF;\n}\n@media (min-width: 1024px) {\n  .giftcard .button-plus {\n    font-size: 1.2em;\n  }\n}\n.giftcard .button-plus.mainplanaction {\n  background: -webkit-gradient(linear, left top, right top, from(#007FFE), to(#01B5FF));\n  background: linear-gradient(to right, #007FFE, #01B5FF);\n  color: white;\n  border-color: transparent;\n  -webkit-transition: all 200ms ease-in;\n  transition: all 200ms ease-in;\n}\n.giftcard .button-plus.mainplanaction:hover {\n  box-shadow: 0px 0px 38px -3px rgba(204, 204, 204, 0.99);\n}\n.giftcard .link {\n  text-decoration: underline;\n  font-weight: 500;\n  cursor: pointer;\n  font-size: 1.2em;\n  position: relative;\n}\n.giftcard .link a {\n  color: black !important;\n}"

/***/ }),

/***/ "./src/app/modules/landing/manage-account/manage-account.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/modules/landing/manage-account/manage-account.component.ts ***!
  \****************************************************************************/
/*! exports provided: ManageAccountComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageAccountComponent", function() { return ManageAccountComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _core_services_copy_to_clipboard_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../core/services/copy-to-clipboard.service */ "./src/app/core/services/copy-to-clipboard.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/services/deeplinks.service */ "./src/app/core/services/deeplinks.service.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/redux/actions/manage-account.actions */ "./src/app/core/redux/actions/manage-account.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");















var ManageAccountComponent = /** @class */ (function () {
    function ManageAccountComponent(locale, store, _utilService, _deeplinkService, _translateService, _actionsSubject, route, copyToClipboard) {
        this.locale = locale;
        this.store = store;
        this._utilService = _utilService;
        this._deeplinkService = _deeplinkService;
        this._translateService = _translateService;
        this._actionsSubject = _actionsSubject;
        this.route = route;
        this.copyToClipboard = copyToClipboard;
        this.env = _environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].assetsCDN + "img/landing/";
        this.manageAccountsAssetsEnv = _environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].assetsCDN + "img/manageaccount/";
        this.landingAssetsEnv = _environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].assetsCDN + "img/landing/";
        this.isAddingFamilyMember = false;
        this.showAddFamilyMemberButton = false;
        this.isModalToggled = {
            removeAccount: false,
            cancelPlusFirst: false,
            cancelPlusSecond: false,
            updateCreditCard: false,
            cancelPurchase: false,
            restorePurchase: false,
            restorePlan: false
        };
        this.translations = {
            add: '',
            copy: '',
            yes: '',
            no: '',
            subscriptionEndsOn: '',
            currentlySubscribedTo: '',
            removeNameFirst: '',
            removeNameSecond: '',
            addPlaceholder: ''
        };
        this.statusIcons = {
            '#28A3D0': this.manageAccountsAssetsEnv + 'check.svg',
            '#F47A00': this.manageAccountsAssetsEnv + 'cancel.svg',
            '#FF0233': this.manageAccountsAssetsEnv + 'warning.svg'
        };
        this.userLoggedIn$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__["getLoggedIn"]));
        this.userData$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__["getUser"]));
    }
    ManageAccountComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.initializeTranslations();
        this.userDataSubscription = this.userData$.subscribe(function (data) {
            if (data && data.anid) {
                _this.getAccountData();
                if (!_this.paramSubscription) {
                    _this.paramSubscription = _this.route.queryParams.subscribe(function (params) {
                        if (params.unsubscribed === 'true') {
                            _this.unsubscribeFromPlanDevices();
                        }
                    });
                }
            }
        });
    };
    ManageAccountComponent.prototype.ngOnDestroy = function () {
        if (this.paramSubscription) {
            this.paramSubscription.unsubscribe();
        }
        if (this.userDataSubscription) {
            this.userDataSubscription.unsubscribe();
        }
    };
    ManageAccountComponent.prototype.updateAddFamilyMemberButtonVisibility = function () {
        if (this.planDevices.planinfo &&
            this.planDevices.planinfo.allowedDevices &&
            this.planDevices.planinfo.allowedDevices - this.invitees.length > 0) {
            this.showAddFamilyMemberButton = true;
        }
        else {
            this.showAddFamilyMemberButton = false;
        }
    };
    ManageAccountComponent.prototype.toggleRemoveModal = function (member) {
        this.isModalToggled.removeAccount = true;
        this.accountBeingRemoved = member;
    };
    ManageAccountComponent.prototype.toggleFirstCancellationModal = function () {
        this.isModalToggled.cancelPlusFirst = true;
    };
    ManageAccountComponent.prototype.toggleSecondCancellationModal = function () {
        this.isModalToggled.cancelPlusFirst = false;
        this.isModalToggled.cancelPlusSecond = true;
    };
    ManageAccountComponent.prototype.toggleUpdateCreditCard = function () {
        this.isModalToggled.updateCreditCard = true;
    };
    ManageAccountComponent.prototype.toggleCancelPurchase = function (purchase) {
        this.purchaseBeingCancelled = purchase;
        this.isModalToggled.cancelPurchase = true;
    };
    ManageAccountComponent.prototype.toggleRestorePurchase = function (purchase) {
        this.purchaseBeingRestored = purchase;
        this.isModalToggled.restorePurchase = true;
    };
    ManageAccountComponent.prototype.toggleRestorePlan = function () {
        this.isModalToggled.restorePlan = true;
    };
    ManageAccountComponent.prototype.updateCreditCardSuccess = function (event) {
        this.planDevices = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.planDevices, { plancardinfo: event.plancardinfo });
        this.closeModal();
    };
    ManageAccountComponent.prototype.goToCancel = function () {
        window.location.href = this.planDevices.plancanunsubscribe;
    };
    ManageAccountComponent.prototype.closeModal = function () {
        for (var modal in this.isModalToggled) {
            this.isModalToggled[modal] = false;
        }
        this.accountBeingRemoved = {};
        this.purchaseBeingCancelled = null;
    };
    ManageAccountComponent.prototype.handleManagePurchaseReturnedLink = function (link) {
        var isDeeplink = link.startsWith('anghami://');
        if (isDeeplink) {
            this._deeplinkService.handleDeeplink(link);
        }
        else {
            window.location.href = link;
        }
    };
    ManageAccountComponent.prototype.validateAlphanumeric = function (input) {
        var regex = /^[a-zA-Z0-9_\\-\\. ]*$/;
        return regex.test(input);
    };
    ManageAccountComponent.prototype.validateEmail = function (input) {
        var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return regex.test(input);
    };
    ManageAccountComponent.prototype.copyToClip = function (str) {
        this.copyToClipboard.copy(str);
        //After copying show toast saying text has been copied to clipboard
        var dialog = {
            displaymode: 'toast',
            title: this._translateService.instant('link_copied_toast')
        };
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_10__["OpenDialog"](dialog));
    };
    ManageAccountComponent.prototype.initializeTranslations = function () {
        this.translations.removeNameFirst = this._translateService.instant('manage_account_remove_name_first');
        this.translations.removeNameSecond = this._translateService.instant('manage_account_remove_name_second');
        this.translations.addPlaceholder = this._translateService.instant('manage_account_add_placeholder');
    };
    //API ACTIONS BELOW
    //Grabs user account info from GETPurchases and GETPlandevices
    ManageAccountComponent.prototype.getAccountData = function () {
        var _this = this;
        this.store.dispatch(new _anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["GetPlanDevices"]({}));
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_13__["ofType"])(_anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["ManageAccountActionTypes"].GetPlanDevicesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            _this.planDevices = res.payload;
            _this.invitees = res.payload.invitees
                ? res.payload.invitees.invitee
                : [];
            _this.updateAddFamilyMemberButtonVisibility();
        });
        this.store.dispatch(new _anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["GetPurchases"]({}));
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_13__["ofType"])(_anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["ManageAccountActionTypes"].GetPurchasesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            _this.purchases = res.payload.purchases ? res.payload.purchases : [];
        });
    };
    //Sends post request to renew/cancel purchases
    ManageAccountComponent.prototype.managePurchase = function (action, purchase) {
        var _this = this;
        var params = {
            action: action,
            purchaseID: purchase.id
        };
        this.store.dispatch(new _anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["ManagePurchases"](params));
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_13__["ofType"])(_anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["ManageAccountActionTypes"].ManagePurchasesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            if (action === 'cancel' &&
                res.payload.status === 'ok' &&
                res.payload.link) {
                _this.handleManagePurchaseReturnedLink(res.payload.link);
            }
            _this.getAccountData();
            _this.closeModal();
        });
    };
    //Adds an account to family plan
    ManageAccountComponent.prototype.addAccount = function () {
        var _this = this;
        if (this.isAddingFamilyMember) {
            if (this.validateEmail(this.inviteeInput)) {
                var params = {
                    inviteemail: this.inviteeInput,
                    invitename: null,
                    deleteemail: null,
                    unsubscribe: 0,
                    reactivate: 0
                };
                this.store.dispatch(new _anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["GetPlanDevices"](params));
                this._actionsSubject
                    .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_13__["ofType"])(_anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["ManageAccountActionTypes"]
                    .GetPlanDevicesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
                    .subscribe(function (res) {
                    if (res.payload.status === 'ok') {
                        _this.planDevices = res.payload;
                        _this.invitees = res.payload.invitees
                            ? res.payload.invitees.invitee
                            : [];
                        _this.isAddingFamilyMember = false;
                        _this.inviteeInput = '';
                    }
                    _this.updateAddFamilyMemberButtonVisibility();
                });
            }
            else if (this.validateAlphanumeric(this.inviteeInput)) {
                var params = {
                    inviteemail: null,
                    invitename: this.inviteeInput,
                    deleteemail: null,
                    unsubscribe: 0,
                    reactivate: 0
                };
                this.store.dispatch(new _anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["GetPlanDevices"](params));
                this._actionsSubject
                    .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_13__["ofType"])(_anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["ManageAccountActionTypes"]
                    .GetPlanDevicesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
                    .subscribe(function (res) {
                    if (res.payload.status === 'ok') {
                        _this.planDevices = res.payload;
                        _this.invitees = res.payload.invitees
                            ? res.payload.invitees.invitee
                            : [];
                        _this.isAddingFamilyMember = false;
                        _this.inviteeInput = '';
                    }
                    _this.updateAddFamilyMemberButtonVisibility();
                });
            }
            else {
                var dialog = {
                    displaymode: 'toast',
                    title: this._translateService.instant('enter_valid_name_toast')
                };
                this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_10__["OpenDialog"](dialog));
            }
        }
        else {
            this.isAddingFamilyMember = true;
        }
    };
    //Unsubscribes from family plan/anghami plus
    ManageAccountComponent.prototype.unsubscribeFromPlanDevices = function () {
        var _this = this;
        var params = {
            inviteemail: null,
            invitename: null,
            deleteemail: null,
            unsubscribe: 1,
            reactivate: 0
        };
        this.store.dispatch(new _anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["GetPlanDevices"](params));
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_13__["ofType"])(_anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["ManageAccountActionTypes"].GetPlanDevicesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            _this.planDevices = res.payload;
            _this.invitees = res.payload.invitees
                ? res.payload.invitees.invitee
                : [];
            _this.updateAddFamilyMemberButtonVisibility();
        });
    };
    //Reactivated Anghami Plus/Family Plan
    ManageAccountComponent.prototype.reactivatePlanDevices = function () {
        var _this = this;
        var params = {
            inviteemail: null,
            invitename: null,
            deleteemail: null,
            unsubscribe: 0,
            reactivate: 1
        };
        this.store.dispatch(new _anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["GetPlanDevices"](params));
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_13__["ofType"])(_anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["ManageAccountActionTypes"].GetPlanDevicesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            _this.planDevices = res.payload;
            _this.invitees = res.payload.invitees
                ? res.payload.invitees.invitee
                : [];
            _this.updateAddFamilyMemberButtonVisibility();
            _this.getAccountData();
            _this.closeModal();
        });
    };
    //Removes account from Family Plan
    ManageAccountComponent.prototype.removeAccount = function (email) {
        var _this = this;
        var params = {
            inviteemail: null,
            invitename: null,
            deleteemail: email,
            unsubscribe: 0,
            reactivate: 1
        };
        this.store.dispatch(new _anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["GetPlanDevices"](params));
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_13__["ofType"])(_anghami_redux_actions_manage_account_actions__WEBPACK_IMPORTED_MODULE_12__["ManageAccountActionTypes"].GetPlanDevicesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            _this.isModalToggled.removeAccount = false;
            _this.accountBeingRemoved = {};
            _this.getAccountData();
        });
    };
    ManageAccountComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'anghami-manage-account',
            template: __webpack_require__(/*! raw-loader!./manage-account.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/manage-account/manage-account.component.html"),
            styles: [__webpack_require__(/*! ./manage-account.component.scss */ "./src/app/modules/landing/manage-account/manage-account.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String, _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilService"],
            _anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_9__["DeeplinksService"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__["TranslateService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["ActionsSubject"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            _core_services_copy_to_clipboard_service__WEBPACK_IMPORTED_MODULE_1__["CopyToClipboardService"]])
    ], ManageAccountComponent);
    return ManageAccountComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/manage-account/manage-account.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/modules/landing/manage-account/manage-account.module.ts ***!
  \*************************************************************************/
/*! exports provided: ManageAccountModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageAccountModule", function() { return ManageAccountModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _manage_account_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./manage-account.component */ "./src/app/modules/landing/manage-account/manage-account.component.ts");
/* harmony import */ var _manage_account_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./manage-account-routing.module */ "./src/app/modules/landing/manage-account/manage-account-routing.module.ts");
/* harmony import */ var _core_components_download_app_download_app_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/download-app/download-app.module */ "./src/app/core/components/download-app/download-app.module.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _anghami_redux_effects_manage_account_effects__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/effects/manage-account.effects */ "./src/app/core/redux/effects/manage-account.effects.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/components/payment-form/payment-form.module */ "./src/app/core/components/payment-form/payment-form.module.ts");
/* harmony import */ var _anghami_services_copy_to_clipboard_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/services/copy-to-clipboard.service */ "./src/app/core/services/copy-to-clipboard.service.ts");
/* harmony import */ var _anghami_services_manage_account_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/manage-account.service */ "./src/app/core/services/manage-account.service.ts");














var ManageAccountModule = /** @class */ (function () {
    function ManageAccountModule() {
    }
    ManageAccountModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_manage_account_component__WEBPACK_IMPORTED_MODULE_3__["ManageAccountComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ReactiveFormsModule"],
                _manage_account_routing_module__WEBPACK_IMPORTED_MODULE_4__["ManageAccountRoutingModule"],
                _core_components_download_app_download_app_module__WEBPACK_IMPORTED_MODULE_5__["DownloadAppModule"],
                _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"],
                _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_6__["IconModule"],
                _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_11__["PaymentFormModule"],
                _ngrx_effects__WEBPACK_IMPORTED_MODULE_10__["EffectsModule"].forFeature([_anghami_redux_effects_manage_account_effects__WEBPACK_IMPORTED_MODULE_9__["ManageAccountEffects"]])
            ],
            providers: [
                _anghami_services_copy_to_clipboard_service__WEBPACK_IMPORTED_MODULE_12__["CopyToClipboardService"],
                _anghami_services_manage_account_service__WEBPACK_IMPORTED_MODULE_13__["ManageAccountService"]
            ]
        })
    ], ManageAccountModule);
    return ManageAccountModule;
}());



/***/ })

}]);