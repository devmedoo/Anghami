(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~discover-page-discover-page-module~modules-base-base-module~modules-landing-landing-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/discover/discover.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/discover/discover.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"flex-container\">\n  <a\n    *ngIf=\"fromPopover\"\n    class=\"discover-more-anchor\"\n    [routerLink]=\"['/discover']\"\n  >\n    <div class=\"discover-more-text\" i18n=\"@@follow_requests\">\n      Follow Requests\n    </div>\n  </a>\n\n  <div\n    *ngIf=\"!loading\"\n    [ngClass]=\"{ 'component-wrapper-popover': fromPopover }\"\n  >\n    <ng-container *ngIf=\"friendRequests?.data\">\n      <span\n        *ngIf=\"\n          (friendRequests?.data.length > 0 && !fromPopover) ||\n          (friendRequests?.data.length == 0 && userHasFB && !fromPopover)\n        \"\n      >\n        <h2 [ngClass]=\"{ 'discover-popover-header': fromPopover }\">\n          <span i18n=\"@@follow_requests\">Follow requests </span> &nbsp;\n        </h2>\n        <a\n          *ngIf=\"\n            fromPopover && !(friendRequests?.data.length == 0 && !userHasFB)\n          \"\n          [routerLink]=\"['/discover']\"\n          class=\"view-more\"\n          i18n=\"@@discover_people_window_requests_viewall\"\n          >View all</a\n        >\n      </span>\n\n      <div\n        [ngClass]=\"{ 'smaller-font': fromPopover }\"\n        class=\"friends-request-section\"\n        *ngIf=\"friendRequests?.data.length > 0\"\n      >\n        <ng-container\n          *ngFor=\"\n            let user of friendRequests?.data | slice: 0:nbOfRequestsDisplayed\n          \"\n        >\n          <div\n            [ngClass]=\"{ 'fromPopover friend-request-popover': fromPopover }\"\n            class=\"friend-request\"\n          >\n            <a\n              class=\"friend-request-info\"\n              [routerLink]=\"['/profile/', user.userid]\"\n            >\n              <img\n                class=\"friend-request-image\"\n                [src]=\"user.image\"\n                onError=\"this.src='https://anghamiwebcdn.akamaized.net/assets/img/userholder.jpg'\"\n              />\n              <div class=\"friend-request-text\">\n                <div\n                  class=\"title\"\n                  [ngClass]=\"{ 'title-popover': !fromPopover }\"\n                >\n                  {{ user.title }}\n                </div>\n                <div *ngIf=\"user.sim_factor > 0\">\n                  {{ user.sim_factor }}%\n                  <span i18n=\"@@disover_people_musicmatch_percentage\">\n                    Music match\n                  </span>\n                </div>\n              </div>\n            </a>\n            <div class=\"discover-list-button-group\" *ngIf=\"user.state == ''\">\n              <button\n                class=\"anghami-primary-btn delete-button\"\n                (click)=\"acceptRejectFriendRequest('reject', user.id)\"\n                i18n=\"@@discover_people_window_delete\"\n              >\n                Delete\n              </button>\n              <button\n                class=\"anghami-primary-btn\"\n                (click)=\"acceptRejectFriendRequest('accept', user.id)\"\n                i18n=\"@@follow_accept\"\n              >\n                Accept\n              </button>\n            </div>\n            <div\n              class=\"discover-list-button-group\"\n              *ngIf=\"user.state == 'accept'\"\n            >\n              <button\n                i18n=\"@@discover_people_button_profile\"\n                (click)=\"goToProfile(user.userid)\"\n                class=\"anghami-primary-btn\"\n              >\n                Go To Profile\n              </button>\n            </div>\n            <div\n              class=\"discover-list-button-group\"\n              *ngIf=\"user.state == 'reject'\"\n              i18n=\"@@discover_people_request_delete\"\n            >\n              Deleted\n            </div>\n          </div>\n        </ng-container>\n      </div>\n\n      <div *ngIf=\"friendRequests?.data.length == 0 && !userHasFB\">\n        <img class=\"no-friends\" [ngClass]=\"{ 'smaller-image': !fromPopover }\" />\n        <div class=\"centered-text\" i18n=\"@@discover_people_window_nofriends\">\n          You don't seem to be connected to any friends\n        </div>\n        <button\n          [ngClass]=\"{ 'smaller-image': !fromPopover }\"\n          type=\"button\"\n          class=\"login-btn login-btn-big login-btn-fb\"\n          (click)=\"connectToFacebook()\"\n        >\n          <i></i>\n          <span\n            class=\"login-btn-txt\"\n            i18n=\"@@discover_people_connect_window_facebook_title\"\n            >Connect to Facebook</span\n          >\n        </button>\n      </div>\n\n      <div *ngIf=\"friendRequests?.data.length == 0 && userHasFB\">\n        <div class=\"no-friend-request padded\">\n          <div class=\"no-friends-icon\" i18n=\"@@no_pending_follow_requests\">\n            No pending requests\n          </div>\n        </div>\n      </div>\n\n      <div\n        class=\"section-moredataloader\"\n        *ngIf=\"\n          !fromPopover &&\n          this.friendRequests.data.length > 6 &&\n          this.nbOfRequestsDisplayed != this.friendRequests.data.length - 1\n        \"\n      >\n        <button\n          (click)=\"expandFriendRequestsSection()\"\n          class=\"anghami-default-btn more-button\"\n          i18n=\"@@more\"\n        >\n          More\n        </button>\n      </div>\n    </ng-container>\n\n    <ng-container *ngIf=\"friendSuggestions?.data && friendSuggestions?.data.length >0\">\n      <h2 [ngClass]=\"{ 'discover-popover-header': fromPopover }\">\n        <span i18n=\"@@discover_people_window_title\">Your Music buddies </span>\n        &nbsp;\n      </h2>\n      <a\n        *ngIf=\"fromPopover\"\n        class=\"view-more\"\n        i18n=\"@@discover_people_window_requests_viewall\"\n        [routerLink]=\"['/discover']\"\n        >View all</a\n      >\n      <div\n        i18n=\"@@discover_people_window_subtitle\"\n        class=\"music-taste\"\n        [ngClass]=\"{ 'music-taste-smaller': fromPopover }\"\n      >\n        People you share the same taste with\n      </div>\n\n      <div\n        class=\"container-fluid\"\n        [ngClass]=\"{ 'remove-padding': !fromPopover }\"\n      >\n        <div\n          [ngClass]=\"{\n            'smaller-font friend-suggestions-section-popover': fromPopover\n          }\"\n          class=\"friend-suggestions-section row \"\n        >\n          <ng-container\n            *ngFor=\"\n              let user of friendSuggestions?.data\n                | slice: 0:(fromPopover ? nbOfRequestsDisplayed : 16)\n            \"\n          >\n            <div\n              [ngClass]=\"{\n                'col-xl-4 col-lg-4 col-4': fromPopover,\n                'col-xl-2 col-lg-3 col-md-4 col-sm-5 col-3': !fromPopover\n              }\"\n            >\n              <div\n                [ngClass]=\"{ 'smaller-friend-suggestion': fromPopover }\"\n                class=\"friend-suggestion \"\n              >\n                <a\n                  class=\"suggestion-anchor\"\n                  [routerLink]=\"['/profile/', user.id]\"\n                >\n                  <img\n                    [src]=\"user.image\"\n                    onError=\"this.src='https://anghamiwebcdn.akamaized.net/assets/img/userholder.jpg'\"\n                    class=\"friend-suggestion-image\"\n                  />\n                  <div\n                    class=\"trim title pt-2 friend-suggestion-text\"\n                    [ngClass]=\"{ 'title-popover': !fromPopover }\"\n                  >\n                    {{ user.name }}\n                  </div>\n                </a>\n\n                <div class=\"pb-2 sim-container\">\n                  {{ user.sim_factor }}%\n                  <span i18n=\"@@disover_people_musicmatch_percentage\">\n                    Music match\n                  </span>\n                </div>\n                <button\n                  class=\"anghami-primary-btn\"\n                  *ngIf=\"user.state == ''\"\n                  (click)=\"followUser(user)\"\n                  i18n=\"@@Follow\"\n                >\n                  Follow\n                </button>\n                <button\n                  class=\"anghami-primary-btn go-to-profile\"\n                  (click)=\"goToProfile(user.id)\"\n                  *ngIf=\"user.state == 'followed'\"\n                  i18n=\"@@discover_people_button_profile\"\n                >\n                  Go to profile\n                </button>\n                <div\n                  *ngIf=\"user.state == 'requested'\"\n                  i18n=\"@@follow_requested\"\n                >\n                  Requested\n                </div>\n              </div>\n            </div>\n          </ng-container>\n        </div>\n      </div>\n    </ng-container>\n\n    <ng-container\n      *ngIf=\"fromPopover && !userHasFB && friendRequests?.data.length > 0\"\n    >\n      <h2\n        [ngClass]=\"{ 'discover-popover-header': fromPopover }\"\n        i18n=\"@@discover_people_window_uptodate\"\n      >\n        Stay up-to-date with your friends\n      </h2>\n      <button\n        type=\"button\"\n        class=\"login-btn login-btn-big login-btn-fb\"\n        (click)=\"connectToFacebook()\"\n      >\n        <i></i>\n        <span\n          class=\"login-btn-txt\"\n          i18n=\"@@discover_people_connect_window_facebook_title\"\n          >Connect to Facebook</span\n        >\n      </button>\n    </ng-container>\n  </div>\n\n  <ng-container *ngIf=\"loading\">\n    <anghami-loading class=\"loader\"></anghami-loading>\n  </ng-container>\n</div>\n"

/***/ }),

/***/ "./src/app/core/components/discover/discover.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/core/components/discover/discover.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "html[lang=ar] :host .delete-button {\n  margin-left: 1em;\n  margin-right: 0em;\n}\nhtml[lang=ar] :host h2 {\n  font-weight: 800;\n  text-align: right;\n}\nhtml[lang=ar] :host .discover-list-text {\n  text-align: right;\n}\nhtml[lang=ar] :host .title {\n  direction: ltr;\n}\nhtml[lang=ar] :host .go-to-profile {\n  font-size: 0.84em;\n}\nhtml[lang=ar] :host .music-taste {\n  text-align: right;\n}\nhtml[lang=ar] :host .friend-suggestions-section {\n  direction: rtl;\n}\nhtml[lang=ar] :host .friend-suggestions-section-popover {\n  direction: ltr;\n}\n.no-friend-request {\n  text-align: center;\n  padding-top: 1em;\n  padding-bottom: 0.5em;\n}\n.padded {\n  padding: 2em;\n}\n.icon {\n  color: var(--search-text-color);\n}\n.no-friends-icon {\n  padding: 0.7em;\n  display: inline-block;\n  vertical-align: middle;\n}\nanghami-icon.no-friends-icon {\n  border-radius: 50%;\n  background: var(--recent-search-icon-bg);\n}\n.discover-more-anchor {\n  color: var(--text-color) !important;\n}\n.discover-more-anchor .discover-more-text {\n  background-color: var(--light-gray);\n  padding: 0.5em 1em;\n  font-size: 1.2em;\n  font-weight: 600;\n  border-top-left-radius: 0.3em;\n  border-top-right-radius: 0.3em;\n}\n.component-wrapper-popover {\n  overflow-y: auto;\n  overflow-x: none;\n  min-height: 15em;\n  padding: 0.5em 1em 0 1em;\n}\n.discover-popover-header {\n  font-size: 1.2em;\n  display: inline;\n}\n.view-more {\n  color: var(--brand-purple) !important;\n}\n.smaller-font {\n  font-size: 0.85em;\n}\n.friends-request-section {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: start;\n      align-content: flex-start;\n  margin-bottom: 1em;\n}\n.friend-request {\n  width: 49%;\n  padding: 0.5em 0;\n  border-bottom: 1px solid rgba(112, 112, 112, 0.2);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: stretch;\n      -ms-flex-align: stretch;\n          align-items: stretch;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n}\n@media screen and (max-width: 1200px) {\n  .friend-request {\n    width: 100%;\n  }\n}\n.friend-request-popover {\n  margin: 0 !important;\n}\n.friend-request-info {\n  width: 55%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-align: stretch;\n      -ms-flex-align: stretch;\n          align-items: stretch;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n}\n.friend-request-image {\n  width: 5em;\n  height: 5em;\n  border-radius: 50%;\n}\n.friend-request-text {\n  margin: auto 0.5em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: stretch;\n      -ms-flex-align: stretch;\n          align-items: stretch;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  color: var(--text-color);\n  text-decoration: none;\n}\n.friend-suggestions-section {\n  margin: 1em 0 1em;\n  padding: 0 0 0.5em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n.friend-suggestions-section-popover {\n  margin: 1em 0 1em -2em;\n}\n.friend-suggestion {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding: 0.5em;\n  background: var(--suggestion-background);\n  border-radius: 5px;\n  margin-bottom: 1em;\n  min-width: 10em !important;\n  min-height: 15em !important;\n  border: 1px solid var(--suggestion-border);\n}\n.smaller-friend-suggestion {\n  width: 11em;\n}\n.friend-suggestion-image {\n  border-radius: 50%;\n  display: block;\n  max-width: 6em;\n  min-width: 6em;\n  max-block-size: 6em;\n  min-height: 6em;\n}\n.friend-suggestion-text {\n  text-align: center;\n  text-decoration: none;\n  width: 100%;\n}\n.more-button:hover {\n  color: var(--text-color) !important;\n  opacity: 1 !important;\n}\n.more-button:hover:before {\n  background: var(--text-color) !important;\n  opacity: 1 !important;\n}\n.more-button:hover:after {\n  background: var(--text-color) !important;\n  opacity: 1 !important;\n}\n.more-button {\n  color: #727272 !important;\n}\n.more-button:before {\n  background: #727272 !important;\n}\n.more-button:after {\n  background: #727272 !important;\n}\n.more-button {\n  margin: 0 0.25em;\n}\n.login-btn:focus,\n.login-btn-circle:focus {\n  outline: none;\n}\nlogin-btn-txt {\n  font-size: 1em;\n}\n.login-btn-fb {\n  background: -webkit-gradient(linear, left top, right top, color-stop(0, var(--fb-light)), to(var(--fb-dark)));\n  background: linear-gradient(90deg, var(--fb-light) 0, var(--fb-dark));\n}\n.login-btn-fb i {\n  background-image: url('facebookicon.png');\n  margin-left: 0.3em !important;\n}\n@media only screen and (min-width: 1450px) {\n  .login-btn-fb i {\n    margin-left: 0.6em !important;\n  }\n}\n.login-btn-fb .login-btn-txt {\n  margin-left: 1em;\n}\n.login-btn {\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  border-radius: 30px;\n  margin: 0.5em auto;\n  position: relative;\n  cursor: pointer;\n}\n.login-btn:not(.login-btn-small) {\n  font-family: var(--font-main-latin);\n  font-weight: bold;\n}\n.login-btn[disabled] {\n  cursor: initial;\n  border: 1px solid #ced4da !important;\n  color: #ced4da !important;\n}\n.login-btn.login-btn-big {\n  margin: 1em auto 1em auto;\n  padding: 0.75em;\n  width: 50%;\n  font-size: small;\n}\n.login-btn.login-btn-big:not(.login-btn-ifttt) {\n  min-width: 16em;\n}\n.login-btn.login-btn-big:not(.login-btn-fb):not(.login-btn-google):not(.login-btn-prpl) {\n  color: var(--text-color);\n}\n.login-btn:not(.login-entr-mbl) {\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\ni {\n  position: absolute;\n  width: 1.4em;\n  height: 1.4em;\n  left: 1em;\n  top: 0;\n  bottom: 0;\n  margin: auto;\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: contain;\n}\n.login-btn-fb {\n  color: #fff;\n  border: none;\n}\n.trim {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\na {\n  color: var(--text-color) !important;\n}\na:hover,\na:visited,\na:link,\na:active {\n  text-decoration: none;\n}\n.fromPopover {\n  width: 100% !important;\n}\nh2 {\n  font-size: 1.7em;\n  margin: 0.1em 0 0.05em 0;\n  padding: 0;\n  color: var(--title);\n  font-weight: 500;\n  pointer-events: none;\n  float: unset;\n}\n.dicover-popover-header {\n  font-size: 1.2em;\n  background: none;\n  margin: 1em 0 0;\n}\n.flex-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n.title {\n  font-weight: 500;\n  font-size: 1.2em;\n}\n.title-popover {\n  font-weight: 500;\n  font-size: 1.2em;\n}\n.facebook-share-button {\n  background-color: #3a559f;\n  border-radius: 0.2em;\n}\n.discover-list-button-group {\n  margin-top: auto;\n  margin-bottom: auto;\n}\n.delete-button {\n  margin-right: 1em;\n  background: none;\n  border: 1px solid #5b5e62;\n  color: #5b5e62;\n}\n.no-friends {\n  content: url('facebookfriends.png');\n  width: 40%;\n  margin: auto;\n  display: block;\n}\n.smaller-image {\n  width: 20% !important;\n}\n.music-taste-smaller {\n  font-size: smaller;\n}\n.centered-text {\n  text-align: center;\n}\n.suggestion-anchor {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  width: 90%;\n}\n.anghami-primary-btn:not(.delete-button) {\n  background-color: rgba(141, 0, 242, 0.85) !important;\n}\n.anghami-primary-btn:hover:not(.delete-button) {\n  background-color: #8d00f2 !important;\n}\n.sim-container {\n  text-align: center;\n}\n.remove-padding {\n  padding: 0 !important;\n  margin: 0 -1em;\n}"

/***/ }),

/***/ "./src/app/core/components/discover/discover.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/core/components/discover/discover.component.ts ***!
  \****************************************************************/
/*! exports provided: DiscoverComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscoverComponent", function() { return DiscoverComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_actions_follow_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/follow.actions */ "./src/app/core/redux/actions/follow.actions.ts");
/* harmony import */ var _anghami_redux_selectors_follow_selector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/selectors/follow.selector */ "./src/app/core/redux/selectors/follow.selector.ts");
/* harmony import */ var _anghami_redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/user.actions */ "./src/app/core/redux/actions/user.actions.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _core_services_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");













var DiscoverComponent = /** @class */ (function () {
    function DiscoverComponent(authService, store, _router, _actionSubject) {
        this.authService = authService;
        this.store = store;
        this._router = _router;
        this._actionSubject = _actionSubject;
        this.closeModal = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.initialiseSubscriptions();
        this.loading = true;
    }
    DiscoverComponent.prototype.ngOnInit = function () {
        this.loading = false;
        if (this.fromPopover) {
            this.detectNavigation();
        }
        if (this.fromPopover) {
            this.nbOfRequestsDisplayed = 3;
        }
        else {
            this.nbOfRequestsDisplayed = 6;
        }
    };
    DiscoverComponent.prototype.initialiseSubscriptions = function () {
        var _this = this;
        this.userSub$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__["getUser"])).subscribe(function (user) {
            if (user && user.hasfacebook == "true") {
                _this.userHasFB = true;
            }
            else if (user && user.hasfacebook == "false") {
                _this.userHasFB = false;
                _this.authService.initFacebookSDK();
            }
        });
        this.friendRequestsSub$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_follow_selector__WEBPACK_IMPORTED_MODULE_4__["getNewFriendRequests"]))
            .subscribe(function (res) {
            if (res.type) {
                _this.friendRequests = res;
            }
            else {
                _this.friendRequests = { data: [] };
            }
        });
        this.friendSuggestionsSub$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_follow_selector__WEBPACK_IMPORTED_MODULE_4__["getWhoToFollow"]))
            .subscribe(function (res) {
            if (res.type) {
                _this.friendSuggestions = res;
            }
            else {
                _this.friendSuggestions = { data: [] };
            }
        });
    };
    DiscoverComponent.prototype.detectNavigation = function () {
        var _this = this;
        this.routeSub$ = this._router.events.subscribe(function (val) {
            if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_6__["NavigationStart"]) {
                _this.destroyPopover();
                if (val.url.indexOf("discover") != -1) {
                    _this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
                        name: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].goToDiscoverPeople
                    }));
                }
            }
        });
    };
    DiscoverComponent.prototype.destroyPopover = function () {
        this.closeModal.emit();
    };
    DiscoverComponent.prototype.acceptRejectFriendRequest = function (action, id) {
        this.store.dispatch(new _anghami_redux_actions_follow_actions__WEBPACK_IMPORTED_MODULE_3__["HandleAcceptRejectRequest"]({ action: action, id: id }));
        if (action == "accept") {
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].acceptFollowRequest,
                props: {
                    profileId: id
                }
            }));
        }
        else {
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].declineFollowRequest,
                props: {
                    profileId: id
                }
            }));
        }
    };
    DiscoverComponent.prototype.followUser = function (user) {
        var _this = this;
        this.store.dispatch(new _anghami_redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_5__["FollowProfile"]({
            profileId: user.id,
            isPrivate: !user.ispublic,
            requestStatus: "None",
            extras: undefined,
            unfollow: false
        }));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_7__["ofType"])(_anghami_redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_5__["UserActionTypes"].FollowProfileSuccess))
            .take(1)
            .subscribe(function (res) {
            if (res.payload &&
                res.payload.success[0].state == "followed") {
                _this.store.dispatch(new _anghami_redux_actions_follow_actions__WEBPACK_IMPORTED_MODULE_3__["SugestedFollowersUIUpdate"]({ id: user.id, state: "followed" }));
            }
            else if (res.payload &&
                res.payload.success[0].state == "requested") {
                _this.store.dispatch(new _anghami_redux_actions_follow_actions__WEBPACK_IMPORTED_MODULE_3__["SugestedFollowersUIUpdate"]({ id: user.id, state: "requested" }));
            }
            _this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].followProfile,
                props: {
                    profileId: "id",
                    type: res.payload.success[0].state == "followed"
                        ? "public"
                        : "private",
                    source: _this.fromPopover
                        ? "friend request tab"
                        : "discover people page"
                }
            }));
        });
    };
    DiscoverComponent.prototype.goToProfile = function (id) {
        this._router.navigate(["profile/", id]);
    };
    DiscoverComponent.prototype.ngOnDestroy = function () {
        if (this.friendRequestsSub$) {
            this.friendRequestsSub$.unsubscribe();
        }
        if (this.friendSuggestionsSub$) {
            this.friendSuggestionsSub$.unsubscribe();
        }
        if (this.userSub$) {
            this.userSub$.unsubscribe();
        }
        if (this.routeSub$) {
            this.routeSub$.unsubscribe();
        }
    };
    DiscoverComponent.prototype.connectToFacebook = function () {
        this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_12__["LoginWithFacebook"]());
    };
    DiscoverComponent.prototype.expandFriendRequestsSection = function () {
        if (this.nbOfRequestsDisplayed + 6 < this.friendRequests.data.length) {
            this.nbOfRequestsDisplayed = this.nbOfRequestsDisplayed + 6;
        }
        else {
            this.nbOfRequestsDisplayed = this.friendRequests.data.length - 1;
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], DiscoverComponent.prototype, "fromPopover", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DiscoverComponent.prototype, "closeModal", void 0);
    DiscoverComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "anghami-discover",
            template: __webpack_require__(/*! raw-loader!./discover.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/discover/discover.component.html"),
            styles: [__webpack_require__(/*! ./discover.component.scss */ "./src/app/core/components/discover/discover.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_core_services_auth_service__WEBPACK_IMPORTED_MODULE_8__["AuthService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"]])
    ], DiscoverComponent);
    return DiscoverComponent;
}());



/***/ }),

/***/ "./src/app/core/components/discover/discover.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/core/components/discover/discover.module.ts ***!
  \*************************************************************/
/*! exports provided: DiscoverModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscoverModule", function() { return DiscoverModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _discover_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./discover.component */ "./src/app/core/components/discover/discover.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _loading_loading_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _icon_icon_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");







var DiscoverModule = /** @class */ (function () {
    function DiscoverModule() {
    }
    DiscoverModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"], _loading_loading_module__WEBPACK_IMPORTED_MODULE_5__["LoadingModule"], _icon_icon_module__WEBPACK_IMPORTED_MODULE_6__["IconModule"]],
            declarations: [_discover_component__WEBPACK_IMPORTED_MODULE_3__["DiscoverComponent"]],
            providers: [_discover_component__WEBPACK_IMPORTED_MODULE_3__["DiscoverComponent"]],
            exports: [_discover_component__WEBPACK_IMPORTED_MODULE_3__["DiscoverComponent"]]
        })
    ], DiscoverModule);
    return DiscoverModule;
}());



/***/ }),

/***/ "./src/app/core/redux/selectors/follow.selector.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/redux/selectors/follow.selector.ts ***!
  \*********************************************************/
/*! exports provided: friendsState, getNewFriendRequests, getWhoToFollow */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "friendsState", function() { return friendsState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNewFriendRequests", function() { return getNewFriendRequests; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWhoToFollow", function() { return getWhoToFollow; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _reducers_follow_reducer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../reducers/follow.reducer */ "./src/app/core/redux/reducers/follow.reducer.ts");


var friendsState = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createFeatureSelector"])("friends");
var getNewFriendRequests = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(friendsState, _reducers_follow_reducer__WEBPACK_IMPORTED_MODULE_1__["selectNewFriendRequests"]);
var getWhoToFollow = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(friendsState, _reducers_follow_reducer__WEBPACK_IMPORTED_MODULE_1__["selectWhoToFollow"]);


/***/ })

}]);