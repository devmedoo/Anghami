(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~ambassador-ambassador-module~careers-careers-module"],{

/***/ "./src/app/core/components/photo-gallery/photo-gallery.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/core/components/photo-gallery/photo-gallery.component.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n:host .gallery-wrapper {\n  right: 0;\n  top: 0;\n  left: 0;\n  bottom: 0;\n  height: 100%;\n  width: 100%;\n  position: fixed;\n  z-index: 99999999999;\n  direction: ltr !important;\n}\n:host .gallery-wrapper.on-close {\n  -webkit-transform: scale(0);\n      -ms-transform: scale(0);\n          transform: scale(0);\n  -webkit-animation: scaleDown 0.3s ease-out;\n          animation: scaleDown 0.3s ease-out;\n}\n:host .gallery-wrapper:not(.on-close) {\n  -webkit-transform: scale(1);\n      -ms-transform: scale(1);\n          transform: scale(1);\n  -webkit-animation: scaleUp 0.3s ease-in;\n          animation: scaleUp 0.3s ease-in;\n}\n:host .close-btn {\n  position: absolute;\n  top: 1em;\n  right: 1em;\n  z-index: 9999999;\n  color: white;\n  font-size: 2.5em;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear;\n  border: none !important;\n  background: none !important;\n  cursor: pointer;\n}\n:host .close-btn:hover {\n  opacity: 0.6;\n}\n:host .img-navigate {\n  position: absolute;\n  width: 1em;\n  height: 3em;\n  top: 0;\n  bottom: 0;\n  margin: auto;\n  cursor: pointer;\n}\n:host .img-navigate.prev {\n  left: 2em;\n}\n:host .img-navigate.prev:after {\n  content: \"〉\";\n  position: absolute;\n  right: 0;\n  left: 0;\n  top: 0;\n  bottom: 0;\n  margin: auto;\n  width: 0.35em;\n  height: 1.4em;\n  font-size: 3em;\n  z-index: 999;\n  color: white;\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n:host .img-navigate.next {\n  right: 2em;\n}\n:host .img-navigate.next:before {\n  content: \"〉\";\n  position: absolute;\n  right: 0;\n  left: 0;\n  top: 0;\n  bottom: 0;\n  margin: auto;\n  width: 0.35em;\n  height: 1.4em;\n  font-size: 3em;\n  z-index: 999;\n  color: white;\n}\n:host .gallery-view {\n  background: rgba(0, 0, 0, 0.8);\n  height: 100%;\n  width: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  z-index: 9999;\n}\n:host .loader {\n  position: absolute;\n  margin: auto;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n}\n:host figure {\n  width: 65%;\n  margin: auto;\n  position: absolute;\n  height: auto;\n  margin: auto;\n  left: 0;\n  right: 0;\n  margin: auto;\n  top: 0;\n  bottom: 0;\n}\n:host figure img {\n  width: 100%;\n  height: auto;\n}\n:host figure figcaption {\n  color: white;\n  margin: 0.5em 0;\n}\n:host .active {\n  background-color: white;\n}\n:host .fullOpacity {\n  -webkit-animation: OPACITYIN 1s;\n          animation: OPACITYIN 1s;\n}\n@-webkit-keyframes scaleUp {\n  0% {\n    -webkit-transform: scale(0);\n            transform: scale(0);\n  }\n  25% {\n    -webkit-transform: scale(0.25);\n            transform: scale(0.25);\n  }\n  50% {\n    -webkit-transform: scale(0.5);\n            transform: scale(0.5);\n  }\n  75% {\n    -webkit-transform: scale(0.75);\n            transform: scale(0.75);\n  }\n  100% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n}\n@keyframes scaleUp {\n  0% {\n    -webkit-transform: scale(0);\n            transform: scale(0);\n  }\n  25% {\n    -webkit-transform: scale(0.25);\n            transform: scale(0.25);\n  }\n  50% {\n    -webkit-transform: scale(0.5);\n            transform: scale(0.5);\n  }\n  75% {\n    -webkit-transform: scale(0.75);\n            transform: scale(0.75);\n  }\n  100% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n}\n@-webkit-keyframes scaleDown {\n  0% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n  25% {\n    -webkit-transform: scale(0.75);\n            transform: scale(0.75);\n  }\n  50% {\n    -webkit-transform: scale(0.5);\n            transform: scale(0.5);\n  }\n  75% {\n    -webkit-transform: scale(0.25);\n            transform: scale(0.25);\n  }\n  100% {\n    -webkit-transform: scale(0);\n            transform: scale(0);\n  }\n}\n@keyframes scaleDown {\n  0% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n  }\n  25% {\n    -webkit-transform: scale(0.75);\n            transform: scale(0.75);\n  }\n  50% {\n    -webkit-transform: scale(0.5);\n            transform: scale(0.5);\n  }\n  75% {\n    -webkit-transform: scale(0.25);\n            transform: scale(0.25);\n  }\n  100% {\n    -webkit-transform: scale(0);\n            transform: scale(0);\n  }\n}\nhtml[lang=ar] :host figure figcaption {\n  text-align: right;\n}"

/***/ }),

/***/ "./src/app/core/components/photo-gallery/photo-gallery.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/photo-gallery/photo-gallery.component.ts ***!
  \**************************************************************************/
/*! exports provided: PhotoGalleryComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PhotoGalleryComponent", function() { return PhotoGalleryComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");




let PhotoGalleryComponent = class PhotoGalleryComponent {
    constructor(document, platformId) {
        this.document = document;
        this.platformId = platformId;
        this.state = {
            toggleGalleryView: false,
            images: undefined,
            currentIndex: undefined,
            currentImage: undefined,
            previousDocKeydown: undefined,
            startCloseAnimation: false,
            previousBodyOverflow: undefined
        };
    }
    ngAfterViewInit() {
        this.galleryItemsOnKeypress();
    }
    galleryItemsOnKeypress() {
        if (typeof this.state.images === 'undefined' ||
            this.state.images === null) {
            const elements = this.document.getElementsByClassName('gallery-img');
            this.state.images = Array.from(elements);
            this.state.images.forEach(img => {
                img.onclick = this.onImageClick.bind(this);
            });
        }
    }
    onImageClick(e) {
        e.preventDefault();
        e.stopPropagation();
        if (e.target.classList &&
            typeof e.target.classList[0] !== 'undefined' &&
            e.target.classList[0] !== null) {
            this.state.currentIndex = Number(e.target.classList[0]);
            this.toggleGallery(e);
            this.setCurrentImage();
        }
    }
    right(e) {
        this.state.currentIndex =
            this.state.currentIndex === this.galleryImages.length - 1
                ? 0
                : ++this.state.currentIndex;
        this.setCurrentImage();
    }
    left(e) {
        this.state.currentIndex =
            this.state.currentIndex === 0
                ? this.galleryImages.length - 1
                : --this.state.currentIndex;
        this.setCurrentImage();
    }
    setCurrentImage() {
        this.state.currentImage = this.galleryImages[this.state.currentIndex];
        this.state.currentImage.caption =
            this.state.currentImage.description ||
                this.state.currentImage.caption ||
                this.state.currentImage.title ||
                this.state.currentImage.name;
    }
    keydownhandler(e) {
        e.preventDefault();
        e.stopPropagation();
        switch (e.keyCode) {
            case 39:
                this.right(e);
                break;
            case 37:
                this.left(e);
                break;
            case 8:
            case 112:
            case 27:
            case 79:
                this.toggleGallery({ keyCode: 13 });
                break;
            default:
                break;
        }
    }
    toggleGallery(e) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["isPlatformBrowser"])(this.platformId)) {
            e.preventDefault();
            e.stopPropagation();
            if (this.state.toggleGalleryView) {
                //was shown, then hide
                this.resetKeydownAndOverflow();
                this.state.startCloseAnimation = true;
                if (typeof this.onDestroy === 'function') {
                    this.onDestroy();
                }
                setTimeout(() => {
                    this.state.startCloseAnimation = false;
                    this.state.toggleGalleryView = false;
                }, 400);
            }
            else if (!this.state.toggleGalleryView) {
                //was hidden, then show
                this.alterKeyDownAndOverflow();
                this.state.toggleGalleryView = true;
                if (typeof this.onInit === 'function') {
                    this.onInit();
                }
            }
        }
    }
    resetKeydownAndOverflow() {
        this.document.body.style.overflow = this.state.previousBodyOverflow;
        this.document.onkeydown = this.state.previousDocKeydown;
    }
    alterKeyDownAndOverflow() {
        this.state.previousDocKeydown = this.document.onkeydown;
        this.document.onkeydown = this.keydownhandler.bind(this);
        this.state.previousBodyOverflow = this.document.body.style.overflow;
        this.document.body.style.overflow = 'hidden';
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('galleryImages'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
], PhotoGalleryComponent.prototype, "galleryImages", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('onInit'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function)
], PhotoGalleryComponent.prototype, "onInit", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('onDestroy'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function)
], PhotoGalleryComponent.prototype, "onDestroy", void 0);
PhotoGalleryComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-photo-gallery',
        template: `
    <div
      class="gallery-wrapper"
      *ngIf="state.toggleGalleryView"
      [class.on-close]="state.startCloseAnimation"
    >
      <button type="button" class="close-btn" (click)="toggleGallery($event)">
        <span aria-hidden="true">&times;</span>
      </button>
      <div class="gallery-view">
        <div
          (click)="toggleGallery($event)"
          class="loader backgroundSimple"
        ></div>
        <span class="img-navigate next" (click)="right($event)"></span>
        <ng-container *ngIf="state.currentImage">
          <figure class="d-flex flex-column justify-content-center">
            <ng-container *ngIf="state.currentImage.image">
              <img [src]="state.currentImage.image" />
            </ng-container>
            <ng-container *ngIf="state.currentImage.caption">
              <figcaption dir="auto">
                {{ state.currentImage.caption }}
              </figcaption>
            </ng-container>
          </figure>
        </ng-container>
        <span class="img-navigate prev" (click)="left($event)"></span>
      </div>
    </div>
  `,
        styles: [__webpack_require__(/*! ./photo-gallery.component.scss */ "./src/app/core/components/photo-gallery/photo-gallery.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_2__["DOCUMENT"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, Object])
], PhotoGalleryComponent);



/***/ }),

/***/ "./src/app/core/components/photo-gallery/photo-gallery.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/core/components/photo-gallery/photo-gallery.module.ts ***!
  \***********************************************************************/
/*! exports provided: PhotoGalleryModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PhotoGalleryModule", function() { return PhotoGalleryModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _photo_gallery_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./photo-gallery.component */ "./src/app/core/components/photo-gallery/photo-gallery.component.ts");




let PhotoGalleryModule = class PhotoGalleryModule {
};
PhotoGalleryModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
        declarations: [_photo_gallery_component__WEBPACK_IMPORTED_MODULE_3__["PhotoGalleryComponent"]],
        exports: [_photo_gallery_component__WEBPACK_IMPORTED_MODULE_3__["PhotoGalleryComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], PhotoGalleryModule);



/***/ })

}]);