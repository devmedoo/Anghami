(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["core-components-upload-music-upload-music-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/upload-music/upload-music.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/upload-music/upload-music.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main\">\n  <div class=\"upload-container background\" *ngIf=\"!results\">\n    <div class=\"image-container\">\n      <img class=\"upload-img\" *ngIf=\"!matchingMusic\" />\n      <ng-container *ngIf=\"matchingMusic\">\n        <div class=\"lds-ring\">\n          <div></div>\n          <div></div>\n          <div></div>\n          <div></div>\n        </div>\n      </ng-container>\n    </div>\n    <div class=\"upload-text\">\n      <div *ngIf=\"!matchingMusic\">\n        <!-- <p>\n          Drag & drop files here\n        </p>\n        <p>\n          or\n        </p> -->\n        <div class=\"title\">\n          <span i18n=\"@@upload_songs_page_title\">\n            Select the music files that you want to upload\n          </span>\n        </div>\n        <button type=\"submit\" class=\"anghami-primary-btn\" i18n=\"@@upload_songs_page_button\"\n          (click)=\"openDirectoryChooser()\">\n          Choose files to upload\n        </button>\n      </div>\n      <div *ngIf=\"matchingMusic\">\n        <p i18n=\"@@upload_songs_process_page\">\n          Your songs are being processed\n        </p>\n      </div>\n    </div>\n  </div>\n  <div class=\"notes\" *ngIf=\"!results\">\n    <span i18n=\"@@upload_songs_page_notes\">\n      Notes:<br />\n      - We will match your songs with the ones we have, and upload those we don&apos;t.<br />\n      - Some files might not get uploaded if their format is not supported by Anghami. <br />\n      - You are the only one who can play your uploaded files but you can access them from as many devices as you\n      want.<br />\n    </span>\n  </div>\n  <div *ngIf=\"results\">\n    <h1 i18n=\"@@upload_songs_details_header\">\n      Uploading Songs\n    </h1>\n    <div class=\"vibes-tag\" [class.selected-vibe]=\"activeTab === 'all'\" (click)=\"switchActiveTab('all')\">\n      All\n    </div>\n    <ng-container *ngFor=\"let result of results\">\n      <div class=\"vibes-tag\" [class.selected-vibe]=\"activeTab === result.type\" (click)=\"switchActiveTab(result.type)\"\n        *ngIf=\"result.data.length > 0\">\n        {{result.type}}\n      </div>\n    </ng-container>\n    <div class=\"buttons float-right\">\n      <button type=\"submit\" class=\"anghami-primary-btn right-margin\" i18n=\"@@Done\" (click)=\"finishBatch()\"\n        *ngIf=\"uploadDone\">\n        Done\n      </button>\n      <button type=\"submit\" class=\"anghami-primary-btn cancel-btn right-margin\" i18n=\"@@Cancel\" (click)=\"cancelBatch()\"\n        *ngIf=\"!uploadDone\">\n        Cancel\n      </button>\n      <button type=\"submit\" class=\"anghami-primary-btn\" i18n=\"@@Go to playlist\" (click)=\"goToComputerPlaylist()\"\n        *ngIf=\"computerPlaylistExists\">\n        Go to playlist\n      </button>\n    </div>\n    <div class=\"results\">\n      <div *ngFor=\"let result of results\">\n        <div *ngIf=\"result.data.length > 0 && (result.type === activeTab || activeTab === 'all')\">\n          <span class=\"result-title\">\n            {{result.title}}\n          </span>\n          <div>\n            <div class=\"song-container\">\n              <div class=\"song-object\" *ngFor=\"let song of result.data\">\n                <div class=\"image\">\n                  <div class=\"placeholder-container\">\n                    <img class=\"song-placeholder-img\" />\n                  </div>\n                </div>\n                <div class=\"info\">\n                  <div class=\"song-title trim\">\n                    <span>{{ song.name }}</span>\n                  </div>\n                  <div class=\"song-location trim\">\n                    <span>{{ song.local_path }}</span>\n                  </div>\n                </div>\n                <div class=\"actions\">\n                  <div class=\"button-container\" *ngIf=\"(song.uploaded || result.type === 'matched') && !song.canceled\"\n                    (click)=\"goToComputerPlaylist()\">\n                    <div class=\"success\">\n                      <anghami-icon class=\"icon\" [data]=\"'check'\"></anghami-icon>\n                    </div>\n                  </div>\n                  <div\n                    *ngIf=\"!song.uploaded && !song.canceled && currentUploadingSong?.local_path !== song.local_path \n                      && result.type === 'unmatched'\">\n                    <div class=\"button-container\">\n                      <ng-container *ngIf=\"userIsPlus\">\n                        <anghami-icon class=\"icon close-icon\" [data]=\"'close'\" (click)=\"cancelSongUpload(song)\"></anghami-icon>\n                        <div class=\"cancel\"></div>\n                      </ng-container>\n                      <ng-container *ngIf=\"!userIsPlus\">\n                        <button class=\"anghami-primary-btn\" i18n=\"@@Go to playlist\" (click)=\"handleFreeUserUploadClick()\">\n                          Upload\n                        </button>\n                      </ng-container>\n                    </div>\n                  </div>\n                  <div\n                    *ngIf=\"!song.uploaded && currentUploadingSong?.local_path === song.local_path && result.type === 'unmatched'\">\n                    <div class=\"button-container\">\n                      <div class=\"progress\"></div>\n                    </div>\n                  </div>\n                  <div *ngIf=\"result.type === 'ignored'\">\n                    <div class=\"button-container\">\n                      <anghami-icon class=\"icon\" [data]=\"'warning'\"></anghami-icon>\n                    </div>\n                  </div>\n                  <div class=\"button-container\" *ngIf=\"song.canceled\">\n                    <anghami-icon class=\"icon\" [data]=\"'warning'\"></anghami-icon>\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/core/components/upload-music/upload-music-routing.module.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/core/components/upload-music/upload-music-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: routes, UploadMusicRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadMusicRoutingModule", function() { return UploadMusicRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _upload_music_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./upload-music.component */ "./src/app/core/components/upload-music/upload-music.component.ts");




const routes = [
    {
        path: '',
        children: [{ path: '', component: _upload_music_component__WEBPACK_IMPORTED_MODULE_3__["UploadMusicComponent"] }]
    }
];
let UploadMusicRoutingModule = class UploadMusicRoutingModule {
};
UploadMusicRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], UploadMusicRoutingModule);



/***/ }),

/***/ "./src/app/core/components/upload-music/upload-music.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/upload-music/upload-music.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .ang-main {\n  margin: 1em;\n}\n:host .ang-main .trim {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n:host .ang-main .background {\n  background-color: var(--upload-music-banner-bg);\n}\n:host .ang-main .border {\n  border: 1px dashed var(--upload-music-banner-border);\n}\n:host .ang-main .right-margin {\n  margin-right: 1em;\n}\n:host .ang-main .cancel-btn {\n  background-color: var(--search-background);\n  color: var(--text-color);\n}\n:host .ang-main .notes {\n  margin-left: 13.5%;\n}\n:host .ang-main .notes ul {\n  padding-left: 1.1em;\n  list-style-type: circle;\n}\n:host .ang-main .notes span {\n  font-size: 0.9em;\n  color: var(--text-color-light);\n  white-space: pre-line;\n}\n:host .ang-main .upload-container {\n  margin: auto;\n  width: 75%;\n  height: auto;\n  padding: 6em;\n  margin-top: 5em;\n  border-radius: 5px;\n}\n:host .ang-main .upload-container .image-container {\n  width: 80%;\n  margin: 0 auto 2em auto;\n  text-align: center;\n}\n:host .ang-main .upload-container .image-container .upload-img {\n  content: var(--upload-music-banner-bg-img);\n  width: 80%;\n}\n:host .ang-main .upload-container .upload-text {\n  text-align: center;\n}\n:host .ang-main .upload-container .upload-text .title {\n  margin-bottom: 1em;\n}\n:host .ang-main .upload-container .upload-text .title span {\n  font-size: 1.3em;\n  font-weight: bold;\n}\n:host .ang-main .upload-container .upload-ended-img {\n  content: var(--upload-music-banner-files-uploaded-bg);\n  width: 100%;\n}\n:host .ang-main .vibes-tag {\n  padding: 0.5rem 1rem 0.5rem 1rem;\n  border-radius: 0.3rem;\n  font-size: 0.75rem;\n  display: inline-block;\n  vertical-align: middle;\n  margin-right: 0.5em;\n  margin-top: 0.5em;\n  color: var(--vibes-foreground);\n  cursor: pointer;\n  text-transform: capitalize;\n  white-space: nowrap;\n  text-align: start;\n  background: var(--vibes-background);\n}\n:host .ang-main .selected-vibe {\n  background: var(--vibes-tag-selected-bg);\n  color: var(--vibes-tag-bg);\n}\n:host .ang-main .selected-vibe .vibes-name {\n  color: var(--vibes-tag-bg);\n  font-weight: 500;\n}\n:host .ang-main .results {\n  margin-top: 2em;\n}\n:host .ang-main .results .result-title {\n  font-weight: bold;\n  font-size: 2.1em;\n}\n:host .ang-main .song-container {\n  width: 70%;\n  margin-right: auto;\n  margin-top: 1.5em;\n  margin-bottom: 3em;\n}\n:host .ang-main .song-container .song-object {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n  margin-bottom: 2em;\n}\n:host .ang-main .song-container .song-object .info {\n  -webkit-box-flex: 0.9;\n      -ms-flex: 0.9;\n          flex: 0.9;\n  padding-left: 1em;\n  width: 75%;\n  margin-right: 1em;\n  overflow: hidden;\n}\n:host .ang-main .song-container .song-object .info .song-title {\n  color: var(--text-color);\n  font-weight: bold;\n  font-size: 1.1em;\n}\n:host .ang-main .song-container .song-object .actions {\n  margin-top: 0.3em;\n}\n:host .ang-main .song-container .song-object .actions .button-container:hover {\n  cursor: pointer;\n}\n:host .ang-main .song-container .song-object .actions .button-container .upload-icon {\n  margin-top: 1em;\n}\n:host .ang-main .song-container .song-object .actions .button-container .cancel-icon {\n  z-index: 1000;\n  top: 28%;\n  right: 46%;\n}\n:host .ang-main .song-container .song-object .actions .button-container .success {\n  background: var(--brand-purple);\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n  padding: 0.8em;\n  border-radius: 50%;\n  margin: auto;\n  border: 2px solid var(--brand-purple);\n}\n:host .ang-main .song-container .song-object .actions .button-container .success .icon {\n  color: #fff;\n  font-size: 0.8em;\n}\n:host .ang-main .song-container .song-object .actions .button-container .cancel {\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n  padding: 1.4em;\n  border-radius: 50%;\n  margin: auto;\n  background: var(--bg-white-secondary);\n  border: 2px solid var(--bg-white-secondary);\n  box-shadow: 0 0 0 2px var(--upload-music-box-shadow-color) inset;\n  box-sizing: border-box;\n}\n:host .ang-main .song-container .song-object .actions .button-container .cancel .icon {\n  color: var(--text-color-light);\n  font-size: 0.8em;\n}\n:host .ang-main .song-container .song-object .actions .button-container .close-icon {\n  position: absolute;\n  font-size: 0.7em;\n  margin: 1.46em;\n}\n:host .ang-main .song-container .song-object .actions .button-container .progress {\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n  padding: 1.38em;\n  border-radius: 50%;\n  margin: auto;\n  background: var(--bg-white-secondary);\n  border: 2px solid var(--bg-white-secondary);\n  border-top: 2px solid var(--upload-music-progress-color);\n  -webkit-animation: spin 2s linear infinite;\n  animation: spin 2s linear infinite;\n  box-shadow: 0 0 0 2px var(--upload-music-box-shadow-color) inset;\n  box-sizing: border-box;\n}\n:host .ang-main .song-container .song-object .actions .button-container .progress:hover {\n  cursor: default;\n}\n:host .ang-main .song-container .song-object .actions .button-container .progress .icon {\n  color: var(--text-color-light);\n  font-size: 0.8em;\n}\n:host .ang-main .lds-ring {\n  display: inline-block;\n  position: relative;\n  width: 80px;\n  height: 80px;\n}\n:host .ang-main .lds-ring div {\n  box-sizing: border-box;\n  display: block;\n  position: absolute;\n  width: 64px;\n  height: 64px;\n  margin: 8px;\n  border: 3px solid var(--brand-purple);\n  border-radius: 50%;\n  -webkit-animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;\n          animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;\n  border-color: var(--brand-purple) transparent transparent transparent;\n}\n:host .ang-main .lds-ring div:nth-child(1) {\n  -webkit-animation-delay: -0.45s;\n          animation-delay: -0.45s;\n}\n:host .ang-main .lds-ring div:nth-child(2) {\n  -webkit-animation-delay: -0.3s;\n          animation-delay: -0.3s;\n}\n:host .ang-main .lds-ring div:nth-child(3) {\n  -webkit-animation-delay: -0.15s;\n          animation-delay: -0.15s;\n}\n@-webkit-keyframes lds-ring {\n  0% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n  }\n}\n@keyframes lds-ring {\n  0% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n  }\n}\n:host .placeholder-container {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  width: 8.5%;\n}\n:host .placeholder-container .song-placeholder-img {\n  content: var(--upload-music-song-placeholder);\n  width: auto;\n  height: 4em;\n}\n:host .song-info-container {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  vertical-align: top;\n  margin: 0.3em 1em;\n  height: -webkit-max-content;\n  height: -moz-max-content;\n  height: max-content;\n  max-width: 25em;\n  overflow: hidden;\n}\n:host .song-info-container span {\n  display: block;\n  margin-bottom: 0.3em;\n}\n:host .song-info-container .song-title {\n  color: var(--text-color);\n  font-weight: bold;\n  font-size: 1.1em;\n  width: 30em;\n}\n:host .song-info-container .song-location {\n  width: 45em;\n}\n:host .anghami-default-btn {\n  width: 10em;\n  margin-left: auto;\n  margin-right: 3em;\n}\n:host .song-list {\n  margin-top: 4em;\n}\n:host .title {\n  float: left;\n  font-size: 1.3em;\n  font-weight: bold;\n  margin-left: 0.5em;\n  width: 100%;\n}\n:host .text-color-light, :host .ang-main .song-container .song-object .info .song-location, :host .song-info-container .song-location {\n  color: var(--text-color-light);\n}\n:host .loader {\n  border: 3px solid #f3f3f3;\n  border-radius: 50%;\n  border-top: 3px solid var(--brand-purple);\n  width: 3.1em;\n  height: 3.1em;\n  -webkit-animation: spin 2s linear infinite;\n  animation: spin 2s linear infinite;\n}\n@-webkit-keyframes spin {\n  0% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n  }\n}\n@keyframes spin {\n  0% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n  }\n}"

/***/ }),

/***/ "./src/app/core/components/upload-music/upload-music.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/upload-music/upload-music.component.ts ***!
  \************************************************************************/
/*! exports provided: UploadMusicComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadMusicComponent", function() { return UploadMusicComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_services_desktop_match_music_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/desktop-match-music.service */ "./src/app/core/services/desktop-match-music.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");













let UploadMusicComponent = class UploadMusicComponent {
    constructor(store, desktopMatchMusicService, authService, changeDetectorRef, platformId) {
        this.store = store;
        this.desktopMatchMusicService = desktopMatchMusicService;
        this.authService = authService;
        this.changeDetectorRef = changeDetectorRef;
        this.platformId = platformId;
        this.matchingMusic = false;
        this.uploadDone = false;
        this.results = null;
        this.activeTab = 'all';
        this.currentUploadingSong = null;
        this.userIsPlus = true;
        this.computerPlaylistExists = false;
    }
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_12__["isPlatformServer"])(this.platformId)) {
            return;
        }
        this.loadingSubscription = this.desktopMatchMusicService.matchingMusic$.subscribe((response) => {
            this.matchingMusic = response;
            this.changeDetectorRef.detectChanges();
        });
        this.uploadDoneSubscription = this.desktopMatchMusicService.uploadDone$.subscribe((response) => {
            this.uploadDone = response;
            this.changeDetectorRef.detectChanges();
        });
        this.resultsSubscription = this.desktopMatchMusicService.finalMatchingResults$.subscribe((response) => {
            if (!response) {
                this.results = null;
                this.currentUploadingSong = null;
                this.changeDetectorRef.detectChanges();
                return;
            }
            if (response.unmatched.length === 0 && response.matched.length === 0 && response.ignored.length === 0) {
                this.results = null;
                this.currentUploadingSong = null;
                this.changeDetectorRef.detectChanges();
                return;
            }
            this.results = this.desktopMatchMusicService.constructResultsStructure(response);
            this.currentUploadingSong = this.desktopMatchMusicService.currentUploadingSong;
            this.desktopMatchMusicService.validateUploadStatus();
            this.changeDetectorRef.detectChanges();
            setTimeout(() => {
                this.computerPlaylistExists = this.desktopMatchMusicService.computerPlaylist && this.desktopMatchMusicService.computerPlaylist.id;
            }, 2000);
        });
        this.store.select(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_8__["getUser"]).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1)).subscribe(user => {
            this.userIsPlus = user && user.plantype === '3';
        });
        this.desktopMatchMusicService.checkForBackedUpResultsAndRestore();
        this.computerPlaylistExists = this.desktopMatchMusicService.computerPlaylist && this.desktopMatchMusicService.computerPlaylist.id;
    }
    switchActiveTab(newTab) {
        this.activeTab = newTab;
        this.changeDetectorRef.detectChanges();
    }
    openDirectoryChooser() {
        if (!window['desktopClient']) {
            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__["OpenCustomDialog"]({ type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_7__["DIALOG_TYPES"].DESKTOP_IMPORT_DOWNLOAD }));
            return;
        }
        if (!this.authService.isUserLoggedIn()) {
            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__["OpenCustomDialog"]({
                type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_7__["DIALOG_TYPES"].LOGIN
            }));
            return;
        }
        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__["MatchMusicOpenDialog"]());
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_11__["AmplitudeEvents"].clickOnBrowseFiles,
            props: {}
        }));
    }
    handleFreeUserUploadClick() {
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__["OpenCustomDialog"]({
            type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_7__["DIALOG_TYPES"].PLUS_FEATURE_WEB
        }));
    }
    goToComputerPlaylist() {
        if (this.uploadDone) {
            this.desktopMatchMusicService.finishBatch();
        }
        this.desktopMatchMusicService.goToUserComputerPlaylist();
    }
    cancelBatch() {
        this.desktopMatchMusicService.cancelBatch();
    }
    finishBatch() {
        this.desktopMatchMusicService.finishBatch();
    }
    cancelSongUpload(song) {
        this.desktopMatchMusicService.removeItemFromQueue(song);
    }
    ngOnChanges(SimpleChanges) { }
    ngOnDestroy() {
        this.resultsSubscription.unsubscribe();
        this.loadingSubscription.unsubscribe();
        this.uploadDoneSubscription.unsubscribe();
    }
};
UploadMusicComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'anghami-upload-music',
        template: __webpack_require__(/*! raw-loader!./upload-music.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/upload-music/upload-music.component.html"),
        styles: [__webpack_require__(/*! ./upload-music.component.scss */ "./src/app/core/components/upload-music/upload-music.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_3__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
        _anghami_services_desktop_match_music_service__WEBPACK_IMPORTED_MODULE_2__["DesktopMatchMusicService"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"],
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectorRef"],
        Object])
], UploadMusicComponent);



/***/ }),

/***/ "./src/app/core/components/upload-music/upload-music.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/upload-music/upload-music.module.ts ***!
  \*********************************************************************/
/*! exports provided: UploadMusicModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadMusicModule", function() { return UploadMusicModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _upload_music_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./upload-music-routing.module */ "./src/app/core/components/upload-music/upload-music-routing.module.ts");
/* harmony import */ var _upload_music_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./upload-music.component */ "./src/app/core/components/upload-music/upload-music.component.ts");
/* harmony import */ var _icon_icon_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");






let UploadMusicModule = class UploadMusicModule {
};
UploadMusicModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _upload_music_routing_module__WEBPACK_IMPORTED_MODULE_3__["UploadMusicRoutingModule"], _icon_icon_module__WEBPACK_IMPORTED_MODULE_5__["IconModule"]],
        declarations: [_upload_music_component__WEBPACK_IMPORTED_MODULE_4__["UploadMusicComponent"]],
        exports: [_upload_music_component__WEBPACK_IMPORTED_MODULE_4__["UploadMusicComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], UploadMusicModule);



/***/ })

}]);