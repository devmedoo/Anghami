(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["press-press-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/inner-header/inner-header.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  id=\"headerid\"\n  class=\"header\"\n  [ngStyle]=\"backgroundimage\"\n  [ngClass]=\"{ extra: backgroundHeader.extra, smallerHeader: smallerHeader }\"\n>\n  <img\n    class=\"logo\"\n    *ngIf=\"backgroundHeader.innerLogo\"\n    [src]=\"backgroundHeader.innerLogo\"\n  />\n  <div>\n    <ng-container *ngIf=\"!isapi\">\n      <h1 class=\"title\">{{ backgroundHeader?.title | translateInstant }}</h1>\n      <h5 class=\"subtitle \">\n        {{ backgroundHeader?.subtitle | translateInstant }}\n      </h5>\n    </ng-container>\n    <ng-container *ngIf=\"isapi\">\n      <div class=\"title\">{{ backgroundHeader?.title }}</div>\n      <h5 class=\"subtitle \">{{ backgroundHeader?.subtitle }}</h5>\n    </ng-container>\n  </div>\n  <img\n    *ngIf=\"isWave\"\n    class=\"wave\"\n    src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\"\n  />\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/press/press.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/press/press.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<anghami-inner-header [backgroundHeader]=\"innerHeader\"></anghami-inner-header>\n<section class=\"full-row-layout\">\n  <div class=\"container\">\n    <div class=\"row\">\n      <div class=\"col-lg-12\">\n        <p>\n          For media and press-related inquiries, emails us:\n          <a href=\"maito:press@anghami.com\" class=\"link\">press@anghami.com</a>\n        </p>\n      </div>\n    </div>\n    <div class=\"row\">\n      <ng-container *ngIf=\"(press$ | async) as press\">\n        <a\n          [href]=\"item.link\"\n          target=\"_blank\"\n          class=\"col-md-4 press-item\"\n          *ngFor=\"let item of press['sections'][0]['data']\"\n        >\n          <div class=\"card mb-4 shadow-sm\">\n            <div\n              class=\"press-image\"\n              [ngStyle]=\"{\n                'background-image': 'url(' + item.image + ')',\n                'background-size': 'contain',\n                'background-repeat': 'no-repeat',\n                'background-position': 'center center'\n              }\"\n            ></div>\n\n            <div class=\"card-body\">\n              <p class=\"card-text\" [class.rtl]=\"item.rtl\">\n                {{ item.excerpt }}\n              </p>\n              <div class=\"d-flex justify-content-between align-items-center\">\n                <small class=\"text-muted\">{{ item.date }}</small>\n              </div>\n            </div>\n          </div>\n        </a>\n      </ng-container>\n    </div>\n  </div>\n</section>\n"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: -webkit-gradient(linear, left top, right top, from(#e03f8d), color-stop(#a22ccf), to(#2fa0df));\n  background: linear-gradient(to right, #e03f8d, #a22ccf, #2fa0df);\n  height: 30em;\n  background-size: cover !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    height: auto;\n    min-height: 15em;\n  }\n}\n:host .header.pringles {\n  background-size: cover !important;\n  background-position: center !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header.extra .title {\n  width: 60%;\n  margin: auto;\n}\n:host .header .logo {\n  max-width: 5em;\n  display: block;\n  margin: 1em auto;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n  }\n}\n:host .header .subtitle {\n  font-size: 1.2rem;\n  margin: auto;\n  font-weight: 200;\n  text-align: center;\n  padding-top: 0.5em;\n}\n@media (max-width: 768px) {\n  :host .header .subtitle {\n    width: 85%;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.ts ***!
  \************************************************************************/
/*! exports provided: InnerHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderComponent", function() { return InnerHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/mobile-detection.service */ "./src/app/core/services/mobile-detection.service.ts");



let InnerHeaderComponent = class InnerHeaderComponent {
    constructor(_mobileDetection, locale) {
        this._mobileDetection = _mobileDetection;
        this.locale = locale;
        this.locale =
            this.locale && this.locale !== null
                ? this.locale.indexOf('en') > -1
                    ? 'en'
                    : this.locale
                : 'en';
    }
    ngOnInit() {
        this._mobileDetection.verticalScreen.subscribe(isVertical => {
            if (this.backgroundHeader.mainimagemobile) {
                const image = isVertical
                    ? this.backgroundHeader.mainimagemobile
                    : this.backgroundHeader.mainimage;
                this.setBackgroundImage(image, this.backgroundHeader.backgroundcolor);
            }
        });
    }
    setBackgroundImage(img, color) {
        const backgroundcolor = color && color !== null && color !== ''
            ? color
            : 'linear-gradient(to right, #E03F8D, #A22CCF, #2FA0DF)';
        this.backgroundimage = Object.assign({}, this.backgroundimage, { background: 'url(' +
                img +
                ') 0% 0%,' + backgroundcolor });
    }
    ngOnChanges() {
        if (this.backgroundHeader && this.backgroundHeader !== null) {
            if (this.backgroundHeader.mainimage) {
                this.backgroundimage = {
                    'background-size': 'cover',
                };
                this.setBackgroundImage(this.backgroundHeader.mainimage);
            }
            if (this.backgroundHeader.type) {
                const headerElt = document.getElementById('headerid');
                if (headerElt && headerElt !== null) {
                    headerElt.classList.add(this.backgroundHeader.type);
                }
            }
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('backgroundHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "backgroundHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('smallerHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "smallerHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "isWave", void 0);
InnerHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-inner-header',
        template: __webpack_require__(/*! raw-loader!./inner-header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html"),
        styles: [__webpack_require__(/*! ./inner-header.component.scss */ "./src/app/core/components/inner-header/inner-header.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__["MobileDetectionService"], String])
], InnerHeaderComponent);



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.module.ts ***!
  \*********************************************************************/
/*! exports provided: InnerHeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderModule", function() { return InnerHeaderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.component */ "./src/app/core/components/inner-header/inner-header.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");





let InnerHeaderModule = class InnerHeaderModule {
};
InnerHeaderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__["PipesModule"]],
        declarations: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        exports: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], InnerHeaderModule);



/***/ }),

/***/ "./src/app/core/services/landing.service.ts":
/*!**************************************************!*\
  !*** ./src/app/core/services/landing.service.ts ***!
  \**************************************************/
/*! exports provided: LandingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingService", function() { return LandingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../core/enums/enums */ "./src/app/core/enums/enums.ts");









let LandingService = class LandingService {
    constructor(http, store, locale) {
        this.http = http;
        this.store = store;
        this.locale = locale;
    }
    getLandingPage() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('timestamp', date.toString())
            .set('type', 'GETLandingpagev2');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["timeout"])(3000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    getTeamMembers() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETTeam');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    getPress() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETPress');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                const newdata = data.sections[0].data.map(item => {
                    return Object.assign({}, item, { excerpt: item.excerpt.substring(0, 150) + '...' });
                });
                data.sections[0].data = newdata;
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    getSesssionsInfo() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETongroundeventinfo')
            .set('event_name', 'anghamisessions');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    SubmitSessionInfo(info) {
        const date = new Date().getTime();
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'POSTongroundeventattender.view');
        for (const key in info) {
            if (info.hasOwnProperty(key)) {
                body = body.set(key, info[key]);
            }
        }
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        });
    }
    getWebPurchaseOptions(params) {
        const date = new Date().getTime();
        let appSidFromUrl = this.getQueryFromUrl('appsid') || this.getQueryFromUrl('sid');
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETwebpurchaseoptions')
            .set('studentsoffer', '1');
        if (appSidFromUrl) {
            body = body.set("sid", appSidFromUrl);
        }
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err);
        }));
    }
    getQueryFromUrl(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split('&');
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split('=');
            if (decodeURIComponent(pair[0]) == variable) {
                return decodeURIComponent(pair[1]);
            }
        }
        return null;
    }
    postStudentsOfferProfileUpdates(params) {
        const date = new Date().getTime();
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        let successevent;
        let failevent;
        let appSidFromUrl = this.getQueryFromUrl('appsid') || this.getQueryFromUrl('sid');
        if (appSidFromUrl) {
            body = body.set('sid', appSidFromUrl);
        }
        if (params.email) {
            body = body.set('type', 'POSTaddemail').set('email', params.email);
            successevent = _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].studentOfferEmailSuccess;
            failevent = _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].studentOfferEmailFail;
        }
        else if (params.birthdate) {
            successevent = 'studentOfferEmailSuccess';
            failevent = 'studentOfferEmailFail';
            body = body
                .set('type', 'UPDATEprofile')
                .set('birthdate', params.birthdate);
        }
        else if (params.card_number && params.cardholder_name) {
            successevent = 'studentOfferISICSuccess';
            failevent = 'studentOfferISICFail';
            body = body
                .set('type', 'POSTisicmembership')
                .set('card_number', params.card_number)
                .set('cardholder_name', params.cardholder_name);
        }
        else {
            return;
        }
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: failevent,
                    props: {
                        details: data
                    }
                }));
            }
            else {
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: successevent,
                    props: {
                        details: data
                    }
                }));
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                name: failevent,
                props: {
                    details: err
                }
            }));
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err);
        }));
    }
    validateEmailToken(params) {
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        if (params && params !== null) {
            body = body.set('type', 'POSTvalidatemailtoken');
            for (const key of Object.keys(params)) {
                body = body.set(key, params[key]);
            }
        }
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
};
LandingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"], String])
], LandingService);



/***/ }),

/***/ "./src/app/core/services/mobile-detection.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/services/mobile-detection.service.ts ***!
  \***********************************************************/
/*! exports provided: MobileDetectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileDetectionService", function() { return MobileDetectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");





let MobileDetectionService = class MobileDetectionService {
    constructor(_cookie, utils) {
        this._cookie = _cookie;
        this.utils = utils;
        this.verticalScreen = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"]();
        if (this.utils.isBrowser()) {
            this.detectVerticalScreen();
            window.addEventListener('resize', () => {
                this.resizeThrottler();
            }, false);
        }
    }
    resizeThrottler() {
        if (this.utils.isBrowser()) {
            if (!this.resizeTimeout) {
                this.resizeTimeout = setTimeout(() => {
                    this.resizeTimeout = null;
                    this.detectVerticalScreen();
                }, 200);
            }
        }
    }
    detectVerticalScreen() {
        this.device = this._cookie.get('device');
        const width = window.innerWidth < 768 ? true : false;
        const ismobile = this.device && (this.device === 'android' || this.device === 'ios')
            ? true
            : false;
        this.verticalScreen.next(width || ismobile ? true : false);
    }
    getVerticalScreen() {
        return this.verticalScreen.asObservable();
    }
};
MobileDetectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_cookie__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
], MobileDetectionService);



/***/ }),

/***/ "./src/app/modules/landing/press/press.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/landing/press/press.component.ts ***!
  \**********************************************************/
/*! exports provided: PressComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PressComponent", function() { return PressComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _core_services_landing_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/services/landing.service */ "./src/app/core/services/landing.service.ts");




let PressComponent = class PressComponent {
    constructor(locale, store, landingservice) {
        this.locale = locale;
        this.store = store;
        this.landingservice = landingservice;
        this.innerHeader = [];
        this.innerHeader.title =
            locale === 'ar' ? 'صحافة' : locale === 'fr' ? 'Presse' : 'Press';
    }
    ngOnInit() {
        this.press$ = this.landingservice.getPress();
    }
};
PressComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-landing-home',
        template: __webpack_require__(/*! raw-loader!./press.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/press/press.component.html"),
        styles: ["\n      .press-item {\n        text-decoration: none;\n      }\n      .press-image {\n        height: 8em;\n        margin: 2em;\n      }\n      .card-text {\n        text-decoration: none;\n        color: #333;\n        min-height: 7em;\n      }\n      .card-text.rtl {\n        direction: rt;\n      }\n    "]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String, _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
        _core_services_landing_service__WEBPACK_IMPORTED_MODULE_3__["LandingService"]])
], PressComponent);



/***/ }),

/***/ "./src/app/modules/landing/press/press.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/modules/landing/press/press.module.ts ***!
  \*******************************************************/
/*! exports provided: PressModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PressModule", function() { return PressModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _press_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./press.component */ "./src/app/modules/landing/press/press.component.ts");
/* harmony import */ var _press_route__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./press.route */ "./src/app/modules/landing/press/press.route.ts");
/* harmony import */ var _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.module */ "./src/app/core/components/inner-header/inner-header.module.ts");








let PressModule = class PressModule {
};
PressModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
            _press_route__WEBPACK_IMPORTED_MODULE_6__["PressRoutingModule"],
            _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_7__["InnerHeaderModule"]
        ],
        declarations: [_press_component__WEBPACK_IMPORTED_MODULE_5__["PressComponent"]],
        exports: [_press_component__WEBPACK_IMPORTED_MODULE_5__["PressComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], PressModule);



/***/ }),

/***/ "./src/app/modules/landing/press/press.route.ts":
/*!******************************************************!*\
  !*** ./src/app/modules/landing/press/press.route.ts ***!
  \******************************************************/
/*! exports provided: routes, PressRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PressRoutingModule", function() { return PressRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _press_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./press.component */ "./src/app/modules/landing/press/press.component.ts");




const routes = [
    {
        path: '',
        component: _press_component__WEBPACK_IMPORTED_MODULE_3__["PressComponent"]
    }
];
let PressRoutingModule = class PressRoutingModule {
};
PressRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        providers: []
    })
], PressRoutingModule);



/***/ })

}]);