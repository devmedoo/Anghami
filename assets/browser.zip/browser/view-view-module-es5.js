(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["view-view-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/collection-header-banner/collection-header-banner.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/collection-header-banner/collection-header-banner.component.html ***!
  \****************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"collection-header\">\n  <ng-container *ngIf=\"collectionType==='video'\">\n    <anghami-video [collectionMeta]=\"collectionMeta\" [collectionSections]=\"collectionSections\"></anghami-video>\n  </ng-container>\n\n  <ng-container *ngIf=\"collectionType!=='video'\">\n    <div class=\"title-container\">\n      <h1 class=\"collection-title\" [class.verified]=\"collectionMeta.verified==1\">\n        <div class='title-with-back' *ngIf=\"collectionType === 'tag'\">\n          <anghami-icon (click)=\"backButtonClick()\" class='icon' [data]=\"'arrow-back'\"></anghami-icon>\n          <img [src]=\"collectionMeta.coverArtImage\" [attr.alt]=\"collectionMeta.title\" class=\"collection-cover-img\" />\n          <ng-container *ngIf=\"collectionType!='profile'\">\n            {{ collectionMeta.name ||  collectionMeta.title }}\n          </ng-container>\n        </div>\n        <ng-container *ngIf=\"collectionType!='profile' && collectionType!='tag'\">\n          {{ collectionMeta.name ||  collectionMeta.title }}\n        </ng-container>\n\n        <ng-container *ngIf=\"collectionType=='profile'\">\n          {{ collectionMeta.fname + ' ' + collectionMeta.lname }}\n        </ng-container>\n\n        <div *ngIf=\"collectionMeta.verified==1 && collectionType === 'artist'\" class=\"verified-artist\"></div>\n        <div *ngIf=\"collectionMeta.explicit == 1\" class=\"explicit\">\n          <span class=\"e-block\">e</span>\n        </div>\n        <anghami-icon class=\"icon private\" [data]=\"'lock'\"\n          *ngIf=\"collectionMeta.public != 'true' && collectionType == 'playlist'\"></anghami-icon>\n      </h1>\n\n      <ng-container *ngIf=\"collectionMeta.languageselector && collectionMeta.languageselector.length > 1\">\n        <anghami-music-language-selector class=\"music-langselector\"\n          [languageSelectorOptions]=\"collectionMeta.languageselector\"></anghami-music-language-selector>\n      </ng-container>\n    </div>\n\n    <div class=\"by\" *ngIf=\"collectionType !== 'podcast'\">\n      <ng-container *ngIf=\"collectionMeta?.OwnerName && collectionMeta?.OwnerID != userData?.anid\">\n        <div class=\"mt-1 mb-1\">\n          <img *ngIf=\"collectionMeta.OwnerPicture !== undefined\" [src]=\"collectionMeta.OwnerPicture\"\n            [attr.alt]=\"collectionMeta.OwnerName\" />\n          <a [routerLink]=\"['/profile', collectionMeta.OwnerID]\">{{ collectionMeta.OwnerName }}\n          </a>\n        </div>\n      </ng-container>\n      <div class=\"mt-1 mb-1\">\n        <img *ngIf=\"collectionMeta.ArtistArt !== 'undefined' && collectionMeta?.artistID\"\n          [src]=\"collectionMeta.ArtistArt\" [attr.alt]=\"collectionMeta.artist\" />\n        <a *ngIf=\"collectionMeta?.artistID\"\n          [routerLink]=\"[collectionMeta?.is_podcast ? '/podcaster' : '/artist', collectionMeta?.artistID]\"\n          [class.disabled]=\"collectionMeta?.artistID == '414'\">{{ collectionMeta.artist }}\n        </a>\n      </div>\n    </div>\n    <ng-container *ngIf=\"collectionType === 'podcast'; else elseTemplate\">\n      <div class='info-description podcast' *ngIf=\"collectionMeta.description && collectionMeta.description.fullText\">\n        <ng-container *ngIf=\"podcastDescriptionShowAll; else podcastElselseTemplate\">\n          <p>\n            {{ collectionMeta.description.fullText }}\n            <span *ngIf=\"collectionMeta.description.showMore\" (click)=\"togglePodcastDescriptionShowMore()\"\n              i18n=\"@@show_less\"> Show less </span>\n          </p>\n        </ng-container>\n        <ng-template #podcastElselseTemplate>\n          <p>\n            {{ collectionMeta.description.shortenText }}\n            <span (click)=\"togglePodcastDescriptionShowMore()\" i18n=\"@@show_more\">Show more </span>\n          </p>\n        </ng-template>\n      </div>\n    </ng-container>\n    <ng-template #elseTemplate>\n      <div class='info-description'>\n        <p *ngIf=\"isUserOwnProfile\" class=\"mb-0\">{{ '#' + userData?.anid }}</p>\n        <p *ngIf=\"collectionMeta.bio\">{{ collectionMeta.bio }}</p>\n        <p *ngIf=\"collectionMeta.description || collectionMeta.subtitle\">\n          {{ collectionMeta.description || collectionMeta.subtitle }}\n          <ng-container *ngIf=\"collectionMeta.hashtags\">\n            <a [routerLink]=\"['/hashtag', tag.id]\" class=\"hashtag\"\n              *ngFor=\"let tag of collectionMeta.hashtags\">{{ tag.name }}\n            </a>\n          </ng-container>\n        </p>\n      </div>\n    </ng-template>\n  </ng-container>\n\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/error-page/error-page.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/error-page/error-page.component.html ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"code && message; else unknownError\">\n  <div class=\"wrapper text-center w-50 pt-5 m-auto\">\n    <img [src]=\"env + 'error-icon.png'\" alt=\"\" class=\"img-fluid\" width=\"50%\" />\n    <h1 class=\"font-weight-bold\">\n      <!-- <span i18n=\"@@Error\">Oops!</span> -->\n      <!-- {{ code }} -->\n    </h1>\n    <p>{{ message }}</p>\n  </div>\n</ng-container>\n\n<div class=\"text-center\">\n  <a\n    class=\"anghami-primary-btn btn-default-animation\"\n    [routerLink]=\"['/home']\"\n    i18n=\"@@go_to_explore\"\n    >Go To Explore</a\n  >\n</div>\n\n<ng-template #unknownError>\n  <div class=\"wrapper text-center w-50 pt-5 m-auto\">\n    <img [src]=\"env + '500@2x.png'\" alt=\"\" class=\"img-fluid\" width=\"50%\" />\n    <h3 class=\"font-weight-bold\" i18n=\"@@Oops, something went wrong\">\n      Oops! Something went wrong\n    </h3>\n  </div>\n</ng-template>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/jsonld/jsonld.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/jsonld/jsonld.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/placeholders/view-placeholder/view-placeholder.component.html":
/*!*************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/placeholders/view-placeholder/view-placeholder.component.html ***!
  \*************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"view-side\">\n  <div class=\"placeholder-box shine\"></div>\n\n  <div class=\"placeholder-title short shine\"></div>\n  <div class=\"placeholder-title shine\"></div>\n</div>\n\n<div class=\"view-content\">\n  <div class=\"placeholder-title short shine\"></div>\n  <div class=\"placeholder-title shine\"></div>\n  <div class=\"placeholder-track\">\n    <div><div class=\"placeholder-box small shine\"></div></div>\n    <div>\n      <div class=\"placeholder-line short shine\"></div>\n      <div class=\"placeholder-line shine\"></div>\n      <div class=\"placeholder-line shine\"></div>\n    </div>\n  </div>\n  <div class=\"placeholder-track\">\n    <div><div class=\"placeholder-box small shine\"></div></div>\n    <div>\n      <div class=\"placeholder-line short shine\"></div>\n      <div class=\"placeholder-line shine\"></div>\n      <div class=\"placeholder-line shine\"></div>\n    </div>\n  </div>\n  <div class=\"placeholder-track\">\n    <div><div class=\"placeholder-box small shine\"></div></div>\n    <div>\n      <div class=\"placeholder-line short shine\"></div>\n      <div class=\"placeholder-line shine\"></div>\n      <div class=\"placeholder-line shine\"></div>\n    </div>\n  </div>\n  <div class=\"mt-5\">\n    <div>\n    <div class=\"placeholder-title shine\"></div>\n      </div>\n      <div>\n    <div class=\"placeholder-video\">\n      <div><div class=\"placeholder-box small shine\"></div></div>\n      <div>\n        <div class=\"placeholder-line short shine\"></div>\n        <div class=\"placeholder-line shine\"></div>\n        <div class=\"placeholder-line shine\"></div>\n      </div>\n    </div>\n\n    <div class=\"placeholder-video\">\n      <div><div class=\"placeholder-box small shine\"></div></div>\n      <div>\n        <div class=\"placeholder-line short shine\"></div>\n        <div class=\"placeholder-line shine\"></div>\n        <div class=\"placeholder-line shine\"></div>\n      </div>\n    </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/view/view.component.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/view/view.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"sectionsHaveCarousel\">\n  <div class=\"ang-main\" *ngIf=\"!carouselInitialized\">\n    <anghami-view-placeholder></anghami-view-placeholder>\n  </div>\n</ng-container>\n<ng-container *ngIf=\"!sectionsHaveCarousel\">\n  <div class=\"ang-main\" *ngIf=\"(!collectionMeta && !error)\">\n    <anghami-view-placeholder></anghami-view-placeholder>\n  </div>\n</ng-container>\n\n<div class=\"ang-main\" infiniteScroll [infiniteScrollDistance]=\"2\" [infiniteScrollThrottle]=\"50\"\n  (scrolled)=\"loadMoreViewSections()\" role=\"main\" *ngIf=\"collectionMeta\">\n  <div class=\"view-side\" *ngIf=\"!hideSideView && !(isLikesOrDownloads && isLikesOrDownloadsEmpty)\">\n    <ng-container *ngIf=\"collectionMeta && collectionSections\">\n      <anghami-collection-header-side [collectionSections]=\"collectionSections\" [collectionMeta]=\"collectionMeta\"\n        [collectionType]=\"type\"></anghami-collection-header-side>\n    </ng-container>\n  </div>\n  <div class=\"view-content\">\n\n    <div class=\"auto-downloads-btn float-right\" *ngIf=\"shouldShowAutoDownloadsComponent\">\n      <button class=\"anghami-primary-btn\" (click)=\"goToOnOtherDevices()\">\n        <span i18n=\"@@Downloads_on_other_devices\">Downloads on other devices</span>\n      </button>\n    </div>\n    \n    <anghami-collection-header-banner [collectionSections]=\"collectionSections\" [collectionMeta]=\"collectionMeta\"\n      [collectionType]=\"type\" *ngIf=\"!(isLikesOrDownloads && isLikesOrDownloadsEmpty)\"></anghami-collection-header-banner>\n    <ng-container *ngIf=\"type\">\n      <ng-container *ngIf=\"type && collectionSections && !isListSectionEmpty\">\n        <ng-container *ngIf=\"isDesktopClient && downloadQueue?.length > 0\">\n          <div class=\"download-queue-section\" (click)=\"goToDownloadQueuePage()\">\n            <div class=\"download-icon-container\">\n              <span>\n                <anghami-icon class=\"icon download-icon\" [data]=\"'download'\" *ngIf=\"!downloadQueueState?.paused\">\n                </anghami-icon>\n                <anghami-icon class=\"icon download-icon\" [data]=\"'download-paused'\" *ngIf=\"downloadQueueState?.paused\">\n                </anghami-icon>\n              </span>\n            </div>\n            <div class=\"download-queue-label\">\n              <span>\n                <ng-container i18n=\"@@Downloading\">Downloading</ng-container>\n                {{ translateNumber(downloadQueue.length) }}\n                <ng-container i18n=\"@@Songs\" *ngIf=\"downloadQueue.length > 1\">\n                  Songs\n                </ng-container>\n                <ng-container i18n=\"@@Song\" *ngIf=\"downloadQueue.length === 1\">\n                  Song\n                </ng-container>\n              </span>\n            </div>\n            <div class=\"arrow-container\">\n              <span>\n                <anghami-icon class=\"icon arrow-left\" [data]=\"'arrow-left'\"></anghami-icon>\n              </span>\n            </div>\n            <div class=\"pause-label-container\">\n              <span class=\"pause-label\">\n                {{ downloadQueueState?.paused ? 'Paused' : '' }}\n              </span>\n            </div>\n          </div>\n        </ng-container>\n        <anghami-new-section-builder #sectionBuilder [sections]=\"collectionSections\" [searchTerm]=\"searchTerm\"\n          #sectionBuilder [type]=\"type\" [collectionMeta]=\"collectionMeta\" [isView]=\"true && !hideSideView\"\n          (carouselInitialized)=\"setCarouselInitializationState($event)\" [isLikesOrDownloads]=\"isLikesOrDownloads\">\n        </anghami-new-section-builder>\n      </ng-container>\n      <ng-container *ngIf=\"isListSectionEmpty && type === 'profile'\">\n        <anghami-empty-pages [type]=\"type\" [data]=\"collectionMeta\"></anghami-empty-pages>\n      </ng-container>\n      <ng-container *ngIf=\"isLikesOrDownloads && isLikesOrDownloadsEmpty\">\n        <anghami-empty-pages [type]=\"likesOrDownloadsEmptyPageType\"></anghami-empty-pages>\n      </ng-container>\n    </ng-container>\n  </div>\n</div>\n<ng-container *ngIf=\"error\">\n  <anghami-error-page [errorMeta]=\"errorMeta\"></anghami-error-page>\n</ng-container>\n<ng-container *ngIf=\"jsonLdCollectionMeta\">\n  <anghami-jsonld [collectionMeta]=\"jsonLdCollectionMeta\" [type]=\"jsonLdType\" [collectionSections]=\"jsonLdSections\">\n  </anghami-jsonld>\n</ng-container>"

/***/ }),

/***/ "./src/app/core/components/collection-header-banner/collection-header-banner.component.scss":
/*!**************************************************************************************************!*\
  !*** ./src/app/core/components/collection-header-banner/collection-header-banner.component.scss ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: block;\n}\n:host .collection-title {\n  margin: 0 0 0em 0;\n  font-size: 3em;\n  font-weight: bold;\n  position: relative;\n}\n:host .collection-title .title-with-back {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n:host .collection-title .title-with-back anghami-icon {\n  font-size: 0.3em;\n  margin-right: 0.5em;\n  cursor: pointer;\n}\n:host .collection-title .title-with-back anghami-icon:lang(ar) {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n:host .collection-title .title-with-back .collection-cover-img {\n  width: 1.5em;\n  border-radius: 0.3em;\n  box-shadow: var(--gray-shadow);\n  display: block;\n  margin: auto 0.3em auto 0.3em;\n}\n:host .collection-title .private {\n  font-size: 0.5em;\n  display: inline-block;\n  vertical-align: middle;\n}\n:host .collection-title.verified {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .collection-title.verified .verified-artist {\n  width: 0.5em;\n  height: 0.5em;\n  margin: 0.4em 0.1em;\n}\n:host .collection-title .explicit {\n  width: 0.5em;\n  height: 0.5em;\n  right: -1.5em;\n  bottom: 0.25em;\n  font-family: var(--font-main-latin);\n}\n:host .by img {\n  width: 1.2em;\n  height: 1.2em;\n  background: #aaa;\n  border-radius: 50%;\n  vertical-align: middle;\n  display: inline-block;\n}\n:host .by a {\n  color: var(--text-color);\n  margin: 0 0.5em;\n  position: relative;\n  font-weight: lighter;\n  font-size: 1.2em;\n  text-decoration: none;\n  vertical-align: middle;\n  display: inline-block;\n}\n:host .by a:hover {\n  font-weight: 500;\n}\n:host .info-description span {\n  cursor: pointer;\n  font-weight: bolder;\n  text-decoration: underline;\n}\n:host .info-description.podcast {\n  margin-bottom: -1em;\n}\n:host .hashtag {\n  color: var(--hashtags-color);\n}\n:host .title-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  margin-bottom: 0.5em;\n}\n:host .title-container anghami-music-language-selector {\n  margin-left: 2em;\n  margin-top: 0.5em;\n}\n:host .title-container h1 {\n  margin-bottom: 0.3em;\n}\n:host .title-container:lang(ar) {\n  text-align: right;\n}\n:host .title-container:lang(ar) anghami-music-language-selector {\n  margin-left: 0em;\n  margin-top: 0.35em;\n}\n:host .header-pullup:lang(ar) {\n  text-align: right;\n}\n:host .info-description:lang(ar) p {\n  text-align: right;\n}\nhtml[lang=ar] :host .collection-title .explicit {\n  bottom: 29% !important;\n  right: 106% !important;\n}"

/***/ }),

/***/ "./src/app/core/components/collection-header-banner/collection-header-banner.component.ts":
/*!************************************************************************************************!*\
  !*** ./src/app/core/components/collection-header-banner/collection-header-banner.component.ts ***!
  \************************************************************************************************/
/*! exports provided: CollectionHeaderBannerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CollectionHeaderBannerComponent", function() { return CollectionHeaderBannerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");








var CollectionHeaderBannerComponent = /** @class */ (function () {
    function CollectionHeaderBannerComponent(store, _location) {
        this.store = store;
        this._location = _location;
        this.isUserOwnProfile = false;
        this.podcastDescriptionShowAll = true;
    }
    CollectionHeaderBannerComponent.prototype.checkIfOwnUser = function () {
        var _this = this;
        this.userSubscription = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_6__["getUser"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(function (user) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(user);
        }))
            .subscribe(function (user) {
            if (user) {
                if (user && _this.collectionMeta) {
                    _this.isUserOwnProfile = user.anid == _this.collectionMeta.id;
                }
                _this.userData = user;
            }
        });
    };
    CollectionHeaderBannerComponent.prototype.ngOnInit = function () {
        this.checkIfOwnUser();
        if (this.collectionType === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_3__["CollectionTypes"].ALBUM && this.collectionMeta.isPodcast === 1) {
            this.collectionType = _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_3__["CollectionTypes"].PODCAST;
            var descriptionSection = this.collectionSections.find(function (c) { return c.type === 'text'; });
            if (descriptionSection && descriptionSection.text) {
                var description = {
                    fullText: descriptionSection.text,
                    showMore: false,
                    shortenText: descriptionSection.text
                };
                if (descriptionSection.text.length > 300) {
                    description.showMore = true;
                    description.shortenText = description.fullText.substr(0, 300);
                    this.podcastDescriptionShowAll = false;
                }
                this.collectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.collectionMeta, { description: description });
            }
        }
    };
    CollectionHeaderBannerComponent.prototype.togglePodcastDescriptionShowMore = function () {
        this.podcastDescriptionShowAll = !this.podcastDescriptionShowAll;
    };
    CollectionHeaderBannerComponent.prototype.ngOnDestroy = function () {
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
    };
    CollectionHeaderBannerComponent.prototype.backButtonClick = function () {
        this._location.back();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CollectionHeaderBannerComponent.prototype, "collectionMeta", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CollectionHeaderBannerComponent.prototype, "collectionSections", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CollectionHeaderBannerComponent.prototype, "collectionType", void 0);
    CollectionHeaderBannerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'anghami-collection-header-banner',
            template: __webpack_require__(/*! raw-loader!./collection-header-banner.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/collection-header-banner/collection-header-banner.component.html"),
            styles: [__webpack_require__(/*! ./collection-header-banner.component.scss */ "./src/app/core/components/collection-header-banner/collection-header-banner.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["Location"]])
    ], CollectionHeaderBannerComponent);
    return CollectionHeaderBannerComponent;
}());



/***/ }),

/***/ "./src/app/core/components/collection-header-banner/collection-header-banner.module.ts":
/*!*********************************************************************************************!*\
  !*** ./src/app/core/components/collection-header-banner/collection-header-banner.module.ts ***!
  \*********************************************************************************************/
/*! exports provided: CollectionHeaderBannerModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CollectionHeaderBannerModule", function() { return CollectionHeaderBannerModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_components_ang_header_stories_ang_header_stories_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/components/ang-header-stories/ang-header-stories.module */ "./src/app/core/components/ang-header-stories/ang-header-stories.module.ts");
/* harmony import */ var _components_collection_header_banner_collection_header_banner_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/collection-header-banner/collection-header-banner.component */ "./src/app/core/components/collection-header-banner/collection-header-banner.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _core_components_ang_video_ang_video_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/components/ang-video/ang-video.module */ "./src/app/core/components/ang-video/ang-video.module.ts");
/* harmony import */ var _music_language_selector_music_language_selector_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../music-language-selector/music-language-selector.module */ "./src/app/core/components/music-language-selector/music-language-selector.module.ts");












var CollectionHeaderBannerModule = /** @class */ (function () {
    function CollectionHeaderBannerModule() {
    }
    CollectionHeaderBannerModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _core_components_ang_header_stories_ang_header_stories_module__WEBPACK_IMPORTED_MODULE_4__["AngHeaderStoriesModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"],
                _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_6__["PipesModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__["NgbModule"],
                _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_9__["IconModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"],
                _core_components_ang_video_ang_video_module__WEBPACK_IMPORTED_MODULE_10__["AngVideoModule"],
                _music_language_selector_music_language_selector_module__WEBPACK_IMPORTED_MODULE_11__["MusicLanguageSelectorModule"]
            ],
            declarations: [
                _components_collection_header_banner_collection_header_banner_component__WEBPACK_IMPORTED_MODULE_5__["CollectionHeaderBannerComponent"],
            ],
            exports: [_components_collection_header_banner_collection_header_banner_component__WEBPACK_IMPORTED_MODULE_5__["CollectionHeaderBannerComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], CollectionHeaderBannerModule);
    return CollectionHeaderBannerModule;
}());



/***/ }),

/***/ "./src/app/core/components/error-page/error-page.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/core/components/error-page/error-page.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "a:hover {\n  color: white;\n}"

/***/ }),

/***/ "./src/app/core/components/error-page/error-page.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/core/components/error-page/error-page.component.ts ***!
  \********************************************************************/
/*! exports provided: ErrorPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ErrorPageComponent", function() { return ErrorPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");




var ErrorPageComponent = /** @class */ (function () {
    function ErrorPageComponent(platformId, injector) {
        this.platformId = platformId;
        this.injector = injector;
        this.env = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].assetsCDN + "img/404/";
    }
    ErrorPageComponent.prototype.ngOnInit = function () {
        if (this.errorMeta) {
            this.code = this.errorMeta.code;
            this.message = this.errorMeta.message;
        }
        else {
            this.code = 404;
            this.message = '';
        }
        if (!Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["isPlatformBrowser"])(this.platformId)) {
            var response = this.injector.get('RESPONSE');
            if (this.code >= 500) {
                response.status(this.code);
            }
            else {
                response.status(404);
            }
        }
    };
    ErrorPageComponent.prototype.ngOnChanges = function () {
        if (this.errorMeta) {
            this.code = this.errorMeta.code;
            this.message = this.errorMeta.message;
        }
        else {
            this.code = 404;
            this.message = "";
        }
        if (!Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["isPlatformBrowser"])(this.platformId)) {
            var response = this.injector.get('RESPONSE');
            if (this.code >= 500) {
                response.status(this.code);
            }
            else {
                response.status(404);
            }
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('errorMeta'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ErrorPageComponent.prototype, "errorMeta", void 0);
    ErrorPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-error-page',
            template: __webpack_require__(/*! raw-loader!./error-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/error-page/error-page.component.html"),
            styles: [__webpack_require__(/*! ./error-page.component.scss */ "./src/app/core/components/error-page/error-page.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object,
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injector"]])
    ], ErrorPageComponent);
    return ErrorPageComponent;
}());



/***/ }),

/***/ "./src/app/core/components/jsonld/jsonld.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/core/components/jsonld/jsonld.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/core/components/jsonld/jsonld.component.ts":
/*!************************************************************!*\
  !*** ./src/app/core/components/jsonld/jsonld.component.ts ***!
  \************************************************************/
/*! exports provided: JsonldComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JsonldComponent", function() { return JsonldComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");



var JsonldComponent = /** @class */ (function () {
    function JsonldComponent(_renderer2, _document, platformId) {
        this._renderer2 = _renderer2;
        this._document = _document;
        this.platformId = platformId;
    }
    JsonldComponent.prototype.ngOnChanges = function () {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["isPlatformServer"])(this.platformId)) {
            this.createAndAppendJsonLd();
        }
    };
    JsonldComponent.prototype.createAndAppendJsonLd = function () {
        this.script = this._renderer2.createElement('script');
        this.script.type = "application/ld+json";
        var json = {};
        if (this.type === 'album') {
            json = {
                "@context": "http://schema.org/",
                "@type": "MusicAlbum",
                "name": this.collectionMeta.title || '',
                "byArtist": {
                    "@type": "MusicGroup",
                    "name": this.collectionMeta.artist || ''
                },
                "image": this.collectionMeta.coverArtImage || '',
                "url": "",
                "genre": "",
                "numtracks": this.collectionMeta.nbrsongs || '',
                "track": this.getSongList().map(function (song) {
                    return {
                        "@context": "http://schema.org/",
                        "@type": "MusicRecording",
                        "name": song.title || '',
                        "byArtist": {
                            "@type": "MusicGroup",
                            "name": song.artist || ''
                        },
                        "inAlbum": {
                            "@type": "MusicAlbum",
                            "name": song.album || ''
                        },
                        "image": song.coverArtImage || '',
                        "url": "",
                        "genre": song.genre || ''
                    };
                })
            };
        }
        if (this.type === 'playlist') {
            json = {
                "@context": "http://schema.org/",
                "@type": "MusicPlaylist",
                "name": this.collectionMeta.name || '',
                "image": this.collectionMeta.coverArtImage || '',
                "url": "",
                "genre": "",
                "numtracks": this.collectionMeta.numsongs || '',
                "track": this.getSongList().map(function (song) {
                    return {
                        "@context": "http://schema.org/",
                        "@type": "MusicRecording",
                        "name": song.title || '',
                        "byArtist": {
                            "@type": "MusicGroup",
                            "name": song.artist || ''
                        },
                        "inAlbum": {
                            "@type": "MusicAlbum",
                            "name": song.album || ''
                        },
                        "image": song.coverArtImage || '',
                        "url": "",
                        "genre": song.genre || ''
                    };
                })
            };
        }
        if (this.type === 'song') {
            json = {
                "@context": "http://schema.org/",
                "@type": "MusicRecording",
                "name": this.collectionMeta.title || '',
                "byArtist": {
                    "@type": "MusicGroup",
                    "name": this.collectionMeta.artist || ''
                },
                "inAlbum": {
                    "@type": "MusicAlbum",
                    "name": this.collectionMeta.album || ''
                },
                "image": this.collectionMeta.coverArtImage || '',
                "url": "",
                "genre": this.collectionMeta.genre || ''
            };
        }
        if (this.type === 'artist') {
            json = {
                "@context": "http://schema.org/",
                "@type": "MusicGroup",
                "name": this.collectionMeta.name || '',
                "image": this.collectionMeta.ArtistArt || '',
                "track": this.getSongList().map(function (song) {
                    return {
                        "@context": "http://schema.org/",
                        "@type": "MusicRecording",
                        "name": song.title || '',
                        "byArtist": {
                            "@type": "MusicGroup",
                            "name": song.artist || ''
                        },
                        "inAlbum": {
                            "@type": "MusicAlbum",
                            "name": song.album || ''
                        },
                        "image": song.coverArtImage || '',
                        "url": "",
                        "genre": song.genre || ''
                    };
                })
            };
        }
        this.script.text = JSON.stringify(json);
        this._renderer2.appendChild(this._document.body, this.script);
    };
    JsonldComponent.prototype.getSongList = function () {
        return [].concat.apply([], this.collectionSections.filter(function (section) { return section.type === 'song'; }).map(function (section) { return section.data; }));
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], JsonldComponent.prototype, "collectionMeta", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], JsonldComponent.prototype, "collectionSections", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], JsonldComponent.prototype, "type", void 0);
    JsonldComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-jsonld',
            template: __webpack_require__(/*! raw-loader!./jsonld.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/jsonld/jsonld.component.html"),
            styles: [__webpack_require__(/*! ./jsonld.component.scss */ "./src/app/core/components/jsonld/jsonld.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_2__["DOCUMENT"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"],
            Document,
            Object])
    ], JsonldComponent);
    return JsonldComponent;
}());



/***/ }),

/***/ "./src/app/core/components/jsonld/jsonld.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/components/jsonld/jsonld.module.ts ***!
  \*********************************************************/
/*! exports provided: JsonldModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JsonldModule", function() { return JsonldModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _jsonld_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./jsonld.component */ "./src/app/core/components/jsonld/jsonld.component.ts");




var JsonldModule = /** @class */ (function () {
    function JsonldModule() {
    }
    JsonldModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_jsonld_component__WEBPACK_IMPORTED_MODULE_3__["JsonldComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]
            ],
            exports: [_jsonld_component__WEBPACK_IMPORTED_MODULE_3__["JsonldComponent"]]
        })
    ], JsonldModule);
    return JsonldModule;
}());



/***/ }),

/***/ "./src/app/core/components/placeholders/view-placeholder/view-placeholder.component.scss":
/*!***********************************************************************************************!*\
  !*** ./src/app/core/components/placeholders/view-placeholder/view-placeholder.component.scss ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .view-side {\n  width: 19em;\n  float: left;\n  padding: 1em;\n}\n:host .view-content {\n  overflow: hidden;\n  padding: 1em;\n  position: relative;\n}"

/***/ }),

/***/ "./src/app/core/components/placeholders/view-placeholder/view-placeholder.component.ts":
/*!*********************************************************************************************!*\
  !*** ./src/app/core/components/placeholders/view-placeholder/view-placeholder.component.ts ***!
  \*********************************************************************************************/
/*! exports provided: ViewPlaceholderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewPlaceholderComponent", function() { return ViewPlaceholderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ViewPlaceholderComponent = /** @class */ (function () {
    function ViewPlaceholderComponent() {
    }
    ViewPlaceholderComponent.prototype.ngOnInit = function () {
    };
    ViewPlaceholderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-view-placeholder',
            template: __webpack_require__(/*! raw-loader!./view-placeholder.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/placeholders/view-placeholder/view-placeholder.component.html"),
            styles: [__webpack_require__(/*! ./view-placeholder.component.scss */ "./src/app/core/components/placeholders/view-placeholder/view-placeholder.component.scss"), __webpack_require__(/*! ../placeholders.scss */ "./src/app/core/components/placeholders/placeholders.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ViewPlaceholderComponent);
    return ViewPlaceholderComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/view/view-routing.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/base/view/view-routing.module.ts ***!
  \**********************************************************/
/*! exports provided: ViewRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewRoutingModule", function() { return ViewRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _view_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./view.component */ "./src/app/modules/base/view/view.component.ts");
/* harmony import */ var _view_resolver__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./view.resolver */ "./src/app/modules/base/view/view.resolver.ts");





var routes = [
    { path: '', component: _view_component__WEBPACK_IMPORTED_MODULE_3__["ViewComponent"], resolve: { viewData: _view_resolver__WEBPACK_IMPORTED_MODULE_4__["ViewResolver"] } }
];
var ViewRoutingModule = /** @class */ (function () {
    function ViewRoutingModule() {
    }
    ViewRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], ViewRoutingModule);
    return ViewRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/base/view/view.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/modules/base/view/view.component.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .view-side {\n  width: 18em;\n  float: left;\n  padding: 0.5em;\n  padding-left: 0 !important;\n}\n:host .view-content {\n  position: relative;\n  overflow: hidden;\n  padding: 1em;\n}\n:host anghami-collection-header-side {\n  width: 18em;\n}\n:host .download-queue-section {\n  display: inline-block;\n  width: 100%;\n  text-align: center;\n  cursor: pointer;\n  padding: 1em;\n  margin-top: 2em;\n  margin-bottom: 1em;\n  border-top: 1px solid var(--bg-white-secondary);\n  border-bottom: 1px solid var(--bg-white-secondary);\n}\n:host .download-queue-section .icon {\n  display: inline-block;\n  vertical-align: middle;\n}\n:host .download-queue-section .download-icon-container {\n  margin: 0 0.5em;\n  display: inline-block;\n}\n:host .download-queue-section .download-icon-container ::ng-deep svg {\n  font-size: 1.5em;\n}\n:host .download-queue-section .download-queue-label {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  font-weight: bold;\n  font-size: 1.1em;\n}\n:host .download-queue-section .download-icon {\n  margin-right: 0.3em;\n  color: var(--download-icon-color);\n  position: relative;\n  bottom: 0.1em;\n}\n:host .download-queue-section .arrow-container {\n  margin: 0 0.5em;\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  position: relative;\n  bottom: 0.06em;\n}\n:host .download-queue-section .pause-label-container {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n}\n:host .download-queue-section .pause-label-container .pause-label {\n  color: var(--download-icon-color);\n}\n:host .download-queue-section .arrow-left {\n  font-size: 0.6em;\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n  margin-right: 0.2em;\n}\n:host .auto-downloads-btn button {\n  background-color: var(--search-background);\n}\n:host .auto-downloads-btn button span {\n  color: var(--text-color);\n}\n.section-loader,\n.section-loader:after {\n  border-radius: 50%;\n  width: 4em;\n  height: 4em;\n}\nhtml[lang=ar] :host .view-side {\n  width: 18em;\n  float: right;\n}"

/***/ }),

/***/ "./src/app/modules/base/view/view.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/modules/base/view/view.component.ts ***!
  \*****************************************************/
/*! exports provided: ViewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewComponent", function() { return ViewComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _core_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _core_services_metas_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/services/metas.service */ "./src/app/core/services/metas.service.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _app_core_components_new_section_builder_new_section_builder_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../app/core/components/new-section-builder/new-section-builder.component */ "./src/app/core/components/new-section-builder/new-section-builder.component.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _core_enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/enums/special-playlist-names.enum */ "./src/app/core/enums/special-playlist-names.enum.ts");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/services/desktop-download.service */ "./src/app/core/services/desktop-download.service.ts");
/* harmony import */ var _anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/redux/selectors/desktop-client.selectors */ "./src/app/core/redux/selectors/desktop-client.selectors.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");






















var VIEW_KEY = Object(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__["makeStateKey"])('view');
var ViewComponent = /** @class */ (function () {
    function ViewComponent(store, _metaService, _actionsSubject, router, route, state, sectionService, platformId, locale, translateService, desktopDownloadsService, changeDetectorRef, utilityService) {
        var _this = this;
        this.store = store;
        this._metaService = _metaService;
        this._actionsSubject = _actionsSubject;
        this.router = router;
        this.route = route;
        this.state = state;
        this.sectionService = sectionService;
        this.platformId = platformId;
        this.locale = locale;
        this.translateService = translateService;
        this.desktopDownloadsService = desktopDownloadsService;
        this.changeDetectorRef = changeDetectorRef;
        this.utilityService = utilityService;
        this.class = 'ang-view';
        this.carouselInitialized = false;
        this.likesOrDownloadsTemporaryNumItems = 200;
        this.oldContentIds = [];
        // Desktop Downloads
        this.isDesktopClient = !!window['desktopClient'];
        this.downloadQueue = [];
        this.shouldShowAutoDownloadsComponent = false;
        this.routerSubscription = this.router.events.subscribe(function (val) {
            if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_3__["NavigationEnd"]) {
                _this.originalSections = null; // reset original sections
            }
            if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_3__["ResolveStart"]) {
                _this.collectionSections = [];
                _this.collectionMeta = null;
                _this.type = '';
                _this.sectionsHaveCarousel = false;
            }
        });
        this.actionSubjectSubs = this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_7__["ofType"])(_core_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_5__["CollectionActionTypes"].GetCollectionSuccessNew))
            .subscribe(function (res) {
            if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_8__["isPlatformServer"])(_this.platformId)) {
                var payload = res.payload;
                var collectionData = {
                    sections: _this.collectionSections,
                    collectionType: _this.type,
                    collectionId: _this.collectionId,
                    collectionMeta: _this.collectionMeta
                };
                _this.state.set(VIEW_KEY, collectionData);
                _this.sectionsHaveCarousel = _this.checkIfSectionsHaveCarousel(_this.collectionSections);
                _this.hideSideView = true;
                _this.prepareViewData(payload);
            }
            else {
                var payload = res.payload;
                _this.error = false;
                if (payload.fromPaginatedRequest) {
                    _this.collectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, payload.collectionMeta, { buttons: _this.collectionMeta.buttons });
                    if (payload.sections && payload.sections.length > 0) {
                        _this.collectionSections = _this.sectionService.checkAndMergeSections(_this.collectionSections, payload.sections);
                    }
                }
                else {
                    _this.prepareViewData(payload);
                }
                _this.handleOnOtherDevicesPlaylistName();
            }
        });
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_7__["ofType"])(_core_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_5__["CollectionActionTypes"].GetCollectionError))
            .subscribe(function (res) {
            if (res.payload) {
                if (res.payload.error) {
                    _this.error = true;
                    _this.errorMeta = res.payload.error;
                }
                else {
                    _this.error = true;
                    _this.errorMeta = res.payload;
                }
            }
        });
        if (this.router.url === '/likes') {
            this.isLikesOrDownloads = true;
            this.likesOrDownloadsPipeCount = 0;
            this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_14__["getLikedSongsState"]))
                .subscribe(function (data) {
                if (data && data !== null) {
                    _this.likesOrDownloadsPipeCount++;
                    _this.type = data.list_type;
                    _this.collectionMeta = JSON.parse(JSON.stringify(data));
                    _this.collectionSections = JSON.parse(JSON.stringify(data.sections));
                    _this.collectionSections = _this.collectionSections.map(function (section) {
                        if (section.type === 'song') {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, section, { initialNumItems: _this.likesOrDownloadsPipeCount === 1 ? 200 : section.data.length });
                        }
                        else {
                            return section;
                        }
                    });
                    _this.isLikesOrDownloadsEmpty = _this.collectionSections
                        && ((_this.collectionSections.find(function (elt) { return elt.displaytype === 'list' && elt.data.length === 0; }))
                            || _this.collectionSections.length === 0)
                        && (_this.type === 'playlist' || _this.type === 'profile');
                    if (_this.isLikesOrDownloads && _this.isLikesOrDownloadsEmpty) {
                        _this.likesOrDownloadsEmptyPageType = 'likes';
                    }
                }
            });
        }
        if (this.router.url === '/downloads') {
            this.isLikesOrDownloads = true;
            this.likesOrDownloadsPipeCount = 0;
            this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_14__["getDownloadedSongsState"]))
                .subscribe(function (data) {
                if (data && data !== null) {
                    _this.likesOrDownloadsPipeCount++;
                    _this.type = data.list_type;
                    _this.collectionMeta = JSON.parse(JSON.stringify(data));
                    _this.collectionSections = JSON.parse(JSON.stringify(data.sections));
                    _this.collectionSections = _this.collectionSections.map(function (section) {
                        if (section.type === 'song') {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, section, { initialNumItems: _this.likesOrDownloadsPipeCount === 1 ? 200 : section.data.length });
                        }
                        else {
                            return section;
                        }
                    });
                    _this.isLikesOrDownloadsEmpty = _this.collectionSections
                        && ((_this.collectionSections.find(function (elt) { return elt.displaytype === 'list' && elt.data.length === 0; }))
                            || _this.collectionSections.length === 0)
                        && (_this.type === 'playlist' || _this.type === 'profile');
                    if (_this.isLikesOrDownloads && _this.isLikesOrDownloadsEmpty) {
                        _this.likesOrDownloadsEmptyPageType = 'downloads';
                    }
                }
                _this.loadMoreViewSections();
            });
        }
        if (this.router.url === '/desktop-downloads' && this.isDesktopClient) {
            this.isLikesOrDownloads = true;
            this.likesOrDownloadsPipeCount = 0;
            this.collectionMeta = this.desktopDownloadsService.getDownloadsPageStruct();
            this.collectionSections = this.collectionMeta.sections;
            this.type = this.collectionMeta.list_type;
            this.downloadQueueSubscription = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_16__["getDownloadQueue"]))
                .subscribe(function (response) {
                _this.downloadQueue = response;
            });
            this.downloadListSubscription = this.desktopDownloadsService.desktopDownloads$.subscribe(function (response) {
                var struct = _this.desktopDownloadsService.getDownloadsPageStruct();
                _this.collectionMeta = struct;
                _this.collectionSections = _this.collectionMeta.sections;
            });
            this.downloadQueueStateSubscription = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_16__["downloadQueueState"]))
                .subscribe(function (response) {
                _this.downloadQueueState = response;
            });
            this.shouldShowAutoDownloadsComponent = true;
        }
        else {
            this.freeDownloadsSubscriptions();
        }
    }
    ViewComponent.prototype.searchSection = function (term) {
        this.searchTerm = term;
    };
    ViewComponent.prototype.parseUrlAndReportEvent = function (page, id) {
        var contentIds = [];
        if (this.type === 'song' || this.type === 'album') {
            if (!this.collectionMeta.artistID) {
                return;
            }
            contentIds.push("artist_" + this.collectionMeta.artistID);
        }
        else {
            contentIds.push(this.type + "_" + id);
        }
        if (this.oldContentIds.length > 0 &&
            this.oldContentIds[0] === contentIds[0] &&
            this.oldType === this.type &&
            this.oldId === id) {
            // This check is here to fix the multiple pixel event reporting issue
            // because of the collection subscription above throwing multiple times
            return;
        }
        this.oldContentIds = contentIds;
        this.oldType = this.type;
        this.oldId = id;
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["ReportPixelEvent"]({
            eventName: 'viewcontent',
            eventProps: {
                content_ids: contentIds,
                content_type: 'product'
            }
        }));
    };
    ViewComponent.prototype.emptyViewData = function () {
        this.collectionMeta = null;
        this.type = null;
        this.collectionSections = null;
        this.collectionId = null;
    };
    ViewComponent.prototype.prepareViewData = function (payload) {
        var _this = this;
        if (payload && Object.keys(payload).length > 0) {
            // Using the payload data to generate jsonld for search engine optimization
            this.jsonLdCollectionMeta = payload.collectionMeta;
            this.jsonLdType = payload.collectionType;
            this.jsonLdSections = payload.sections;
            var collectionMeta = payload.collectionMeta, collectionType_1 = payload.collectionType, sections = payload.sections, collectionId_1 = payload.collectionId;
            this._metaService.setMetas(collectionType_1, collectionMeta);
            if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_8__["isPlatformBrowser"])(this.platformId)) {
                this.collectionMeta = collectionMeta;
                this.collectionSections = sections;
                this.sectionsHaveCarousel = this.checkIfSectionsHaveCarousel(this.collectionSections);
                this.type = collectionType_1;
                this.isListSectionEmpty = this.collectionSections
                    && ((this.collectionSections.find(function (elt) { return elt.displaytype === 'list' && elt.data.length === 0; }))
                        || this.collectionSections.length === 0)
                    && (this.type === 'playlist' || this.type === 'profile');
                this.collectionId = collectionId_1;
                this.setSelectedSongId();
                this.setSideBarVisibility(collectionType_1);
                setTimeout(function () {
                    _this.parseUrlAndReportEvent(collectionType_1, collectionId_1);
                }, 5000);
            }
        }
    };
    ViewComponent.prototype.setSelectedSongId = function () {
        var _this = this;
        if (this.type === 'album') {
            this.queryParamSubscription = this.route.queryParams.subscribe(function (params) {
                var songid = params.songid;
                _this.collectionSections = _this.collectionSections.map(function (section) {
                    if (section.type === 'song') {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, section, { data: section.data.map(function (song) {
                                if (song.id === songid) {
                                    return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, song, { selectedSongId: true });
                                }
                                else {
                                    return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, song, { selectedSongId: false });
                                }
                            }) });
                    }
                    else {
                        return section;
                    }
                });
            });
        }
    };
    ViewComponent.prototype.loadMoreViewSections = function () {
        var _this = this;
        if (this.sectionBuilder && !this.isLikesOrDownloads) {
            this.sectionBuilder.loadMoreViewSections();
        }
        else if (this.isLikesOrDownloads) {
            var expandedCollectionSections = this.collectionSections.map(function (section) {
                if (section.type === 'song') {
                    if (section.initialNumItems < section.data.length) {
                        section.initialNumItems += 100;
                        _this.likesOrDownloadsTemporaryNumItems = section.initialNumItems;
                    }
                }
                return section;
            });
            this.collectionSections = JSON.parse(JSON.stringify(expandedCollectionSections));
        }
    };
    ViewComponent.prototype.searchArtist = function (query) {
        if (!this.originalSections) {
            this.originalSections = this.collectionSections;
        }
        // to cancel any pending actions we handle empty query inside effect
        this.store.dispatch(new _core_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_5__["SearchArtist"]({ artistId: this.collectionMeta.id, query: query }));
        if (!query) {
            this.store.dispatch(new _core_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_5__["GetCollectionSuccess"]({ sections: this.originalSections }));
        }
    };
    ViewComponent.prototype.ngOnInit = function () {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_8__["isPlatformBrowser"])(this.platformId)) {
            var collectionData = this.state.get(VIEW_KEY, null);
            if (collectionData) {
                this.prepareViewData(collectionData);
                this.state.remove(VIEW_KEY);
            }
        }
    };
    ViewComponent.prototype.setCarouselInitializationState = function (e) {
        this.carouselInitialized = true;
    };
    ViewComponent.prototype.checkIfSectionsHaveCarousel = function (sections) {
        if (sections && sections.length > 0) {
            for (var i = 0; i < sections.length; i++) {
                if ((sections[i].displaytype === 'carousel' || sections[i].displaytype === 'carousel') && sections[i].type !== 'text' && sections[i].data && sections[i].data.length > 0) {
                    return true;
                }
            }
        }
        return false;
    };
    ViewComponent.prototype.setSideBarVisibility = function (type) {
        if (type === 'tag' ||
            type === 'tags' ||
            type === 'hashtag' ||
            type === 'video') {
            this.hideSideView = true;
        }
        else {
            this.hideSideView = false;
        }
    };
    ViewComponent.prototype.handleOnOtherDevicesPlaylistName = function () {
        var isDesktop = !!window['desktopClient'];
        if (isDesktop && this.collectionMeta && this.collectionMeta.PlaylistName === _core_enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_13__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS) {
            this.collectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.collectionMeta, { name: this.translateService.instant('on_other_devices'), title: this.translateService.instant('on_other_devices') });
        }
    };
    ViewComponent.prototype.goToDownloadQueuePage = function () {
        this.router.navigateByUrl('/download-queue');
    };
    ViewComponent.prototype.goToOnOtherDevices = function () {
        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_17__["GoToDownloadsOnOtherDevices"]());
    };
    ViewComponent.prototype.translateNumber = function (num) {
        var str = num.toString();
        if (this.locale === 'ar') {
            return this.utilityService.toArabicDigits(str);
        }
        return str;
    };
    ViewComponent.prototype.freeDownloadsSubscriptions = function () {
        if (this.downloadQueueSubscription) {
            this.downloadListSubscription.unsubscribe();
        }
        if (this.downloadListSubscription) {
            this.downloadListSubscription.unsubscribe();
        }
        if (this.downloadQueueStateSubscription) {
            this.downloadListSubscription.unsubscribe();
        }
    };
    ViewComponent.prototype.ngOnDestroy = function () {
        if (this.collectionMeta$) {
            this.collectionMeta$.unsubscribe();
        }
        if (this.routerSubscription) {
            this.routerSubscription.unsubscribe();
        }
        if (this.actionSubjectSubs) {
            this.actionSubjectSubs.unsubscribe();
        }
        if (this.queryParamSubscription) {
            this.queryParamSubscription.unsubscribe();
        }
        this.freeDownloadsSubscriptions();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["HostBinding"])('attr.class'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ViewComponent.prototype, "class", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])('sectionBuilder', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _app_core_components_new_section_builder_new_section_builder_component__WEBPACK_IMPORTED_MODULE_10__["NewSectionBuilderComponent"])
    ], ViewComponent.prototype, "sectionBuilder", void 0);
    ViewComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'anghami-view',
            template: __webpack_require__(/*! raw-loader!./view.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/view/view.component.html"),
            styles: [__webpack_require__(/*! ./view.component.scss */ "./src/app/modules/base/view/view.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](7, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](8, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
            _core_services_metas_service__WEBPACK_IMPORTED_MODULE_6__["MetasService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["ActionsSubject"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__["TransferState"],
            _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_11__["SectionService"],
            Object, String, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__["TranslateService"],
            _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_15__["DesktopDownloadService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ChangeDetectorRef"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_18__["UtilService"]])
    ], ViewComponent);
    return ViewComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/view/view.module.ts":
/*!**************************************************!*\
  !*** ./src/app/modules/base/view/view.module.ts ***!
  \**************************************************/
/*! exports provided: ViewModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewModule", function() { return ViewModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _view_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./view-routing.module */ "./src/app/modules/base/view/view-routing.module.ts");
/* harmony import */ var _view_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./view.component */ "./src/app/modules/base/view/view.component.ts");
/* harmony import */ var _view_resolver__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./view.resolver */ "./src/app/modules/base/view/view.resolver.ts");
/* harmony import */ var _core_components_empty_pages_empty_pages_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/empty-pages/empty-pages.module */ "./src/app/core/components/empty-pages/empty-pages.module.ts");
/* harmony import */ var _core_components_search_input_search_input_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/search-input/search-input.module */ "./src/app/core/components/search-input/search-input.module.ts");
/* harmony import */ var ngx_infinite_scroll__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-infinite-scroll */ "./node_modules/ngx-infinite-scroll/modules/ngx-infinite-scroll.es5.js");
/* harmony import */ var _core_components_collection_header_banner_collection_header_banner_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/components/collection-header-banner/collection-header-banner.module */ "./src/app/core/components/collection-header-banner/collection-header-banner.module.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");
/* harmony import */ var _core_components_error_page_error_page_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/components/error-page/error-page.component */ "./src/app/core/components/error-page/error-page.component.ts");
/* harmony import */ var _core_components_collection_header_side_collection_header_side_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/components/collection-header-side/collection-header-side.module */ "./src/app/core/components/collection-header-side/collection-header-side.module.ts");
/* harmony import */ var _core_components_placeholders_view_placeholder_view_placeholder_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/components/placeholders/view-placeholder/view-placeholder.component */ "./src/app/core/components/placeholders/view-placeholder/view-placeholder.component.ts");
/* harmony import */ var _core_components_jsonld_jsonld_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/components/jsonld/jsonld.module */ "./src/app/core/components/jsonld/jsonld.module.ts");















var ViewModule = /** @class */ (function () {
    function ViewModule() {
    }
    ViewModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _view_routing_module__WEBPACK_IMPORTED_MODULE_3__["ViewRoutingModule"],
                _core_components_empty_pages_empty_pages_module__WEBPACK_IMPORTED_MODULE_6__["EmptyPagesModule"],
                _core_components_search_input_search_input_module__WEBPACK_IMPORTED_MODULE_7__["SearchInputModule"],
                ngx_infinite_scroll__WEBPACK_IMPORTED_MODULE_8__["InfiniteScrollModule"],
                _core_components_collection_header_banner_collection_header_banner_module__WEBPACK_IMPORTED_MODULE_9__["CollectionHeaderBannerModule"],
                _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_10__["NewSectionBuilderModule"],
                _core_components_collection_header_side_collection_header_side_module__WEBPACK_IMPORTED_MODULE_12__["CollectionHeaderSideModule"],
                _core_components_jsonld_jsonld_module__WEBPACK_IMPORTED_MODULE_14__["JsonldModule"]
            ],
            declarations: [_view_component__WEBPACK_IMPORTED_MODULE_4__["ViewComponent"], _core_components_error_page_error_page_component__WEBPACK_IMPORTED_MODULE_11__["ErrorPageComponent"], _core_components_placeholders_view_placeholder_view_placeholder_component__WEBPACK_IMPORTED_MODULE_13__["ViewPlaceholderComponent"]],
            providers: [_view_resolver__WEBPACK_IMPORTED_MODULE_5__["ViewResolver"]],
            exports: [_view_component__WEBPACK_IMPORTED_MODULE_4__["ViewComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], ViewModule);
    return ViewModule;
}());



/***/ })

}]);