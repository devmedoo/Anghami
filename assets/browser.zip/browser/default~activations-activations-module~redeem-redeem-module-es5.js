(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~activations-activations-module~redeem-redeem-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/activation-code/activation-code.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/activation-code/activation-code.component.html ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container [ngSwitch]=\"displaytype\">\n  <ng-container *ngSwitchCase=\"'redeem'\">\n    <ng-container *ngTemplateOutlet=\"\n        redeemTemplate;\"></ng-container>\n  </ng-container>\n  <ng-container *ngSwitchCase=\"'OPERATOR_INFO'\">\n    <ng-container *ngTemplateOutlet=\"\n        operatorActivationTemplate;\"></ng-container>\n  </ng-container>\n  <ng-container *ngSwitchCase=\"'DEFAULT'\">\n    <ng-container *ngTemplateOutlet=\"\n        operatorTemplate;\"></ng-container>\n  </ng-container>\n</ng-container>\n<ng-template #redeemTemplate>\n  <ng-container *ngIf=\"activation && activation?.inputLst && activation?.inputLst.length > 0\">\n    <div class=\"form-group\" *ngFor=\"let inputfield of activation?.inputLst\">\n      <label for=\"promocodeid\" class=\"px-1 promolabel\">{{ inputfield.label | translateInstant }}</label>\n      <div class=\"d-flex my-3\">\n        <input type=\"text\" \n          id=\"promocodeid\"\n          class=\"form-control promo\"\n          [(ngModel)]=\"inputfield.model\"\n          placeholder=\"{{inputfield.placeholder | translateInstant }}\"\n          (keypress)=\"submitActivation($event);\"\n          (ngModelChange)=\"clearError.emit()\">\n        <div class=\"ang-primary-colored-btn btn\" [ngClass]=\"{'loading': loading}\" id=\"submitid\" (click)=\"submit.emit()\">\n          <ng-container *ngIf=\"!loading\">\n            <span>{{ activation?.action | translateInstant }}</span>\n          </ng-container>\n          <img class=\"op-loader\" *ngIf=\"loading\" src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/op-loader.gif\">\n        </div>\n      </div>\n    </div>\n  </ng-container>\n</ng-template>\n<ng-template #operatorActivationTemplate>\n  <div class=\"flex-display\">\n    <img class=\"logo\" [src]=\"activation?.logoimg\" />\n    <div class=\"description\">\n      {{ activation?.mainlabel }}\n    </div>\n  </div>\n  <div class=\"d-flex operator-activation\">\n    <ng-container *ngIf=\"activation && activation?.inputLst && activation?.inputLst.length > 0\">\n      <div class=\"form-group\" *ngFor=\"let inputfield of activation?.inputLst\">\n        <ng-container *ngIf=\"inputfield && inputfield !== null\">\n          <label>{{ inputfield.label }}</label>\n          <input \n            *ngIf=\"isDeviceMobile\"\n            placeholder=\"{{inputfield.placeholder}}\"\n            class=\"form-control\"\n            [type]=\"inputfield.conditions?.type\"\n            [pattern]=\"inputfield.conditions?.pattern\"\n            [maxLength]=\"inputfield.conditions?.maxlength\"\n            [id]=\"inputfield.id\"\n            [(ngModel)]=\"inputfield.model\"\n            (ngModelChange)=\"clearError.emit()\"\n          />\n          <input\n            *ngIf=\"!isDeviceMobile\"\n            placeholder=\"{{inputfield.placeholder}}\"\n            class=\"form-control\"\n            [id]=\"inputfield.id\"\n            [(ngModel)]=\"inputfield.model\"\n            (ngModelChange)=\"clearError.emit()\"\n            (keypress)=\"handleConditions($event, inputfield.conditions);\" />\n        </ng-container>\n      </div>\n    </ng-container>\n  </div>\n  <div class=\"d-flex justify-content-center\">\n    <div class=\"ang-primary-colored-btn redeem\" (click)=\"submitInfo()\">\n      <ng-container *ngIf=\"!loading\">\n        <span>{{ activation?.action }}</span>\n      </ng-container>\n      <img class=\"op-loader\" *ngIf=\"loading\" src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/op-loader.gif\">\n    </div>\n  </div>\n</ng-template>\n<ng-template #operatorTemplate>\n  <div *ngIf=\"type==='verify'\" class=\"disclaimer\">\n    <div>We sent an SMS to +{{ selectedtelco?.msidn }} -\n      <a (click)=\"submitInfo('resend')\" i18n=\"@@Send Again\" [ngClass]=\"{'disabled': (disabledTimer>0)}\">Send again\n      </a>\n    </div>\n    <div *ngIf=\"disabledTimer>0\" class=\"retry\">\n      <span i18n=\"@@Didn't receive the code yet?\">Didn't receive the code yet?</span>&nbsp;\n      <span i18n=\"@@Retry in\">Retry in</span>&nbsp;{{ disabledTimer }}\n    </div>\n  </div>\n  <div class=\"inline-box inline-box-col\">\n    <div class=\"inline-box w-100\">\n      <span class=\"inline-box login-input-flag\" [ngClass]=\"{'hidearrow': (type==='verify')}\">\n        <select (ngModelChange)=\"setOperator($event)\" [(ngModel)]=\"selectedtelco\" *ngIf=\"type==='operator'\">\n          <option\n            *ngFor=\"let telco of activation?.telcoLst\"\n            [ngValue]=\"telco\">{{ telco?.operatorname }}</option>\n        </select>\n        <img class=\"logo telco\" [src]=\"selectedtelco?.image\" />\n      </span>\n      <div *ngFor=\"let inputfield of activation?.inputLst\" class=\"w-100 bottom-input-line inline-box\">\n        <span\n          class=\"prefix\"\n          *ngIf=\"type==='operator'&&selectedtelco?.prefix!==''\"\n        >+{{ selectedtelco?.prefix }}\n        </span>\n        <input\n          *ngIf=\"isDeviceMobile\"\n          placeholder=\"{{inputfield.placeholder}}\"\n          class=\"hidden-input form-control ml-2 py-2\"\n          [type]=\"inputfield.conditions?.type\"\n          [pattern]=\"inputfield.conditions?.pattern\"\n          [maxLength]=\"inputfield.conditions?.maxlength\"\n          required\n          [id]=\"inputfield.id\"\n          [(ngModel)]=\"inputfield.model\"\n          (ngModelChange)=\"clearError.emit()\"\n        />\n        <input\n          *ngIf=\"!isDeviceMobile\"\n          placeholder=\"{{inputfield.placeholder}}\"\n          class=\"hidden-input form-control ml-2 py-2\"\n          [id]=\"inputfield.id\"\n          [(ngModel)]=\"inputfield.model\"\n          (ngModelChange)=\"clearError.emit()\"\n          (keypress)=\"handleConditions($event, inputfield.conditions);\"\n        />\n      </div>\n    </div>\n    <div class=\"d-flex justify-content-center padtop-2\">\n      <div class=\"ang-operator-btn redeem\" (click)=\"submitInfo(type)\">\n        <ng-container *ngIf=\"!loading\">\n          <span>{{ activation?.action }}</span>\n        </ng-container>\n        <img class=\"op-loader\" *ngIf=\"loading\" src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/op-loader.gif\">\n      </div>\n    </div>\n  </div>\n  <div class=\"trial\" *ngIf=\"activation?.trial\">{{ activation?.trial }}</div>\n</ng-template>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/inner-header/inner-header.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  id=\"headerid\"\n  class=\"header\"\n  [ngStyle]=\"backgroundimage\"\n  [ngClass]=\"{ extra: backgroundHeader.extra, smallerHeader: smallerHeader }\"\n>\n  <img\n    class=\"logo\"\n    *ngIf=\"backgroundHeader.innerLogo\"\n    [src]=\"backgroundHeader.innerLogo\"\n  />\n  <div>\n    <ng-container *ngIf=\"!isapi\">\n      <h1 class=\"title\">{{ backgroundHeader?.title | translateInstant }}</h1>\n      <h5 class=\"subtitle \">\n        {{ backgroundHeader?.subtitle | translateInstant }}\n      </h5>\n    </ng-container>\n    <ng-container *ngIf=\"isapi\">\n      <div class=\"title\">{{ backgroundHeader?.title }}</div>\n      <h5 class=\"subtitle \">{{ backgroundHeader?.subtitle }}</h5>\n    </ng-container>\n  </div>\n  <img\n    *ngIf=\"isWave\"\n    class=\"wave\"\n    src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\"\n  />\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/notice/notice.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/notice/notice.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container [ngSwitch]=\"type\">\n  <ng-container *ngSwitchCase=\"'notice'\">\n    <ng-container *ngTemplateOutlet=\"\n          noticeTemplate;\"></ng-container>\n  </ng-container>\n  <ng-container *ngSwitchCase=\"'result'\">\n    <ng-container *ngTemplateOutlet=\"\n          resultTemplate;\"></ng-container>\n  </ng-container>\n</ng-container>\n\n<ng-template #noticeTemplate>\n  <div class=\"row-between-flex\">\n    <h5>{{ notice?.title }}</h5>\n    <div [ngClass]=\"notice?.actionclass\" *ngIf=\"notice?.action\" (click)=\"submit.emit(notice?.action)\">\n      {{ notice?.actionbutton }}\n    </div>\n  </div>\n  <p *ngIf=\"notice?.ftitle || notice?.factiontext\">\n    <small>\n      {{ notice?.ftitle }}\n      <a (click)=\"footerClick.emit(notice?.faction)\" *ngIf=\"notice?.factiontext\" href=\"javascript:void(0);\">&nbsp;{{ notice?.factiontext }}</a>\n    </small>\n  </p>\n</ng-template>\n<ng-template #resultTemplate>\n  <img [src]=\"notice?.imagesrc\" class=\"result\">\n  <div class=\"col-flex\">\n    <div class=\"title\">{{ notice?.title }}</div>\n    <div class=\"subtitle\">{{ notice?.subtitle }}</div>\n  </div>\n</ng-template>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/white-box/white-box.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"wrapper-box\" [ngClass]=\"{'loader': loading, 'notice': notice, 'brand': brand}\">\n  <div class=\"white-box\" [ngClass]=\"{'notice': notice}\">\n    <ng-content></ng-content>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/core/components/activation-code/activation-code.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/core/components/activation-code/activation-code.component.ts ***!
  \******************************************************************************/
/*! exports provided: ActivationCodeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivationCodeComponent", function() { return ActivationCodeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/promo.service */ "./src/app/core/services/promo.service.ts");
/* harmony import */ var _anghami_redux_selectors_plus_selectors__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/selectors/plus.selectors */ "./src/app/core/redux/selectors/plus.selectors.ts");








var ActivationCodeComponent = /** @class */ (function () {
    function ActivationCodeComponent(store, _utilService, _promoService, _cd) {
        this.store = store;
        this._utilService = _utilService;
        this._promoService = _promoService;
        this._cd = _cd;
        this.submit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.clearError = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.selectOperator = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.disabledTimer = 0;
    }
    ActivationCodeComponent.prototype.ngOnInit = function () {
        this.isDeviceMobile = this._utilService.detectmob();
    };
    ActivationCodeComponent.prototype.ngOnChanges = function (changes) {
        var _this = this;
        if (changes.activation && this.activation !== undefined) {
            if (this.activation.inputLst) {
                this.activation.inputLst = this.activation.inputLst.map(function (elt) {
                    return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, elt, { model: elt.model === undefined || elt.model === null ? '' : elt.model });
                });
            }
            if (this.activation.telcoLst && this.activation.telcoLst !== null && this.activation.telcoLst.length > 0) {
                if (this.selectedtelco === undefined || this.selectedtelco === null) {
                    this.setOperator(this.activation.telcoLst[0]);
                }
            }
            if (this.displaytype === 'DEFAULT' && this.type === 'verify') {
                this.operatorSub$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_plus_selectors__WEBPACK_IMPORTED_MODULE_7__["getOperator"])).subscribe(function (data) {
                    _this.selectedtelco = JSON.parse(JSON.stringify(data));
                });
            }
        }
    };
    ActivationCodeComponent.prototype.submitActivation = function (evt) {
        this._cd.detectChanges();
        if (evt.keyCode === 13) {
            document.getElementById('submitid').click();
        }
    };
    ActivationCodeComponent.prototype.login = function () {
        var currenturl = window.location.href;
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_3__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_4__["AmplitudeEvents"].redirectLogin,
            props: {
                page: currenturl,
                action: 'loginLanding'
            }
        }));
        window.location.href =
            'https://www.anghami.com/login?redirecturl=' + currenturl;
    };
    ActivationCodeComponent.prototype.handleConditions = function (evt, condition) {
        this._promoService.handleConditions(evt, condition);
    };
    ActivationCodeComponent.prototype.setOperator = function (data) {
        this.selectedtelco = data;
        this.selectOperator.emit(this.selectedtelco);
    };
    ActivationCodeComponent.prototype.submitInfo = function (key) {
        var _this = this;
        var info = {};
        var isResend = false;
        if (this.activation && this.activation !== null) {
            info = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, info, this.inputObjectMapping(this.activation.inputLst));
        }
        if (key && key !== null) {
            if (this.type === 'verify') {
                info = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, info, { msidn: this.selectedtelco.msidn, key: key });
                if (key === 'resend') {
                    isResend = true;
                    delete info.code;
                }
            }
        }
        if (!isResend || (isResend && this.disabledTimer === 0)) {
            this.submit.emit(info);
            if (isResend) {
                this.disabledTimer = 60;
                this.timer = setInterval(function () {
                    if (_this.disabledTimer > 0) {
                        _this.disabledTimer--;
                    }
                    else {
                        _this.clearInterval();
                    }
                }, 1000);
            }
        }
    };
    ActivationCodeComponent.prototype.clearInterval = function () {
        clearInterval(this.timer);
    };
    ActivationCodeComponent.prototype.inputObjectMapping = function (inputLst) {
        var inputObj = {};
        if (inputLst && inputLst !== null && inputLst.length > 0) {
            inputLst.forEach(function (elt) {
                inputObj[elt.id] = elt.model;
            });
        }
        return inputObj;
    };
    ActivationCodeComponent.prototype.ngOnDestroy = function () {
        if (this.operatorSub$) {
            this.operatorSub$.unsubscribe();
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ActivationCodeComponent.prototype, "activation", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ActivationCodeComponent.prototype, "displaytype", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ActivationCodeComponent.prototype, "type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ActivationCodeComponent.prototype, "loggedin", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ActivationCodeComponent.prototype, "isplus", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ActivationCodeComponent.prototype, "loading", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], ActivationCodeComponent.prototype, "submit", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], ActivationCodeComponent.prototype, "clearError", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], ActivationCodeComponent.prototype, "selectOperator", void 0);
    ActivationCodeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-activation-code',
            template: __webpack_require__(/*! raw-loader!./activation-code.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/activation-code/activation-code.component.html"),
            styles: [__webpack_require__(/*! ./activation-code.component.scss */ "./src/app/core/components/activation-code/activation-code.component.scss"), __webpack_require__(/*! ../../../modules/landing/redeem/promo.component.scss */ "./src/app/modules/landing/redeem/promo.component.scss"), __webpack_require__(/*! ../../../modules/login/components/login-landing/login-shared.scss */ "./src/app/modules/login/components/login-landing/login-shared.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilService"],
            _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_6__["PromoService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]])
    ], ActivationCodeComponent);
    return ActivationCodeComponent;
}());



/***/ }),

/***/ "./src/app/core/components/activation-code/activivaton-code.module.ts":
/*!****************************************************************************!*\
  !*** ./src/app/core/components/activation-code/activivaton-code.module.ts ***!
  \****************************************************************************/
/*! exports provided: ActivationCodeModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivationCodeModule", function() { return ActivationCodeModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _activation_code_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./activation-code.component */ "./src/app/core/components/activation-code/activation-code.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");






var ActivationCodeModule = /** @class */ (function () {
    function ActivationCodeModule() {
    }
    ActivationCodeModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__["PipesModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"]],
            declarations: [_activation_code_component__WEBPACK_IMPORTED_MODULE_3__["ActivationCodeComponent"]],
            exports: [_activation_code_component__WEBPACK_IMPORTED_MODULE_3__["ActivationCodeComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], ActivationCodeModule);
    return ActivationCodeModule;
}());



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: -webkit-gradient(linear, left top, right top, from(#e03f8d), color-stop(#a22ccf), to(#2fa0df));\n  background: linear-gradient(to right, #e03f8d, #a22ccf, #2fa0df);\n  height: 30em;\n  background-size: cover !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    height: auto;\n    min-height: 15em;\n  }\n}\n:host .header.pringles {\n  background-size: cover !important;\n  background-position: center !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header.extra .title {\n  width: 60%;\n  margin: auto;\n}\n:host .header .logo {\n  max-width: 5em;\n  display: block;\n  margin: 1em auto;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n  }\n}\n:host .header .subtitle {\n  font-size: 1.2rem;\n  margin: auto;\n  font-weight: 200;\n  text-align: center;\n  padding-top: 0.5em;\n}\n@media (max-width: 768px) {\n  :host .header .subtitle {\n    width: 85%;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.ts ***!
  \************************************************************************/
/*! exports provided: InnerHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderComponent", function() { return InnerHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/mobile-detection.service */ "./src/app/core/services/mobile-detection.service.ts");



var InnerHeaderComponent = /** @class */ (function () {
    function InnerHeaderComponent(_mobileDetection, locale) {
        this._mobileDetection = _mobileDetection;
        this.locale = locale;
        this.locale =
            this.locale && this.locale !== null
                ? this.locale.indexOf('en') > -1
                    ? 'en'
                    : this.locale
                : 'en';
    }
    InnerHeaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._mobileDetection.verticalScreen.subscribe(function (isVertical) {
            if (_this.backgroundHeader.mainimagemobile) {
                var image = isVertical
                    ? _this.backgroundHeader.mainimagemobile
                    : _this.backgroundHeader.mainimage;
                _this.setBackgroundImage(image, _this.backgroundHeader.backgroundcolor);
            }
        });
    };
    InnerHeaderComponent.prototype.setBackgroundImage = function (img, color) {
        var backgroundcolor = color && color !== null && color !== ''
            ? color
            : 'linear-gradient(to right, #E03F8D, #A22CCF, #2FA0DF)';
        this.backgroundimage = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.backgroundimage, { background: 'url(' +
                img +
                ') 0% 0%,' + backgroundcolor });
    };
    InnerHeaderComponent.prototype.ngOnChanges = function () {
        if (this.backgroundHeader && this.backgroundHeader !== null) {
            if (this.backgroundHeader.mainimage) {
                this.backgroundimage = {
                    'background-size': 'cover',
                };
                this.setBackgroundImage(this.backgroundHeader.mainimage);
            }
            if (this.backgroundHeader.type) {
                var headerElt = document.getElementById('headerid');
                if (headerElt && headerElt !== null) {
                    headerElt.classList.add(this.backgroundHeader.type);
                }
            }
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('backgroundHeader'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InnerHeaderComponent.prototype, "backgroundHeader", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('smallerHeader'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InnerHeaderComponent.prototype, "smallerHeader", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InnerHeaderComponent.prototype, "isWave", void 0);
    InnerHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-inner-header',
            template: __webpack_require__(/*! raw-loader!./inner-header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html"),
            styles: [__webpack_require__(/*! ./inner-header.component.scss */ "./src/app/core/components/inner-header/inner-header.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__["MobileDetectionService"], String])
    ], InnerHeaderComponent);
    return InnerHeaderComponent;
}());



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.module.ts ***!
  \*********************************************************************/
/*! exports provided: InnerHeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderModule", function() { return InnerHeaderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.component */ "./src/app/core/components/inner-header/inner-header.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");





var InnerHeaderModule = /** @class */ (function () {
    function InnerHeaderModule() {
    }
    InnerHeaderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__["PipesModule"]],
            declarations: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
            exports: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], InnerHeaderModule);
    return InnerHeaderModule;
}());



/***/ }),

/***/ "./src/app/core/components/notice/notice.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/core/components/notice/notice.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n\n.row-between-flex {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n\nh5 {\n  font-weight: 600;\n}\n\n@media (max-width: 768px) {\n  h5 {\n    padding-right: 0.5em;\n    padding-left: 0.5em;\n  }\n}\n\n.ang-primary-colored-btn,\n.ang-operator-btn {\n  margin-left: 3em;\n}\n\n.ang-primary-colored-btn:hover,\n.ang-operator-btn:hover {\n  margin-left: 2.6em;\n}\n\nimg.result {\n  max-width: 3.5em;\n}\n\n.title {\n  font-size: 1.2em;\n}\n\n.col-flex {\n  padding: 0 1.5em;\n}\n\np {\n  margin-top: 0.5em;\n  margin-bottom: 0 !important;\n}\n\nhtml[lang=ar] :host .ang-primary-colored-btn,\nhtml[lang=ar] :host .ang-operator-btn {\n  margin-left: 0em;\n  margin-right: 3em;\n}\n\nhtml[lang=ar] :host .ang-primary-colored-btn:hover,\nhtml[lang=ar] :host .ang-operator-btn:hover {\n  margin-left: 0em;\n  margin-right: 2.6em;\n}"

/***/ }),

/***/ "./src/app/core/components/notice/notice.component.ts":
/*!************************************************************!*\
  !*** ./src/app/core/components/notice/notice.component.ts ***!
  \************************************************************/
/*! exports provided: NoticeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoticeComponent", function() { return NoticeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var NoticeComponent = /** @class */ (function () {
    function NoticeComponent() {
        this.submit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.footerClick = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.isCol = false;
    }
    NoticeComponent.prototype.ngOnInit = function () {
    };
    NoticeComponent.prototype.ngOnChanges = function () {
        this.isCol = this.notice && this.notice !== null
            && (this.notice.ftitle || this.notice.factiontext);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], NoticeComponent.prototype, "type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('notice'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], NoticeComponent.prototype, "notice", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], NoticeComponent.prototype, "submit", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], NoticeComponent.prototype, "footerClick", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class.flex-column'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], NoticeComponent.prototype, "isCol", void 0);
    NoticeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-notice',
            template: __webpack_require__(/*! raw-loader!./notice.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/notice/notice.component.html"),
            styles: [__webpack_require__(/*! ./notice.component.scss */ "./src/app/core/components/notice/notice.component.scss"), __webpack_require__(/*! ../activation-code/activation-code.component.scss */ "./src/app/core/components/activation-code/activation-code.component.scss"), __webpack_require__(/*! ../../../modules/landing/redeem/redeem.component.scss */ "./src/app/modules/landing/redeem/redeem.component.scss"), __webpack_require__(/*! ../../../modules/landing/redeem/promo.component.scss */ "./src/app/modules/landing/redeem/promo.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], NoticeComponent);
    return NoticeComponent;
}());



/***/ }),

/***/ "./src/app/core/components/notice/notice.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/components/notice/notice.module.ts ***!
  \*********************************************************/
/*! exports provided: NoticeModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoticeModule", function() { return NoticeModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _app_core_components_notice_notice_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../app/core/components/notice/notice.component */ "./src/app/core/components/notice/notice.component.ts");




var NoticeModule = /** @class */ (function () {
    function NoticeModule() {
    }
    NoticeModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
            declarations: [_app_core_components_notice_notice_component__WEBPACK_IMPORTED_MODULE_3__["NoticeComponent"]],
            exports: [_app_core_components_notice_notice_component__WEBPACK_IMPORTED_MODULE_3__["NoticeComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], NoticeModule);
    return NoticeModule;
}());



/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .wrapper-box {\n  display: inline-block;\n  margin: auto;\n  width: 100%;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box {\n    width: 90%;\n  }\n}\n:host .wrapper-box.loader {\n  width: 40% !important;\n}\n:host .wrapper-box.notice {\n  width: unset;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box.notice {\n    width: 90%;\n  }\n}\n:host .wrapper-box.brand .white-box {\n  margin-top: -5.5em !important;\n}\n:host .white-box {\n  margin: auto;\n  min-width: 5em;\n  border: 1px solid #EEEEEE;\n  border-radius: 0.5em;\n  box-shadow: 5px 5px 30px -5px lightgrey;\n  padding: 1.5em;\n  display: block;\n  background-color: white;\n  position: relative;\n  max-width: 55em;\n  margin-top: -8em;\n}\n@media (max-width: 768px) {\n  :host .white-box {\n    margin-top: -3em;\n  }\n}\n:host .white-box.notice {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-top: -5em;\n  padding: 2em;\n}"

/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.ts ***!
  \******************************************************************/
/*! exports provided: WhiteBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxComponent", function() { return WhiteBoxComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var WhiteBoxComponent = /** @class */ (function () {
    function WhiteBoxComponent() {
    }
    WhiteBoxComponent.prototype.ngOnInit = function () { };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], WhiteBoxComponent.prototype, "notice", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], WhiteBoxComponent.prototype, "loading", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], WhiteBoxComponent.prototype, "brand", void 0);
    WhiteBoxComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-white-box',
            template: __webpack_require__(/*! raw-loader!./white-box.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html"),
            styles: [__webpack_require__(/*! ./white-box.component.scss */ "./src/app/core/components/white-box/white-box.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], WhiteBoxComponent);
    return WhiteBoxComponent;
}());



/***/ }),

/***/ "./src/app/core/components/white-box/white-box.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.module.ts ***!
  \***************************************************************/
/*! exports provided: WhiteBoxModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxModule", function() { return WhiteBoxModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.component */ "./src/app/core/components/white-box/white-box.component.ts");




var WhiteBoxModule = /** @class */ (function () {
    function WhiteBoxModule() {
    }
    WhiteBoxModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
            declarations: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
            exports: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], WhiteBoxModule);
    return WhiteBoxModule;
}());



/***/ }),

/***/ "./src/app/core/redux/selectors/plus.selectors.ts":
/*!********************************************************!*\
  !*** ./src/app/core/redux/selectors/plus.selectors.ts ***!
  \********************************************************/
/*! exports provided: selectPlusState, getFaq, getOperator */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectPlusState", function() { return selectPlusState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFaq", function() { return getFaq; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOperator", function() { return getOperator; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _reducers_plus_reducer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../reducers/plus.reducer */ "./src/app/core/redux/reducers/plus.reducer.ts");


var selectPlusState = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createFeatureSelector"])('plus');
var getFaq = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(selectPlusState, _reducers_plus_reducer__WEBPACK_IMPORTED_MODULE_1__["getFAQData"]);
var getOperator = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(selectPlusState, _reducers_plus_reducer__WEBPACK_IMPORTED_MODULE_1__["getOperator"]);


/***/ }),

/***/ "./src/app/core/services/mobile-detection.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/services/mobile-detection.service.ts ***!
  \***********************************************************/
/*! exports provided: MobileDetectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileDetectionService", function() { return MobileDetectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm5/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");





var MobileDetectionService = /** @class */ (function () {
    function MobileDetectionService(_cookie, utils) {
        var _this = this;
        this._cookie = _cookie;
        this.utils = utils;
        this.verticalScreen = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"]();
        if (this.utils.isBrowser()) {
            this.detectVerticalScreen();
            window.addEventListener('resize', function () {
                _this.resizeThrottler();
            }, false);
        }
    }
    MobileDetectionService.prototype.resizeThrottler = function () {
        var _this = this;
        if (this.utils.isBrowser()) {
            if (!this.resizeTimeout) {
                this.resizeTimeout = setTimeout(function () {
                    _this.resizeTimeout = null;
                    _this.detectVerticalScreen();
                }, 200);
            }
        }
    };
    MobileDetectionService.prototype.detectVerticalScreen = function () {
        this.device = this._cookie.get('device');
        var width = window.innerWidth < 768 ? true : false;
        var ismobile = this.device && (this.device === 'android' || this.device === 'ios')
            ? true
            : false;
        this.verticalScreen.next(width || ismobile ? true : false);
    };
    MobileDetectionService.prototype.getVerticalScreen = function () {
        return this.verticalScreen.asObservable();
    };
    MobileDetectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_cookie__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
    ], MobileDetectionService);
    return MobileDetectionService;
}());



/***/ })

}]);