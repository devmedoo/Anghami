(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["plus-plus-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/white-box/white-box.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"wrapper-box\" [ngClass]=\"{'loader': loading, 'notice': notice, 'brand': brand}\">\n  <div class=\"white-box\" [ngClass]=\"{'notice': notice}\">\n    <ng-content></ng-content>\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/plus/plus.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/plus/plus.component.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<img src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/plus/left_corner.png\" class=\"left-corner\">\n<img src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/plus/right_corner.png\" class=\"right-corner\">\n<h1 class=\"pluslogo\">\n    <span i18n=\"@@Anghami\">Anghami</span>&nbsp;<span i18n=\"@@Plus\" class=\"highlight\">Plus</span>\n</h1>\n<anghami-benefits\n    class=\"features-top\" [display]=\"'main'\"\n    title=\"{{ 'subscreen_main_title' | translate }}\"\n    [benefits]=\"benefitsLst\"\n    [actualSize]=\"subscribe?.features.length\"\n    (showMore)=\"goToBenefits()\"\n></anghami-benefits>\n<div id=\"subscribeId\">\n    <div class=\"h-6\"></div>\n    <ng-container *ngIf=\"sectionsLst && sectionsLst.length > 0\">\n        <div class=\"flexbox box stretch\">\n            <div\n                (click)=\"selectPlanSection(i, section)\"\n                *ngFor=\"let section of sectionsLst;let i = index;\"\n                class=\"px-2 pointer section flexbox\"\n                [ngClass]=\"{'selected': section.selected}\">\n                <div class=\"inner-section\">{{ section.title }}</div>\n            </div>\n        </div>\n    </ng-container>\n    <ng-container *ngIf=\"visiblePlans && visiblePlans.length > 0\">\n        <div class=\"plans-wrapper flexbox flow\" [ngClass]=\"{'singleplan': visiblePlans.length === 1 }\">\n            <div \n                class=\"plan mx-2 my-5 flexbox cols between\"\n                [ngClass]=\"{\n                    'gradient-box': (subscribe?.mainplanid==plan?.planid) && !plan?.mainbgd,\n                    'isrelatedplans': relPlansExist,\n                    'h-42': multiplierExists,\n                    'main-bgd': (subscribe?.mainplanid==plan?.planid) && plan?.mainbgd\n                }\"\n                [ngStyle]=\"(subscribe?.mainplanid==plan?.planid) && plan?.mainbgd ? plan?.mainbgd : null\"\n                *ngFor=\"let plan of visiblePlans\">\n                <div class=\"my-3\">\n                    <div class=\"logo\">\n                        <img [lazyLoad]=\"plan?.bigimage\" *ngIf=\"plan?.bigimage\">\n                    </div>\n                    <div\n                        class=\"title initial\"\n                        [ngClass]=\"{'main': (subscribe?.mainplanid==plan?.planid) && !plan?.mainbgd }\"\n                    >{{ plan?.title }}</div>\n                    <div class=\"flexbox end h-2 plandtls\">\n                        <div class=\"price-wrap flexbox\">\n                            <div *ngIf=\"plan?.price != 0\" class=\"currency\">{{ plan?.currency }}</div>\n                            <div class=\"price\">\n                                <span *ngIf=\"plan?.price != 0 && plan?.price !== ''\">{{ plan?.price | number:'1.0-2' }}</span>\n                                <span *ngIf=\"plan?.price == 0 && plan?.price !== ''\" class=\"text-uppercase\" i18n=\"@@Free\">Free</span>\n                            </div>\n                        </div>\n                        <div class=\"duration\">{{ plan?.duration }}</div>\n                    </div>\n                </div>\n                <div class=\"h-4\">\n                    <div *ngFor=\"let benefit of plan?.benefits\" class=\"benefit\">\n                        {{ benefit }}\n                    </div>\n                </div>\n                <div class=\"h-6\" [ngClass]=\"{'w-16': visiblePlans.length > 1, 'w-19': visiblePlans.length === 1}\">\n           \n                     <anghami-button class=\"d-block\" label=\"{{plan?.planbutton}}\" (click)=\"actionPlan(plan)\" layout=\"blue\" target=\"none\" size=\"narrow\"></anghami-button>\n\n\n\n                    <div class=\"trial darkgray\">{{ plan?.trial }}</div>\n                </div>\n                <div\n                    class=\"relatedplans-wrap\"\n                    [ngClass]=\"{'w-16': visiblePlans.length > 1, 'w-19': visiblePlans.length === 1, 'h-13': multiplierExists }\"\n                    [ngStyle]=\"{'display': !relPlansExist ? 'none' : 'block'}\">\n                    <ng-container *ngIf=\"plan.relatedplans && plan.relatedplans.length > 1\">\n                        <div class=\"darkgray desc\" i18n=\"@@save_more\">Save more by switching to</div>\n                        <ng-container *ngFor=\"let relplan of plan.relatedplans\">\n                            <ng-container *ngIf=\"relplan.planid !== plan.planid\">\n                                <div \n                                    (click)=\"actionPlan(relplan)\"\n                                    class=\"flexbox between relatedplan pointer\"\n                                    [ngClass]=\"{\n                                        'nomultiplier': !multiplierExists, \n                                        'pd2': (!relplan?.multiplier || relatedplan?.multiplier == 0 || relatedplan?.multiplier == '')\n                                    }\">\n                                    <div class=\"title\">{{ relplan?.title }}</div>\n                                    <div class=\"flexbox\">\n                                        <div class=\"flexbox cols\">\n                                            <div class=\"multiplier\"\n                                                *ngIf=\"relplan?.multiplier && relatedplan?.multiplier != 0 && relatedplan?.multiplier != ''\">\n                                                {{ relplan?.currency}}{{ relplan?.multiplier * relplan?.price | number:'1.0-2' }}\n                                            </div>\n                                            <div class=\"planprice\">{{ relplan?.currency}}{{ relplan?.price | number:'1.0-2' }}</div>\n                                        </div>\n                                        <anghami-icon class=\"icon arrow\" [data]=\"'arrow-left'\"></anghami-icon>\n                                    </div>\n                                </div>\n                            </ng-container>\n                        </ng-container>\n                    </ng-container>\n                </div>\n            </div>\n        </div>\n    </ng-container>\n    <div class=\"cancelPlan\">\n        <span i18n=\"@@cancel_anytime\">You can cancel any plan at anytime.</span>&nbsp;\n        <a\n            class=\"terms\" i18n=\"@@Terms & Conditions\"\n            href=\"http://play.anghami.com/legal?webview=true\"\n            target=\"_blank\"\n        >Terms & Conditions</a>\n    </div>\n</div>\n<div class=\"h-6\"></div>\n<anghami-gift-block></anghami-gift-block>\n<div id=\"featuresId\">\n    <div class=\"h-6\"></div>\n    <anghami-features [features]=\"featuresLst\" (subscribeEvent)=\"goToSubscribe()\"></anghami-features>\n</div>\n<div class=\"h-2\"></div>\n<anghami-faq [showHelpCenter]=\"true\" [showQuestions]=\"true\"></anghami-faq>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/plus/subscribe/subscribe.component.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/plus/subscribe/subscribe.component.html ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"page-container\">\n  <h1 class=\"pluslogo\">\n    <span i18n=\"@@Anghami\">Anghami</span>&nbsp;<span i18n=\"@@Plus\" class=\"highlight\">Plus</span>\n  </h1>\n  <div *ngIf=\"loading\">\n    <anghami-loading></anghami-loading>\n  </div>\n  <ng-container *ngIf=\"!loading\">\n    <div class=\"title\" *ngIf=\"currentPlan?.title && !loading\">\n      <h2>{{currentPlan?.title}}</h2>\n    </div>\n    <ng-container *ngIf=\"!isSubscribed\">\n      <div class=\"form-container\">\n        <div class=\"form-left-side\">\n          <div class=\"form-plans\" *ngIf=\"cardList && cardList !== null\">\n            <ng-container *ngFor=\"let card of cardList\">\n              <div class=\"tab\" [class.active]=\"activePaymentMethod?.type === card.type\"\n                (click)=\"changePaymentMethod($event, card)\">\n                <img [src]=\"card.image\" alt=\"\">\n              </div>\n            </ng-container>\n          </div>\n          <div class=\"form\">\n            <ng-container *ngIf=\"activePaymentMethod?.type === 'visa'\">\n              <anghami-payment-form #paymentForm [selectedPlan]=\"currentPlan\" [submitText]=\"currentPlan?.planbutton\"\n                (success)=\"successPayment($event)\" [isPlusSubscription]=\"true\"></anghami-payment-form>\n            </ng-container>\n            <ng-container *ngIf=\"activePaymentMethod?.type === 'paypal'\">\n              <span i18n=\"@@cc_paypal_redirect\">\n                You will be redirected to PayPal to complete your purchase.\n              </span>\n            </ng-container>\n            <ng-container *ngIf=\"activePaymentMethod?.type === 'cashu'\">\n              <span class='color-gray cashu'>\n                <span i18n='@@cashu_s_1'>Buy a CashU card from</span>&nbsp;\n                <a class='purple' target='_blank' href='https://www.cashu.com/site/site/findResellersInfo?lang=en'\n                  i18n='@@cashu_s_2'>any store near you </a>&nbsp;\n                <span i18n='@@cashu_s_3'>then pay with CashU to subscribe.</span>\n              </span>\n            </ng-container>\n            <ng-container *ngIf=\"activePaymentMethod?.type === 'applepay'\">\n              <span class='color-gray'>\n                <div *ngIf=\"(activePaymentMethod?.type === 'applePay') && !applePaySupported\" i18n=\"@@cc_applepay\"\n                  class=\"err-msg\">\n                  Apple Pay is not available on your device.\n                </div>\n                <div *ngIf=\"(activePaymentMethod?.type === 'applePay') && applePaySupported && !applePayHaveActiveCards\"\n                  i18n=\"@@cc_applepay_error\" class=\"err-msg\">\n                  You need to add your payment details to Wallet to be able to proceed.\n                </div>\n                <div *ngIf=\"errorMessage\" class=\"err-msg\">\n                  {{errorMessage}}\n                </div>\n              </span>\n              <div *ngIf=\"applePaySupported && applePayHaveActiveCards && isMobile\" (click)=\"handleApplePayClick()\" class=\"apple-action-button\">\n                <div class=\"apple-pay-button-with-text apple-pay-button-white-with-text\">\n                  <span class=\"text\">Pay with</span>\n                  <span class=\"logo\"></span>\n                </div>\n              </div>\n            </ng-container>\n          </div>\n        </div>\n\n        <div class=\"related-plans-container\">\n          <div class=\"arrow\">\n            <img src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/triangle-rr@2x.png\" alt=\"\">\n          </div>\n          <p class=\"related-plans-title\" i18n=\"@@pick_another_plan\">\n            Expand your options, choose the plan that suits you best\n          </p>\n          <div class=\"related-plans\">\n            <ng-container *ngIf=\"relatedPlans && relatedPlans !== null\">\n              <div class=\"related-plan\" *ngFor=\"let plan of relatedPlans\">\n                <div class=\"md-radio\">\n                  <input [id]=\"plan.planid\" type=\"radio\" class=\"custom-control-input\" [value]=\"plan\"\n                    [name]=\"plan.planid\" [ngModel]=\"radioSelectedPlan\" (change)=\"relatedPlanSelected($event, plan)\"\n                    required>\n                  <label class=\"custom-control-label\" for=\"{{plan.planid}}\">\n                    <span *ngIf=\"plan?.price != 0\">{{ plan.currency }}</span>\n                    <span *ngIf=\"plan?.price != 0 && plan?.price !== ''\"> {{plan?.price | number:'1.0-2'}} </span>\n                    <span *ngIf=\"plan?.price == 0 && plan?.price !== ''\" i18n=\"@@Free\">Free </span>\n                    {{plan.duration}}\n                  </label>\n                </div>\n              </div>\n            </ng-container>\n            <div class=\"action-button\" *ngIf=\"activePaymentMethod?.type !== 'applepay' &&  !isMobile\"\n              (click)=\"onFormSubmit()\">\n              <span *ngIf=\"activePaymentMethod?.type === 'visa'\">{{currentPlan?.planbutton}}</span>\n              <span *ngIf=\"activePaymentMethod?.type !== 'visa'\">{{'Pay with ' + activePaymentMethod?.type}}</span>\n              <!-- <img class=\"op-loader\" *ngIf=\"paymentLoading\" src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/op-loader.gif\"> -->\n            </div>\n            <div\n              *ngIf=\"(activePaymentMethod?.type === 'applepay') && applePaySupported && applePayHaveActiveCards && !isMobile\"\n              (click)=\"handleApplePayClick()\" class=\"apple-action-button\">\n              <div class=\"apple-pay-button-with-text apple-pay-button-white-with-text\">\n                <span class=\"text\">Pay with</span>\n                <span class=\"logo\"></span>\n              </div>\n            </div>\n            <ng-container *ngIf=\"relatedPlans && relatedPlans.length===0 && benefitsLst.length > 0\">\n              <div class=\"py-3\">\n                <div class=\"benefits my-3\" *ngFor=\"let benefit of benefitsLst\">\n                  <img src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/check-icon.png\" class=\"checkmark\">\n                  <div class=\"benefit-txt px-3\">{{ benefit.title }}</div>\n                </div>\n              </div>\n            </ng-container>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"isSubscribed\">\n      <anghami-white-box class=\"ang-white-box\" [notice]=\"true\" [loading]=\"false\">\n        <span class=\"notice\">{{ 'already_plus' | translate }}</span>\n      </anghami-white-box>\n    </ng-container>\n  </ng-container>\n  <div class=\"back px-2\" (click)=\"back()\">\n    <img [src]=\"backArrowImg\"><span class=\"txt px-1\" i18n=\"@@back_to_plans\">Go back to plans</span>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .wrapper-box {\n  display: inline-block;\n  margin: auto;\n  width: 100%;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box {\n    width: 90%;\n  }\n}\n:host .wrapper-box.loader {\n  width: 40% !important;\n}\n:host .wrapper-box.notice {\n  width: unset;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box.notice {\n    width: 90%;\n  }\n}\n:host .wrapper-box.brand .white-box {\n  margin-top: -5.5em !important;\n}\n:host .white-box {\n  margin: auto;\n  min-width: 5em;\n  border: 1px solid #EEEEEE;\n  border-radius: 0.5em;\n  box-shadow: 5px 5px 30px -5px lightgrey;\n  padding: 1.5em;\n  display: block;\n  background-color: white;\n  position: relative;\n  max-width: 55em;\n  margin-top: -8em;\n}\n@media (max-width: 768px) {\n  :host .white-box {\n    margin-top: -3em;\n  }\n}\n:host .white-box.notice {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-top: -5em;\n  padding: 2em;\n}"

/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.ts ***!
  \******************************************************************/
/*! exports provided: WhiteBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxComponent", function() { return WhiteBoxComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let WhiteBoxComponent = class WhiteBoxComponent {
    constructor() { }
    ngOnInit() { }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], WhiteBoxComponent.prototype, "notice", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], WhiteBoxComponent.prototype, "loading", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], WhiteBoxComponent.prototype, "brand", void 0);
WhiteBoxComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-white-box',
        template: __webpack_require__(/*! raw-loader!./white-box.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html"),
        styles: [__webpack_require__(/*! ./white-box.component.scss */ "./src/app/core/components/white-box/white-box.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], WhiteBoxComponent);



/***/ }),

/***/ "./src/app/core/components/white-box/white-box.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.module.ts ***!
  \***************************************************************/
/*! exports provided: WhiteBoxModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxModule", function() { return WhiteBoxModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.component */ "./src/app/core/components/white-box/white-box.component.ts");




let WhiteBoxModule = class WhiteBoxModule {
};
WhiteBoxModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
        declarations: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
        exports: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], WhiteBoxModule);



/***/ }),

/***/ "./src/app/modules/landing/plus/plus-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/modules/landing/plus/plus-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: routes, PlusRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlusRoutingModule", function() { return PlusRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _plus_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./plus.component */ "./src/app/modules/landing/plus/plus.component.ts");
/* harmony import */ var _subscribe_subscribe_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./subscribe/subscribe.component */ "./src/app/modules/landing/plus/subscribe/subscribe.component.ts");





const routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: _plus_component__WEBPACK_IMPORTED_MODULE_3__["PlusComponent"],
            }, {
                path: 'operators',
                loadChildren: '../../../core/components/operators/operators.module#OperatorsModule',
                pathMatch: 'prefix'
            }, {
                path: 'operators/:operatorname',
                loadChildren: '../../../core/components/operators/operators.module#OperatorsModule',
                pathMatch: 'prefix'
            }, {
                path: 'operators/:operatorname/:pid',
                loadChildren: '../../../core/components/operators/operators.module#OperatorsModule',
                pathMatch: 'prefix'
            }, {
                path: ':planid',
                component: _subscribe_subscribe_component__WEBPACK_IMPORTED_MODULE_4__["SubscribeComponent"]
            }
        ]
    }
];
let PlusRoutingModule = class PlusRoutingModule {
};
PlusRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], PlusRoutingModule);



/***/ }),

/***/ "./src/app/modules/landing/plus/plus.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/modules/landing/plus/plus.component.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host h1 {\n  text-align: center;\n  margin: 0.5em auto;\n  font-size: 2em;\n  font-weight: bold;\n}\n:host .left-corner {\n  position: absolute;\n  max-width: 35em;\n  left: -23em;\n  z-index: -1;\n}\n@media (max-width: 769px) {\n  :host .left-corner {\n    display: none;\n  }\n}\n:host .plandtls {\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n}\n:host .main-bgd {\n  color: white !important;\n  border: none !important;\n}\n:host .main-bgd .duration {\n  color: white !important;\n}\n:host .main-bgd .desc {\n  color: white !important;\n  opacity: 0.8;\n}\n:host .main-bgd .relatedplan {\n  color: white;\n  background-color: rgba(255, 255, 255, 0.3) !important;\n}\n:host .main-bgd .multiplier {\n  color: white !important;\n  opacity: 0.7;\n}\n:host .main-bgd .trial {\n  color: white !important;\n}\n:host .right-corner {\n  position: absolute;\n  max-width: 30em;\n  top: 15em;\n  right: -18em;\n  z-index: -1;\n}\n@media (max-width: 769px) {\n  :host .right-corner {\n    display: none;\n  }\n}\n:host .features-top {\n  width: 80%;\n}\n@media (min-width: 769px) {\n  :host .features-top {\n    width: 60% !important;\n  }\n}\n@media (max-width: 568px) {\n  :host .features-top {\n    width: 95% !important;\n  }\n}\n@media (max-width: 768px) {\n  :host .plans-wrapper {\n    -webkit-box-pack: start !important;\n        -ms-flex-pack: start !important;\n            justify-content: flex-start !important;\n    overflow: auto;\n    width: 100%;\n  }\n}\n:host .flexbox {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .flexbox.cols {\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n:host .flexbox.between {\n  -webkit-box-pack: justify !important;\n      -ms-flex-pack: justify !important;\n          justify-content: space-between !important;\n}\n:host .flexbox.end {\n  -webkit-box-align: end;\n      -ms-flex-align: end;\n          align-items: flex-end;\n}\n:host .flexbox.stretch {\n  -webkit-box-align: stretch !important;\n      -ms-flex-align: stretch !important;\n          align-items: stretch !important;\n}\n@media (max-width: 769px) {\n  :host .flexbox.flow {\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-flow: column;\n            flex-flow: column;\n  }\n}\n:host .icon.arrow {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n  padding: 0em 0.7em 0.2em 0.7em;\n}\n:host .icon.arrow ::ng-deep svg {\n  width: 0.6em !important;\n  height: 0.6em !important;\n}\n:host .box {\n  box-shadow: 0px 5px 20px -4px lightgrey;\n  background-color: #f2f5f7;\n  border-radius: 2em;\n  font-size: 1.2em;\n  width: -webkit-fit-content;\n  width: -moz-fit-content;\n  width: fit-content;\n  margin: auto;\n}\n:host .pointer {\n  cursor: pointer;\n}\n:host .section {\n  color: #9aa3a7;\n  padding: 0.7em 1em;\n  min-width: 10em;\n  max-width: 12em;\n  text-align: center;\n}\n:host .section.selected {\n  color: var(--purple-alertnate);\n  font-weight: 600;\n  background-color: white;\n  border: 1px solid #e5ebed;\n  border-radius: 2em;\n}\n:host .h-2 {\n  height: 2em;\n}\n:host .h-4 {\n  height: 4em;\n}\n:host .h-6 {\n  height: 6em;\n}\n:host .singleplan .plan {\n  width: 22em !important;\n  padding: 0 1em !important;\n}\n:host .plan {\n  background-color: white;\n  border: 1px solid lightgray;\n  border-radius: 0.5em;\n  padding: 0 2em;\n  text-align: center;\n  width: 19em;\n  height: 30em;\n}\n:host .plan.isrelatedplans {\n  height: 40em;\n}\n:host .plan.isrelatedplans.h-42 {\n  height: 46em !important;\n}\n:host .plan .logo {\n  width: 4em;\n  height: 4em;\n  margin: auto;\n  margin-bottom: 0.75em;\n}\n:host .plan .logo img {\n  width: 100%;\n}\n:host .plan .darkgray {\n  color: #575757;\n}\n:host .plan .duration {\n  padding: 0 0.5em;\n  font-size: 1.2em;\n  color: #7f7f7f;\n}\n:host .plan .currency {\n  font-size: 1.7em;\n}\n:host .plan .price {\n  font-size: 2.7em;\n  font-weight: 600;\n  line-height: 1em;\n}\n:host .plan .initial.title {\n  text-transform: uppercase;\n  font-size: 1.3em;\n  height: 3em;\n}\n:host .plan .benefit {\n  font-size: 1.2em;\n  font-weight: 400;\n}\n:host .plan .relatedplan {\n  background-color: #f7f7f7;\n  margin: 1em 0;\n  padding: 0.5em 0;\n  border-radius: 0.5em;\n}\n:host .plan .relatedplan.nomultiplier {\n  padding: 0.5em 0;\n}\n:host .plan .relatedplan .title {\n  font-size: 1.1em;\n  padding: 0 0.7em;\n}\n:host .plan .relatedplan .planprice {\n  font-weight: 600;\n}\n:host .plan .relatedplan .multiplier {\n  text-decoration: line-through;\n  font-size: 0.9em;\n  color: #919191;\n}\n:host .pd2 {\n  padding: 1.2em 0 !important;\n}\n:host .cancelPlan {\n  font-size: 1.2em;\n  text-align: center;\n}\n:host .cancelPlan .terms {\n  text-decoration: underline;\n  color: black;\n  font-weight: 600;\n}\n:host .relatedplans-wrap {\n  height: 12em;\n}\n@media (max-width: 769px) {\n  :host .relatedplans-wrap {\n    height: 18em !important;\n  }\n  :host .relatedplans-wrap.h-13 {\n    height: 18em !important;\n  }\n}\n:host .relatedplans-wrap.h-13 {\n  height: 14em;\n}\n:host .relatedplans-wrap .desc {\n  font-size: 1.1em;\n  text-align: left;\n}\n:host .letter-space-1 {\n  letter-spacing: 1px;\n}\n:host .w-16 {\n  width: 16em;\n}\n:host .w-19 {\n  width: 19em;\n}\n:host .gradient-box {\n  height: calc(40em + 7px) !important;\n  background: white;\n  background-clip: padding-box;\n  border: solid 5px transparent;\n  border-radius: 1em;\n  position: relative;\n}\n:host .gradient-box:before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: -1;\n  margin: -5px;\n  border-radius: inherit;\n  background: -webkit-gradient(linear, left top, right top, from(#e13f8c), color-stop(46%, #9d2ad5), to(#2aa6e1));\n  background: linear-gradient(to right, #e13f8c 0%, #9d2ad5 46%, #2aa6e1 100%);\n}\n:host .main {\n  color: var(--purple-alertnate);\n  font-weight: 900;\n}\nhtml[lang=ar] :host .icon.arrow {\n  -webkit-transform: rotate(360deg) !important;\n      -ms-transform: rotate(360deg) !important;\n          transform: rotate(360deg) !important;\n}\nhtml[lang=ar] :host .plandtls {\n  -webkit-box-align: center !important;\n      -ms-flex-align: center !important;\n          align-items: center !important;\n}\nhtml[lang=ar] :host .relatedplans-wrap .desc {\n  text-align: right !important;\n}\n@media (max-width: 768px) {\n  html[lang=ar] :host .features-top {\n    width: 100% !important;\n  }\n}\nhtml[lang=fr] :host .initial.title {\n  height: 3em !important;\n}\nhtml[lang=fr] :host .price-wrap {\n  direction: ltr !important;\n}"

/***/ }),

/***/ "./src/app/modules/landing/plus/plus.component.ts":
/*!********************************************************!*\
  !*** ./src/app/modules/landing/plus/plus.component.ts ***!
  \********************************************************/
/*! exports provided: PlusComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlusComponent", function() { return PlusComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _anghami_services_subscription_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/subscription.service */ "./src/app/core/services/subscription.service.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");











let PlusComponent = class PlusComponent {
    constructor(_router, _route, _subscriptionService, _authService, _store, platformId) {
        this._router = _router;
        this._route = _route;
        this._subscriptionService = _subscriptionService;
        this._authService = _authService;
        this._store = _store;
        this.platformId = platformId;
        this.relPlansExist = false;
        this.multiplierExists = false;
        this.sectionsLst = [];
        this.visiblePlans = [];
        this.benefitsLst = [];
        this.subParams = {};
        this._route.queryParams.subscribe(params => {
            if (params && params !== null) {
                for (const key of Object.keys(params)) {
                    this.subParams[key] = params[key];
                }
            }
            if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_8__["isPlatformBrowser"])(this.platformId)) {
                this._subscriptionService.initSubscription(this.subParams, false);
            }
        });
        this.featuresLst = this._subscriptionService.getFeaturesLst();
    }
    ngOnInit() {
        this.isloggedin = this._authService.isUserLoggedIn();
        this._subscriptionService.getSubscription().subscribe((sub) => {
            if (sub && sub !== null) {
                this.subscribe = sub;
                this.benefitsLst = sub.features && sub.features.length > 3
                    ? sub.features.slice(0, 3)
                    : sub.features;
                this.initHandlingMainPage(sub);
            }
        });
        this._subscriptionService.getSections().subscribe(sections => {
            this.sectionsLst = sections;
            let sectionIndex = this._subscriptionService.getSectionIndex(this.sectionsLst.find(elt => elt.selected));
            sectionIndex = sectionIndex > -1 ? sectionIndex : 0;
            this.selectPlanSection(sectionIndex, this.sectionsLst[sectionIndex]);
        });
    }
    initHandlingMainPage(subscription) {
        const paypalObject = this._subscriptionService.getPaypal(this.subParams);
        if (Object.keys(paypalObject).length >= 2) {
            this._subscriptionService.paypalSubscription(paypalObject);
            return;
        }
        this._subscriptionService.getPaymentSections(this.subParams);
    }
    resetVisiblePlans() {
        this.visiblePlans = [];
    }
    resetSectionSelection(section, index) {
        this.subscribe.sections.forEach(elt => elt.selected = false);
        this.selectedSection = this._subscriptionService.getSectionIndex(section);
        section.selected = (this.selectedSection === index);
    }
    selectPlanSection(index, section) {
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_7__["AmplitudeEvents"].selectPlansSection,
            props: {
                sectiontype: section.type
            }
        }));
        if (this.selectedSection != index) {
            this.resetSectionSelection(section, index);
            this.resetVisiblePlans();
            this.visiblePlans =
                this.subscribe.plans.filter(elt => elt.section_type === section.type && !elt.hidden);
            this.handleRelatedPlans();
            this.reorderVisiblePlans();
        }
        else {
            section.selected = true;
        }
    }
    reorderVisiblePlans() {
        const mainPlan = this._subscriptionService.getMainPlan(this.visiblePlans);
        const mainPlanExists = mainPlan && mainPlan !== null ?
            Object.keys(mainPlan).length > 0
                ? true : false
            : false;
        if (this.visiblePlans && this.visiblePlans.length > 0 && mainPlanExists) {
            let index = 0;
            if (this.visiblePlans < 4 && this.visiblePlans.length % 2 != 0) { // && !this.isMobile
                index = Math.floor(this.visiblePlans.length / 2);
            }
            const replaceablePlan = this.visiblePlans[index];
            const mainplanindex = this.visiblePlans.findIndex(plan => plan.planid == mainPlan.planid);
            this.visiblePlans[index] = mainPlan;
            if (mainplanindex !== index) {
                this.visiblePlans[mainplanindex] = replaceablePlan;
            }
        }
    }
    handleRelatedPlans() {
        if (this.visiblePlans && this.visiblePlans.length > 0) {
            this.visiblePlans.forEach(plan => {
                return plan['relatedplans'] = this._subscriptionService.setRelatedPlans(plan);
            });
            this.multiplierExists = this.multiplierExist();
            this.relPlansExist = this.relatedPlansExist();
        }
    }
    multiplierExist() {
        this.visiblePlans.forEach(plan => {
            if (plan['relatedplans'] && plan['relatedplans'].length > 0) {
                plan.ismultiplier = (plan['relatedplans']
                    .find(elt => elt.multiplier && elt.multiplier != 0 && elt.multiplier !== '') !== undefined);
            }
        });
        return this.visiblePlans.find(elt => elt.ismultiplier === true)
            ? true
            : false;
    }
    relatedPlansExist() {
        return this.visiblePlans.find(plan => plan['relatedplans'] && plan['relatedplans'].length > 0)
            ? true
            : false;
    }
    actionPlan(plan) {
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_7__["AmplitudeEvents"].planAction,
            props: {
                title: plan.title,
                id: plan.planid,
                action: plan.action,
                type: plan.section_type
            }
        }));
        const selected = this.selectedSection < this.sectionsLst.length
            ? this.sectionsLst[this.selectedSection].type
            : '';
        if (!this.isloggedin && selected !== 'operator') {
            this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_9__["OpenCustomDialog"]({
                type: _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_10__["DIALOG_TYPES"].LOGIN
            }));
        }
        else {
            if (!plan.action || plan.action == null) {
                const queryparams = (this._subscriptionService.checkIfSubscribed(plan))
                    ? { subscribed: 1 }
                    : {};
                this._router.navigate([`/plus/${plan.planid}`], { queryParams: queryparams });
            }
            else if (plan.action && plan.action.includes('operators')) {
                const operator = this.getOperatorDetails(plan.action);
                this._router.navigate([`/plus/operators/${operator.name}/${operator.id}`]);
            }
            else if (plan.action && plan.action.includes('studentoffer')) {
                this._router.navigate(['/studentsoffer']);
            }
            else {
                window.open(plan.action, '_blank');
            }
        }
    }
    getOperatorDetails(action) {
        return {
            name: action.substring(action.lastIndexOf('/') + 1, action.lastIndexOf('?')),
            id: action.substring(action.lastIndexOf('pid=') + 4)
        };
    }
    goToBenefits() {
        const featuresid = document.getElementById('featuresId');
        if (featuresid && featuresid !== null) {
            featuresid.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    goToSubscribe() {
        const subscribeId = document.getElementById('subscribeId');
        if (subscribeId && subscribeId !== null) {
            subscribeId.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    ngOnDestroy() {
        this._subscriptionService.destroySubscriptions();
    }
};
PlusComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-plus',
        template: __webpack_require__(/*! raw-loader!./plus.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/plus/plus.component.html"),
        styles: [__webpack_require__(/*! ./plus.component.scss */ "./src/app/modules/landing/plus/plus.component.scss"), __webpack_require__(/*! ./plus-internal.component.scss */ "./src/app/modules/landing/plus/plus-internal.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](5, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _anghami_services_subscription_service__WEBPACK_IMPORTED_MODULE_3__["SubscriptionService"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
        Object])
], PlusComponent);



/***/ }),

/***/ "./src/app/modules/landing/plus/plus.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/modules/landing/plus/plus.module.ts ***!
  \*****************************************************/
/*! exports provided: PlusModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlusModule", function() { return PlusModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/footer/footer.module */ "./src/app/core/components/footer/footer.module.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _plus_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./plus.component */ "./src/app/modules/landing/plus/plus.component.ts");
/* harmony import */ var _plus_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./plus-routing.module */ "./src/app/modules/landing/plus/plus-routing.module.ts");
/* harmony import */ var _core_components_benefits_activation_benefits_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/benefits/activation-benefits.module */ "./src/app/core/components/benefits/activation-benefits.module.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _core_components_gift_block_gift_block_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/components/gift-block/gift-block.module */ "./src/app/core/components/gift-block/gift-block.module.ts");
/* harmony import */ var _core_components_features_features_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/components/features/features.module */ "./src/app/core/components/features/features.module.ts");
/* harmony import */ var _core_components_faq_faq_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/components/faq/faq.module */ "./src/app/core/components/faq/faq.module.ts");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _subscribe_subscribe_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./subscribe/subscribe.component */ "./src/app/modules/landing/plus/subscribe/subscribe.component.ts");
/* harmony import */ var _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/components/payment-form/payment-form.module */ "./src/app/core/components/payment-form/payment-form.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.module */ "./src/app/core/components/white-box/white-box.module.ts");
/* harmony import */ var _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../core/components/button/button.module */ "./src/app/core/components/button/button.module.ts");



















let PlusModule = class PlusModule {
};
PlusModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _plus_routing_module__WEBPACK_IMPORTED_MODULE_6__["PlusRoutingModule"],
            _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_3__["FooterModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateModule"],
            _core_components_benefits_activation_benefits_module__WEBPACK_IMPORTED_MODULE_7__["ActivationBenefitsModule"],
            _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_8__["IconModule"],
            _core_components_gift_block_gift_block_module__WEBPACK_IMPORTED_MODULE_9__["GiftBlockModule"],
            _core_components_features_features_module__WEBPACK_IMPORTED_MODULE_10__["FeaturesModule"],
            _core_components_faq_faq_module__WEBPACK_IMPORTED_MODULE_11__["FaqModule"],
            _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_12__["LoadingModule"],
            _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_14__["PaymentFormModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_15__["FormsModule"],
            ng_lazyload_image__WEBPACK_IMPORTED_MODULE_16__["LazyLoadImageModule"],
            _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_17__["WhiteBoxModule"],
            _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_18__["ButtonModule"]
        ],
        declarations: [
            _plus_component__WEBPACK_IMPORTED_MODULE_5__["PlusComponent"],
            _subscribe_subscribe_component__WEBPACK_IMPORTED_MODULE_13__["SubscribeComponent"]
        ]
    })
], PlusModule);



/***/ }),

/***/ "./src/app/modules/landing/plus/subscribe/subscribe.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/modules/landing/plus/subscribe/subscribe.component.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  @import url(https://fonts.googleapis.com/css?family=Roboto);\n}\n:host .back {\n  cursor: pointer;\n  width: 70%;\n  max-width: 80em;\n  margin: auto;\n}\n:host .back img {\n  max-width: 1em;\n}\n:host .back .txt {\n  color: #919191;\n}\n@media (max-width: 768px) {\n  :host .back {\n    padding: 1em;\n    width: 95%;\n  }\n}\n@media (min-width: 769px) {\n  :host .back.mx-2 {\n    margin: 0 !important;\n  }\n}\n:host .benefits {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n}\n:host .benefits .checkmark {\n  max-width: 1em;\n}\n:host .benefits .benefit-txt {\n  font-size: 1.2em;\n  font-weight: 500;\n}\n:host .ang-white-box {\n  margin-top: 8em;\n}\n:host .ang-white-box .notice {\n  font-size: 1.4em;\n  font-weight: 500;\n}\n:host .page-container {\n  margin-top: 2em;\n}\n:host .page-container .title {\n  text-align: center;\n}\n:host .page-container .form-container {\n  width: 70%;\n  max-width: 80em;\n  height: -webkit-fit-content;\n  height: -moz-fit-content;\n  height: fit-content;\n  min-height: 24rem;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin-top: 3em;\n  margin-bottom: 3em;\n  margin-left: auto;\n  margin-right: auto;\n  background: #fff;\n  border: 1px solid var(--bg-white-secondary);\n  border-radius: 8px;\n  box-shadow: 0 2px 4px 0 rgba(50, 50, 93, 0.1);\n}\n@media (max-width: 768px) {\n  :host .page-container .form-container {\n    width: inherit;\n    margin: 1em;\n  }\n}\n:host .page-container .form-container .form-left-side {\n  width: 60%;\n  padding: 0.9em 0.8em 0;\n}\n:host .page-container .form-container .form {\n  padding: 0.3em 0em 1.5em 0em;\n}\n:host .page-container .form-container .form-plans {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  margin: 0 1.3em;\n  height: auto;\n  border-bottom: 1px solid #d5d5d5;\n}\n:host .page-container .form-container .form-plans .tab {\n  font-size: 1.3em;\n  padding-top: 0.3em;\n  padding-right: 0.7em;\n}\n:host .page-container .form-container .form-plans .tab::after {\n  content: \"\";\n  display: block;\n  width: 0;\n  height: 2px;\n  background: #8d00f2;\n  -webkit-transition: width 0.15s;\n  transition: width 0.15s;\n  margin-top: 0.5em;\n}\n:host .page-container .form-container .form-plans .tab.active::after {\n  width: 100%;\n  margin-top: 0.5em;\n}\n:host .page-container .form-container .form-plans .tab:hover {\n  cursor: pointer;\n}\n:host .page-container .form-container .form-plans .tab img {\n  height: 1.5em;\n  width: 3em;\n}\n:host .page-container .form-container .related-plans-container {\n  width: 40%;\n  background-color: #f8fafb;\n  overflow: hidden;\n  padding: 2em;\n  position: relative;\n  border-top-right-radius: 8px;\n  border-bottom-right-radius: 8px;\n}\n:host .page-container .form-container .related-plans-container .related-plans-title {\n  font-size: 1.5em;\n  font-weight: 600;\n}\n:host .page-container .form-container .related-plans-container .arrow {\n  position: absolute;\n  left: 0;\n  top: 25em;\n}\n:host .page-container .form-container .related-plans-container .arrow img {\n  width: 1.5em;\n}\n:host .page-container .action-button {\n  background: -webkit-gradient(linear, left top, right top, from(#dc4190), to(#943dcb));\n  background: linear-gradient(to right, #dc4190, #943dcb);\n  margin: 2em auto 0.5em auto;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  max-width: 14em;\n  border: 1px solid var(--light-white);\n  white-space: nowrap;\n  padding: 0.5em 1em;\n  color: var(--light-white);\n  font-weight: 600;\n  text-align: center;\n  font-size: 1.1em;\n}\n:host .page-container .action-button.op-loader {\n  min-height: 2em;\n}\n:host .page-container .apple-action-button {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  margin: 2em auto 0.5em auto;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n@media (max-width: 1000px) {\n  :host .page-container ::ng-deep .payment-footer {\n    -webkit-box-orient: vertical !important;\n    -webkit-box-direction: normal !important;\n        -ms-flex-direction: column !important;\n            flex-direction: column !important;\n  }\n}\n@media (max-width: 768px) {\n  :host .page-container .form-container {\n    height: auto;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: reverse;\n        -ms-flex-direction: column-reverse;\n            flex-direction: column-reverse;\n  }\n  :host .page-container .form-left-side {\n    width: 100% !important;\n  }\n  :host .page-container .related-plans-container {\n    width: 100% !important;\n  }\n}\n:host .err-msg {\n  font-size: 0.9em;\n  color: red;\n  font-weight: 300;\n  margin: 1em 0;\n}\n@-webkit-keyframes ripple {\n  0% {\n    box-shadow: 0px 0px 0px 1px rgba(0, 0, 0, 0);\n  }\n  50% {\n    box-shadow: 0px 0px 0px 15px rgba(0, 0, 0, 0.1);\n  }\n  100% {\n    box-shadow: 0px 0px 0px 15px rgba(0, 0, 0, 0);\n  }\n}\n@keyframes ripple {\n  0% {\n    box-shadow: 0px 0px 0px 1px rgba(0, 0, 0, 0);\n  }\n  50% {\n    box-shadow: 0px 0px 0px 15px rgba(0, 0, 0, 0.1);\n  }\n  100% {\n    box-shadow: 0px 0px 0px 15px rgba(0, 0, 0, 0);\n  }\n}\n:host .md-radio {\n  margin: 16px 0;\n}\n:host .md-radio.md-radio-inline {\n  display: inline-block;\n}\n:host .md-radio input[type=radio] {\n  display: none;\n}\n:host .md-radio input[type=radio]:checked + label:before {\n  border-color: #92278f;\n  -webkit-animation: ripple 0.2s linear forwards;\n          animation: ripple 0.2s linear forwards;\n  background-color: transparent !important;\n}\n:host .md-radio input[type=radio]:checked + label:after {\n  -webkit-transform: scale(1);\n      -ms-transform: scale(1);\n          transform: scale(1);\n}\n:host .md-radio label {\n  display: inline-block;\n  min-height: 20px;\n  position: relative;\n  padding: 0 30px;\n  margin-bottom: 0;\n  cursor: pointer;\n  vertical-align: bottom;\n}\n:host .md-radio label:before, :host .md-radio label:after {\n  position: absolute;\n  content: \"\";\n  border-radius: 50%;\n  -webkit-transition: all 0.3s ease;\n  transition: all 0.3s ease;\n  -webkit-transition-property: border-color, -webkit-transform;\n  transition-property: border-color, -webkit-transform;\n  transition-property: transform, border-color;\n  transition-property: transform, border-color, -webkit-transform;\n}\n:host .md-radio label:before {\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  border: 2px solid rgba(0, 0, 0, 0.54);\n}\n:host .md-radio label:after {\n  top: 5px;\n  left: 5px;\n  width: 10px;\n  height: 10px;\n  -webkit-transform: scale(0);\n      -ms-transform: scale(0);\n          transform: scale(0);\n  background: #92278f;\n}\n:host *,\n:host *:before,\n:host *:after {\n  box-sizing: border-box;\n}\n:host body {\n  background: #f0f0f0;\n  position: absolute;\n  width: 100%;\n  padding: 0;\n  margin: 0;\n  font-family: \"Roboto\", sans-serif;\n  color: #333;\n}\n:host section {\n  background: white;\n  margin: 0 auto;\n  padding: 4em;\n  max-width: 800px;\n}\n:host section h1 {\n  margin: 0 0 2em;\n}\n:host section h3 {\n  margin: 1.5em 0 0;\n}\n@supports (-webkit-appearance: -apple-pay-button) {\n  :host .apple-pay-button-with-text {\n    display: inline-block;\n    -webkit-appearance: -apple-pay-button;\n    -apple-pay-button-type: buy;\n  }\n  :host .apple-pay-button-with-text > * {\n    display: none;\n  }\n  :host .apple-pay-button-black-with-text {\n    -apple-pay-button-style: black;\n  }\n  :host .apple-pay-button-white-with-text {\n    -apple-pay-button-style: white;\n  }\n  :host .apple-pay-button-white-with-line-with-text {\n    -apple-pay-button-style: white-outline;\n  }\n}\n@supports not (-webkit-appearance: -apple-pay-button) {\n  :host .apple-pay-button-with-text {\n    --apple-pay-scale: 1;\n    /* (height / 32) */\n    display: -webkit-inline-box;\n    display: -ms-inline-flexbox;\n    display: inline-flex;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    font-size: 12px;\n    border-radius: 5px;\n    padding: 0px;\n    box-sizing: border-box;\n    min-width: 200px;\n    min-height: 32px;\n    max-height: 64px;\n  }\n  :host .apple-pay-button-black-with-text {\n    background-color: black;\n    color: white;\n  }\n  :host .apple-pay-button-white-with-text {\n    background-color: white;\n    color: black;\n  }\n  :host .apple-pay-button-white-with-line-with-text {\n    background-color: white;\n    color: black;\n    border: 0.5px solid black;\n  }\n  :host .apple-pay-button-with-text.apple-pay-button-black-with-text > .logo {\n    background-image: -webkit-named-image(apple-pay-logo-white);\n    background-color: black;\n  }\n  :host .apple-pay-button-with-text.apple-pay-button-white-with-text > .logo {\n    background-image: -webkit-named-image(apple-pay-logo-black);\n    background-color: white;\n  }\n  :host .apple-pay-button-with-text.apple-pay-button-white-with-line-with-text > .logo {\n    background-image: -webkit-named-image(apple-pay-logo-black);\n    background-color: white;\n  }\n  :host .apple-pay-button-with-text > .text {\n    font-family: -apple-system;\n    font-size: calc(1em * var(--apple-pay-scale));\n    font-weight: 300;\n    -ms-flex-item-align: center;\n        align-self: center;\n    margin-right: calc(2px * var(--apple-pay-scale));\n  }\n  :host .apple-pay-button-with-text > .logo {\n    width: calc(35px * var(--scale));\n    height: 100%;\n    background-size: 100% 60%;\n    background-repeat: no-repeat;\n    background-position: 0 50%;\n    margin-left: calc(2px * var(--apple-pay-scale));\n    border: none;\n  }\n}\nhtml[lang=ar] :host .md-radio {\n  text-align: right;\n}\nhtml[lang=ar] :host .md-radio label:before {\n  right: 0;\n  left: unset !important;\n}\nhtml[lang=ar] :host .md-radio label:after {\n  right: 5px;\n  left: 0 1important;\n}\nhtml[lang=ar] :host .related-plans-title {\n  text-align: right;\n}\nhtml[lang=ar] :host .back {\n  width: 90%;\n  margin: auto;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}"

/***/ }),

/***/ "./src/app/modules/landing/plus/subscribe/subscribe.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/modules/landing/plus/subscribe/subscribe.component.ts ***!
  \***********************************************************************/
/*! exports provided: SubscribeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscribeComponent", function() { return SubscribeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _anghami_services_subscription_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/subscription.service */ "./src/app/core/services/subscription.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _app_core_components_payment_form_payment_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../app/core/components/payment-form/payment-form.component */ "./src/app/core/components/payment-form/payment-form.component.ts");
/* harmony import */ var _anghami_services_gateway_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/services/gateway.service */ "./src/app/core/services/gateway.service.ts");
/* harmony import */ var _anghami_services_plus_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/services/plus.service */ "./src/app/core/services/plus.service.ts");
/* harmony import */ var _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/plus.actions */ "./src/app/core/redux/actions/plus.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../app/core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");

















let SubscribeComponent = class SubscribeComponent {
    constructor(activatedRoute, subscriptionService, store, gatewayService, plusService, _actionSubject, _route, _router, _utilService, _authService, locale, platformId) {
        this.activatedRoute = activatedRoute;
        this.subscriptionService = subscriptionService;
        this.store = store;
        this.gatewayService = gatewayService;
        this.plusService = plusService;
        this._actionSubject = _actionSubject;
        this._route = _route;
        this._router = _router;
        this._utilService = _utilService;
        this._authService = _authService;
        this.locale = locale;
        this.platformId = platformId;
        this.currentPlan = null;
        this.getSubscribeResponse = null;
        this.relatedPlans = [];
        this.loading = true;
        this.radioSelectedPlan = null;
        this.cardList = [];
        this.activePaymentMethod = null;
        this.paymentLoading = false;
        this.applePaySupported = false;
        this.applePayHaveActiveCards = false;
        this.applePayCountry = null;
        this.isMobile = false;
        this.isSubscribed = false;
        this.benefitsLst = [];
        this.backArrowImg = this.locale === 'ar'
            ? 'https://anghamiwebcdn.akamaized.net/web2/assets/img/back-arrow-ar.png'
            : 'https://anghamiwebcdn.akamaized.net/web2/assets/img/back-arrow.png';
    }
    ngOnInit() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({ name: 'openPayment' }));
        this.isloggedin = this._authService.isUserLoggedIn();
        if (!this.isloggedin) {
            this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_15__["AuthRedirect"](`/login?redirecturl=${window.location.href}`));
        }
        this.planId = this.activatedRoute.snapshot.params['planid'];
        this.urlQueryParams = this.activatedRoute.snapshot.queryParamMap['params'];
        this.subscriptionService.getUserInfo();
        this.isMobile = this._utilService.detectmob();
        if (this.urlQueryParams && Object.keys(this.urlQueryParams).length > 0 && this.urlQueryParams['subscribed'] == 1) {
            this.isSubscribed = true;
        }
        if (this.subscriptionService.subscribe) {
            // Coming from /plus page
            this.fillPlanInfo(this.subscriptionService.subscribe);
        }
        else {
            // Coming directly to current /plus/:planid page
            this.subscriptionService.subscribeSubject.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1)).subscribe(resp => {
                this.fillPlanInfo(resp);
            });
            this.getSubscribe();
        }
    }
    back() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
            name: _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_12__["AmplitudeEvents"].onSubscribeBackNav
        }));
        this._router.navigate(['/plus']);
    }
    fillPlanInfo(subscribeResponse) {
        this.getSubscribeResponse = subscribeResponse;
        this.currentPlan = subscribeResponse.plans.find(plan => plan.planid === this.planId);
        if (this.currentPlan && this.currentPlan !== null) {
            if (!this.isSubscribed && this.subscriptionService.checkIfSubscribed(this.currentPlan)) {
                this.isSubscribed = true;
                this.loading = false;
            }
            else {
                this.benefitsLst = this.subscriptionService.getBenefits(this.currentPlan.planid == '649');
                this.relatedPlans = this.subscriptionService.setRelatedPlans(this.currentPlan);
                this.radioSelectedPlan = this.currentPlan;
                // a plan must be selected + set apple pay country if available in subscription response
                if (this.currentPlan && this.getSubscribeResponse.applepay_country) {
                    this.applePayCountry = this.getSubscribeResponse.applepay_country;
                }
                // store merchant_id and checkout public key in service from enviroment
                this.subscriptionService.fillCheckoutInfo(this.applePayCountry);
                this.isApplePayAvailable();
                this.fillCardList();
                this.loading = false;
            }
        }
        else {
            this._router.navigate(['/plus']);
        }
    }
    relatedPlanSelected($event, plan) {
        this.currentPlan = plan;
        this.planId = plan.planid;
        this.radioSelectedPlan = plan;
        if (this.currentPlan) {
            this.fillCardList();
        }
    }
    changePaymentMethod($event, card) {
        this.activePaymentMethod = card;
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
            name: 'changePaymentType',
            props: { cardtype: card.type }
        }));
    }
    fillCardList() {
        this.cardList = [];
        this.cardList.push({
            type: 'visa',
            image: `https://anghamiwebcdn.akamaized.net/web2/assets/img/card-details/Visa-Master.png`
        });
        // show tab if plan support apple pay (returned with applepay_country), even if the user don't have apple pay supported
        if (this.applePayCountry) {
            this.cardList.push({
                type: 'applepay',
                image: `https://anghamiwebcdn.akamaized.net/web2/assets/img/card-details/applePay.png`
            });
        }
        if (this.currentPlan.haspaypal === 1) {
            this.cardList.push({
                type: 'paypal',
                image: 'https://anghamiwebcdn.akamaized.net/web2/assets/img/card-details/paypal.png'
            });
        }
        if (this.currentPlan.hascashu === 1) {
            this.cardList.push({
                type: 'cashu',
                image: 'https://anghamiwebcdn.akamaized.net/web2/assets/img/card-details/cashu.jpg'
            });
        }
        this.activePaymentMethod = this.cardList[0];
    }
    getSubscribe() {
        const subParams = {};
        const pid = this._route.snapshot.params['planid'];
        const isSeries = pid && pid !== null
            ? this.subscriptionService.checkSeries(pid)
            : false;
        this.activatedRoute.queryParams.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1)).subscribe(params => {
            if (params) {
                for (const key of Object.keys(params)) {
                    subParams[key] = params[key];
                }
            }
            if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_16__["isPlatformBrowser"])(this.platformId)) {
                this.subscriptionService.initSubscription(subParams, isSeries);
            }
        });
    }
    onFormSubmit() {
        this.paymentLoading = true;
        if (this.activePaymentMethod.type === 'paypal') {
            this.subscriptionService.subscribeToPaypal(this.currentPlan);
        }
        else if (this.activePaymentMethod.type === 'visa') {
            this.paymentForm.submitForm();
        }
        else if (this.activePaymentMethod.type === 'cashu') { }
    }
    successPayment($event) {
        this.paymentLoading = false;
    }
    pay(info) {
        let paymentParams = Object.assign({ planid: this.currentPlan.planid && this.currentPlan.planid !== null ? this.currentPlan.planid : '' }, info); // if (this.currentPlan &&
        //   this.currentPlan.extradetails && this.currentPlan.extradetails !== null) {
        //   paymentParams = {
        //     ...paymentParams,
        //     ...this.currentPlan.extradetails
        //   };
        // }
        this.paymentSuccessSub$ = this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_11__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_10__["PlusActionTypes"].performPaymentSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1))
            .subscribe(data => {
            this.paymentLoading = false;
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                name: _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_12__["AmplitudeEvents"].submitPayment,
                props: {
                    price: this.currentPlan.price,
                    planid: this.currentPlan.planid
                }
            }));
            this.plusService.paymentSuccess(Object.assign({}, this.currentPlan, { id: this.currentPlan.planid }), true);
        });
        this.paymentErrorSub$ = this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_11__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_10__["PlusActionTypes"].performPaymentError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1))
            .subscribe((action) => {
            const data = action.payload ? action.payload.error : undefined;
            this.paymentLoading = false;
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                name: _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_12__["AmplitudeEvents"].submitPayment,
                props: {
                    price: this.currentPlan.price,
                    planid: this.currentPlan.planid
                }
            }));
            if (data['error']['message']) {
                this.errorMessage = data['error']['message'];
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_12__["AmplitudeEvents"].purchaseError,
                    props: {
                        price: this.currentPlan.price,
                        planid: this.currentPlan.planid,
                        message: data['error']['message']
                    }
                }));
            }
            else {
                this.errorMessage = 'There is a problem processing your request. Please try again';
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_12__["AmplitudeEvents"].purchaseError,
                    props: {
                        price: this.currentPlan.price,
                        planid: this.currentPlan.planid,
                        message: 'Unknown Error'
                    }
                }));
            }
        });
        this.store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_10__["performPayment"]({
            paymentParams: paymentParams,
            urlparams: this.urlQueryParams
        }));
    }
    handleApplePayErrors(response, step) {
        this.paymentLoading = false;
        const msg = response['error']
            ? response['error']['message'] ? response['error']['message'] : response['error']['_attributes']['message']
            : 'Oops, something went wrong! Please contact support.';
        this.errorMessage = msg;
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
            name: 'applepay_error',
            props: {
                step: step,
                message: msg
            }
        }));
    }
    isApplePayAvailable() {
        // first check if browser support apple pay
        if (window[`ApplePaySession`] && window.ApplePaySession.canMakePayments()) {
            this.applePaySupported = true;
            // then check if user have available setup cards with apple pay wallet
            const promise = window.ApplePaySession.canMakePaymentsWithActiveCard(this.subscriptionService.merchant_id);
            promise.then(canMakePayments => {
                if (canMakePayments) {
                    this.applePayHaveActiveCards = true;
                }
            });
        }
    }
    handleApplePayClick() {
        if (this.applePaySupported && this.applePayHaveActiveCards) {
            const paymentRequest = {
                countryCode: this.applePayCountry || 'SA',
                currencyCode: this.currentPlan.currency === '$' ? 'USD' : this.currentPlan.currency ? this.currentPlan.currency : 'USD',
                total: {
                    label: this.currentPlan.title || 'Selected Plan',
                    amount: Number(this.currentPlan.price) ? Number(this.currentPlan.price).toString() : '0',
                    type: 'final'
                },
                supportedNetworks: ['masterCard', 'visa', 'discover', 'amex', 'mada', 'elo'],
                merchantCapabilities: ['supports3DS']
            };
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                name: 'applepay_payment_request',
            }));
            this.applePaySession = new window.ApplePaySession(5, paymentRequest);
            /**
             * Merchant Validation
             * This event is triggered when the apple pay modal opens
             * We call our merchant session endpoint, passing the URL to use,
             * to get the verified session object
             */
            this.applePaySession.onvalidatemerchant = (event) => {
                this.gatewayService.gateway.getApplePaySession({
                    validation_url: event.validationURL
                }).then(response => {
                    if (response && response.payment_session) {
                        this.applePaySession.completeMerchantValidation(response.payment_session);
                        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                            name: 'applepay_merchant_validated'
                        }));
                    }
                    else {
                        this.handleApplePayErrors(response, 'merchant validation');
                    }
                }).catch(err => {
                    this.handleApplePayErrors(err, 'merchant validation catch');
                });
            };
            /**
             * This is called when user dismisses the payment modal
              this.applePaySession.oncancel = (event) => {
              };
             */
            /**
             * Payment Authorization
             * Here you receive the encrypted payment data.
             * We send this encrypted token to checkout api,
             * and return an appropriate status in session.completePayment()
             */
            this.applePaySession.onpaymentauthorized = (event) => {
                const token = event.payment.token;
                this.paymentLoading = true;
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: 'applepay_payment_autherized',
                    props: { transationId: token.paymentData.header.transactionId }
                }));
                let checkout_response;
                this.plusService.applePayCheckoutRequest(token, this.subscriptionService.checkout_public_key).subscribe((res) => {
                    checkout_response = res;
                }, err => this.handleApplePayErrors(err, 'checkout request'), () => {
                    if (checkout_response.token) {
                        // handling checkout body
                        const checkoutBody = {
                            token: checkout_response.token,
                            isCheckout: 1,
                            webmethod: 'APPLE_PAY'
                        };
                        this.pay(checkoutBody);
                        const status = checkout_response.token ?
                            this.applePaySession.STATUS_SUCCESS :
                            this.applePaySession.STATUS_FAILURE;
                        this.applePaySession.completePayment(status);
                        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                            name: 'applepay_payment_completed',
                            props: { status: status }
                        }));
                    }
                    else {
                        this.handleApplePayErrors(checkout_response, 'checkout response');
                    }
                });
            };
            /**
             * This will show up the modal for payments through Apple Pay
             */
            this.applePaySession.begin();
        }
    }
    ngOnDestroy() {
        this.subscriptionService.destroySubscriptions();
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('paymentForm', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _app_core_components_payment_form_payment_form_component__WEBPACK_IMPORTED_MODULE_7__["PaymentFormComponent"])
], SubscribeComponent.prototype, "paymentForm", void 0);
SubscribeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-subscribe',
        template: __webpack_require__(/*! raw-loader!./subscribe.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/plus/subscribe/subscribe.component.html"),
        styles: [__webpack_require__(/*! ./subscribe.component.scss */ "./src/app/modules/landing/plus/subscribe/subscribe.component.scss"), __webpack_require__(/*! ../plus-internal.component.scss */ "./src/app/modules/landing/plus/plus-internal.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](10, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](11, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _anghami_services_subscription_service__WEBPACK_IMPORTED_MODULE_3__["SubscriptionService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
        _anghami_services_gateway_service__WEBPACK_IMPORTED_MODULE_8__["GatewayService"],
        _anghami_services_plus_service__WEBPACK_IMPORTED_MODULE_9__["PlusService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["ActionsSubject"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_13__["UtilService"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_14__["AuthService"], String, Object])
], SubscribeComponent);



/***/ })

}]);