(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~core-components-operators-operators-module~gifts-gifts-module~plus-plus-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/features/features.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/features/features.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"features && features.length > 0\">\n  <div class=\"title\" i18n=\"@@allfeatures_title\">Get the ultimate music experience with Anghami Plus</div>\n  <div class=\"flexbox box\">\n    <div *ngFor=\"let feature of features\" class=\"flexbox feature\">\n      <img [lazyLoad]=\"feature?.image\">\n      <div class=\"pd-3\">\n        <div class=\"header\">{{ feature?.title | translate }}</div>\n        <div class=\"desc\">{{ feature?.description | translate }}</div>\n      </div>\n    </div>\n  </div>\n<anghami-button (click)=\"subscribeEvent.emit()\" label=\"getAnghamiPlus\" link=\"/plus\" layout=\"blue\" target=\"router\" >\n</anghami-button>\n</ng-container>"

/***/ }),

/***/ "./src/app/core/components/features/features.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/core/components/features/features.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .title {\n  text-align: center;\n  font-size: 1.3rem;\n  font-weight: 600;\n  margin: auto;\n  width: 50%;\n}\n@media (max-width: 768px) {\n  :host .title {\n    width: 90%;\n  }\n}\n:host .ang-operator-btn {\n  padding: 1em 2.5em;\n  font-size: 0.8rem;\n  box-shadow: 0px 5px 10px 5px lightgrey;\n}\n:host img {\n  max-width: 8em;\n}\n:host .flexbox {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .feature {\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  text-align: center;\n  max-width: 16em;\n  margin: 1.2em;\n}\n@media (max-width: 768px) {\n  :host .feature {\n    -webkit-box-orient: horizontal !important;\n    -webkit-box-direction: normal !important;\n        -ms-flex-direction: row !important;\n            flex-direction: row !important;\n    text-align: left;\n    min-width: 90%;\n    max-width: 100% !important;\n    -webkit-box-pack: start !important;\n        -ms-flex-pack: start !important;\n            justify-content: flex-start !important;\n  }\n}\n:host .feature .header {\n  font-weight: 600;\n  font-size: 1rem;\n  margin: 0.5em auto 0.25em auto;\n}\n@media (max-width: 768px) {\n  :host .feature .pd-3 {\n    padding: 0 1em;\n  }\n}\n:host .box {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  margin: 2em auto;\n  width: 80%;\n}\n@media (max-width: 768px) {\n  :host .box {\n    width: 90% !important;\n  }\n}\n@media (max-width: 768px) {\n  html[lang=ar] :host .feature {\n    direction: rtl;\n    text-align: right !important;\n  }\n}"

/***/ }),

/***/ "./src/app/core/components/features/features.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/core/components/features/features.component.ts ***!
  \****************************************************************/
/*! exports provided: FeaturesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FeaturesComponent", function() { return FeaturesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var FeaturesComponent = /** @class */ (function () {
    function FeaturesComponent() {
        this.subscribeEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    FeaturesComponent.prototype.ngOnInit = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], FeaturesComponent.prototype, "features", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], FeaturesComponent.prototype, "subscribeEvent", void 0);
    FeaturesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-features',
            template: __webpack_require__(/*! raw-loader!./features.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/features/features.component.html"),
            styles: [__webpack_require__(/*! ./features.component.scss */ "./src/app/core/components/features/features.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], FeaturesComponent);
    return FeaturesComponent;
}());



/***/ }),

/***/ "./src/app/core/components/features/features.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/core/components/features/features.module.ts ***!
  \*************************************************************/
/*! exports provided: FeaturesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FeaturesModule", function() { return FeaturesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _features_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./features.component */ "./src/app/core/components/features/features.component.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _button_button_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../button/button.module */ "./src/app/core/components/button/button.module.ts");








var FeaturesModule = /** @class */ (function () {
    function FeaturesModule() {
    }
    FeaturesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"], ng_lazyload_image__WEBPACK_IMPORTED_MODULE_6__["LazyLoadImageModule"], _button_button_module__WEBPACK_IMPORTED_MODULE_7__["ButtonModule"]],
            declarations: [_features_component__WEBPACK_IMPORTED_MODULE_4__["FeaturesComponent"]],
            exports: [_features_component__WEBPACK_IMPORTED_MODULE_4__["FeaturesComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], FeaturesModule);
    return FeaturesModule;
}());



/***/ }),

/***/ "./src/app/core/services/sub-operators.service.ts":
/*!********************************************************!*\
  !*** ./src/app/core/services/sub-operators.service.ts ***!
  \********************************************************/
/*! exports provided: SubOperatorsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubOperatorsService", function() { return SubOperatorsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/operators.actions */ "./src/app/core/redux/actions/operators.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");









var SubOperatorsService = /** @class */ (function () {
    function SubOperatorsService(_utilsService, _actionSubject, _store, platformId) {
        this._utilsService = _utilsService;
        this._actionSubject = _actionSubject;
        this._store = _store;
        this.platformId = platformId;
        this.msidnValidations = {};
        this.clearResultMessage();
    }
    SubOperatorsService.prototype.clearResultMessage = function () {
        this.resultmsg = '';
    };
    SubOperatorsService.prototype.getOperatorPlan = function (opdetails, isActivation) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_8__["isPlatformServer"])(this.platformId)) {
            return;
        }
        if (opdetails && opdetails !== null && Object.keys(opdetails).length > 0) {
            var appSidFromUrl = this._utilsService.getQueryFromUrl('appsid')
                || this._utilsService.getQueryFromUrl('sid');
            var params = {
                type: 'GEToperatorplan',
                output: 'jsonhp'
            };
            if (isActivation) {
                params['activation'] = opdetails.type;
            }
            else {
                params = Object.assign(params, opdetails);
            }
            if (appSidFromUrl) {
                params['appsid'] = appSidFromUrl;
            }
            var result = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["race"])(this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["OperatorsActionTypes"].GETOperatorSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(function (res) {
                return {
                    res: res.payload
                };
            })), this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["OperatorsActionTypes"].GETOperatorError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(function (res) {
                return {
                    res: res.payload
                };
            })));
            this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["GETOperator"](params));
            return result;
        }
    };
    SubOperatorsService.prototype.autofillPhoneNumber = function (msidn) {
        var mobilenum = '';
        if (msidn && msidn != null && msidn !== '') {
            var msidncode = msidn.substring(0, 3);
            if (msidncode === this.msidnValidations['countrycode']) {
                mobilenum = msidn.replace(/^.{3}/g, '');
            }
        }
        return mobilenum;
    };
    SubOperatorsService.prototype.checkOperatorValidationsExist = function (plan) {
        if (plan.min_digits && plan.min_digits !== null && plan.min_digits !== ''
            && plan.max_digits && plan.max_digits !== null && plan.max_digits !== ''
            && plan.country_code && plan.country_code !== null && plan.country_code !== '') {
            return true;
        }
        return false;
    };
    SubOperatorsService.prototype.setMsidnDetails = function (plan) {
        var validations = {};
        if (this.checkOperatorValidationsExist(plan)) {
            validations = {
                min_digits: plan.min_digits,
                max_digits: plan.max_digits,
                countrycode: plan.country_code
            };
        }
        return validations;
    };
    SubOperatorsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["ActionsSubject"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
            Object])
    ], SubOperatorsService);
    return SubOperatorsService;
}());



/***/ }),

/***/ "./src/app/core/services/subscription.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/core/services/subscription.service.ts ***!
  \*******************************************************/
/*! exports provided: SubscriptionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscriptionService", function() { return SubscriptionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/plus.actions */ "./src/app/core/redux/actions/plus.actions.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/sub-operators.service */ "./src/app/core/services/sub-operators.service.ts");














var SubscriptionService = /** @class */ (function () {
    function SubscriptionService(_store, _actionSubject, _translateService, _router, _subOperatorService) {
        this._store = _store;
        this._actionSubject = _actionSubject;
        this._translateService = _translateService;
        this._router = _router;
        this._subOperatorService = _subOperatorService;
        this.subscribeSubject = new rxjs__WEBPACK_IMPORTED_MODULE_10__["ReplaySubject"](1);
        this.sectionsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_10__["ReplaySubject"]();
    }
    SubscriptionService.prototype.getUserInfo = function () {
        var _this = this;
        this.user$ = this._store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_12__["getUser"]))
            .subscribe(function (data) {
            if (data && data !== null) {
                _this.user = JSON.parse(JSON.stringify(data));
            }
        });
    };
    SubscriptionService.prototype.destroySubscriptions = function () {
        if (this.user$) {
            this.user$.unsubscribe();
        }
    };
    SubscriptionService.prototype.initSubscription = function (params, isSeries) {
        var _this = this;
        var subparams = {};
        this.isSeries = isSeries;
        if (params && params !== null) {
            subparams = {
                country: params['country'],
                source: params['source'],
                mainplanid: params['mainplanid']
            };
            Object.keys(subparams).forEach(function (key) { return subparams[key] === undefined && delete subparams[key]; });
        }
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_4__["PlusActionTypes"].GETSubscribeSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(function (data) {
            var sub = data.payload && data.payload !== null
                ? data.payload.data
                : null;
            _this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_7__["AmplitudeEvents"].viewSubscribe
            }));
            if (sub && sub !== null) {
                _this.subscribe = JSON.parse(JSON.stringify(sub));
                _this.setSubscription(_this.subscribe);
            }
        });
        this._store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_4__["GETSubscribe"](params));
    };
    SubscriptionService.prototype.checkIfSubscribed = function (plan) {
        return this.user && this.user !== null
            ? (this.user.plantype === plan.plan_type)
            : false;
    };
    SubscriptionService.prototype.fillCheckoutInfo = function (applePayCountry) {
        // By default, it's the SA public key and merchant id
        // NB: in dev envirment both are sandbox and SA (handled in enviroment file)
        this.checkout_public_key = _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].checkout_public_key;
        this.merchant_id = _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].merchant_id;
        if (applePayCountry && applePayCountry === 'AE') {
            this.checkout_public_key = _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].AE_merchant_info.checkout_public_key;
            this.merchant_id = _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].AE_merchant_info.merchant_id;
        }
    };
    SubscriptionService.prototype.getPaypal = function (params) {
        var paypalObject = {};
        if (params && params['token'] && params['paypalstatus']) {
            return Object.assign(paypalObject, {
                'token': params['token'],
                'status': params['paypalstatus'] === 1
                    ? true
                    : false
            });
        }
        return paypalObject;
    };
    SubscriptionService.prototype.paypalSubscription = function (params) {
        var _this = this;
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_7__["AmplitudeEvents"].viewSubscribe,
            props: {
                token: params['token']
            }
        }));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_4__["PlusActionTypes"].EXECUTEpaypalsubSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(function (res) {
            var data = res.payload ? res.payload.data : {};
            if (data && data !== null && data !== '') {
                _this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_7__["AmplitudeEvents"].viewSubscribe
                }));
                _this._subOperatorService.resultmsg = _this._translateService.instant('paypal_confirm_sub');
                _this._router.navigate(['/subscriptioncheck']);
            }
        });
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_4__["PlusActionTypes"].EXECUTEpaypalsubError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(function (res) {
            var data = res.payload ? res.paylaod : {};
            if (data && data['error']) {
                _this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_7__["AmplitudeEvents"].executePaypalError,
                    props: {
                        error: true,
                        message: data['error'].message
                    }
                }));
                _this._subOperatorService.resultmsg = data['error'].message;
                _this._router.navigate(['/subscriptioncheck']);
            }
        });
        this._store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_4__["EXECUTEpaypalsub"](params));
    };
    SubscriptionService.prototype.subscribeToPaypal = function (plan) {
        var _this = this;
        plan.errMsg = '';
        plan.loader = 'https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/pay-loader.gif';
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_4__["PlusActionTypes"].SUBSCRIBEpaypalSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(function (res) {
            var data = res.payload ? res.payload.data : {};
            plan.loader = undefined;
            if (data && data['redirecturl']) {
                _this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_7__["AmplitudeEvents"].redirectPaypal
                }));
                window.location.href = data['redirecturl'];
            }
        });
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_4__["PlusActionTypes"].SUBSCRIBEpaypalError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(function (res) {
            plan.loader = undefined;
            var data = res.payload ? res.payload : {};
            if (data['error']) {
                plan.errMsg = data['error'].message;
            }
        });
        this._store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_4__["SUBSCRIBEpaypal"]({ planid: plan.planid }));
    };
    SubscriptionService.prototype.getPaymentTypes = function () {
        var sub = this.subscribe;
        var sectionsLst = [];
        if (sub && sub.sections && sub.sections.length > 0) {
            sub.sections.forEach(function (section) {
                if (sub.plans && sub.plans.length > 0) {
                    var selectedplans = sub.plans.filter(function (plan) { return plan.section_type == section.type; });
                    if (selectedplans && selectedplans.length > 0) {
                        sectionsLst.push(section);
                    }
                }
            });
        }
        return sectionsLst;
    };
    SubscriptionService.prototype.getPaymentSections = function (params) {
        this.sectionsLst = this.getPaymentTypes();
        if (this.sectionsLst.length > 0) {
            var selectedSection = params && params['payment_type']
                ? params['payment_type']
                : null;
            var index = 0;
            if (selectedSection !== null && selectedSection !== '') {
                this.sectionsLst.forEach(function (elt) {
                    elt.selected = (params['payment_type'] === elt.type);
                });
            }
            this.setSections(this.sectionsLst);
        }
    };
    SubscriptionService.prototype.getMainPlan = function (list) {
        var _this = this;
        var mainPlan = list.find(function (elt) { return elt.planid == _this.subscribe.mainplanid; });
        var mainPlanBackground = undefined;
        if (mainPlan && mainPlan.background) {
            mainPlanBackground = {
                'background-image': "url('" + mainPlan.background + "')",
                'background-color': '#9AA3A8',
                'background-repeat': 'no-repeat',
                'background-size': 'cover'
            };
            return mainPlan ? tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, mainPlan, { mainbgd: mainPlanBackground }) : {};
        }
    };
    SubscriptionService.prototype.checkSeries = function (id) {
        return _enums_enums__WEBPACK_IMPORTED_MODULE_7__["seriesOperatorIds"].indexOf(id) > -1;
    };
    // TODO: just for testing, to be removed later
    SubscriptionService.prototype.getFeaturesLst = function () {
        return [
            {
                'image': 'https://anghamiwebcdn.akamaized.net/web/assets/img/plus/features/features_download.png',
                'title': 'allfeatures_title_1',
                'description': 'allfeatures_subtitle_1'
            },
            {
                'image': 'https://anghamiwebcdn.akamaized.net/web/assets/img/plus/features/features_no_interruptions.png',
                'title': 'allfeatures_title_2',
                'description': 'allfeatures_subtitle_2'
            },
            {
                'image': 'https://anghamiwebcdn.akamaized.net/web/assets/img/plus/features/features_hq.png',
                'title': 'allfeatures_title_3',
                'description': 'allfeatures_subtitle_3'
            },
            {
                'image': 'https://anghamiwebcdn.akamaized.net/web/assets/img/plus/features/features_lyrics.png',
                'title': 'allfeatures_title_4',
                'description': 'allfeatures_subtitle_4'
            },
            {
                'image': 'https://anghamiwebcdn.akamaized.net/web/assets/img/plus/features/features_import_music.png',
                'title': 'allfeatures_title_5',
                'description': 'allfeatures_subtitle_5'
            },
            {
                'image': 'https://anghamiwebcdn.akamaized.net/web/assets/img/plus/features/features_sound.png',
                'title': 'allfeatures_title_6',
                'description': 'allfeatures_subtitle_6'
            },
            {
                'image': 'https://anghamiwebcdn.akamaized.net/web/assets/img/plus/features/features_skip.png',
                'title': 'allfeatures_title_7',
                'description': 'allfeatures_subtitle_7'
            }
        ];
    };
    SubscriptionService.prototype.setRelatedPlans = function (plan) {
        var relatedPlans = [];
        if (plan && this.subscribe.relatedplans && this.subscribe.relatedplans.length > 0) {
            var relplans_1 = this.subscribe.relatedplans.find(function (relplan) {
                return relplan.find(function (elt) { return elt === parseInt(plan.planid, 10); });
            });
            if (relplans_1) {
                relatedPlans = this.subscribe.plans.filter(function (elt) { return relplans_1.includes(parseInt(elt.planid, 10)); });
            }
        }
        return relatedPlans;
    };
    SubscriptionService.prototype.getSectionIndex = function (section) {
        return section && section !== null
            ? this.subscribe.sections.indexOf(this.subscribe.sections.find(function (elt) { return elt.type == section.type; }))
            : 0;
    };
    SubscriptionService.prototype.getBenefits = function (isStatic) {
        var list = [];
        if (isStatic) {
            list = [
                {
                    "title": this._translateService.instant('got_payment_benefit1')
                }, {
                    "title": this._translateService.instant('got_payment_benefit2')
                }, {
                    "title": this._translateService.instant('got_payment_benefit3')
                }, {
                    "title": this._translateService.instant('got_payment_benefit4')
                }, {
                    "title": this._translateService.instant('got_payment_benefit5')
                }, {
                    "title": this._translateService.instant('got_payment_benefit6')
                }
            ];
        }
        else {
            if (this.subscribe && this.subscribe.features
                && this.subscribe.features != null) {
                list = list.concat(this.subscribe.features);
            }
        }
        return list;
    };
    SubscriptionService.prototype.setSubscription = function (sub) {
        this.subscribeSubject.next(sub);
    };
    SubscriptionService.prototype.getSubscription = function () {
        return this.subscribeSubject.asObservable();
    };
    SubscriptionService.prototype.setSections = function (list) {
        this.sectionsSubject.next(list);
    };
    SubscriptionService.prototype.getSections = function () {
        return this.sectionsSubject.asObservable();
    };
    SubscriptionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"],
            _anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_13__["SubOperatorsService"]])
    ], SubscriptionService);
    return SubscriptionService;
}());



/***/ })

}]);