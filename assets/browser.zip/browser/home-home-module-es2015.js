(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/aos/dist/aos.js":
/*!**************************************!*\
  !*** ./node_modules/aos/dist/aos.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

!function(e,t){ true?module.exports=t():undefined}(this,function(){return function(e){function t(o){if(n[o])return n[o].exports;var i=n[o]={exports:{},id:o,loaded:!1};return e[o].call(i.exports,i,i.exports,t),i.loaded=!0,i.exports}var n={};return t.m=e,t.c=n,t.p="dist/",t(0)}([function(e,t,n){"use strict";function o(e){return e&&e.__esModule?e:{default:e}}var i=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(e[o]=n[o])}return e},r=n(1),a=(o(r),n(6)),u=o(a),c=n(7),s=o(c),f=n(8),d=o(f),l=n(9),p=o(l),m=n(10),b=o(m),v=n(11),y=o(v),g=n(14),h=o(g),w=[],k=!1,x={offset:120,delay:0,easing:"ease",duration:400,disable:!1,once:!1,startEvent:"DOMContentLoaded",throttleDelay:99,debounceDelay:50,disableMutationObserver:!1},j=function(){var e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];if(e&&(k=!0),k)return w=(0,y.default)(w,x),(0,b.default)(w,x.once),w},O=function(){w=(0,h.default)(),j()},M=function(){w.forEach(function(e,t){e.node.removeAttribute("data-aos"),e.node.removeAttribute("data-aos-easing"),e.node.removeAttribute("data-aos-duration"),e.node.removeAttribute("data-aos-delay")})},S=function(e){return e===!0||"mobile"===e&&p.default.mobile()||"phone"===e&&p.default.phone()||"tablet"===e&&p.default.tablet()||"function"==typeof e&&e()===!0},_=function(e){x=i(x,e),w=(0,h.default)();var t=document.all&&!window.atob;return S(x.disable)||t?M():(x.disableMutationObserver||d.default.isSupported()||(console.info('\n      aos: MutationObserver is not supported on this browser,\n      code mutations observing has been disabled.\n      You may have to call "refreshHard()" by yourself.\n    '),x.disableMutationObserver=!0),document.querySelector("body").setAttribute("data-aos-easing",x.easing),document.querySelector("body").setAttribute("data-aos-duration",x.duration),document.querySelector("body").setAttribute("data-aos-delay",x.delay),"DOMContentLoaded"===x.startEvent&&["complete","interactive"].indexOf(document.readyState)>-1?j(!0):"load"===x.startEvent?window.addEventListener(x.startEvent,function(){j(!0)}):document.addEventListener(x.startEvent,function(){j(!0)}),window.addEventListener("resize",(0,s.default)(j,x.debounceDelay,!0)),window.addEventListener("orientationchange",(0,s.default)(j,x.debounceDelay,!0)),window.addEventListener("scroll",(0,u.default)(function(){(0,b.default)(w,x.once)},x.throttleDelay)),x.disableMutationObserver||d.default.ready("[data-aos]",O),w)};e.exports={init:_,refresh:j,refreshHard:O}},function(e,t){},,,,,function(e,t){(function(t){"use strict";function n(e,t,n){function o(t){var n=b,o=v;return b=v=void 0,k=t,g=e.apply(o,n)}function r(e){return k=e,h=setTimeout(f,t),M?o(e):g}function a(e){var n=e-w,o=e-k,i=t-n;return S?j(i,y-o):i}function c(e){var n=e-w,o=e-k;return void 0===w||n>=t||n<0||S&&o>=y}function f(){var e=O();return c(e)?d(e):void(h=setTimeout(f,a(e)))}function d(e){return h=void 0,_&&b?o(e):(b=v=void 0,g)}function l(){void 0!==h&&clearTimeout(h),k=0,b=w=v=h=void 0}function p(){return void 0===h?g:d(O())}function m(){var e=O(),n=c(e);if(b=arguments,v=this,w=e,n){if(void 0===h)return r(w);if(S)return h=setTimeout(f,t),o(w)}return void 0===h&&(h=setTimeout(f,t)),g}var b,v,y,g,h,w,k=0,M=!1,S=!1,_=!0;if("function"!=typeof e)throw new TypeError(s);return t=u(t)||0,i(n)&&(M=!!n.leading,S="maxWait"in n,y=S?x(u(n.maxWait)||0,t):y,_="trailing"in n?!!n.trailing:_),m.cancel=l,m.flush=p,m}function o(e,t,o){var r=!0,a=!0;if("function"!=typeof e)throw new TypeError(s);return i(o)&&(r="leading"in o?!!o.leading:r,a="trailing"in o?!!o.trailing:a),n(e,t,{leading:r,maxWait:t,trailing:a})}function i(e){var t="undefined"==typeof e?"undefined":c(e);return!!e&&("object"==t||"function"==t)}function r(e){return!!e&&"object"==("undefined"==typeof e?"undefined":c(e))}function a(e){return"symbol"==("undefined"==typeof e?"undefined":c(e))||r(e)&&k.call(e)==d}function u(e){if("number"==typeof e)return e;if(a(e))return f;if(i(e)){var t="function"==typeof e.valueOf?e.valueOf():e;e=i(t)?t+"":t}if("string"!=typeof e)return 0===e?e:+e;e=e.replace(l,"");var n=m.test(e);return n||b.test(e)?v(e.slice(2),n?2:8):p.test(e)?f:+e}var c="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},s="Expected a function",f=NaN,d="[object Symbol]",l=/^\s+|\s+$/g,p=/^[-+]0x[0-9a-f]+$/i,m=/^0b[01]+$/i,b=/^0o[0-7]+$/i,v=parseInt,y="object"==("undefined"==typeof t?"undefined":c(t))&&t&&t.Object===Object&&t,g="object"==("undefined"==typeof self?"undefined":c(self))&&self&&self.Object===Object&&self,h=y||g||Function("return this")(),w=Object.prototype,k=w.toString,x=Math.max,j=Math.min,O=function(){return h.Date.now()};e.exports=o}).call(t,function(){return this}())},function(e,t){(function(t){"use strict";function n(e,t,n){function i(t){var n=b,o=v;return b=v=void 0,O=t,g=e.apply(o,n)}function r(e){return O=e,h=setTimeout(f,t),M?i(e):g}function u(e){var n=e-w,o=e-O,i=t-n;return S?x(i,y-o):i}function s(e){var n=e-w,o=e-O;return void 0===w||n>=t||n<0||S&&o>=y}function f(){var e=j();return s(e)?d(e):void(h=setTimeout(f,u(e)))}function d(e){return h=void 0,_&&b?i(e):(b=v=void 0,g)}function l(){void 0!==h&&clearTimeout(h),O=0,b=w=v=h=void 0}function p(){return void 0===h?g:d(j())}function m(){var e=j(),n=s(e);if(b=arguments,v=this,w=e,n){if(void 0===h)return r(w);if(S)return h=setTimeout(f,t),i(w)}return void 0===h&&(h=setTimeout(f,t)),g}var b,v,y,g,h,w,O=0,M=!1,S=!1,_=!0;if("function"!=typeof e)throw new TypeError(c);return t=a(t)||0,o(n)&&(M=!!n.leading,S="maxWait"in n,y=S?k(a(n.maxWait)||0,t):y,_="trailing"in n?!!n.trailing:_),m.cancel=l,m.flush=p,m}function o(e){var t="undefined"==typeof e?"undefined":u(e);return!!e&&("object"==t||"function"==t)}function i(e){return!!e&&"object"==("undefined"==typeof e?"undefined":u(e))}function r(e){return"symbol"==("undefined"==typeof e?"undefined":u(e))||i(e)&&w.call(e)==f}function a(e){if("number"==typeof e)return e;if(r(e))return s;if(o(e)){var t="function"==typeof e.valueOf?e.valueOf():e;e=o(t)?t+"":t}if("string"!=typeof e)return 0===e?e:+e;e=e.replace(d,"");var n=p.test(e);return n||m.test(e)?b(e.slice(2),n?2:8):l.test(e)?s:+e}var u="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},c="Expected a function",s=NaN,f="[object Symbol]",d=/^\s+|\s+$/g,l=/^[-+]0x[0-9a-f]+$/i,p=/^0b[01]+$/i,m=/^0o[0-7]+$/i,b=parseInt,v="object"==("undefined"==typeof t?"undefined":u(t))&&t&&t.Object===Object&&t,y="object"==("undefined"==typeof self?"undefined":u(self))&&self&&self.Object===Object&&self,g=v||y||Function("return this")(),h=Object.prototype,w=h.toString,k=Math.max,x=Math.min,j=function(){return g.Date.now()};e.exports=n}).call(t,function(){return this}())},function(e,t){"use strict";function n(e){var t=void 0,o=void 0,i=void 0;for(t=0;t<e.length;t+=1){if(o=e[t],o.dataset&&o.dataset.aos)return!0;if(i=o.children&&n(o.children))return!0}return!1}function o(){return window.MutationObserver||window.WebKitMutationObserver||window.MozMutationObserver}function i(){return!!o()}function r(e,t){var n=window.document,i=o(),r=new i(a);u=t,r.observe(n.documentElement,{childList:!0,subtree:!0,removedNodes:!0})}function a(e){e&&e.forEach(function(e){var t=Array.prototype.slice.call(e.addedNodes),o=Array.prototype.slice.call(e.removedNodes),i=t.concat(o);if(n(i))return u()})}Object.defineProperty(t,"__esModule",{value:!0});var u=function(){};t.default={isSupported:i,ready:r}},function(e,t){"use strict";function n(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function o(){return navigator.userAgent||navigator.vendor||window.opera||""}Object.defineProperty(t,"__esModule",{value:!0});var i=function(){function e(e,t){for(var n=0;n<t.length;n++){var o=t[n];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,o.key,o)}}return function(t,n,o){return n&&e(t.prototype,n),o&&e(t,o),t}}(),r=/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i,a=/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i,u=/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i,c=/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i,s=function(){function e(){n(this,e)}return i(e,[{key:"phone",value:function(){var e=o();return!(!r.test(e)&&!a.test(e.substr(0,4)))}},{key:"mobile",value:function(){var e=o();return!(!u.test(e)&&!c.test(e.substr(0,4)))}},{key:"tablet",value:function(){return this.mobile()&&!this.phone()}}]),e}();t.default=new s},function(e,t){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=function(e,t,n){var o=e.node.getAttribute("data-aos-once");t>e.position?e.node.classList.add("aos-animate"):"undefined"!=typeof o&&("false"===o||!n&&"true"!==o)&&e.node.classList.remove("aos-animate")},o=function(e,t){var o=window.pageYOffset,i=window.innerHeight;e.forEach(function(e,r){n(e,i+o,t)})};t.default=o},function(e,t,n){"use strict";function o(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(t,"__esModule",{value:!0});var i=n(12),r=o(i),a=function(e,t){return e.forEach(function(e,n){e.node.classList.add("aos-init"),e.position=(0,r.default)(e.node,t.offset)}),e};t.default=a},function(e,t,n){"use strict";function o(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(t,"__esModule",{value:!0});var i=n(13),r=o(i),a=function(e,t){var n=0,o=0,i=window.innerHeight,a={offset:e.getAttribute("data-aos-offset"),anchor:e.getAttribute("data-aos-anchor"),anchorPlacement:e.getAttribute("data-aos-anchor-placement")};switch(a.offset&&!isNaN(a.offset)&&(o=parseInt(a.offset)),a.anchor&&document.querySelectorAll(a.anchor)&&(e=document.querySelectorAll(a.anchor)[0]),n=(0,r.default)(e).top,a.anchorPlacement){case"top-bottom":break;case"center-bottom":n+=e.offsetHeight/2;break;case"bottom-bottom":n+=e.offsetHeight;break;case"top-center":n+=i/2;break;case"bottom-center":n+=i/2+e.offsetHeight;break;case"center-center":n+=i/2+e.offsetHeight/2;break;case"top-top":n+=i;break;case"bottom-top":n+=e.offsetHeight+i;break;case"center-top":n+=e.offsetHeight/2+i}return a.anchorPlacement||a.offset||isNaN(t)||(o=t),n+o};t.default=a},function(e,t){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=function(e){for(var t=0,n=0;e&&!isNaN(e.offsetLeft)&&!isNaN(e.offsetTop);)t+=e.offsetLeft-("BODY"!=e.tagName?e.scrollLeft:0),n+=e.offsetTop-("BODY"!=e.tagName?e.scrollTop:0),e=e.offsetParent;return{top:n,left:t}};t.default=n},function(e,t){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=function(e){return e=e||document.querySelectorAll("[data-aos]"),Array.prototype.map.call(e,function(e){return{node:e}})};t.default=n}])});

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/button/button.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "  <a \n  class=\"anghami_btn {{layout}} {{size}}\"\n  (click)=\"clickHandler($event)\"\n  [href]=\"link\"\n  [attr.target]=\"target\"\n  [class.loading]=\"loading\">\n  <span *ngIf=\"!loading\">\n    {{label_locale}}\n  </span>\n    \n    <div class=\"spinner-border text-light\" role=\"status\" *ngIf=\"loading\">\n      <span class=\"sr-only\">Loading...</span>\n    </div>\n  </a>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/home/home.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/home/home.component.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"home-wrapper\">\n  <div class=\"landing-parallax-banner\">\n\n    <div class=\"content\">\n\n      <div class=\"hero-btn\" (click)=\"reportClickToAmplitude()\" >\n        <a *ngIf=\"os === 'ios'\"\n          href=\"https://itunes.apple.com/us/app/anghami-%D8%A7%D9%86%D8%BA%D8%A7%D9%85%D9%8A/id545395155?mt=8\">Play Now\n          for FREE</a>\n        <a *ngIf=\"os === 'android'\" href=\"https://play.google.com/store/apps/details?id=com.anghami&hl=en\">Play Now for\n          FREE</a>\n        <a *ngIf=\"os!=='android' && os!='ios'\" href=\"https://play.anghami.com/home\" i18n=\"@@Start Playing\">Play\n          Now for FREE</a>\n      </div>\n      <div class=\"man-parallax-wrapper\">\n        <div class=\"man-parallax\">\n          <div class=\"hero-title\">\n            <h1 i18n=\"@@landing_hero_title\">FREE MUSIC</h1>\n            <h2 i18n=\"@@landing_hero_subtitle\">Anytime, anywhere</h2>\n          </div>\n          <div class=\"man-parallax-holder\">\n            <img [src]=\"env + 'ManWeb_landing.png'\" #manParallax>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <section class=\"container songs\">\n    <div class=\"row no-gutters\">\n      <div class=\"col-md-6 col-xs-12 order-2 order-md-1\">\n        <div class=\"img-collection-cntr\">\n          <a [attr.href]=\"\n              (landingData?.breakfree)[switch1.index]['data'][\n                landingData.breakfree[switch1.index]['highlighted_id']\n              ]?.link\n            \">\n            <ng-container *ngFor=\"\n                let breakFreeImg of (landingData?.breakfree)[switch1.index][\n                  'data'\n                ] | keyvalue;\n                index as i\n              \">\n              <div class=\"cntr\" [class.one]=\"i === 0\" [class.two]=\"i === 1\" [class.three]=\"i === 2\"\n                [class.four]=\"i === 3\">\n                <img [@animateSwitchColl]=\"'in'\" class=\"img-fluid\" [src]=\"breakFreeImg.value.image\" alt=\"\" />\n                <div class=\"play-icon\">\n                  <img [src]=\"env + 'play-button.png'\" alt=\"\" />\n                </div>\n              </div>\n            </ng-container>\n          </a>\n        </div>\n      </div>\n      <div class=\"col-md-6 col-xs-12 div-2 order-1 order-md-2\">\n        <div class=\"title text-uppercase text-center text-md-right\" i18n=\"@@landing_section1_title\">\n          BREAK FREE WITH <br />\n          MILLIONS OF SONGS\n        </div>\n        <div class=\"subtitle text-center text-md-right\" i18n=\"@@landing_section1_subtitle\">\n          Arabic and International in one place\n        </div>\n        <div class=\"switch-section-title\">\n          <ul class=\"d-flex d-md-block justify-content-between\">\n            <li [class.active]=\"switch1.index === ind1\" *ngFor=\"let break of landingData?.breakfree; index as ind1\">\n              <span class=\"text-capitalize\">{{ break.title }} {{ index }}</span>\n              <br class=\"d-block d-md-none\" />\n              <div class=\"loading\">\n                <span [ngStyle]=\"{ 'width.%': switch1.width }\"></span>\n              </div>\n            </li>\n          </ul>\n        </div>\n      </div>\n    </div>\n  </section>\n  <section class=\"container-fluid product-platforms\">\n    <div class=\"row no-gutters\">\n      <div class=\"col-12 col-md-3 offset-md-1 platform-text-div\">\n        <div class=\"div-1 text-center text-md-left\" #platformText>\n          <h2 class=\"title text-uppercase\" i18n=\"@@landing_section2_title\">\n            MORE FREEDOM ON THE GO\n          </h2>\n          <p class=\"description\" i18n=\"@@landing_section2_subtitle\">\n            All the music you want. <br />Anywhere. Anytime\n          </p>\n          <!-- <button class=\"btn\">View Product</button> -->\n        </div>\n      </div>\n      <div class=\"text-center text-md-left col-12 col-md-8\">\n        <div class=\"row boxes-container no-gutters\" #platformBoxes>\n          <div data-aos=\"zoom-in\" data-aos-once=\"true\"\n            class=\"col-12 d-flex justify-content-between justify-content-md-center one\">\n            <div class=\"box-item d-inline-block\">\n              <img class=\"img-fluid\" [src]=\"env + 'mobile@2x.png'\" lowsrc=\"{{ env + 'mobile.png' }}\" alt=\"\" />\n              <p>Mobile & Tablets</p>\n            </div>\n            <div class=\"box-item d-inline-block\">\n              <img class=\"img-fluid\" [src]=\"env + 'laptop@2x.png'\" lowsrc=\"{{ env + 'laptop.png' }}\" alt=\"\" />\n              <p>Desktop & Laptop</p>\n            </div>\n            <div class=\"box-item d-inline-block\">\n              <img class=\"img-fluid\" [src]=\"env + 'speakers@2x.png'\" lowsrc=\"{{ env + 'speakers.png' }}\" alt=\"\" />\n              <p i18n=\"@@landing_section2_item3\">Speakers</p>\n            </div>\n          </div>\n          <div data-aos=\"zoom-in\" data-aos-once=\"true\"\n            class=\"col-12 d-flex justify-content-between justify-content-md-center two\">\n            <div class=\"box-item d-inline-block\">\n              <img class=\"img-fluid\" [src]=\"env + 'car@2x.png'\" lowsrc=\"{{ env + 'car.png' }}\" alt=\"\" />\n              <p i18n=\"@@landing_section2_item4\">Cars</p>\n            </div>\n            <div class=\"box-item d-inline-block\">\n              <img class=\"img-fluid\" [src]=\"env + 'chromecast@2x.png'\" lowsrc=\"{{ env + 'chromecast.png' }}\" alt=\"\" />\n              <p i18n=\"@@landing_section2_item5\">Chromecast</p>\n            </div>\n            <div class=\"img-fluid\" class=\"box-item d-inline-block\">\n              <img [src]=\"env + 'playstation@2x.png'\" lowsrc=\"{{ env + 'playstation.png' }}\" alt=\"\" />\n              <p i18n=\"@@landing_section2_item6\">Playstation</p>\n            </div>\n          </div>\n          <div data-aos=\"zoom-in\" data-aos-once=\"true\"\n            class=\"col-12 d-flex justify-content-center justify-content-md-center three\"\n            style=\"transform: translateX(60px);\">\n            <div class=\"box-item d-inline-block\">\n              <img class=\"img-fluid\" [src]=\"env + 'wearables@2x.png'\" lowsrc=\"{{ env + 'wearables.png' }}\" alt=\"\" />\n              <p i18n=\"@@landing_section2_item7\">Wearables</p>\n            </div>\n            <div class=\"box-item d-inline-block\">\n              <img class=\"img-fluid\" [src]=\"env + 'AppleTV@2x.png'\" lowsrc=\"{{ env + 'AppleTV.png' }}\" alt=\"\" />\n              <p i18n=\"@@landing_section2_item8\">Apple TV</p>\n            </div>\n            <div class=\"box-item d-inline-block\">\n              <img class=\"img-fluid\" [src]=\"env + 'TVs@2x.jpg'\" lowsrc=\"{{ env + 'TVs@2x.jpg' }}\" alt=\"\" />\n              <p i18n=\"@@landing_section2_item9\">On TVs</p>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>\n  <section class=\"container features\">\n    <div class=\"title\">\n      <h2 class=\"text-uppercase font-weight-bold\" i18n=\"@@landing_section3_title\">\n        THAT SOUNDS GREAT\n      </h2>\n    </div>\n    <div class=\"row no-gutters\">\n      <div data-aos=\"fade-down\" data-aos-once=\"true\"\n        class=\"col-12 feature d-flex flex-column flex-md-row align-items-center\"\n        *ngFor=\"let card of landingData?.cards | keyvalue\">\n        <img [lazyLoad]=\"(landingData?.cards)[card.key].image\" [attr.alt]=\"(landingData?.cards)[card.key].title\" />\n        <div class=\"info align-self-center\">\n          <h2>{{ (landingData?.cards)[card.key].title }}</h2>\n          <p>{{ (landingData?.cards)[card.key].description }}</p>\n        </div>\n      </div>\n    </div>\n  </section>\n  <section class=\"container-fluid latest\">\n    <div class=\"row no-gutters\" #latestTextSection>\n      <div class=\"col-12 col-md-6 mixtape-img order-2 order-md-1\">\n        <img [@animateSwitchColl]=\"'in'\" class=\"img-fluid mixtape-img\" [src]=\"switch2.img[switch2.index]\" alt=\"\" />\n      </div>\n      <div class=\"col-12 col-md-6 div-2 order-1 order-md-2\">\n        <div class=\"title text-uppercase\" i18n=\"@@landing_section4_title\">\n          Keeping up with the latest\n        </div>\n        <div class=\"subtitle\" i18n=\"@@landing_section1_subtitle\">\n          Arabic and International in one place\n        </div>\n        <div class=\"switch-section-title\">\n          <ul class=\"d-flex d-md-block justify-content-around\">\n            <li [class.active]=\"switch2.index === 0\">\n              <ng-container i18n=\"@@landing_section4_itemtitle1\">Stories </ng-container><br class=\"d-block d-md-none\" />\n              <div class=\"loading\">\n                <span [ngStyle]=\"{ 'width.%': switch2.width }\"></span>\n              </div>\n              <div class=\"desc d-none d-md-block\" *ngIf=\"switch2.index === 0\">\n                <p i18n=\"@@landing_section4_itemsubtitle1\">\n                  Reveal your friends’ mood through music and react to it\n                </p>\n              </div>\n            </li>\n            <li [class.active]=\"switch2.index === 1\">\n              <ng-container i18n=\"@@landing_section4_itemtitle2\">Radar\n              </ng-container>\n              <br class=\"d-block d-md-none\" />\n              <div class=\"loading\">\n                <span [ngStyle]=\"{ 'width.%': switch2.width }\"></span>\n              </div>\n              <div class=\"desc d-none d-md-block\" *ngIf=\"switch2.index === 1\">\n                <p i18n=\"@@landing_section4_itemsubtitle2\">\n                  Identify music playing around you\n                </p>\n              </div>\n            </li>\n            <li [class.active]=\"switch2.index === 2\">\n              <ng-container i18n=\"@@landing_section4_itemtitle3\">Chats\n              </ng-container>\n              <br class=\"d-block d-md-none\" />\n              <div class=\"loading\">\n                <span [ngStyle]=\"{ 'width.%': switch2.width }\"></span>\n              </div>\n              <div class=\"desc d-none d-md-block\" *ngIf=\"switch2.index === 2\">\n                <p i18n=\"@@landing_section4_itemsubtitle3\">\n                  A new way of sharing music with your friends\n                </p>\n              </div>\n            </li>\n          </ul>\n          <div class=\"desc-mob d-block d-md-none text-center\">\n            <h3 *ngIf=\"switch2.index === 0\" i18n=\"@@landing_section4_itemsubtitle1\">\n              Reveal your friends’ mood through music and react to it\n            </h3>\n            <h3 *ngIf=\"switch2.index === 1\" i18n=\"@@landing_section4_itemsubtitle2\">\n              Identify music playing around you\n            </h3>\n            <h3 *ngIf=\"switch2.index === 2\" i18n=\"@@landing_section4_itemsubtitle3\">\n              A new way of sharing music with your friends\n            </h3>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>\n  <section class=\"container-fluid plans\">\n    <h1 class=\"section-title\" i18n=\"@@landing_section5_title\">\n      A Sound For Everyone\n    </h1>\n    <div class=\"row no-gutters plans-row\">\n      <div class=\"col-12 d-flex flex-md-row flex-column justify-content-around align-items-center\">\n        <div [class.popular]=\"(landingData?.plans)[plan.key].flag\" class=\"plan\" [ngClass]=\"'order-' + plan.value.order\"\n          *ngFor=\"let plan of landingData?.plans | keyvalue\">\n          <div class=\"sale-box\" *ngIf=\"(landingData?.plans)[plan.key].flag === 'Popular'\">\n            <span class=\"on_sale\">{{\n              (landingData?.plans)[plan.key].flag\n            }}</span>\n          </div>\n          <div class=\"plan-title\">\n            <h3>{{ plan.value.title }}</h3>\n          </div>\n          <div class=\"plan-details\">\n            <ul class=\"features\">\n              <li [class.disabled]=\"feature.enabled == 0\" class=\"text-left text-md-left\"\n                *ngFor=\"let feature of landingData.plans[plan.key]['data']\">\n                <img [src]=\"env + 'checkmark-plan.png'\" alt=\"\" /> &nbsp;\n                <span> {{ feature.description }}</span>\n              </li>\n            </ul>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"row no-gutters\">\n      <div class=\"col btn-container\">\n\n          <anghami-button \n            label=\"learnMore\"\n            link=\"/subscribe\"\n            layout=\"blue_gradient\"\n            target=\"router\">\n          </anghami-button>\n      </div>\n    </div>\n  </section>\n  <section class=\"container-fluid gift\">\n    <div class=\"row no-gutters align-items-center\">\n      <div class=\"col-12 col-md-4 offset-md-2 text-center text-md-left\">\n        <h2 i18n=\"@@landing_section6_title\">The Gift of Music</h2>\n        <p i18n=\"@@landing_section6_subtitle\">\n          Share the joy of music with family and friends\n        </p>\n        <div class=\"col btn-container d-md-flex p-0\">\n          <anghami-button label=\"sendGift\" link=\"gifts\" target=\"router\" layout=\"blue_gradient\">\n          </anghami-button>\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 text-center\">\n        <img [src]=\"env + 'card@2x.png'\" lowsrc=\"{{ env + 'card.png' }}\" alt=\"\" width=\"65%\" />\n      </div>\n    </div>\n  </section>\n</div>\n"

/***/ }),

/***/ "./src/app/core/components/button/button-labels.enum.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button-labels.enum.ts ***!
  \**************************************************************/
/*! exports provided: ButtonLabelsEN, ButtonLabelsFR, ButtonLabelsAR */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsEN", function() { return ButtonLabelsEN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsFR", function() { return ButtonLabelsFR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsAR", function() { return ButtonLabelsAR; });
var ButtonLabelsEN;
(function (ButtonLabelsEN) {
    ButtonLabelsEN["learnMore"] = "Learn more";
    ButtonLabelsEN["sendGift"] = "Send gift";
    ButtonLabelsEN["goToHelpCenter"] = "Go to help center";
    ButtonLabelsEN["getAnghamiPlus"] = "Get Anghami Plus";
    ButtonLabelsEN["giftAnghamiPlus"] = "Gift Anghami Plus";
    ButtonLabelsEN["login"] = "Login";
    ButtonLabelsEN["manageAccount"] = "Manage Account";
    ButtonLabelsEN["subscribe"] = "Subscribe";
    ButtonLabelsEN["weAreHiring"] = "We're hiring";
    ButtonLabelsEN["haveApp"] = "Continue in app";
})(ButtonLabelsEN || (ButtonLabelsEN = {}));
var ButtonLabelsFR;
(function (ButtonLabelsFR) {
    ButtonLabelsFR["learnMore"] = "Renseignez - vous";
    ButtonLabelsFR["sendGift"] = "Envoyer un cadeau";
    ButtonLabelsFR["goToHelpCenter"] = "Aller au centre d'aide";
    ButtonLabelsFR["getAnghamiPlus"] = "Obtiens Anghami Plus";
    ButtonLabelsFR["giftAnghamiPlus"] = "Offrez Anghami Plus";
    ButtonLabelsFR["subscribe"] = "S'abonner";
    ButtonLabelsFR["login"] = "Connexion";
    ButtonLabelsFR["manageAccount"] = "Gestion du compte";
    ButtonLabelsFR["weAreHiring"] = "Nous recrutons";
    ButtonLabelsFR["haveApp"] = "Continuer depuis l'appli";
})(ButtonLabelsFR || (ButtonLabelsFR = {}));
var ButtonLabelsAR;
(function (ButtonLabelsAR) {
    ButtonLabelsAR["learnMore"] = "\u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0645\u0632\u064A\u062F";
    ButtonLabelsAR["sendGift"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u062A\u0643";
    ButtonLabelsAR["goToHelpCenter"] = "\u0627\u0630\u0647\u0628 \u0627\u0644\u0649 \u0642\u0633\u0645 \u0627\u0644\u0645\u0633\u0627\u0639\u062F\u0629";
    ButtonLabelsAR["getAnghamiPlus"] = "\u0625\u062D\u0635\u0644 \u0639\u0644\u0649 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u0633";
    ButtonLabelsAR["giftAnghamiPlus"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u0629 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u064E\u0633";
    ButtonLabelsAR["subscribe"] = "\u0627\u0634\u062A\u0631\u0643";
    ButtonLabelsAR["login"] = "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644";
    ButtonLabelsAR["manageAccount"] = "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u062D\u0633\u0627\u0628";
    ButtonLabelsAR["weAreHiring"] = "\u0646\u0648\u0638\u0651\u0641 \u0627\u0644\u0622\u0646!";
    ButtonLabelsAR["haveApp"] = "\u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0645\u0646 \u0627\u0644\u062A\u0637\u0628\u064A\u0642";
})(ButtonLabelsAR || (ButtonLabelsAR = {}));


/***/ }),

/***/ "./src/app/core/components/button/button.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: inline-block;\n}\n:host a {\n  text-decoration: none;\n  cursor: pointer;\n  color: #FFF;\n  padding: 1.2em 2.5em;\n  border-radius: 3em;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n  display: inline-block;\n}\n:host a.narrow {\n  padding: 0.8em 2.5em;\n}\n:host a .spinner-border {\n  width: 1.5rem;\n  height: 1.5rem;\n  vertical-align: middle;\n  margin-top: -0.1em;\n}\n:host a.loading {\n  padding: 1.2em 4em;\n}\n:host a.purple_gradient {\n  background-image: -webkit-gradient(linear, left top, right top, from(#e1418c), color-stop(#d6379b), color-stop(#c732ab), color-stop(#b035bc), to(#913ccd));\n  background-image: linear-gradient(to right, #e1418c, #d6379b, #c732ab, #b035bc, #913ccd);\n}\n:host a.white {\n  background: #FFF;\n  color: #000;\n}\n:host a.blue_gradient {\n  background: -webkit-gradient(linear, left top, right top, from(#0093fe), to(#5fd2cb));\n  background: linear-gradient(90deg, #0093fe 0%, #5fd2cb 100%);\n}\n:host a.purple {\n  background: #8d00f2;\n}\n:host a.blue {\n  background: #007ffe;\n  background: -webkit-gradient(linear, left top, right top, from(#007ffe), to(#01b5ff));\n  background: linear-gradient(90deg, #007ffe 0%, #01b5ff 100%);\n}\n:host:hover a:not(.loading) {\n  -webkit-transform: translateY(-2px);\n      -ms-transform: translateY(-2px);\n          transform: translateY(-2px);\n  opacity: 0.9;\n  box-shadow: 0px 3px 5px 0px rgba(0, 0, 0, 0.24);\n}"

/***/ }),

/***/ "./src/app/core/components/button/button.component.ts":
/*!************************************************************!*\
  !*** ./src/app/core/components/button/button.component.ts ***!
  \************************************************************/
/*! exports provided: ButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonComponent", function() { return ButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button-labels.enum */ "./src/app/core/components/button/button-labels.enum.ts");




let ButtonComponent = class ButtonComponent {
    constructor(router, locale) {
        this.router = router;
        this.locale = locale;
        this.label = '';
        this.layout = '';
        this.loading = false;
        this.link = '';
        this.target = '';
        this.size = '';
        this.hidden = false;
    }
    ngOnInit() {
        if (!this.label.length) {
            this.hidden = true;
        }
        let pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsEN"];
        if (this.locale === "ar") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsAR"];
        }
        else if (this.locale === "fr") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsFR"];
        }
        this.label_locale = pack[this.label] || this.label;
    }
    clickHandler(e) {
        if (this.target === "router") {
            e.preventDefault();
            this.router.navigateByUrl(this.link);
        }
        if (this.target === "none") {
            e.preventDefault();
            return;
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "label", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "layout", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ButtonComponent.prototype, "loading", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "link", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "target", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "size", void 0);
ButtonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-button',
        template: __webpack_require__(/*! raw-loader!./button.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html"),
        styles: [__webpack_require__(/*! ./button.component.scss */ "./src/app/core/components/button/button.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], String])
], ButtonComponent);



/***/ }),

/***/ "./src/app/core/components/button/button.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/components/button/button.module.ts ***!
  \*********************************************************/
/*! exports provided: ButtonModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonModule", function() { return ButtonModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button.component */ "./src/app/core/components/button/button.component.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");





let ButtonModule = class ButtonModule {
};
ButtonModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateModule"]],
        declarations: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
        exports: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]],
    })
], ButtonModule);



/***/ }),

/***/ "./src/app/core/redux/actions/landing.actions.ts":
/*!*******************************************************!*\
  !*** ./src/app/core/redux/actions/landing.actions.ts ***!
  \*******************************************************/
/*! exports provided: LandingActionTypes, GetLandingPage, GetLandingPageSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingActionTypes", function() { return LandingActionTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetLandingPage", function() { return GetLandingPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetLandingPageSuccess", function() { return GetLandingPageSuccess; });
var LandingActionTypes;
(function (LandingActionTypes) {
    LandingActionTypes["GetLandingPage"] = "[Landing] Get LandPage";
    LandingActionTypes["GetLandingPageSuccess"] = "[Landing] Get LandPage Success";
})(LandingActionTypes || (LandingActionTypes = {}));
class GetLandingPage {
    constructor(payload = null) {
        this.payload = payload;
        this.type = LandingActionTypes.GetLandingPage;
    }
}
class GetLandingPageSuccess {
    constructor(payload = null) {
        this.payload = payload;
        this.type = LandingActionTypes.GetLandingPageSuccess;
    }
}


/***/ }),

/***/ "./src/app/core/redux/effects/landing.effects.ts":
/*!*******************************************************!*\
  !*** ./src/app/core/redux/effects/landing.effects.ts ***!
  \*******************************************************/
/*! exports provided: LandingEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingEffects", function() { return LandingEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _services_landing_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/landing.service */ "./src/app/core/services/landing.service.ts");
/* harmony import */ var _actions_landing_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/landing.actions */ "./src/app/core/redux/actions/landing.actions.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");







let LandingEffects = class LandingEffects {
    constructor(actions$, landingService) {
        this.actions$ = actions$;
        this.landingService = landingService;
        this.getLandingData$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_landing_actions__WEBPACK_IMPORTED_MODULE_4__["LandingActionTypes"].GetLandingPage), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(action => {
            return this.landingService.getLandingPage().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(response => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_landing_actions__WEBPACK_IMPORTED_MODULE_4__["GetLandingPageSuccess"](response));
            }));
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], LandingEffects.prototype, "getLandingData$", void 0);
LandingEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"],
        _services_landing_service__WEBPACK_IMPORTED_MODULE_3__["LandingService"]])
], LandingEffects);



/***/ }),

/***/ "./src/app/core/redux/reducers/landing/index.ts":
/*!******************************************************!*\
  !*** ./src/app/core/redux/reducers/landing/index.ts ***!
  \******************************************************/
/*! exports provided: reducers */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducers", function() { return reducers; });
/* harmony import */ var _landing_reducer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./landing.reducer */ "./src/app/core/redux/reducers/landing/landing.reducer.ts");

const reducers = {
    data: _landing_reducer__WEBPACK_IMPORTED_MODULE_0__["reducer"]
};


/***/ }),

/***/ "./src/app/core/redux/reducers/landing/landing.reducer.ts":
/*!****************************************************************!*\
  !*** ./src/app/core/redux/reducers/landing/landing.reducer.ts ***!
  \****************************************************************/
/*! exports provided: initialState, reducer, getLandingDataState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducer", function() { return reducer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLandingDataState", function() { return getLandingDataState; });
/* harmony import */ var _anghami_redux_actions_landing_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @anghami/redux/actions/landing.actions */ "./src/app/core/redux/actions/landing.actions.ts");
/*
 * Created Date: Wednesday November 14th 2018
 * Author: Siraj Tahra
 * Email: siraj.tahra@anghami.com
 * -----
 * Copyright (c) 2018 Anghami
 */

const initialState = {
    cards: null,
    plans: null,
    breakfree: null
};
function reducer(state = initialState, action) {
    switch (action.type) {
        case _anghami_redux_actions_landing_actions__WEBPACK_IMPORTED_MODULE_0__["LandingActionTypes"].GetLandingPageSuccess: {
            return Object.assign({}, state, { cards: action.payload['_sections']['cards'], plans: action.payload['_sections']['plans'], breakfree: action.payload['_sections']['break_free'] });
        }
        default: {
            return state;
        }
    }
}
const getLandingDataState = (state) => state;


/***/ }),

/***/ "./src/app/core/redux/selectors/landing.selector.ts":
/*!**********************************************************!*\
  !*** ./src/app/core/redux/selectors/landing.selector.ts ***!
  \**********************************************************/
/*! exports provided: selectLandingState, selectLandingDataState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectLandingState", function() { return selectLandingState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectLandingDataState", function() { return selectLandingDataState; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/*
 * Created Date: Wednesday November 14th 2018
 * Author: Siraj Tahra
 * Email: siraj.tahra@anghami.com
 * -----
 * Copyright (c) 2018 Anghami
 */

const selectLandingState = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createFeatureSelector"])('landing');
const selectLandingDataState = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(selectLandingState, (state) => state.data);
// export const getLandingDataState = createSelector(
//     selectLandingDataState,
//     (state: AuthState) => state.loginPage
// );


/***/ }),

/***/ "./src/app/core/services/landing.service.ts":
/*!**************************************************!*\
  !*** ./src/app/core/services/landing.service.ts ***!
  \**************************************************/
/*! exports provided: LandingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingService", function() { return LandingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../core/enums/enums */ "./src/app/core/enums/enums.ts");









let LandingService = class LandingService {
    constructor(http, store, locale) {
        this.http = http;
        this.store = store;
        this.locale = locale;
    }
    getLandingPage() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('timestamp', date.toString())
            .set('type', 'GETLandingpagev2');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["timeout"])(3000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    getTeamMembers() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETTeam');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    getPress() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETPress');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                const newdata = data.sections[0].data.map(item => {
                    return Object.assign({}, item, { excerpt: item.excerpt.substring(0, 150) + '...' });
                });
                data.sections[0].data = newdata;
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    getSesssionsInfo() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETongroundeventinfo')
            .set('event_name', 'anghamisessions');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    SubmitSessionInfo(info) {
        const date = new Date().getTime();
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'POSTongroundeventattender.view');
        for (const key in info) {
            if (info.hasOwnProperty(key)) {
                body = body.set(key, info[key]);
            }
        }
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        });
    }
    getWebPurchaseOptions(params) {
        const date = new Date().getTime();
        let appSidFromUrl = this.getQueryFromUrl('appsid') || this.getQueryFromUrl('sid');
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETwebpurchaseoptions')
            .set('studentsoffer', '1');
        if (appSidFromUrl) {
            body = body.set("sid", appSidFromUrl);
        }
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err);
        }));
    }
    getQueryFromUrl(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split('&');
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split('=');
            if (decodeURIComponent(pair[0]) == variable) {
                return decodeURIComponent(pair[1]);
            }
        }
        return null;
    }
    postStudentsOfferProfileUpdates(params) {
        const date = new Date().getTime();
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        let successevent;
        let failevent;
        let appSidFromUrl = this.getQueryFromUrl('appsid') || this.getQueryFromUrl('sid');
        if (appSidFromUrl) {
            body = body.set('sid', appSidFromUrl);
        }
        if (params.email) {
            body = body.set('type', 'POSTaddemail').set('email', params.email);
            successevent = _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].studentOfferEmailSuccess;
            failevent = _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].studentOfferEmailFail;
        }
        else if (params.birthdate) {
            successevent = 'studentOfferEmailSuccess';
            failevent = 'studentOfferEmailFail';
            body = body
                .set('type', 'UPDATEprofile')
                .set('birthdate', params.birthdate);
        }
        else if (params.card_number && params.cardholder_name) {
            successevent = 'studentOfferISICSuccess';
            failevent = 'studentOfferISICFail';
            body = body
                .set('type', 'POSTisicmembership')
                .set('card_number', params.card_number)
                .set('cardholder_name', params.cardholder_name);
        }
        else {
            return;
        }
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: failevent,
                    props: {
                        details: data
                    }
                }));
            }
            else {
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: successevent,
                    props: {
                        details: data
                    }
                }));
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                name: failevent,
                props: {
                    details: err
                }
            }));
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err);
        }));
    }
    validateEmailToken(params) {
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        if (params && params !== null) {
            body = body.set('type', 'POSTvalidatemailtoken');
            for (const key of Object.keys(params)) {
                body = body.set(key, params[key]);
            }
        }
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
};
LandingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"], String])
], LandingService);



/***/ }),

/***/ "./src/app/modules/landing/home/aos.ts":
/*!*********************************************!*\
  !*** ./src/app/modules/landing/home/aos.ts ***!
  \*********************************************/
/*! exports provided: aos, AosToken */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "aos", function() { return aos; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AosToken", function() { return AosToken; });
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! aos */ "./node_modules/aos/dist/aos.js");
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(aos__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/*
 * Created Date: Thursday November 15th 2018
 * Author: Siraj Tahra
 * Email: siraj.tahra@anghami.com
 * -----
 * Copyright (c) 2018 Anghami
 */


const aos = aos__WEBPACK_IMPORTED_MODULE_0__;
// This makes it possible to refer to AOS in Angular, see below
const AosToken = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["InjectionToken"]('AOS');


/***/ }),

/***/ "./src/app/modules/landing/home/home.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/modules/landing/home/home.component.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@-webkit-keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes scale-in-right {\n  0% {\n    -webkit-transform: scale(0.8);\n    transform: scale(0.8);\n    -webkit-transform-origin: 100% 50%;\n    transform-origin: 100% 50%;\n    opacity: 1;\n  }\n  100% {\n    -webkit-transform: scale(1.2);\n    transform: scale(1.2);\n    -webkit-transform-origin: 100% 50%;\n    transform-origin: 100% 50%;\n    opacity: 1;\n  }\n}\n@keyframes scale-in-right {\n  0% {\n    -webkit-transform: scale(0.8);\n    transform: scale(0.8);\n    -webkit-transform-origin: 100% 50%;\n    transform-origin: 100% 50%;\n    opacity: 1;\n  }\n  100% {\n    -webkit-transform: scale(1.2);\n    transform: scale(1.2);\n    -webkit-transform-origin: 100% 50%;\n    transform-origin: 100% 50%;\n    opacity: 1;\n  }\n}\n@-webkit-keyframes crescendo {\n  0% {\n    -webkit-transform: scale(0.8);\n            transform: scale(0.8);\n  }\n  100% {\n    -webkit-transform: scale(1.5);\n            transform: scale(1.5);\n  }\n}\n@keyframes crescendo {\n  0% {\n    -webkit-transform: scale(0.8);\n            transform: scale(0.8);\n  }\n  100% {\n    -webkit-transform: scale(1.5);\n            transform: scale(1.5);\n  }\n}\n/* ----------------------------------------------\n * Generated by Animista on 2018-11-16 16:52:42\n * w: http://animista.net, t: @cssanimista\n * ---------------------------------------------- */\n/**\n * ----------------------------------------\n * animation scale-in-center\n * ----------------------------------------\n */\n@-webkit-keyframes scale-in-center {\n  0% {\n    -webkit-transform: scale(0.8);\n    transform: scale(0.8);\n    opacity: 1;\n  }\n  100% {\n    -webkit-transform: scale(1.2);\n    transform: scale(1.2);\n    opacity: 1;\n  }\n}\n@keyframes scale-in-center {\n  0% {\n    -webkit-transform: scale(0.8);\n    transform: scale(0.8);\n    opacity: 1;\n  }\n  100% {\n    -webkit-transform: scale(1.2);\n    transform: scale(1.2);\n    opacity: 1;\n  }\n}\nul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\nul li {\n  margin: 0;\n  padding: 0;\n}\n.home-wrapper .landing-parallax-banner {\n  text-align: center;\n  position: relative;\n  background-image: url('backgroundlanding.jpg');\n  background-position: center center;\n  background-size: cover;\n  border-bottom-right-radius: 150% 40%;\n  border-bottom-left-radius: 150% 40%;\n}\n.home-wrapper .landing-parallax-banner .hero-title {\n  position: absolute;\n  left: 0;\n  right: 0;\n  text-align: center;\n  bottom: 15%;\n}\n@media (max-width: 480px) {\n  .home-wrapper .landing-parallax-banner .hero-title {\n    bottom: 20%;\n  }\n}\n.home-wrapper .landing-parallax-banner .hero-title h1 {\n  color: #FFF;\n  font-weight: 800;\n  word-spacing: 3em;\n  font-size: 8em;\n  -webkit-transform: translateX(0.35em);\n      -ms-transform: translateX(0.35em);\n          transform: translateX(0.35em);\n  margin-bottom: 1em;\n  text-transform: uppercase;\n}\n@media (max-width: 1652px) {\n  .home-wrapper .landing-parallax-banner .hero-title h1 {\n    word-spacing: 2.5em;\n    font-size: 8em;\n    margin-bottom: 0.5em;\n  }\n}\n@media (max-width: 930px) {\n  .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 6.5em;\n    word-spacing: 1.7em;\n    margin-bottom: 0;\n  }\n}\n@media (max-width: 730px) {\n  .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 5.5em;\n    word-spacing: 1.4em;\n  }\n}\n@media (max-width: 575px) {\n  .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 5em;\n    word-spacing: 1.5em;\n  }\n}\n@media (max-width: 480px) {\n  .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 5.5em;\n    word-spacing: 99em;\n    -webkit-transform: translateX(0) translateY(-3em);\n        -ms-transform: translateX(0) translateY(-3em);\n            transform: translateX(0) translateY(-3em);\n  }\n}\n@media (max-width: 410px) {\n  .home-wrapper .landing-parallax-banner .hero-title h1 {\n    -webkit-transform: translateY(-2em);\n        -ms-transform: translateY(-2em);\n            transform: translateY(-2em);\n  }\n}\n@media (max-width: 340px) {\n  .home-wrapper .landing-parallax-banner .hero-title h1 {\n    -webkit-transform: translateY(-1em);\n        -ms-transform: translateY(-1em);\n            transform: translateY(-1em);\n    font-size: 3.5rem;\n  }\n}\n.home-wrapper .landing-parallax-banner .hero-title h2 {\n  color: #FFF;\n  text-align: center;\n  font-size: 4.5em;\n  font-weight: 500;\n  z-index: 2;\n  position: relative;\n}\n@media (max-width: 930px) {\n  .home-wrapper .landing-parallax-banner .hero-title h2 {\n    font-size: 4em;\n  }\n}\n@media (max-width: 730px) {\n  .home-wrapper .landing-parallax-banner .hero-title h2 {\n    font-size: 3.5em;\n  }\n}\n@media (max-width: 575px) {\n  .home-wrapper .landing-parallax-banner .hero-title h2 {\n    font-size: 2em;\n  }\n}\n.home-wrapper .landing-parallax-banner .man-parallax-wrapper {\n  border-bottom-right-radius: 150% 40%;\n  border-bottom-left-radius: 150% 40%;\n  overflow: hidden;\n}\n.home-wrapper .landing-parallax-banner .man-parallax {\n  width: 40%;\n  margin: auto;\n  padding: 5em 0 0 0;\n}\n@media (max-width: 480px) {\n  .home-wrapper .landing-parallax-banner .man-parallax {\n    width: 85%;\n    margin: auto;\n    padding: 18em 0 0 0;\n  }\n}\n.home-wrapper .landing-parallax-banner .man-parallax .man-parallax-holder {\n  overflow: hidden;\n}\n.home-wrapper .landing-parallax-banner .man-parallax .man-parallax-holder img {\n  display: block;\n  max-width: 100%;\n  margin: auto;\n  position: relative;\n  z-index: 1;\n}\n.home-wrapper .landing-parallax-banner .hero-btn {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  text-align: center;\n  z-index: 2;\n}\n.home-wrapper .landing-parallax-banner .hero-btn a {\n  padding: 1.2em 3.2em;\n  color: #FFF;\n  background-color: #1274d4;\n  text-align: center;\n  border-radius: 3em;\n  font-size: 1.4em;\n  text-decoration: none;\n  cursor: pointer;\n  -webkit-transition: background-color 200ms ease;\n  transition: background-color 200ms ease;\n  box-shadow: 0px 0px 17px -9px black;\n}\n.home-wrapper .landing-parallax-banner .hero-btn a:hover {\n  background-color: #0d579f;\n}\n.home-wrapper .landing-parallax-banner .hero-btn a:active {\n  background-color: #1274d4;\n}\n.home-wrapper > section .switch-section-title {\n  padding-top: 2em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section .switch-section-title {\n    font-size: 2vw;\n  }\n}\n.home-wrapper > section .switch-section-title ul {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: inline-block;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section .switch-section-title ul {\n    margin-right: 0em;\n    margin-top: 1em;\n    margin-bottom: 1em;\n  }\n}\n.home-wrapper > section .switch-section-title ul li {\n  font-weight: 600;\n  font-size: 1.5em;\n  padding-bottom: 1em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section .switch-section-title ul li {\n    text-align: center;\n    font-size: 2em;\n  }\n}\n.home-wrapper > section .switch-section-title ul li .loading {\n  display: inline-block;\n  opacity: 0;\n}\n.home-wrapper > section .switch-section-title ul li.active {\n  -webkit-transition: 1s ease-in-out;\n  transition: 1s ease-in-out;\n  -webkit-animation: scale-in-right 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) 0s 1 normal both running;\n          animation: scale-in-right 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) 0s 1 normal both running;\n  font-weight: bold;\n  margin-right: 0em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section .switch-section-title ul li.active {\n    -webkit-animation: scale-in-center 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) both;\n    animation: scale-in-center 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) both;\n  }\n}\n.home-wrapper > section .switch-section-title ul li.active .loading {\n  opacity: 1;\n  display: inline-block;\n}\n.home-wrapper > section .switch-section-title ul li .loading {\n  background-color: #d0d0d0;\n  width: 2em;\n  height: 0.12em;\n  margin-bottom: 3px;\n  transition: none;\n  -webkit-transition: none;\n  -moz-transition: none;\n}\n.home-wrapper > section .switch-section-title ul li .loading span {\n  background-color: #ce39a0;\n  display: block;\n  height: 100%;\n}\n.home-wrapper > section.video .video-status-btn {\n  position: absolute;\n  width: 2em;\n  height: 2em;\n  border-radius: 50%;\n  border: none;\n  z-index: 9;\n  margin: auto;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  cursor: pointer;\n  font-size: 3em;\n}\n.home-wrapper > section.video .video-status-btn .icon {\n  color: var(--app-background);\n  fill: var(--app-background);\n  padding: 0;\n  width: 2em;\n  height: 2em;\n  -webkit-transform: translate3d(12%, 10%, 0);\n          transform: translate3d(12%, 10%, 0);\n  -webkit-animation-name: fadeIn;\n  animation-name: fadeIn;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.3s;\n  animation-duration: 0.3s;\n  -webkit-animation-delay: 0;\n  animation-delay: 0;\n  -webkit-animation-timing-function: ease;\n  animation-timing-function: ease;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}\n.home-wrapper > section.video .video-cntr {\n  position: relative;\n}\n.home-wrapper > section.video .video-cntr .vid-footer {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  width: 100%;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding: 0 1em;\n  color: var(--app-background);\n  position: absolute;\n  bottom: 1em;\n  left: 0;\n  z-index: 9;\n}\n.home-wrapper > section.video .video-cntr .vid-footer div:not(.video-hd) {\n  display: inline-block;\n}\n.home-wrapper > section.video .video-cntr .video-fullscreen {\n  background-image: url('fullscreen.png');\n  background-position: 50%;\n  background-repeat: no-repeat;\n  background-size: contain;\n  width: 1.5em;\n  height: 1.5em;\n  display: inline-block;\n  vertical-align: middle;\n}\n.home-wrapper > section.video .video-cntr .video-fn-left {\n  padding: 0.25em;\n  background-color: rgba(1, 1, 1, 0.3);\n  border-radius: 0.7em;\n}\n.home-wrapper > section.video .video-cntr .video-fullscreen,\n.home-wrapper > section.video .video-cntr .video-hd {\n  cursor: pointer;\n}\n.home-wrapper > section.video .video-cntr .video-hd {\n  border-radius: 50%;\n  color: var(--text-color);\n  background-color: var(--hd);\n  width: 2em;\n  height: 2em;\n  margin: 0 1em;\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.home-wrapper > section.video .video-cntr .video-hd h5 {\n  font-size: 0.83em;\n  font-weight: 800;\n  margin: 0;\n}\n.home-wrapper > section.video .video-cntr #video {\n  width: 100%;\n  height: 37em;\n  display: block;\n  position: relative;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.video .video-cntr #video {\n    height: 16em;\n  }\n}\n.home-wrapper > section.songs {\n  padding-top: 2em;\n}\n.home-wrapper > section.songs .div-2 {\n  text-align: right;\n}\n@media (min-width: 576px) {\n  .home-wrapper > section.songs .div-2 {\n    padding-top: 4em;\n  }\n}\n.home-wrapper > section.songs .div-2 .title {\n  font-weight: bold;\n  font-size: 3em;\n  line-height: 1.2;\n  padding-bottom: 0.2em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.songs .div-2 .title {\n    font-size: 2em;\n  }\n}\n.home-wrapper > section.songs .div-2 .subtitle {\n  font-weight: 500;\n  font-size: 1.5em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.songs .div-2 .subtitle {\n    font-size: 1.2em;\n  }\n}\n.home-wrapper > section.songs .img-collection-cntr {\n  position: relative;\n  height: 31em;\n  width: 85%;\n  margin: 0 auto;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.songs .img-collection-cntr {\n    height: 22em;\n    width: 100%;\n  }\n}\n.home-wrapper > section.songs .img-collection-cntr .cntr {\n  -webkit-transition: 0.5s ease-in-out;\n  transition: 0.5s ease-in-out;\n}\n@media (min-width: 576px) {\n  .home-wrapper > section.songs .img-collection-cntr .cntr:hover {\n    -webkit-transform: translate(10%, -5%);\n    -ms-transform: translate(10%, -5%);\n    transform: translate(10%, -5%);\n    z-index: 3;\n  }\n  .home-wrapper > section.songs .img-collection-cntr .cntr:hover .img-fluid {\n    width: 15em;\n  }\n  .home-wrapper > section.songs .img-collection-cntr .cntr:hover .play-icon {\n    opacity: 1;\n  }\n}\n.home-wrapper > section.songs .img-collection-cntr .play-icon {\n  -webkit-transition: 0.5s ease;\n  transition: 0.5s ease;\n  opacity: 0;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  -ms-transform: translate(-50%, -50%);\n  text-align: center;\n}\n.home-wrapper > section.songs .img-collection-cntr .play-icon img {\n  width: 5em;\n}\n.home-wrapper > section.songs .img-collection-cntr img {\n  width: 14em;\n  border-radius: 15px;\n  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);\n  -webkit-transition: 0.5s ease-in-out;\n  transition: 0.5s ease-in-out;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.songs .img-collection-cntr img {\n    width: 10em;\n  }\n}\n.home-wrapper > section.songs .img-collection-cntr .one {\n  position: absolute;\n  bottom: 4em;\n  left: 0%;\n  -webkit-transition: all 0.3 ease;\n  transition: all 0.3 ease;\n}\n.home-wrapper > section.songs .img-collection-cntr .two {\n  position: absolute;\n  top: 0em;\n  left: 5em;\n}\n.home-wrapper > section.songs .img-collection-cntr .three {\n  position: absolute;\n  top: 5em;\n  right: 3em;\n  z-index: 2;\n}\n.home-wrapper > section.songs .img-collection-cntr .four {\n  position: absolute;\n  bottom: 0em;\n  right: 0em;\n}\n.home-wrapper > section.product-platforms {\n  padding-top: 13em;\n  position: relative;\n}\n.home-wrapper > section.product-platforms::after {\n  content: \"\";\n  width: 55%;\n  height: 87em;\n  background-image: url('product_wave.png');\n  background-repeat: no-repeat;\n  background-position: left;\n  background-size: contain;\n  top: -21em;\n  left: 0em;\n  position: absolute;\n  display: inline-block;\n  z-index: -5;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.product-platforms::after {\n    width: 100em;\n    height: 183%;\n    top: -25em;\n    left: -17em;\n  }\n}\n.home-wrapper > section.product-platforms .row {\n  position: relative;\n}\n.home-wrapper > section.product-platforms .platform-text-div {\n  top: 15em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.product-platforms .platform-text-div {\n    top: 0em;\n  }\n}\n.home-wrapper > section.product-platforms .div-1 {\n  padding-top: 5em;\n  z-index: 10;\n  color: white;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.product-platforms .div-1 {\n    padding-top: 0em;\n  }\n}\n.home-wrapper > section.product-platforms .div-1 .title {\n  font-weight: bold;\n  font-size: 3em;\n  line-height: 1em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.product-platforms .div-1 .title {\n    font-size: 2em;\n  }\n}\n.home-wrapper > section.product-platforms .div-1 .description {\n  font-weight: 500;\n  font-size: 1.5em;\n}\n.home-wrapper > section.product-platforms .div-1 .btn {\n  background: transparent;\n  color: white;\n  border: 1px solid white;\n}\n.home-wrapper > section.product-platforms .boxes-container {\n  top: 15em;\n  z-index: 10;\n}\n.home-wrapper > section.product-platforms .boxes-container .one {\n  margin-bottom: 1em;\n  padding-right: 10em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.product-platforms .boxes-container .one {\n    padding-right: 0em;\n  }\n}\n.home-wrapper > section.product-platforms .boxes-container .two {\n  margin-bottom: 1em;\n}\n.home-wrapper > section.product-platforms .boxes-container .box-item {\n  background-color: white;\n  color: black;\n  padding: 1.5em;\n  text-align: center;\n  border-radius: 12px;\n  margin-right: 3em;\n  width: 12em;\n  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.product-platforms .boxes-container .box-item {\n    padding: 1em;\n    width: 7em;\n    margin: 0.5em;\n  }\n}\n.home-wrapper > section.product-platforms .boxes-container .box-item img {\n  width: 100%;\n}\n.home-wrapper > section.product-platforms .boxes-container .box-item p {\n  font-weight: bold;\n  margin-top: 1em;\n  margin-bottom: 0em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.product-platforms .boxes-container .box-item p {\n    margin-top: 1em;\n    font-size: 0.9em;\n  }\n}\n.home-wrapper > section.features {\n  padding-top: 4em;\n}\n.home-wrapper > section.features > .title {\n  text-align: center;\n  font-weight: bold;\n  font-size: 2.3em;\n  margin-bottom: 1em;\n}\n.home-wrapper > section.features .feature {\n  padding: 2em 9em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.features .feature {\n    padding: 0em 1em;\n  }\n}\n.home-wrapper > section.features .feature img {\n  width: 14em;\n}\n.home-wrapper > section.features .feature .info {\n  max-width: 30em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.features .feature .info {\n    text-align: center !important;\n    padding-top: 1em;\n  }\n}\n.home-wrapper > section.features .feature .info h2 {\n  font-weight: bold;\n}\n.home-wrapper > section.features .feature .info p {\n  font-weight: 300;\n}\n@media (min-width: 768px) {\n  .home-wrapper > section.features .feature:nth-child(even) {\n    -webkit-box-orient: horizontal !important;\n    -webkit-box-direction: reverse !important;\n        -ms-flex-direction: row-reverse !important;\n            flex-direction: row-reverse !important;\n  }\n}\n.home-wrapper > section.features .feature:nth-child(even) .info {\n  text-align: right;\n  padding-right: 1em;\n}\n.home-wrapper > section.features .feature:nth-child(odd) .info {\n  text-align: left;\n  padding-left: 1em;\n}\n.home-wrapper > section.latest {\n  padding: 10em 12em 0em 12em;\n  position: relative;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.latest {\n    padding: 10em 2em 0em 2em;\n  }\n}\n.home-wrapper > section.latest .div-2 {\n  color: white;\n}\n@media (min-width: 768px) {\n  .home-wrapper > section.latest .div-2 {\n    top: 9em;\n  }\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.latest .div-2 {\n    text-align: center !important;\n  }\n}\n.home-wrapper > section.latest .div-2 .loading {\n  background-color: #9444c4 !important;\n}\n.home-wrapper > section.latest .div-2 .loading span {\n  background-color: #fff !important;\n}\n.home-wrapper > section.latest .div-2 .switch-section-title .desc {\n  display: none;\n}\n.home-wrapper > section.latest .div-2 .switch-section-title .desc p {\n  font-size: 0.6em;\n  font-weight: 500;\n  padding-right: 4em;\n}\n.home-wrapper > section.latest .div-2 .switch-section-title .active .desc {\n  display: block;\n}\n.home-wrapper > section.latest::after {\n  content: \"\";\n  width: 70%;\n  height: 54vw;\n  background-image: url('product_wave_1.png');\n  background-repeat: no-repeat;\n  background-position: left;\n  background-size: cover;\n  top: 0em;\n  right: 0em;\n  position: absolute;\n  display: inline-block;\n  z-index: -10;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.latest::after {\n    width: 163%;\n    height: 75em;\n  }\n}\n.home-wrapper > section.latest .mixtape-img {\n  text-align: center;\n}\n.home-wrapper > section.latest .mixtape-img img {\n  width: 24em;\n}\n.home-wrapper > section.latest .div-2 {\n  text-align: right;\n}\n.home-wrapper > section.latest .div-2 .title {\n  font-weight: bold;\n  font-size: 2.5em;\n}\n.home-wrapper > section.latest .div-2 .subtitle {\n  font-weight: 500;\n  font-size: 1.5em;\n}\n.home-wrapper > section.plans {\n  padding: 10em 12em 0em 12em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.plans {\n    padding: 0em 1em;\n  }\n}\n.home-wrapper > section.plans > .section-title {\n  text-align: center;\n  font-weight: bold;\n  font-size: 2.5em;\n  padding: 0em 0em 2em 0em;\n  text-transform: uppercase;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.plans > .section-title {\n    padding: 2em 0em 2em 0em;\n  }\n}\n@media (min-width: 768px) {\n  .home-wrapper > section.plans .plans-row {\n    font-size: 0.8vw;\n  }\n}\n.home-wrapper > section.plans .plan {\n  padding: 2em 2em 1em 2em;\n  background-color: white;\n  box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.15);\n  width: 24em;\n  text-align: left;\n  border-radius: 8px;\n  position: relative;\n  overflow: hidden;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.plans .plan {\n    width: 22em;\n  }\n}\n.home-wrapper > section.plans .plan .plan-title h3 {\n  font-weight: bold;\n  color: #000;\n}\n.home-wrapper > section.plans .plan .sale-box {\n  position: absolute;\n  top: 0;\n  height: 106px;\n  width: 10em;\n  text-align: center;\n  z-index: 0;\n  right: 0;\n  border-top-right-radius: 0.7em;\n  -o-border-top-right-radius: 0.7em;\n  -moz-border-top-right-radius: 0.7em;\n  -webkit-border-top-right-radius: 0.7em;\n}\n.home-wrapper > section.plans .plan .sale-box > .on_sale {\n  font-size: 1.1em;\n  background: #32aadc;\n  color: white;\n  text-transform: uppercase;\n  padding: 0.5em 3px;\n  width: 17em;\n  text-align: center;\n  display: block;\n  position: absolute;\n  top: 1em;\n  left: -3em;\n  -webkit-transition: all 0.5s ease;\n  transition: all 0.5s ease;\n  -webkit-transform: rotate(-44deg);\n  -ms-transform: rotate(-44deg);\n  transform: rotate(40deg);\n}\n.home-wrapper > section.plans .plan.popular {\n  width: 30em;\n  padding: 2em 2em 2em 2em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.plans .plan.popular {\n    width: 24em;\n  }\n}\n.home-wrapper > section.plans .plan.popular .features {\n  background-color: white;\n  width: 24em;\n  padding: 2em 1em 1em 1em;\n  border-radius: 8px;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.plans .plan.popular .features {\n    width: 19em;\n  }\n}\n.home-wrapper > section.plans .plan.popular .plan-title {\n  color: white;\n  padding-bottom: 1em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.plans .plan {\n    margin: 0em 3.5em 2em 3.5em;\n  }\n}\n.home-wrapper > section.plans .plan .plan-title {\n  text-transform: uppercase;\n  text-align: center;\n}\n.home-wrapper > section.plans .plan .features {\n  margin: 0 auto;\n}\n.home-wrapper > section.plans .plan .features li {\n  font-size: 1.2em;\n  padding: 0.5em;\n}\n.home-wrapper > section.plans .plan .features li.disabled {\n  opacity: 0.3;\n}\n.home-wrapper > section.plans .btn-container {\n  text-align: center;\n  padding: 2em 0em;\n}\n.home-wrapper > section.gift h1 {\n  font-size: 2em;\n}\n.home-wrapper > section.gift h2 {\n  font-weight: bold;\n  text-transform: uppercase;\n}\n.home-wrapper > section.gift p {\n  font-size: 1.4em;\n}\n.home-wrapper > section.gift .row {\n  padding: 0 5em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.gift .row {\n    padding: 0 2em;\n  }\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.gift img {\n    width: 90%;\n  }\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > section.gift .btn-container {\n    -webkit-box-pack: center !important;\n        -ms-flex-pack: center !important;\n            justify-content: center !important;\n  }\n}\n.home-wrapper > footer {\n  position: relative;\n  padding: 12em 5em 2em 5em;\n}\n@media (max-width: 767.98px) {\n  .home-wrapper > footer {\n    padding: 2em 1em;\n  }\n}\n.home-wrapper > footer .ang-logo {\n  width: 12em;\n  margin-bottom: 1em;\n}\n.home-wrapper > footer .btn {\n  margin: 2em 0em 1em 0em;\n  border: 1px solid black;\n  text-transform: capitalize;\n  background-color: transparent;\n}\n.home-wrapper > footer .store-links-btns img {\n  width: 3.5em;\n  padding-right: 1em;\n}\n.home-wrapper > footer .roadmap .link {\n  padding-top: 1em;\n}\n.home-wrapper > footer .roadmap .link a {\n  color: black;\n  text-decoration: none;\n  text-transform: capitalize;\n  font-weight: 300;\n  padding-top: 1em;\n}\n.home-wrapper > footer .roadmap h3 {\n  text-transform: uppercase;\n  font-size: 1.1em;\n  font-weight: bold;\n}\n.home-wrapper > footer .roadmap.socialize {\n  padding-top: 1.5em;\n}\n.home-wrapper > footer .roadmap.socialize img {\n  width: 2.5em;\n  margin-right: 1em;\n}\n[lang=ar] .home-wrapper .landing-parallax-banner .hero-title h1 {\n  word-spacing: 3.2em;\n  font-size: 8em;\n}\n@media (max-width: 1652px) {\n  [lang=ar] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    word-spacing: 2.2em;\n    font-size: 7.5em;\n    margin-bottom: 0.5em;\n  }\n}\n@media (max-width: 930px) {\n  [lang=ar] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 6em;\n    word-spacing: 1.6em;\n    -webkit-transform: translateX(0.35em) translateY(-0.5em);\n        -ms-transform: translateX(0.35em) translateY(-0.5em);\n            transform: translateX(0.35em) translateY(-0.5em);\n    margin-bottom: 0em;\n  }\n}\n@media (max-width: 750px) {\n  [lang=ar] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    word-spacing: 1.2em;\n    font-size: 5.5em;\n  }\n}\n@media (max-width: 670px) {\n  [lang=ar] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 4.5em;\n  }\n}\n@media (max-width: 575px) {\n  [lang=ar] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 4em;\n  }\n}\n@media (max-width: 480px) {\n  [lang=ar] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 5.5em;\n    word-spacing: 99em;\n    -webkit-transform: translateX(0) translateY(-3em);\n        -ms-transform: translateX(0) translateY(-3em);\n            transform: translateX(0) translateY(-3em);\n  }\n}\n@media (max-width: 410px) {\n  [lang=ar] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    -webkit-transform: translateY(-2em);\n        -ms-transform: translateY(-2em);\n            transform: translateY(-2em);\n  }\n}\n@media (max-width: 340px) {\n  [lang=ar] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    -webkit-transform: translateY(-1em);\n        -ms-transform: translateY(-1em);\n            transform: translateY(-1em);\n    font-size: 3.5rem;\n  }\n}\n[lang=fr] .home-wrapper .landing-parallax-banner .hero-title h1 {\n  -webkit-transform: translateX(0.05em);\n      -ms-transform: translateX(0.05em);\n          transform: translateX(0.05em);\n  word-spacing: 3em;\n  margin-bottom: 1em;\n}\n@media (max-width: 1652px) {\n  [lang=fr] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    word-spacing: 2em;\n    font-size: 7.2em;\n    margin-bottom: 0.5em;\n  }\n}\n@media (max-width: 930px) {\n  [lang=fr] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 6em;\n    word-spacing: 1.6em;\n    -webkit-transform: translateX(0em) translateY(-0.5em);\n        -ms-transform: translateX(0em) translateY(-0.5em);\n            transform: translateX(0em) translateY(-0.5em);\n  }\n}\n@media (max-width: 750px) {\n  [lang=fr] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    word-spacing: 1.2em;\n    font-size: 5.1em;\n  }\n}\n@media (max-width: 670px) {\n  [lang=fr] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 4em;\n  }\n}\n@media (max-width: 480px) {\n  [lang=fr] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    font-size: 5.5em;\n    word-spacing: 99em;\n    -webkit-transform: translateX(0) translateY(-3em);\n        -ms-transform: translateX(0) translateY(-3em);\n            transform: translateX(0) translateY(-3em);\n  }\n}\n@media (max-width: 410px) {\n  [lang=fr] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    -webkit-transform: translateY(-2em);\n        -ms-transform: translateY(-2em);\n            transform: translateY(-2em);\n  }\n}\n@media (max-width: 340px) {\n  [lang=fr] .home-wrapper .landing-parallax-banner .hero-title h1 {\n    -webkit-transform: translateY(-1em);\n        -ms-transform: translateY(-1em);\n            transform: translateY(-1em);\n    font-size: 3.5rem;\n  }\n}\n@media (min-width: 576px) {\n  nav {\n    padding: 0.5rem 4rem;\n  }\n  nav > .navbar-main > .nav-toggle {\n    display: none;\n  }\n}\n@media (max-width: 767.98px) {\n  nav {\n    padding: 0.5rem 1rem;\n  }\n  nav > .navbar-main .menu-links,\nnav > .navbar-main .menu-actions {\n    display: none !important;\n  }\n  nav > .navbar-main > .nav-toggle {\n    display: block;\n  }\n}\n@media screen and (max-width: 992px) {\n  nav {\n    padding: 0.5rem 1rem;\n  }\n}\nhtml:lang(fr) .landing-wrapper > .header-banner > .content > .title {\n  word-spacing: 0;\n}\nhtml:lang(ar) nav .menu-links ul li a {\n  padding-left: 0em;\n  padding-right: 2em;\n}\nhtml:lang(ar) nav .dropdown-menu {\n  text-align: right;\n}\nhtml:lang(ar) nav .dropdown-menu li a {\n  padding-right: 0 !important;\n}\nhtml:lang(ar) nav .navbar-main > .menu-actions .btn {\n  margin-right: 0em;\n  margin-left: 1em;\n}\nhtml:lang(ar) .header-banner .content > div {\n  direction: ltr;\n}\nhtml:lang(ar) .plans .plan .features li {\n  text-align: right !important;\n}\nhtml:lang(ar) .features .feature:nth-child(even) .info {\n  text-align: left;\n  padding-right: 0em;\n  padding-left: 1em;\n}\nhtml:lang(ar) .features .feature:nth-child(odd) .info {\n  text-align: right;\n  padding-right: 1em;\n  padding-left: 0em;\n}\nhtml:lang(ar) .latest::after {\n  left: 0;\n  right: unset;\n  -webkit-transform: scaleX(-1);\n  -ms-transform: scaleX(-1);\n      transform: scaleX(-1);\n}\nhtml:lang(ar) .product-platforms .div-1 {\n  text-align: right !important;\n}\n@media (max-width: 767.98px) {\n  html:lang(ar) .product-platforms .div-1 {\n    text-align: center !important;\n  }\n}\nhtml:lang(ar) .product-platforms .platform-text-div {\n  right: 5em;\n}\n@media (max-width: 767.98px) {\n  html:lang(ar) .product-platforms .platform-text-div {\n    right: unset;\n  }\n}\nhtml:lang(ar) .product-platforms::after {\n  right: 0;\n  left: unset;\n  -webkit-transform: scaleX(-1);\n  -ms-transform: scaleX(-1);\n      transform: scaleX(-1);\n}\nhtml:lang(ar) footer .ang-logo {\n  float: left;\n}\nhtml:lang(ar) footer .store-links-btns {\n  float: left;\n}\nhtml:lang(ar) .landing-wrapper > .sidemenu .content .menu-link .btn {\n  -webkit-box-pack: start !important;\n      -ms-flex-pack: start !important;\n          justify-content: flex-start !important;\n}"

/***/ }),

/***/ "./src/app/modules/landing/home/home.component.ts":
/*!********************************************************!*\
  !*** ./src/app/modules/landing/home/home.component.ts ***!
  \********************************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_landing_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/landing.actions */ "./src/app/core/redux/actions/landing.actions.ts");
/* harmony import */ var _anghami_redux_selectors_landing_selector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/selectors/landing.selector */ "./src/app/core/redux/selectors/landing.selector.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm2015/animations.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/modules/player/actions/player.actions */ "./src/app/core/modules/player/actions/player.actions.ts");
/* harmony import */ var _core_services_landing_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/services/landing.service */ "./src/app/core/services/landing.service.ts");
/* harmony import */ var _aos__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./aos */ "./src/app/modules/landing/home/aos.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
















let HomeComponent = class HomeComponent {
    constructor(render, document, platformId, landingService, locale, store, aos, cookieService, _meta, _utilService) {
        this.render = render;
        this.document = document;
        this.platformId = platformId;
        this.landingService = landingService;
        this.locale = locale;
        this.store = store;
        this.cookieService = cookieService;
        this._meta = _meta;
        this._utilService = _utilService;
        this.env = `${_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].assetsCDN}img/landing/`;
        this.menuToggler = false;
        this.actionsVisible = true;
        this.playerActionsTimeout = 1000;
        this.videoId = 50937;
        this.videoDidInit = false;
        // selectedLanguage;
        this.os = '';
        this.videoPlayedFirstTime = false;
        this.currentPlayerOptions = {
            playing: false,
            shuffle: false,
            repeat: false,
            volume: 100,
            position: 0,
            progress: 0,
            percentage: 0,
            sod: true,
            index: 0,
            video: false,
            buffering: true,
            bufferProgress: 0
        };
        this.switch1 = {
            index: 0,
            width: 0
        };
        this.switch2 = {
            index: 0,
            width: 0,
            img: {
                0: `${this.env}stories-en.png`,
                1: `${this.env}radar-en.png`,
                2: `${this.env}chat-en.png`
            }
        };
        this.isPlatformBrowser = false;
        this.landingData$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_anghami_redux_selectors_landing_selector__WEBPACK_IMPORTED_MODULE_2__["selectLandingDataState"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["skip"])(1));
        this.aos = aos;
    }
    ngOnInit() {
        this.isPlatformBrowser = Object(_angular_common__WEBPACK_IMPORTED_MODULE_5__["isPlatformBrowser"])(this.platformId);
        this.os = this._utilService.getOSName();
        // TODO: unsubscribe
        this.store.dispatch(new _anghami_redux_actions_landing_actions__WEBPACK_IMPORTED_MODULE_1__["GetLandingPage"]());
        this.landingDataSub$ = this.landingData$.subscribe(data => {
            this.landingData = {
                cards: data['cards']['data'][0]['data'],
                plans: data['plans'],
                breakfree: data['breakfree']['data']
            };
        });
        this.initLocalGlobals();
        if (this.isPlatformBrowser) {
            this.aos.init();
        }
    }
    played() {
    }
    setPlyr($event) {
    }
    reportClickToAmplitude() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_15__["LogAmplitudeEvent"]({
            name: 'clickOnLandingCTA',
            props: {
                operatingSystem: this.os
            }
        }));
    }
    detectmob() {
        if (navigator && navigator.userAgent) {
            if (navigator.userAgent.match(/Android/i) ||
                navigator.userAgent.match(/webOS/i) ||
                navigator.userAgent.match(/iPhone/i) ||
                navigator.userAgent.match(/iPad/i) ||
                navigator.userAgent.match(/iPod/i) ||
                navigator.userAgent.match(/BlackBerry/i) ||
                navigator.userAgent.match(/Windows Phone/i)) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
    ngAfterViewInit() {
        this.landingDataSub2$ = this.landingData$.subscribe(data => {
            if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_5__["isPlatformBrowser"])(this.platformId)) {
                this.initSwitch1Timer(this.landingData['breakfree'].length);
                this.initSwitch2Timer(3);
            }
        });
        this.render.listen('window', 'scroll', event => {
            this.setParallaxElements(event);
        });
    }
    initLocalGlobals() {
        if (this.locale === 'ar') {
            this.switch2 = {
                index: 0,
                width: 0,
                img: {
                    0: `${this.env}stories-ar.png`,
                    1: `${this.env}radar-ar.png`,
                    2: `${this.env}chat-ar.png`
                }
            };
        }
    }
    toggleMenu() {
        this.menuToggler = !this.menuToggler;
    }
    onResize(event) {
        if (event.target.innerWidth > 767) {
            this.menuToggler = false;
        }
    }
    setParallaxElements($event) {
        if (!!this.document && !!this.document.scrollingElement && !!this.document.scrollingElement.scrollTop) {
            const wScroll = this.document.scrollingElement.scrollTop;
            this.render.setStyle(this.manParallax.nativeElement, 'transform', `translate(0px, ${wScroll / 30}%)`);
            this.render.setStyle(this.platformText.nativeElement, 'transform', `translate(0px, -${wScroll / 30}%)`);
            this.render.setStyle(this.platformBoxes.nativeElement, 'transform', `translate(0px, -${wScroll / 30}%)`);
        }
    }
    initSwitch1Timer(arrLength) {
        const switchMax = arrLength - 1;
        this.interval1 = setInterval(() => {
            if (this.switch1.width === 100) {
                this.switch1.width = 0;
                if (this.switch1.index === switchMax) {
                    this.switch1.index = 0;
                }
                else {
                    ++this.switch1.index;
                }
            }
            else {
                this.switch1.width = this.switch1.width + 1 / 4;
            }
        }, 10);
    }
    initSwitch2Timer(arrLength) {
        const switchMax = arrLength - 1;
        this.interval2 = setInterval(() => {
            if (this.switch2.width === 100) {
                this.switch2.width = 0;
                if (this.switch2.index === switchMax) {
                    this.switch2.index = 0;
                }
                else {
                    ++this.switch2.index;
                }
            }
            else {
                this.switch2.width = this.switch2.width + 1 / 4;
            }
        }, 10);
    }
    pause() {
        this.store.dispatch(new _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_12__["PlayerAction"]('pause'));
    }
    play() {
        this.store.dispatch(new _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_12__["PlayerAction"]('play', { forcePlay: true }));
    }
    togglePlayerActions() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_5__["isPlatformBrowser"])(this.platformId)) {
            this.actionsVisible = true;
            clearTimeout(this.togglePlayerActionsTimeout);
            this.togglePlayerActionsTimeout = setTimeout(() => {
                this.actionsVisible = false;
            }, this.playerActionsTimeout);
        }
    }
    ngOnDestroy() {
        clearInterval(this.interval1);
        clearInterval(this.interval2);
        if (this.landingDataSub$) {
            this.landingDataSub$.unsubscribe();
        }
        if (this.landingDataSub2$) {
            this.landingDataSub2$.unsubscribe();
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('manParallax', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"])
], HomeComponent.prototype, "manParallax", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('platformText', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"])
], HomeComponent.prototype, "platformText", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('platformBoxes', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"])
], HomeComponent.prototype, "platformBoxes", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('latestTextSection', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"])
], HomeComponent.prototype, "latestTextSection", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["HostListener"])('window:resize', ['$event']),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
], HomeComponent.prototype, "onResize", null);
HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
        selector: 'anghami-landing-home',
        template: __webpack_require__(/*! raw-loader!./home.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/home/home.component.html"),
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewEncapsulation"].None,
        animations: [
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["trigger"])('animateSwitchColl', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["state"])('in', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["style"])({ opacity: 1 })),
                // fade in when created. this could also be written as transition('void => *')
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["transition"])(':enter', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["style"])({ opacity: 0 }), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["animate"])(450)]),
                // fade out when destroyed. this could also be written as transition('void => *')
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["transition"])(':leave', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["animate"])(450, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["style"])({ opacity: 0 })))
            ])
        ],
        styles: [__webpack_require__(/*! ./home.component.scss */ "./src/app/modules/landing/home/home.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_5__["DOCUMENT"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_6__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_6__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](6, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_aos__WEBPACK_IMPORTED_MODULE_14__["AosToken"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_6__["Renderer2"],
        Document,
        Object,
        _core_services_landing_service__WEBPACK_IMPORTED_MODULE_13__["LandingService"], String, _ngrx_store__WEBPACK_IMPORTED_MODULE_8__["Store"], Object, ngx_cookie__WEBPACK_IMPORTED_MODULE_9__["CookieService"],
        _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__["Meta"],
        _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilService"]])
], HomeComponent);



/***/ }),

/***/ "./src/app/modules/landing/home/home.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/modules/landing/home/home.module.ts ***!
  \*****************************************************/
/*! exports provided: HomeModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeModule", function() { return HomeModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _home_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home.component */ "./src/app/modules/landing/home/home.component.ts");
/* harmony import */ var _home_route__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.route */ "./src/app/modules/landing/home/home.route.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_reducers_landing__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/reducers/landing */ "./src/app/core/redux/reducers/landing/index.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _anghami_redux_effects_landing_effects__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/effects/landing.effects */ "./src/app/core/redux/effects/landing.effects.ts");
/* harmony import */ var _aos__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./aos */ "./src/app/modules/landing/home/aos.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/components/button/button.module */ "./src/app/core/components/button/button.module.ts");















let HomeModule = class HomeModule {
};
HomeModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
            _home_route__WEBPACK_IMPORTED_MODULE_6__["HomeRoutingModule"],
            _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_12__["IconModule"],
            ng_lazyload_image__WEBPACK_IMPORTED_MODULE_13__["LazyLoadImageModule"],
            _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_14__["ButtonModule"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["StoreModule"].forFeature('landing', _anghami_redux_reducers_landing__WEBPACK_IMPORTED_MODULE_8__["reducers"]),
            _ngrx_effects__WEBPACK_IMPORTED_MODULE_9__["EffectsModule"].forFeature([_anghami_redux_effects_landing_effects__WEBPACK_IMPORTED_MODULE_10__["LandingEffects"]])
        ],
        declarations: [_home_component__WEBPACK_IMPORTED_MODULE_5__["HomeComponent"]],
        exports: [_home_component__WEBPACK_IMPORTED_MODULE_5__["HomeComponent"]],
        providers: [{ provide: _aos__WEBPACK_IMPORTED_MODULE_11__["AosToken"], useValue: _aos__WEBPACK_IMPORTED_MODULE_11__["aos"] }],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], HomeModule);



/***/ }),

/***/ "./src/app/modules/landing/home/home.route.ts":
/*!****************************************************!*\
  !*** ./src/app/modules/landing/home/home.route.ts ***!
  \****************************************************/
/*! exports provided: routes, HomeRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeRoutingModule", function() { return HomeRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.component */ "./src/app/modules/landing/home/home.component.ts");




const routes = [
    {
        path: '',
        component: _home_component__WEBPACK_IMPORTED_MODULE_3__["HomeComponent"]
    }
];
let HomeRoutingModule = class HomeRoutingModule {
};
HomeRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        providers: []
    })
], HomeRoutingModule);



/***/ })

}]);