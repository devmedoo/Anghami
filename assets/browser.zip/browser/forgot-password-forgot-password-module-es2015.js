(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["forgot-password-forgot-password-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/inner-header/inner-header.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  id=\"headerid\"\n  class=\"header\"\n  [ngStyle]=\"backgroundimage\"\n  [ngClass]=\"{ extra: backgroundHeader.extra, smallerHeader: smallerHeader }\"\n>\n  <img\n    class=\"logo\"\n    *ngIf=\"backgroundHeader.innerLogo\"\n    [src]=\"backgroundHeader.innerLogo\"\n  />\n  <div>\n    <ng-container *ngIf=\"!isapi\">\n      <h1 class=\"title\">{{ backgroundHeader?.title | translateInstant }}</h1>\n      <h5 class=\"subtitle \">\n        {{ backgroundHeader?.subtitle | translateInstant }}\n      </h5>\n    </ng-container>\n    <ng-container *ngIf=\"isapi\">\n      <div class=\"title\">{{ backgroundHeader?.title }}</div>\n      <h5 class=\"subtitle \">{{ backgroundHeader?.subtitle }}</h5>\n    </ng-container>\n  </div>\n  <img\n    *ngIf=\"isWave\"\n    class=\"wave\"\n    src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\"\n  />\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/white-box/white-box.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"wrapper-box\" [ngClass]=\"{'loader': loading, 'notice': notice, 'brand': brand}\">\n  <div class=\"white-box\" [ngClass]=\"{'notice': notice}\">\n    <ng-content></ng-content>\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/forgot-password/forgot-password.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/forgot-password/forgot-password.component.html ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<anghami-inner-header\n  class=\"header\"\n  [backgroundHeader]=\"innerHeader\"\n  [smallerHeader]=\"true\"\n></anghami-inner-header>\n\n<anghami-white-box class=\"pass-white-box\">\n  <div class=\"form-group\">\n    <ng-container *ngIf=\"forgotPassword\">\n      <label i18n=\"@@Reset your password\" class=\"px-1 title\">\n        To reset your password, you'll receive an email on how to create a new\n        password and login to your account.\n      </label>\n      <input\n        [(ngModel)]=\"emailModel\"\n        type=\"email\"\n        ngModel\n        email\n        placeholder=\"Enter your email\"\n        i18n-placeholder=\"@@enter your email\"\n        class=\"form-control\"\n        (keypress)=\"handleKeypress($event)\"\n      />\n    </ng-container>\n    <ng-container *ngIf=\"!forgotPassword\">\n      <input\n        [(ngModel)]=\"pass1Model\"\n        type=\"password\"\n        placeholder=\"Your new password\"\n        i18n-placeholder=\"@@your_new_password\"\n        class=\"form-control pass1-input\"\n        (keypress)=\"handleKeypress($event)\"\n      />\n      <input\n        [(ngModel)]=\"pass2Model\"\n        type=\"password\"\n        placeholder=\"Rewrite your new password\"\n        i18n-placeholder=\"@@rewrite_your_password\"\n        class=\"form-control\"\n        (keypress)=\"handleKeypress($event)\"\n      />\n    </ng-container>\n    <div\n      class=\"ang-primary-colored-btn btn\"\n      id=\"submitid\"\n      (click)=\"forgotPassword ? sendResetEmail() : resetPassword()\"\n    >\n      <ng-container *ngIf=\"!loading\">\n        <span *ngIf=\"forgotPassword\" i18n=\"@@Send Reset Email\">Send Reset Email</span>\n        <span *ngIf=\"!forgotPassword\" i18n=\"@@submit_and_login\">Submit and Login</span>\n      </ng-container>\n      <img\n        class=\"op-loader\"\n        *ngIf=\"loading\"\n        src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/op-loader.gif\"\n      />\n    </div>\n    <div class=\"message-container\">\n      <div class=\"err\" *ngIf=\"message\">{{ message }}</div>\n      <div *ngIf=\"apimessage\">{{ apimessage }}</div>\n    </div>\n  </div>\n</anghami-white-box>\n"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: -webkit-gradient(linear, left top, right top, from(#e03f8d), color-stop(#a22ccf), to(#2fa0df));\n  background: linear-gradient(to right, #e03f8d, #a22ccf, #2fa0df);\n  height: 30em;\n  background-size: cover !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    height: auto;\n    min-height: 15em;\n  }\n}\n:host .header.pringles {\n  background-size: cover !important;\n  background-position: center !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header.extra .title {\n  width: 60%;\n  margin: auto;\n}\n:host .header .logo {\n  max-width: 5em;\n  display: block;\n  margin: 1em auto;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n  }\n}\n:host .header .subtitle {\n  font-size: 1.2rem;\n  margin: auto;\n  font-weight: 200;\n  text-align: center;\n  padding-top: 0.5em;\n}\n@media (max-width: 768px) {\n  :host .header .subtitle {\n    width: 85%;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.ts ***!
  \************************************************************************/
/*! exports provided: InnerHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderComponent", function() { return InnerHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/mobile-detection.service */ "./src/app/core/services/mobile-detection.service.ts");



let InnerHeaderComponent = class InnerHeaderComponent {
    constructor(_mobileDetection, locale) {
        this._mobileDetection = _mobileDetection;
        this.locale = locale;
        this.locale =
            this.locale && this.locale !== null
                ? this.locale.indexOf('en') > -1
                    ? 'en'
                    : this.locale
                : 'en';
    }
    ngOnInit() {
        this._mobileDetection.verticalScreen.subscribe(isVertical => {
            if (this.backgroundHeader.mainimagemobile) {
                const image = isVertical
                    ? this.backgroundHeader.mainimagemobile
                    : this.backgroundHeader.mainimage;
                this.setBackgroundImage(image, this.backgroundHeader.backgroundcolor);
            }
        });
    }
    setBackgroundImage(img, color) {
        const backgroundcolor = color && color !== null && color !== ''
            ? color
            : 'linear-gradient(to right, #E03F8D, #A22CCF, #2FA0DF)';
        this.backgroundimage = Object.assign({}, this.backgroundimage, { background: 'url(' +
                img +
                ') 0% 0%,' + backgroundcolor });
    }
    ngOnChanges() {
        if (this.backgroundHeader && this.backgroundHeader !== null) {
            if (this.backgroundHeader.mainimage) {
                this.backgroundimage = {
                    'background-size': 'cover',
                };
                this.setBackgroundImage(this.backgroundHeader.mainimage);
            }
            if (this.backgroundHeader.type) {
                const headerElt = document.getElementById('headerid');
                if (headerElt && headerElt !== null) {
                    headerElt.classList.add(this.backgroundHeader.type);
                }
            }
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('backgroundHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "backgroundHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('smallerHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "smallerHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "isWave", void 0);
InnerHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-inner-header',
        template: __webpack_require__(/*! raw-loader!./inner-header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html"),
        styles: [__webpack_require__(/*! ./inner-header.component.scss */ "./src/app/core/components/inner-header/inner-header.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__["MobileDetectionService"], String])
], InnerHeaderComponent);



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.module.ts ***!
  \*********************************************************************/
/*! exports provided: InnerHeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderModule", function() { return InnerHeaderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.component */ "./src/app/core/components/inner-header/inner-header.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");





let InnerHeaderModule = class InnerHeaderModule {
};
InnerHeaderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__["PipesModule"]],
        declarations: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        exports: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], InnerHeaderModule);



/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .wrapper-box {\n  display: inline-block;\n  margin: auto;\n  width: 100%;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box {\n    width: 90%;\n  }\n}\n:host .wrapper-box.loader {\n  width: 40% !important;\n}\n:host .wrapper-box.notice {\n  width: unset;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box.notice {\n    width: 90%;\n  }\n}\n:host .wrapper-box.brand .white-box {\n  margin-top: -5.5em !important;\n}\n:host .white-box {\n  margin: auto;\n  min-width: 5em;\n  border: 1px solid #EEEEEE;\n  border-radius: 0.5em;\n  box-shadow: 5px 5px 30px -5px lightgrey;\n  padding: 1.5em;\n  display: block;\n  background-color: white;\n  position: relative;\n  max-width: 55em;\n  margin-top: -8em;\n}\n@media (max-width: 768px) {\n  :host .white-box {\n    margin-top: -3em;\n  }\n}\n:host .white-box.notice {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-top: -5em;\n  padding: 2em;\n}"

/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.ts ***!
  \******************************************************************/
/*! exports provided: WhiteBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxComponent", function() { return WhiteBoxComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let WhiteBoxComponent = class WhiteBoxComponent {
    constructor() { }
    ngOnInit() { }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], WhiteBoxComponent.prototype, "notice", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], WhiteBoxComponent.prototype, "loading", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], WhiteBoxComponent.prototype, "brand", void 0);
WhiteBoxComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-white-box',
        template: __webpack_require__(/*! raw-loader!./white-box.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html"),
        styles: [__webpack_require__(/*! ./white-box.component.scss */ "./src/app/core/components/white-box/white-box.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], WhiteBoxComponent);



/***/ }),

/***/ "./src/app/core/components/white-box/white-box.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.module.ts ***!
  \***************************************************************/
/*! exports provided: WhiteBoxModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxModule", function() { return WhiteBoxModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.component */ "./src/app/core/components/white-box/white-box.component.ts");




let WhiteBoxModule = class WhiteBoxModule {
};
WhiteBoxModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
        declarations: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
        exports: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], WhiteBoxModule);



/***/ }),

/***/ "./src/app/core/redux/actions/reset-password.actions.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/redux/actions/reset-password.actions.ts ***!
  \**************************************************************/
/*! exports provided: ResetPasswordActionsTypes, SendResetEmail, SendResetEmailSuccess, ResetPassword, ResetPasswordSuccess, ResetPasswordError */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordActionsTypes", function() { return ResetPasswordActionsTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SendResetEmail", function() { return SendResetEmail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SendResetEmailSuccess", function() { return SendResetEmailSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPassword", function() { return ResetPassword; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordSuccess", function() { return ResetPasswordSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordError", function() { return ResetPasswordError; });
var ResetPasswordActionsTypes;
(function (ResetPasswordActionsTypes) {
    ResetPasswordActionsTypes["SendResetEmail"] = "[ResetPassword] Send Password Reset Email";
    ResetPasswordActionsTypes["SendResetEmailSuccess"] = "[ResetPassword] Reset Email Sent Successfully";
    ResetPasswordActionsTypes["ResetPassword"] = "[ResetPassword] Reset Password";
    ResetPasswordActionsTypes["ResetPasswordSuccess"] = "[ResetPassword] Password Reset Successful";
    ResetPasswordActionsTypes["ResetPasswordError"] = "[ResetPassword] Password Reset Unsuccessful";
})(ResetPasswordActionsTypes || (ResetPasswordActionsTypes = {}));
class SendResetEmail {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ResetPasswordActionsTypes.SendResetEmail;
    }
}
class SendResetEmailSuccess {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ResetPasswordActionsTypes.SendResetEmailSuccess;
    }
}
class ResetPassword {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ResetPasswordActionsTypes.ResetPassword;
    }
}
class ResetPasswordSuccess {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ResetPasswordActionsTypes.ResetPasswordSuccess;
    }
}
class ResetPasswordError {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ResetPasswordActionsTypes.ResetPasswordError;
    }
}


/***/ }),

/***/ "./src/app/core/redux/effects/reset-password.effects.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/redux/effects/reset-password.effects.ts ***!
  \**************************************************************/
/*! exports provided: ResetPasswordEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordEffects", function() { return ResetPasswordEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_services_reset_password_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/services/reset-password.service */ "./src/app/core/services/reset-password.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../actions/reset-password.actions */ "./src/app/core/redux/actions/reset-password.actions.ts");







let ResetPasswordEffects = class ResetPasswordEffects {
    constructor(actions$, _resetPasswordService) {
        this.actions$ = actions$;
        this._resetPasswordService = _resetPasswordService;
        this.sendResetEmail$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_6__["ResetPasswordActionsTypes"].SendResetEmail), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(action => {
            const payload = action.payload;
            return this._resetPasswordService.sendResetEmail(payload.email).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(data => {
                return new _actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_6__["SendResetEmailSuccess"](data);
            }));
        }));
        this.resetPassword$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_6__["ResetPasswordActionsTypes"].ResetPassword), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(action => {
            const payload = action.payload;
            return this._resetPasswordService
                .resetPassword(payload.password, payload.session)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(data => {
                return new _actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_6__["ResetPasswordSuccess"](data);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(error => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_6__["ResetPasswordError"](error));
            }));
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ResetPasswordEffects.prototype, "sendResetEmail$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ResetPasswordEffects.prototype, "resetPassword$", void 0);
ResetPasswordEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["Actions"],
        _anghami_services_reset_password_service__WEBPACK_IMPORTED_MODULE_1__["ResetPasswordService"]])
], ResetPasswordEffects);



/***/ }),

/***/ "./src/app/core/services/mobile-detection.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/services/mobile-detection.service.ts ***!
  \***********************************************************/
/*! exports provided: MobileDetectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileDetectionService", function() { return MobileDetectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");





let MobileDetectionService = class MobileDetectionService {
    constructor(_cookie, utils) {
        this._cookie = _cookie;
        this.utils = utils;
        this.verticalScreen = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"]();
        if (this.utils.isBrowser()) {
            this.detectVerticalScreen();
            window.addEventListener('resize', () => {
                this.resizeThrottler();
            }, false);
        }
    }
    resizeThrottler() {
        if (this.utils.isBrowser()) {
            if (!this.resizeTimeout) {
                this.resizeTimeout = setTimeout(() => {
                    this.resizeTimeout = null;
                    this.detectVerticalScreen();
                }, 200);
            }
        }
    }
    detectVerticalScreen() {
        this.device = this._cookie.get('device');
        const width = window.innerWidth < 768 ? true : false;
        const ismobile = this.device && (this.device === 'android' || this.device === 'ios')
            ? true
            : false;
        this.verticalScreen.next(width || ismobile ? true : false);
    }
    getVerticalScreen() {
        return this.verticalScreen.asObservable();
    }
};
MobileDetectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_cookie__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
], MobileDetectionService);



/***/ }),

/***/ "./src/app/core/services/reset-password.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/services/reset-password.service.ts ***!
  \*********************************************************/
/*! exports provided: ResetPasswordService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordService", function() { return ResetPasswordService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../enums/enums */ "./src/app/core/enums/enums.ts");









let ResetPasswordService = class ResetPasswordService {
    constructor(http, store) {
        this.http = http;
        this.store = store;
    }
    sendResetEmail(email) {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('type', 'PostForgotPassword')
            .set('email', email)
            .set('output', 'jsonhp');
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["switchMap"])(data => {
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].changeEmail
            }));
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["of"])(data);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(err)));
    }
    resetPassword(password, session) {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('type', 'POSTresetpass')
            .set('session', session)
            .set('pass', password)
            .set('output', 'jsonhp');
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(data.error);
            }
            else {
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].resetPassword
                }));
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(err)));
    }
};
ResetPasswordService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"]])
], ResetPasswordService);



/***/ }),

/***/ "./src/app/modules/landing/forgot-password/forgot-password-routing.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/modules/landing/forgot-password/forgot-password-routing.module.ts ***!
  \***********************************************************************************/
/*! exports provided: routes, ForgotPasswordRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordRoutingModule", function() { return ForgotPasswordRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _forgot_password_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./forgot-password.component */ "./src/app/modules/landing/forgot-password/forgot-password.component.ts");




const routes = [
    {
        path: '',
        component: _forgot_password_component__WEBPACK_IMPORTED_MODULE_3__["ForgotPasswordComponent"]
    }
];
let ForgotPasswordRoutingModule = class ForgotPasswordRoutingModule {
};
ForgotPasswordRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], ForgotPasswordRoutingModule);



/***/ }),

/***/ "./src/app/modules/landing/forgot-password/forgot-password.component.scss":
/*!********************************************************************************!*\
  !*** ./src/app/modules/landing/forgot-password/forgot-password.component.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "html[lang=ar] :host .ang-primary-colored-btn,\nhtml[lang=ar] :host .ang-operator-btn {\n  line-height: 2em;\n  margin-right: 0em;\n  margin-left: 0em;\n}\nhtml[lang=ar] :host .ang-primary-colored-btn:hover,\nhtml[lang=ar] :host .ang-operator-btn:hover {\n  margin-right: 0.6em;\n}\n@media (max-width: 768px) {\n  html[lang=ar] :host .ang-primary-colored-btn,\nhtml[lang=ar] :host .ang-operator-btn {\n    margin-right: 0;\n  }\n}\n.form-group {\n  width: 100%;\n  text-align: center;\n  margin: 0px;\n}\n.pass-white-box {\n  margin-bottom: 11.5em;\n}\n@media (max-width: 575.98px) {\n  .pass-white-box {\n    margin-bottom: 4em;\n  }\n}\n.ang-primary-colored-btn,\n.ang-operator-btn {\n  margin: 0px auto;\n  min-width: 12em;\n}\n.ang-primary-colored-btn.loading,\n.ang-operator-btn.loading {\n  padding: 0.5em 1.2em !important;\n}\n.ang-primary-colored-btn:hover,\n.ang-operator-btn:hover {\n  color: white;\n}\n@media (max-width: 768px) {\n  .ang-primary-colored-btn,\n.ang-operator-btn {\n    margin-left: 0;\n  }\n}\n.btn {\n  -webkit-transition: all 0.2s ease !important;\n  transition: all 0.2s ease !important;\n}\n.px-1 {\n  margin-bottom: 1em;\n}\n.form-control {\n  margin-bottom: 1em;\n  border-radius: 3em;\n}\n.form-control:focus {\n  box-shadow: 0 0 5px 0.1rem rgba(173, 175, 176, 0.25) !important;\n  border-color: transparent;\n}\n.form-control.pass1-input {\n  margin-top: 1.1em;\n}\n.form-control::-webkit-input-placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n.form-control::-moz-placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n.form-control:-ms-input-placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n.form-control::-ms-input-placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n.form-control::placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n.op-loader {\n  max-width: 1.4em !important;\n}\n.err {\n  color: red;\n}\n.message-container {\n  margin-top: 1em;\n}\n.title {\n  font-size: 1.1em;\n}\n::ng-deep .landing-wrapper {\n  background-size: 100% 55%;\n}\n::ng-deep .landing-wrapper {\n  background-size: 100% 55%;\n}\n::ng-deep .white-box {\n  max-width: 45em !important;\n}"

/***/ }),

/***/ "./src/app/modules/landing/forgot-password/forgot-password.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/modules/landing/forgot-password/forgot-password.component.ts ***!
  \******************************************************************************/
/*! exports provided: ForgotPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordComponent", function() { return ForgotPasswordComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/reset-password.actions */ "./src/app/core/redux/actions/reset-password.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");








let ForgotPasswordComponent = class ForgotPasswordComponent {
    constructor(_route, router, store, _actionsSubject, translateService) {
        this._route = _route;
        this.router = router;
        this.store = store;
        this._actionsSubject = _actionsSubject;
        this.translateService = translateService;
        this.innerHeader = {
            isbox: true
        };
        this.EMAIL_REGEXP = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
    }
    ngOnInit() {
        this.session = this._route.snapshot.queryParams.session;
        this.resetMessages();
        if (this.session) {
            this.forgotPassword = false;
            this.innerHeader.title = this.translateService.instant('reset_pass');
        }
        else {
            this.forgotPassword = true;
            this.innerHeader.title = this.translateService.instant('forgot_pass');
        }
    }
    ngOnDestroy() {
        if (this.resetlinkSubscription$) {
            this.resetlinkSubscription$.unsubscribe();
        }
        if (this.resetPasswordSuccessSubscription$) {
            this.resetPasswordSuccessSubscription$.unsubscribe();
        }
        if (this.resetPasswordErrorSubscription$) {
            this.resetPasswordErrorSubscription$.unsubscribe();
        }
    }
    sendResetEmail() {
        this.resetMessages();
        const email = this.emailModel;
        if (!email || email === '') {
            this.message = this.translateService.instant('empty_field');
        }
        else if (!this.EMAIL_REGEXP.test(email)) {
            this.message = this.translateService.instant('valid_email');
        }
        else {
            this.loading = true;
            this.store.dispatch(new _anghami_redux_actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_1__["SendResetEmail"]({ email: email }));
            this.resetlinkSubscription$ = this._actionsSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_anghami_redux_actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_1__["ResetPasswordActionsTypes"].SendResetEmailSuccess))
                .subscribe(action => {
                this.loading = false;
                this.apimessage = action.payload.message;
            });
        }
    }
    resetPassword() {
        this.resetMessages();
        const pass1 = this.pass1Model;
        const pass2 = this.pass2Model;
        if (pass1 === pass2) {
            if (pass1.length > 3) {
                this.loading = true;
                this.store.dispatch(new _anghami_redux_actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_1__["ResetPassword"]({
                    session: this.session,
                    password: pass1
                }));
                this.resetPasswordSuccessSubscription$ = this._actionsSubject
                    .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_anghami_redux_actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_1__["ResetPasswordActionsTypes"].ResetPasswordSuccess))
                    .subscribe(action => {
                    this.loading = false;
                    this.apimessage = action.payload.message;
                    this.router.navigateByUrl('/login');
                });
                this.resetPasswordErrorSubscription$ = this._actionsSubject
                    .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_anghami_redux_actions_reset_password_actions__WEBPACK_IMPORTED_MODULE_1__["ResetPasswordActionsTypes"].ResetPasswordError))
                    .subscribe(action => {
                    this.loading = false;
                    this.apimessage = action.payload.message;
                });
            }
            else if (pass1.length === 0 || pass2.length === 0) {
                this.message = this.translateService.instant('empty_field');
            }
            else {
                this.message = this.translateService.instant('password_short');
            }
        }
        else {
            this.message = this.translateService.instant('passwords_not_matching');
        }
    }
    handleKeypress(event) {
        if (event.keyCode === 13) {
            if (this.forgotPassword) {
                this.sendResetEmail();
            }
            else {
                this.resetPassword();
            }
        }
    }
    resetMessages() {
        this.message = '';
        this.apimessage = '';
    }
};
ForgotPasswordComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'anghami-forgot-password',
        template: __webpack_require__(/*! raw-loader!./forgot-password.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/forgot-password/forgot-password.component.html"),
        styles: [__webpack_require__(/*! ./forgot-password.component.scss */ "./src/app/modules/landing/forgot-password/forgot-password.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["ActionsSubject"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateService"]])
], ForgotPasswordComponent);



/***/ }),

/***/ "./src/app/modules/landing/forgot-password/forgot-password.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/modules/landing/forgot-password/forgot-password.module.ts ***!
  \***************************************************************************/
/*! exports provided: ForgotPasswordModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordModule", function() { return ForgotPasswordModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/footer/footer.module */ "./src/app/core/components/footer/footer.module.ts");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./forgot-password-routing.module */ "./src/app/modules/landing/forgot-password/forgot-password-routing.module.ts");
/* harmony import */ var _forgot_password_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./forgot-password.component */ "./src/app/modules/landing/forgot-password/forgot-password.component.ts");
/* harmony import */ var _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.module */ "./src/app/core/components/inner-header/inner-header.module.ts");
/* harmony import */ var _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.module */ "./src/app/core/components/white-box/white-box.module.ts");
/* harmony import */ var _anghami_services_reset_password_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/reset-password.service */ "./src/app/core/services/reset-password.service.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _anghami_redux_effects_reset_password_effects__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/redux/effects/reset-password.effects */ "./src/app/core/redux/effects/reset-password.effects.ts");














let ForgotPasswordModule = class ForgotPasswordModule {
};
ForgotPasswordModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_7__["ForgotPasswordRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_5__["FooterModule"],
            _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_6__["LoadingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateModule"],
            _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_9__["InnerHeaderModule"],
            _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_10__["WhiteBoxModule"],
            _ngrx_effects__WEBPACK_IMPORTED_MODULE_12__["EffectsModule"].forFeature([
                _anghami_redux_effects_reset_password_effects__WEBPACK_IMPORTED_MODULE_13__["ResetPasswordEffects"],
            ])
        ],
        declarations: [_forgot_password_component__WEBPACK_IMPORTED_MODULE_8__["ForgotPasswordComponent"]],
        providers: [_anghami_services_reset_password_service__WEBPACK_IMPORTED_MODULE_11__["ResetPasswordService"]],
        exports: [_forgot_password_component__WEBPACK_IMPORTED_MODULE_8__["ForgotPasswordComponent"]]
    })
], ForgotPasswordModule);



/***/ })

}]);