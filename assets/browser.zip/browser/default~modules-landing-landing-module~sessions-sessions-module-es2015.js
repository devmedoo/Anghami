(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~modules-landing-landing-module~sessions-sessions-module"],{

/***/ "./node_modules/rxjs/internal/observable/from.js":
/*!*******************************************************!*\
  !*** ./node_modules/rxjs/internal/observable/from.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Observable_1 = __webpack_require__(/*! ../Observable */ "./node_modules/rxjs/internal/Observable.js");
var subscribeTo_1 = __webpack_require__(/*! ../util/subscribeTo */ "./node_modules/rxjs/internal/util/subscribeTo.js");
var scheduled_1 = __webpack_require__(/*! ../scheduled/scheduled */ "./node_modules/rxjs/internal/scheduled/scheduled.js");
function from(input, scheduler) {
    if (!scheduler) {
        if (input instanceof Observable_1.Observable) {
            return input;
        }
        return new Observable_1.Observable(subscribeTo_1.subscribeTo(input));
    }
    else {
        return scheduled_1.scheduled(input, scheduler);
    }
}
exports.from = from;
//# sourceMappingURL=from.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/operators/map.js":
/*!*****************************************************!*\
  !*** ./node_modules/rxjs/internal/operators/map.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Subscriber_1 = __webpack_require__(/*! ../Subscriber */ "./node_modules/rxjs/internal/Subscriber.js");
function map(project, thisArg) {
    return function mapOperation(source) {
        if (typeof project !== 'function') {
            throw new TypeError('argument is not a function. Are you looking for `mapTo()`?');
        }
        return source.lift(new MapOperator(project, thisArg));
    };
}
exports.map = map;
var MapOperator = (function () {
    function MapOperator(project, thisArg) {
        this.project = project;
        this.thisArg = thisArg;
    }
    MapOperator.prototype.call = function (subscriber, source) {
        return source.subscribe(new MapSubscriber(subscriber, this.project, this.thisArg));
    };
    return MapOperator;
}());
exports.MapOperator = MapOperator;
var MapSubscriber = (function (_super) {
    __extends(MapSubscriber, _super);
    function MapSubscriber(destination, project, thisArg) {
        var _this = _super.call(this, destination) || this;
        _this.project = project;
        _this.count = 0;
        _this.thisArg = thisArg || _this;
        return _this;
    }
    MapSubscriber.prototype._next = function (value) {
        var result;
        try {
            result = this.project.call(this.thisArg, value, this.count++);
        }
        catch (err) {
            this.destination.error(err);
            return;
        }
        this.destination.next(result);
    };
    return MapSubscriber;
}(Subscriber_1.Subscriber));
//# sourceMappingURL=map.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/operators/switchMap.js":
/*!***********************************************************!*\
  !*** ./node_modules/rxjs/internal/operators/switchMap.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var OuterSubscriber_1 = __webpack_require__(/*! ../OuterSubscriber */ "./node_modules/rxjs/internal/OuterSubscriber.js");
var InnerSubscriber_1 = __webpack_require__(/*! ../InnerSubscriber */ "./node_modules/rxjs/internal/InnerSubscriber.js");
var subscribeToResult_1 = __webpack_require__(/*! ../util/subscribeToResult */ "./node_modules/rxjs/internal/util/subscribeToResult.js");
var map_1 = __webpack_require__(/*! ./map */ "./node_modules/rxjs/internal/operators/map.js");
var from_1 = __webpack_require__(/*! ../observable/from */ "./node_modules/rxjs/internal/observable/from.js");
function switchMap(project, resultSelector) {
    if (typeof resultSelector === 'function') {
        return function (source) { return source.pipe(switchMap(function (a, i) { return from_1.from(project(a, i)).pipe(map_1.map(function (b, ii) { return resultSelector(a, b, i, ii); })); })); };
    }
    return function (source) { return source.lift(new SwitchMapOperator(project)); };
}
exports.switchMap = switchMap;
var SwitchMapOperator = (function () {
    function SwitchMapOperator(project) {
        this.project = project;
    }
    SwitchMapOperator.prototype.call = function (subscriber, source) {
        return source.subscribe(new SwitchMapSubscriber(subscriber, this.project));
    };
    return SwitchMapOperator;
}());
var SwitchMapSubscriber = (function (_super) {
    __extends(SwitchMapSubscriber, _super);
    function SwitchMapSubscriber(destination, project) {
        var _this = _super.call(this, destination) || this;
        _this.project = project;
        _this.index = 0;
        return _this;
    }
    SwitchMapSubscriber.prototype._next = function (value) {
        var result;
        var index = this.index++;
        try {
            result = this.project(value, index);
        }
        catch (error) {
            this.destination.error(error);
            return;
        }
        this._innerSub(result, value, index);
    };
    SwitchMapSubscriber.prototype._innerSub = function (result, value, index) {
        var innerSubscription = this.innerSubscription;
        if (innerSubscription) {
            innerSubscription.unsubscribe();
        }
        var innerSubscriber = new InnerSubscriber_1.InnerSubscriber(this, undefined, undefined);
        var destination = this.destination;
        destination.add(innerSubscriber);
        this.innerSubscription = subscribeToResult_1.subscribeToResult(this, result, value, index, innerSubscriber);
    };
    SwitchMapSubscriber.prototype._complete = function () {
        var innerSubscription = this.innerSubscription;
        if (!innerSubscription || innerSubscription.closed) {
            _super.prototype._complete.call(this);
        }
        this.unsubscribe();
    };
    SwitchMapSubscriber.prototype._unsubscribe = function () {
        this.innerSubscription = null;
    };
    SwitchMapSubscriber.prototype.notifyComplete = function (innerSub) {
        var destination = this.destination;
        destination.remove(innerSub);
        this.innerSubscription = null;
        if (this.isStopped) {
            _super.prototype._complete.call(this);
        }
    };
    SwitchMapSubscriber.prototype.notifyNext = function (outerValue, innerValue, outerIndex, innerIndex, innerSub) {
        this.destination.next(innerValue);
    };
    return SwitchMapSubscriber;
}(OuterSubscriber_1.OuterSubscriber));
//# sourceMappingURL=switchMap.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/scheduled/scheduleArray.js":
/*!***************************************************************!*\
  !*** ./node_modules/rxjs/internal/scheduled/scheduleArray.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Observable_1 = __webpack_require__(/*! ../Observable */ "./node_modules/rxjs/internal/Observable.js");
var Subscription_1 = __webpack_require__(/*! ../Subscription */ "./node_modules/rxjs/internal/Subscription.js");
function scheduleArray(input, scheduler) {
    return new Observable_1.Observable(function (subscriber) {
        var sub = new Subscription_1.Subscription();
        var i = 0;
        sub.add(scheduler.schedule(function () {
            if (i === input.length) {
                subscriber.complete();
                return;
            }
            subscriber.next(input[i++]);
            if (!subscriber.closed) {
                sub.add(this.schedule());
            }
        }));
        return sub;
    });
}
exports.scheduleArray = scheduleArray;
//# sourceMappingURL=scheduleArray.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/scheduled/scheduleIterable.js":
/*!******************************************************************!*\
  !*** ./node_modules/rxjs/internal/scheduled/scheduleIterable.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Observable_1 = __webpack_require__(/*! ../Observable */ "./node_modules/rxjs/internal/Observable.js");
var Subscription_1 = __webpack_require__(/*! ../Subscription */ "./node_modules/rxjs/internal/Subscription.js");
var iterator_1 = __webpack_require__(/*! ../symbol/iterator */ "./node_modules/rxjs/internal/symbol/iterator.js");
function scheduleIterable(input, scheduler) {
    if (!input) {
        throw new Error('Iterable cannot be null');
    }
    return new Observable_1.Observable(function (subscriber) {
        var sub = new Subscription_1.Subscription();
        var iterator;
        sub.add(function () {
            if (iterator && typeof iterator.return === 'function') {
                iterator.return();
            }
        });
        sub.add(scheduler.schedule(function () {
            iterator = input[iterator_1.iterator]();
            sub.add(scheduler.schedule(function () {
                if (subscriber.closed) {
                    return;
                }
                var value;
                var done;
                try {
                    var result = iterator.next();
                    value = result.value;
                    done = result.done;
                }
                catch (err) {
                    subscriber.error(err);
                    return;
                }
                if (done) {
                    subscriber.complete();
                }
                else {
                    subscriber.next(value);
                    this.schedule();
                }
            }));
        }));
        return sub;
    });
}
exports.scheduleIterable = scheduleIterable;
//# sourceMappingURL=scheduleIterable.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/scheduled/scheduleObservable.js":
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/internal/scheduled/scheduleObservable.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Observable_1 = __webpack_require__(/*! ../Observable */ "./node_modules/rxjs/internal/Observable.js");
var Subscription_1 = __webpack_require__(/*! ../Subscription */ "./node_modules/rxjs/internal/Subscription.js");
var observable_1 = __webpack_require__(/*! ../symbol/observable */ "./node_modules/rxjs/internal/symbol/observable.js");
function scheduleObservable(input, scheduler) {
    return new Observable_1.Observable(function (subscriber) {
        var sub = new Subscription_1.Subscription();
        sub.add(scheduler.schedule(function () {
            var observable = input[observable_1.observable]();
            sub.add(observable.subscribe({
                next: function (value) { sub.add(scheduler.schedule(function () { return subscriber.next(value); })); },
                error: function (err) { sub.add(scheduler.schedule(function () { return subscriber.error(err); })); },
                complete: function () { sub.add(scheduler.schedule(function () { return subscriber.complete(); })); },
            }));
        }));
        return sub;
    });
}
exports.scheduleObservable = scheduleObservable;
//# sourceMappingURL=scheduleObservable.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/scheduled/schedulePromise.js":
/*!*****************************************************************!*\
  !*** ./node_modules/rxjs/internal/scheduled/schedulePromise.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Observable_1 = __webpack_require__(/*! ../Observable */ "./node_modules/rxjs/internal/Observable.js");
var Subscription_1 = __webpack_require__(/*! ../Subscription */ "./node_modules/rxjs/internal/Subscription.js");
function schedulePromise(input, scheduler) {
    return new Observable_1.Observable(function (subscriber) {
        var sub = new Subscription_1.Subscription();
        sub.add(scheduler.schedule(function () { return input.then(function (value) {
            sub.add(scheduler.schedule(function () {
                subscriber.next(value);
                sub.add(scheduler.schedule(function () { return subscriber.complete(); }));
            }));
        }, function (err) {
            sub.add(scheduler.schedule(function () { return subscriber.error(err); }));
        }); }));
        return sub;
    });
}
exports.schedulePromise = schedulePromise;
//# sourceMappingURL=schedulePromise.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/scheduled/scheduled.js":
/*!***********************************************************!*\
  !*** ./node_modules/rxjs/internal/scheduled/scheduled.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var scheduleObservable_1 = __webpack_require__(/*! ./scheduleObservable */ "./node_modules/rxjs/internal/scheduled/scheduleObservable.js");
var schedulePromise_1 = __webpack_require__(/*! ./schedulePromise */ "./node_modules/rxjs/internal/scheduled/schedulePromise.js");
var scheduleArray_1 = __webpack_require__(/*! ./scheduleArray */ "./node_modules/rxjs/internal/scheduled/scheduleArray.js");
var scheduleIterable_1 = __webpack_require__(/*! ./scheduleIterable */ "./node_modules/rxjs/internal/scheduled/scheduleIterable.js");
var isInteropObservable_1 = __webpack_require__(/*! ../util/isInteropObservable */ "./node_modules/rxjs/internal/util/isInteropObservable.js");
var isPromise_1 = __webpack_require__(/*! ../util/isPromise */ "./node_modules/rxjs/internal/util/isPromise.js");
var isArrayLike_1 = __webpack_require__(/*! ../util/isArrayLike */ "./node_modules/rxjs/internal/util/isArrayLike.js");
var isIterable_1 = __webpack_require__(/*! ../util/isIterable */ "./node_modules/rxjs/internal/util/isIterable.js");
function scheduled(input, scheduler) {
    if (input != null) {
        if (isInteropObservable_1.isInteropObservable(input)) {
            return scheduleObservable_1.scheduleObservable(input, scheduler);
        }
        else if (isPromise_1.isPromise(input)) {
            return schedulePromise_1.schedulePromise(input, scheduler);
        }
        else if (isArrayLike_1.isArrayLike(input)) {
            return scheduleArray_1.scheduleArray(input, scheduler);
        }
        else if (isIterable_1.isIterable(input) || typeof input === 'string') {
            return scheduleIterable_1.scheduleIterable(input, scheduler);
        }
    }
    throw new TypeError((input !== null && typeof input || input) + ' is not observable');
}
exports.scheduled = scheduled;
//# sourceMappingURL=scheduled.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/isInteropObservable.js":
/*!****************************************************************!*\
  !*** ./node_modules/rxjs/internal/util/isInteropObservable.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var observable_1 = __webpack_require__(/*! ../symbol/observable */ "./node_modules/rxjs/internal/symbol/observable.js");
function isInteropObservable(input) {
    return input && typeof input[observable_1.observable] === 'function';
}
exports.isInteropObservable = isInteropObservable;
//# sourceMappingURL=isInteropObservable.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/isIterable.js":
/*!*******************************************************!*\
  !*** ./node_modules/rxjs/internal/util/isIterable.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var iterator_1 = __webpack_require__(/*! ../symbol/iterator */ "./node_modules/rxjs/internal/symbol/iterator.js");
function isIterable(input) {
    return input && typeof input[iterator_1.iterator] === 'function';
}
exports.isIterable = isIterable;
//# sourceMappingURL=isIterable.js.map

/***/ }),

/***/ "./src/app/core/redux/actions/external-pages.actions.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/redux/actions/external-pages.actions.ts ***!
  \**************************************************************/
/*! exports provided: ExternalPagesActionTypes, SubscribeCampaign, SubmitAdvertisePage, getWebPurchaseOptions, getWebPurchaseOptionsSuccess, submitStudentsOfferData, submitStudentsOfferDataSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExternalPagesActionTypes", function() { return ExternalPagesActionTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscribeCampaign", function() { return SubscribeCampaign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubmitAdvertisePage", function() { return SubmitAdvertisePage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWebPurchaseOptions", function() { return getWebPurchaseOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWebPurchaseOptionsSuccess", function() { return getWebPurchaseOptionsSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitStudentsOfferData", function() { return submitStudentsOfferData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitStudentsOfferDataSuccess", function() { return submitStudentsOfferDataSuccess; });
/*
 * Created Date: Thursday September 6th 2018
 * Author: Siraj Tahra
 * Email: siraj.tahra@anghami.com
 * -----
 * Copyright (c) 2018 Anghami
 */
var ExternalPagesActionTypes;
(function (ExternalPagesActionTypes) {
    ExternalPagesActionTypes["SubscribeCampaign"] = "[Auth] Subscribe Campaign";
    ExternalPagesActionTypes["SubmitAdvertisePage"] = "[Auth] Submit Advertise Page";
    ExternalPagesActionTypes["getWebPurchaseOptions"] = "[Landing] Get Web Purchase Options";
    ExternalPagesActionTypes["getWebPurchaseOptionsSuccess"] = "[Landing] Get Web Purchase Options Success";
    ExternalPagesActionTypes["submitStudentsOfferData"] = "[Landing] Submit Students Offer Data";
    ExternalPagesActionTypes["submitStudentsOfferDataSuccess"] = "[Landing] Submit Students Offer Success";
})(ExternalPagesActionTypes || (ExternalPagesActionTypes = {}));
class SubscribeCampaign {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ExternalPagesActionTypes.SubscribeCampaign;
    }
}
class SubmitAdvertisePage {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ExternalPagesActionTypes.SubmitAdvertisePage;
    }
}
class getWebPurchaseOptions {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ExternalPagesActionTypes.getWebPurchaseOptions;
    }
}
class getWebPurchaseOptionsSuccess {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ExternalPagesActionTypes.getWebPurchaseOptionsSuccess;
    }
}
class submitStudentsOfferData {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ExternalPagesActionTypes.submitStudentsOfferData;
    }
}
class submitStudentsOfferDataSuccess {
    constructor(payload = null) {
        this.payload = payload;
        this.type = ExternalPagesActionTypes.submitStudentsOfferDataSuccess;
    }
}


/***/ }),

/***/ "./src/app/core/redux/effects/external-pages.effects.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/redux/effects/external-pages.effects.ts ***!
  \**************************************************************/
/*! exports provided: ExternalPagesEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExternalPagesEffects", function() { return ExternalPagesEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _services_landing_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/landing.service */ "./src/app/core/services/landing.service.ts");
/* harmony import */ var _actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../actions/external-pages.actions */ "./src/app/core/redux/actions/external-pages.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _anghami_services_advertise_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/services/advertise.service */ "./src/app/core/services/advertise.service.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var rxjs_internal_operators_switchMap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/internal/operators/switchMap */ "./node_modules/rxjs/internal/operators/switchMap.js");
/* harmony import */ var rxjs_internal_operators_switchMap__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(rxjs_internal_operators_switchMap__WEBPACK_IMPORTED_MODULE_12__);













let ExternalPagesEffects = class ExternalPagesEffects {
    constructor(actions$, store$, advertiseService, landingService) {
        this.actions$ = actions$;
        this.store$ = store$;
        this.advertiseService = advertiseService;
        this.landingService = landingService;
        this.subscribeCampaign$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_8__["ExternalPagesActionTypes"].SubscribeCampaign), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["exhaustMap"])(params => this.advertiseService.subscribeCampaign(params).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["exhaustMap"])(data => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_6__["AmplitudeEvents"].subscribeAnghamiSessionsCampaign,
                props: {
                    campaign: params.campaign,
                    fullname: params.name,
                    msidn: params.msidn,
                    extravalue: params.extravalue,
                    email: params.email
                }
            }), new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_11__["OpenDialog"](data));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(data => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_11__["OpenDialog"](data));
        }))));
        this.submitAdvertisePage$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_8__["ExternalPagesActionTypes"].SubmitAdvertisePage), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["exhaustMap"])(params => this.advertiseService.submitAdvertisePage(params).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["exhaustMap"])(data => {
            if (typeof data.onSuccess === 'function') {
                data.onSuccess();
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_11__["OpenDialog"](data));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(data => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_11__["OpenDialog"](data));
        }))));
        this.getWebPurchaseOptions$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_8__["ExternalPagesActionTypes"].getWebPurchaseOptions), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_internal_operators_switchMap__WEBPACK_IMPORTED_MODULE_12__["switchMap"])(params => {
            return this.landingService.getWebPurchaseOptions(params).pipe(Object(rxjs_internal_operators_switchMap__WEBPACK_IMPORTED_MODULE_12__["switchMap"])(data => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_8__["getWebPurchaseOptionsSuccess"](data));
            }));
        }));
        this.submitStudentsOfferData$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_8__["ExternalPagesActionTypes"].submitStudentsOfferData), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_internal_operators_switchMap__WEBPACK_IMPORTED_MODULE_12__["switchMap"])(params => {
            return this.landingService.postStudentsOfferProfileUpdates(params).pipe(Object(rxjs_internal_operators_switchMap__WEBPACK_IMPORTED_MODULE_12__["switchMap"])(data => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_8__["submitStudentsOfferDataSuccess"](data));
            }));
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ExternalPagesEffects.prototype, "subscribeCampaign$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ExternalPagesEffects.prototype, "submitAdvertisePage$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ExternalPagesEffects.prototype, "getWebPurchaseOptions$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ExternalPagesEffects.prototype, "submitStudentsOfferData$", void 0);
ExternalPagesEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_9__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
        _anghami_services_advertise_service__WEBPACK_IMPORTED_MODULE_10__["AdvertiseService"],
        _services_landing_service__WEBPACK_IMPORTED_MODULE_7__["LandingService"]])
], ExternalPagesEffects);



/***/ }),

/***/ "./src/app/core/services/advertise.service.ts":
/*!****************************************************!*\
  !*** ./src/app/core/services/advertise.service.ts ***!
  \****************************************************/
/*! exports provided: AdvertiseService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdvertiseService", function() { return AdvertiseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _anghami_services_custom_encoder__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/custom-encoder */ "./src/app/core/services/custom-encoder.ts");







let AdvertiseService = class AdvertiseService {
    constructor(http) {
        this.http = http;
    }
    getAdvertisePage() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('type', 'GETbrandpage');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["empty"])();
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(err)));
    }
    subscribeCampaign(params) {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]({ encoder: new _anghami_services_custom_encoder__WEBPACK_IMPORTED_MODULE_6__["CustomEncoder"]() })
            .set('type', 'POSTsubscribecampaign')
            .set('campaign', params.campaign)
            .set('fullname', params.name)
            .set('msidn', params.msidn)
            .set('extravalue', params.extravalue)
            .set('email', params.email);
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["exhaustMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])({
                    title: data.error.message || 'An error has occured. Please try again!',
                    displaymode: 'toast'
                });
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["of"])(Object.assign({}, data, { title: params.extravalue === null
                        ? `Maybe you'll attend the next one :)`
                        : 'Thank you for submitting the form!', displaymode: 'toast' }));
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(err)));
    }
    submitAdvertisePage(params) {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]({ encoder: new _anghami_services_custom_encoder__WEBPACK_IMPORTED_MODULE_6__["CustomEncoder"]() })
            .set('type', 'GETbrandpage')
            .set('firstname', params.firstName)
            .set('lastname', params.lastName)
            .set('email', params.email)
            .set('company', params.company)
            .set('country', params.country)
            .set('phone', params.phone);
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["exhaustMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])({
                    title: data.error.message || 'An error has occured. Please try again!',
                    displaymode: 'toast'
                });
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["of"])(Object.assign({}, data, { title: data.message || 'Thank you for submitting the form!', displaymode: 'toast', onSuccess: params.onSuccess }));
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(err)));
    }
};
AdvertiseService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({ providedIn: 'root' }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], AdvertiseService);



/***/ }),

/***/ "./src/app/core/services/custom-encoder.ts":
/*!*************************************************!*\
  !*** ./src/app/core/services/custom-encoder.ts ***!
  \*************************************************/
/*! exports provided: CustomEncoder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomEncoder", function() { return CustomEncoder; });
class CustomEncoder {
    encodeKey(key) {
        return encodeURIComponent(key);
    }
    encodeValue(value) {
        return encodeURIComponent(value);
    }
    decodeKey(key) {
        return decodeURIComponent(key);
    }
    decodeValue(value) {
        return decodeURIComponent(value);
    }
}


/***/ }),

/***/ "./src/app/core/services/landing.service.ts":
/*!**************************************************!*\
  !*** ./src/app/core/services/landing.service.ts ***!
  \**************************************************/
/*! exports provided: LandingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingService", function() { return LandingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../core/enums/enums */ "./src/app/core/enums/enums.ts");









let LandingService = class LandingService {
    constructor(http, store, locale) {
        this.http = http;
        this.store = store;
        this.locale = locale;
    }
    getLandingPage() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('timestamp', date.toString())
            .set('type', 'GETLandingpagev2');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["timeout"])(3000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    getTeamMembers() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETTeam');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    getPress() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETPress');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                const newdata = data.sections[0].data.map(item => {
                    return Object.assign({}, item, { excerpt: item.excerpt.substring(0, 150) + '...' });
                });
                data.sections[0].data = newdata;
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    getSesssionsInfo() {
        const date = new Date().getTime();
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETongroundeventinfo')
            .set('event_name', 'anghamisessions');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    }
    SubmitSessionInfo(info) {
        const date = new Date().getTime();
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'POSTongroundeventattender.view');
        for (const key in info) {
            if (info.hasOwnProperty(key)) {
                body = body.set(key, info[key]);
            }
        }
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        });
    }
    getWebPurchaseOptions(params) {
        const date = new Date().getTime();
        let appSidFromUrl = this.getQueryFromUrl('appsid') || this.getQueryFromUrl('sid');
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETwebpurchaseoptions')
            .set('studentsoffer', '1');
        if (appSidFromUrl) {
            body = body.set("sid", appSidFromUrl);
        }
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err);
        }));
    }
    getQueryFromUrl(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split('&');
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split('=');
            if (decodeURIComponent(pair[0]) == variable) {
                return decodeURIComponent(pair[1]);
            }
        }
        return null;
    }
    postStudentsOfferProfileUpdates(params) {
        const date = new Date().getTime();
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        let successevent;
        let failevent;
        let appSidFromUrl = this.getQueryFromUrl('appsid') || this.getQueryFromUrl('sid');
        if (appSidFromUrl) {
            body = body.set('sid', appSidFromUrl);
        }
        if (params.email) {
            body = body.set('type', 'POSTaddemail').set('email', params.email);
            successevent = _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].studentOfferEmailSuccess;
            failevent = _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].studentOfferEmailFail;
        }
        else if (params.birthdate) {
            successevent = 'studentOfferEmailSuccess';
            failevent = 'studentOfferEmailFail';
            body = body
                .set('type', 'UPDATEprofile')
                .set('birthdate', params.birthdate);
        }
        else if (params.card_number && params.cardholder_name) {
            successevent = 'studentOfferISICSuccess';
            failevent = 'studentOfferISICFail';
            body = body
                .set('type', 'POSTisicmembership')
                .set('card_number', params.card_number)
                .set('cardholder_name', params.cardholder_name);
        }
        else {
            return;
        }
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: failevent,
                    props: {
                        details: data
                    }
                }));
            }
            else {
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: successevent,
                    props: {
                        details: data
                    }
                }));
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => {
            this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                name: failevent,
                props: {
                    details: err
                }
            }));
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err);
        }));
    }
    validateEmailToken(params) {
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        if (params && params !== null) {
            body = body.set('type', 'POSTvalidatemailtoken');
            for (const key of Object.keys(params)) {
                body = body.set(key, params[key]);
            }
        }
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
};
LandingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"], String])
], LandingService);



/***/ })

}]);