(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["explore-explore-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/placeholders/explore-placeholders/explore-placeholders.component.html":
/*!*********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/placeholders/explore-placeholders/explore-placeholders.component.html ***!
  \*********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n\n<div class=\"placeholder-title short shine m-1\"></div>\n\n<div class=\"d-flex\">\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n\n</div>\n\n\n<div class=\"placeholder-title short shine m-1\"></div>\n\n<div class=\"d-flex\">\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n\n</div>\n\n\n<div class=\"placeholder-title short shine m-1\"></div>\n\n<div class=\"d-flex\">\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n\n</div>\n\n\n\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/explore/explore.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/explore/explore.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"sectionsHaveCarousel\">\n  <div class=\"ang-main\" *ngIf=\"!carouselInitialized\">\n    <div class=\"container-fluid\">\n      <div class=\"page-title\">\n        <h1 i18n=\"@@home\">\n          Home\n        </h1>\n      </div>\n      <anghami-explore-placeholders></anghami-explore-placeholders>\n    </div>\n  </div>\n</ng-container>\n<ng-container *ngIf=\"!sectionsHaveCarousel\">\n  <div class=\"ang-main\" *ngIf=\"!sectionMeta && !error\">\n    <div class=\"container-fluid\">\n      <div class=\"page-title\">\n        <h1 i18n=\"@@home\">\n          Home\n        </h1>\n      </div>\n      <anghami-explore-placeholders></anghami-explore-placeholders>\n    </div>\n  </div>\n</ng-container>\n<div\n  class=\"ang-main\"\n  infiniteScroll\n  [infiniteScrollDistance]=\"1\"\n  [infiniteScrollThrottle]=\"50\"\n  (scrolled)=\"loadMoreExploreSections()\"\n>\n  <div class=\"container-fluid\">\n    <div class=\"page-title\">\n      <h1 i18n=\"@@home\">\n        Home\n      </h1>\n      <ng-container *ngIf=\"sectionMeta && sectionMeta.languageselector\">\n        <anghami-music-language-selector\n          [languageSelectorOptions]=\"sectionMeta.languageselector\"\n        ></anghami-music-language-selector>\n      </ng-container>\n    </div>\n    <anghami-new-section-builder\n      #sectionBuilder\n      [sections]=\"sections\"\n      [collectionMeta]=\"sectionMeta\"\n      (carouselInitialized)=\"setCarouselInitializationState($event)\"\n    >\n    </anghami-new-section-builder>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/core/components/placeholders/explore-placeholders/explore-placeholders.component.ts":
/*!*****************************************************************************************************!*\
  !*** ./src/app/core/components/placeholders/explore-placeholders/explore-placeholders.component.ts ***!
  \*****************************************************************************************************/
/*! exports provided: ExplorePlaceholdersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExplorePlaceholdersComponent", function() { return ExplorePlaceholdersComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ExplorePlaceholdersComponent = class ExplorePlaceholdersComponent {
    constructor() { }
    ngOnInit() {
    }
};
ExplorePlaceholdersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-explore-placeholders',
        template: __webpack_require__(/*! raw-loader!./explore-placeholders.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/placeholders/explore-placeholders/explore-placeholders.component.html"),
        styles: [__webpack_require__(/*! ../placeholders.scss */ "./src/app/core/components/placeholders/placeholders.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], ExplorePlaceholdersComponent);



/***/ }),

/***/ "./src/app/core/redux/effects/explore.effects.ts":
/*!*******************************************************!*\
  !*** ./src/app/core/redux/effects/explore.effects.ts ***!
  \*******************************************************/
/*! exports provided: ExploreEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreEffects", function() { return ExploreEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _services_explore_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/explore.service */ "./src/app/core/services/explore.service.ts");
/* harmony import */ var _actions_collection_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../actions/error-handling.actions */ "./src/app/core/redux/actions/error-handling.actions.ts");
/* harmony import */ var _actions_explore_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../actions/explore.actions */ "./src/app/core/redux/actions/explore.actions.ts");












let ExploreEffects = class ExploreEffects {
    /**
     * takes section data and converts cover art into an actual url image
     */
    constructor(actions$, exploreService, sectionService, store) {
        this.actions$ = actions$;
        this.exploreService = exploreService;
        this.sectionService = sectionService;
        this.store = store;
        this.getHomePageNew$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_actions_explore_actions__WEBPACK_IMPORTED_MODULE_11__["ExploreActionTypes"].GetHomePageNew), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["withLatestFrom"])(this.store.select(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_1__["getUser"])), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["exhaustMap"])(([action, userdata]) => {
            return this.exploreService.getHomePage().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(response => {
                const sectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"](response, []);
                const filtered = this.sectionService.filterSections(response, {
                    type: ['placeholder', 'story'],
                    group: [
                        'editorial',
                        'requests_preview',
                        'uservideos',
                        'uservideos_old'
                    ]
                });
                const carouselSections = filtered.response && filtered.response !== null
                    ? filtered.response.sections.filter(section => section.displaytype === 'card_carousel')
                    : [];
                carouselSections.forEach(section => {
                    section.data.forEach(elt => {
                        if (elt.deeplink) {
                            elt.hasOverlay =
                                elt.deeplink.toLowerCase().trim() !== 'anghami://got' && elt.deeplink.toLowerCase().trim().indexOf('profile') === -1;
                        }
                    });
                });
                response = Object.assign({}, filtered.response);
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_collection_actions__WEBPACK_IMPORTED_MODULE_9__["GetCollectionSuccessNew"]({
                    sections: this.sectionService.enhanceSections(response),
                    sectionMeta: sectionMeta,
                    sectionType: 'explore'
                }), new _actions_explore_actions__WEBPACK_IMPORTED_MODULE_11__["GetHomePageSuccess"]({}));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_10__["ErrorWithRedirect"](err));
            }));
        }));
        this.getPaginatedHomePage$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_actions_explore_actions__WEBPACK_IMPORTED_MODULE_11__["ExploreActionTypes"].GetPaginatedHomePage), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["withLatestFrom"])(this.store.select(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_1__["getUser"])), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["exhaustMap"])(([action, userdata]) => {
            const musiclang = userdata ? userdata.musiclanguage : 0;
            return this.exploreService
                .getHomePage(musiclang, action.payload.page)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(response => {
                const { sections } = response, sectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"](response, ["sections"]);
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["from"])([
                    // new GetPaginatedCollectionSuccess({
                    //   sections: this.sectionService.enhanceSections(response)
                    // }),
                    new _actions_collection_actions__WEBPACK_IMPORTED_MODULE_9__["SetCollectionMeta"](sectionMeta)
                ]);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_10__["ErrorWithRedirect"](err));
            }));
        }));
        this.getPaginatedHomePageNew$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_actions_explore_actions__WEBPACK_IMPORTED_MODULE_11__["ExploreActionTypes"].GetPaginatedHomePageNew), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["withLatestFrom"])(this.store.select(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_1__["getUser"])), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["exhaustMap"])(([action, userdata]) => {
            const musiclang = userdata ? userdata.musiclanguage : 0;
            return this.exploreService
                .getHomePage(musiclang, action.payload.page)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(response => {
                const { sections } = response, sectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"](response, ["sections"]);
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_collection_actions__WEBPACK_IMPORTED_MODULE_9__["GetCollectionSuccessNew"]({
                    sections: this.sectionService.enhanceSections(response),
                    sectionMeta: sectionMeta,
                    sectionType: 'explore',
                    paginated: true
                }));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(err => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_10__["ErrorWithRedirect"](err));
            }));
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ExploreEffects.prototype, "getHomePageNew$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ExploreEffects.prototype, "getPaginatedHomePage$", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ExploreEffects.prototype, "getPaginatedHomePageNew$", void 0);
ExploreEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["Actions"],
        _services_explore_service__WEBPACK_IMPORTED_MODULE_8__["ExploreService"],
        _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_2__["SectionService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"]])
], ExploreEffects);



/***/ }),

/***/ "./src/app/core/services/explore.service.ts":
/*!**************************************************!*\
  !*** ./src/app/core/services/explore.service.ts ***!
  \**************************************************/
/*! exports provided: ExploreService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreService", function() { return ExploreService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");

/*
 * Created Date: Tuesday October 16th 2018
 * Author: Siraj Tahra
 * Email: siraj.tahra@anghami.com
 * -----
 * Copyright (c) 2018 Anghami
 */






let ExploreService = class ExploreService {
    constructor(http, _cookieService, locale) {
        this.http = http;
        this._cookieService = _cookieService;
        this.locale = locale;
    }
    getHomePage(musiclang, page = '0') {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GEThomepage').set('page', page);
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                this._cookieService.put('ghpts', Date.now().toString());
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
};
ExploreService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
        ngx_cookie__WEBPACK_IMPORTED_MODULE_6__["CookieService"], String])
], ExploreService);



/***/ }),

/***/ "./src/app/modules/base/explore/explore-routing.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/modules/base/explore/explore-routing.module.ts ***!
  \****************************************************************/
/*! exports provided: ExploreRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreRoutingModule", function() { return ExploreRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _explore_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./explore.component */ "./src/app/modules/base/explore/explore.component.ts");
/* harmony import */ var _explore_resolver__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./explore.resolver */ "./src/app/modules/base/explore/explore.resolver.ts");





const routes = [
    {
        path: '',
        component: _explore_component__WEBPACK_IMPORTED_MODULE_3__["ExploreComponent"],
        resolve: { viewData: _explore_resolver__WEBPACK_IMPORTED_MODULE_4__["ExploreResolver"] }
    }
];
let ExploreRoutingModule = class ExploreRoutingModule {
};
ExploreRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        providers: [_explore_resolver__WEBPACK_IMPORTED_MODULE_4__["ExploreResolver"]],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], ExploreRoutingModule);



/***/ }),

/***/ "./src/app/modules/base/explore/explore.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/modules/base/explore/explore.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .page-title {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  margin: 0.7em 0 0.7em 0em;\n}\n:host .page-title h1 {\n  font-size: 2.2rem;\n}\n:host .page-title anghami-music-language-selector {\n  margin: 0.41em 0em 0 1.4em;\n}\n:host .page-title:lang(ar) anghami-music-language-selector {\n  margin: 0.41em 2.4em 0 0em;\n}"

/***/ }),

/***/ "./src/app/modules/base/explore/explore.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/modules/base/explore/explore.component.ts ***!
  \***********************************************************/
/*! exports provided: ExploreComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreComponent", function() { return ExploreComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.component */ "./src/app/core/components/new-section-builder/new-section-builder.component.ts");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");







let ExploreComponent = class ExploreComponent {
    constructor(store, _actionsSubject, changeDetectorRef) {
        this.store = store;
        this._actionsSubject = _actionsSubject;
        this.changeDetectorRef = changeDetectorRef;
        this.currentClass = 'ang-view';
        this.sections = [];
        this.error = false;
        this.carouselInitialized = false;
        this.actionSubjectSub$ = this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_5__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_4__["CollectionActionTypes"].GetCollectionSuccessNew))
            .subscribe(res => {
            if (res.payload.sectionType === 'explore') {
                if (res.payload.paginated) {
                    this.sections = this.sections.concat(res.payload.sections);
                }
                else {
                    this.sections = res.payload.sections;
                }
                this.sectionMeta = res.payload.sectionMeta;
                this.sectionsHaveCarousel = this.checkIfSectionsHaveCarousel(this.sections);
                this.changeDetectorRef.detectChanges();
            }
        });
    }
    loadMoreExploreSections() {
        this.sectionBuilder.loadMoreExploreSections();
    }
    setCarouselInitializationState(e) {
        this.carouselInitialized = true;
    }
    checkIfSectionsHaveCarousel(sections) {
        for (var i = 0; i < sections.length; i++) {
            if (sections[i].displaytype === 'carousel' || sections[i].displaytype === 'carousel') {
                return true;
            }
        }
        return false;
    }
    ngOnDestroy() {
        if (this.actionSubjectSub$) {
            this.actionSubjectSub$.unsubscribe();
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('sectionBuilder', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _core_components_new_section_builder_new_section_builder_component__WEBPACK_IMPORTED_MODULE_3__["NewSectionBuilderComponent"])
], ExploreComponent.prototype, "sectionBuilder", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ExploreComponent.prototype, "currentClass", void 0);
ExploreComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-explore',
        template: __webpack_require__(/*! raw-loader!./explore.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/explore/explore.component.html"),
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
        styles: [__webpack_require__(/*! ./explore.component.scss */ "./src/app/modules/base/explore/explore.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"], _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]])
], ExploreComponent);



/***/ }),

/***/ "./src/app/modules/base/explore/explore.module.ts":
/*!********************************************************!*\
  !*** ./src/app/modules/base/explore/explore.module.ts ***!
  \********************************************************/
/*! exports provided: ExploreModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreModule", function() { return ExploreModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var ngx_infinite_scroll__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-infinite-scroll */ "./node_modules/ngx-infinite-scroll/modules/ngx-infinite-scroll.js");
/* harmony import */ var _explore_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./explore-routing.module */ "./src/app/modules/base/explore/explore-routing.module.ts");
/* harmony import */ var _explore_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./explore.component */ "./src/app/modules/base/explore/explore.component.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");
/* harmony import */ var _core_components_music_language_selector_music_language_selector_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/music-language-selector/music-language-selector.module */ "./src/app/core/components/music-language-selector/music-language-selector.module.ts");
/* harmony import */ var _core_components_placeholders_explore_placeholders_explore_placeholders_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/components/placeholders/explore-placeholders/explore-placeholders.component */ "./src/app/core/components/placeholders/explore-placeholders/explore-placeholders.component.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _anghami_redux_effects_explore_effects__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/effects/explore.effects */ "./src/app/core/redux/effects/explore.effects.ts");
/* harmony import */ var _anghami_services_explore_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/explore.service */ "./src/app/core/services/explore.service.ts");












let ExploreModule = class ExploreModule {
};
ExploreModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _explore_routing_module__WEBPACK_IMPORTED_MODULE_4__["ExploreRoutingModule"],
            _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_6__["NewSectionBuilderModule"],
            ngx_infinite_scroll__WEBPACK_IMPORTED_MODULE_3__["InfiniteScrollModule"],
            _core_components_music_language_selector_music_language_selector_module__WEBPACK_IMPORTED_MODULE_7__["MusicLanguageSelectorModule"],
            _ngrx_effects__WEBPACK_IMPORTED_MODULE_9__["EffectsModule"].forFeature([
                _anghami_redux_effects_explore_effects__WEBPACK_IMPORTED_MODULE_10__["ExploreEffects"],
            ])
        ],
        providers: [_anghami_services_explore_service__WEBPACK_IMPORTED_MODULE_11__["ExploreService"]],
        declarations: [_explore_component__WEBPACK_IMPORTED_MODULE_5__["ExploreComponent"], _core_components_placeholders_explore_placeholders_explore_placeholders_component__WEBPACK_IMPORTED_MODULE_8__["ExplorePlaceholdersComponent"]],
        exports: [_explore_component__WEBPACK_IMPORTED_MODULE_5__["ExploreComponent"]]
    })
], ExploreModule);



/***/ }),

/***/ "./src/app/modules/base/explore/explore.resolver.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/base/explore/explore.resolver.ts ***!
  \**********************************************************/
/*! exports provided: ExploreResolver */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreResolver", function() { return ExploreResolver; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _anghami_redux_actions_explore_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/explore.actions */ "./src/app/core/redux/actions/explore.actions.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");






let ExploreResolver = class ExploreResolver {
    constructor(store, platformId) {
        this.store = store;
        this.platformId = platformId;
    }
    resolve(route) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_5__["isPlatformServer"])(this.platformId)) {
            // this.initViewData();
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["empty"])();
        }
        else {
            this.initViewData();
            return this.waitForViewDataToLoad();
        }
    }
    // TODO: handle if collectionType is the same or havnt changed
    waitForViewDataToLoad() {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])();
    }
    initViewData() {
        setTimeout(() => {
            this.store.dispatch(new _anghami_redux_actions_explore_actions__WEBPACK_IMPORTED_MODULE_3__["GetHomePageNew"]());
        });
    }
};
ExploreResolver = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["Store"],
        Object])
], ExploreResolver);



/***/ })

}]);