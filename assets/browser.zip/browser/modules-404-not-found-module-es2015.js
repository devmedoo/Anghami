(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modules-404-not-found-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/404/not-found.component.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/404/not-found.component.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"full-row-layout\">\n  <div class=\"container\">\n    <div class=\"row flippable\">\n      <div class=\"col-md-8 secondary\">\n        <div class=\"img-container\">\n          <img\n            class=\"disk\"\n            src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/404/disk-404.png\"\n          />\n        </div>\n      </div>\n      <div class=\"col-md-4 primary d-flex align-items-center\">\n        <div class=\"onsided-title\">\n          <img\n            class=\"my-5 logo\"\n            src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/anghami-official-white@2x.png\"\n          />\n          <h1 i18n=\"@@404_title\">DON'T WORRY ABOUT A THING</h1>\n          <p i18n=\"@@404_subtitle\">Cause every little thing gonna be all right</p>\n          <form (ngSubmit)=\"search(term)\">\n            <div class=\"search-bar\">\n              <input\n                type=\"text\"\n                name=\"searchTerm\"\n                placeholder=\"Search for something else\"\n                i18n-placeholder=\"@@Search for something else\"\n                [(ngModel)]=\"term\"\n              />\n              <img\n                class=\"search-img img-fluid h-100\"\n                src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/404/Search-button.png\"\n                alt=\"Search\"\n                (click)=\"search(term)\"\n              />\n            </div>\n          </form>\n          <p class=\"my-2\">\n          <a i18n=\"@@Gotohomepage\" [routerLink]=\"'/home'\">Go to homepage</a>\n          </p>\n        </div>\n      </div>\n    </div>\n  </div>\n</section>\n"

/***/ }),

/***/ "./src/app/modules/404/not-found.component.scss":
/*!******************************************************!*\
  !*** ./src/app/modules/404/not-found.component.scss ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  min-height: 100vh;\n  overflow: hidden;\n  display: block;\n  width: 100%;\n}\n:host .full-row-layout {\n  background: -webkit-gradient(linear, left top, left bottom, from(#48BCAD), to(#99F4E8));\n  background: linear-gradient(#48BCAD, #99F4E8);\n  /* Center and scale the image nicely */\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  overflow: hidden;\n  color: white;\n  height: 100vh;\n  width: 100%;\n}\n:host .full-row-layout .container {\n  padding: 0 !important;\n  margin: 0 !important;\n  max-width: 100%;\n  height: 100%;\n  position: relative;\n}\n:host .full-row-layout .row {\n  -webkit-box-flex: nowrap !important;\n      -ms-flex: nowrap !important;\n          flex: nowrap !important;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  height: 100%;\n  width: 95%;\n}\n:host .full-row-layout .onsided-title {\n  text-align: right;\n  width: 100%;\n}\n:host .full-row-layout .onsided-title p {\n  font-size: 1.2em;\n  font-weight: 600;\n}\n:host .full-row-layout .onsided-title p.my-2 {\n  font-weight: normal;\n}\n:host .full-row-layout .onsided-title p.my-2 a {\n  cursor: pointer;\n  text-decoration: underline;\n  color: white !important;\n}\n:host .full-row-layout .onsided-title p.my-2 a:hover {\n  color: white;\n}\n.logo {\n  max-width: 15em;\n}\n.disk {\n  max-width: 55em;\n  -webkit-transform: translate(-35%, 35%);\n      -ms-transform: translate(-35%, 35%);\n          transform: translate(-35%, 35%);\n}\n@media (max-width: 768px) {\n  .disk {\n    -webkit-transform: translate(-50%, 50%);\n        -ms-transform: translate(-50%, 50%);\n            transform: translate(-50%, 50%);\n  }\n}\n@media (max-width: 768px) {\n  .secondary {\n    height: 0;\n  }\n}\n@media (max-width: 768px) {\n  .primary {\n    height: 100%;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n  }\n}\n.error-message {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: end !important;\n      -ms-flex-align: end !important;\n          align-items: flex-end !important;\n}\n.error-message h1 {\n  font-weight: bold;\n  font-size: 4rem;\n}\n.error-message p {\n  font-size: 1.1rem;\n}\n.search-bar {\n  position: relative;\n}\n.search-bar .search-img {\n  position: absolute;\n  right: 0;\n  padding: 0.3rem 0.5rem;\n  cursor: pointer;\n}\n.search-bar input {\n  background: transparent;\n  border: 1px solid white;\n  border-radius: 2rem;\n  padding: 1rem 1rem;\n  color: white;\n  width: 100%;\n}\n.search-bar input::-webkit-input-placeholder {\n  color: rgba(255, 255, 255, 0.8);\n}\n.search-bar input::-moz-placeholder {\n  color: rgba(255, 255, 255, 0.8);\n}\n.search-bar input:-ms-input-placeholder {\n  color: rgba(255, 255, 255, 0.8);\n}\n.search-bar input::-ms-input-placeholder {\n  color: rgba(255, 255, 255, 0.8);\n}\n.search-bar input::placeholder {\n  color: rgba(255, 255, 255, 0.8);\n}\n@media (max-width: 768px) {\n  .search-bar input {\n    width: 80%;\n  }\n}"

/***/ }),

/***/ "./src/app/modules/404/not-found.component.ts":
/*!****************************************************!*\
  !*** ./src/app/modules/404/not-found.component.ts ***!
  \****************************************************/
/*! exports provided: NotFoundComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotFoundComponent", function() { return NotFoundComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");




let NotFoundComponent = class NotFoundComponent {
    constructor(router, platformId, injector) {
        this.router = router;
        this.platformId = platformId;
        this.injector = injector;
        if (!Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            const response = this.injector.get('RESPONSE');
            response.status(404);
        }
    }
    ngOnInit() {
        this.term = '';
    }
    search(term) {
        term = encodeURIComponent(term);
        if (Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["isDevMode"])()) {
            this.router.navigate(['search', term]);
        }
        else {
            window.location.href = 'https://play.anghami.com/search/' + term;
        }
    }
};
NotFoundComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-not-found',
        template: __webpack_require__(/*! raw-loader!./not-found.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/404/not-found.component.html"),
        styles: [__webpack_require__(/*! ./not-found.component.scss */ "./src/app/modules/404/not-found.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        Object,
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injector"]])
], NotFoundComponent);



/***/ }),

/***/ "./src/app/modules/404/not-found.module.ts":
/*!*************************************************!*\
  !*** ./src/app/modules/404/not-found.module.ts ***!
  \*************************************************/
/*! exports provided: NotFoundModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotFoundModule", function() { return NotFoundModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _not_found_route__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./not-found.route */ "./src/app/modules/404/not-found.route.ts");
/* harmony import */ var _not_found_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./not-found.component */ "./src/app/modules/404/not-found.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");







let NotFoundModule = class NotFoundModule {
};
NotFoundModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"],
            _not_found_route__WEBPACK_IMPORTED_MODULE_4__["NotFoundRoutingModule"]
        ],
        declarations: [_not_found_component__WEBPACK_IMPORTED_MODULE_5__["NotFoundComponent"]],
        exports: [_not_found_component__WEBPACK_IMPORTED_MODULE_5__["NotFoundComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], NotFoundModule);



/***/ }),

/***/ "./src/app/modules/404/not-found.route.ts":
/*!************************************************!*\
  !*** ./src/app/modules/404/not-found.route.ts ***!
  \************************************************/
/*! exports provided: routes, NotFoundRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotFoundRoutingModule", function() { return NotFoundRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _not_found_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./not-found.component */ "./src/app/modules/404/not-found.component.ts");




const routes = [
    {
        path: '',
        component: _not_found_component__WEBPACK_IMPORTED_MODULE_3__["NotFoundComponent"]
    }
];
let NotFoundRoutingModule = class NotFoundRoutingModule {
};
NotFoundRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        providers: []
    })
], NotFoundRoutingModule);



/***/ })

}]);