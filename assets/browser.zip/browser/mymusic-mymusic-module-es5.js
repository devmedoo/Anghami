(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mymusic-mymusic-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/link/link.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/link/link.component.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"flex flex-row tool\" *ngIf=\"!data?.isHidden\" [routerLink]=\"data?.deeplink\">\n  <anghami-icon class=\"icon\" [data]=\"data?.image || data?.icon\"></anghami-icon>\n  <span class=\"name\">{{ data.title }}</span>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/profile-header/profile-header.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/profile-header/profile-header.component.html ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-header flex flex-col align-start\" *ngIf=\"userDtls as user\">\n  <div class=\"flex flex-row\">\n    <div class=\"profile-img\">\n      <img\n        [src]=\"user.picture\"\n        onError=\"this.src='https://anghamiwebcdn.akamaized.net/assets/img/userholder.jpg'\"\n      />\n      <div class=\"plus\" *ngIf=\"user.plantype == 3\">PLUS</div>\n    </div>\n    <div class=\"profile-info flex flex-col align-start\">\n      <div class=\"flex flex-row\">\n        <div class=\"name\">\n          <a\n            *ngIf=\"profileType === 'mymusic'\"\n            [routerLink]=\"'/profile/' + user.anid\"\n          >\n            <ng-container *ngIf=\"user.fullname && user.fullname !== ''\"\n              >{{ user.fullname }}\n            </ng-container>\n            <ng-container\n              *ngIf=\"\n                (!user.fullname || user.fullname === '') &&\n                user.email &&\n                user.email !== ''\n              \"\n              >{{ user.email.split('@')[0] }}</ng-container\n            >\n          </a>\n          <ng-container *ngIf=\"profileType === 'profile'\"\n            >{{ user.fullname }}\n          </ng-container>\n        </div>\n        <div\n          class=\"action-button edit\"\n          [routerLink]=\"'/editprofile'\"\n          *ngIf=\"false\"\n        >\n          <span i18n=\"@@Edit Profile\">Edit Profile</span>\n        </div>\n        <div\n          class=\"action-button edit upload\"\n          (click)=\"uploadMusic()\"\n          [class.gray-scale-disabled]=\"uploadBatchExists || matchingMusic\"\n        >\n          <span\n            i18n=\"@@upload_music\"\n            *ngIf=\"!uploadBatchExists && !matchingMusic\"\n            >Upload your music</span\n          >\n          <span\n            i18n=\"@@progress_title\"\n            *ngIf=\"uploadBatchExists || matchingMusic\"\n            >Upload in progress</span\n          >\n        </div>\n        <!-- TODO add edit profile component and change route name -->\n      </div>\n      <div class=\"id\">#{{ user.anid }}</div>\n\n      <div\n        class=\"section-details flex\"\n        *ngIf=\"(userProfile$ | async) as userProfile\"\n      >\n        <span\n          class=\"vertical-line flex flwrs\"\n          (click)=\"displayUsersModal('Followers')\"\n          *ngIf=\"userProfile.numFollowers > 0\"\n        >\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ userProfile.numFollowers | formatNumbers }}\n            </div>\n            {{ userProfile.numFollowers | i18nPlural: followerMapping }}\n          </div>\n        </span>\n        <span\n          class=\"vertical-line flex flwrs\"\n          (click)=\"displayUsersModal('Following')\"\n          *ngIf=\"userProfile.numfollowing > 0 && userProfile.numfollowing\"\n        >\n          <div>\n            <div class=\"font-weight-bold value\">\n              {{ userProfile.numfollowing | formatNumbers }}\n            </div>\n            {{ userProfile.numfollowing | i18nPlural: followingMapping }}\n          </div>\n        </span>\n      </div>\n    </div>\n  </div>\n  <ng-container *ngIf=\"profileType == 'mymusic'\">\n    <ng-container *ngIf=\"(libraryInfo$ | async)?.headerLinks.type == 'link'\">\n      <div class=\"flex flex-row icons\">\n        <anghami-link\n          [data]=\"item\"\n          *ngFor=\"let item of (libraryInfo$ | async)?.headerLinks.data\"\n        ></anghami-link>\n      </div>\n    </ng-container>\n  </ng-container>\n</div>\n<hr />\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/mymusic/mymusic.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/mymusic/mymusic.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main\">\n    \n  <anghami-profile-header [profileType]=\"'mymusic'\"></anghami-profile-header>\n  <div class=\"playlists\" *ngIf=\"(playlists$ | async) as playlistsSection\">\n    <div class=\"flex flex-row between header align-start\">\n      <h2 class=\"playlists-span\"><span i18n=\"@@Playlists\">Playlists</span></h2>\n      <!-- TODO: pending design/product decision *ngIf=\"playlistsSection.data?.length !== 0\" -->\n      <div class=\"flex flex-row align-start\">\n        <div class=\"flex flex-col align-end create\">\n          <div class=\"anghami-primary-btn md-btn\" (click)=\"createPlaylist()\">\n            <span>+ </span>\n            <span i18n=\"@@Create Playlist\">Create Playlist</span>\n          </div>\n        </div>\n      </div>\n    </div>\n    <anghami-new-section-builder\n      [sections]=\"[playlistsSection]\"\n    ></anghami-new-section-builder>\n    <div\n      class=\"d-flex align-items-center illustration\"\n      *ngIf=\"playlistsSection.data?.length === 0\"\n    >\n      <p i18n=\"@@start_playlist_journey\">\n        Start your journey by creating your own playlists with songs you like\n        the most\n      </p>\n      <img [src]=\"env + 'mymusic/create-playlist.png'\" />\n    </div>\n    <div class=\"section-moredataloader\">\n      <button\n        class=\"anghami-default-btn more\"\n        *ngIf=\"playlistsSection.data?.length >= 4\"\n        [routerLink]=\"['/mymusic/playlists']\"\n        i18n=\"@@more\"\n      >\n        More\n      </button>\n    </div>\n  </div>\n  <div class=\"margin2\">\n    <anghami-new-section-builder\n      [sections]=\"(libraryInfo$ | async)?.sections\"\n      [type]=\"'library'\"\n    ></anghami-new-section-builder>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/core/components/link/link.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/core/components/link/link.component.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".tool {\n  margin-right: 1em;\n  cursor: pointer;\n}\n.tool ::ng-deep .icon {\n  border: 1px solid black;\n  padding: 0.7em;\n  border-radius: 50%;\n}\n.tool ::ng-deep .icon svg {\n  width: 1.2em !important;\n  height: 1.2em !important;\n}\n.tool .name {\n  padding: 0 1em;\n}\n.flex {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.flex.flex-col {\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n.flex.flex-row {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n}\n.flex.flex-center {\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n.flex.around {\n  -ms-flex-pack: distribute;\n      justify-content: space-around;\n}\n.flex.start {\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -ms-flex-line-pack: start;\n      align-content: flex-start;\n}\n.flex.between {\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n.flex.align-start {\n  -webkit-box-align: start !important;\n      -ms-flex-align: start !important;\n          align-items: flex-start !important;\n}\n.flex.align-end {\n  -webkit-box-align: end !important;\n      -ms-flex-align: end !important;\n          align-items: flex-end !important;\n}"

/***/ }),

/***/ "./src/app/core/components/link/link.component.ts":
/*!********************************************************!*\
  !*** ./src/app/core/components/link/link.component.ts ***!
  \********************************************************/
/*! exports provided: LinkComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LinkComponent", function() { return LinkComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var LinkComponent = /** @class */ (function () {
    function LinkComponent() {
    }
    LinkComponent.prototype.ngOnInit = function () {
        if (this.data && this.data != null) {
            if (this.data.deeplink &&
                (this.data.deeplink.indexOf('profile') > -1 ||
                    this.data.deeplink.indexOf('playlist') > -1)) {
                this.data = Object.assign({ isHidden: true }, this.data);
            }
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('data'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], LinkComponent.prototype, "data", void 0);
    LinkComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-link',
            template: __webpack_require__(/*! raw-loader!./link.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/link/link.component.html"),
            styles: [__webpack_require__(/*! ./link.component.scss */ "./src/app/core/components/link/link.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LinkComponent);
    return LinkComponent;
}());



/***/ }),

/***/ "./src/app/core/components/profile-header/profile-header.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/core/components/profile-header/profile-header.component.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ::ng-deep .icon {\n  border-color: var(--text-color) !important;\n}\n\n.profile-img {\n  max-width: 9em;\n  width: 100%;\n  position: relative;\n}\n\n.profile-img img {\n  max-width: 9em;\n  border-radius: 5em;\n}\n\n.profile-info {\n  margin: auto 2em;\n  line-height: 2.2em;\n}\n\n.profile-info .name {\n  font-size: 2em;\n  font-weight: 600;\n  margin-right: 0.5em;\n}\n\n.profile-info .name a {\n  color: var(--text-color);\n}\n\n.profile-info .name a:hover {\n  text-decoration: none;\n}\n\n.profile-info .id {\n  color: #969696;\n}\n\n.profile-info .followers {\n  color: #5c5c5c;\n}\n\n.profile-info .followers .number {\n  font-weight: 600;\n}\n\n.plus {\n  background: #e13f8c;\n  background: -webkit-gradient(linear, left top, right top, from(#e13f8c), color-stop(46%, #9d2ad5), to(#517bdd));\n  background: linear-gradient(to right, #e13f8c 0%, #9d2ad5 46%, #517bdd 100%);\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: -0.5em;\n  margin: auto;\n  width: 3.5em;\n  height: 1.5em;\n  border-radius: 3em;\n  color: #ffffff;\n  font-weight: 500;\n  text-align: center;\n  vertical-align: middle;\n  border: 1px solid var(--app-background);\n  line-height: 1.5em;\n  font-size: 1.1em;\n}\n\n.icons {\n  margin-left: 11em;\n}\n\n.icons .tool {\n  margin-right: 1em;\n  cursor: pointer;\n}\n\n.icons .tool .icon {\n  font-size: 1.3em;\n  border: 1px solid var(--text-color);\n  padding: 0.5em;\n  border-radius: 2em;\n}\n\n.icons .tool .name {\n  padding: 0 1em;\n}\n\n.content-header {\n  margin: 2em;\n}\n\n.action-button.edit {\n  border: 1px solid var(--text-color);\n  padding: 0 1.2em;\n  margin: auto 0.5em;\n  white-space: nowrap;\n}\n\n.action-button.upload {\n  margin: auto 0.3em !important;\n  max-width: 25em;\n}\n\nhtml[lang=ar] :host .icons {\n  margin-left: 0em;\n  margin-right: 11em;\n}\n\n.section-details {\n  color: var(--grey-text-color);\n}\n\n.flwrs {\n  cursor: pointer;\n  line-height: 1.5em;\n}\n\n.value {\n  font-size: 1.07em;\n  line-height: 1em;\n  color: var(--text-color);\n}\n\n.vertical-line::before {\n  content: \"\";\n  width: 1px;\n  height: 2em;\n  margin: 1em;\n  background: var(--grey-text-color);\n  opacity: 0.25;\n}\n\n.vertical-line:first-child:before {\n  content: \"\";\n  width: 0;\n  height: 0;\n  margin: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/profile-header/profile-header.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/core/components/profile-header/profile-header.component.ts ***!
  \****************************************************************************/
/*! exports provided: ProfileHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfileHeaderComponent", function() { return ProfileHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/user.actions */ "./src/app/core/redux/actions/user.actions.ts");
/* harmony import */ var _anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/selectors/desktop-client.selectors */ "./src/app/core/redux/selectors/desktop-client.selectors.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../app/core/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _app_core_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../app/core/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");














var ProfileHeaderComponent = /** @class */ (function () {
    function ProfileHeaderComponent(_store, router, locale) {
        var _this = this;
        this._store = _store;
        this.router = router;
        this.locale = locale;
        this.isDesktopApp = !!window['desktopClient'];
        this.uploadBatchExists = false;
        this.matchingMusic = false;
        this.followerMapping = {
            '=0': 'No followers',
            '=1': 'Follower',
            other: 'Followers'
        };
        this.followingMapping = {
            '=0': 'No following',
            '=1': 'Following',
            other: 'Following'
        };
        this.libraryInfo$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_app_core_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_10__["getLibraryInfoState"]));
        this.initMappingLocale();
        if (this.isDesktopApp) {
            this.uploadBatchSubscription = this._store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_5__["getUploadBatch"]))
                .subscribe(function (response) {
                if (response && response.id) {
                    _this.uploadBatchExists = true;
                }
                else {
                    _this.uploadBatchExists = false;
                }
            });
            this.matchMusicStatusSubscription = this._store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_5__["getMatchMusicStatus"]))
                .subscribe(function (response) {
                _this.matchingMusic = response;
            });
        }
        this.userDtlsSubsctiption$ = this._store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__["getUser"]))
            .subscribe(function (res) {
            _this.userDtls = res;
        });
        this.followersList$ = this._store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__["getFollowers"]))
            .subscribe(function (data) {
            if (_this.modalType &&
                typeof data !== 'undefined' &&
                data !== null &&
                Object.keys(data).length > 0) {
                _this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_3__["OpenUsersModal"]({
                    type: _this.modalType,
                    section: data
                }));
                _this.modalType = null;
            }
        });
    }
    ProfileHeaderComponent.prototype.ngOnInit = function () {
        this.getUserProfile();
    };
    ProfileHeaderComponent.prototype.getUserProfile = function () {
        this._store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_1__["GetUserProfile"]());
        this.userProfile$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["select"])(_app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__["getUserProfile"]));
    };
    ProfileHeaderComponent.prototype.uploadMusic = function () {
        if (this.isDesktopApp) {
            if (!this.uploadBatchExists) {
                if (this.matchingMusic) {
                }
                else {
                    this._store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_2__["MatchMusicOpenDialog"]());
                }
            }
            else {
                this.router.navigateByUrl('/upload-music');
            }
        }
        else {
            this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_3__["OpenCustomDialog"]({ type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_11__["DIALOG_TYPES"].DESKTOP_IMPORT_DOWNLOAD }));
        }
    };
    ProfileHeaderComponent.prototype.ngOnDestroy = function () {
        if (this.uploadBatchSubscription) {
            this.uploadBatchSubscription.unsubscribe();
        }
        if (this.matchMusicStatusSubscription) {
            this.matchMusicStatusSubscription.unsubscribe();
        }
        if (this.followersList$) {
            this.followersList$.unsubscribe();
        }
        if (this.userDtlsSubsctiption$) {
            this.userDtlsSubsctiption$.unsubscribe();
        }
    };
    ProfileHeaderComponent.prototype.displayUsersModal = function (type) {
        this._store.dispatch(new _anghami_redux_actions_user_actions__WEBPACK_IMPORTED_MODULE_4__["GetFollowers"]({
            id: this.userDtls.anid,
            followersType: this.handleRequestType(type),
            page: '0'
        }));
    };
    // Handles determining the corresponding api call parameter
    // since they use the same api call
    ProfileHeaderComponent.prototype.handleRequestType = function (type) {
        this.modalType = type;
        if (type == 'Followers') {
            return 'profile';
        }
        else if (type == 'Following') {
            return 'friends';
        }
    };
    ProfileHeaderComponent.prototype.initMappingLocale = function () {
        if (this.locale === 'ar') {
            this.followerMapping = {
                '=0': 'No followers',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_12__["HeaderCollectionInfoAR"].FOLLOWER,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_12__["HeaderCollectionInfoAR"].FOLLOWERS
            };
            this.followingMapping = {
                '=0': 'No followers',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_12__["HeaderCollectionInfoAR"].FOLLOWING,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_12__["HeaderCollectionInfoAR"].FOLLOWING
            };
        }
        else if (this.locale === 'fr') {
            this.followerMapping = {
                '=0': 'No followers',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_12__["HeaderCollectionInfoFR"].FOLLOWER,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_12__["HeaderCollectionInfoFR"].FOLLOWERS
            };
            this.followingMapping = {
                '=0': 'No followers',
                '=1': _enums_enums__WEBPACK_IMPORTED_MODULE_12__["HeaderCollectionInfoFR"].FOLLOWING,
                other: _enums_enums__WEBPACK_IMPORTED_MODULE_12__["HeaderCollectionInfoFR"].FOLLOWING
            };
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ProfileHeaderComponent.prototype, "profileType", void 0);
    ProfileHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
            selector: 'anghami-profile-header',
            template: __webpack_require__(/*! raw-loader!./profile-header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/profile-header/profile-header.component.html"),
            styles: [__webpack_require__(/*! ./profile-header.component.scss */ "./src/app/core/components/profile-header/profile-header.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_6__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_8__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"], String])
    ], ProfileHeaderComponent);
    return ProfileHeaderComponent;
}());



/***/ }),

/***/ "./src/app/core/redux/effects/mymusic.effects.ts":
/*!*******************************************************!*\
  !*** ./src/app/core/redux/effects/mymusic.effects.ts ***!
  \*******************************************************/
/*! exports provided: MymusicEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MymusicEffects", function() { return MymusicEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../actions/error-handling.actions */ "./src/app/core/redux/actions/error-handling.actions.ts");
/* harmony import */ var _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/actions/mymusic.actions */ "./src/app/core/redux/actions/mymusic.actions.ts");
/* harmony import */ var _anghami_services_mymusic_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/services/mymusic.service */ "./src/app/core/services/mymusic.service.ts");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../enums/special-playlist-names.enum */ "./src/app/core/enums/special-playlist-names.enum.ts");














var MymusicEffects = /** @class */ (function () {
    function MymusicEffects(actions$, _utils, _store, coverartservice, sectionService, locale, _mymusicService) {
        var _this = this;
        this.actions$ = actions$;
        this._utils = _utils;
        this._store = _store;
        this.coverartservice = coverartservice;
        this.sectionService = sectionService;
        this.locale = locale;
        this._mymusicService = _mymusicService;
        this.SetLibraryPlaylistCollection$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["MymusicActionTypes"].SetLibraryPlaylistCollection), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (action) { return action.payload; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (type) {
            var routeToSelectorMapping = {
                likes: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_10__["getLikedSongsState"],
                downloads: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_10__["getDownloadsState"],
                albums: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_10__["getLikedAlbumsState"],
                playlists: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_10__["getFollowedPlaylistsState"],
                artists: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_10__["getFollowedArtistsState"]
            };
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["combineLatest"])(_this._store.select(routeToSelectorMapping[type]), _this._store.select(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_10__["getLikedSongsState"])).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (_a) {
                var data = _a[0], likes = _a[1];
                if (data && data != null) {
                    // && Object.keys(data).length > 0
                    var routeToActionMapping_1 = {
                        likes: _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["SetLikedSongsCollectionSuccess"],
                        downloads: _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["SetDownloadsCollectionSuccess"],
                        albums: _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["SetLikedAlbumsCollectionSuccess"],
                        playlists: _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["SetFollowedPlaylistsCollectionSuccess"],
                        artists: _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["SetFollowedArtistsCollectionSuccess"]
                    };
                    if (type === 'albums') {
                        var observable = void 0;
                        if (data.length > 0) {
                            var coverArts = data.map(function (obj) {
                                return _this.coverartservice.getCoverArtImage(obj.coverArt, 600);
                            });
                            observable = _this.coverartservice.createCoverArtFromImages(coverArts);
                        }
                        else {
                            observable = Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])('https://anghamiwebcdn.akamaized.net/assets/img/albumholder_large.jpg');
                        }
                        var newsections_1 = JSON.parse(JSON.stringify(data));
                        newsections_1.forEach(function (elt) {
                            elt.type = 'album';
                            elt.generictype = 'album';
                            elt.liked = true;
                        });
                        var sect_1 = {
                            type: 'genericitem',
                            displaytype: 'list',
                            data: newsections_1
                        };
                        return observable.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (coverArt) {
                            return {
                                sections: _this.sectionService.enhanceSections({
                                    sections: [sect_1]
                                }),
                                coverArtImage: coverArt,
                                list_type: 'albums',
                                title: 'My Albums',
                                numalbums: newsections_1 && newsections_1 != null
                                    ? newsections_1.length
                                    : 0
                            };
                        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (albumsSection) {
                            albumsSection = _this._mymusicService.enhanceCollection(albumsSection, type, albumsSection.list_type);
                            albumsSection['isempty'] = data.length === 0;
                            return new routeToActionMapping_1[type](albumsSection);
                        }));
                    }
                    else if (type === 'playlists') {
                        if (data && data.length > 0) {
                            var collection = JSON.parse(JSON.stringify(data));
                            collection.forEach(function (section) {
                                if (section && section !== null && section.data) {
                                    section.type = 'genericitem';
                                    section.data.forEach(function (elt) {
                                        elt.type = 'playlist';
                                        elt.generictype = 'playlist';
                                    });
                                    var sectData = section && section !== null
                                        ? section.data &&
                                            section.data !== null &&
                                            section.data.length > 0
                                            ? section.data
                                            : []
                                        : [];
                                    section.isempty =
                                        sectData && sectData.length > 0
                                            ? section.data.filter(function (elt) {
                                                return elt.name !== _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_13__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS &&
                                                    elt.name !== _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_13__["SPECIAL_PLAYLIST_NAMES"].LIKES;
                                            }).length === 0
                                            : true;
                                }
                            });
                            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new routeToActionMapping_1[type](collection));
                        }
                        else {
                            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(undefined);
                        }
                    }
                    else if (type === 'artists') {
                        if (data && data.length > 0) {
                            var collection = JSON.parse(JSON.stringify(data));
                            collection.forEach(function (section) {
                                if (section && section !== null && section.data) {
                                    section.data.forEach(function (elt) {
                                        elt.type = 'artist';
                                        elt.generictype = 'artist';
                                    });
                                    section.displaytype = 'bigimages';
                                    var sectData = section && section !== null
                                        ? section.data &&
                                            section.data !== null &&
                                            section.data.length > 0
                                            ? section.data
                                            : []
                                        : [];
                                    section.isempty = !(sectData && sectData.length > 0);
                                }
                            });
                            collection.type = 'playlist';
                            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new routeToActionMapping_1[type](collection));
                        }
                        else {
                            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(undefined);
                        }
                    }
                    else {
                        var listtype = data.list_type;
                        var playlistid = data.playlistid;
                        var likesSection = likes && likes !== null
                            ? likes.sections &&
                                likes.sections !== null &&
                                likes.sections.length > 0
                                ? likes.sections.filter(function (elt) { return elt.type === 'song' && elt.displaytype === 'list'; })
                                : []
                            : [];
                        var likesLst_1 = likesSection && likesSection !== null && likesSection.length > 0
                            ? likesSection[0].data
                            : [];
                        if (listtype === 'playlist') {
                            return _this._mymusicService
                                .getPlaylistData({ id: playlistid })
                                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (response) {
                                var res = _this._mymusicService.enhanceCollection(response, type, response.list_type);
                                if (res && res !== null) {
                                    var sect = res.sections && res.sections !== null
                                        ? res.sections.filter(function (elt) { return elt.displaytype === 'list'; })
                                        : [];
                                    if (sect && sect.length > 0) {
                                        if (sect[0].data &&
                                            sect[0].data !== null &&
                                            sect[0].data.length > 0) {
                                            sect[0].data.forEach(function (elt) {
                                                if (likesLst_1 && likesLst_1.length > 0) {
                                                    elt.liked = likesLst_1.find(function (song) { return song.id === elt.id; })
                                                        ? true
                                                        : false;
                                                }
                                            });
                                        }
                                    }
                                    res.isempty =
                                        sect && sect.length > 0
                                            ? !(sect[0].data &&
                                                sect[0].data !== null &&
                                                sect[0].data.length > 0)
                                            : true;
                                    res.duration =
                                        sect && sect.length > 0
                                            ? _this._utils.getListDuration(sect[0].data)
                                            : 0;
                                }
                                return new routeToActionMapping_1[type](res);
                            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function () {
                                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _actions_error_handling_actions__WEBPACK_IMPORTED_MODULE_7__["EffectError"]());
                            }));
                        }
                        else {
                            return new routeToActionMapping_1[type]({});
                        }
                    }
                }
                else {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["empty"])();
                }
            }));
        }));
        this.getQarii$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["MymusicActionTypes"].GetQarii), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function () {
            return _this._mymusicService.getQarii().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (response) {
                var res = response.payload;
                var data = res.sections && res.sections !== null && res.sections.length > 0
                    ? res.sections[0] && res.sections[0] !== null
                        ? res.sections[0].data
                        : []
                    : [];
                if (data && data !== null && data.length > 0) {
                    data.forEach(function (elt) {
                        elt.coverArtImage = _this.coverartservice.getCoverArtImage(elt.ArtistArt, 296);
                        elt.name = {
                            en: elt.nameen,
                            fr: elt.nameen,
                            ar: elt.namear
                        };
                        elt.selected =
                            elt.selected && elt.selected !== null ? elt.selected : false;
                    });
                }
                return new _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["GetQariiSuccess"](data);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["GetQariiError"](err));
            }));
        }));
        this.postQarii$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["MymusicActionTypes"].PostQarii), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (action) {
            var payload = action.payload;
            return _this._mymusicService.postQarii(payload).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (data) {
                return new _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["PostQariiSuccess"](data);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_8__["PostQariiError"](error));
            }));
        }));
    }
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], MymusicEffects.prototype, "SetLibraryPlaylistCollection$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], MymusicEffects.prototype, "getQarii$", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], MymusicEffects.prototype, "postQarii$", void 0);
    MymusicEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](5, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_6__["UtilService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
            _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_11__["CoverArtService"],
            _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_12__["SectionService"], String, _anghami_services_mymusic_service__WEBPACK_IMPORTED_MODULE_9__["MymusicService"]])
    ], MymusicEffects);
    return MymusicEffects;
}());



/***/ }),

/***/ "./src/app/core/services/mymusic.service.ts":
/*!**************************************************!*\
  !*** ./src/app/core/services/mymusic.service.ts ***!
  \**************************************************/
/*! exports provided: MymusicService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MymusicService", function() { return MymusicService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/actions/mymusic.actions */ "./src/app/core/redux/actions/mymusic.actions.ts");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../enums/special-playlist-names.enum */ "./src/app/core/enums/special-playlist-names.enum.ts");













var MymusicService = /** @class */ (function () {
    function MymusicService(http, _authService, store, coverartservice, sectionService, locale) {
        this.http = http;
        this._authService = _authService;
        this.store = store;
        this.coverartservice = coverartservice;
        this.sectionService = sectionService;
        this.locale = locale;
        this.disabled = false;
    }
    MymusicService.prototype.getPlaylistData = function (params) {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETplaylistdata')
            .set('playlistid', params.id)
            .set('reverse', 'true');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    MymusicService.prototype.enhanceCollection = function (collection, sectionType, type) {
        var _this = this;
        var isloggedin = this._authService.isUserLoggedIn();
        var collectionData = tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"](collection, []);
        var thumb = collectionData.coverArt
            ? collectionData.coverArt
            : collectionData.coverArtImage
                ? collectionData.coverArtImage
                : 0;
        var newbuttons = collectionData.buttons && collectionData.buttons != null
            ? JSON.parse(JSON.stringify(collectionData.buttons))
            : [];
        this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_8__["getFollowedPlaylistsState"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (data) {
            var playlists = [];
            if (data && data !== null && data.length > 0) {
                data = data.filter(function (elt) { return elt.name === 'playlists'; });
                data.forEach(function (elt) {
                    if (elt.data) {
                        playlists.push.apply(playlists, elt.data);
                    }
                });
                playlists = playlists.filter(function (elt) {
                    return elt.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_12__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS ||
                        elt.name === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_12__["SPECIAL_PLAYLIST_NAMES"].LIKES;
                });
            }
            return playlists;
        }))
            .subscribe(function (data) {
            var disabledPlaylists = data;
            var iscollab = !!(collectionData.collaborative && collectionData.collaborative === 1);
            var canedit = collectionData.canedit;
            var isfeatured = !!collectionData.isfeatured && collectionData.isfeatured == 'true';
            if (disabledPlaylists &&
                disabledPlaylists != null &&
                disabledPlaylists.length > 0) {
                _this.disabled =
                    isfeatured ||
                        (iscollab && !canedit) ||
                        (disabledPlaylists &&
                            disabledPlaylists.find(function (elt) { return elt.id == collectionData.id; })
                            ? true
                            : false);
            }
            else {
                _this.disabled = !canedit || isfeatured;
            }
            if (type === 'playlist') {
                if (sectionType && sectionType === 'downloads') {
                    newbuttons = newbuttons.concat([
                        {
                            deeplink: null,
                            text: _this.locale === 'ar'
                                ? 'استمع'
                                : _this.locale === 'fr'
                                    ? 'Écouter'
                                    : 'Play',
                            type: 'play'
                        },
                        {
                            deeplink: null,
                            text: _this.locale === 'ar'
                                ? 'عشوائي'
                                : _this.locale === 'fr'
                                    ? 'Aléatoire'
                                    : 'Shuffle',
                            type: 'shuffle'
                        }
                    ]);
                }
                if (collectionData.canedit) {
                    if (newbuttons && newbuttons != null) {
                        newbuttons = newbuttons.concat([
                            {
                                deeplink: null,
                                text: _this.locale === 'ar'
                                    ? 'تعديل القائمة الموسيقية'
                                    : _this.locale === 'fr'
                                        ? 'Modifier la Playlist'
                                        : 'Edit Playlist',
                                type: 'edit'
                            }
                        ]);
                    }
                }
                if (!_this.disabled) {
                    newbuttons = newbuttons.concat([
                        {
                            deeplink: null,
                            text: _this.locale === 'ar'
                                ? 'حذف قائمة الموسيقى'
                                : _this.locale === 'fr'
                                    ? 'Supprimer la Playlist'
                                    : 'Delete Playlist',
                            type: 'delete'
                        }
                    ]);
                }
            }
            // TODO: Pending API
            // if (type === 'albums') {
            //     if (newbuttons && newbuttons != null) {
            //         newbuttons = newbuttons.concat([
            //             {
            //                 deeplink: null,
            //                 text:
            //                     this.locale === 'ar'
            //                         ? 'استمع'
            //                         : this.locale === 'fr'
            //                             ? 'Écouter'
            //                             : 'Play',
            //                 type: 'play'
            //             }, {
            //                 deeplink: null,
            //                 text:
            //                     this.locale === 'ar'
            //                         ? 'عشوائي'
            //                         : this.locale === 'fr'
            //                             ? 'Aléatoire'
            //                             : 'Shuffle',
            //                 type: 'shuffle'
            //             }
            //         ]);
            //     }
            // }
        });
        if (!isloggedin) {
            newbuttons = newbuttons.filter(function (elt) { return elt.type !== 'follow'; });
        }
        var newCollectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, collectionData, { coverArtImage: this.coverartservice.getCoverArtImage(thumb, 296), ArtistArt: this.coverartservice.getCoverArtImage(collectionData.ArtistArt, 296), buttons: newbuttons, numsongs: type === 'playlist'
                ? !collectionData.numsongs || collectionData.numsongs == null
                    ? '0'
                    : collectionData.numsongs
                : collectionData.numsongs, sections: this.sectionService.enhanceSections(collection, sectionType) });
        var filtered = this.sectionService.filterSections(collection, {
            type: ['question', 'placeholder', 'story'],
            group: ['editorial', 'requests_preview', 'uservideos', 'uservideos_old']
        });
        collection = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, filtered.response);
        return newCollectionMeta;
    };
    MymusicService.prototype.getQarii = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETqari');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_9__["GetQariiSuccess"](data));
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    MymusicService.prototype.postQarii = function (payload) {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        if (payload && payload !== null) {
            for (var _i = 0, _a = Object.keys(payload); _i < _a.length; _i++) {
                var key = _a[_i];
                body = body.set(key, payload[key]);
            }
        }
        return this.http.post("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    MymusicService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](5, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"],
            _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_10__["CoverArtService"],
            _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_11__["SectionService"], String])
    ], MymusicService);
    return MymusicService;
}());



/***/ }),

/***/ "./src/app/modules/base/mymusic/mymusic-routing.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/modules/base/mymusic/mymusic-routing.module.ts ***!
  \****************************************************************/
/*! exports provided: routes, matcherFunction, MymusicRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "matcherFunction", function() { return matcherFunction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MymusicRoutingModule", function() { return MymusicRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _mymusic_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mymusic.component */ "./src/app/modules/base/mymusic/mymusic.component.ts");
/* harmony import */ var _mymusic_resolver__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./mymusic.resolver */ "./src/app/modules/base/mymusic/mymusic.resolver.ts");
/* harmony import */ var _view_view_resolver__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../view/view.resolver */ "./src/app/modules/base/view/view.resolver.ts");






var routes = [
    {
        path: '',
        component: _mymusic_component__WEBPACK_IMPORTED_MODULE_3__["MymusicComponent"],
        resolve: {
            viewData: _mymusic_resolver__WEBPACK_IMPORTED_MODULE_4__["MymusicResolver"]
        }
    },
    {
        path: 'likes',
        loadChildren: '../view/view.module#ViewModule',
        resolve: {
            viewData: _view_view_resolver__WEBPACK_IMPORTED_MODULE_5__["ViewResolver"]
        }
    },
    {
        matcher: matcherFunction,
        resolve: {
            viewData: _mymusic_resolver__WEBPACK_IMPORTED_MODULE_4__["MymusicResolver"]
        },
        loadChildren: '../library/library.module#LibraryModule',
        data: { preload: true, delay: true }
    }
];
function matcherFunction(url) {
    // TODO: check how many params can be added
    if (url.length === 1) {
        var path = url[0].path;
        if (path === 'playlists' || path === 'downloads'
            || path === 'albums' || path === 'artists' || path === 'desktop-downloads') {
            return {
                consumed: [],
                posParams: { collectionType: url[0] }
            };
        }
    }
    else {
        return null;
    }
}
var MymusicRoutingModule = /** @class */ (function () {
    function MymusicRoutingModule() {
    }
    MymusicRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], MymusicRoutingModule);
    return MymusicRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/base/mymusic/mymusic.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/modules/base/mymusic/mymusic.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n:host .playlists {\n  margin: auto 2em;\n}\n:host .playlists .playlists-span {\n  font-size: 1.8em;\n}\n:host .playlists .illustration {\n  margin: 1em;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  width: calc(100% - 8em);\n}\n:host .playlists .illustration img {\n  max-width: 7em;\n}\n:host .playlists .illustration p {\n  font-size: 1.1em;\n  text-align: center;\n  margin: 0 auto !important;\n  max-width: 20em;\n  color: var(--gray-text-color);\n}\n:host .playlists .btn-secondary {\n  color: black;\n  border-color: black;\n  border-radius: 3em;\n  padding: 0.2em 1.2em;\n  background-color: var(--text-color);\n}\n:host h4 {\n  font-weight: bold;\n}\n:host .header {\n  padding-bottom: 0.5em;\n}\n:host .margin2 {\n  margin: 2em;\n}\n:host .fullwidth {\n  width: 100%;\n}"

/***/ }),

/***/ "./src/app/modules/base/mymusic/mymusic.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/modules/base/mymusic/mymusic.component.ts ***!
  \***********************************************************/
/*! exports provided: MymusicComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MymusicComponent", function() { return MymusicComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _app_core_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../app/core/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _core_enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/enums/special-playlist-names.enum */ "./src/app/core/enums/special-playlist-names.enum.ts");









var MymusicComponent = /** @class */ (function () {
    function MymusicComponent(_store, _router, _route) {
        this._store = _store;
        this._router = _router;
        this._route = _route;
        this.env = _environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].assetsCDN + "img/";
        this.libraryInfo$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["select"])(_app_core_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__["getLibraryInfoState"]));
        this.playlists$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["select"])(_app_core_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__["getFollowedPlaylistsState"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (data) {
            var playlists = [];
            var playlistSection = {};
            if (data && data.length > 0) {
                data.forEach(function (elt) {
                    playlists.push.apply(playlists, elt.data);
                });
                playlists = playlists.filter(function (elt) {
                    return elt.name.indexOf(_core_enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_8__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS) === -1 &&
                        elt.name.indexOf(_core_enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_8__["SPECIAL_PLAYLIST_NAMES"].LIKES) === -1;
                });
                playlistSection = {
                    displaytype: 'card',
                    title: '',
                    data: playlists,
                    type: 'playlist',
                    initialNumItems: 12
                };
            }
            return playlistSection;
        }));
    }
    MymusicComponent.prototype.createPlaylist = function () {
        this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_1__["OpenPlaylistManager"]({ type: 'create' }));
    };
    MymusicComponent.prototype.ngOnInit = function () {
        // this._store.dispatch(new MyMusicActions.GetLibrary());
    };
    MymusicComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'anghami-mymusic',
            template: __webpack_require__(/*! raw-loader!./mymusic.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/mymusic/mymusic.component.html"),
            host: { class: 'ang-view' },
            styles: [__webpack_require__(/*! ./mymusic.component.scss */ "./src/app/modules/base/mymusic/mymusic.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], MymusicComponent);
    return MymusicComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/mymusic/mymusic.module.ts":
/*!********************************************************!*\
  !*** ./src/app/modules/base/mymusic/mymusic.module.ts ***!
  \********************************************************/
/*! exports provided: MymusicModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MymusicModule", function() { return MymusicModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _mymusic_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mymusic.component */ "./src/app/modules/base/mymusic/mymusic.component.ts");
/* harmony import */ var _mymusic_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./mymusic-routing.module */ "./src/app/modules/base/mymusic/mymusic-routing.module.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _mymusic_resolver__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mymusic.resolver */ "./src/app/modules/base/mymusic/mymusic.resolver.ts");
/* harmony import */ var _core_components_profile_header_profile_header_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/profile-header/profile-header.component */ "./src/app/core/components/profile-header/profile-header.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _core_components_link_link_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/components/link/link.component */ "./src/app/core/components/link/link.component.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");
/* harmony import */ var _view_view_resolver__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../view/view.resolver */ "./src/app/modules/base/view/view.resolver.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _anghami_redux_effects_mymusic_effects__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/redux/effects/mymusic.effects */ "./src/app/core/redux/effects/mymusic.effects.ts");
/* harmony import */ var _anghami_services_mymusic_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @anghami/services/mymusic.service */ "./src/app/core/services/mymusic.service.ts");















var MymusicModule = /** @class */ (function () {
    function MymusicModule() {
    }
    MymusicModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _mymusic_routing_module__WEBPACK_IMPORTED_MODULE_4__["MymusicRoutingModule"],
                _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_5__["IconModule"],
                _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_10__["NewSectionBuilderModule"],
                _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"],
                _ngrx_effects__WEBPACK_IMPORTED_MODULE_12__["EffectsModule"].forFeature([
                    _anghami_redux_effects_mymusic_effects__WEBPACK_IMPORTED_MODULE_13__["MymusicEffects"]
                ])
            ],
            declarations: [_mymusic_component__WEBPACK_IMPORTED_MODULE_3__["MymusicComponent"], _core_components_profile_header_profile_header_component__WEBPACK_IMPORTED_MODULE_7__["ProfileHeaderComponent"], _core_components_link_link_component__WEBPACK_IMPORTED_MODULE_9__["LinkComponent"]],
            exports: [_mymusic_component__WEBPACK_IMPORTED_MODULE_3__["MymusicComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["NO_ERRORS_SCHEMA"]],
            providers: [_mymusic_resolver__WEBPACK_IMPORTED_MODULE_6__["MymusicResolver"], _view_view_resolver__WEBPACK_IMPORTED_MODULE_11__["ViewResolver"], _anghami_services_mymusic_service__WEBPACK_IMPORTED_MODULE_14__["MymusicService"]]
        })
    ], MymusicModule);
    return MymusicModule;
}());



/***/ }),

/***/ "./src/app/modules/base/mymusic/mymusic.resolver.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/base/mymusic/mymusic.resolver.ts ***!
  \**********************************************************/
/*! exports provided: MymusicResolver */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MymusicResolver", function() { return MymusicResolver; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/library.actions */ "./src/app/core/redux/actions/library.actions.ts");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _core_services_utils_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/services/utils.service */ "./src/app/core/services/utils.service.ts");










var MymusicResolver = /** @class */ (function () {
    function MymusicResolver(store, platformId, utils, _authService) {
        this.store = store;
        this.platformId = platformId;
        this.utils = utils;
        this._authService = _authService;
    }
    MymusicResolver.prototype.resolve = function (route, state) {
        var routeId = state.url.split('/').length >= 3
            ? state.url.split('/')[2]
            : 'mymusic' || false;
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_4__["isPlatformServer"])(this.platformId)) {
            // this.initViewData(routeId);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["empty"])();
        }
        else {
            return this.waitForViewDataToLoad(routeId);
        }
    };
    // TODO: handle if same collection type but different collection Id
    MymusicResolver.prototype.waitForViewDataToLoad = function (routeId) {
        var _this = this;
        var routeToSelectorMapping = {
            mymusic: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_2__["getLibraryInfoState"],
            downloads: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_2__["getDownloadsState"],
            albums: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_2__["getLikedAlbumsState"],
            artists: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_2__["getFollowedArtistsState"],
            likes: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_2__["getLikedSongsState"],
            playlists: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_2__["getFollowedPlaylistsState"]
        };
        if (routeToSelectorMapping[routeId]) {
            var libraryStream$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["select"])(routeToSelectorMapping[routeId]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["filter"])(function (state) {
                // check when to fire the api [if collection is empty]
                if (state === undefined || state === null) {
                    _this.initViewData(routeId);
                    return false;
                }
                else {
                    return true;
                }
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1));
            return libraryStream$;
        }
        else {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["empty"])();
        }
    };
    MymusicResolver.prototype.initViewData = function (routeId) {
        var isloggedin = this._authService.isUserLoggedIn();
        if (isloggedin) {
            if (routeId === 'downloads') {
                this.handleDownloads();
            }
            else {
                var routeToActionMapping = {
                    mymusic: _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLibraryInfo"],
                    albums: _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLikedAlbums"],
                    artists: _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetFollowedArtists"],
                    likes: _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetFollowedPlaylists"],
                    playlists: _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetFollowedPlaylists"]
                };
                this.store.dispatch(new routeToActionMapping[routeId]());
            }
        }
    };
    MymusicResolver.prototype.handleDownloads = function () {
        var _this = this;
        this.likesState = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_2__["getLikedSongsState"]))
            .subscribe(function (data) {
            if (!data || data === null) {
                _this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetFollowedPlaylists"]());
            }
            else {
                _this.store
                    .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_2__["getFollowedPlaylistsState"]))
                    .subscribe(function (res) {
                    _this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetDownloads"](res));
                    if (_this.likesState) {
                        _this.likesState.unsubscribe();
                    }
                });
            }
        });
    };
    MymusicResolver = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_5__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"],
            Object,
            _core_services_utils_service__WEBPACK_IMPORTED_MODULE_9__["UtilService"],
            _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])
    ], MymusicResolver);
    return MymusicResolver;
}());



/***/ })

}]);