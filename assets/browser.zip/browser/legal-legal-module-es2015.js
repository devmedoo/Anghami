(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["legal-legal-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/inner-header/inner-header.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  id=\"headerid\"\n  class=\"header\"\n  [ngStyle]=\"backgroundimage\"\n  [ngClass]=\"{ extra: backgroundHeader.extra, smallerHeader: smallerHeader }\"\n>\n  <img\n    class=\"logo\"\n    *ngIf=\"backgroundHeader.innerLogo\"\n    [src]=\"backgroundHeader.innerLogo\"\n  />\n  <div>\n    <ng-container *ngIf=\"!isapi\">\n      <h1 class=\"title\">{{ backgroundHeader?.title | translateInstant }}</h1>\n      <h5 class=\"subtitle \">\n        {{ backgroundHeader?.subtitle | translateInstant }}\n      </h5>\n    </ng-container>\n    <ng-container *ngIf=\"isapi\">\n      <div class=\"title\">{{ backgroundHeader?.title }}</div>\n      <h5 class=\"subtitle \">{{ backgroundHeader?.subtitle }}</h5>\n    </ng-container>\n  </div>\n  <img\n    *ngIf=\"isWave\"\n    class=\"wave\"\n    src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\"\n  />\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/legal/legal.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/legal/legal.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<anghami-inner-header [backgroundHeader]=\"innerHeader\"></anghami-inner-header>\n<section class=\"full-row-layout\">\n  <div class=\"container\" *ngIf=\"locale != 'ar'\">\n    <h1 class=\"landing-page-title\">Legal <span>— this is important</span></h1>\n    <h3>Terms of Service</h3>\n    <p>\n      If you have purchased a subscription to Anghami, you will be charged on a\n      monthly, half-yearly, or yearly basis based on the plan you choose. If you\n      have purchased a subscription to Anghami, you have the right to cancel\n      your purchase and receive a full refund within 14 days of purchase.\n      However, if you access the Anghami app within the 14-day period, you will\n      no longer be eligible for a refund if you decide to cancel your purchase.\n    </p>\n    <p>\n      You may cancel your subscription to Anghami at any time via the mobile app\n      or on Anghami’s website. The termination shall have effect at the expiry\n      of the then-current subscription period that you have already paid for\n      (e.g. one month, 3 months, 6 months, or a year) and you will not be\n      refunded for any remaining portion of subscription fees you have already\n      paid for (unless with the 14-day period and under the conditions described\n      above).\n    </p>\n    <p>\n      Anghami reserves the right to terminate and/or suspend your account at any\n      time in case of unauthorised use of the service. If Anghami terminates or\n      suspends your account for any suspicious activity, Anghami shall have no\n      liability or responsibility to you, and will not refund any amounts that\n      you have previously paid.\n    </p>\n    <h3>A- Privacy Policy</h3>\n    <p>\n      This Privacy Policy governs the manner in which Anghami collects, uses,\n      maintains and discloses information collected from users (each, a 'User')\n      of the www.anghami.com website and Anghami app ('Site/App') (“Data”). This\n      privacy policy applies to the Site/App and all products and services\n      offered by Anghami (the “Service”). We use your Data to provide and\n      improve the Service. By using the Service, you agree to the collection and\n      use of information in accordance with this policy.\n    </p>\n    <h4>1- Personal identification information: Personal Data</h4>\n    <p>\n      We may collect personal identification information from Users in a variety\n      of ways, including, but not limited to, when Users visit our site,\n      register on the site, and in connection with other activities, services,\n      features or resources we make available on our Site/App. Users may be\n      asked for, as appropriate, name, email address, credit card information.\n      Users may, however, visit our Site/App anonymously. We will collect\n      personal identification information from Users only if they voluntarily\n      submit such information to us. Users can always refuse to supply\n      personally identification information, except that it may prevent them\n      from engaging in certain Site/App related activities.\n    </p>\n    <h4>2- Non-personal identification information : Usage Data</h4>\n    <p>\n      We may collect non-personal identification information about Users\n      whenever they interact with our Site/App. Non-personal identification\n      information may include the browser name, the type of computer and\n      technical information about Users means of connection to our Site/App,\n      such as the operating system and the Internet service providers utilized\n      and other similar information.\n    </p>\n    <h4>3- Web browser cookies</h4>\n    <p>\n      Our Site/App may use 'cookies' to enhance User experience. User's web\n      browser places cookies on their hard drive for record-keeping purposes and\n      sometimes to track information about them. User may choose to set their\n      web browser to refuse cookies, or to alert you when cookies are being\n      sent. If they do so, note that some parts of the Site/App may not function\n      properly.\n    </p>\n    <h4>4- How we use collected information</h4>\n    <p>\n      Anghami may collect and use Users personal information for the following\n      purposes:\n    </p>\n    <ul>\n      <li>\n        To improve customer service: information you provide helps us respond to\n        your customer service requests and support needs more efficiently.\n      </li>\n      <li>\n        To personalize user experience: we may use information in the aggregate\n        to understand how our Users as a group use the services and resources\n        provided on our Site/App.\n      </li>\n      <li>\n        To improve our Site/App: we may use feedback you provide to improve our\n        products and services.\n      </li>\n      <li>\n        To process payments: we may use the information Users provide about\n        themselves when placing an order only to provide service to that order.\n        We do not share this information with outside parties except to the\n        extent necessary to provide the service.\n      </li>\n      <li>\n        To run a promotion, contest, survey or other Site/App feature: To send\n        Users information they agreed to receive about topics we think will be\n        of interest to them. To send periodic emails We may use the email\n        address to send User information and updates pertaining to their order.\n        It may also be used to respond to their inquiries, questions, and/or\n        other requests. If User decides to opt-in to our mailing list, they will\n        receive emails that may include company news, updates, related product\n        or service information, etc. If at any time the User would like to\n        unsubscribe from receiving future emails, we include detailed\n        unsubscribe instructions at the bottom of each email or User may contact\n        us via our Site/App.\n      </li>\n    </ul>\n    <h4>5- How we protect your Data</h4>\n    <p>\n      - We adopt appropriate data collection, storage and processing practices\n      and security measures to protect against unauthorized access, alteration,\n      disclosure or destruction of your personal information, username,\n      password, transaction information and data stored on our Site/App. <br />\n      Sensitive and private data exchange between the Site/App and its Users\n      happens over a SSL secured communication channel and is encrypted and\n      protected with digital signatures.\n    </p>\n    <p>\n      - Legal basis for processing personal data under general data protection\n      regulation <strong>(GDPR):</strong>\n    </p>\n    <p>\n      If you are from the European Economic Area (EEA), Anghami legal basis for\n      collecting and using the personal information described in this Privacy\n      Policy depends on the Personal Data we collect and the specific context in\n      which we collect it. If you are a resident of the EEA, you have certain\n      data protection rights. We aim to take reasonable steps to allow you to\n      correct, amend, delete, or limit the use of your Personal Data. If you\n      wish to be informed what Personal Data we hold about you and if you want\n      it to be removed from our systems, please contact us.\n    </p>\n    <p>Anghami may process your Personal Data because:</p>\n    <ul>\n      <li>We need to perform a contract with you</li>\n      <li>You have given us permission to do so</li>\n      <li>\n        The processing is in our legitimate interests and it's not overridden by\n        your rights\n      </li>\n      <li>For payment processing purposes</li>\n      <li>To comply with the law</li>\n    </ul>\n    <p>\n      In certain circumstances, you have the following data protection rights:\n    </p>\n    <ul>\n      <li>\n        <strong\n          >The right to access, update or to delete the information we have on\n          you.</strong\n        ><br />Whenever made possible, you can access, update or request\n        deletion of your Personal Data directly within your account settings\n        section. If you are unable to perform these actions yourself, please\n        contact us to assist you.\n      </li>\n      <li>\n        <strong>The right of rectification.</strong><br />You have the right to\n        have your information rectified if that information is inaccurate or\n        incomplete.\n      </li>\n      <li>\n        <strong>The right to object.</strong><br />You have the right to object\n        to our processing of your Personal Data.\n      </li>\n      <li>\n        <strong>The right of restriction.</strong><br />You have the right to\n        request that we restrict the processing of your personal information.\n      </li>\n      <li>\n        <strong>The right to data portability.</strong><br />You have the right\n        to be provided with a copy of the information we have on you in a\n        structured, machine-readable and commonly used format.\n      </li>\n      <li>\n        <strong>The right to withdraw consent.</strong><br />You also have the\n        right to withdraw your consent at any time where Anghami relied on your\n        consent to process your personal information.\n      </li>\n    </ul>\n    <p>\n      Please note that we may ask you to verify your identity before responding\n      to such requests.\n    </p>\n    <p>\n      You have the right to complain to a Data Protection Authority about our\n      collection and use of your Personal Data. For more information, please\n      contact your local data protection authority in the European Economic Area\n      (EEA).\n    </p>\n    <h4>6- Retaining your Data</h4>\n    <p>\n      We will retain your Personal Data only for as long as it is necessary for\n      the purposes set out in this Privacy Policy. We will retain and use your\n      Personal Data to the extent necessary to comply with our legal obligations\n      and policies. We will also retain Usage Data for internal analysis\n      purposes. Usage Data is generally retained for a shorter period of time,\n      except when this data is used to strengthen the security or to improve the\n      functionality of our Service, or we are legally obligated to retain this\n      data for longer periods of time.\n    </p>\n    <h4>7- Sharing your Data</h4>\n    <p>\n      We do not sell, trade, or rent Users personal identification information\n      to others. We may share generic aggregated demographic information not\n      linked to any personal identification information regarding visitors and\n      users with our business partners, trusted affiliates and advertisers for\n      the purposes outlined above. We may use third party service providers to\n      help us operate our business and the Site/App or administer activities on\n      our behalf, such as sending out newsletters or surveys. We may share your\n      information with these third parties for those limited purposes provided\n      that you have given us your permission.\n    </p>\n    <h4>8- Children Protection</h4>\n    <p>\n      If you are from the European Economic Area (EEA) and under the age of 16,\n      you must provide us with a parental consent. If you are a parent or\n      guardian and you are aware that your Children under the age of 16, has\n      provided us with Personal Data, please contact us. If we become aware that\n      we have collected Personal Data from children under the age of 16, without\n      verification of parental consent, we take steps to remove that information\n      from our servers.\n    </p>\n    <h4>9- Itunes: In-App Purchase payment</h4>\n    <ul>\n      <li>\n        Payment will be charged to iTunes Account at confirmation of purchase\n      </li>\n      <li>\n        Subscription automatically renews unless auto-renew is turned off at\n        least 24-hours before the end of the current period\n      </li>\n      <li>\n        Account will be charged for renewal within 24-hours prior to the end of\n        the current period, and identify the cost of the renewal\n      </li>\n      <li>\n        Subscriptions may be managed by the user and auto-renewal may be turned\n        off by going to the user's Account Settings after purchase\n      </li>\n      <li>\n        Any unused portion of a free trial period, if offered, will be forfeited\n        when the user purchases a subscription to that publication, where\n        applicable\n      </li>\n    </ul>\n    <h4>10- Changes to this privacy policy</h4>\n    <p>\n      Anghami has the discretion to update this privacy policy at any time. When\n      we do, we will revise the updated date at the bottom of this page. We\n      encourage Users to frequently check this page for any changes to stay\n      informed about how we are helping to protect the personal information we\n      collect. You acknowledge and agree that it is your responsibility to\n      review this privacy policy periodically and become aware of modifications.\n    </p>\n    <h3>\n      B- Notice and procedure for making claims of copyright or other\n      intellectual property infringements.\n    </h3>\n    <p>\n      <b>(a)</b> Anghami respects the intellectual property of others and takes\n      the protection of copyrights and all other intellectual property very\n      seriously, and we ask our users to do the same. Infringing activity will\n      not be tolerated on or through the Site or the Anghami Service.\n    </p>\n    <p>\n      <b>(b)</b> Anghami’s intellectual property policy is to (1) remove\n      material that Anghami believes in good faith, upon notice from an\n      intellectual property owner or their agent, is infringing the intellectual\n      property of a third party by being made available through the Site, and\n      (2) remove any Products or Submissions posted to the Site by “repeat\n      infringers.” Anghami considers a “repeat infringer” to be any user that\n      has uploaded Products or Submissions to the Service and for whom Anghami\n      has received more than two takedown notices compliant with the provisions\n      of 17 U.S.C. § 512(c) with respect to such Products or Submissions.\n      Anghami has discretion, however, to terminate the account of any user\n      after receipt of a single notification of claimed infringement or upon\n      Anghami’ s own determination.\n    </p>\n    <p>\n      <b>(c) Procedure for Reporting Claimed Infringement.</b> If you believe\n      that any Productions or Submissions made available on or through the Site\n      or the Anghami Service have been used or exploited in a manner that\n      infringes an intellectual property right you own or control, then please\n      promptly send a “Notification of Claimed Infringement” containing the\n      following information to the Designated Agent identified below. Your\n      communication must include substantially the following:\n    </p>\n    <ul class=\"light-list\">\n      <li>\n        (i) A physical or electronic signature of a person authorized to act on\n        behalf of the owner of the work(s) that has/have been allegedly\n        infringed;\n      </li>\n      <li>\n        (ii) Identification of works or materials being infringed, or, if\n        multiple works are covered by a single notification, a representative\n        list of such works;\n      </li>\n      <li>\n        (iii) Identification of the specific material that is claimed to be\n        infringing or to be the subject of infringing activity and that is to be\n        removed or access to which is to be disabled, and information reasonably\n        sufficient to permit Anghami to locate the material;\n      </li>\n      <li>\n        (iv) Information reasonably sufficient to permit Anghami to contact you,\n        such as an address, telephone number, and, if available, an electronic\n        mail address at which you may be contacted;\n      </li>\n      <li>\n        (v) A statement that you have a good faith belief that the use of the\n        material in the manner complained of is not authorized by the copyright\n        owner, its agent, or the law; and\n      </li>\n      <li>\n        (vi) A statement that the information in the notification is accurate,\n        and under penalty of perjury, that you are authorized to act on behalf\n        of the owner of an exclusive right that is allegedly infringed.\n      </li>\n    </ul>\n    <p>\n      You should consult with your own lawyer and/or see 17 U.S.C. § 512 to\n      confirm your obligations to provide a valid notice of claimed\n      infringement.\n    </p>\n    <p>\n      <b>(d) Designated Agent Contact Information.</b> Anghami’s Designated\n      Agent for notices of claimed infringement can be contacted at:\n    </p>\n    <ul class=\"light-list\">\n      <li><u>Via E-mail</u> : legal@anghami.com</li>\n      <li>\n        <u>Via U.S. Mail</u> : Zardman building, 5th floor, Jal el Dib, Lebanon\n      </li>\n    </ul>\n    <p>\n      <b>(e) Counter Notification.</b> If you receive a notification from\n      Anghami that material made available by you on or through the Site or the\n      Anghami Service has been the subject of a Notification of Claimed\n      Infringement, then you will have the right to provide Anghami with what is\n      called a “Counter Notification.” To be effective, a Counter Notification\n      must be in writing, provided Anghami’ s Designated Agent through one of\n      the methods identified in Section B(d) of this TOS, and include\n      substantially the following information:\n    </p>\n    <ul class=\"light-list\">\n      <li>(i) A physical or electronic signature of the subscriber;</li>\n      <li>\n        (ii) Identification of the material that has been removed or to which\n        access has been disabled and the location at which the material appeared\n        before it was removed or access to it was disabled;\n      </li>\n      <li>\n        (iii) A statement under penalty of perjury that the subscriber has a\n        good faith belief that the material was removed or disabled as a result\n        of mistake or misidentification of the material to be removed or\n        disabled;\n      </li>\n      <li>\n        (iv) The subscriber’s name, address, and telephone number, and a\n        statement that the subscriber consents to the jurisdiction of Federal\n        District Court for the judicial district in which the address is\n        located, or if the subscriber’s address is outside of the United States,\n        Civil Courts in Beirut / Lebanon, and that the subscriber will accept\n        service of process from the person who provided notification under\n        Section B(c) of this TOS above or an agent of such person.\n      </li>\n    </ul>\n    <p>\n      A party submitting a Counter Notification should consult a lawyer or see\n      17 U.S.C. § 512 to confirm the party’s obligations to provide a valid\n      counter notification under the Copyright Act.\n    </p>\n    <p>\n      <b\n        >(f) False Notifications of Claimed Infringement or Counter\n        Notifications.</b\n      >\n      The Copyright Act provides that:\n    </p>\n    <ul class=\"light-list\">\n      <li>\n        Any person who knowingly materially misrepresents under [Section 512 of\n        the Copyright Act (17 U.S.C. § 512)] (1) that material or activity is\n        infringing, or (2) that material or activity was removed or disabled by\n        mistake or misidentification, shall be liable for any damages, including\n        costs and attorneys’ fees, incurred by the alleged infringer, by any\n        copyright owner or copyright owner’s authorized licensee, or by a\n        service provider, who is injured by such misrepresentation, as the\n        result of Anghami relying upon such misrepresentation in removing or\n        disabling access to the material or activity claimed to be infringing,\n        or in replacing the removed material or ceasing to disable access to it.\n      </li>\n    </ul>\n    <p>\n      17 U.S.C. § 512(f). Anghami reserves the right to seek damages from any\n      party that submits a notification of claimed infringement or counter\n      notification in violation of the law. For the avoidance of doubt, only\n      notices submitted under the Digital Millennium Copyright Act and the\n      procedures set forth in this Section C should be sent to the Designated\n      Agent at the e-mail or postal address set forth above. Any other comments,\n      compliments, complaints or suggestions about Anghami, the operation of the\n      Site or the Anghami Service or any other matter should be sent to\n      <a href=\"mailto:info@anghami.com\">info@anghami.com</a>.\n    </p>\n    <h4>Your acceptance of these terms</h4>\n    <p>\n      By using this Site/App, you signify your acceptance of this policy. If you\n      do not agree to this policy, please do not use our Site/App. Your\n      continued use of the Site/App following the posting of changes to this\n      policy will be deemed your acceptance of those changes.\n    </p>\n    <h3>Contacting us</h3>\n    <div>Anghami <a href=\"http://www.anghami.com\">www.anghami.com</a></div>\n    <div>Lebanon: Zardman building, 5th floor, Jal el Dib</div>\n    <div>UAE: Dubai Internet City, Building 1, Office 211</div>\n    <div>+961 4 719446</div>\n    <div><a href=\"mailto:info@anghami.com\">info@anghami.com</a></div>\n    <p class=\"top-margin\">This document was last updated on May 24, 2018</p>\n  </div>\n  <div class=\"container\" *ngIf=\"locale == 'ar'\">\n    <div class=\"arabic-legal\">\n      <h1 class=\"landing-page-title\">قانوني!<span>— مهم جداً</span></h1>\n      <h4>شروط الخدمة</h4>\n      <p>\n        إذا اشتريت اشتراكًا في أنغامي بلَس، فسيتم محاسبتك على أساسٍ شهريّ أو نصف\n        سنويّ أو سنويّ استنادًا إلى الخطة التي تختارها. إذا قمت بشراء اشتراكاً\n        في أنغامي بلَس، فيحق لك إلغاء الإشتراك واسترداد المبلغ كاملاً في غضون 14\n        يومًا من تاريخ الشراء. ومع ذلك، إذا قمت بالولوج إلى تطبيق أنغامي خلال\n        فترة ال14 يومًا، فلن تكون مؤهلاً لاسترداد الأموال إذا قررت إلغاء\n        الإشتراك.\n      </p>\n      <p>\n        يمكنك إلغاء الإشتراك في أنغامي في أي وقت عبر تطبيق الجوال أو عبر موقع\n        أنغامي. يكون الإنهاء ساريًا عند انتهاء فترة الاشتراك الحالية التي سبق\n        ودفعتها (على سبيل المثال، شهر واحد، أو ثلاثة أشهر، أو ستة أشهر، أو سنة)،\n        ولن يتم رد أموالك مقابل أي جزءٍ متبقٍ من رسوم الاشتراك الذي قد سبق وتم\n        دفعه (ما لم يكن ذلك ضمن فترة ال14 يوماً وبحسب الشروط المذكورة أعلاه).\n      </p>\n      <p>\n        تحتفظ أنغامي بالحق في إنهاء و/أو تعليق حسابك في أي وقت في حالة الاستخدام\n        غير المصرح به للخدمة. إذا أنهت أو علقت أنغامي حسابك بسبب أي نشاطٍ مشبوه،\n        فلن تتحمل أنغامي أية التزامات أو مسؤولية تجاهك، ولن تقوم برد أي مبالغ قد\n        دفعته من قبل.\n      </p>\n      <p><strong>أ- </strong><strong>سياسة الخصوصية</strong></p>\n      <p>\n        تحكم سياسة الخصوصية هذه الطريقة التي تجمع وتستخدم وتحافظ وتكشف عبرها\n        أنغامي عن المعلومات التي يتم جمعها من المستخدمين (كل منهم، \"مستخدم\") من\n        موقع www.anghami.com وتطبيق أنغامي (\"الموقع/التطبيق\") (\"البيانات\").\n        تنطبق سياسة الخصوصية هذه على الموقع/التطبيق وجميع المنتجات والخدمات التي\n        تقدمها أنغامي (\"الخدمة\"). نستخدم بياناتك لتوفير الخدمة وتحسينها. عبر\n        استخدامك لهذه الخدمة، فإنك توافق على جمع واستخدام المعلومات وفقًا لهذه\n        السياسة.\n      </p>\n      <p>\n        <strong><em>1- </em></strong><strong>معلومات</strong>\n        <strong>التعريف</strong> <strong>الشخصية</strong\n        ><strong><em>: </em></strong><strong>البيانات</strong>\n        <strong>الشخصية</strong>\n      </p>\n      <p>\n        قد نقوم بجمع معلومات التعريف الشخصية من المستخدمين بطرق متنوعة، بما في\n        ذلك وعلى سبيل المثال لا الحصر، عندما يزور المستخدمون موقعنا ويسجلون\n        دخولهم على الموقع، وفيما يتعلق بأنشطة أو خدمات أو ميزات أو موارد أخرى\n        نوفرها على موقعنا/التطبيق. قد يُطلب من المستخدمين، حسب الاقتضاء، الاسم\n        وعنوان البريد الإلكتروني ومعلومات بطاقة الائتمان. ومع ذلك، يجوز\n        للمستخدمين زيارة موقعنا/تطبيقنا بشكل مجهول. سنقوم بجمع معلومات التعريف\n        الشخصية من المستخدمين فقط إذا قاموا بتقديم هذه المعلومات لنا طوعاً. يمكن\n        للمستخدمين دائمًا رفض تقديم معلومات تحديد الهوية الشخصية باستثناء أنها\n        قد تمنعهم من المشاركة في أنشطة معينة متعلقة بالموقع/التطبيق.\n      </p>\n      <p>\n        <strong><em>2- </em></strong><strong>معلومات</strong>\n        <strong>التعريف</strong> <strong>غير</strong> <strong>الشخصية</strong\n        ><strong><em>: </em></strong><strong>بيانات</strong>\n        <strong>الاستخدام</strong>\n      </p>\n      <p>\n        قد نقوم بجمع معلومات التعريف غير الشخصية عن المستخدمين كلما تفاعلوا مع\n        موقعنا/تطبيقنا. قد تتضمن معلومات التعريف غير الشخصية اسم المتصفح ونوع\n        الكمبيوتر والمعلومات التقنية حول وسيلة اتصال المستخدمين بموقعنا/تطبيقنا،\n        مثل نظام التشغيل وموفري خدمة الإنترنت ومعلومات أخرى مماثلة.\n      </p>\n      <p>\n        <strong><em>3- </em></strong><strong>ملفات</strong>\n        <strong>تعريف</strong> <strong>ارتباط</strong> <strong>متصفح</strong>\n        <strong>الويب</strong>\n      </p>\n      <p>\n        قد يستخدم موقعنا/التطبيق \"ملفات تعريف الارتباط\" لتحسين تجربة المستخدم.\n        يضع متصفح الويب الخاص بالمستخدم ملفات تعريف الارتباط على محرك الأقراص\n        الثابتة لأغراض حفظ السجلات، وفي بعض الأحيان يتتبع المعلومات عنها. قد\n        يختار المستخدم تعيين متصفح الويب الخاص به لرفض ملفات تعريف الارتباط، أو\n        لتنبيهك عند إرسال ملفات تعريف الارتباط. إذا قاموا بذلك، فبعض أجزاء\n        الموقع/التطبيق قد لا تعمل بشكل صحيح.\n      </p>\n      <p>\n        <strong><em>4- </em></strong><strong>كيف</strong>\n        <strong>نستخدم</strong> <strong>البيانات</strong> <strong>التي</strong>\n        <strong>تم</strong> <strong>جمعها</strong>\n      </p>\n      <p>\n        يمكن لأنغامي أن تجمع وان تستخدم المعلومات الشخصية للمستخدمين للأغراض\n        التالية:\n      </p>\n      <ul>\n        <li>\n          لتحسين خدمة العملاء: تساعدنا المعلومات التي تقدمها على الاستجابة\n          لطلبات خدمة العملاء واحتياجات الدعم بشكل أكثر كفاءة.\n        </li>\n        <li>\n          لإضفاء طابعٍ شخصيٍّ على تجربة المستخدم: قد نستخدم المعلومات في المجمل\n          لفهم كيفية استخدام مستخدمينا كمجموعةٍ للخدمات والموارد المتوفرة على\n          موقعنا/تطبيقنا.\n        </li>\n        <li>\n          لتحسين موقعنا/تطبيقنا: قد نستخدم التعليقات التي تقدمها لتحسين منتجاتنا\n          وخدماتنا.\n        </li>\n        <li>\n          لتسيير الدفعات: قد نستخدم المعلومات التي يقدمها المستخدمون عن أنفسهم\n          عند تقديم طلب فقط لتوفير الخدمة لهذا الطلب. نحن لا نشارك هذه المعلومات\n          مع أطراف خارجية إلا بالقدر اللازم لتقديم الخدمة.\n        </li>\n        <li>\n          للقيام بعرضٍ ترويجيٍّ أو مسابقةٍ أو استبيان أو ميزة أخرى\n          للموقع/التطبيق: لإرسال معلومات للمستخدمين قد وافقوا على تلقيها حول\n          المواضيعٍ نعتقد أنها ستثير اهتمامهم. لإرسال رسائل البريد الإلكتروني\n          الدوري لهم يجوز ان نستخدم عنوان البريد الإلكتروني لإرسال معلومات\n          المستخدم والتحديثات المتعلقة بطلبه. كما يمكن استخدامه للرد على\n          استفساراتهم وأسئلتهم و/أو طلباتهم الأخرى. إذا قرر المستخدم الاشتراك في\n          قائمتنا البريدية، فسوف يتلقى رسائل البريد الإلكتروني التي قد تتضمن\n          أخبار الشركة والتحديثات والمعلومات ذات الصلة بالمنتج أو الخدمة وما إلى\n          ذلك. إذا أراد المستخدم في أي وقتٍ إلغاء الاشتراك من تلقي رسائل البريد\n          الإلكتروني المستقبلية، يمكنه أن يجد تعليمات إلغاء الاشتراك في أسفل كل\n          بريد إلكتروني أو يمكن للمستخدم الاتصال بنا عبر موقعنا/التطبيق.\n        </li>\n      </ul>\n      <p>\n        <strong><em>5- </em></strong><strong>كيف</strong> <strong>نحمي</strong>\n        <strong>بياناتك</strong>\n      </p>\n      <p>\n        <strong>أ-</strong> نحن نستخدم طرقاً مناسبة لجمع البيانات وتخزينها\n        ومعالجتها وتدابير الأمن لحمايتها من الوصول اليها الغير المصرح به أو\n        التغيير أو الإفصاح أو إتلاف معلوماتك الشخصية واسم المستخدم وكلمة المرور\n        ومعلومات المعاملات والبيانات المخزنة على موقعنا/تطبيقنا.\n      </p>\n      <p>\n        يتم إجراء تبادل البيانات الحساسة والخاصة بين الموقع/التطبيق ومستخدميه\n        عبر قناة اتصال مؤمنة بواسطة طبقة الوصلات الآمنة SSL ويتم تشفيرها\n        وحمايتها بالتوقيعات الرقمية.\n      </p>\n      <p>\n        <strong>ب-</strong> الأساس القانوني لمعالجة البيانات الشخصية بموجب\n        القاعدة العامة لحماية البيانات (GDPR):\n      </p>\n      <p>\n        إذا كنت من المنطقة الاقتصادية الأوروبية (EEA)، يعتمد الأساس القانوني\n        لأنغامي لجمع واستخدام المعلومات الشخصية الموضحة في سياسة الخصوصية هذه\n        على البيانات الشخصية التي نجمعها والسياق المحدد الذي نجمعها فيه. إذا كنت\n        مقيماً في المنطقة الاقتصادية الأوروبية، فلديك حقوق حماية معينة للبيانات.\n        نهدف إلى اتخاذ خطوات معقولة تسمح لك بتصحيح أو تعديل أو حذف أو تحديد\n        استخدام بياناتك الشخصية. إذا كنت ترغب في أن تكون على علم بالبيانات\n        الشخصية التي نحتفظ بها عنك، وإذا كنت تريد إزالتها من أنظمتنا، فالرجاء\n        الاتصال بنا.\n      </p>\n      <p>قد تقوم أنغامي بمعالجة بياناتك الشخصية للأسباب التالية:</p>\n      <ul>\n        <li>نحن بحاجة إلى انجاز عقدٍ معك</li>\n        <li>لقد منحتنا الإذن للقيام بذلك</li>\n        <li>التجهيز ضمن مصلحتنا المشروعة ولا يتم تجاوزه من خلال حقوقك</li>\n        <li>لأغراض تسيير الدفع</li>\n        <li>للامتثال أمام القانون</li>\n      </ul>\n      <p>في بعض الحالات، لديك حقوق حماية البيانات التالية:</p>\n      <ul>\n        <li>\n          <strong\n            >الحق في الولوج إلى المعلومات الموجودة لدينا أو تحديثها أو\n            حذفها</strong\n          >. حين يتاح ذلك، يمكنك الولوج إلى بياناتك الشخصية أو تحديثها أو طلب\n          حذفها مباشرةً داخل قسم الإعدادات في الحسابك. إذا كنت غير قادرٍ على\n          تنفيذ هذه الإجراءات بنفسك، فالرجاء الاتصال بنا لمساعدتك.\n        </li>\n        <li>\n          <strong>حق التصحيح.</strong> لك الحق في تصحيح معلوماتك إذا كانت تلك\n          المعلومات غير دقيقة أو غير كاملة.\n        </li>\n        <li>\n          <strong>الحق في الاعتراض</strong>. لديك الحق في الاعتراض على معالجة\n          بياناتك الشخصية من قبلنا.\n        </li>\n        <li>\n          <strong>حق التحديد.</strong> لديك الحق في أن تطالبنا بتحديد معالجة\n          معلوماتك الشخصية.\n        </li>\n        <li>\n          <strong>الحق في قابلية نقل البيانات</strong>. لديك الحق في أن يتم\n          تزويدك بنسخة من المعلومات التي نملكها عنك بصيغة منظمة، ويمكن قراءتها\n          آليًا وشكلٍ يمكن استخدامه بطريقةٍ شائعة.\n        </li>\n        <li>\n          <strong>الحق في سحب الموافقة</strong>. كما يحق لك أيضًا سحب موافقتك في\n          أي وقت تعتمد فيه أنغامي على موافقتك على معالجة معلوماتك الشخصية.\n        </li>\n      </ul>\n      <p>\n        يرجى الأخذ بالعلم بأننا قد نطلب منك التحقق من هويتك قبل الرد على هذه\n        الطلبات.\n      </p>\n      <p>\n        لك الحق في تقديم شكوى إلى هيئة حماية البيانات حول جمع بياناتك الشخصية\n        واستخدامها من قبلنا. لمزيد من المعلومات، يرجى الاتصال بسلطة حماية\n        البيانات المحلية في المنطقة الاقتصادية الأوروبية (EEA).\n      </p>\n      <p>\n        <strong><em>6- </em></strong><strong>الاحتفاظ</strong>\n        <strong>ببياناتك</strong>\n      </p>\n      <p>\n        سنحتفظ ببياناتك الشخصية فقط طالما هي ضرورية للأغراض المنصوص عليها في\n        سياسة الخصوصية هذه. سوف نحتفظ ببياناتك الشخصية ونستخدمها بالقدر اللازم\n        للامتثال بالتزاماتنا وبسياساتنا القانونية. سوف نحتفظ أيضًا ببيانات\n        الاستخدام لأغراض التحليل الداخلي. يتم الاحتفاظ ببيانات الاستخدام بصفة\n        عامة لفترة زمنية أقصر، باستثناء عندما يتم استخدام هذه البيانات لتعزيز\n        الأمن أو لتحسين وظائف خدمتنا، أو أننا ملزمون قانونًا بالاحتفاظ بهذه\n        البيانات لفترات زمنية أطول.\n      </p>\n      <p>\n        <strong><em>7- </em></strong><strong>مشاركة</strong>\n        <strong>البيانات</strong> <strong>الخاصة</strong> <strong>بك</strong>\n      </p>\n      <p>\n        نحن لا نبيع أو نتاجر أو نؤجر معلومات التعريف الشخصية للمستخدمين للآخرين.\n        قد نشارك معلومات ديموغرافية مجمعة عامةً وغير مرتبطة بأية معلومات تعريف\n        شخصية تتعلق بالزائرين والمستخدمين مع شركائنا التجاريين والشركات التابعة\n        الموثوقة والشركات المعلنة للأغراض الموضحة أعلاه. قد نستخدم مزودي خدمات\n        من أطراف ثالثة لمساعدتنا في تشغيل أعمالنا وموقعنا/تطبيقاتنا أو إدارة\n        الأنشطة نيابة عنا، مثل إرسال رسائل إخبارية أو استطلاعات. يجوز لنا مشاركة\n        معلوماتك مع هذه الجهات الخارجية لتلك الأغراض المحدودة بشرط أن تمنحنا\n        موافقتك.\n      </p>\n      <p>\n        <strong><em>8- </em></strong><strong>حماية</strong>\n        <strong>الأطفال</strong>\n      </p>\n      <p>\n        إذا كنت من المنطقة الاقتصادية الأوروبية (EEA) وعمرك أقل من 16 عامًا،\n        فيجب أن تزودنا بموافقة الوالدين. إذا كنت والدًا أو وصيًا وكنت على دراية\n        بأن أطفالك، الذين تقل أعمارهم عن 16 عامًا، قد زودونا ببيانات شخصية، نرجو\n        منك الاتصال بنا. إذا علمنا بأننا جمعنا بياناتٍ شخصية من أولاد دون سن 16\n        عامًا، من دون التحقق من موافقة الوالدين، فإننا نتّخذ خطواتٍ لإزالة تلك\n        المعلومات من خوادمنا.\n      </p>\n      <p>\n        <strong><em>9- </em></strong><strong>اي</strong> <strong>تيونز</strong\n        ><strong><em>: </em></strong><strong>الدفع</strong>\n        <strong>للشراء</strong> <strong>داخل</strong> <strong>التطبيق</strong>\n      </p>\n      <ul>\n        <li>سيتم خصم الدفع من حساب اي تيونز iTunes عند تأكيد الشراء</li>\n        <li>\n          يتم تجديد الاشتراك تلقائياً ما لم يتم إيقاف التجديد التلقائي قبل 24\n          ساعة على الأقل من نهاية الفترة الحالية\n        </li>\n        <li>\n          سيتم تحميل رسم تجديد الحساب خلال 24 ساعة قبل نهاية الفترة الحالية،\n          وتحديد تكلفة التجديد\n        </li>\n        <li>\n          يمكن إدارة الاشتراكات من قبل المستخدم ويجوز إيقاف التشغيل التلقائي عن\n          طريق الانتقال إلى إعدادات حساب المستخدم بعد الشراء\n        </li>\n        <li>\n          ان أي جزء غير مستخدم من الفترة التجريبية المجانية، إذا تم عرضه، تتم\n          خسارته عندما يشترك المستخدم اشتراكًا في هذا الاعلان، حيثما ينطبق ذلك\n        </li>\n      </ul>\n      <p>\n        <strong><em>10- </em></strong><strong>التغييرات</strong>\n        <strong>في</strong> <strong>سياسة</strong> <strong>الخصوصية</strong>\n        <strong>هذه</strong>\n      </p>\n      <p>\n        لدى أنغامي القدرة على تحديث سياسة الخصوصية هذه في أي وقت. عندما نقوم\n        بذلك، سنقوم بمراجعة التاريخ المحدث في أسفل هذه الصفحة. نشجع المستخدمين\n        على التحقق من هذه الصفحة بشكل متكرر لمعرفة أي تغييرات وللبقاء على اطلاع\n        على كيفية قيامنا بالمساعدة في حماية المعلومات الشخصية التي نجمعها. أنت\n        تقر وتوافق اذ أنه من مسؤوليتك مراجعة سياسة الخصوصية هذه بشكل دوري وأن\n        تصبح على علمٍ بالتعديلات.\n      </p>\n      <p>\n        <strong\n          >ب- إخطار وإجراءات تقديم المطالبات بحقوق التأليف والنشر أو غيرها من\n          انتهاكات الملكية الفكرية.</strong\n        >\n      </p>\n      <p>\n        <strong>(أ)</strong> تحترم أنغامي الملكية الفكرية للآخرين وتأخذ حماية\n        حقوق التأليف والنشر وجميع حقوق الملكية الفكرية على محمل الجد، ونطلب من\n        مستخدمينا أن يفعلوا الشيء ذاته. لن يتم السماح بالنشاط المخالف على أو من\n        خلال موقع أو خدمة أنغامي.\n      </p>\n      <p>\n        <strong>(ب)</strong> ان سياسة أنغامي للملكية الفكرية هي (1) إزالة المواد\n        التي تعتقد أنغامي بأنها، بكل حسن نية، وبناءًا على إشعارٍ من مالك الملكية\n        الفكرية أو وكيله، تنتهك الملكية الفكرية لطرف ثالث عن طريق إتاحتها عبر\n        الموقع، و (2) إزالة أي منتجات أو ملفات مرسلة معروضة على الموقع بواسطة\n        المتعدين المتكررين. تعتبر أنغامي منتهكًا متكرراً أي مستخدم قد قام بتحميل\n        منتجات أو ملفّات إلى الخدمة وقد تلقّت أنغامي أكثر من إخطارين بالإزالة\n        متوافقين مع أحكام 17 U.S.C 512 &sect;(ج) فيما يتعلق بمثل هذه المنتجات أو\n        الملفّات. ومع ذلك، تملك أنغامي حرّية التصرّف لإنهاء حساب أي مستخدم بعد\n        استلام إخطار واحد بحدوث انتهاكٍ مزعوم أو بناءًا على قرار أنغامي نفسه.\n      </p>\n      <p>\n        <strong>(ج) إجراءات الإبلاغ عن التعدي المطالب به. </strong>إذا كنت تعتقد\n        أن أية انتاجات أو ملفّات إرسال متوفرة على الموقع أو من خلاله أو أنه قد\n        تم استخدام خدمة أنغامي أو استغلالها بطريقةٍ تنتهك حقوق الملكية الفكرية\n        التي تمتلكها أو تتحكم بها، فيرجى على الفور إرسال \"إخطار بالتعدي المطالب\n        به\" يتضمّن المعلومات التالية إلى الوكيل المعين المحددة أدناه. ويجب أن\n        تتضمن رسالتك المعلومات التالية:\n      </p>\n      <ul>\n        <li>\n          (1) توقيع طبيعي أو إلكتروني لشخصٍ مخولٍ بالتصرف نيابة عن مالك العمل\n          (أو الأعمال) المزعوم انتهاكه/ها؛\n        </li>\n        <li>\n          (2) تحديد الأعمال أو المواد التي تم التعدي عليها، أو إذا كان هناك\n          أعمال متعددة مشمولة بإشعار واحد يجب تحديد قائمة تمثيلية لتلك الأعمال؛\n        </li>\n        <li>\n          (3) تحديد المادة المحددة التي يُزعم أنها منتهكة أو موضوعًا للنشاط\n          المخالف والتي يجب إزالتها أو تعطيل الوصول إليها، بالاضافة الى معلومات\n          كافية بشكل معقول للسماح لأنغامي بتحديد موقع المادة؛\n        </li>\n        <li>\n          (4) تزويد معلومات كافية بشكل معقول للسماح لأنغامي بالاتصال بك، مثل\n          العنوان ورقم الهاتف، وعنوان البريد الإلكتروني إذا كان متاحًا للاتصال\n          بك؛\n        </li>\n        <li>\n          (5) إقرارٌ بأنك تعتقد، وبكل حسن نية، بأن استخدام المادة بالطريقة\n          المشكوك بها غير مصرح به من قبل مالك حقوق النشر أو وكيله أو القانون؛ و\n        </li>\n        <li>\n          (6) اقرارٌ بأن المعلومات الواردة في الإشعار دقيقة، وتحت طائلة عقوبة\n          شهادة الزور، بأنك مفوض بالتصرف نيابةً عن مالك الحق الحصري المزعوم\n          انتهاكه.\n        </li>\n      </ul>\n      <p>\n        يجب عليك استشارة محاميك و/أو الاطلاع على 17 U.S.C 512 &sect; لتأكيد\n        التزاماتك بتقديم إشعار صالح بالانتهاك المطالب به.\n      </p>\n      <p>\n        <strong>(د) معلومات الاتصال بالوكيل المعين. </strong>يمكن الاتصال بوكيل\n        أنغامي المعين لإشعارات الانتهاك المزعوم عبر:\n      </p>\n      <ul>\n        <li>\n          عبر البريد الالكتروني:\n          <a href=\"mailto:legal@anghami.com\">legal@anghami.com</a>\n        </li>\n        <li>\n          عبر البريد الأميركي: مبنى زردمان، الطابق الخامس، جل الديب، لبنان\n        </li>\n      </ul>\n      <p>\n        <strong>(ه) الإشعار المضاد. </strong>إذا تلقيت إخطارًا من أنغامي بأن\n        المواد التي تتيحها على الموقع أو من خلاله أو عبر خدمة أنغامي هي موضوعًا\n        للإشعار بالانتهاك المطالب به، يكون لك الحق في تزويد أنغامي بما يسمى\n        بالإشعار المضاد. لكي يكون هذا الاشعار فعّالاً يجب أن يكون خطّيّاً شرط أن\n        يكون الوكيل المعين من قبل أنغامي من خلال إحدى الطرق المحددة في القسم ب\n        (د) من شروط الخدمة هذه، ويتضمن المعلومات التالية بشكل واضح:\n      </p>\n      <ul>\n        <li>(1) توقيع طبيعي أو إلكتروني للمشترك؛</li>\n        <li>\n          (2) تحديد الأعمال التي تم حذفها أو التي تم تعطيل الوصول إليها،\n          بالاضافة الى المكان حيث ظهرت الأعمال قبل أن يتم حذفها أو تعطيل الوصول\n          اليها؛\n        </li>\n        <li>\n          (3) اقرارٌ تحت طائلة عقوبة شهادة الزور بأنه لدى المشترك قناعة ذات حسن\n          نيّة بأنه تم حذف أو تعطيل الوصول الى الأعمال نتيجةً لخطأ أو التعريف\n          الخاطئ عن المادة المراد إزالتها أو تعطيلها؛ و\n        </li>\n        <li>\n          (4) اسم المشترك، عنوانه، رقم هاتفه، واقرارٌ بأن المشترك يوافق على\n          اختصاص محكمة المقاطعة الفيدرالية في الدائرة القضائية التي يقع فيها\n          العنوان، أو إذا كان عنوان المشترك خارج الولايات المتحدة، فاختصاص\n          المحاكم المدنية في بيروت/لبنان، وبأن المشترك سيقبل بخدمة العملية من\n          الشخص الذي قدّم إخطارًا بموجب القسم ب (ج) من بنود الخدمة المذكورة\n          أعلاه أو وكيلاً لهذا الشخص.\n        </li>\n      </ul>\n      <p>\n        يجب على الطرف مقدّم الاشعار المضاد استشارة محامٍ و/أو الاطلاع على 17\n        U.S.C 512 &sect; لتأكيد التزامات الطرف بتقديم إشعار صالح بموجب قانون\n        حقوق الطبع والنشر.\n      </p>\n      <p>\n        <strong\n          >(و) إخطارات كاذبة بالانتهاك المطالب به أو الإشعارات المضادة. </strong\n        >ينص قانون حقوق الطبع والنشر على ما يلي:\n      </p>\n      <ul>\n        <li>\n          ان أيّ شخصٍ يقدم بصورة خاطئة فعليًا بموجب المادة [512 من قانون حقوق\n          الطبع والنشر (17 U.S.C 512 &sect;)] (1) أن مادةً أو نشاطًا ما يمثل\n          انتهاكًا، أو (2) انّه تمت إزالة مادة أو نشاط أو تعطيله عن طريق الخطأ\n          أو التعريف الخاطئ، يكون مسؤولاً عن أي أضرار، بما في ذلك التكاليف\n          وأتعاب المحاماة التي يتكبدها المتعدي المزعوم من قبل أي مالك حقوق نشر\n          أو طرف مرخص له من قبل مالك حقوق النشر، أو من قبل مقدم الخدمة الذي أصيب\n          بهذا التحريف نتيجةً لاعتماد أنغامي على ذلك التحريف في إزالة أو تعطيل\n          الوصول إلى المادة أو النشاط المزعوم انتهاكه، أو عبر استبدال المواد\n          التي تمت إزالتها أو التوقف عن تعطيل الوصول إليها.\n        </li>\n      </ul>\n      <p>\n        17 U.S.C 512 &sect;(و). تحتفظ أنغامي بحق المطالبة بتعويضات من أي جهة\n        تقدم إخطارًا بانتهاك مزعوم أو إشعار مضاد ينتهك القانون. لتجنب الشك، يجب\n        إرسال الإشعارات فقط المقدمة بموجب قانون الألفية الجديدة لحقوق طبع ونشر\n        المواد الرقمية والإجراءات المنصوص عليها في هذا القسم ج إلى الوكيل المعين\n        في البريد الإلكتروني أو العنوان البريدي المذكور أعلاه. كما يجب إرسال أية\n        تعليقات أو مجاملات أو شكاوى أو اقتراحات أخرى عن أنغامي أو عن تشغيل\n        الموقع أو خدمة أنغامي أو أية مسألة أخرى إلى\n        <a href=\"mailto:info@anghami.com\">info@anghami.com</a>.\n      </p>\n      <p><strong>موافقتك على هذه الشروط</strong></p>\n      <p>\n        عبر استخدام هذا الموقع/التطبيق، تكون قد وافقت على هذه السياسة. إذا كنت\n        لا توافق على هذه السياسة، يرجى عدم استخدام موقعنا/التطبيق. ان استمرارك\n        الدائم في استخدام الموقع/التطبيق بعد عرض التعديلات على هذه السياسة يعتبر\n        موافقة من قبلك على هذه التغييرات.\n      </p>\n      <p><strong>للاتّصال بنا</strong></p>\n      <p>أنغامي <a href=\"http://www.anghami.com\">www.anghami.com</a></p>\n      <p>لبنان: مبنى زردمان، الطابق الخامس، جل الديب</p>\n      <p>\n        الامارات العربيّة المتّحدة: دبي انترنت سيتي - مبنى رقم ١ - مكتب رقم ٢١١\n      </p>\n      <p><span dir=\"ltr\">+961 4 719446</span></p>\n      <p><a href=\"mailto:info@anghami.com\">info@anghami.com</a></p>\n      <p>لقد تم آخر تحديث لهذا المستند في 24 أيّار 2018</p>\n    </div>\n  </div>\n</section>\n"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: -webkit-gradient(linear, left top, right top, from(#e03f8d), color-stop(#a22ccf), to(#2fa0df));\n  background: linear-gradient(to right, #e03f8d, #a22ccf, #2fa0df);\n  height: 30em;\n  background-size: cover !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    height: auto;\n    min-height: 15em;\n  }\n}\n:host .header.pringles {\n  background-size: cover !important;\n  background-position: center !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header.extra .title {\n  width: 60%;\n  margin: auto;\n}\n:host .header .logo {\n  max-width: 5em;\n  display: block;\n  margin: 1em auto;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n  }\n}\n:host .header .subtitle {\n  font-size: 1.2rem;\n  margin: auto;\n  font-weight: 200;\n  text-align: center;\n  padding-top: 0.5em;\n}\n@media (max-width: 768px) {\n  :host .header .subtitle {\n    width: 85%;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.ts ***!
  \************************************************************************/
/*! exports provided: InnerHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderComponent", function() { return InnerHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/mobile-detection.service */ "./src/app/core/services/mobile-detection.service.ts");



let InnerHeaderComponent = class InnerHeaderComponent {
    constructor(_mobileDetection, locale) {
        this._mobileDetection = _mobileDetection;
        this.locale = locale;
        this.locale =
            this.locale && this.locale !== null
                ? this.locale.indexOf('en') > -1
                    ? 'en'
                    : this.locale
                : 'en';
    }
    ngOnInit() {
        this._mobileDetection.verticalScreen.subscribe(isVertical => {
            if (this.backgroundHeader.mainimagemobile) {
                const image = isVertical
                    ? this.backgroundHeader.mainimagemobile
                    : this.backgroundHeader.mainimage;
                this.setBackgroundImage(image, this.backgroundHeader.backgroundcolor);
            }
        });
    }
    setBackgroundImage(img, color) {
        const backgroundcolor = color && color !== null && color !== ''
            ? color
            : 'linear-gradient(to right, #E03F8D, #A22CCF, #2FA0DF)';
        this.backgroundimage = Object.assign({}, this.backgroundimage, { background: 'url(' +
                img +
                ') 0% 0%,' + backgroundcolor });
    }
    ngOnChanges() {
        if (this.backgroundHeader && this.backgroundHeader !== null) {
            if (this.backgroundHeader.mainimage) {
                this.backgroundimage = {
                    'background-size': 'cover',
                };
                this.setBackgroundImage(this.backgroundHeader.mainimage);
            }
            if (this.backgroundHeader.type) {
                const headerElt = document.getElementById('headerid');
                if (headerElt && headerElt !== null) {
                    headerElt.classList.add(this.backgroundHeader.type);
                }
            }
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('backgroundHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "backgroundHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('smallerHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "smallerHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "isWave", void 0);
InnerHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-inner-header',
        template: __webpack_require__(/*! raw-loader!./inner-header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html"),
        styles: [__webpack_require__(/*! ./inner-header.component.scss */ "./src/app/core/components/inner-header/inner-header.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__["MobileDetectionService"], String])
], InnerHeaderComponent);



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.module.ts ***!
  \*********************************************************************/
/*! exports provided: InnerHeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderModule", function() { return InnerHeaderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.component */ "./src/app/core/components/inner-header/inner-header.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");





let InnerHeaderModule = class InnerHeaderModule {
};
InnerHeaderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__["PipesModule"]],
        declarations: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        exports: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], InnerHeaderModule);



/***/ }),

/***/ "./src/app/core/services/mobile-detection.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/services/mobile-detection.service.ts ***!
  \***********************************************************/
/*! exports provided: MobileDetectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileDetectionService", function() { return MobileDetectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");





let MobileDetectionService = class MobileDetectionService {
    constructor(_cookie, utils) {
        this._cookie = _cookie;
        this.utils = utils;
        this.verticalScreen = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"]();
        if (this.utils.isBrowser()) {
            this.detectVerticalScreen();
            window.addEventListener('resize', () => {
                this.resizeThrottler();
            }, false);
        }
    }
    resizeThrottler() {
        if (this.utils.isBrowser()) {
            if (!this.resizeTimeout) {
                this.resizeTimeout = setTimeout(() => {
                    this.resizeTimeout = null;
                    this.detectVerticalScreen();
                }, 200);
            }
        }
    }
    detectVerticalScreen() {
        this.device = this._cookie.get('device');
        const width = window.innerWidth < 768 ? true : false;
        const ismobile = this.device && (this.device === 'android' || this.device === 'ios')
            ? true
            : false;
        this.verticalScreen.next(width || ismobile ? true : false);
    }
    getVerticalScreen() {
        return this.verticalScreen.asObservable();
    }
};
MobileDetectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_cookie__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
], MobileDetectionService);



/***/ }),

/***/ "./src/app/modules/landing/legal/legal-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/modules/landing/legal/legal-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: LegalRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LegalRoutingModule", function() { return LegalRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _legal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./legal.component */ "./src/app/modules/landing/legal/legal.component.ts");




const routes = [
    {
        path: '',
        component: _legal_component__WEBPACK_IMPORTED_MODULE_3__["LegalComponent"]
    }
];
let LegalRoutingModule = class LegalRoutingModule {
};
LegalRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], LegalRoutingModule);



/***/ }),

/***/ "./src/app/modules/landing/legal/legal.component.scss":
/*!************************************************************!*\
  !*** ./src/app/modules/landing/legal/legal.component.scss ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".arabic-legal {\n  text-align: right;\n}"

/***/ }),

/***/ "./src/app/modules/landing/legal/legal.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/landing/legal/legal.component.ts ***!
  \**********************************************************/
/*! exports provided: LegalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LegalComponent", function() { return LegalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LegalComponent = class LegalComponent {
    constructor(locale) {
        this.locale = locale;
        this.innerHeader = [];
        this.innerHeader.mainimage =
            'https://anghamiwebcdn.akamaized.net/assets/img/legal.jpg';
    }
    ngOnInit() { }
};
LegalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-legal',
        template: __webpack_require__(/*! raw-loader!./legal.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/legal/legal.component.html"),
        styles: [__webpack_require__(/*! ./legal.component.scss */ "./src/app/modules/landing/legal/legal.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
], LegalComponent);



/***/ }),

/***/ "./src/app/modules/landing/legal/legal.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/modules/landing/legal/legal.module.ts ***!
  \*******************************************************/
/*! exports provided: LegalModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LegalModule", function() { return LegalModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _legal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./legal.component */ "./src/app/modules/landing/legal/legal.component.ts");
/* harmony import */ var _legal_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./legal-routing.module */ "./src/app/modules/landing/legal/legal-routing.module.ts");
/* harmony import */ var _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.module */ "./src/app/core/components/inner-header/inner-header.module.ts");






let LegalModule = class LegalModule {
};
LegalModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_legal_component__WEBPACK_IMPORTED_MODULE_3__["LegalComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _legal_routing_module__WEBPACK_IMPORTED_MODULE_4__["LegalRoutingModule"], _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_5__["InnerHeaderModule"]]
    })
], LegalModule);



/***/ })

}]);