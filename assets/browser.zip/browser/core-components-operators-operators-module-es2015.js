(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["core-components-operators-operators-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/button/button.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "  <a \n  class=\"anghami_btn {{layout}} {{size}}\"\n  (click)=\"clickHandler($event)\"\n  [href]=\"link\"\n  [attr.target]=\"target\"\n  [class.loading]=\"loading\">\n  <span *ngIf=\"!loading\">\n    {{label_locale}}\n  </span>\n    \n    <div class=\"spinner-border text-light\" role=\"status\" *ngIf=\"loading\">\n      <span class=\"sr-only\">Loading...</span>\n    </div>\n  </a>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/operators/operators.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/operators/operators.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<img src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/plus/left_corner.png\" class=\"left-corner\">\n<img src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/plus/right_corner.png\" class=\"right-corner\"> \n<div class=\"header\" id=\"subscribeId\">\n  <h1 class=\"pluslogo\">\n    <span i18n=\"@@Anghami\">Anghami</span>&nbsp;<span i18n=\"@@Plus\" class=\"highlight\">Plus</span>\n  </h1>\n  <div class=\"title\">{{ plan?.title }}</div>\n  <div class=\"subtitle\">{{ plan?.subtitle }}</div>\n</div>\n<anghami-benefits\n  class=\"features-top\" [display]=\"'main'\"\n  [title]=\"null\"\n  [benefits]=\"visibleFeaturesLst\"\n  [actualSize]=\"featuresLst.length\"\n  (showMore)=\"goToBenefits()\"\n></anghami-benefits>\n<div class=\"flexbox colls mw-100 ar\">\n  <anghami-white-box\n    [notice]=\"isNotice || initialloading\"\n    [loading]=\"initialloading\"\n    class=\"h-100 w-100 ang-white-box\"\n    [ngClass]=\"{'operator': (step==='operator'), 'sms': isSms, 'loading': initialloading, 'error': isError}\"\n  >\n    <ng-container *ngIf=\"!initialloading\">\n      <ng-container *ngIf=\"!isError\">\n        <div class=\"flexbox colls\" [ngClass]=\"{'start': isSms}\">\n          <div class=\"sms-details\" *ngIf=\"(step==='verifycode')\">\n            <span i18n=\"@@We sent an SMS to\">We sent an SMS to</span> +{{ phoneValidations?.countrycode }}{{ mobilenumber }} -\n            <a (click)=\"resend()\" i18n=\"@@Send Again\" [ngClass]=\"{'disabled': (disabledTimer>0)}\">Send again</a><span *ngIf=\"disabledTimer>0&&disabledTimer<60\" class=\"timer\">{{ disabledTimer }}</span>\n          </div>\n          <div class=\"flexbox start vertical\" [ngClass]=\"{'w-100': isSms, 'redirect': (redirectUrl && redirectUrl !== '') }\">\n            <div class=\"flexbox middle w-100 minw-30\"\n              [ngClass]=\"{'justify-start': isSms, 'between': (step==='verifycode'), 'mb-2': (redirectUrl && redirectUrl !== ''), 'colls': (redirectUrl !== '' && noticeErr !== '')}\">\n              <img class=\"logo\" [src]=\"plan?.bigimage\">\n              <div *ngIf=\"isSms; then smsOperator else defaultOperator\"></div>\n              <ng-template #defaultOperator>\n                <div class=\"flexbox colls start w-100\" *ngIf=\"redirectUrl === ''\">\n                  <div class=\"flexbox middle num-wrap\">\n                    <ng-container *ngIf=\"step === 'operator'\">\n                      <span\n                        class=\"prefix\"\n                      >+{{ phoneValidations?.countrycode }}\n                      </span>\n                      <input\n                        *ngIf=\"isDeviceMobile\"\n                        type=\"tel\" pattern=\"^[0-9]*$\"\n                        [maxLength]=\"phoneValidations?.max_digits\"\n                        required\n                        id=\"phonenumid\"\n                        #phonenumElt\n                        class=\"hidden-input form-control p-0 h-100 mobilenum\"\n                        placeholder=\"{{msidninputPlaceholder}}\"\n                        [(ngModel)]=\"mobilenumber\"\n                        (ngModelChange)=\"clearError()\"\n                      />\n                      <input\n                        *ngIf=\"!isDeviceMobile\"\n                        class=\"hidden-input form-control p-0 h-100 mobilenum\"\n                        placeholder=\"{{msidninputPlaceholder}}\"\n                        id=\"phonenumid\"\n                        #phonenumElt\n                        [(ngModel)]=\"mobilenumber\"\n                        (ngModelChange)=\"clearError()\"\n                        (keypress)=\"handleConditions($event, 'operator')\"\n                      />\n                    </ng-container>\n                    <ng-container *ngIf=\"step === 'verifycode'\">\n                      <!--\n                        (keypress)=\"handleOnlyPositiveInt($event);handleVerificationNumLength($event)\"\n                      -->\n                      <input \n                        *ngIf=\"!isDeviceMobile\"\n                        class=\"hidden-input form-control p-0 h-100 mobilenum verify-code\"\n                        placeholder=\"{{codeinputPlaceholder}}\"\n                        id=\"verificationid\"\n                        #verificationElt\n                        [(ngModel)]=\"code\"\n                        (ngModelChange)=\"clearError()\"\n                      >\n                      <input\n                        type=\"tel\" pattern=\"\\d*\"\n                        [maxLength]=\"10\" \n                        *ngIf=\"isDeviceMobile\"\n                        class=\"hidden-input form-control p-0 h-100 mobilenum verify-code\"\n                        placeholder=\"{{codeinputPlaceholder}}\"\n                        id=\"verificationid\"\n                        #verificationElt\n                        [(ngModel)]=\"code\"\n                        (ngModelChange)=\"clearError()\"> \n                    </ng-container>\n                  </div>\n                  <div class=\"err\">{{ errmsg }}</div>\n                </div>\n                <div class=\"noticeErr pt-2\" *ngIf=\"redirectUrl !== '' && noticeErr !== ''\">\n                  {{ noticeErr }}\n                </div>\n              </ng-template>\n              <ng-template #smsOperator>\n                <div class=\"sms-wrap\">\n                  <span i18n=\"@@Send\">Send&nbsp;</span><span [ngStyle]=\"{'color': plan.color}\"> {{plan.smstext}} </span><span i18n=\"@@To\">to</span><span class=\"bold\" [ngStyle]=\"{'color': plan.color}\">&nbsp;{{plan.sms}}</span>\n                </div>\n              </ng-template>\n            </div>\n            <ng-container *ngIf=\"!isSms\">\n              <div class=\"my-2\">\n                <ng-container *ngIf=\"noticeErr === ''\">\n                  <div class=\"ang-operator-btn\"\n                    [ngClass]=\"{'loading-btn': loading, 'verify': (step === 'verifycode')}\"\n                    (click)=\"handleSubscribeClick(mobilenumber, code)\">\n                    <ng-container *ngIf=\"!loading\">\n                      <span *ngIf=\"step === 'operator'\">{{ plan?.planbutton }}</span>\n                      <span *ngIf=\"step === 'verifycode'\" i18n=\"@@Verify\">Verify</span>\n                    </ng-container>\n                    <img class=\"op-loader\" *ngIf=\"loading\" src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/op-loader.gif\">\n                  </div>\n                  <div class=\"trial py-1\" *ngIf=\"step === 'operator'\">{{ plan?.trial }}</div>\n                </ng-container>\n                <ng-container *ngIf=\"redirectUrl !== '' && noticeErr !== ''\">\n                  <div class=\"retry\" (click)=\"handleSubscribeClick(mobilenumber, code)\">Retry</div>\n                </ng-container>\n              </div>\n              <!-- <div class=\"err\">{{ errmsg }}</div> -->\n            </ng-container>\n          </div>\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"isError\">\n        <div class=\"err-wrap err\">{{ errmsg }}</div>\n      </ng-container>\n    </ng-container>\n    <ng-container *ngIf=\"initialloading\">\n      <img class=\"initial-loader\" src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/loader.gif\">\n    </ng-container>\n  </anghami-white-box>\n  <div\n    *ngIf=\"plan?.disclaimer\"\n    [innerHtml]=\"plan?.disclaimer\"\n    class=\"disclaimer p-2\"\n  ></div>\n  <div class=\"back py-3 px-2\" [ngClass]=\"{'mx-2': !isSms}\" (click)=\"back()\" *ngIf=\"!isRBT\">\n    <img [src]=\"backArrowImg\"><span class=\"txt px-1\" i18n=\"@@back_to_plans\">Go back to plans</span>\n  </div>\n</div>\n<div id=\"featuresId\">\n  <div class=\"h-6\"></div>\n  <anghami-features class=\"mb-3\" [features]=\"benefitsLst\" (subscribeEvent)=\"goToSubscribe()\"></anghami-features>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/white-box/white-box.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"wrapper-box\" [ngClass]=\"{'loader': loading, 'notice': notice, 'brand': brand}\">\n  <div class=\"white-box\" [ngClass]=\"{'notice': notice}\">\n    <ng-content></ng-content>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/core/components/button/button-labels.enum.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button-labels.enum.ts ***!
  \**************************************************************/
/*! exports provided: ButtonLabelsEN, ButtonLabelsFR, ButtonLabelsAR */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsEN", function() { return ButtonLabelsEN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsFR", function() { return ButtonLabelsFR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsAR", function() { return ButtonLabelsAR; });
var ButtonLabelsEN;
(function (ButtonLabelsEN) {
    ButtonLabelsEN["learnMore"] = "Learn more";
    ButtonLabelsEN["sendGift"] = "Send gift";
    ButtonLabelsEN["goToHelpCenter"] = "Go to help center";
    ButtonLabelsEN["getAnghamiPlus"] = "Get Anghami Plus";
    ButtonLabelsEN["giftAnghamiPlus"] = "Gift Anghami Plus";
    ButtonLabelsEN["login"] = "Login";
    ButtonLabelsEN["manageAccount"] = "Manage Account";
    ButtonLabelsEN["subscribe"] = "Subscribe";
    ButtonLabelsEN["weAreHiring"] = "We're hiring";
    ButtonLabelsEN["haveApp"] = "Continue in app";
})(ButtonLabelsEN || (ButtonLabelsEN = {}));
var ButtonLabelsFR;
(function (ButtonLabelsFR) {
    ButtonLabelsFR["learnMore"] = "Renseignez - vous";
    ButtonLabelsFR["sendGift"] = "Envoyer un cadeau";
    ButtonLabelsFR["goToHelpCenter"] = "Aller au centre d'aide";
    ButtonLabelsFR["getAnghamiPlus"] = "Obtiens Anghami Plus";
    ButtonLabelsFR["giftAnghamiPlus"] = "Offrez Anghami Plus";
    ButtonLabelsFR["subscribe"] = "S'abonner";
    ButtonLabelsFR["login"] = "Connexion";
    ButtonLabelsFR["manageAccount"] = "Gestion du compte";
    ButtonLabelsFR["weAreHiring"] = "Nous recrutons";
    ButtonLabelsFR["haveApp"] = "Continuer depuis l'appli";
})(ButtonLabelsFR || (ButtonLabelsFR = {}));
var ButtonLabelsAR;
(function (ButtonLabelsAR) {
    ButtonLabelsAR["learnMore"] = "\u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0645\u0632\u064A\u062F";
    ButtonLabelsAR["sendGift"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u062A\u0643";
    ButtonLabelsAR["goToHelpCenter"] = "\u0627\u0630\u0647\u0628 \u0627\u0644\u0649 \u0642\u0633\u0645 \u0627\u0644\u0645\u0633\u0627\u0639\u062F\u0629";
    ButtonLabelsAR["getAnghamiPlus"] = "\u0625\u062D\u0635\u0644 \u0639\u0644\u0649 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u0633";
    ButtonLabelsAR["giftAnghamiPlus"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u0629 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u064E\u0633";
    ButtonLabelsAR["subscribe"] = "\u0627\u0634\u062A\u0631\u0643";
    ButtonLabelsAR["login"] = "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644";
    ButtonLabelsAR["manageAccount"] = "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u062D\u0633\u0627\u0628";
    ButtonLabelsAR["weAreHiring"] = "\u0646\u0648\u0638\u0651\u0641 \u0627\u0644\u0622\u0646!";
    ButtonLabelsAR["haveApp"] = "\u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0645\u0646 \u0627\u0644\u062A\u0637\u0628\u064A\u0642";
})(ButtonLabelsAR || (ButtonLabelsAR = {}));


/***/ }),

/***/ "./src/app/core/components/button/button.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: inline-block;\n}\n:host a {\n  text-decoration: none;\n  cursor: pointer;\n  color: #FFF;\n  padding: 1.2em 2.5em;\n  border-radius: 3em;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n  display: inline-block;\n}\n:host a.narrow {\n  padding: 0.8em 2.5em;\n}\n:host a .spinner-border {\n  width: 1.5rem;\n  height: 1.5rem;\n  vertical-align: middle;\n  margin-top: -0.1em;\n}\n:host a.loading {\n  padding: 1.2em 4em;\n}\n:host a.purple_gradient {\n  background-image: -webkit-gradient(linear, left top, right top, from(#e1418c), color-stop(#d6379b), color-stop(#c732ab), color-stop(#b035bc), to(#913ccd));\n  background-image: linear-gradient(to right, #e1418c, #d6379b, #c732ab, #b035bc, #913ccd);\n}\n:host a.white {\n  background: #FFF;\n  color: #000;\n}\n:host a.blue_gradient {\n  background: -webkit-gradient(linear, left top, right top, from(#0093fe), to(#5fd2cb));\n  background: linear-gradient(90deg, #0093fe 0%, #5fd2cb 100%);\n}\n:host a.purple {\n  background: #8d00f2;\n}\n:host a.blue {\n  background: #007ffe;\n  background: -webkit-gradient(linear, left top, right top, from(#007ffe), to(#01b5ff));\n  background: linear-gradient(90deg, #007ffe 0%, #01b5ff 100%);\n}\n:host:hover a:not(.loading) {\n  -webkit-transform: translateY(-2px);\n      -ms-transform: translateY(-2px);\n          transform: translateY(-2px);\n  opacity: 0.9;\n  box-shadow: 0px 3px 5px 0px rgba(0, 0, 0, 0.24);\n}"

/***/ }),

/***/ "./src/app/core/components/button/button.component.ts":
/*!************************************************************!*\
  !*** ./src/app/core/components/button/button.component.ts ***!
  \************************************************************/
/*! exports provided: ButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonComponent", function() { return ButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button-labels.enum */ "./src/app/core/components/button/button-labels.enum.ts");




let ButtonComponent = class ButtonComponent {
    constructor(router, locale) {
        this.router = router;
        this.locale = locale;
        this.label = '';
        this.layout = '';
        this.loading = false;
        this.link = '';
        this.target = '';
        this.size = '';
        this.hidden = false;
    }
    ngOnInit() {
        if (!this.label.length) {
            this.hidden = true;
        }
        let pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsEN"];
        if (this.locale === "ar") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsAR"];
        }
        else if (this.locale === "fr") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsFR"];
        }
        this.label_locale = pack[this.label] || this.label;
    }
    clickHandler(e) {
        if (this.target === "router") {
            e.preventDefault();
            this.router.navigateByUrl(this.link);
        }
        if (this.target === "none") {
            e.preventDefault();
            return;
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "label", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "layout", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ButtonComponent.prototype, "loading", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "link", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "target", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "size", void 0);
ButtonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-button',
        template: __webpack_require__(/*! raw-loader!./button.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html"),
        styles: [__webpack_require__(/*! ./button.component.scss */ "./src/app/core/components/button/button.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], String])
], ButtonComponent);



/***/ }),

/***/ "./src/app/core/components/button/button.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/components/button/button.module.ts ***!
  \*********************************************************/
/*! exports provided: ButtonModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonModule", function() { return ButtonModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button.component */ "./src/app/core/components/button/button.component.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");





let ButtonModule = class ButtonModule {
};
ButtonModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateModule"]],
        declarations: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
        exports: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]],
    })
], ButtonModule);



/***/ }),

/***/ "./src/app/core/components/operators/operators-routing.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/core/components/operators/operators-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: routes, OperatorsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OperatorsRoutingModule", function() { return OperatorsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _operators_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./operators.component */ "./src/app/core/components/operators/operators.component.ts");




const routes = [
    {
        path: '',
        component: _operators_component__WEBPACK_IMPORTED_MODULE_3__["OperatorsComponent"]
    }
];
let OperatorsRoutingModule = class OperatorsRoutingModule {
};
OperatorsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], OperatorsRoutingModule);



/***/ }),

/***/ "./src/app/core/components/operators/operators.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/core/components/operators/operators.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .h-6 {\n  height: 6em;\n}\n:host .features-top {\n  width: 80%;\n  margin-bottom: 5em;\n}\n@media (min-width: 769px) {\n  :host .features-top {\n    width: 60% !important;\n  }\n}\n@media (max-width: 568px) {\n  :host .features-top {\n    display: none;\n  }\n}\n:host .left-corner {\n  position: absolute;\n  max-width: 35em;\n  left: -23em;\n  z-index: -1;\n  top: 0;\n}\n:host .right-corner {\n  position: absolute;\n  max-width: 30em;\n  top: 15em;\n  right: -18em;\n  z-index: -1;\n}\n:host .initial-loader {\n  max-width: 4em;\n}\n:host .header {\n  width: 100%;\n  margin: 0em auto 2em auto;\n  padding: 1em;\n}\n:host .header .title {\n  text-align: center;\n  font-size: 2.7em;\n  font-weight: 500;\n}\n:host .header .subtitle {\n  text-align: center;\n  padding-top: 0.5em;\n  font-size: 1.3em;\n  font-weight: 500;\n}\n:host .ang-white-box ::ng-deep .white-box {\n  margin-top: 0 !important;\n}\n:host .ang-white-box.operator ::ng-deep .white-box {\n  padding-bottom: 0.5em !important;\n}\n:host .ang-white-box.operator.error ::ng-deep .white-box {\n  padding-top: 0.5em !important;\n}\n:host .ang-white-box.sms ::ng-deep .white-box {\n  max-width: 25em;\n  padding: 0.75em 1.5em;\n}\n@media (max-width: 768px) {\n  :host .ang-white-box.sms ::ng-deep .wrapper-box {\n    width: 100% !important;\n  }\n}\n@media (min-width: 769px) {\n  :host .ang-white-box.loading ::ng-deep .wrapper-box.loader {\n    width: 100% !important;\n  }\n}\n:host .ang-white-box.loading ::ng-deep .white-box {\n  padding: 0em !important;\n}\n@media (max-width: 768px) {\n  :host .reverse-box {\n    -webkit-box-orient: vertical !important;\n    -webkit-box-direction: reverse !important;\n        -ms-flex-direction: column-reverse !important;\n            flex-direction: column-reverse !important;\n  }\n}\n@media (max-width: 768px) {\n  :host .mw-100 {\n    width: 100%;\n  }\n}\n:host .redirect {\n  -webkit-box-orient: vertical !important;\n  -webkit-box-direction: normal !important;\n      -ms-flex-direction: column !important;\n          flex-direction: column !important;\n  -webkit-box-align: center !important;\n      -ms-flex-align: center !important;\n          align-items: center !important;\n}\n:host .redirect .minw-30 {\n  min-width: unset !important;\n}\n:host .noticeErr {\n  font-weight: 500;\n  font-size: 1.3em;\n  text-align: center;\n  color: red;\n}\n@media (min-width: 769px) {\n  :host :not(.sms) .minw-30 {\n    min-width: 30em;\n  }\n}\n:host .form-control::-webkit-input-placeholder {\n  color: #c9c9c9;\n  font-size: 1em;\n}\n:host .form-control::-moz-placeholder {\n  color: #c9c9c9;\n  font-size: 1em;\n}\n:host .form-control:-ms-input-placeholder {\n  color: #c9c9c9;\n  font-size: 1em;\n}\n:host .form-control::-ms-input-placeholder {\n  color: #c9c9c9;\n  font-size: 1em;\n}\n:host .form-control::placeholder {\n  color: #c9c9c9;\n  font-size: 1em;\n}\n:host .retry {\n  text-decoration: underline;\n  font-size: 1.3em;\n  cursor: pointer;\n  font-weight: 300;\n}\n:host .flexbox {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .flexbox.middle {\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .flexbox.colls {\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n:host .flexbox.between {\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n:host .flexbox.start {\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n}\n:host .flexbox.justify-start {\n  -webkit-box-pack: start !important;\n      -ms-flex-pack: start !important;\n          justify-content: flex-start !important;\n}\n@media (max-width: 768px) {\n  :host .flexbox.vertical {\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n  }\n}\n:host .logo {\n  max-width: 4em;\n}\n:host .timer {\n  padding: 0 0.5em;\n  color: #b8b8b8;\n}\n:host .num-wrap {\n  border-bottom: 1px solid #ced4da;\n  height: 3em;\n  margin: 0 1.5em;\n  width: 90%;\n}\n:host .mobilenum {\n  border: none;\n  border-radius: 0;\n  font-size: 1.5em;\n  color: black;\n  margin-left: 0.5em;\n}\n:host .mobilenum.verify-code {\n  margin: 0 !important;\n}\n:host .mobilenum:focus {\n  box-shadow: unset !important;\n}\n:host .prefix {\n  font-size: 1.5em;\n  line-height: 1em;\n}\n:host .ang-operator-btn {\n  white-space: nowrap;\n  padding: 1em 2em;\n  font-size: 1.1em;\n  text-transform: none !important;\n}\n:host .trial {\n  text-align: center;\n  margin: auto;\n  font-size: 1em;\n  color: #b8b8b8;\n}\n:host .op-loader {\n  max-width: 2em;\n}\n:host .loading-btn {\n  min-width: 10em;\n  padding: 0.5em;\n}\n:host .verify {\n  min-width: 10em;\n  padding: 0.75em 1em;\n}\n:host .err-wrap {\n  font-size: 1.5em !important;\n  color: black !important;\n}\n:host .err {\n  color: red;\n  font-weight: 500;\n  margin: 0.5em 1.5em;\n}\n:host .sms-details {\n  margin-left: 5em;\n  font-size: 1.1em;\n}\n:host .sms-details a {\n  color: #b8b8b8;\n  text-decoration: underline;\n}\n:host .sms-details a.disabled {\n  color: black;\n  cursor: not-allowed !important;\n}\n:host .sms-wrap {\n  width: 100%;\n  font-size: 1.4em;\n  text-align: center;\n}\n:host .sms-wrap .bold {\n  font-weight: 600;\n}\n:host .back {\n  cursor: pointer;\n}\n:host .back img {\n  max-width: 1em;\n}\n:host .back .txt {\n  color: #919191;\n}\n@media (max-width: 768px) {\n  :host .back {\n    padding: 1em;\n  }\n}\n@media (min-width: 769px) {\n  :host .back.mx-2 {\n    margin: 0 !important;\n  }\n}\n:host .disclaimer {\n  max-width: 55em;\n  color: #b8b8b8;\n  line-height: 1.7em;\n}\n@media (max-width: 768px) {\n  :host .disclaimer {\n    width: 90%;\n    margin: auto;\n  }\n}\nhtml[lang=ar] :host .mobilenum {\n  margin-right: 0.5em;\n  margin-left: 0 !important;\n}\nhtml[lang=ar] :host .mobilenum.verify-code {\n  margin: 0 !important;\n}\nhtml[lang=ar] :host .back {\n  width: 90%;\n  margin: auto;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n@media (max-width: 768px) {\n  html[lang=ar] :host .ar {\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n  }\n}\nhtml[lang=ar] :host .ang-white-box ::ng-deep .white-box {\n  direction: ltr !important;\n}\nhtml[lang=ar] :host .disclaimer {\n  text-align: right !important;\n}"

/***/ }),

/***/ "./src/app/core/components/operators/operators.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/core/components/operators/operators.component.ts ***!
  \******************************************************************/
/*! exports provided: OperatorsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OperatorsComponent", function() { return OperatorsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/sub-operators.service */ "./src/app/core/services/sub-operators.service.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/promo.service */ "./src/app/core/services/promo.service.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _anghami_services_amplitude_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/services/amplitude.service */ "./src/app/core/services/amplitude.service.ts");
/* harmony import */ var _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/redux/actions/operators.actions */ "./src/app/core/redux/actions/operators.actions.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _anghami_services_gtmConversion_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/gtmConversion.service */ "./src/app/core/services/gtmConversion.service.ts");
/* harmony import */ var _anghami_services_subscription_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @anghami/services/subscription.service */ "./src/app/core/services/subscription.service.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");


















let OperatorsComponent = class OperatorsComponent {
    constructor(_store, _router, _route, _subOperatorService, _utilService, _translateService, _promoService, _actionSubject, _amplitudeService, _gtmConversion, _subscriptionService, locale, platformId) {
        this._store = _store;
        this._router = _router;
        this._route = _route;
        this._subOperatorService = _subOperatorService;
        this._utilService = _utilService;
        this._translateService = _translateService;
        this._promoService = _promoService;
        this._actionSubject = _actionSubject;
        this._amplitudeService = _amplitudeService;
        this._gtmConversion = _gtmConversion;
        this._subscriptionService = _subscriptionService;
        this.locale = locale;
        this.platformId = platformId;
        this.id = 'operatorId';
        this.errmsg = '';
        this.step = 'operator';
        this.initialloading = true;
        this.loading = false;
        this.isNotice = false;
        this.isRBT = false;
        this.isSubscribed = false;
        this.subParams = {};
        this.amplitudeEventObject = {};
        this.phoneValidations = {};
        this.innerHeader = {};
        this.device = this._utilService.getOSName();
        this.isDeviceMobile = this._utilService.detectmob();
        this.resendCount = 0;
        this.rbtplan = {};
        this.isAutoSub = false;
        this.isAutofill = false;
        this.autoSubParams = {};
        this.backArrowImg = this.locale === 'ar'
            ? 'https://anghamiwebcdn.akamaized.net/web2/assets/img/back-arrow-ar.png'
            : 'https://anghamiwebcdn.akamaized.net/web2/assets/img/back-arrow.png';
        this.featuresLst = [];
        this.visibleFeaturesLst = [];
        this.benefitsLst = [];
        this.isError = false;
        this.disabledTimer = 0;
        this.noticeErr = '';
        this.isPhonenumInputFocused = false;
        this.isVerifycodeInputFocused = false;
    }
    ngOnInit() {
        this.user$ = this._store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_15__["getUser"]))
            .subscribe(data => {
            if (data && data !== null) {
                this.user = JSON.parse(JSON.stringify(data));
            }
        });
        this.msidninputPlaceholder = this._translateService.instant('operatorplaceholder');
        this.codeinputPlaceholder = this._translateService.instant('verification_code_placeholder');
        this._route.queryParams.subscribe(params => {
            if (params && params !== null) {
                this.queryParams = JSON.parse(JSON.stringify(params));
            }
            this.setOperatorsSubParams(params);
            this.isRBT = (this.subParams['operator'] === 'rbt');
            this.setAmplitudeObject(this.subParams);
            if (this.subParams['operator']) {
                this._gtmConversion.reportLandingTracking(this.subParams['operator']);
            }
            if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_17__["isPlatformBrowser"])(this.platformId)) {
                this.getOperatorPlan();
            }
        });
        document.addEventListener('keypress', (evt) => {
            const key = evt.which || evt.keyCode;
            if (key === 13 && (this.isPhonenumInputFocused || this.isVerifycodeInputFocused)) {
                this.handleSubscribeClick(this.mobilenumber, this.code);
            }
        });
    }
    handleFocusInput() {
        if (this.phonenumElt) {
            this.phonenumElt.nativeElement.addEventListener('focus', () => {
                this.isPhonenumInputFocused = true;
            });
            this.phonenumElt.nativeElement.addEventListener('blur', () => {
                this.isPhonenumInputFocused = false;
            });
        }
        if (this.verificationElt) {
            this.verificationElt.nativeElement.addEventListener('focus', () => {
                this.isVerifycodeInputFocused = true;
            });
            this.verificationElt.nativeElement.addEventListener('blur', () => {
                this.isVerifycodeInputFocused = false;
            });
        }
    }
    setFeaturesLst(res) {
        this.featuresLst = res.features
            ? res.plan && res.plan.benefits
                ? res.plan.benefits.concat(res.features)
                : res.features
            : res.plan && res.plan.benefits
                ? res.plan.benefits
                : [];
        if (this.featuresLst && this.featuresLst.length > 3) {
            this.visibleFeaturesLst = this.featuresLst.slice(0, 3);
        }
        else {
            this.visibleFeaturesLst = JSON.parse(JSON.stringify(this.featuresLst));
        }
        this.benefitsLst = this._subscriptionService.getFeaturesLst();
    }
    goToBenefits() {
        const featuresid = document.getElementById('featuresId');
        if (featuresid && featuresid !== null) {
            featuresid.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    goToSubscribe() {
        const subscribeId = document.getElementById('operatorId');
        if (subscribeId && subscribeId !== null) {
            subscribeId.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    setOperatorsSubParams(params) {
        if (params && params != null) {
            for (const key of Object.keys(params)) {
                if (params['campaign']) {
                    this.subParams['campaignid'] = params['campaign'].toLowerCase();
                }
                else if (params['msisdn']) {
                    this.subParams['msidn'] = params['msisdn'];
                }
                else if (params['pid']) {
                    this.subParams['planid'] = parseInt(params['pid'], 10);
                }
                else {
                    this.subParams[key] = params[key];
                }
            }
        }
        this.subParams['operator'] = this._route.snapshot.params['operatorname']
            ? this._route.snapshot.params['operatorname'].toLowerCase()
            : '';
        if (this.subParams['planid'] === undefined || this.subParams['planid'] === null || this.subParams['planid'] === '') {
            this.subParams['planid'] = this._route.snapshot.params['pid']
                ? parseInt(this._route.snapshot.params['pid'], 10)
                : undefined;
        }
        this.filterParams(this.subParams);
    }
    setAmplitudeObject(params) {
        const ampParams = ['operator', 'source', 'artistid', 'songid', 'playlistid', 'albumid'];
        if (params && params !== null) {
            const selectedParams = Object.keys(params).filter(elt => ampParams.includes(elt));
            selectedParams.forEach(elt => {
                this.amplitudeEventObject[elt] = params[elt];
            });
        }
    }
    getOperatorPlan() {
        if (this.isRBT) {
            this.getRBT();
        }
        else {
            this._subOperatorService
                .getOperatorPlan(this.subParams)
                .subscribe((result) => {
                if (result && result !== null) {
                    const data = result.res && result.res !== null
                        ? result.res.data
                            ? result.res.data
                            : result.res
                        : null;
                    this.handleOperatorResponse(data);
                    setTimeout(() => {
                        this.handleFocusInput();
                    });
                }
            });
        }
    }
    getRBT() {
        const rbtParams = {
            type: 'GETrbtinfo',
            providerid: this.subParams['providerid'],
            songid: this.subParams['songid'],
            msidn: this.subParams['msidn'],
            output: 'jsonhp'
        };
        this.filterParams(rbtParams);
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].GetRBTInfoSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            this.initialloading = true;
            const response = res.payload ? res.payload.data : null;
            if (response && response !== null) {
                const data = {
                    plan: response,
                    msidn: this.subParams['msidn']
                };
                this.setOperatorDetails(data);
                if (this.subParams['msidn'] && this.phoneValidations.countrycode) {
                    if (typeof this.subParams['msidn'] === 'number'
                        && this.subParams['msidn'].startsWith(this.phoneValidations.countrycode)) {
                        let rbtnum = this.subParams['msidn'].replace(this.phoneValidations.countrycode, '');
                        rbtnum = rbtnum.indexOf(0) === 0 ? rbtnum.replace(0, '') : rbtnum;
                        if (this.phoneValidations.min_digits <= rbtnum.length
                            && rbtnum.length <= this.phoneValidations.max_digits) {
                            this.mobilenumber = rbtnum;
                        }
                    }
                }
            }
        });
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].GetRBTInfoError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            this.initialloading = false;
            const data = res.payload ? res.payload : null;
            if (data && data !== null) {
                this.errmsg = data.error ? data.error.message : this._translateService.instant('oops');
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].operatorPageVisit,
                    props: Object.assign({}, this.amplitudeEventObject, { message: this.errmsg, isRBT: true })
                }));
            }
        });
        this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["GetRBTInfo"](rbtParams));
    }
    handleOperatorResponse(result) {
        if (result && result !== null) {
            this.initialloading = false;
            if (result.error) {
                this.isError = true;
                this.errmsg = result['error']['message'] ? result['error']['message'] : this._translateService.instant('oops');
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].operatorPageVisit,
                    props: Object.assign({}, this.amplitudeEventObject, { message: this.errmsg })
                }));
            }
            else {
                if (result.plan) {
                    // TODO: add metas
                    this.setOperatorDetails(result);
                    this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                        name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].operatorPageVisit,
                        props: Object.assign({}, this.amplitudeEventObject)
                    }));
                    if (!this.isSms) {
                        if (this.subParams['token']) {
                            this.checkRedirectSubscription(result.plan);
                        }
                        else {
                            this.checkAutoSubscription(result.plan);
                        }
                    }
                    else {
                        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                            name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].operatorPageVisit,
                            props: Object.assign({}, this.amplitudeEventObject, { isSms: true })
                        }));
                    }
                }
            }
        }
    }
    setOperatorDetails(result) {
        this.plan = JSON.parse(JSON.stringify(result.plan));
        this.setFeaturesLst(result);
        this.setInnerHeader();
        if (this.plan['operatorname']) {
            this.plan['operatorname'] = this.plan['operatorname'].replace('\u200f', '');
        }
        this.isSms = (this.plan.api === 'sms');
        this.step = this.isSms ? '' : 'operator';
        this.phoneValidations = this._subOperatorService.msidnValidations =
            this._subOperatorService.setMsidnDetails(result.plan);
        this.mobilenumber = this._subOperatorService.autofillPhoneNumber(result.msidn);
        this.redirectUrl = this.plan.redirect_url ? this.plan.redirect_url : '';
    }
    setInnerHeader() {
        if (this.plan && this.plan !== null) {
            this.innerHeader = {
                mainimage: this.plan.topbanner,
                title: this.plan.title,
                subtitle: this.plan.subtitle
            };
        }
    }
    checkRedirectSubscription(plan) {
        const params = Object.assign({}, this.subParams, { type: plan.api, token: this.subParams['token'] });
        this.filterParams(params);
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].RedirectTelcoSubscriptionSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            const data = res.payload ? res.payload.data : null;
            this.noticeErr = '';
            if (data && data !== null) {
                const amp = Object.assign({}, this.amplitudeEventObject, { token: this.subParams['token'], redirecturl: this.redirectUrl });
                this.reportConversion(amp, true);
            }
        });
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].RedirectTelcoSubscriptionError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            const error = res.payload && res.payload.error
                ? res.payload.error
                : {};
            this.noticeErr = error.message;
        });
        this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["RedirectTelcoSubscription"](params));
    }
    checkAutoSubscription(plan) {
        const params = Object.assign({}, this.subParams, { type: plan.api, auto: 1 });
        this.filterParams(params);
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].AutoSubscribeTelcoSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            const data = res.payload ? res.payload.data : null;
            if (data && data !== null) {
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].operatorPageVisit,
                    props: Object.assign({}, this.amplitudeEventObject, { auto: data.msidnauto && data.hash ? 1 : '' })
                }));
                if (data['msidnauto'] && data['hash']) {
                    this.autoSubParams = {
                        'msidn': data['msidnauto'],
                        'hash': data['hash']
                    };
                    this.isAutofill = (data['autofill'] && data['autofill'] == true);
                    if (this.isAutofill) {
                        this.mobilenumber = this._subOperatorService.autofillPhoneNumber(data['msidnauto']);
                    }
                    else {
                        this.isAutoSub = true;
                    }
                }
                else if (data['url']) {
                    window.location.href = data['url'];
                }
                else if (data['status'] === 'ok' && this.subParams['token']) {
                    const amp = Object.assign({}, this.amplitudeEventObject, { token: this.subParams['token'], redirecturl: this.redirectUrl });
                    this.reportConversion(amp, true);
                }
            }
        });
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].AutoSubscribeTelcoError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            const data = res.payload ? res.payload : null;
            if (data && data !== null && data['error']) {
                this.errmsg = data['error']['message'] ? data['error']['message'] : this._translateService.instant('oops');
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].operatorPageVisit,
                    props: Object.assign({}, this.amplitudeEventObject, { message: this.errmsg })
                }));
            }
        });
        this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["AutoSubscribeTelco"](params));
    }
    handleConditions(evt, type) {
        let condition = {
            type: 'tel'
        };
        if (type === 'operator') {
            condition = Object.assign({}, condition, { maxlength: this.phoneValidations
                    ? this.phoneValidations.max_digits
                    : 0, pattern: '^[0-9]*$' });
        }
        else if (type === 'code') {
        }
        this._promoService.handleConditions(evt, condition);
    }
    clearError() {
        this.errmsg = '';
    }
    applyAutoSubscription() {
        const params = Object.assign({}, this.autoSubParams, { type: this.plan.api, planid: this.plan.id, campaignid: this.subParams ? this.subParams['campaignid'] : undefined });
        this.filterParams(params);
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].clickSubscribe,
            props: Object.assign({}, this.amplitudeEventObject, { auto: 1 })
        }));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].ApplyAutoSubscribeError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            this.loading = false;
            this.isSubscribed = false;
            const data = res.payload ? res.payload : null;
            if (data && data !== null && data['error']) {
                this.errmsg = data['error']['message'] ? data['error']['message'] : this._translateService.instant('oops');
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].subscriptionFailure,
                    props: Object.assign({}, this.amplitudeEventObject, { message: this.errmsg })
                }));
            }
        });
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].ApplyAutoSubscribeSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            this.loading = false;
            this.isSubscribed = false;
            const data = res.payload ? res.payload.data : null;
            if (data && data !== null) {
                this.reportConversion(JSON.parse(JSON.stringify(this.amplitudeEventObject)));
                this._subOperatorService.resultmsg = this.isRBT
                    ? this._translateService.instant('request_inprocess')
                    : this._translateService.instant('congrats_plus');
                this._router.navigate(['/subscriptioncheck'], { queryParams: { operator: this.plan['operatorname'] } });
            }
        });
        this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["ApplyAutoSubscribe"](params));
    }
    subscribeTelco(mobile, resend) {
        this.amplitudeEventObject = Object.assign({}, this.amplitudeEventObject, { msidn: this.phoneValidations && this.phoneValidations.countrycode
                ? this.phoneValidations.countrycode + mobile
                : mobile });
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].clickSubscribe,
            props: this.amplitudeEventObject
        }));
        if (mobile === undefined) {
            this.loading = false;
            this.isSubscribed = false;
            this.errmsg = this._translateService.instant('phone_required');
            this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].subscriptionNumberRequired,
                props: Object.assign({}, this.amplitudeEventObject, { message: this.errmsg })
            }));
            return;
        }
        let mobilestr = mobile + '';
        mobilestr = mobilestr.indexOf('0') === 0 ? mobilestr.replace('0', '') : mobilestr;
        this.mobilenumber = JSON.parse(JSON.stringify(mobilestr));
        const isValidMsidn = this.phoneValidations && this.phoneValidations.min_digits <= mobilestr.length
            && mobilestr.length <= this.phoneValidations.max_digits;
        if (!isValidMsidn) {
            this.loading = false;
            this.isSubscribed = false;
            this.errmsg = this._translateService.instant('phone_invalid');
            this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].subscriptionNumberRequired,
                props: Object.assign({}, this.amplitudeEventObject, { message: this.errmsg })
            }));
            return;
        }
        if (resend) {
            this.resendCount++;
        }
        let params = {
            type: this.plan.api,
            msidn: (this.phoneValidations ? this.phoneValidations.countrycode : '') + mobilestr,
            output: 'jsonhp'
        };
        if (this.isRBT) {
            params = Object.assign({}, params, { providerid: this.subParams['providerid'], songid: this.subParams['songid'] });
        }
        else {
            params = Object.assign({}, params, { planid: this.plan.id, resend: this.resendCount, campaignid: this.subParams['campaignid'] });
        }
        this.filterParams(params);
        this.handleSubscribeTelcoResponse(mobilestr);
        this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["SUBSCRIBETelco"](params));
    }
    handleSubscribeTelcoResponse(mobilenum) {
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].SUBSCRIBETelcoSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            this.loading = false;
            this.isSubscribed = false;
            const data = res && res.payload ? res.payload.data : null;
            if (data && data !== null) { // && data.status === 'ok'
                if (this.isRBT) {
                    this.rbtplan = JSON.parse(JSON.stringify(data));
                }
                this.subParams['msidn'] = this.phoneValidations.countrycode + mobilenum;
                this.step = 'verifycode';
                setTimeout(() => {
                    this.handleFocusInput();
                });
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].goToVerificationPage
                }));
            }
        });
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].SUBSCRIBETelcoError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            this.loading = false;
            this.isSubscribed = false;
            const data = res.payload ? res.payload : null;
            if (data && data !== null) {
                if (data['error']['code'] == 20 && data['redirect']) {
                    // TODO: open confirmation modal
                    // if (data['error']['code'] == 20 && data['redirect']) {
                    //   const dialogRef = this.dialog.open(ConfirmationModalComponent, {
                    //     data: {
                    //       action : data['redirect'],
                    //       text:  data['error']['message'],
                    //       showSingleBtn: true,
                    //       image: 'https://anghamiwebcdn.akamaized.net/web2/assets/img/info.png'
                    //     },
                    //     panelClass: 'confirmationModal'
                    //   });
                    //   dialogRef.afterClosed().subscribe(key => {
                    //     if (key === 'confirm') {
                    //       this._analyticsService.logAmplitudeEvent('redirectOperatorUrl', {
                    //         redirecturl: data['redirect'],
                    //         message: data['error']['message']
                    //       });
                    //       window.location.href = '/subscribe' + data['redirect'];
                    //     } else {
                    //       this._analyticsService.logAmplitudeEvent('cancelredirectOperatorUrl', {
                    //         redirecturl: data['redirect'],
                    //         message: data['error']['message']
                    //       });
                    //     }
                    //     return;
                    //   });
                }
                else {
                    this.errmsg = data['error']['message'] ? data['error']['message'] : this._translateService.instant('oops');
                    this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                        name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].subscriptionFailure,
                        props: Object.assign({}, this.amplitudeEventObject, { message: this.errmsg, code: data['error']['code'] })
                    }));
                }
            }
        });
    }
    handleSubscribeClick(mobilenumber, code) {
        if (!this.isSubscribed) {
            this.loading = true;
            this.isSubscribed = true;
            this.clearError();
            if (this.redirectUrl && this.redirectUrl !== '') {
                window.location.href = this.redirectUrl;
            }
            else {
                if (this.step === 'operator') {
                    if (this.plan.api === 'sms') {
                        this.sendSms();
                    }
                    else {
                        if (this.isAutoSub) {
                            this.applyAutoSubscription();
                        }
                        else {
                            this.subscribeTelco(mobilenumber);
                        }
                    }
                }
                else if (this.step === 'verifycode') {
                    this.verifyTelcoCode(mobilenumber, code);
                }
                else {
                    this.loading = false;
                    this.isSubscribed = false;
                    this.errmsg = this._translateService.instant('oops');
                }
            }
        }
    }
    sendSms() {
        window.location.href = this.getSmsHref();
    }
    getSmsHref() {
        let smshref = '';
        if (this.device === 'ios') {
            smshref = `sms:${this.plan.sms}&body=${encodeURI(this.plan.smstext)}`;
        }
        else if (this.device === 'android') {
            smshref = 'sms:' + this.plan.sms + '?body=' + encodeURI(this.plan.smstext);
        }
        return smshref;
    }
    filterParams(params) {
        Object.keys(params).forEach(key => (params[key] === undefined || params[key] === null
            || (typeof params[key] === 'object' && Object.keys(params[key]).length === 0))
            && delete params[key]);
    }
    verifyTelcoCode(mobilenum, code) {
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].clickVerifySubscribe,
            props: this.amplitudeEventObject
        }));
        if (code) {
            const params = {
                'type': this.plan.api,
                'code': code,
                'planid': this.plan.id,
                'utmtags': this._amplitudeService.getUTMTagsFromUrl(window.location.href),
                'campaignid': this.subParams['campaignid'],
                'msidn': this.phoneValidations['countrycode'] + mobilenum
            };
            this.filterParams(params);
            this.handleVerifyTelcoResponse();
            this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["SUBSCRIBETelcoVerification"](params));
        }
        else {
            this.loading = false;
            this.isSubscribed = false;
            this.errmsg = this._translateService.instant('pincode_invalid');
            this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].wrongPinError,
                props: Object.assign({}, this.amplitudeEventObject, { message: this.errmsg })
            }));
        }
    }
    handleVerifyTelcoResponse() {
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].SUBSCRIBETelcoVerificationSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((res) => {
            this.loading = false;
            this.isSubscribed = false;
            const data = res && res.payload ? res.payload.data : null;
            if (data && data !== null) {
                this.subscriptionSuccess(data, this.amplitudeEventObject);
            }
        });
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_8__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_11__["OperatorsActionTypes"].SUBSCRIBETelcoVerificationError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe((data) => {
            this.isSubscribed = false;
            this.loading = false;
            const res = data && data.payload ? data.payload : null;
            if (res && res !== null) {
                if (res.error) {
                    this.errmsg = res.error.message;
                    this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                        name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].subscriptionFailure,
                        props: Object.assign({}, this.amplitudeEventObject, { message: this.errmsg, code: res.error.code })
                    }));
                }
            }
        });
    }
    reportConversion(amplitudeParams, isredirect) {
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].subscriptionSuccess,
            props: amplitudeParams
        }));
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["ReportPixelEvent"]({ eventName: 'lead' }));
        this._gtmConversion.reportTwitterConversion(this.plan['operatorname']);
        this._gtmConversion.reportFacebookConversion(this.plan['operatorname']);
        this._gtmConversion.reportSnapConversion(this.plan['operatorname']);
        const url = this._subscriptionService.isSeries || !isredirect ? undefined : '/subscriptioncheck';
        this._gtmConversion.reportConversion(this.user, this.plan.id, url, { success: 1 }, this.plan['operatorname']);
        if (this._subscriptionService.isSeries) {
            this._router.navigate(['/subscriptioncheck'], { queryParams: { success: 1, operator: this.plan['operatorname'] } });
        }
    }
    subscriptionSuccess(data, amplitudeParams) {
        if (data['status'] === 'ok') {
            this.amplitudeEventObject = Object.assign({}, this.amplitudeEventObject, { utmtags: this._amplitudeService.getUTMTagsFromUrl(window.location.href) });
            this.filterParams(this.amplitudeEventObject);
            if (this.isRBT) {
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].rbtSuccessful,
                    props: Object.assign({}, this.amplitudeEventObject)
                }));
                this._subOperatorService.resultmsg = this._translateService.instant('request_inprocess');
                this._router.navigate(['/subscriptioncheck'], { queryParams: { operator: this.plan['operatorname'] } });
            }
            else {
                this.reportConversion(amplitudeParams, true);
            }
        }
        else if (data.success) {
            if (data.inprocess) {
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                    name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].subscriptionInProgress,
                    props: amplitudeParams
                }));
                this._subOperatorService.resultmsg = data['message'];
                if (this.subParams['operator'] && this.subParams['operator'].toLowerCase() === 'stc') {
                    this._gtmConversion.reportTwitterConversion(this.subParams['operator']);
                    this._gtmConversion.reportFacebookConversion(this.subParams['operator']);
                    this._gtmConversion.reportSnapConversion(this.subParams['operator']);
                }
                this._router.navigate(['/subscriptioncheck'], { queryParams: { operator: this.plan['operatorname'] } });
            }
        }
    }
    resend() {
        if (this.disabledTimer === 0) {
            this.disabledTimer = 60;
            this.timer = setInterval(() => {
                if (this.disabledTimer > 0) {
                    this.disabledTimer--;
                }
                else {
                    this.clearInterval();
                }
            }, 1000);
            this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
                name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].resendMsidnCode
            }));
            if (this.subParams['msidn'] && this.subParams['msidn'] !== null) {
                const updated_msidn = this.subParams['msidn'].replace('+', '').replace(this.phoneValidations.countrycode, '');
                this.subscribeTelco(updated_msidn, true);
            }
        }
    }
    back() {
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_12__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].onSubscribeBackNav
        }));
        this._router.navigate(['/plus'], { queryParams: this.queryParams });
    }
    clearInterval() {
        clearInterval(this.timer);
    }
    ngOnDestroy() {
        if (this.user$) {
            this.user$.unsubscribe();
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('attr.id'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], OperatorsComponent.prototype, "id", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('phonenumElt', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], OperatorsComponent.prototype, "phonenumElt", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('verificationElt', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], OperatorsComponent.prototype, "verificationElt", void 0);
OperatorsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-operators',
        template: __webpack_require__(/*! raw-loader!./operators.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/operators/operators.component.html"),
        styles: [__webpack_require__(/*! ./operators.component.scss */ "./src/app/core/components/operators/operators.component.scss"), __webpack_require__(/*! ../../../modules/landing/plus/plus-internal.component.scss */ "./src/app/modules/landing/plus/plus-internal.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](11, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](12, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_3__["SubOperatorsService"],
        _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilService"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateService"],
        _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_7__["PromoService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["ActionsSubject"],
        _anghami_services_amplitude_service__WEBPACK_IMPORTED_MODULE_10__["AmplitudeService"],
        _anghami_services_gtmConversion_service__WEBPACK_IMPORTED_MODULE_13__["GtmConversionService"],
        _anghami_services_subscription_service__WEBPACK_IMPORTED_MODULE_14__["SubscriptionService"], String, Object])
], OperatorsComponent);



/***/ }),

/***/ "./src/app/core/components/operators/operators.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/components/operators/operators.module.ts ***!
  \***************************************************************/
/*! exports provided: OperatorsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OperatorsModule", function() { return OperatorsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _operators_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./operators.component */ "./src/app/core/components/operators/operators.component.ts");
/* harmony import */ var _operators_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./operators-routing.module */ "./src/app/core/components/operators/operators-routing.module.ts");
/* harmony import */ var _footer_footer_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../footer/footer.module */ "./src/app/core/components/footer/footer.module.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _white_box_white_box_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../white-box/white-box.module */ "./src/app/core/components/white-box/white-box.module.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _benefits_activation_benefits_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../benefits/activation-benefits.module */ "./src/app/core/components/benefits/activation-benefits.module.ts");
/* harmony import */ var _features_features_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../features/features.module */ "./src/app/core/components/features/features.module.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_11__);












let OperatorsModule = class OperatorsModule {
};
OperatorsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"],
            _operators_routing_module__WEBPACK_IMPORTED_MODULE_3__["OperatorsRoutingModule"],
            _footer_footer_module__WEBPACK_IMPORTED_MODULE_4__["FooterModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"],
            _white_box_white_box_module__WEBPACK_IMPORTED_MODULE_6__["WhiteBoxModule"],
            _benefits_activation_benefits_module__WEBPACK_IMPORTED_MODULE_9__["ActivationBenefitsModule"],
            _features_features_module__WEBPACK_IMPORTED_MODULE_10__["FeaturesModule"],
            ng_lazyload_image__WEBPACK_IMPORTED_MODULE_11__["LazyLoadImageModule"]
        ],
        declarations: [
            _operators_component__WEBPACK_IMPORTED_MODULE_2__["OperatorsComponent"]
        ]
    })
], OperatorsModule);



/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .wrapper-box {\n  display: inline-block;\n  margin: auto;\n  width: 100%;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box {\n    width: 90%;\n  }\n}\n:host .wrapper-box.loader {\n  width: 40% !important;\n}\n:host .wrapper-box.notice {\n  width: unset;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box.notice {\n    width: 90%;\n  }\n}\n:host .wrapper-box.brand .white-box {\n  margin-top: -5.5em !important;\n}\n:host .white-box {\n  margin: auto;\n  min-width: 5em;\n  border: 1px solid #EEEEEE;\n  border-radius: 0.5em;\n  box-shadow: 5px 5px 30px -5px lightgrey;\n  padding: 1.5em;\n  display: block;\n  background-color: white;\n  position: relative;\n  max-width: 55em;\n  margin-top: -8em;\n}\n@media (max-width: 768px) {\n  :host .white-box {\n    margin-top: -3em;\n  }\n}\n:host .white-box.notice {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-top: -5em;\n  padding: 2em;\n}"

/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.ts ***!
  \******************************************************************/
/*! exports provided: WhiteBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxComponent", function() { return WhiteBoxComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let WhiteBoxComponent = class WhiteBoxComponent {
    constructor() { }
    ngOnInit() { }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], WhiteBoxComponent.prototype, "notice", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], WhiteBoxComponent.prototype, "loading", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], WhiteBoxComponent.prototype, "brand", void 0);
WhiteBoxComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-white-box',
        template: __webpack_require__(/*! raw-loader!./white-box.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html"),
        styles: [__webpack_require__(/*! ./white-box.component.scss */ "./src/app/core/components/white-box/white-box.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], WhiteBoxComponent);



/***/ }),

/***/ "./src/app/core/components/white-box/white-box.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.module.ts ***!
  \***************************************************************/
/*! exports provided: WhiteBoxModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxModule", function() { return WhiteBoxModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.component */ "./src/app/core/components/white-box/white-box.component.ts");




let WhiteBoxModule = class WhiteBoxModule {
};
WhiteBoxModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
        declarations: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
        exports: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], WhiteBoxModule);



/***/ })

}]);