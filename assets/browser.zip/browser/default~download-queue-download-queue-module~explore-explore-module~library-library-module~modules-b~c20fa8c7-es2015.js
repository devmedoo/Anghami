(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~download-queue-download-queue-module~explore-explore-module~library-library-module~modules-b~c20fa8c7"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/auto-downloads/auto-downloads.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/auto-downloads/auto-downloads.component.html ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"auto-downloads-container\">\n  <div class=\"toggle float-right\">\n    <label class=\"switch\">\n      <input type=\"checkbox\" [checked]=\"autoDownloadsValue\" (click)=\"toggleAutoDownloads()\" />\n      <span class=\"slider round\"></span>\n    </label>\n  </div>\n\n  <div class=\"title\">\n    <span i18n=\"@@enable_auto_download\">\n      Enable auto downloads\n    </span>\n  </div>\n\n  <div class=\"subtitle\">\n    <span i18n=\"@@autodownload_other_devices\">\n      Songs you have on your other devices will be automatically downloaded here.\n    </span>\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/context-sheet-new/context-sheet-new.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/context-sheet-new/context-sheet-new.component.html ***!
  \**************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ng-container>\n  <anghami-icon\n    *ngIf=\"showMoreIcon\"\n    #popover=\"ngbPopover\"\n    class=\"icon more\"\n    container=\"body\"\n    popoverClass=\"context-sheet\"\n    [data]=\"'more'\"\n    autoClose=\"outside\"\n    [ngClass]=\"{ 'highlighted': popoverOpen, 'overlay': source === 'overlay' }\"\n    [placement]=\"placement\"\n    [ngbPopover]=\"contextsheet\"\n    triggers=\"manual\"\n    [disablePopover] = \"disablePopover\"\n    (click)=\"$event.stopPropagation(); $event.preventDefault(); popover.open()\"\n    (hidden)=\"sheetHiddenEvent()\"\n    (shown)=\"sheetShownEvent()\"\n  ></anghami-icon>\n    <anghami-icon\n      *ngIf=\"showShareButton\"\n      class=\"icon more\"\n      data=\"share\"\n      [ngClass]=\"{'overlay': source === 'overlay' }\"\n      (click)=\"$event.stopPropagation(); $event.preventDefault(); share()\"\n  ></anghami-icon>\n  <ng-template #contextsheet>\n    <anghami-context-sheet \n      [type]=\"type\" \n      [source]=\"source\"\n      [data]=\"data\" \n      [currentList]=\"currentList\"\n      [isQueue]=\"isQueue\"\n      [isVideo]=\"data?.videoonly && data?.videoonly == 1\" \n      (likeTrack)=\"likeSong()\"\n      (playNextEvent)=\"playNext()\"\n      (playNowEvent)=\"playSong()\"\n      (deleteTrack) =\"removeSong()\"\n      (shareEvent) =\"share()\"\n      (closeContextSheet) = \"closePopover()\"\n    ></anghami-context-sheet>\n  </ng-template>\n</ng-container>\n    \n    \n\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/context-sheet/context-sheet.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/context-sheet/context-sheet.component.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"morewrapper\" *ngIf=\"type === 'song' || type === 'album' || type === 'podcast'\">\n  <div class=\"flex flex-row header more\">\n    <!-- <img class=\"coverart\" [src]=\"data.coverArtImage || data.coverArtImageSmall\"\n      onError=\"this.src='https://anghamiwebcdn.akamaized.net/assets/img/trackholder.jpg'\" /> -->\n    <div class=\"action-font\">\n      <div class=\"flex\">\n        <div class=\"trim title d-block\" dir=\"auto\">\n          {{ data?.title || data?.name }}\n        </div>\n      </div>\n      <div class=\"flex\">\n        <div class=\"trim artist\">{{ data?.artist || data?.description }}</div>\n      </div>\n      <div class=\"info\" *ngIf=\"type !== 'album'\">\n        <ng-container *ngIf=\"data?.likes\"> \n          {{ data?.likes | transformNumber }}\n          <ng-container i18n=\"@@Likes\"> likes </ng-container> \n          <ng-container *ngIf=\"data?.plays\"> | </ng-container>\n        </ng-container>\n        <ng-container *ngIf=\"data?.plays\"> {{ data?.plays | transformNumber }}  <ng-container i18n=\"@@Plays\"> plays </ng-container> </ng-container>\n        </div>\n    </div>\n  </div>\n</div>\n<div class=\"actions flex\" *ngIf=\"source !== 'player' && (type === 'song' || type === 'podcast')\">\n  <div class=\"action-item\">\n    <div class=\"play-action\" (click)=\"isCurrentSong ? playerAction('playpause') : playNowEvent.emit()\" [ngClass]=\"{'selected': isCurrentSong}\" placement=\"top\">\n      <anghami-icon class=\"icon\" [data]=\"currentPlayerOptions?.playing || currentPlayerOptions?.buffering? 'pause-shape' : 'play-shape'\" style=\"font-size: 15.5px\"></anghami-icon>\n    </div>\n    <ng-container *ngIf=\"currentPlayerOptions?.playing || currentPlayerOptions?.buffering; else notPlaying\">\n          <span i18n=\"@@Pause\"> Pause</span>\n    </ng-container>\n    <ng-template #notPlaying>\n          <span i18n=\"@@Play\"> Play</span>\n    </ng-template>\n  </div>\n  <div class=\"action-item\">\n    <div (click)=\"likeSong($event)\">\n      <anghami-icon class=\"icon\" [data]=\"data?.liked ? 'liked' : 'like'\" [ngStyle]=\"{'font-size': data?.liked ? '10px' : '9.5px' }\"></anghami-icon>\n    </div>\n    <ng-container *ngIf=\"data?.liked; else notLiked\">\n      <span i18n=\"@@Liked\"> Liked</span>\n    </ng-container>\n    <ng-template #notLiked>\n      <span i18n=\"@@Like\"> Like</span>\n    </ng-template>\n  </div>\n  <div class=\"action-item\" *ngIf=\"isloggedin && (type === 'song' || type === 'podcast')\">\n    <div class=\"flex flex-row item\" (click)=\"downloadSong()\">\n      <anghami-icon class=\"icon\" [data]=\"'download'\" style=\"font-size:13.5px; margin-bottom: 0.2em;\"></anghami-icon>\n    </div>\n    <ng-container *ngIf=\"data?.isDownloaded; else notDownloaded\">\n      <span i18n=\"@@Downloaded\"> Downloaded</span>\n    </ng-container>\n    <ng-template #notDownloaded>\n      <ng-container *ngIf=\"data?.isInDownloadQueue; else notDownloading\">\n          <span i18n=\"@@Downloading\"> Downloading</span>\n      </ng-container>\n      <ng-template #notDownloading>\n          <span i18n=\"@@Download\"> Download</span>\n      </ng-template>\n    </ng-template>\n  </div>\n  <div class=\"action-item\">\n    <div (click)=\"playNext(data?.id)\" [ngClass]=\"{'disabled': isCurrentSong}\">\n      <anghami-icon class=\"icon\" [data]=\"'playnext'\" style=\"font-size: 8px\"></anghami-icon>\n    </div>\n    <span i18n=\"@@Play Next\">\n      Play Next\n    </span>\n  </div>\n</div>\n<div class=\"details\" [class.gray-scale-disabled]=\"!(online$ | async)\">\n  <div class='divider' *ngIf=\"(type === 'song' || type === 'podcast')\"> </div>\n  <ng-container *ngIf=\"isPersonalStory\">\n      <div class=\"flex flex-row item\" (click)=\"removeStoryEvent.emit()\">\n        <anghami-icon class=\"icon\" [data]=\"'hide'\"></anghami-icon>\n        <span class=\"text\" i18n=\"@@stories_hidestory\">Hide from my story</span>\n      </div>\n      <div class=\"flex flex-row item\" (click)=\"editPrivacyEvent.emit()\">\n        <anghami-icon class=\"icon\" [data]=\"'edit'\"></anghami-icon>\n        <span class=\"text\" i18n=\"@@edit_profile_privacy\">Edit profile and privacy</span>\n      </div>\n  </ng-container>\n  <ng-container *ngIf=\"isloggedin && type === 'song'\">\n    <div class=\"flex flex-row item\" (click)=\"addToPlaylist()\">\n      <anghami-icon class=\"icon\" [data]=\"'add_to_playlist'\"></anghami-icon>\n      <span class=\"text\" i18n=\"@@Add to Playlist\">Add to Playlist</span>\n    </div>\n    <div class=\"flex flex-row item\" *ngIf=\"isOwner && !isQueue && currentList?.list_type == 'playlist'\" (click)=\"removeSongFromList()\">\n      <anghami-icon class=\"icon\" [data]=\"'delete'\"></anghami-icon>\n      <span class=\"text\" i18n=\"@@Remove from list\">Remove from list</span>\n    </div>\n  </ng-container>\n  \n  <div *ngIf=\"!isLocal && !isPersonalStory\" class=\"flex flex-row item\" (click)=\"share()\">\n    <anghami-icon class=\"icon\" [data]=\"'share'\"></anghami-icon>\n    <span class=\"text\" i18n=\"@@Share\">Share</span>\n  </div>\n  <div class=\"flex flex-row item\" *ngIf=\"source !== 'player' && !data?.isPodcast &&\n                  !isQueue && planId === '3' \" (click)=\"addToQueue(data?.id, data?.genericid)\">\n    <anghami-icon class=\"icon\" [data]=\"'AddToQueue'\"></anghami-icon>\n    <span class=\"text\" i18n=\"@@Add to Queue\">Add to Queue</span>\n  </div>\n  <div class=\"flex flex-row item\" *ngIf=\"!isLocal && type === 'song'\" (click)=\"getSong()\">\n    <anghami-icon class=\"icon\" [data]=\"'radio'\"></anghami-icon>\n    <span class=\"text\" i18n=\"@@Play more like this\">Play more like this</span>\n  </div>\n  <ng-container *ngIf=\"type === 'album' && !isLocal && data?.artistID != '414'\">\n    <a [routerLink]=\"['/artist/' + data?.artistID]\" target=\"{{type === 'story' ? '_blank' : '_self'}}\">\n      <div class=\"flex flex-row item\">\n        <anghami-icon class=\"icon\" [data]=\"'artist'\"></anghami-icon>\n        <span class=\"text\"> <span i18n=\"@@Go To Artist\">Go to artist</span> </span>\n      </div>\n    </a>\n  </ng-container>\n\n  <ng-container *ngIf=\"type === 'song'\">\n    <a [routerLink]=\"['/' + currentList.list_type + '/' + currentList?.id]\" *ngIf=\"source === 'player' && currentList?.id\">\n      <div class=\"flex flex-row item\">\n        <anghami-icon class=\"icon\" [data]=\"'playlist'\"></anghami-icon>\n        <span class=\"text\" i18n=\"@@Go To Playlist\">Go to Playlist </span>\n      </div>\n    </a>\n    <ng-container *ngIf=\"!isLocal\">\n      <a [routerLink]=\"['/artist/' + data?.artistID]\" target=\"{{source === 'story' ? '_blank' : '_self'}}\"\n        *ngIf=\"data?.artistID != '414'\">\n        <div class=\"flex flex-row item\">\n          <anghami-icon class=\"icon\" [data]=\"'artist'\"></anghami-icon>\n          <span class=\"text\"> <span i18n=\"@@Go To Artist\">Go to artist</span> </span>\n        </div>\n      </a>\n      <!-- <a [routerLink]=\"['/song/' + data?.id]\">\n        <div class=\"flex flex-row item\">\n          <anghami-icon class=\"icon\" [data]=\"'AddToSong'\"></anghami-icon>\n          <span class=\"text\">\n            <span i18n=\"@@Go To Song\">Go to song</span>\n          </span>\n        </div>\n      </a> -->\n      <a [routerLink]=\"['/album/' + data?.albumID]\"\n        target=\"{{source === 'story' && !isDesktopClient ? '_blank' : '_self'}}\">\n        <div class=\"flex flex-row item\">\n          <anghami-icon class=\"icon\" [data]=\"'albums'\"></anghami-icon>\n          <span class=\"text\">\n            <span i18n=\"@@Go To Album\">Go to album</span>\n          </span>\n        </div>\n      </a>\n      <!-- <a [routerLink]=\"['/video/' + data?.id]\" target=\"{{source === 'story' && !isDesktopClient ? '_blank' : '_self'}}\"\n        *ngIf=\"data?.videoid\">\n        <div class=\"flex flex-row item\">\n          <anghami-icon class=\"icon\" [data]=\"'music-videos'\"></anghami-icon>\n          <span class=\"text\">\n            <span i18n=\"@@Go To Video\">Go to video</span>\n          </span>\n        </div>\n      </a> -->\n    </ng-container>\n  </ng-container>\n  <ng-container *ngIf=\"type === 'podcast'\">\n    <ng-container *ngIf=\"!isLocal\">\n      <a [routerLink]=\"['/podcaster/' + data?.artistID]\" target=\"{{source === 'story' ? '_blank' : '_self'}}\"\n        *ngIf=\"data?.artistID != '414'\">\n        <div class=\"flex flex-row item\">\n          <anghami-icon class=\"icon\" [data]=\"'artist'\"></anghami-icon>\n          <span class=\"text\"> <span i18n=\"@@go_to_podcaster\">Go to podcaster</span> </span>\n        </div>\n      </a>\n      <a [routerLink]=\"['/podcast/' + data?.albumID]\"\n        target=\"{{source === 'story' && !isDesktopClient ? '_blank' : '_self'}}\">\n        <div class=\"flex flex-row item\">\n          <anghami-icon class=\"icon\" [data]=\"'albums'\"></anghami-icon>\n          <span class=\"text\">\n            <span i18n=\"@@go_to_podcast\">Go to podcast</span>\n          </span>\n        </div>\n      </a>\n      <a [routerLink]=\"['/episode/' + data?.id]\">\n        <div class=\"flex flex-row item\">\n          <anghami-icon class=\"icon\" [data]=\"'AddToSong'\"></anghami-icon>\n          <span class=\"text\">\n            <span i18n=\"@@go_to_episode\">Go to episode</span>\n          </span>\n        </div>\n      </a>\n    </ng-container>\n  </ng-container>\n\n<div class=\"flex flex-row item bottom-item\"\n  *ngIf=\"!isDesktopClient && (type === 'song' || type === 'playlist' || type === 'albums' || type === 'podcast')\"\n  (click)=\"openInDesktopDialog()\">\n  <anghami-icon class=\"icon\" [data]=\"'desktop'\"></anghami-icon>\n  <span class=\"text\" i18n=\"@@open_desk_app\">Open in desktop app</span>\n</div>\n</div>\n<!-- <button (click)=\"debug()\"> Debug </button> -->"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/empty-search/empty-search.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/empty-search/empty-search.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"section-wrapper\">\n  <div class=\"empty-header\">\n    <anghami-icon class=\"icon recent-icon \" [data]=\"'search'\"></anghami-icon>\n    <h1 *ngIf=\"info\" class=\"header-1\">{{ info }}</h1>\n    <h1 i18n=\"@@discover_trending\" class=\"header-2\">\n      Discover what's trending on Anghami\n    </h1>\n  </div>\n  <span class=\"card-wrapper\" *ngIf=\"(searchSuggestion$ | async)?.length !== 0\">\n    <div class=\"container\">\n      <div class=\"row\">\n\n        <anghami-card-item *ngFor=\"let item of searchResults.data | slice: 0:4\" class=\"collection-item\"\n          [ngClass]=\"[searchResults?.displaytype, searchResults?.type]\" [displayType]=\"searchResults?.displaytype\" [type]=\"searchResults?.type\" [collectionItem]=\"item\">\n        </anghami-card-item>\n      </div>\n    </div>\n  </span>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/jsonhp-button/jsonhp-button.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/jsonhp-button/jsonhp-button.component.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<a [href]=\"buttondata.href\" (click)=\"handlebutton($event, buttondata)\">\n  <div class=\"image\" [ngStyle]=\"getGradient()\">\n    <img [src]=\"buttondata.image\" *ngIf=\"buttondata.image\" />\n  </div>\n  <div class=\"text\">\n    {{ buttondata.title }}\n  </div>\n  <anghami-icon class=\"icon arrow\" [data]=\"'arrow-left'\"></anghami-icon>\n</a>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/card-item/card-item.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/new-section-builder/card-item/card-item.component.html ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container>\n  <div [ngClass]=\"[\n      'collection-item-template',\n      displayType,\n      type,\n      collectionItem?.generictype || ''\n    ]\" [class.unmatched]=\"collectionItem?.unmatched\" [class.disabled]=\"\n      collectionItem?.generictype === 'artist' && collectionItem?.id == '414'\n    \">\n    <ng-container *ngIf=\"displayType === 'widenew'\">\n      <a [routerLink]=\"collectionItem?.deeplink?null:collectionItem?.href\" [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\" anghamiExtras [extras]=\"collectionItem?.extras\" class=\"d-flex hover-none w-100\" (click)=\"clickHandler()\">\n        <div *ngIf=\"type !== 'video'\" class=\"widenew-image\" [lazyLoad]=\"collectionItem.coverArtImageRect\"></div>\n        <div *ngIf=\"type === 'video'\" class=\"widenewvideo\">\n          <div class=\"widenew-image\" [lazyLoad]=\"collectionItem.coverArtImage\"></div>\n          <anghami-icon class=\"play-video-icon\" [data]=\"'play'\"></anghami-icon>\n        </div>\n        <div class=\"item-title\" >\n          <h2>{{ collectionItem?.title }}</h2>\n          <span>{{ collectionItem?.details || collectionItem.artist }}</span>\n          <div class=\"latest-date\" *ngIf=\"collectionItem?.islatestrelease\">\n            {{ collectionItem?.releasedate | formatDate }}\n          </div>\n          <button *ngIf=\"collectionItem?.button_text\" class=\"card-button\"  [class.anghami-primary-btn]=\"true\">\n              {{ collectionItem?.button_text }}\n          </button>\n        </div>\n      </a>\n    </ng-container>\n    <ng-container *ngIf=\"displayType !== 'widenew' && displayType !== 'carousel' && displayType !== 'card_carousel'\">\n      <a [routerLink]=\"collectionItem?.href\" [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\" anghamiExtras [extras]=\"collectionItem?.extras\">\n        <div class=\"item-image\" [lazyLoad]=\"collectionItem?.coverArtImage\">\n          <anghami-overlay-collection-controls (overlayAction)=\"overlayAction($event)\" [data]=\"collectionItem\" [type]=\"collectionItem?.genericid ? 'generic' : type\"\n            *ngIf=\"shouldShowControls\" [isContextSheet]=\"collectionItem?.isContextSheet\"></anghami-overlay-collection-controls>\n          <span class=\"exclusive-badge\" *ngIf=\"collectionItem?.exclusive == '1'\" i18n=\"@@exclusive\">exclusive</span>\n        </div>\n      </a>\n      <a  [routerLink]=\"collectionItem?.href\" [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\" class=\"item-title-primary\" [ngClass]=\"{\n          isowner: collectionItem?.Owner,\n          'align-collection-item':\n            collectionItem?.details || collectionItem?.artist\n        }\">\n        <div class=\"item-name max-2-lines w-100\" [ngClass]=\"{\n            'artist-block': collectionItem.verified == 1 && collectionItem?.name\n          }\" [title]=\"collectionItem?.title || collectionItem?.name\">\n          {{ collectionItem?.title || collectionItem?.name }}\n          <div class=\"verified-artist float-right\" *ngIf=\"collectionItem.verified == 1 && collectionItem?.name\"></div>\n\n          <div class=\"latest-date\" *ngIf=\"collectionItem?.islatestrelease\">\n            {{ collectionItem?.releasedate | formatDate }}\n          </div>\n        </div>\n        <div class=\"flex align-items-center owner\" *ngIf=\"collectionItem?.Owner\">\n          <img [src]=\"collectionItem?.OwnerPicture\" [attr.alt]=\"collectionItem?.Owner\" />\n          <div class=\"name\">{{ collectionItem?.Owner }}</div>\n        </div>\n      </a>\n      <div class=\"item-title-secondary\"  *ngIf=\"collectionItem?.artist\">\n        <a class=\"float-left max-2-lines hoverable\" [routerLink]=\"['/artist/' + collectionItem?.artistID]\" [class.disabled]=\"collectionItem?.artistID == '414'\">{{ collectionItem?.artist }}</a>\n      </div>\n      <div  class=\"item-title-secondary\" *ngIf=\"collectionItem.details\">\n        <anghami-icon class=\"icon private-padding d-inline-block lock\" *ngIf=\"displayType == 'list'\" [data]=\"'lock'\" [ngClass]=\"{\n            visible: collectionItem?.public === 'false' && displayType == 'list'\n          }\"></anghami-icon>\n        <a [routerLink]=\"collectionItem?.href\" [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\" class=\"float-left max-2-lines\">{{ collectionItem.details }}\n        </a>\n      </div>\n    </ng-container>\n  </div>\n  <ng-container *ngIf=\"displayType === 'card_carousel' || displayType === 'carousel'\">\n    <a [ngClass]=\"[\n    'collection-item-template',\n    displayType,\n    type,\n    collectionItem?.generictype || ''\n  ]\" [routerLink]=\"type !== 'song' && !hrefHasHttp ? [collectionItem?.href] : []\" anghamiExtras [extras]=\"collectionItem?.extras\" [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\" [class.disabled]=\"\n    collectionItem?.generictype === 'artist' && collectionItem?.id == '414'\n  \" (click)=\"playSong()\">\n      <div class=\"item-image\" [lazyLoad]=\"collectionItem?.coverArtImage\" >\n        <anghami-overlay-collection-controls *ngIf=\"shouldShowControlsCarousel\" (overlayAction)=\"overlayAction($event)\" [data]=\"collectionItem\"\n          [type]=\"type\" [isContextSheet]=\"collectionItem?.isContextSheet\"></anghami-overlay-collection-controls>\n        <ng-container *ngIf=\"type === 'link' && collectionItem.big !== 1\">\n          <div class=\"bottom-title\" *ngIf=\"collectionItem?.title || collectionItem?.supertitle\">\n            <div class=\"gradient-overlay\" [ngStyle]=\"getGradient()\"></div>\n            <div class=\"gradient-overlay-dark\"></div>\n            <div class=\"supertitle\" *ngIf=\"collectionItem?.supertitle?.length\" >\n              <span>{{ collectionItem?.supertitle }}</span>\n            </div>\n            <div class=\"title\">\n              <div class=\"item-name float-left max-2-lines\">\n                <span class=\"text-wrapper\">{{ collectionItem?.title }}</span>\n              </div>\n            </div>\n            <div class=\"description\">\n              <div class=\"item-name float-left max-2-lines\">\n                {{ collectionItem?.description }}\n              </div>\n            </div>\n          </div>\n        </ng-container>\n        <div class=\"explicit card-item-explicit\" *ngIf=\"collectionItem.explicit === '1'\">\n          <span class=\"e-block\">e</span>\n        </div>\n      </div>\n      <ng-container *ngIf=\"type !== 'link' || collectionItem.big === 1\">\n        <a  [routerLink]=\"collectionItem?.href\" [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\" class=\"item-title-primary\" [ngClass]=\"{\n              isowner: collectionItem?.Owner,\n              'align-collection-item':\n                collectionItem?.details || collectionItem?.artist\n            }\">\n          <div class=\"item-label\" *ngIf=\"collectionItem?.supertitle\">\n            {{ collectionItem?.supertitle }}\n          </div>\n          <div class=\"item-name max-2-lines w-100\" [ngClass]=\"{\n                'artist-block': collectionItem.verified == 1 && collectionItem?.name\n              }\" [title]=\"collectionItem?.title || collectionItem?.name\">\n              <span class=\"text-wrapper\">{{ collectionItem?.title || collectionItem?.name }}</span>\n            <div class=\"verified-artist float-right\" *ngIf=\"collectionItem.verified == 1 && collectionItem?.name\"></div>\n\n            <div class=\"latest-date\" *ngIf=\"collectionItem?.islatestrelease\">\n              {{ collectionItem?.releasedate | formatDate }}\n            </div>\n          </div>\n          <div class=\"flex align-items-center owner\" *ngIf=\"collectionItem?.Owner\">\n            <img [src]=\"collectionItem?.OwnerPicture\" [attr.alt]=\"collectionItem?.Owner\" />\n            <div class=\"name\">{{ collectionItem?.Owner }}</div>\n          </div>\n        </a>\n        <div class=\"item-title-secondary\"  *ngIf=\"collectionItem?.artist\">\n        <a class=\"float-left max-2-lines hoverable\" [routerLink]=\"['/artist/' + collectionItem?.artistID]\" [class.disabled]=\"collectionItem?.artistID == '414'\">{{ collectionItem?.artist }}</a>\n        </div>\n      </ng-container>\n    </a>\n  </ng-container>\n</ng-container>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/card-section/card-section.component.html":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/new-section-builder/card-section/card-section.component.html ***!
  \************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"isCardItem\">\n  <div class=\"container-fluid\">\n    <div\n      class=\"row\"\n      [ngClass]=\"[isMulitilineCard ? 'section_' + section.hash : '']\"\n      [attr.id]=\"[isMulitilineCard ? 'section_' + section.hash : '']\"\n    >\n      <div\n        [ngClass]=\" {\n          'multiline-card-container' : isMultilineCard,\n          'widenew-container' : isWideNew,\n          'small-button-container' : isSmallButton\n        }\"\n        *ngFor=\"let item of section.data | slice: 0:(section.initialNumItems || section.data.length)\" \n      >\n        <anghami-card-item\n          class=\" collection-item \"\n          [collectionItem]=\"item\"\n          [class.unmatched]=\"item.unmatched\"\n          [displayType]=\"section.displaytype\"\n          [type]=\"section.type\"\n        ></anghami-card-item>\n      </div>\n    </div>\n  </div>\n</ng-container>\n<ng-container *ngIf=\"isQuestion\">\n  <anghami-question-item [type]=\"section.type\" [section]=\"section\"></anghami-question-item>\n  <!--<div class=\"question-card\">\n    <div class=\"question-left\">\n      <div>{{section.message}}</div>\n      <div>\n        <button \n          class=\"anghami-primary-btn\" \n          *ngFor=\"let button of section.data\"\n          (click)=\"handleQuestionClick(button.url)\">\n          {{button.title}}\n        </button>\n      </div>\n    </div>\n    <div class=\"question-right\">\n      <img [src]=\"section.image\">\n    </div>\n    <div class=\"close-question\" *ngIf=\"section.allowclose\" (click)=\"closeQuestion()\"> × </div>\n  </div>-->\n</ng-container>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/list-item/list-item.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/new-section-builder/list-item/list-item.component.html ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container\n  *ngIf=\"collectionItem?.is_podcast && (displayType === 'progress_card' || currentList?.is_podcast); else notPodcast\">\n  <div class=\"common-list-item podcast-list-item\"\n    [ngClass]=\"{'search-edge-item':fromSearchEdgeContainer}\"\n    [class.unmatched]=\"collectionItem?.unmatched\" [class.grayscale]=\"collectionItem?.disabled\"\n    [class.disabled]=\"collectionItem?.generictype === 'artist' && collectionItem?.id == '414'\"\n    (click)=\"clickHandler($event,index)\" anghamiExtras [extras]=\"collectionItem?.extras\"\n    [routerLink]=\"!shouldShowPlayIcon ? [collectionItem?.href] : []\"\n    [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\">\n    <div class=\"flex\">\n      <div class=\"list-item-details\">\n        <a class=\"item-title-primary\" [ngClass]=\"{\n                  isowner: collectionItem?.Owner,\n                  'align-collection-item': collectionItem?.details || collectionItem?.artist\n                }\">\n          <div class=\"item-name\" [ngClass]=\"{\n                      'artist-block': collectionItem.verified == 1 && collectionItem?.name,\n                      'arabic-item-details': collectionItem?.arabictext\n                    }\" [title]=\"collectionItem?.title || collectionItem?.name\">\n            <span class=\"text-wrapper\">{{ collectionItem?.title || collectionItem?.name }}</span>\n          </div>\n\n          <div class=\"track-date-duration\">\n            <span>{{ collectionItem?.releasedate | formatDate }}</span>\n            <span>{{ collectionItem?.duration | convertDuration }} <ng-container i18n=\"Got_page_minutes\">minutes\n              </ng-container></span>\n          </div>\n        </a>\n      </div>\n      <div class=\"list-item-actions\">\n        <anghami-icon (click)=\"$event.stopPropagation()\" class=\"icon\" [data]=\"'music-videos'\"\n          *ngIf=\"collectionItem?.videoid && type !== 'queue'\" [routerLink]=\"['/video/' + collectionItem?.id]\">\n        </anghami-icon>\n        <anghami-context-sheet-new type=\"podcast\" [data]=\"collectionItem\" [currentList]=\"list\" [isQueue]=\"isQueue\"\n          [placement]=\"['bottom', 'auto']\" (playNowEvent)=\"clickHandler()\">\n        </anghami-context-sheet-new>\n      </div>\n    </div>\n    <div class=\"description\" *ngIf=\"collectionItem?.description\">\n      {{shortenText(collectionItem.description)}}\n    </div>\n    <ng-container *ngIf=\"podcastItemWithPodcast\">\n      <div class=\"podcast-progress\" *ngFor=\"let progressData of calculatePercentage()\">\n        <div class=\"progress\">\n          <div class=\"progress-bar\" role=\"progressbar\" [ngStyle]=\"{width: progressData.currentProgress + '%'}\"\n            [attr.aria-valuenow]=\"progressData.currentProgress\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\n        </div>\n        <span> {{ progressData.timeLeft | convertDurationReadable }}</span>\n      </div>\n    </ng-container>\n    <div class=\"download-progress-bar-container\" *ngIf=\"collectionItem.isInDownloadQueue\">\n      <div class=\"download-progress-bar\" [ngStyle]=\"{ width: collectionItem.downloadProgress + '%' }\"></div>\n    </div>\n\n  </div>\n</ng-container>\n<ng-template #notPodcast>\n  <div class=\"common-list-item\" [ngClass]=\"[\n      'list-item',\n      displayType || '',\n      type || '',\n      collectionItem?.generictype || '',\n      collectionItem.selectedSongId ? 'selected-song' : '',\n      fromSearchEdgeContainer ? 'search-edge-item' : ''\n    ]\" [class.current-track]=\"collectionItem?.isCurrentTrack\" [class.unmatched]=\"collectionItem?.unmatched\"\n    [class.grayscale]=\"collectionItem?.disabled\"\n    [class.disabled]=\"collectionItem?.generictype === 'artist' && collectionItem?.id == '414'\"\n    (click)=\"clickHandler($event)\" anghamiExtras [extras]=\"collectionItem?.extras\" [routerLink]=\"!shouldShowPlayIcon && !collectionItem.isPlaying &&\n    collectionItem?.generictype !== 'link' ? [collectionItem?.href] : []\"\n    [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\">\n\n    <!--<a [routerLink]=\"collectionItem?.href\" *ngIf=\"type !== 'song' && collectionItem.generictype !== 'song'\" class=\"list-item-click-block\"></a>-->\n    <div class=\"item-top\" *ngIf=\"collectionItem.rankchange || top == 1\">\n      <div>{{ index +1 }}</div>\n      <div>\n        <anghami-icon *ngIf=\"collectionItem.rankchange\" class=\"icon {{ collectionItem.rankchange }}\" [data]=\"collectionItem.rankchange\"></anghami-icon>\n      </div>\n    </div>\n    <div class=\"queue-actions\" *ngIf=\"type === 'queue'\">\n      <anghami-icon (click)=\"removeFromQueue($event, index)\" class=\"icon remove\" [data]=\"'remove'\"></anghami-icon>\n      <anghami-icon class=\"handle\" [data]=\"'rearrange'\" (mousedown)=\"$event.stopPropagation()\"\n        (touchstart)=\"$event.stopPropagation()\"></anghami-icon>\n\n    </div>\n\n\n\n    <div class=\"list-item-image\"\n      [routerLink]=\"!shouldShowPlayIcon && !collectionItem.isPlaying ? [collectionItem?.href] : []\"\n      [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\" [scrollTarget]=\"scrollTarget\"\n      [lazyLoad]=\"collectionItem?.coverArtImage\" *ngIf=\"!isAlbumView\">\n      <div class=\"equalizer\">\n        <anghami-equalizer *ngIf=\"collectionItem?.isPlaying\"></anghami-equalizer>\n      </div>\n      <div class=\"explicit list-item-explicit\" *ngIf=\"collectionItem?.explicit == '1'\">\n        <span class=\"e-block\">e</span>\n      </div>\n\n      <span class=\"list-item-play-icon \" *ngIf=\"shouldShowPlayIcon\">\n        <anghami-icon class=\"icon\" [data]=\"'play'\"></anghami-icon>\n      </span>\n\n      <span class=\"exclusive-badge\" *ngIf=\"collectionItem?.exclusive == '1'\" i18n=\"@@exclusive\">\n        exclusive\n      </span>\n    </div>\n    <div class=\"album-list-item-image\" *ngIf=\"isAlbumView\">\n      <div class=\"equalizer\">\n        <anghami-equalizer *ngIf=\"collectionItem?.isPlaying\"></anghami-equalizer>\n      </div>\n    </div>\n    <div class=\"list-item-details\">\n      <a class=\"item-title-primary\" [ngClass]=\"{\n              isowner: collectionItem?.Owner,\n              'align-collection-item': collectionItem?.details || collectionItem?.artist\n            }\">\n        <div class=\"item-name\" [ngClass]=\"{\n                  'artist-block': collectionItem.verified == 1 && collectionItem?.name,\n                  'arabic-item-details': collectionItem?.arabictext\n                }\" [title]=\"collectionItem?.title || collectionItem?.name\">\n          <span class=\"text-wrapper\">{{ (collectionItem?.title || collectionItem?.name) | ellipsis: 35 }}</span>\n          <div class=\"verified-artist \" *ngIf=\"collectionItem.verified == 1 && collectionItem?.name\"></div>\n\n          <div class=\"latest-date\" *ngIf=\"collectionItem?.islatestrelease\">\n            {{ collectionItem?.releasedate | formatDate }}\n          </div>\n        </div>\n\n        <div *ngIf=\"collectionItem?.Owner\" class=\"owner-container\">\n          <img [src]=\"collectionItem?.OwnerPicture\" class=\"owner-picture\" [attr.alt]=\"collectionItem?.Owner\" />\n          <div class=\"owner-name\">{{ collectionItem?.Owner }}</div>\n        </div>\n\n      </a>\n\n      <div class=\"item-title-secondary\" *ngIf=\"collectionItem?.artist\" [class.gray-scale-disabled]=\"offlineMode\">\n        <a [ngClass]=\"{'arabic-item-details': collectionItem?.arabictext}\" class=\"max-2-lines hoverable\"\n          [routerLink]=\"[collectionItem.is_podcast ? '/podcaster' : '/artist', collectionItem?.artistID]\"\n          [class.disabled]=\"collectionItem?.artistID == '414'\"\n          (click)=\"$event.stopPropagation()\">{{ collectionItem?.artist | ellipsis: 40}}</a>\n      </div>\n\n      <div class=\"item-title-secondary\" *ngIf=\"collectionItem.details && collectionItem.generictype === 'playlist'\">\n        <anghami-icon class=\"icon private-padding d-inline-block lock visible\"\n          *ngIf=\"collectionItem?.public === 'false' \" [data]=\"'lock'\">\n        </anghami-icon>\n        <a [routerLink]=\"collectionItem?.href\" [attr.rel]=\"collectionItem.nofollow ? 'nofollow' : ''\"\n          class=\"float-left max-2-lines\">\n          {{ collectionItem.details }}\n        </a>\n      </div>\n    </div>\n    <div class=\"generic-type\" *ngIf=\"collectionItem.generictype && collectionItem.generictype !== 'song'\n      && !collectionItem.supertitle\">\n      {{ collectionItem.generictype.toUpperCase() }}\n    </div>\n    <div class=\"generic-type\"\n      *ngIf=\"collectionItem.supertitle && collectionItem.generictype !== 'song' && type !== 'song'\">\n      {{ collectionItem.supertitle.toUpperCase() }}\n    </div>\n    <div class=\"list-item-actions\" *ngIf=\"isBrowser\">\n      <anghami-icon (click)=\"$event.stopPropagation()\" class=\"icon\" [data]=\"'music-videos'\"\n        *ngIf=\"collectionItem?.videoid && type !== 'queue'\" [routerLink]=\"['/video/' + collectionItem?.id]\">\n      </anghami-icon>\n      <anghami-icon class=\"icon\" (click)=\"downloadSong($event)\" [data]=\"'download'\"\n        *ngIf=\"!collectionItem?.isDownloaded && (type === 'song' || collectionItem.generictype === 'song')\">\n      </anghami-icon>\n      <anghami-icon class=\"icon\" [data]=\"'downloaded'\" *ngIf=\"collectionItem?.isDownloaded && type !== 'queue'\">\n      </anghami-icon>\n      <anghami-icon class=\"icon\" [data]=\"collectionItem.liked ? 'liked' : 'like'\" [ngClass]=\"{\n            hidden: !shouldShowLikeButton,\n            liked: collectionItem.liked\n          }\" (click)=\"handleLikeClick($event,index)\" *ngIf=\"shouldShowLikeButton\">\n      </anghami-icon>\n      <anghami-context-sheet-new *ngIf=\"isBrowser\"\n        [type]=\"collectionItem.is_podcast ? 'podcast' : collectionItem.generictype ? collectionItem.generictype : type === 'queue' ? 'song' : type\"\n        source=\"list\" [currentList]=\"currentList\" [data]=\"collectionItem\" [isQueue]=\"type === 'queue'\"\n        [placement]=\"['bottom', 'auto']\" (playNowEvent)=\"clickHandler()\">\n      </anghami-context-sheet-new>\n    </div>\n    <div class=\"download-progress-bar-container\" *ngIf=\"collectionItem.isInDownloadQueue\">\n      <div class=\"download-progress-bar\" [ngStyle]=\"{ width: collectionItem.downloadProgress + '%' }\"></div>\n    </div>\n\n  </div>\n</ng-template>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/list-section/list-section.component.html":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/new-section-builder/list-section/list-section.component.html ***!
  \************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"shouldShowAutoDownloadsComponent\">\n  <anghami-auto-downloads></anghami-auto-downloads>\n</ng-container>\n<div class=\"d-flex\" *ngIf=\"vibesLookup && (vibesLookup|json) !== '{}'\">\n  <div class=\"swiper-container overflow-hidden w-100\" #carouselContainer>\n    <div class=\"vibes-tags-container swiper-wrapper\">\n      <ng-container *ngFor=\"let vibe of filterVibesBySectionSize(vibesLookup)\">\n        <div class=\"swiper-slide\" *ngIf=\"vibesLookup[vibe].name\">\n          <div (click)=\"filterByVibe(vibe)\" class=\"vibes-tag\" [ngClass]=\"{ 'selected-vibe': vibe === selectedVibe }\">\n            <div class=\"vibes-number\" *ngIf=\"vibe === selectedVibe\">\n              {{ vibesLookup[vibe].section.length }}\n            </div>\n            <div class=\"vibes-name\">{{ vibesLookup[vibe].name }}</div>\n          </div>\n        </div>\n      </ng-container>\n    </div>\n  </div>\n  <div #prev class=\"swiper-button-prev\" *ngIf=\"!hideSwiperButtons\">\n    <span class=\"arrow left\">\n      <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 5.792 10.208\">\n        <path id=\"Path_3208\" data-name=\"Path 3208\" d=\"M4.625,10.023a.681.681,0,0,0,.481.209.636.636,0,0,0,.481-.209.67.67,0,0,0,0-.963L1.653,5.126,5.588,1.192a.67.67,0,0,0,0-.963.67.67,0,0,0-.963,0L.209,4.645A.681.681,0,0,0,0,5.126a.606.606,0,0,0,.209.481Zm0,0\"\n          transform=\"translate(0 -0.025)\" />\n      </svg>\n    </span>\n  </div>\n  <div #next class=\"swiper-button-next\" *ngIf=\"!hideSwiperButtons\">\n    <span class=\"arrow right\">\n      <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 5.792 10.208\">\n        <path id=\"Path_3208\" data-name=\"Path 3208\" d=\"M4.625,10.023a.681.681,0,0,0,.481.209.636.636,0,0,0,.481-.209.67.67,0,0,0,0-.963L1.653,5.126,5.588,1.192a.67.67,0,0,0,0-.963.67.67,0,0,0-.963,0L.209,4.645A.681.681,0,0,0,0,5.126a.606.606,0,0,0,.209.481Zm0,0\"\n          transform=\"translate(0 -0.025)\" />\n      </svg>\n    </span>\n  </div>\n</div>\n<ng-container *ngIf=\"section.group !== 'bio' && section.group !== 'social' && (section.type !== 'button' || section.group === 'social_video_button')\">\n  <ng-container *ngFor=\"\n      let item of section.data | slice: 0:listItemsMaxNum;\n      let i = index;\n      trackBy: trackByFn;\n    \">\n    <anghami-list-item [displayType]=\"section?.displaytype\" [top]=\"section?.top\" [class.unmatched]=\"item.unmatched\" [type]=\"section?.type\" [collectionItem]=\"item\" [currentList]=\"collectionMeta\" [fromSearch]=\"fromSearch\" [isSearchActiveTabSong]=\"isSearchActiveTabSong\" [index]=\"i\" (listItemClickEvent)=\"progagateListItemClickEvent($event)\" [isAlbumView]=\"isAlbumView\" [fromSearchEdgeContainer]=\"fromSearchEdgeContainer\" ></anghami-list-item>\n  </ng-container>\n</ng-container>\n<anghami-jsonhp-button *ngIf=\"section.type === 'button' && section.group != 'social_video_button'\" [section]=\"section\"></anghami-jsonhp-button>\n<ng-container *ngIf=\"section.group === 'bio'\">\n  <div class=\"row \">\n    <div class=\"col-sm-12\">\n      <div>\n        <p class=\"bio-scrollable \">\n          {{ section.text }}\n        </p>\n      </div>\n    </div>\n  </div>\n</ng-container>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/new-carousel/new-carousel.component.html":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/new-section-builder/new-carousel/new-carousel.component.html ***!
  \************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"d-flex\" [ngStyle]=\"{'visibility' : swiperInitialized ? 'visible' : 'hidden'}\" *ngIf=\"isBrowser\">\n  <div class=\"carousel-btn-container\">\n      <button \n        #prev \n        class=\"swiper-button-prev\" \n        [ngStyle]=\"{ visibility: isSwiperBeginning || !swiperInitialized ? 'hidden' : 'visible' }\"\n        [ngClass]=\"{'translate-y-1rem-left' : section.displaytype === 'carousel'}\" \n        (click)=\"updateArrowState()\">\n          <span class=\"arrow left\">\n            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"50\" height=\"50\" viewBox=\"0 0 501.5 501.5\">\n              <g>\n                <path d=\"M302.67 90.877l55.77 55.508L254.575 250.75 358.44 355.116l-55.77 55.506L143.56 250.75z\" />\n              </g>\n            </svg>\n          </span>\n        </button>\n  </div>\n  <div class=\"swiper-container overflow-hidden w-100\" #carouselContainer>\n    <div class=\"swiper-wrapper d-flex\">\n      <ng-container *ngFor=\"\n        let item of section.data;\n        trackBy: trackByFn\">\n        <div class=\"swiper-slide\">\n          <anghami-card-item \n            class=\" collection-item \" \n            [collectionItem]=\"item\" \n            [class.unmatched]=\"item.unmatched\" \n            [displayType]=\"section.displaytype\"\n            [type]=\"section.type\"\n            (cardItemClickEvent)=\"progagateCardItemClickEvent($event)\">\n          </anghami-card-item>\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"section.moreData\">\n        <div class=\"swiper-slide\">\n          <div>\n            <div\n              class=\"show-more\" \n              (click)=\"emitHasMoreData()\">\n              <div class=\"show-more-alltitle\">\n                <span>\n                  {{ section.alltitle }}\n                  <span class=\"alltitle-arrow\"></span>\n                </span>\n              </div>\n            </div>\n          </div>\n        </div>\n      </ng-container>\n    </div>\n  </div>\n  <div class=\"carousel-btn-container\">\n      <button \n        #next \n        class=\"swiper-button-next\" \n        [ngStyle]=\"{ visibility: isSwiperEnd || !swiperInitialized ? 'hidden' : 'visible' }\" \n        [ngClass]=\"{'translate-y-1rem-right' : section.displaytype === 'carousel'}\"\n        (click)=\"updateArrowState()\">\n          <span class=\"arrow right\">\n            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"50\" height=\"50\" viewBox=\"0 0 501.5 501.5\">\n              <g>\n                <path d=\"M199.33 410.622l-55.77-55.508L247.425 250.75 143.56 146.384l55.77-55.507L358.44 250.75z\" />\n              </g>\n            </svg>\n          </span>\n        </button>\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/new-section-builder.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/new-section-builder/new-section-builder.component.html ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div *ngIf=\"shouldShowTopContainer\">\n  <div class=\"d-flex\" *ngIf=\"collectionMeta && type === 'artist' && !artistSearchActive\">\n    <div class=\"section-tabs swiper-container\" #carouselContainer>\n      <ul class=\"swiper-wrapper\">\n        <li class=\"swiper-slide\">\n          <a [class.active-tab]=\"!activeSectionId\" href=\"javascript:void(0)\" (click)=\"removeSectionFilter()\">\n            All\n          </a>\n        </li>\n        <li class=\"swiper-slide\" *ngFor=\"let sectionTab of sectionsTabs\">\n          <a [class.active-tab]=\"activeSectionId == sectionTab.id\" href=\"javascript:void(0)\"\n            (click)=\"changeActiveSection(sectionTab)\" rel=\"nofollow\">\n            {{sectionTab.title}}\n          </a>\n        </li>\n      </ul>\n    </div>\n    <div #prev class=\"swiper-button-prev\" *ngIf=\"!hideSwiperButtons\">\n      <span class=\"arrow left\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 5.792 10.208\">\n          <path id=\"Path_3208\" data-name=\"Path 3208\"\n            d=\"M4.625,10.023a.681.681,0,0,0,.481.209.636.636,0,0,0,.481-.209.67.67,0,0,0,0-.963L1.653,5.126,5.588,1.192a.67.67,0,0,0,0-.963.67.67,0,0,0-.963,0L.209,4.645A.681.681,0,0,0,0,5.126a.606.606,0,0,0,.209.481Zm0,0\"\n            transform=\"translate(0 -0.025)\" />\n        </svg>\n      </span>\n    </div>\n    <div #next class=\"swiper-button-next\" *ngIf=\"!hideSwiperButtons\">\n      <span class=\"arrow right\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 5.792 10.208\">\n          <path id=\"Path_3208\" data-name=\"Path 3208\"\n            d=\"M4.625,10.023a.681.681,0,0,0,.481.209.636.636,0,0,0,.481-.209.67.67,0,0,0,0-.963L1.653,5.126,5.588,1.192a.67.67,0,0,0,0-.963.67.67,0,0,0-.963,0L.209,4.645A.681.681,0,0,0,0,5.126a.606.606,0,0,0,.209.481Zm0,0\"\n            transform=\"translate(0 -0.025)\" />\n        </svg>\n      </span>\n    </div>\n  </div>\n  <div class=\"search\">\n    <anghami-search-input (searchInput)=\"onSearchInput($event)\" [layout]=\"searchInputLayout\">\n    </anghami-search-input>\n  </div>\n</div>\n\n<ng-container *ngIf=\"type !== 'queue' && artistSearchLoading && artistSearchLoading\">\n  <div class=\"w-100 text-center d-flex justify-content-center\">\n    <anghami-loading></anghami-loading>\n  </div>\n</ng-container>\n\n<ng-container *ngIf=\"type !== 'queue' && (!artistSearchLoading && !artistSearchLoading)\">\n  <ng-container *ngFor=\"\n  let section of sections | searchSections: searchTerm;\n  let index = index;\n  trackBy: trackByFn\n\">\n    <div class=\"section-wrapper\" [ngSwitch]=\"section.displaytype\" [class.gray-scale-disabled]=\"section.disabled\"\n      *ngIf=\"((section.data?.length > 0 || section.group === 'bio' || section.type === 'text') && !section.hidden )\">\n      <!-- Section Title -->\n      <h2 dir=\"auto\" class=\"section-title\" [class.sectionlink]=\"section.href\"\n        *ngIf=\"section.title ||  section.alltitle || section.supertitle\">\n        <a [routerLink]=\"section.href?section.href:null\" rel=\"nofollow\" class=\"flex flex-row align-items-center\">\n          {{ section.title || section.alltitle || section.supertitle }}\n          <span class=\"section-deeplink-arrow\"></span>\n        </a>\n      </h2>\n\n      <ng-container *ngIf=\"displayTypeLookup[section.displaytype] === 'card'\">\n        <anghami-card-section [section]=\"section\" [initialNumItems]=\"isPodcastTagsSection ? 30 : initialNumItems\" [hasSideView]=\"isView\">\n        </anghami-card-section>\n        <div class=\"section-moredataloader\" [ngClass]=\"['d_' + section.displaytype]\" *ngIf=\"\n      !isPodcastTagsSection && ((section.initialNumItems < section.count &&\n        section.displaytype !== 'carousel') ||\n      section.moreData == 1 ||\n      section.collapsableTitle ||\n    (section.type === 'tag' && initialNumItems < section.count))\n    && !section.expanded\n    && section.count > 1\n    \">\n          <button class=\"anghami-default-btn more-button\" (click)=\"loadMore(section)\" *ngIf=\"!loadingSections\">\n            {{\n        section.alltitle ||\n          section.morebtn ||\n          section.collapsableTitle ||\n          'More'\n      }}\n          </button>\n          <div class=\"w-100 text-center d-flex justify-content-center\">\n            <anghami-loading *ngIf=\"loadingSections\"></anghami-loading>\n          </div>\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"displayTypeLookup[section.displaytype] === 'list'\">\n        <anghami-list-section [section]=\"section\" [collection]=\"sections\" [collectionMeta]=\"collectionMeta\"\n          [fromSearch]=\"fromSearch\" [isSearchActiveTabSong]=\"isSearchActiveTabSong\"\n          (listItemClickEventPropagation)=\"handleListItemClick($event)\" [fromSearchEdgeContainer]=\"fromSearchEdgeContainer\">\n        </anghami-list-section>\n        <div class=\"section-moredataloader\"\n          *ngIf=\"(section.initialNumItems && (section.initialNumItems < section.count)) || section.moreData == 1\">\n          <button class=\"anghami-default-btn\" (click)=\"loadMore(section)\" *ngIf=\"!loadingSections && !isLikesOrDownloads\">\n            {{\n          section.expandbutton ||\n          section.alltitle ||\n          section.morebtn ||\n          section.collapsableTitle ||\n          'More'\n        }}\n          </button>\n          <div class=\"w-100 text-center d-flex justify-content-center\">\n            <anghami-loading *ngIf=\"loadingSections && !isLikesOrDownloads\"></anghami-loading>\n          </div>\n        </div>\n        <div class=\"section-moredataloader\"\n          *ngIf=\"(section.initialNumItems >= section.count) && section.expanded && section.collapsebutton\">\n          <button class=\"anghami-default-btn\" (click)=\"showLess(section)\" *ngIf=\"!loadingSections\">\n            {{\n        section.collapsebutton ||\n        'Less'\n      }}\n          </button>\n          <div class=\"w-100 text-center d-flex justify-content-center\">\n            <anghami-loading *ngIf=\"loadingSections\"></anghami-loading>\n          </div>\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"displayTypeLookup[section.displaytype] === 'progress_card'\">\n        <anghami-list-section [section]=\"section\" [collection]=\"sections\" [collectionMeta]=\"collectionMeta\"\n          [fromSearch]=\"fromSearch\" [isSearchActiveTabSong]=\"isSearchActiveTabSong\"\n          (listItemClickEventPropagation)=\"handleListItemClick($event)\">\n        </anghami-list-section>\n        <div class=\"section-moredataloader\" *ngIf=\"((section.initialNumItems < section.count) || section.moreData == 1) && section.group !== 'latestsong'\">\n          <button class=\"anghami-default-btn\" (click)=\"loadMore(section)\" *ngIf=\"!loadingSections\">\n            {{\n          section.expandbutton ||\n          section.alltitle ||\n          section.morebtn ||\n          section.collapsableTitle ||\n          'More'\n        }}\n          </button>\n          <div class=\"w-100 text-center d-flex justify-content-center\">\n            <anghami-loading *ngIf=\"loadingSections\"></anghami-loading>\n          </div>\n        </div>\n        <div class=\"section-moredataloader\"\n          *ngIf=\"(section.initialNumItems >= section.count) && section.expanded && section.collapsebutton\">\n          <button class=\"anghami-default-btn\" (click)=\"showLess(section)\" *ngIf=\"!loadingSections\">\n            {{\n        section.collapsebutton ||\n        'Less'\n      }}\n          </button>\n          <div class=\"w-100 text-center d-flex justify-content-center\">\n            <anghami-loading *ngIf=\"loadingSections\"></anghami-loading>\n          </div>\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"displayTypeLookup[section.displaytype] === 'carousel' && section.data\">\n        <anghami-new-carousel [section]=\"section\" class=\"{{section.type}}\" [initialNumItems]=\"initialNumItems\"\n          (carouselInitialized)=\"propagateCarouselInitializedEvent($event)\" (hasMoreData)=\"loadMore($event)\"\n          (cardItemClickEventPropagation)=\"handleListItemClick($event)\"></anghami-new-carousel>\n      </ng-container>\n      <ng-container *ngIf=\"section.type === 'text' && !fromSearch && !collectionMeta.isPodcast && section.group!='bio'\">\n        <div class=\"text-template \">{{ section.text }}</div>\n      </ng-container>\n      <ng-container *ngIf=\"\n    (section.count === 0 || (section.data && section.data.length) === 0) &&\n    fromSearch\n  \">\n        <anghami-empty-search [info]=\"section.text\"></anghami-empty-search>\n      </ng-container>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-container *ngIf=\"type === 'queue'\">\n  <anghami-list-section [section]=\"sections[0]\" [infiniteScrollLimit]=\"infiniteScrollLimit\" [collection]=\"sections\" [collectionMeta]=\"collectionMeta\"\n    [fromSearch]=\"fromSearch\" [isSearchActiveTabSong]=\"isSearchActiveTabSong\"\n    (listItemClickEventPropagation)=\"handleListItemClick($event)\">\n  </anghami-list-section>\n</ng-container>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/overlay-collection-controls/overlay-collection-controls.component.html":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/overlay-collection-controls/overlay-collection-controls.component.html ***!
  \**********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  class=\"overlay-container type\"\n  [ngClass]=\"{'open': forceKeepOverlay}\"\n>\n  <ng-content></ng-content>\n  <div class=\"overlay-content\">\n    <ul class=\"controls\">\n      <li>\n        <anghami-icon\n          (click)=\"dipatchAction($event, 'play')\"\n          class=\"icon play\"\n          [data]=\"'play-shape'\"\n        ></anghami-icon>\n      </li>\n      <li>\n        <anghami-icon\n          class=\"icon\"\n          [data]=\"'download'\"\n          (click)=\"dipatchAction($event, 'download')\"\n          [hidden]=\"type === 'video'\"\n        ></anghami-icon>\n      </li>\n      <li [hidden]=\"type !== 'video'\">\n        <anghami-icon\n          class=\"icon share-icon\"\n          [data]=\"'share'\"\n          (click)=\"dipatchAction($event, 'share')\"\n        ></anghami-icon>\n      </li>\n      <li [hidden]=\"type === 'video'\">\n          <anghami-context-sheet-new \n            *ngIf=\"isBrowser\"\n            [type]=\"type || data.generictype\" \n            [data]=\"data\" \n            source=\"overlay\"\n            (playNowEvent) =\"dipatchAction($event, 'play')\"\n            (hidden)=\"toggleForceKeepOverlay(false)\" \n            (shown)=\"toggleForceKeepOverlay(true)\" \n            [placement]=\"['bottom', 'auto']\"\n            >\n          </anghami-context-sheet-new>\n      </li>\n    </ul>\n  </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/question-item/question-item.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/question-item/question-item.component.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container pt-4 pb-4\" *ngIf=\"show\">\n  <div class=\"row no-gutters\">\n    <div\n      class=\"qstn col-12 mx-auto d-flex align-items-center no-gutters\"\n      [ngStyle]=\"{ 'background-color': section.backgroundcolor }\"\n    >\n      <div class=\"close-icon\" *ngIf=\"section.allowclose === '1'\">\n        <button\n          type=\"button\"\n          class=\"close\"\n          aria-label=\"Close\"\n          (click)=\"removeComponent()\"\n        >\n          <span aria-hidden=\"true\">&times;</span>\n        </button>\n      </div>\n      <ng-container [ngSwitch]=\"section.type\">\n        <ng-container *ngSwitchCase=\"'subscribe'\">\n          <ng-container *ngTemplateOutlet=\"templateOne\"></ng-container>\n        </ng-container>\n        <ng-container *ngSwitchCase=\"'question'\">\n          <ng-container *ngTemplateOutlet=\"templateTwo\"></ng-container>\n        </ng-container>\n        <ng-container *ngSwitchDefault>\n          <ng-container *ngTemplateOutlet=\"templateTwo\"></ng-container>\n        </ng-container>\n      </ng-container>\n    </div>\n  </div>\n</div>\n\n<ng-template #textTemplate>\n  <p class=\"mr-2\">{{ section.message }}</p>\n  <div class=\"btns\">\n    <ng-container *ngFor=\"let btn of section.data\">\n      <button\n        *ngIf=\"btn.type === 'button'\"\n        class=\"action-button ml-1 mr-1\"\n        [ngClass]=\"{\n          secondary: section.type === 'subscribe' && !btn.secondary,\n          'purple-btn': section.type !== 'subscribe' && !btn.secondary\n        }\"\n        (click)=\"triggerDeepLink(btn)\"\n      >\n        {{ btn.title }}\n      </button>\n    </ng-container>\n  </div>\n</ng-template>\n\n<ng-template #templateOne>\n  <div\n    class=\"col-5 h-100 bg-image\"\n    [ngStyle]=\"{\n      'background-image': 'url(' + section.headerimage + ')'\n    }\"\n  ></div>\n  <div class=\"col-7 pl-2 pr-2\" [ngStyle]=\"{ color: section.color }\">\n    <ng-container *ngTemplateOutlet=\"textTemplate\"></ng-container>\n  </div>\n</ng-template>\n\n<ng-template #templateTwo>\n  <div class=\"col-8 mx-auto\">\n    <div class=\"row no-gutters align-items-center justify-content-between\">\n      <div class=\"col\">\n        <ng-container *ngTemplateOutlet=\"textTemplate\"></ng-container>\n      </div>\n      <div class=\"col-auto\" *ngIf=\"section.image\">\n        <img\n          class=\"img-fluid rounded\"\n          [src]=\"section.image\"\n          alt=\"\"\n          width=\"100px\"\n        />\n      </div>\n    </div>\n  </div>\n</ng-template>\n"

/***/ }),

/***/ "./src/app/core/components/auto-downloads/auto-downloads.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/core/components/auto-downloads/auto-downloads.component.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* The switch - the box around the slider */\n.switch {\n  position: relative;\n  display: inline-block;\n  width: 35px;\n  height: 16px;\n  /* Hide default HTML checkbox */\n  /* The slider */\n}\n.switch input {\n  opacity: 0;\n  width: 0;\n  height: 0;\n  background: var(--light-background);\n  color: var(--text-color);\n}\n.switch input:checked + .slider {\n  background: var(--checkbox-checked-background);\n}\n.switch input:checked + .slider:before {\n  -webkit-transform: translateX(17px);\n  -ms-transform: translateX(17px);\n  transform: translateX(17px);\n  left: 2.5px;\n}\n.switch .slider {\n  position: absolute;\n  cursor: pointer;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  margin: auto !important;\n  border: var(--checkbox-border);\n  background-color: var(--checkbox-unchecked-background);\n  /* Rounded sliders */\n}\n.switch .slider.round {\n  border-radius: 20px;\n}\n.switch .slider.round:before {\n  border-radius: 50%;\n}\n.switch .slider:before {\n  position: absolute;\n  content: \"\";\n  height: 14px;\n  width: 14px;\n  left: 0;\n  bottom: 0;\n  top: 0;\n  margin: auto;\n  background-color: var(--checkbox-circle-background);\n  -webkit-transition: 0.4s;\n  transition: 0.4s;\n}\n:host .auto-downloads-container {\n  background-color: var(--sidebar-background);\n  border-radius: 5px;\n  padding: 1em;\n}\n:host .auto-downloads-container .title {\n  font-weight: bold;\n}\n:host .auto-downloads-container .subtitle {\n  margin-top: 1em;\n  color: var(--text-color-light);\n}\n:host .auto-downloads-container input:checked + .slider {\n  background: -webkit-gradient(linear, left top, right top, from(#e1418c), to(#913ccd));\n  background: linear-gradient(to right, #e1418c, #913ccd);\n}\n:host .auto-downloads-container .slider {\n  background-color: #ccc;\n}"

/***/ }),

/***/ "./src/app/core/components/auto-downloads/auto-downloads.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/core/components/auto-downloads/auto-downloads.component.ts ***!
  \****************************************************************************/
/*! exports provided: AutoDownloadsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutoDownloadsComponent", function() { return AutoDownloadsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/selectors/desktop-client.selectors */ "./src/app/core/redux/selectors/desktop-client.selectors.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");





let AutoDownloadsComponent = class AutoDownloadsComponent {
    constructor(store) {
        this.store = store;
        this.autoDownloadsValue = false;
    }
    ngOnInit() {
        this.store.select(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_3__["getAutoDownloadsState"]).subscribe(resp => {
            this.autoDownloadsValue = resp.enabled;
        });
    }
    toggleAutoDownloads() {
        this.autoDownloadsValue = !this.autoDownloadsValue;
        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_4__["SetAutoDownloadsState"]({
            enabled: this.autoDownloadsValue
        }));
    }
};
AutoDownloadsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-auto-downloads',
        template: __webpack_require__(/*! raw-loader!./auto-downloads.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/auto-downloads/auto-downloads.component.html"),
        styles: [__webpack_require__(/*! ./auto-downloads.component.scss */ "./src/app/core/components/auto-downloads/auto-downloads.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"]])
], AutoDownloadsComponent);



/***/ }),

/***/ "./src/app/core/components/context-sheet-new/context-sheet-new.component.scss":
/*!************************************************************************************!*\
  !*** ./src/app/core/components/context-sheet-new/context-sheet-new.component.scss ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".icon.more {\n  margin: auto;\n  border-radius: 50%;\n  padding: 0.7em;\n  -webkit-transition: fill, color, background-color 200ms linear;\n  transition: fill, color, background-color 200ms linear;\n  fill: #727272 !important;\n  cursor: pointer;\n}\n.icon.more:hover {\n  color: #AAA;\n  fill: #AAA;\n  border-style: solid;\n  border-width: 0.1em;\n}\n.icon.more.overlay {\n  fill: #727272 !important;\n}\n.icon.more.overlay:hover {\n  fill: #727272 !important;\n}\n.icon.more.highlighted {\n  color: var(--brand-purple);\n  fill: var(--brand-purple);\n  border-style: solid;\n  border-width: 0.1em;\n}\n::ng-deep .context-sheet {\n  z-index: 1006 !important;\n}\n::ng-deep .context-sheet.bs-popover-bottom .arrow:after {\n  border-bottom-color: var(--light-gray) !important;\n}"

/***/ }),

/***/ "./src/app/core/components/context-sheet-new/context-sheet-new.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/core/components/context-sheet-new/context-sheet-new.component.ts ***!
  \**********************************************************************************/
/*! exports provided: ContextSheetNewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextSheetNewComponent", function() { return ContextSheetNewComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modules/player/actions/player.actions */ "./src/app/core/modules/player/actions/player.actions.ts");
/* harmony import */ var _modules_player_selectors_player_selectors__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../modules/player/selectors/player.selectors */ "./src/app/core/modules/player/selectors/player.selectors.ts");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../modules/player/actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");












let ContextSheetNewComponent = class ContextSheetNewComponent {
    constructor(_router, store, platformId) {
        this._router = _router;
        this.store = store;
        this.platformId = platformId;
        this.hidden = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.shown = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.playNowEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.isCurrentSong = false;
        this.sheetHiddenEvent = () => {
            this.popoverOpen = false;
            this.windowObject.removeEventListener('scroll', this.pageScroll, true);
            this.pageScrollPosition = 0;
            if (this.hidden) {
                this.hidden.emit();
            }
        };
        this.sheetShownEvent = () => {
            this.popoverOpen = true;
            this.pageScrollPosition = Number(window.scrollY);
            this.windowObject.addEventListener('scroll', this.pageScroll, true);
            if (this.shown) {
                this.shown.emit();
            }
        };
        this.pageScroll = () => {
            const scrollMaxLimit = this.pageScrollPosition + Number(this.windowObject.innerHeight) / 2;
            const scrollMinLimit = this.pageScrollPosition - Number(this.windowObject.innerHeight) / 2;
            if (window.scrollY > scrollMaxLimit || window.scrollY < scrollMinLimit) {
                this.closePopover();
            }
        };
        this.isDesktopClient = !!window['desktopClient'];
    }
    ngOnDestroy() {
        if (this.currentQueueSub$) {
            this.currentQueueSub$.unsubscribe();
        }
    }
    closePopover() {
        this.popover.close();
    }
    ngOnInit() {
        if (!Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(this.platformId)) {
            return;
        }
        this.windowObject = window;
        this.showContextSheet();
    }
    showContextSheet() {
        if (this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].SONG
            || this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].ALBUM
            || this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].PLAYLIST
            || this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].PODCAST) {
            this.showMoreIcon = true;
        }
        if (this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].ARTIST || this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].GENERIC) {
            this.showShareButton = true;
        }
    }
    playSong() {
        if (this.playNowEvent) {
            this.playNowEvent.emit();
        }
        else {
            if (this.source === 'story') {
                this._router.navigate([this.type + '/' + this.data.id]);
            }
            const queue = {
                data: [this.data],
                displaytype: 'list',
                playmode: 'list',
                type: 'song'
            };
            this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_11__["PlayTrackEngine"]({
                queue: queue,
                list: this.data,
                click: true,
                index: 0
            }));
        }
    }
    share() {
        let type;
        if (!!this.data.genericid) {
            type = _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].GENERIC;
        }
        else if (!!this.data.generictype) {
            type = this.data.generictype;
        }
        else if (!!this.data.videoid && this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].VIDEO) {
            type = _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].VIDEO;
        }
        else if (this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].PODCAST && this.data.is_podcast) {
            type = _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_9__["CollectionTypes"].PODCAST_EPISODE;
        }
        else {
            type = this.type;
        }
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_10__["OpenShareModal"]({
            type: type,
            meta: this.data
        }));
    }
    removeSong(event) {
        if (event) {
            event.stopPropagation();
        }
        let currentQueue;
        this.currentQueueSub$ = this.store
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["take"])(1), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_modules_player_selectors_player_selectors__WEBPACK_IMPORTED_MODULE_8__["getCurrentQueue"]))
            .subscribe(q => (currentQueue = q));
        if (currentQueue &&
            currentQueue != null &&
            currentQueue.data &&
            currentQueue.data != null) {
            const newplaylist = currentQueue.data.filter(elt => elt.id !== this.data.id);
            const newqueue = Object.assign({}, currentQueue, { data: newplaylist });
            this.store.dispatch(new _modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_7__["UpdateQueue"]({
                queue: newqueue
            }));
            this.store.dispatch(new _modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_7__["PUTPOSTPlayQueue"]());
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ContextSheetNewComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetNewComponent.prototype, "data", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetNewComponent.prototype, "source", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetNewComponent.prototype, "currentList", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetNewComponent.prototype, "isQueue", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetNewComponent.prototype, "placement", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetNewComponent.prototype, "disablePopover", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"])
], ContextSheetNewComponent.prototype, "hidden", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"])
], ContextSheetNewComponent.prototype, "shown", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"])
], ContextSheetNewComponent.prototype, "playNowEvent", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])('popover', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["NgbPopover"])
], ContextSheetNewComponent.prototype, "popover", void 0);
ContextSheetNewComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'anghami-context-sheet-new',
        template: __webpack_require__(/*! raw-loader!./context-sheet-new.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/context-sheet-new/context-sheet-new.component.html"),
        styles: [__webpack_require__(/*! ./context-sheet-new.component.scss */ "./src/app/core/components/context-sheet-new/context-sheet-new.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
        Object])
], ContextSheetNewComponent);



/***/ }),

/***/ "./src/app/core/components/context-sheet-new/context-sheet-new.module.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/core/components/context-sheet-new/context-sheet-new.module.ts ***!
  \*******************************************************************************/
/*! exports provided: ContextSheetNewModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextSheetNewModule", function() { return ContextSheetNewModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _context_sheet_context_sheet_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../context-sheet/context-sheet.module */ "./src/app/core/components/context-sheet/context-sheet.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _icon_icon_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _context_sheet_new_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./context-sheet-new.component */ "./src/app/core/components/context-sheet-new/context-sheet-new.component.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");









let ContextSheetNewModule = class ContextSheetNewModule {
};
ContextSheetNewModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [_context_sheet_new_component__WEBPACK_IMPORTED_MODULE_7__["ContextSheetNewComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"], _icon_icon_module__WEBPACK_IMPORTED_MODULE_5__["IconModule"], _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_6__["PipesModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbModule"], _context_sheet_context_sheet_module__WEBPACK_IMPORTED_MODULE_1__["ContextSheetModule"]],
        exports: [_context_sheet_new_component__WEBPACK_IMPORTED_MODULE_7__["ContextSheetNewComponent"]],
        entryComponents: [_context_sheet_new_component__WEBPACK_IMPORTED_MODULE_7__["ContextSheetNewComponent"]]
    })
], ContextSheetNewModule);



/***/ }),

/***/ "./src/app/core/components/context-sheet/context-sheet.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/core/components/context-sheet/context-sheet.component.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  z-index: 1006;\n  background: var(--gray-light-background);\n}\n:host .trim {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n:host .coverart {\n  width: 4em;\n  height: 4em;\n  border-radius: 0.5em;\n}\n:host .header .action-font {\n  margin: 0.5em;\n  font-size: 0.9em;\n  max-width: 15em;\n}\n:host .header .action-font .title {\n  font-weight: 600;\n  color: var(--text-color);\n}\n:host .header .action-font .artist {\n  color: var(--text-color-light);\n}\n:host .header .action-font .info {\n  font-size: 0.8em !important;\n  color: var(--text-color-light);\n  height: 1.4em;\n}\n:host .actions {\n  padding-bottom: 0.5em;\n  padding-left: 0.7em;\n  padding-right: 0.8em;\n  width: 100%;\n  -ms-flex-pack: distribute;\n      justify-content: space-around;\n}\n:host .actions .action-item {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n:host .actions .action-item div {\n  cursor: pointer;\n  width: 3em;\n  height: 2.2em;\n  border-radius: 1.6em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  background-color: var(--light-gray-backgorund);\n  color: var(--light-gray-background-text);\n}\n:host .actions .action-item div.play-action {\n  background: #8D00F2 !important;\n  color: #fff !important;\n}\n:host .actions .action-item div:not(.play-action):hover {\n  -webkit-transition: 0.2ms;\n  transition: 0.2ms;\n  background-color: var(--context-sheet-action-hover);\n}\n:host .actions .action-item div:first-of-type:hover {\n  opacity: 0.9;\n}\n:host .actions .action-item .selected {\n  background-color: #EFF3F5;\n  color: #5b5e62;\n}\n:host .actions .action-item .disabled {\n  color: #5B5E62;\n  cursor: default;\n}\n:host .actions .action-item .disabled anghami-icon {\n  opacity: 0.3 !important;\n}\n:host .actions .action-item span {\n  font-size: 0.6em;\n  text-align: center;\n  color: #5B5E62;\n}\n:host .details {\n  padding-top: 0.5em;\n  color: var(--text-color);\n}\n:host .details .text {\n  padding: 0.5em 1em;\n  font-size: 0.9em;\n}\n:host .details ::ng-deep svg {\n  width: 1em !important;\n  height: 1em !important;\n  font-size: 0.9em !important;\n}\n:host .details .item {\n  padding: 0.1em 1em;\n  cursor: pointer;\n  -webkit-transition: all 200ms linear;\n  transition: all 200ms linear;\n  border-radius: 0.3em;\n}\n:host .details .item:hover {\n  background-color: var(--light-gray);\n}\n:host .details .bottom-item {\n  background: var(--light-gray-backgorund);\n  height: 2.7em;\n}\n:host .bold {\n  font-weight: 600;\n}\n:host .morewrapper {\n  padding: 0.5rem 0.75rem;\n  border-bottom-left-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n:host .divider {\n  width: 90%;\n  border-bottom: 1px solid lightgray;\n  margin: auto;\n  margin-bottom: 0.5em;\n}\n:host a {\n  color: var(--text-color);\n}\n:host a:hover {\n  text-decoration: none;\n}\n.icon.other-context-right {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n.icon.other-context-left {\n  -webkit-transform: rotate(0deg) !important;\n      -ms-transform: rotate(0deg) !important;\n          transform: rotate(0deg) !important;\n}"

/***/ }),

/***/ "./src/app/core/components/context-sheet/context-sheet.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/context-sheet/context-sheet.component.ts ***!
  \**************************************************************************/
/*! exports provided: ContextSheetComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextSheetComponent", function() { return ContextSheetComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../modules/player/actions/player.actions */ "./src/app/core/modules/player/actions/player.actions.ts");
/* harmony import */ var _modules_player_selectors_player_selectors__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../modules/player/selectors/player.selectors */ "./src/app/core/modules/player/selectors/player.selectors.ts");
/* harmony import */ var _redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _services_deeplinks_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../services/deeplinks.service */ "./src/app/core/services/deeplinks.service.ts");
/* harmony import */ var _context_sheet_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./context-sheet.service */ "./src/app/core/components/context-sheet/context-sheet.service.ts");
/* harmony import */ var _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/redux/actions/library.actions */ "./src/app/core/redux/actions/library.actions.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _anghami_redux_actions_playlist_manager_actions__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @anghami/redux/actions/playlist-manager.actions */ "./src/app/core/redux/actions/playlist-manager.actions.ts");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _modules_player_player_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../modules/player/player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../modules/player/actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
























let ContextSheetComponent = class ContextSheetComponent {
    constructor(_actionSubject, deeplinksService, _router, store, _contextSheetService, _authService, _playerService, _translateService, platformId, locale) {
        this._actionSubject = _actionSubject;
        this.deeplinksService = deeplinksService;
        this._router = _router;
        this.store = store;
        this._contextSheetService = _contextSheetService;
        this._authService = _authService;
        this._playerService = _playerService;
        this._translateService = _translateService;
        this.platformId = platformId;
        this.locale = locale;
        this.likeTrack = new _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"]();
        this.playNextEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"]();
        this.playNowEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"]();
        this.editPrivacyEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"]();
        this.removeStoryEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"]();
        this.deleteTrack = new _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"]();
        this.shareEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"]();
        this.closeContextSheet = new _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"]();
        this.isCurrentSong = false;
        this.isDesktopClient = !!window['desktopClient'];
        this.language = this.locale
            ? this.locale.indexOf('en') > -1
                ? 'en'
                : this.locale
            : 'en';
    }
    // debug() {
    //   console.log('--- CONTEXTSHEET DEBUGGING : -- Type ', this.type, '--- Source ', this.source,  '---- Data', this.data)
    // }
    ngOnDestroy() {
        if (this.sub$) {
            this.sub$.unsubscribe();
        }
        if (this.currentSong$) {
            this.currentSong$.unsubscribe();
        }
        if (this.updatePlaylistSuccSub$) {
            this.updatePlaylistSuccSub$.unsubscribe();
        }
        if (this.currentPlayerOptions$) {
            this.currentPlayerOptions$.unsubscribe();
        }
        if (this.updatePlaylistErrorSub$) {
            this.updatePlaylistErrorSub$.unsubscribe();
        }
        if (this.currentQueueSub$) {
            this.currentQueueSub$.unsubscribe();
        }
        if (this.likedTracks$) {
            this.likedTracks$.unsubscribe();
        }
        if (this.songInfo$) {
            this.songInfo$.unsubscribe();
        }
        this.isLocal = false;
    }
    ngOnInit() {
        if (!Object(_angular_common__WEBPACK_IMPORTED_MODULE_4__["isPlatformBrowser"])(this.platformId)) {
            return;
        }
        if (this.source !== 'player' && this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].SONG || this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].PODCAST) {
            this.songInfo$ = this._playerService.getObjectInfo(this.data).subscribe(songInfo => {
                this.data = Object.assign({}, this.data, { likes: songInfo.likes, plays: songInfo.plays });
            });
        }
        this.isloggedin = this._authService.isUserLoggedIn();
        if (this.isloggedin) {
            this.sub$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_13__["getUser"])).subscribe(data => {
                if (data && data.plantype) {
                    this.planId = data.plantype;
                }
                if (data &&
                    data != null &&
                    this.currentList &&
                    this.currentList != null) {
                    // tslint:disable-next-line: triple-equals
                    this.isOwner = data.anid == this.currentList.OwnerID;
                }
            });
        }
        this.isLocal = !!this.data && !!this.data.id && typeof this.data.id === 'string' && this.data.id.indexOf('local') > -1
            ? true : false;
        // this.isCollectionItem = this.type === 'collectionItem';
        // if (this.type === 'collectionItem') {
        //   this.type = this.itemType;
        // }
        this.isQueue = !!this.isQueue;
        if (this.data && this.data != null) {
            this.notification = this.data.notification ? this.data.notification : {};
        }
        this.currentSong$ = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_modules_player_selectors_player_selectors__WEBPACK_IMPORTED_MODULE_12__["getCurrentTrack"]))
            .subscribe(track => {
            if (!!track &&
                !!this.data &&
                !!this.data.id &&
                parseInt(track.id, 0) === parseInt(this.data.id, 0)) {
                this.isCurrentSong = true;
                this.data = Object.assign({}, this.data, { likes: track.likes, plays: track.plays });
                this.currentPlayerOptions$ = this.store
                    .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_modules_player_selectors_player_selectors__WEBPACK_IMPORTED_MODULE_12__["getCurrentOptions"]))
                    .subscribe(data => {
                    if (data !== null &&
                        typeof data !== 'undefined' &&
                        Object.keys(data).length > 0) {
                        this.currentPlayerOptions = data;
                    }
                });
            }
            else {
                this.isCurrentSong = false;
            }
        });
        this.online$ = Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["merge"])(Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["of"])(navigator.onLine), Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["fromEvent"])(window, 'online').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["mapTo"])(true)), Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["fromEvent"])(window, 'offline').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["mapTo"])(false)));
    }
    ngAfterViewInit() {
        if (this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].SONG && this.data.liked === undefined) {
            this.likedTracks$ = this.store.select(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_20__["getLikedSongsHashed"]).subscribe(likedSongs => {
                this.data = Object.assign({}, this.data, { liked: likedSongs[this.data.id] });
            });
        }
    }
    ngOnChanges() {
        if (this.popoverInstance) {
            this._contextSheetService.setCurrent(this.popoverInstance);
        }
    }
    playerAction(action) {
        this.store.dispatch(new _modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_11__["PlayerAction"](action));
    }
    getSong() {
        if (this.data && this.data.id) {
            this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_22__["PlaySongEngine"]({ id: this.data.id }));
        }
        // Play more like this
    }
    addToPlaylist() {
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__["OpenPlaylistManager"]({
            type: 'addtoplaylist',
            tracks: [this.data]
        }));
    }
    downloadSong() {
        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_1__["DownloadSong"]({ song: this.data }));
    }
    share() {
        this.shareEvent.emit();
    }
    addToQueue() {
        // TODO: fix types for podcast and podcast episode
        this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_22__["AddToQueueEngine"]({
            type: this.type,
            data: this.data
        }));
        this.closeContextSheet.emit();
    }
    playNext(id) {
        if (!this.isCurrentSong) {
            switch (this.type) {
                case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].VIDEO:
                case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].PODCAST:
                case _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].SONG: {
                    this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_22__["PlayNextEngine"]({
                        track: this.data
                    }));
                    if (this.data && this.data.isEmitEvent) {
                        this.playNextEvent.emit();
                    }
                    this.closeContextSheet.emit();
                    break;
                }
                default: {
                }
            }
        }
    }
    navigateTo(type, id) {
        if (type && type != null && id && id != null) {
            this._router.navigate([type + '/' + id]);
        }
    }
    likeSong(event) {
        event.stopPropagation();
        event.preventDefault();
        if (!this.isloggedin) {
            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__["OpenCustomDialog"]({
                type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_17__["DIALOG_TYPES"].LOGIN
            }));
            return;
        }
        this.data = Object.assign({}, this.data, { liked: !this.data.liked });
        if (this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].ALBUM || this.data.generictype === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].ALBUM) {
            this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_16__["LikeAlbum"]({
                item: this.data
            }));
        }
        else if (this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].SONG || this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].PODCAST ||
            this.data.generictype === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_10__["CollectionTypes"].SONG) {
            this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_16__["LikeSong"]({
                item: this.data
            }));
        }
    }
    removeSong() {
        this.deleteTrack.emit(this.data);
    }
    removeSongFromList() {
        const payload = {
            id: this.currentList.id,
        };
        payload.songs = {
            type: 'PUTplaylist',
            playlistid: this.currentList.id,
            action: 'delete',
            songid: this.data.id
        };
        this.updatePlaylistSuccSub$ = this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_18__["ofType"])(_anghami_redux_actions_playlist_manager_actions__WEBPACK_IMPORTED_MODULE_19__["PlaylistManagerActionTypes"].UPDATEplaylistSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe(() => {
            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__["OpenConfirmationModal"]({
                question: 'your playlist have been updated',
                type: 'notice'
            }));
        });
        this.updatePlaylistErrorSub$ = this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_18__["ofType"])(_anghami_redux_actions_playlist_manager_actions__WEBPACK_IMPORTED_MODULE_19__["PlaylistManagerActionTypes"].UPDATEplaylistError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["take"])(1))
            .subscribe(res => {
            const errmsg = res.payload && res.payload.message && res.payload.message !== ''
                ? res.payload.message
                : this._translateService.instant('oops');
            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_2__["OpenConfirmationModal"]({
                question: errmsg,
                type: 'notice'
            }));
        });
        this.store.dispatch(new _anghami_redux_actions_playlist_manager_actions__WEBPACK_IMPORTED_MODULE_19__["UPDATEplaylist"](payload));
    }
    openInDesktopDialog() {
        this._contextSheetService.openInDesktopDialog({
            id: this.data.id,
            type: this.type,
        });
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ContextSheetComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetComponent.prototype, "source", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetComponent.prototype, "data", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetComponent.prototype, "currentList", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ContextSheetComponent.prototype, "isQueue", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ContextSheetComponent.prototype, "isPersonalStory", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ContextSheetComponent.prototype, "isVideo", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"])
], ContextSheetComponent.prototype, "likeTrack", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"])
], ContextSheetComponent.prototype, "playNextEvent", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"])
], ContextSheetComponent.prototype, "playNowEvent", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"])
], ContextSheetComponent.prototype, "editPrivacyEvent", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"])
], ContextSheetComponent.prototype, "removeStoryEvent", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"])
], ContextSheetComponent.prototype, "deleteTrack", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"])
], ContextSheetComponent.prototype, "shareEvent", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["EventEmitter"])
], ContextSheetComponent.prototype, "closeContextSheet", void 0);
ContextSheetComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
        selector: 'anghami-context-sheet',
        template: __webpack_require__(/*! raw-loader!./context-sheet.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/context-sheet/context-sheet.component.html"),
        styles: [__webpack_require__(/*! ./context-sheet.component.scss */ "./src/app/core/components/context-sheet/context-sheet.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](8, Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_5__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](9, Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_5__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["ActionsSubject"],
        _services_deeplinks_service__WEBPACK_IMPORTED_MODULE_14__["DeeplinksService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"],
        _context_sheet_service__WEBPACK_IMPORTED_MODULE_15__["ContextSheetService"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
        _modules_player_player_service__WEBPACK_IMPORTED_MODULE_21__["PlayerService"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_23__["TranslateService"],
        Object, String])
], ContextSheetComponent);



/***/ }),

/***/ "./src/app/core/components/context-sheet/context-sheet.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/core/components/context-sheet/context-sheet.module.ts ***!
  \***********************************************************************/
/*! exports provided: ContextSheetModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextSheetModule", function() { return ContextSheetModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _context_sheet_context_sheet_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../context-sheet/context-sheet.component */ "./src/app/core/components/context-sheet/context-sheet.component.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");








let ContextSheetModule = class ContextSheetModule {
};
ContextSheetModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_context_sheet_context_sheet_component__WEBPACK_IMPORTED_MODULE_6__["ContextSheetComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"], _components_icon_icon_module__WEBPACK_IMPORTED_MODULE_4__["IconModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_5__["PipesModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__["NgbModule"]],
        exports: [_context_sheet_context_sheet_component__WEBPACK_IMPORTED_MODULE_6__["ContextSheetComponent"]],
        entryComponents: [_context_sheet_context_sheet_component__WEBPACK_IMPORTED_MODULE_6__["ContextSheetComponent"]]
    })
], ContextSheetModule);



/***/ }),

/***/ "./src/app/core/components/context-sheet/context-sheet.service.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/context-sheet/context-sheet.service.ts ***!
  \************************************************************************/
/*! exports provided: ContextSheetService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextSheetService", function() { return ContextSheetService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");








let ContextSheetService = class ContextSheetService {
    constructor(platformId, store) {
        this.platformId = platformId;
        this.store = store;
    }
    setCurrent(contextSheet) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            setTimeout(() => {
                if (this.currentSheet && this.currentSheet !== contextSheet) {
                    this.closeContextSheet();
                }
                this.currentSheet = contextSheet;
                if (this.currentSheet) {
                    const listener = () => {
                        if (this.currentSheet) {
                            this.currentSheet.close();
                        }
                    };
                    window.addEventListener('scroll', listener, true);
                    this.currentSheet.hidden.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["take"])(1)).subscribe(() => {
                        window.removeEventListener('scroll', listener);
                    });
                }
            }, 0);
        }
    }
    closeContextSheet() {
        if (this.currentSheet && this.currentSheet !== null) {
            this.currentSheet.close();
        }
    }
    getOSName() {
        if (window.navigator.userAgent.indexOf('Windows') !== -1) {
            return 'windows';
        }
        else if (window.navigator.userAgent.indexOf('Mac') !== -1) {
            return 'mac';
        }
    }
    openInDesktopDialog(customData) {
        const desktopLink = 'webs://play.anghami.com/download';
        const dialogConfig = {
            title: `Open ${customData.type} in desktop app`,
            // title: this._translationService.instant('adBlock_detected_title'),
            backgroundimage_web: `${_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].assetsCDN}img/dialogs/download_desktop_app_dialog.png`,
            buttontext: 'I have the desktop app',
            buttonLink: `anghami://${customData.type}/${customData.id}`,
            cancelbuttontext: 'Download desktop app',
            cancelbuttondeeplink: desktopLink,
            reporting_api: 'off',
            reporting_amplitude: 'true',
            keyboard: false,
        };
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_4__["OpenCustomDialog"]({
            type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_5__["DIALOG_TYPES"].CUSTOM_DATA_DIALOG,
            dialogConfig
        }));
    }
};
ContextSheetService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, _ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"]])
], ContextSheetService);



/***/ }),

/***/ "./src/app/core/components/empty-search/empty-search.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/empty-search/empty-search.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".collection-item {\n  -webkit-box-flex: 0 !important;\n      -ms-flex: 0 0 50% !important;\n          flex: 0 0 50% !important;\n  max-width: 50% !important;\n  -ms-flex: 0 0 25% !important;\n      flex: 0 0 25% !important;\n  max-width: 33% !important;\n}\n@media (min-width: 576px) {\n  .collection-item {\n    -webkit-box-flex: 0 !important;\n        -ms-flex: 0 0 50% !important;\n            flex: 0 0 50% !important;\n    max-width: 50% !important;\n  }\n}\n@media (min-width: 768px) {\n  .collection-item {\n    -webkit-box-flex: 0 !important;\n        -ms-flex: 0 0 33% !important;\n            flex: 0 0 33% !important;\n    max-width: 33% !important;\n  }\n}\n@media (min-width: 992px) {\n  .collection-item {\n    -webkit-box-flex: 0 !important;\n        -ms-flex: 0 0 25% !important;\n            flex: 0 0 25% !important;\n    max-width: 25% !important;\n  }\n}\n@media (min-width: 1200px) {\n  .collection-item {\n    -webkit-box-flex: 0 !important;\n        -ms-flex: 0 0 25% !important;\n            flex: 0 0 25% !important;\n    max-width: 25% !important;\n  }\n}\n.container {\n  max-width: 55em;\n  max-width: 25em;\n}\n@media (min-width: 768px) {\n  .container {\n    max-width: 55em;\n  }\n}\n.empty-header {\n  text-align: center;\n  padding-top: 3em;\n  padding-bottom: 0.5em;\n}\n.recent-icon {\n  padding: 0.7em;\n  display: inline-block;\n  vertical-align: middle;\n  margin-bottom: 0.5em;\n  color: var(--search-color);\n}\nanghami-icon.recent-icon {\n  border-radius: 50%;\n  background: var(--recent-search-icon-bg);\n}\n.header-1 {\n  color: #727272;\n  font-size: 1.8em;\n  padding-bottom: 0.5em;\n}\n.header-2 {\n  color: var(--text-color);\n  font-size: 1.8em;\n}\n.row {\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}"

/***/ }),

/***/ "./src/app/core/components/empty-search/empty-search.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/empty-search/empty-search.component.ts ***!
  \************************************************************************/
/*! exports provided: EmptySearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmptySearchComponent", function() { return EmptySearchComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/search.actions */ "./src/app/core/redux/actions/search.actions.ts");
/* harmony import */ var _anghami_redux_selectors_search_selector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/selectors/search.selector */ "./src/app/core/redux/selectors/search.selector.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");







let EmptySearchComponent = class EmptySearchComponent {
    constructor(store, _utilService) {
        this.store = store;
        this._utilService = _utilService;
        this.info = [];
        this.store.dispatch(new _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_1__["GetSearchSuggestions"](''));
    }
    ngOnInit() {
        this.searchSuggestion$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(_anghami_redux_selectors_search_selector__WEBPACK_IMPORTED_MODULE_2__["getSearchSuggestions"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["map"])(searchResults => {
            if (searchResults) {
                this.searchResults = this._utilService.shuffleArray(searchResults);
                return searchResults;
            }
        }));
    }
    ngOnDestroy() { }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], EmptySearchComponent.prototype, "info", void 0);
EmptySearchComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'anghami-empty-search',
        template: __webpack_require__(/*! raw-loader!./empty-search.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/empty-search/empty-search.component.html"),
        styles: [__webpack_require__(/*! ./empty-search.component.scss */ "./src/app/core/components/empty-search/empty-search.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilService"]])
], EmptySearchComponent);



/***/ }),

/***/ "./src/app/core/components/equalizer/equalizer.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/core/components/equalizer/equalizer.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  border-radius: 0.3em;\n}\n:host .equaliser-container {\n  padding: 0 0 0 0;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  margin: -0.4em 0 0 -0.4em;\n  z-index: 1;\n}\n:host .colour-bar {\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  height: 10px;\n  background: #fff;\n}\n:host .equaliser-column {\n  width: 3px;\n  float: left;\n  margin: 0 1px 0 0;\n  padding: 0;\n  height: 12px;\n  position: relative;\n  list-style-type: none;\n}\n:host .equaliser-column:nth-child(1) .colour-bar {\n  -webkit-animation: color-bar 2s 1s ease-out alternate infinite;\n          animation: color-bar 2s 1s ease-out alternate infinite;\n}\n:host .equaliser-column:nth-child(2) .colour-bar {\n  -webkit-animation: color-bar 2s 0.5s ease-out alternate infinite;\n          animation: color-bar 2s 0.5s ease-out alternate infinite;\n}\n:host .equaliser-column:nth-child(3) .colour-bar {\n  -webkit-animation: color-bar 2s 1.5s ease-out alternate infinite;\n          animation: color-bar 2s 1.5s ease-out alternate infinite;\n}\n:host .equaliser-column:nth-child(4) .colour-bar {\n  -webkit-animation: color-bar 2s 0.25s ease-out alternate infinite;\n          animation: color-bar 2s 0.25s ease-out alternate infinite;\n}\n:host .equaliser-column:nth-child(5) .colour-bar {\n  -webkit-animation: color-bar 2s 2s ease-out alternate infinite;\n          animation: color-bar 2s 2s ease-out alternate infinite;\n}\n:host .equaliser-column:last-child {\n  margin-right: 0;\n}\n@-webkit-keyframes color-bar {\n  0% {\n    height: 1px;\n  }\n  10% {\n    height: 3px;\n  }\n  20% {\n    height: 5px;\n  }\n  30% {\n    height: 2px;\n  }\n  40% {\n    height: 7px;\n  }\n  50% {\n    height: 9px;\n  }\n  60% {\n    height: 3px;\n  }\n  70% {\n    height: 8px;\n  }\n  80% {\n    height: 5px;\n  }\n  90% {\n    height: 3px;\n  }\n  100% {\n    height: 1px;\n  }\n}\n@keyframes color-bar {\n  0% {\n    height: 1px;\n  }\n  10% {\n    height: 3px;\n  }\n  20% {\n    height: 5px;\n  }\n  30% {\n    height: 2px;\n  }\n  40% {\n    height: 7px;\n  }\n  50% {\n    height: 9px;\n  }\n  60% {\n    height: 3px;\n  }\n  70% {\n    height: 8px;\n  }\n  80% {\n    height: 5px;\n  }\n  90% {\n    height: 3px;\n  }\n  100% {\n    height: 1px;\n  }\n}"

/***/ }),

/***/ "./src/app/core/components/equalizer/equalizer.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/core/components/equalizer/equalizer.component.ts ***!
  \******************************************************************/
/*! exports provided: EqualizerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EqualizerComponent", function() { return EqualizerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let EqualizerComponent = class EqualizerComponent {
    constructor() { }
    ngOnInit() { }
};
EqualizerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-equalizer',
        template: `<div class="equaliser-container">
  <ol class="equaliser-column">
  <li class="colour-bar"></li>
  </ol>
  <ol class="equaliser-column">
  <li class="colour-bar"></li>
  </ol>
  <ol class="equaliser-column">
  <li class="colour-bar">
  </li>
  </ol>
  </div>`,
        host: { 'class': 'equalizer-bgd' },
        styles: [__webpack_require__(/*! ./equalizer.component.scss */ "./src/app/core/components/equalizer/equalizer.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], EqualizerComponent);



/***/ }),

/***/ "./src/app/core/components/equalizer/equalizer.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/components/equalizer/equalizer.module.ts ***!
  \***************************************************************/
/*! exports provided: EqualizerModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EqualizerModule", function() { return EqualizerModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_equalizer_equalizer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/equalizer/equalizer.component */ "./src/app/core/components/equalizer/equalizer.component.ts");




let EqualizerModule = class EqualizerModule {
};
EqualizerModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_core_components_equalizer_equalizer_component__WEBPACK_IMPORTED_MODULE_3__["EqualizerComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]
        ],
        exports: [_core_components_equalizer_equalizer_component__WEBPACK_IMPORTED_MODULE_3__["EqualizerComponent"]]
    })
], EqualizerModule);



/***/ }),

/***/ "./src/app/core/components/jsonhp-button/jsonhp-button.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/core/components/jsonhp-button/jsonhp-button.component.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host a {\n  width: 100%;\n  border-top: 1px solid var(--default-border-color);\n  border-bottom: 1px solid var(--default-border-color);\n  text-align: center;\n  width: 100%;\n  min-height: 4em;\n  padding: 1em;\n  text-align: center;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  margin: 2em 0;\n}\n:host a:hover .text {\n  text-decoration: underline;\n}\n:host a .text {\n  font-weight: bold;\n  text-align: start;\n  font-size: 1.2em;\n  color: var(--text-color);\n}\n:host a .image {\n  border-radius: 50%;\n  max-width: 5em;\n  margin: 0 2em;\n  background-repeat: no-repeat !important;\n}\n:host a .image img {\n  width: 100%;\n}\n:host a .arrow {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n  font-size: 0.7em;\n  margin: 0 1em;\n  color: var(--text-color);\n}\nhtml[lang=ar] :host .arrow {\n  -webkit-transform: rotate(0);\n      -ms-transform: rotate(0);\n          transform: rotate(0);\n}"

/***/ }),

/***/ "./src/app/core/components/jsonhp-button/jsonhp-button.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/jsonhp-button/jsonhp-button.component.ts ***!
  \**************************************************************************/
/*! exports provided: JsonhpButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JsonhpButtonComponent", function() { return JsonhpButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _core_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../core/services/deeplinks.service */ "./src/app/core/services/deeplinks.service.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");




let JsonhpButtonComponent = class JsonhpButtonComponent {
    constructor(deeplinkservice, sectionService) {
        this.deeplinkservice = deeplinkservice;
        this.sectionService = sectionService;
        this.section = [];
        this.meta = [];
    }
    ngOnInit() {
        if (this.section.data) {
            this.buttondata = Object.assign({}, this.section.data[0], { href: this.sectionService
                    .getItemHref(this.section.data[0].url, 'button')
                    .replace('/collab', '')
                    .replace('browser', 'https') });
        }
    }
    getGradient() {
        return {
            background: 'linear-gradient(to right,' +
                this.buttondata.color1 +
                ',' +
                this.buttondata.color1 +
                ')'
        };
    }
    handlebutton($event, data) {
        $event.preventDefault();
        let url = data.url;
        if (data.url.indexOf('collab') > -1) {
            url = url.replace('/collab', '');
            url =
                url +
                    (url.indexOf('?') !== -1 ? '&' : '?') +
                    'collabtoken=' +
                    this.meta.collabtoken;
        }
        else {
            url = data.url;
        }
        this.deeplinkservice.handleDeeplink(url);
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], JsonhpButtonComponent.prototype, "section", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], JsonhpButtonComponent.prototype, "meta", void 0);
JsonhpButtonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-jsonhp-button',
        template: __webpack_require__(/*! raw-loader!./jsonhp-button.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/jsonhp-button/jsonhp-button.component.html"),
        styles: [__webpack_require__(/*! ./jsonhp-button.component.scss */ "./src/app/core/components/jsonhp-button/jsonhp-button.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_core_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_2__["DeeplinksService"],
        _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_3__["SectionService"]])
], JsonhpButtonComponent);



/***/ }),

/***/ "./src/app/core/components/jsonhp-button/jsonhp-button.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/core/components/jsonhp-button/jsonhp-button.module.ts ***!
  \***********************************************************************/
/*! exports provided: JsonhpButtonModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JsonhpButtonModule", function() { return JsonhpButtonModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_jsonhp_button_jsonhp_button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/jsonhp-button/jsonhp-button.component */ "./src/app/core/components/jsonhp-button/jsonhp-button.component.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");





let JsonhpButtonModule = class JsonhpButtonModule {
};
JsonhpButtonModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_core_components_jsonhp_button_jsonhp_button_component__WEBPACK_IMPORTED_MODULE_3__["JsonhpButtonComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_4__["IconModule"]
        ],
        exports: [_core_components_jsonhp_button_jsonhp_button_component__WEBPACK_IMPORTED_MODULE_3__["JsonhpButtonComponent"]]
    })
], JsonhpButtonModule);



/***/ }),

/***/ "./src/app/core/components/new-section-builder/card-item/card-item.component.scss":
/*!****************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/card-item/card-item.component.scss ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .collection-item-template {\n  text-decoration: none;\n  text-align: start;\n  background: none;\n  display: block;\n  will-change: background-size;\n}\n:host .collection-item-template .card-item-explicit {\n  width: 1rem;\n  height: 1rem;\n  font-family: var(--font-main-latin);\n}\n:host .collection-item-template:hover {\n  background: none;\n}\n:host .collection-item-template:hover .item-image.ng-lazyloaded,\n:host .collection-item-template:hover .widenew-image.ng-lazyloaded {\n  -webkit-transition: background-size 400ms ease;\n  transition: background-size 400ms ease;\n  background-size: 105%;\n}\n:host .collection-item-template.small_button {\n  margin-left: 5px;\n  margin-right: 5px;\n}\n:host .collection-item-template.small_button .item-image {\n  padding-bottom: 47% !important;\n}\n:host .collection-item-template.small_button .item-title div {\n  color: #e8e8e8;\n}\n:host .collection-item-template.tag {\n  position: relative;\n  display: block;\n}\n:host .collection-item-template.tag .item-image {\n  height: 100%;\n  overflow: hidden;\n  text-align: center;\n}\n:host .collection-item-template.tag .item-image img {\n  position: absolute;\n  height: auto;\n  width: 100%;\n  top: -50%;\n}\n:host .collection-item-template.tag .item-title-primary {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  border-radius: 11px;\n  max-width: 100%;\n  text-decoration: none;\n}\n:host .collection-item-template.tag .item-title-primary .item-name {\n  color: #fff;\n  text-decoration: none;\n  text-align: center;\n}\n:host .collection-item-template.widenew.video .item-image {\n  padding-bottom: unset !important;\n}\n:host .collection-item-template.widenew .item-title {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .collection-item-template:not(.bigrow).video .item-image {\n  padding-bottom: 65%;\n}\n:host .collection-item-template:not(.bigrow).video .item-image.ng-lazyloaded {\n  background-color: #000;\n}\n:host .collection-item-template .item-image {\n  display: block;\n  -webkit-backface-visibility: hidden;\n          backface-visibility: hidden;\n  border-radius: 11px;\n  background-repeat: no-repeat;\n  background: var(--placeholder-background);\n  background-size: 100%;\n  padding-bottom: 100%;\n  position: relative;\n  overflow: hidden;\n  box-shadow: var(--gray-shadow);\n}\n:host .collection-item-template .item-image.ng-lazyloaded {\n  -webkit-animation: unset;\n          animation: unset;\n  background-size: 100%;\n  background-position: 50%;\n  background-repeat: no-repeat;\n  -webkit-transition: background-size 300ms ease;\n  transition: background-size 300ms ease;\n}\n:host .collection-item-template .item-title-primary {\n  padding: 0.5em 0 0.2em 0;\n  display: block;\n}\n:host .collection-item-template .item-title-primary.align-collection-item {\n  -webkit-box-flex: 0.5 !important;\n      -ms-flex: 0.5 !important;\n          flex: 0.5 !important;\n}\n:host .collection-item-template .item-title-primary .item-name {\n  color: var(--text-color);\n  font-size: 1em;\n  font-weight: 500;\n  text-align: start;\n  /* autoprefixer: ignore next */\n  /* autoprefixer: ignore next */\n  /* number of lines to show */\n  /* fallback */\n}\n:host .collection-item-template .item-title-primary .item-name.float-left {\n  text-align: left;\n}\n:host .collection-item-template .item-title-primary .cursor-auto {\n  cursor: auto;\n}\n:host .collection-item-template .item-title-primary h2 {\n  margin: 0;\n  color: var(--title);\n}\n:host .collection-item-template .item-title-primary a:not(.actvt-item-text) {\n  color: var(--text-color) !important;\n  text-decoration: none;\n}\n:host .collection-item-template .item-title-primary .owner {\n  padding: 0.2rem 0;\n}\n:host .collection-item-template .item-title-primary .owner img {\n  max-width: 1.5em;\n  border-radius: 50%;\n}\n:host .collection-item-template .item-title-primary .owner .name {\n  font-size: 0.9em;\n  padding: 0 0.5em;\n  color: var(--text-color);\n}\n:host .collection-item-template .item-title-primary.isowner {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .collection-item-template .item-title-secondary {\n  max-width: 12.1rem;\n  font-size: 0.9em;\n  font-weight: normal;\n  color: var(--text-color-light);\n  position: relative;\n}\n:host .collection-item-template .item-title-secondary a {\n  color: #727272;\n}\n:host .collection-item-template .item-title-secondary a:hover {\n  text-decoration: none;\n}\n:host .collection-item-template .item-title-secondary a.hoverable:hover {\n  text-decoration: underline;\n}\n:host .collection-item-template .item-title-secondary .icon.lock {\n  visibility: hidden;\n  padding: 0 0.5rem;\n}\n:host .collection-item-template .item-title-secondary .icon.lock ::ng-deep svg {\n  width: 1.2em;\n  height: 1.2em;\n}\n:host .collection-item-template .item-title-secondary .icon.visible {\n  visibility: visible;\n}\n:host .collection-item-template.widenew {\n  background: var(--light-gray);\n  padding: 1em;\n  border-radius: 0.7em;\n  margin: 1em 0.5em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n}\n:host .collection-item-template.widenew .item-title {\n  padding: 1em;\n  max-width: 100%;\n}\n:host .collection-item-template.widenew .item-title h2 {\n  font-size: 1.5em;\n  color: var(--title);\n  padding: 0.3em 0;\n  font-weight: 500;\n  margin: 0;\n}\n:host .collection-item-template.widenew .item-title span {\n  color: var(--subtitle);\n}\n:host .collection-item-template.widenew .widenew-image {\n  border-radius: 0.3em;\n  width: 50%;\n  max-width: 25em;\n  min-height: 12em;\n  position: relative;\n  overflow: hidden;\n  padding-bottom: 0;\n}\n:host .collection-item-template.widenew .widenew-image img {\n  position: absolute;\n  left: 0;\n  right: 0;\n}\n:host .collection-item-template.widenew .widenew-image.ng-lazyloaded {\n  -webkit-animation: unset;\n          animation: unset;\n  background-size: 100%;\n  background-position: 50%;\n  background-repeat: no-repeat;\n  -webkit-transition: background-size 300ms ease;\n  transition: background-size 300ms ease;\n}\n:host .collection-item-template.widenew .item-image {\n  max-width: 25em;\n  min-height: 12em;\n  position: relative;\n  overflow: hidden;\n  padding-bottom: 0;\n}\n:host .collection-item-template.widenew .item-image img {\n  position: absolute;\n  left: 0;\n  right: 0;\n}\n:host .collection-item-template.bigimages {\n  margin-left: 5px;\n  margin-right: 5px;\n}\n:host .collection-item-template.profile, :host .collection-item-template.artist {\n  border-bottom: 0px !important;\n}\n:host .collection-item-template.profile .item-image, :host .collection-item-template.artist .item-image {\n  border-radius: 50% !important;\n}\n:host .collection-item-template.profile .item-title-primary .item-name, :host .collection-item-template.artist .item-title-primary .item-name {\n  text-align: center;\n}\n:host .collection-item-template.carousel.bigbanner .item-image {\n  width: 100%;\n  padding-bottom: 38%;\n}\n:host .collection-item-template.carousel.video .item-image {\n  background-color: black;\n  width: 100%;\n  padding-bottom: 65%;\n}\n:host .collection-item-template.video .item-image {\n  background-color: black;\n}\n:host .collection-item-template.card_carousel.link .item-image {\n  overflow: hidden;\n  width: 100%;\n}\n:host .collection-item-template.card_carousel.link .bottom-title {\n  position: absolute;\n  bottom: -0.1em;\n  left: -0.1em;\n  right: -0.1em;\n  padding: 1em;\n  height: 60%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  -webkit-box-align: stretch;\n      -ms-flex-align: stretch;\n          align-items: stretch;\n  -ms-flex-line-pack: start;\n      align-content: flex-start;\n}\n:host .collection-item-template.card_carousel.link .bottom-title .gradient-overlay {\n  position: absolute;\n  bottom: -0.1em;\n  left: -0.1em;\n  right: -0.1em;\n  height: 100%;\n  z-index: 1;\n  border-radius: 0.3em;\n}\n:host .collection-item-template.card_carousel.link .bottom-title .gradient-overlay-dark {\n  position: absolute;\n  bottom: -0.1em;\n  left: -0.1em;\n  right: -0.1em;\n  height: 100%;\n  z-index: 1;\n  border-radius: 0.3em;\n  background: -webkit-gradient(linear, left top, left bottom, from(rgba(255, 255, 255, 0)), to(rgba(0, 0, 0, 0.8)));\n  background: linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, rgba(0, 0, 0, 0.8) 100%);\n}\n:host .collection-item-template.card_carousel.link .bottom-title .supertitle {\n  position: relative;\n  margin: 0.3em 0;\n  z-index: 2;\n}\n:host .collection-item-template.card_carousel.link .bottom-title .supertitle span {\n  background: #fff;\n  color: #000;\n  text-transform: uppercase;\n  border-radius: 0.2em;\n  font-weight: 500;\n  font-size: 0.8em;\n  padding: 0em 0.3em;\n}\n:host .collection-item-template.card_carousel.link .bottom-title .description,\n:host .collection-item-template.card_carousel.link .bottom-title .title {\n  color: #fff;\n  position: relative;\n  z-index: 2;\n}\n:host .collection-item-template.card_carousel.link .bottom-title .description .item-name,\n:host .collection-item-template.card_carousel.link .bottom-title .title .item-name {\n  unicode-bidi: -moz-plaintext;\n  unicode-bidi: plaintext;\n}\n:host .collection-item-template.card_carousel.link .bottom-title .description {\n  font-weight: lighter;\n  font-size: 0.9em;\n}\n:host .collection-item-template.card_carousel.link .bottom-title .description .item-name {\n  text-align: start;\n  /* autoprefixer: ignore next */\n  /* autoprefixer: ignore next */\n  /* number of lines to show */\n  /* fallback */\n}\n:host .collection-item-template.card_carousel.link .bottom-title .title {\n  font-weight: 500;\n  font-size: 1.1rem;\n}\n:host.card.artist .item-title-primary, :host.bigimages.artist .item-title-primary {\n  text-align: center;\n  margin: auto;\n}\n:host.card.artist .item-title-primary .item-name, :host.bigimages.artist .item-title-primary .item-name {\n  float: none !important;\n  text-align: center;\n}\n:host .card {\n  margin-left: 5px;\n  margin-right: 5px;\n}\n:host.bigrow .item-action-like,\n:host.bigrow .item-extras {\n  display: none !important;\n}\n:host .widenewvideo {\n  position: relative;\n  width: 100%;\n  max-width: 25em;\n}\n:host .widenewvideo .widenew-image {\n  width: 100% !important;\n}\n:host .play-video-icon {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  margin: auto;\n  left: 0;\n  right: 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  color: white;\n  width: 3.5em;\n  height: 3.5em;\n  border-radius: 50%;\n  box-shadow: 0px 0px 15px 0px black;\n}\n:host .play-video-icon ::ng-deep svg {\n  width: 3.5em;\n  height: 3.5em;\n}\n:host .item-title-primary {\n  text-decoration: none;\n}\n:host .verified-artist {\n  width: 1em;\n  height: 1em;\n}\n:host .artist-block {\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n  -webkit-box-align: center !important;\n      -ms-flex-align: center !important;\n          align-items: center !important;\n}\n:host .lh-2pt5 {\n  line-height: 2.5rem;\n}\n:host .list-item-click-block {\n  position: absolute !important;\n  left: 0;\n  top: 0;\n  bottom: 0;\n  right: 0;\n}\n:host .latest-date {\n  font-weight: normal;\n  color: #727272;\n  text-transform: capitalize;\n  font-size: 0.8em;\n}\n:host .hover-none:hover {\n  color: var(--title);\n  text-decoration: none !important;\n}\n:host .card-button {\n  margin-top: 2em;\n  width: 10em;\n}\n:host .noPointer {\n  cursor: initial;\n}\nhtml[lang=ar] :host .collection-item-template .row-title {\n  text-align: right !important;\n}\nhtml[lang=ar] :host .collection-item-template:not(.artist) .item-title {\n  text-align: right;\n}\nhtml[lang=ar] :host .collection-item-template.card_carousel.link .bottom-title .supertitle span {\n  padding: 0.25em 0.5em 0.1em 0.5em;\n}\nhtml[lang=ar] :host .collection-item-template.button .arrow {\n  -webkit-transform: initial;\n      -ms-transform: initial;\n          transform: initial;\n}\nhtml[lang=ar] :host .collection-item-template .item-name.float-left {\n  text-align: right !important;\n}\nhtml[lang=ar] :host .collection-item-template .item-label {\n  text-align: right !important;\n}"

/***/ }),

/***/ "./src/app/core/components/new-section-builder/card-item/card-item.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/card-item/card-item.component.ts ***!
  \**************************************************************************************/
/*! exports provided: CardItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CardItemComponent", function() { return CardItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../core/modules/player/actions/player.actions */ "./src/app/core/modules/player/actions/player.actions.ts");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/deeplinks.service */ "./src/app/core/services/deeplinks.service.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _core_modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../core/modules/player/actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");
/* harmony import */ var _anghami_redux_actions_deeplinks_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/deeplinks.actions */ "./src/app/core/redux/actions/deeplinks.actions.ts");











let CardItemComponent = class CardItemComponent {
    constructor(store, deeplinksService) {
        this.store = store;
        this.deeplinksService = deeplinksService;
        this.cardItemClickEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    ngOnInit() {
        this.setOverlayControlsVisibility();
        this.genericTypeMapper();
        this.hrefHasHttp = this.collectionItem.href && this.collectionItem.href.indexOf("http") > -1;
        if (this.type === 'video' ||
            this.type === 'playlist' ||
            this.type === 'song' ||
            this.type === 'album') {
            this.shouldShowControlsCarousel = this.shouldShowControls;
        }
        else {
            this.shouldShowControlsCarousel =
                this.checkDeepLinkType(this.type) && !!this.collectionItem.hasOverlay;
        }
    }
    genericTypeMapper() {
        //Update item type if generic
        if (this.type === 'genericitem' &&
            this.collectionItem.generictype) {
            //change item type
            this.type = this.collectionItem.generictype;
        }
    }
    setOverlayControlsVisibility() {
        const displayTypeCond = this.displayType === 'card' ||
            this.displayType === 'carousel' ||
            this.displayType === 'bigimages';
        const typeCond = this.type === 'album' ||
            this.type === 'playlist' ||
            this.type === 'song' ||
            this.type === 'video';
        const genericCond = this.collectionItem.generictype === 'album' ||
            this.collectionItem.generictype === 'song' ||
            this.collectionItem.generictype === 'playlist';
        if (displayTypeCond &&
            (typeCond || genericCond) &&
            !(this.collectionItem.is_premium_content === true)) {
            this.shouldShowControls = true;
        }
    }
    checkDeepLinkType(type) {
        if (this.collectionItem.deeplink) {
            const deeplink = this.deeplinksService.getParsedDeeplinkObject(this.collectionItem.deeplink);
            if (deeplink.name === 'tag' || deeplink.name === 'artist') {
                return false;
            }
            else {
                return true;
            }
        }
        return false;
    }
    getGradient() {
        return {
            background: `-webkit-linear-gradient(top, rgba(0,0,0,0) 0%, ${this.collectionItem.hexcolor} 100%)`
        };
    }
    clickHandler() {
        if (this.collectionItem.deeplink) {
            const dl = decodeURIComponent(this.collectionItem.deeplink);
            this.store.dispatch(new _anghami_redux_actions_deeplinks_actions__WEBPACK_IMPORTED_MODULE_10__["ExecuteDeeplink"](dl));
            return;
        }
    }
    playSong() {
        const isGenericSongCarousel = this.type === 'genericitem' && this.collectionItem.generictype == 'song';
        if (this.type === 'song' || isGenericSongCarousel) {
            this.cardItemClickEvent.emit({
                id: this.collectionItem.id,
                cardItemType: 'song'
            });
        }
        else {
            this.clickHandler();
        }
    }
    overlayAction(event) {
        switch (event) {
            case 'play': {
                switch (this.type) {
                    case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].ALBUM:
                    case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].PLAYLIST: {
                        if (!!this.collectionItem.genericid) {
                            this.store.dispatch(new _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_4__["PlayGenericContent"]({
                                id: this.collectionItem.genericid,
                                type: _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].GENERIC
                            }));
                        }
                        else {
                            this.store.dispatch(new _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_4__["GetCollectionAutoPlay"]({
                                id: this.collectionItem.id,
                                type: this.type
                            }));
                        }
                        break;
                    }
                    case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].SONG: {
                        this.store.dispatch(new _core_modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_9__["PlaySongEngine"]({
                            id: this.collectionItem.id
                        }));
                        break;
                    }
                    case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].GENRIC_ITEM: {
                        this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_5__["SetExtras"]({
                            extras: this.collectionItem.extras
                        }));
                        if (!!this.collectionItem.genericid) {
                            this.store.dispatch(new _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_4__["PlayGenericContent"]({
                                id: this.collectionItem.genericid,
                                type: _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].GENERIC
                            }));
                        }
                        else {
                            switch (this.collectionItem.generictype) {
                                case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].SONG: {
                                    this.store.dispatch(new _core_modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_9__["PlaySongEngine"]({
                                        id: this.collectionItem.id
                                    }));
                                    break;
                                }
                                default: {
                                    this.store.dispatch(new _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_4__["GetCollectionAutoPlay"]({
                                        id: this.collectionItem.id,
                                        type: this.collectionItem.generictype
                                    }));
                                }
                            }
                        }
                        break;
                    }
                    case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].LINK: {
                        const deeplink = this.deeplinksService.getParsedDeeplinkObject(this.collectionItem.deeplink);
                        switch (deeplink.name) {
                            case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].ALBUM:
                            case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].PLAYLIST: {
                                this.store.dispatch(new _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_4__["GetCollectionAutoPlay"]({
                                    id: deeplink.routeParam,
                                    type: deeplink.name
                                }));
                                break;
                            }
                            case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].SONG: {
                                this.store.dispatch(new _core_modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_9__["PlaySongEngine"]({
                                    id: deeplink.routeParam
                                }));
                                break;
                            }
                            case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].GENERIC: {
                                this.store.dispatch(new _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_4__["PlayGenericContent"]({
                                    id: deeplink.routeParam,
                                    type: deeplink.name
                                }));
                                break;
                            }
                        }
                    }
                }
                break;
            }
            case 'download': {
                if (this.collectionItem.href.split('/')[1] == 'song') {
                    this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_7__["DownloadSong"]({ song: this.collectionItem }));
                }
                else {
                    this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_7__["DownloadListByID"]({
                        id: this.collectionItem.href.split('/')[2].split('?')[0],
                        type: this.collectionItem.href.split('/')[1]
                    }));
                }
                break;
            }
            case 'share': {
                let type;
                if (!!this.collectionItem.genericid) {
                    type = _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].GENERIC;
                }
                else if (!!this.collectionItem.generictype) {
                    type = this.collectionItem.generictype;
                }
                else {
                    type = this.type;
                }
                this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_8__["OpenShareModal"]({
                    type: type,
                    meta: this.collectionItem
                }));
            }
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], CardItemComponent.prototype, "cardItemClickEvent", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], CardItemComponent.prototype, "displayType", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], CardItemComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CardItemComponent.prototype, "collectionItem", void 0);
CardItemComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-card-item',
        template: __webpack_require__(/*! raw-loader!./card-item.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/card-item/card-item.component.html"),
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
        styles: [__webpack_require__(/*! ./card-item.component.scss */ "./src/app/core/components/new-section-builder/card-item/card-item.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
        _anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_6__["DeeplinksService"]])
], CardItemComponent);



/***/ }),

/***/ "./src/app/core/components/new-section-builder/card-section/card-section.component.scss":
/*!**********************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/card-section/card-section.component.scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .multiline-card-container,\n:host .small-button-container {\n  margin-top: 0.5rem;\n  margin-bottom: 0.5rem;\n  -webkit-box-flex: 0;\n      -ms-flex: 0 0 16.666666666%;\n          flex: 0 0 16.666666666%;\n  max-width: 16.666666666%;\n}\n@media screen and (max-width: 1050px) {\n  :host .multiline-card-container,\n:host .small-button-container {\n    -webkit-box-flex: 0;\n        -ms-flex: 0 0 33.3333333333%;\n            flex: 0 0 33.3333333333%;\n    max-width: 33.3333333333%;\n  }\n}\n@media screen and (min-width: 1050px) and (max-width: 1300px) {\n  :host .multiline-card-container,\n:host .small-button-container {\n    -webkit-box-flex: 0;\n        -ms-flex: 0 0 25%;\n            flex: 0 0 25%;\n    max-width: 25%;\n  }\n}\n@media screen and (min-width: 1300px) and (max-width: 1800px) {\n  :host .multiline-card-container,\n:host .small-button-container {\n    -webkit-box-flex: 0;\n        -ms-flex: 0 0 20%;\n            flex: 0 0 20%;\n    max-width: 20%;\n  }\n}\n:host .row {\n  margin-left: -20px;\n  margin-right: -20px;\n}\n:host .widenew-container {\n  width: 100%;\n}"

/***/ }),

/***/ "./src/app/core/components/new-section-builder/card-section/card-section.component.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/card-section/card-section.component.ts ***!
  \********************************************************************************************/
/*! exports provided: breakPoints, CardSectionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakPoints", function() { return breakPoints; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CardSectionComponent", function() { return CardSectionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/deeplinks.service */ "./src/app/core/services/deeplinks.service.ts");



var breakPoints;
(function (breakPoints) {
    breakPoints["xs"] = "0";
    breakPoints["sm"] = "576";
    breakPoints["md"] = "768";
    breakPoints["lg"] = "992";
    breakPoints["xl"] = "1400";
    breakPoints["xxl"] = "1800";
})(breakPoints || (breakPoints = {}));
let CardSectionComponent = class CardSectionComponent {
    constructor(_deeplinksService) {
        this._deeplinksService = _deeplinksService;
    }
    ngOnInit() {
        this.checkDisplayType();
        this.isQuestion = this.section.type === 'question' || this.section.type === 'subscribe';
        this.updateSectionInitialNumItems();
    }
    ngOnChanges(changes) {
        this.checkDisplayType();
        this.updateSectionInitialNumItems();
    }
    checkDisplayType() {
        this.isSmallButton = this.section.displaytype === 'small_button';
        this.isWideNew = this.section.displaytype === 'widenew';
        this.isMultilineCard =
            this.section.displaytype === 'bigimages' ||
                this.section.displaytype === 'card';
        this.isCardItem =
            this.isSmallButton || this.isWideNew || this.isMultilineCard;
    }
    handleQuestionClick(url) {
        this._deeplinksService.handleDeeplink(url);
    }
    closeQuestion() {
        this.isQuestion = false;
    }
    updateSectionInitialNumItems() {
        // TODO: Fix initialNumItems logic, we need to unify our logic in such a way that we rely on setting
        // initialNumItems on the client side and ignore what's being returned by the server in order
        // to avoid weird if statements that handle edge cases related to poor instructions from API
        this.section = Object.assign({}, this.section, { initialNumItems: this.section.expanded
                ? this.section.initialNumItems : this.initialNumItems + 1 });
        if (this.hasSideView) {
            if (this.initialNumItems === 2 && !this.section.expanded) {
                this.section.initialNumItems = 4;
            }
            if (this.initialNumItems === 3 && !this.section.expanded) {
                this.section.initialNumItems = 5;
            }
        }
        if (this.section.sectionid === "followed" || (this.section.group && this.section.group.indexOf("generic-") > -1)) { //disgusting stuff
            this.section.initialNumItems = this.section.count;
            this.section.expanded = true;
        }
    }
    renderMoreStateBtnLoop() {
        const winwidth = window.innerWidth;
        let initialNumItems = 4;
        if (winwidth >= parseInt(breakPoints.xxl, 0)) {
            initialNumItems = 6;
        }
        else if (winwidth >= parseInt(breakPoints.xl, 0) &&
            winwidth < parseInt(breakPoints.xxl, 0)) {
            initialNumItems = 5;
        }
        else if (winwidth >= parseInt(breakPoints.lg, 0) &&
            winwidth < parseInt(breakPoints.xl, 0)) {
            initialNumItems = 4;
        }
        else {
            initialNumItems = 3;
        }
        this.section = Object.assign({}, this.section, { initialNumItems: initialNumItems });
    }
    ngOnDestroy() {
        if (this.windowResizeSub$) {
            this.windowResizeSub$.unsubscribe();
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CardSectionComponent.prototype, "section", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
], CardSectionComponent.prototype, "initialNumItems", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], CardSectionComponent.prototype, "hasSideView", void 0);
CardSectionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-card-section',
        template: __webpack_require__(/*! raw-loader!./card-section.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/card-section/card-section.component.html"),
        styles: [__webpack_require__(/*! ./card-section.component.scss */ "./src/app/core/components/new-section-builder/card-section/card-section.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_2__["DeeplinksService"]])
], CardSectionComponent);



/***/ }),

/***/ "./src/app/core/components/new-section-builder/list-item/list-item.component.scss":
/*!****************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/list-item/list-item.component.scss ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".common-list-item {\n  text-decoration: none;\n  background: none;\n  position: relative;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  border-bottom: var(--default-item-border);\n  padding: 1em;\n  cursor: pointer;\n  border-radius: 0.1em;\n  color: #727272;\n  margin: 0 -1em;\n}\n.common-list-item.selected-song {\n  box-shadow: var(--track-shadow);\n  background: var(--track-hover);\n}\n.list-item {\n  text-align: start;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  align-items: center;\n  /*::ng-deep .colour-bar {\n    background: #000\n  }*/\n}\n.list-item:not(.search-edge-item):hover {\n  box-shadow: var(--track-shadow);\n  background: var(--track-hover);\n}\n.list-item:not(.search-edge-item):hover .list-item-play-icon {\n  display: block;\n}\n.list-item.artist .list-item-image, .list-item.profile .list-item-image {\n  border-radius: 50%;\n}\n.list-item.queue {\n  padding: 0;\n  margin: 1em 0;\n  border: 0;\n  box-shadow: none;\n}\n.list-item.queue .item-top {\n  display: none;\n}\n.list-item.queue .queue-actions {\n  padding: 0 1em;\n}\n.list-item.queue .queue-actions anghami-icon {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0 0.5em;\n  font-size: 0.8em;\n}\n.list-item.queue .queue-actions anghami-icon:hover {\n  color: #8d00f2;\n}\n.list-item.queue .queue-actions anghami-icon.remove {\n  visibility: hidden;\n}\n.list-item.queue:hover .queue-actions .remove {\n  visibility: visible;\n}\n.list-item.queue .download-progress-bar-container {\n  left: 5em;\n  right: 2.8em;\n}\n.list-item.current-track {\n  box-shadow: var(--track-shadow);\n  background-color: var(--track-hover);\n  border: 0;\n}\n.list-item.bigrow .item-action-like,\n.list-item.bigrow .item-extras {\n  display: none !important;\n}\n.list-item .owner-picture {\n  max-width: 1.5em;\n  border-radius: 50%;\n}\n.list-item .owner-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.list-item .owner-name {\n  font-size: 0.9em;\n  /* padding: 0 0.5em; */\n  color: var(--text-color);\n  padding-left: 0.5em;\n  padding-right: 0.5em;\n  padding-top: 2px;\n}\n.list-item .item-title-secondary {\n  display: inline-block;\n  font-size: 1.1em;\n  font-weight: normal;\n  color: var(--text-color-light);\n  position: relative;\n}\n.list-item .item-title-secondary a {\n  color: #727272;\n}\n.list-item .item-title-secondary a:hover {\n  text-decoration: none;\n}\n.list-item .item-title-secondary a.hoverable:hover {\n  text-decoration: underline;\n}\n.list-item .item-title-secondary .icon.lock {\n  visibility: hidden;\n  padding: 0 0.5rem;\n}\n.list-item .item-title-secondary .icon.lock ::ng-deep svg {\n  width: 1.2em;\n  height: 1.2em;\n}\n.list-item .item-title-secondary .icon.visible {\n  visibility: visible;\n}\n.list-item .list-item-info {\n  padding: 0 0.5em;\n}\n.list-item .list-item-image {\n  width: 3.5em;\n  height: 3.5em;\n  position: relative;\n  border-radius: 0.3em;\n  background: var(--placeholder-background);\n  background-size: cover;\n}\n.list-item .album-list-item-image {\n  position: relative;\n  width: 1rem;\n}\n.list-item .album-list-item-image .equalizer ::ng-deep .equalizer-bgd .colour-bar {\n  background: var(--album-equalizer-background);\n}\n.list-item .equalizer-loader {\n  width: 3em;\n  position: relative;\n}\n.list-item .equalizer-loader ::ng-deep .equalizer-bgd {\n  padding: 0 2.5em;\n  background: none;\n  top: -5px;\n}\n.list-item .equalizer-loader ::ng-deep .equalizer-bgd .colour-bar {\n  background: var(--text-color);\n}\n.list-item .generic-type {\n  font-size: 0.7em;\n  font-weight: bold;\n}\n.list-item .list-item-play-icon {\n  position: absolute;\n  color: #fff;\n  display: none;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  background-color: rgba(0, 0, 0, 0.5);\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: 50%;\n  border-radius: 0.3em;\n}\n.list-item .list-item-play-icon .icon {\n  font-size: 1.3em;\n  margin: 0.56em;\n}\n.list-item .list-item-click-block {\n  position: absolute !important;\n  left: 0;\n  top: 0;\n  bottom: 0;\n  right: 13%;\n}\n.list-item .verified-artist {\n  width: 1em;\n  height: 1em;\n}\n.list-item .latest-date {\n  font-weight: normal;\n  color: #727272;\n  text-transform: capitalize;\n  font-size: 0.8em;\n}\n.list-item .exclusive-badge {\n  bottom: 0;\n  left: 0;\n  right: 0;\n  top: auto;\n  font-size: 0.6em;\n  top: auto;\n}\n.list-item .item-action-like {\n  color: var(--text-color);\n}\n.list-item .item-action-like.liked {\n  color: var(--brand-purple);\n}\n.list-item .item-action-like.hidden {\n  display: none;\n}\n.list-item .exclusive-badge {\n  bottom: 0;\n  left: 0;\n  right: 0;\n  top: auto;\n  padding: 0.2em;\n  font-size: 0.5em;\n  text-align: center;\n}\n.list-item .item-title-secondary a {\n  font-size: 0.9em;\n  color: #727272;\n  max-height: 3em;\n  /* fallback */\n}\n.list-item .item-title-secondary a:hover {\n  text-decoration: underline;\n}\n.list-item .list-item-details {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  padding: 0 0.5em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n}\n.podcast-list-item {\n  text-align: left;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-align: start !important;\n      -ms-flex-align: start !important;\n          align-items: flex-start !important;\n  box-shadow: 0px 0px 3px 0px var(--list-item-shadow);\n  width: 100%;\n  margin: auto;\n  margin-bottom: 1em;\n  background: var(--light-background);\n  border-radius: 5px;\n}\n.podcast-list-item .flex {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n.podcast-list-item:not(.search-edge-item):hover {\n  background: var(--list-item-hover);\n}\n.podcast-list-item .item-title-primary {\n  max-width: none;\n}\n.podcast-list-item .list-item-info {\n  padding: 0 0.5em;\n}\n.podcast-list-item .description {\n  margin-top: 1.5em;\n}\n.podcast-list-item .podcast-progress {\n  width: 80%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin-top: 1.5em;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.podcast-list-item .podcast-progress .progress {\n  width: 50%;\n  margin-right: 1em;\n  height: 0.3em;\n}\n.podcast-list-item .podcast-progress .progress .progress-bar {\n  background-color: var(--brand-purple);\n}\n.podcast-list-item .podcast-progress .progress:lang(ar) {\n  margin-right: 0em;\n  margin-left: 1em;\n}\n.podcast-list-item .podcast-progress span {\n  padding-bottom: 0.2em;\n}\n.podcast-list-item .list-item-details {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  padding: 0 0.5em;\n}\n.podcast-list-item .list-item-details .track-date-duration {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: left;\n      -ms-flex-pack: left;\n          justify-content: left;\n}\n.podcast-list-item .list-item-details .track-date-duration span {\n  margin-right: 1em;\n  margin-left: 0em;\n}\n.podcast-list-item .list-item-details .track-date-duration:lang(ar) {\n  -webkit-box-pack: right;\n      -ms-flex-pack: right;\n          justify-content: right;\n}\n.podcast-list-item .list-item-details .track-date-duration:lang(ar) span {\n  margin-right: 0em;\n  margin-left: 1em;\n}\n.download-progress-bar-container {\n  height: 0.1em;\n  display: block;\n  background: var(--download-bar-container);\n  position: absolute;\n  bottom: 15%;\n  left: 5.5em;\n  right: 1em;\n  border-radius: 15px;\n}\n.download-progress-bar-container .download-progress-bar {\n  max-width: 100%;\n  height: 0.1em;\n  display: block;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  background: var(--download-bar-fill);\n  position: absolute;\n  bottom: 0;\n  right: 0;\n  left: 0;\n  width: 0%;\n  bottom: 0;\n  border-radius: 15px;\n  -webkit-transition: width 0.2s;\n  transition: width 0.2s;\n  -webkit-transition-timing-function: linear;\n          transition-timing-function: linear;\n}\n.item-action-like,\n.item-context-sheet,\n.item-label,\n.item-extras {\n  display: block;\n}\n.item-top {\n  text-align: center;\n  color: var(--text-color);\n  font-weight: bold;\n  margin-right: 1em;\n}\n.item-top .icon,\n.item-top div {\n  margin: auto;\n}\n.item-top .nochange {\n  color: #979897;\n}\n.item-top .falling {\n  color: #ff0a00;\n}\n.item-top .rising {\n  color: #11ce00;\n}\n.item-top .newentry {\n  color: #11ce00;\n}\n.item-title-primary {\n  text-align: start;\n  padding: 0 1em;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  text-decoration: none;\n}\n.item-title-primary .latest-date {\n  font-weight: normal;\n  color: #727272;\n  text-transform: capitalize;\n  font-size: 0.8em;\n}\n.item-title-primary .item-label {\n  color: var(--grey-text-color);\n  font-weight: lighter;\n  font-size: 0.8em;\n}\n.item-title-primary .item-name {\n  color: var(--text-color);\n  font-size: 1.1em;\n  font-weight: bold;\n  text-align: start;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  /* autoprefixer: ignore next */\n  display: -webkit-box;\n  /* autoprefixer: ignore next */\n  -webkit-box-orient: vertical;\n  -webkit-line-clamp: 2;\n  /* number of lines to show */\n  max-height: 3em;\n  /* fallback */\n}\n.item-name {\n  color: var(--text-color);\n  font-size: 1.1em;\n  font-weight: 500;\n  text-align: start;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  /* autoprefixer: ignore next */\n  display: -webkit-box;\n  /* autoprefixer: ignore next */\n  -webkit-box-orient: vertical;\n  -webkit-line-clamp: 2;\n  /* number of lines to show */\n  max-height: 3em;\n  /* fallback */\n}\n.list-item-actions {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n.list-item-actions .icon {\n  margin: 0.75em 0.6em 0em 0.6em;\n  font-size: 0.8em;\n}\n.list-item-actions .icon:hover {\n  color: #AAA;\n}\n.list-item-actions anghami-context-sheet-new {\n  font-size: 0.8em;\n}\n.cursor-auto {\n  cursor: auto;\n}\n.arabic-item-details {\n  font-family: var(--font-main-arabic);\n}\n.item-title-primary {\n  padding: 0.5em 0 0.2em 0;\n  display: block;\n  max-width: 18rem;\n}\n.item-title-primary .item-name {\n  color: var(--text-color);\n  font-size: 1.1em;\n  font-weight: 500;\n  text-align: start;\n  /* fallback */\n}\n.item-title-primary .item-name.float-left {\n  text-align: left;\n}\n.item-title-primary h2 {\n  margin: 0;\n  color: var(--title);\n}\n.item-title-primary a:not(.actvt-item-text) {\n  color: var(--text-color) !important;\n  text-decoration: none;\n}\n.item-title-primary.isowner {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n.artist-block {\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n  -webkit-box-align: center !important;\n      -ms-flex-align: center !important;\n          align-items: center !important;\n}\n.hidden {\n  display: none;\n}\n.list-item-explicit {\n  height: 32%;\n  width: 26%;\n  font-family: var(--font-main-latin);\n}\n.list-item-explicit .e-block {\n  font-size: 7px;\n}\nhtml[lang=ar] .item-top {\n  margin-right: 0 !important;\n  margin-left: 1em !important;\n}"

/***/ }),

/***/ "./src/app/core/components/new-section-builder/list-item/list-item.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/list-item/list-item.component.ts ***!
  \**************************************************************************************/
/*! exports provided: ListItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListItemComponent", function() { return ListItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/library.actions */ "./src/app/core/redux/actions/library.actions.ts");
/* harmony import */ var _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/services/coverart.service */ "./src/app/core/services/coverart.service.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _anghami_redux_actions_deeplinks_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/actions/deeplinks.actions */ "./src/app/core/redux/actions/deeplinks.actions.ts");
/* harmony import */ var _anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/db.actions */ "./src/app/core/redux/actions/db.actions.ts");
/* harmony import */ var _core_modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../core/modules/player/actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/deeplinks.service */ "./src/app/core/services/deeplinks.service.ts");














let ListItemComponent = class ListItemComponent {
    constructor(authService, deeplinksService, platformId, store, coverArtService) {
        this.authService = authService;
        this.deeplinksService = deeplinksService;
        this.platformId = platformId;
        this.store = store;
        this.coverArtService = coverArtService;
        this.listItemClickEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.offlineMode = false;
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["isPlatformBrowser"])(this.platformId)) {
            this.isBrowser = true;
            this.offlineMode = window['desktopClient'].offlineMode;
        }
    }
    ngOnInit() {
        if (this.type === 'queue') {
            this.scrollTarget = document.getElementById("queue_scroller");
        }
    }
    ngOnChanges() {
        this.setShouldShowStatus();
        this.setShouldRedirectOnClick();
        this.setShouldShowPlayIcon();
        this.setSmallTrackCoverArt();
        this.podcastItemWithPodcast = this.collectionItem.progress && this.collectionItem.progress > 1;
    }
    calculatePercentage() {
        return this.podcastItemWithPodcast ? [{
                currentProgress: (this.collectionItem.progress * 100 / this.collectionItem.duration),
                timeLeft: this.collectionItem.duration - this.collectionItem.progress
            }] : [{
                currentProgress: 0,
                timeLeft: this.collectionItem.duration
            }];
    }
    seoPreventRouting(event) {
        event.stopPropagation();
        event.preventDefault();
        this.clickHandler(event);
        return;
    }
    setSmallTrackCoverArt() {
        let coverArtImage;
        if (this.collectionItem.coverArt) {
            coverArtImage = this.coverArtService.getCoverArtImage(this.collectionItem.coverArt, 60);
        }
        else if (this.collectionItem.image) {
            coverArtImage = this.collectionItem.image;
        }
        else if (this.collectionItem.coverArtImage) {
            coverArtImage = this.coverArtService.getCoverArtImage(this.collectionItem.coverArtImage, 60);
        }
        else {
            coverArtImage = this.coverArtService.getCoverArtImage(this.collectionItem.ArtistArt, 60);
        }
        this.collectionItem = Object.assign({}, this.collectionItem, { coverArtImage: coverArtImage });
    }
    setShouldShowStatus() {
        if (this.displayType === 'list' &&
            (this.collectionItem.generictype === 'album' ||
                this.type === 'album' ||
                this.collectionItem.generictype === 'song' ||
                this.type === 'song') &&
            this.type !== 'queue') {
            this.shouldShowLikeButton = true;
        }
    }
    setShouldRedirectOnClick() {
        if (this.collectionItem.generictype !== 'song' && this.type !== 'song') {
            this.shouldRedirectOnClick = true;
        }
    }
    setShouldShowPlayIcon() {
        if (this.fromSearch) {
            if ((this.isSearchActiveTabSong ||
                this.collectionItem.generictype === 'song') &&
                !this.collectionItem.isPlaying) {
                this.shouldShowPlayIcon = true;
            }
            else {
                this.shouldShowPlayIcon = false;
            }
        }
        else {
            this.shouldShowPlayIcon =
                (this.type === 'song' ||
                    this.type === 'video' ||
                    this.type === 'queue' ||
                    this.collectionItem.generictype === 'song') &&
                    !this.collectionItem.isPlaying;
        }
    }
    shortenText(text) {
        if (text && text.length > 200) {
            return text.substr(0, 200) + ' ...';
        }
        return text;
    }
    clickHandler(event, index) {
        if (this.collectionItem.disabled) {
            if (this.collectionItem.disabled_url) {
                this.store.dispatch(new _anghami_redux_actions_deeplinks_actions__WEBPACK_IMPORTED_MODULE_9__["ExecuteDeeplink"](this.collectionItem.disabled_url));
            }
            return;
        }
        if (this.collectionItem.generictype && this.collectionItem.generictype === 'link'
            && this.collectionItem.deeplink) {
            event.preventDefault();
            if (this.collectionItem.deeplink.indexOf("anghami://") > -1) {
                this.deeplinksService.handleDeeplink(this.collectionItem.deeplink);
            }
            else {
                window.open(this.collectionItem.deeplink, '_blank');
            }
            return;
        }
        if (this.shouldShowPlayIcon) {
            this.listItemClickEvent.emit({
                id: this.collectionItem.id,
                fromSearchWithMixedData: this.isSearchActiveTabSong ||
                    this.collectionItem.generictype === 'song',
                item: this.collectionItem,
                index: this.index,
                isVideo: this.type === 'video'
            });
        }
        if (this.fromSearch) {
            // save collection item to recent search
            this.store.dispatch(new _anghami_redux_actions_db_actions__WEBPACK_IMPORTED_MODULE_10__["PutInTable"]({
                entry: this.collectionItem,
                type: this.type,
                table: 'recentSearches'
            }));
        }
    }
    downloadSong($event) {
        $event.stopPropagation();
        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_12__["DownloadSong"]({ song: this.collectionItem }));
    }
    handleLikeClick($event) {
        $event.stopPropagation();
        if (!this.authService.isUserLoggedIn()) {
            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["OpenCustomDialog"]({
                type: _enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_8__["DIALOG_TYPES"].LOGIN
            }));
            return;
        }
        this.collectionItem = Object.assign({}, this.collectionItem, { liked: !this.collectionItem.liked });
        if (this.type === 'album' || this.collectionItem.generictype === 'album') {
            this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_4__["LikeAlbum"]({
                item: this.collectionItem
            }));
        }
        else if (this.type === 'song' ||
            this.collectionItem.generictype === 'song') {
            this.store.dispatch(new _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_4__["LikeSong"]({
                item: this.collectionItem
            }));
        }
    }
    removeFromQueue(event, index) {
        if (event) {
            event.stopPropagation();
        }
        this.store.dispatch(new _core_modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_11__["RemoveTrackFromQueue"](index));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListItemComponent.prototype, "displayType", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ListItemComponent.prototype, "isAlbumView", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListItemComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListItemComponent.prototype, "currentList", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListItemComponent.prototype, "collectionItem", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListItemComponent.prototype, "index", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ListItemComponent.prototype, "fromSearch", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ListItemComponent.prototype, "isSearchActiveTabSong", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ListItemComponent.prototype, "fromSearchEdgeContainer", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListItemComponent.prototype, "top", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], ListItemComponent.prototype, "listItemClickEvent", void 0);
ListItemComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-list-item',
        template: __webpack_require__(/*! raw-loader!./list-item.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/list-item/list-item.component.html"),
        styles: [__webpack_require__(/*! ./list-item.component.scss */ "./src/app/core/components/new-section-builder/list-item/list-item.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"],
        _anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_13__["DeeplinksService"],
        Object,
        _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
        _anghami_services_coverart_service__WEBPACK_IMPORTED_MODULE_5__["CoverArtService"]])
], ListItemComponent);



/***/ }),

/***/ "./src/app/core/components/new-section-builder/list-item/list-item.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/list-item/list-item.module.ts ***!
  \***********************************************************************************/
/*! exports provided: ListItemModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListItemModule", function() { return ListItemModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _list_item_list_item_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../list-item/list-item.component */ "./src/app/core/components/new-section-builder/list-item/list-item.component.ts");
/* harmony import */ var _context_sheet_new_context_sheet_new_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../context-sheet-new/context-sheet-new.module */ "./src/app/core/components/context-sheet-new/context-sheet-new.module.ts");
/* harmony import */ var _core_directives_extras_extras_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../core/directives/extras/extras.module */ "./src/app/core/directives/extras/extras.module.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _components_equalizer_equalizer_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/equalizer/equalizer.module */ "./src/app/core/components/equalizer/equalizer.module.ts");











let ListItemModule = class ListItemModule {
};
ListItemModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_list_item_list_item_component__WEBPACK_IMPORTED_MODULE_3__["ListItemComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _context_sheet_new_context_sheet_new_module__WEBPACK_IMPORTED_MODULE_4__["ContextSheetNewModule"],
            _core_directives_extras_extras_module__WEBPACK_IMPORTED_MODULE_5__["ExtrasModule"],
            ng_lazyload_image__WEBPACK_IMPORTED_MODULE_6__["LazyLoadImageModule"],
            _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_7__["IconModule"],
            _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_9__["RouterModule"],
            _components_equalizer_equalizer_module__WEBPACK_IMPORTED_MODULE_10__["EqualizerModule"]
        ],
        exports: [_list_item_list_item_component__WEBPACK_IMPORTED_MODULE_3__["ListItemComponent"]]
    })
], ListItemModule);



/***/ }),

/***/ "./src/app/core/components/new-section-builder/list-section/list-section.component.scss":
/*!**********************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/list-section/list-section.component.scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".vibes-tags-container {\n  margin: 0 0 1em 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n\n.vibes-tags-container:lang(ar) {\n  text-align: right;\n}\n\n.vibes-number {\n  background: var(--vibes-tag-bg);\n  color: var(--vibes-tag-selected-bg);\n  border-radius: 3px;\n  font-size: 0.6rem;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  margin-right: 0.5rem;\n  padding-left: 0.25rem;\n  padding-right: 0.25rem;\n}\n\n.vibes-tag {\n  padding: 0.5rem 1rem 0.5rem 1rem;\n  border-radius: 0.3rem;\n  font-size: 0.75rem;\n  display: inline-block;\n  vertical-align: middle;\n  margin-right: 0.5em;\n  margin-top: 0.5em;\n  color: var(--vibes-foreground);\n  cursor: pointer;\n  text-transform: capitalize;\n  white-space: nowrap;\n  text-align: start;\n  background: var(--vibes-background);\n}\n\n.selected-vibe {\n  background: var(--vibes-tag-selected-bg);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n\n.selected-vibe .vibes-name {\n  color: var(--vibes-tag-bg);\n  font-weight: 500;\n}\n\n.tags-limitter {\n  font-size: 0.9em;\n  color: #AAA;\n  display: inline-block;\n  vertical-align: middle;\n  margin-top: 0.5em;\n}\n\n.tags-limitter:hover {\n  text-decoration: underline;\n}\n\n.arrow {\n  fill: #707070;\n  font-size: 1em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  padding-top: 1px;\n  border: solid 1px var(--sidebar-background);\n  margin-top: 0.4em;\n  padding: 0.8em 0.8em;\n  border-radius: 5px;\n  cursor: pointer;\n}\n\n.arrow.left {\n  margin-left: 5px;\n  margin-right: 2.5px;\n}\n\n.arrow.right svg {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n\n.arrow svg {\n  width: 1em;\n  height: 1em;\n}\n\n.arrow:lang(ar).left {\n  margin-right: 5px;\n  margin-left: 2.5px;\n}\n\n.arrow:lang(ar).left svg {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n\n.arrow:lang(ar).right svg {\n  -webkit-transform: rotate(0deg);\n      -ms-transform: rotate(0deg);\n          transform: rotate(0deg);\n}\n\n.bio-scrollable {\n  overflow: auto;\n  max-height: 20em;\n  text-align: justify;\n  padding: 0 0.6em;\n}\n\n.focused-item ::ng-deep .search-edge-item {\n  box-shadow: var(--track-shadow) !important;\n  background: var(--track-hover) !important;\n}"

/***/ }),

/***/ "./src/app/core/components/new-section-builder/list-section/list-section.component.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/list-section/list-section.component.ts ***!
  \********************************************************************************************/
/*! exports provided: KEY_CODE, ListSectionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KEY_CODE", function() { return KEY_CODE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListSectionComponent", function() { return ListSectionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/desktop-download.service */ "./src/app/core/services/desktop-download.service.ts");
/* harmony import */ var _core_modules_player_player_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../core/modules/player/player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../enums/special-playlist-names.enum */ "./src/app/core/enums/special-playlist-names.enum.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! swiper/dist/js/swiper.min.js */ "./node_modules/swiper/dist/js/swiper.min.js");
/* harmony import */ var swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_11__);












var KEY_CODE;
(function (KEY_CODE) {
    KEY_CODE["UP_ARROW"] = "ArrowUp";
    KEY_CODE["DOWN_ARROW"] = "ArrowDown";
    KEY_CODE["ENTER_KEYCODE"] = "Enter";
})(KEY_CODE || (KEY_CODE = {}));

let ListSectionComponent = class ListSectionComponent {
    constructor(store, _actionSubject, changeDetectorRef, downloadService, playerService, _router) {
        this.store = store;
        this._actionSubject = _actionSubject;
        this.changeDetectorRef = changeDetectorRef;
        this.downloadService = downloadService;
        this.playerService = playerService;
        this._router = _router;
        this.listItemClickEventPropagation = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.hideSwiperButtons = false;
        this.shouldShowAutoDownloadsComponent = false;
        this.currentPlayingTrack = {};
        this.isPlaying = false;
    }
    ngOnChanges(changes) {
        if (changes.section) {
            if (this.likedSongsMap &&
                (this.section.type == 'song' ||
                    this.section.type.indexOf('generic') > -1)) {
                this.updateSectionsLikesState('song');
            }
            else if (this.likedAlbumsMap &&
                (this.section.type == 'album' ||
                    this.section.type.indexOf('generic') > -1)) {
                this.updateSectionsLikesState('album');
            }
            if (this.unfilteredSection && this.section.data.length > this.unfilteredSection.data.length) {
                this.unfilteredSection = JSON.parse(JSON.stringify(this.section));
            }
            this.listItemsMaxNum = this.fromSearchEdgeContainer ? 6 : (this.section.initialNumItems || this.section.data.length);
        }
    }
    loadMoreQueue() {
        if (this.section.type === 'queue' && this.infiniteScrollLimit < this.section.data.length) {
            this.infiniteScrollLimit = this.infiniteScrollLimit + 20;
            this.changeDetectorRef.detectChanges();
        }
    }
    ngOnInit() {
        this.unfilteredSection = JSON.parse(JSON.stringify(this.section));
        this.isAlbumView = this.collectionMeta && this.collectionMeta.list_type && this.collectionMeta.list_type === 'album';
        if (!this.fromSearch) {
            this.trickBrowserToSpeedUpRouting();
        }
        if (this.collectionMeta
            && this.collectionMeta.list_type === 'playlist'
            && this.section.playmode === 'list'
            && this.section.type !== 'genericitem'
            && this.unfilteredSection.data
            && this.unfilteredSection.data.length < 200) {
            this.grabPlaylistVibes();
        }
        else {
            this.vibesLookup = {};
        }
        this.playerInitializationSubscription = this.playerService.initializationObservable.subscribe(value => {
            this.initializePlayerSubscriptions();
        });
        this.initializeLikesSubscriptions();
        this.initializePlayerSubscriptions();
        this.handleAutoDownloadsComponentVisibility();
    }
    trickBrowserToSpeedUpRouting() {
        //This weird function tricks the browser into thinking it only has two render 15 items
        //This makes pages with long lists open faster => faster time to interactive
        let originalSectionInitialNumItems = this.listItemsMaxNum;
        this.listItemsMaxNum = 15;
        setTimeout(() => {
            this.listItemsMaxNum = originalSectionInitialNumItems;
        });
    }
    initCarousel() {
        const config = {
            direction: 'horizontal',
            slidesPerView: 'auto',
            //slidesPerGroup: this.initialNumItems,
            //watchOverflow: true,
            navigation: {
                nextEl: this.next.nativeElement,
                prevEl: this.prev.nativeElement
            },
            simulateTouch: false,
            updateOnImagesReady: true,
        };
        this.swiper = new swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_11__(this.carouselContainer.nativeElement, config);
        setTimeout(() => {
            this.hideSwiperButtons = this.swiper.isBeginning && this.swiper.isEnd;
        });
    }
    handleAutoDownloadsComponentVisibility() {
        const isDesktop = !!window['desktopClient'];
        this.shouldShowAutoDownloadsComponent = isDesktop
            && this.collectionMeta
            && this.collectionMeta.PlaylistName === _enums_special_playlist_names_enum__WEBPACK_IMPORTED_MODULE_9__["SPECIAL_PLAYLIST_NAMES"].DOWNLOADS;
    }
    initializePlayerSubscriptions() {
        if (this.playerService.angPlayer) {
            this.engineCurrentTrackSubscription = this.playerService.angPlayer.currentTrack$.subscribe(data => {
                if (!data) {
                    return;
                }
                this.currentPlayingTrack = data;
                this.updateSectionsPlayingSong(this.isPlaying, this.currentPlayingTrack);
            });
            this.enginePlayStateSubscription = this.playerService.angPlayer.playstate$.subscribe(data => {
                this.isPlaying = data;
                this.updateSectionsPlayingSong(this.isPlaying, this.currentPlayingTrack);
            });
            if (this.section.type === 'queue') {
                this.engineQueueSubscription = this.playerService.angPlayer.queue$.subscribe(data => {
                    if (!data) {
                        return;
                    }
                    setTimeout(() => this.updateSectionsPlayingSong(this.isPlaying, this.currentPlayingTrack));
                });
            }
        }
    }
    updateSectionsPlayingSong(isPlaying, currentTrack) {
        this.section = Object.assign({}, this.section, { data: this.section.data.map(song => {
                return Object.assign({}, song, { isPlaying: isPlaying && currentTrack.id === song.id, isCurrentTrack: currentTrack.id === song.id });
            }) });
        this.changeDetectorRef.detectChanges();
    }
    initializeLikesSubscriptions() {
        if (this.section.type == 'song' ||
            this.section.type.indexOf('generic') > -1) {
            this.likedSongsSubscription = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__["getLikedSongsHashed"]))
                .subscribe(data => {
                if (data) {
                    this.likedSongsMap = data;
                    this.updateSectionsLikesState('song');
                }
            });
            if (!!window['desktopClient']) {
                this.downloadsListSubscription = this.downloadService.desktopDownloads$.subscribe(response => {
                    this.handleDownloadChanges();
                });
                this.downloadQueueSubscription = this.downloadService.downloadQueue$.subscribe(response => {
                    this.handleDownloadChanges();
                });
                this.downloadProgressSubscription = this.downloadService.downloadProgress$.subscribe(response => {
                    this.handleDownloadProgressChanges(response);
                });
            }
        }
        if (this.section.type == 'album' ||
            this.section.type.indexOf('generic') > -1) {
            this.likedAlbumsSubscription = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__["getLikedAlbumsHashed"]))
                .subscribe(data => {
                if (data) {
                    this.likedAlbumsMap = data;
                    this.updateSectionsLikesState('album');
                }
            });
        }
    }
    progagateListItemClickEvent(e) {
        const args = Object.assign({}, e, { section: this.section });
        this.listItemClickEventPropagation.emit(args);
    }
    trackByFn(i, item) {
        if (!item) {
            return null;
        }
        return item.id;
    }
    grabPlaylistVibes() {
        // Grabs playlist items' song ids to be used in calling GETsongtags
        let playlistItemsIDs = this.section.data.map(playlistItem => playlistItem.id);
        playlistItemsIDs =
            playlistItemsIDs.length > 300
                ? playlistItemsIDs.slice(0, 300)
                : playlistItemsIDs;
        // Starts a chain of actions that calls GETsongtags first, then uses the received song tags
        // to call GETtaginfo which gets us the titles of the tags
        this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__["GetSongTags"]({ playlistItemsIDs: playlistItemsIDs }));
        this.actionSubjectSub$ = this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__["CollectionActionTypes"].GetVibesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe((res) => {
            const payload = res.payload;
            //On success, we use the grabbed data to generate a look up table which will
            //be used to filter which songs are displayed/played in the queue
            const numberOfVibes = payload.flattenedSongTags.length;
            if (numberOfVibes > 2) {
                this.generateVibesLookup({
                    section: this.section.data,
                    unflattenedSongTags: payload.unflattenedSongTags,
                    flattenedSongTags: payload.flattenedSongTags,
                    tagInfo: payload.res
                });
            }
            else {
                this.vibesLookup = {};
            }
        });
        this.changeDetectorRef.detectChanges();
    }
    filterByVibe(vibe) {
        if (this.selectedVibe === vibe) {
            this.selectedVibe = '';
            this.section.data = this.vibesLookup['all'].section;
        }
        else {
            this.selectedVibe = vibe;
            this.section.data = this.vibesLookup[vibe].section;
        }
        this.section.data = JSON.parse(JSON.stringify(this.section.data));
        this.collection = JSON.parse(JSON.stringify(this.collection));
        this.collection[1].data = this.section.data;
        this.changeDetectorRef.detectChanges();
    }
    filterVibesBySectionSize(vibesLookup) {
        return Object.keys(vibesLookup).sort((vibeA, vibeB) => {
            if (vibesLookup[vibeA].section.length > vibesLookup[vibeB].section.length) {
                return -1;
            }
            if (vibesLookup[vibeA].section.length < vibesLookup[vibeB].section.length) {
                return 1;
            }
            return 0;
        });
        this.changeDetectorRef.detectChanges();
    }
    generateVibesLookup({ section, unflattenedSongTags, flattenedSongTags, tagInfo }) {
        /*
          This function uses all the data we have to generate a lookup table that will be used in the filtering
    
          Inputs:
          - section: The section data we originally have for the playlist
          - unflattenedSongTags: An object that maps every song id to an array containing the ids of the vibe tags that correspond to it
          - flattenedSongTags: An array containing the individual and unique tag ids
          - tagInfo: The name of every vibe
    
          Output:
          - vibesLookup: An object that maps tag names to sections filtered based on having songs that correspond to that tag
        */
        this.vibesLookup = {};
        this.vibesLookup['all'] = {
            section: section,
            name: 'all'
        };
        // tslint:disable-next-line: forin
        for (const tag in flattenedSongTags) {
            this.vibesLookup[flattenedSongTags[tag]] = {
                section: section.filter((song, idx) => {
                    return (unflattenedSongTags[song.id] &&
                        unflattenedSongTags[song.id].indexOf(flattenedSongTags[tag]) > -1);
                }),
                name: tagInfo[flattenedSongTags[tag]]
            };
        }
        setTimeout(() => {
            this.initCarousel();
        });
        this.changeDetectorRef.detectChanges();
    }
    updateSectionsLikesState(type) {
        if (this.section.type.indexOf('generic') > -1) {
            this.section = Object.assign({}, this.section, { data: this.section.data.map(item => {
                    if (item.generictype === 'song' && type === 'song') {
                        return Object.assign({}, item, { liked: this.likedSongsMap[item.id] });
                    }
                    else if (item.generictype === 'album' && type === 'album') {
                        return Object.assign({}, item, { liked: this.likedAlbumsMap[item.id] });
                    }
                    return item;
                }) });
        }
        else {
            const correspondingLikesMap = this.section.type === 'song' ? this.likedSongsMap : this.likedAlbumsMap;
            this.section = Object.assign({}, this.section, { data: this.section.data.map(song => {
                    return Object.assign({}, song, { liked: correspondingLikesMap[song.id] });
                }) });
        }
        this.changeDetectorRef.detectChanges();
    }
    handleDownloadChanges() {
        this.section = Object.assign({}, this.section, { data: this.section.data.map(item => {
                const newItem = Object.assign({}, item, { isDownloaded: this.downloadService.isSongDownloaded(item), isCurrentlyDownloading: this.downloadService.isSongCurrentlyDownloading(item), isInDownloadQueue: this.downloadService.isSongInDownloadQueue(item) });
                return newItem;
            }) });
        this.changeDetectorRef.detectChanges();
    }
    handleDownloadProgressChanges(response) {
        this.section = Object.assign({}, this.section, { data: this.section.data.map(item => {
                const newItem = Object.assign({}, item, { downloadProgress: item.id === response.songId ? response.metrics.percentage : 0 });
                return newItem;
            }) });
        this.changeDetectorRef.detectChanges();
    }
    ngOnDestroy() {
        if (this.actionSubjectSub$) {
            this.actionSubjectSub$.unsubscribe();
        }
        if (this.likedSongsSubscription) {
            this.likedSongsSubscription.unsubscribe();
        }
        if (this.likedAlbumsSubscription) {
            this.likedAlbumsSubscription.unsubscribe();
        }
        if (this.currentTrackSubscription) {
            this.currentTrackSubscription.unsubscribe();
        }
        if (this.downloadsListSubscription) {
            this.downloadsListSubscription.unsubscribe();
        }
        if (this.downloadQueueSubscription) {
            this.downloadQueueSubscription.unsubscribe();
        }
        if (this.downloadProgressSubscription) {
            this.downloadProgressSubscription.unsubscribe();
        }
        if (this.engineCurrentTrackSubscription) {
            this.engineCurrentTrackSubscription.unsubscribe();
        }
        if (this.enginePlayStateSubscription) {
            this.enginePlayStateSubscription.unsubscribe();
        }
        if (this.engineQueueSubscription) {
            this.engineQueueSubscription.unsubscribe();
        }
        if (this.playerInitializationSubscription) {
            this.playerInitializationSubscription.unsubscribe();
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListSectionComponent.prototype, "section", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListSectionComponent.prototype, "collection", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListSectionComponent.prototype, "collectionMeta", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ListSectionComponent.prototype, "fromSearch", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ListSectionComponent.prototype, "isSearchActiveTabSong", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ListSectionComponent.prototype, "fromSearchEdgeContainer", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ListSectionComponent.prototype, "infiniteScrollLimit", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], ListSectionComponent.prototype, "listItemClickEventPropagation", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('carouselContainer', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], ListSectionComponent.prototype, "carouselContainer", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('prev', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], ListSectionComponent.prototype, "prev", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('next', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], ListSectionComponent.prototype, "next", void 0);
ListSectionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-list-section',
        template: __webpack_require__(/*! raw-loader!./list-section.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/list-section/list-section.component.html"),
        styles: [__webpack_require__(/*! ./list-section.component.scss */ "./src/app/core/components/new-section-builder/list-section/list-section.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
        _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_7__["DesktopDownloadService"],
        _core_modules_player_player_service__WEBPACK_IMPORTED_MODULE_8__["PlayerService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"]])
], ListSectionComponent);



/***/ }),

/***/ "./src/app/core/components/new-section-builder/new-carousel/new-carousel.component.scss":
/*!**********************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/new-carousel/new-carousel.component.scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n:host.bigbanner {\n  margin-top: 2em;\n  display: block;\n}\n:host .swiper-button-next,\n:host .swiper-button-prev {\n  border-radius: 50%;\n  height: 2rem;\n  width: 2rem;\n  cursor: pointer;\n  box-shadow: var(--gray-shadow);\n  background: var(--arrow-background);\n  border: 0.4px solid var(--arrow-border);\n  padding: 0.25em 0.6em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  font-family: var(--font-main-latin);\n}\n:host .swiper-button-prev {\n  -webkit-transform: translateX(-39%);\n      -ms-transform: translateX(-39%);\n          transform: translateX(-39%);\n  position: relative;\n  z-index: 1;\n}\n:host .translate-y-1rem-left {\n  -webkit-transform: translateY(-0.8rem) translateX(-39%);\n      -ms-transform: translateY(-0.8rem) translateX(-39%);\n          transform: translateY(-0.8rem) translateX(-39%);\n}\n:host .translate-y-1rem-right {\n  -webkit-transform: translateY(-0.8rem);\n      -ms-transform: translateY(-0.8rem);\n          transform: translateY(-0.8rem);\n}\n:host .swiper-slide .collection-item:not(:last-child) {\n  margin-right: 1.6rem;\n}\n:host .swiper-button-next {\n  margin-left: -1.6rem;\n  position: relative;\n  z-index: 1;\n}\n:host .carousel-btn-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  width: 0;\n  z-index: 5;\n}\n:host .swiper-slide {\n  -ms-flex-negative: 0;\n      flex-shrink: 0;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n}\n:host .show-more {\n  width: 100%;\n  background: var(--sidebar-background);\n  padding-bottom: 100%;\n  border-radius: 11px;\n  position: relative;\n  cursor: pointer;\n}\n:host .show-more .show-more-alltitle {\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  color: #707070;\n}\n:host .show-more .show-more-alltitle .alltitle-arrow {\n  position: relative;\n  vertical-align: middle;\n  margin: 0.3em 0.2em 0 0.2em;\n  font-size: 1em;\n  -webkit-transition: margin 100ms ease-in;\n  transition: margin 100ms ease-in;\n}\n:host .show-more .show-more-alltitle .alltitle-arrow:after {\n  display: inline-block;\n  content: \"〉\";\n  font-weight: bolder;\n}\n:host .arrow {\n  fill: var(--text-color);\n  font-size: 1.4em;\n  margin-bottom: 0.1em;\n}\n:host .arrow.left {\n  margin-right: 0.1em;\n}\n:host .arrow.right {\n  margin-left: 0.1em;\n}\n:host .arrow svg {\n  width: 1em;\n  height: 1em;\n}\n.arrow:lang(ar) svg {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n.translate-y-1rem-left:lang(ar) {\n  -webkit-transform: translateY(-0.8rem) translateX(1em);\n      -ms-transform: translateY(-0.8rem) translateX(1em);\n          transform: translateY(-0.8rem) translateX(1em);\n}\n.translate-y-1rem-right:lang(ar) {\n  -webkit-transform: translateY(-0.8rem) translateX(1em);\n      -ms-transform: translateY(-0.8rem) translateX(1em);\n          transform: translateY(-0.8rem) translateX(1em);\n}"

/***/ }),

/***/ "./src/app/core/components/new-section-builder/new-carousel/new-carousel.component.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/new-carousel/new-carousel.component.ts ***!
  \********************************************************************************************/
/*! exports provided: NewCarouselComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewCarouselComponent", function() { return NewCarouselComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swiper/dist/js/swiper.min.js */ "./node_modules/swiper/dist/js/swiper.min.js");
/* harmony import */ var swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");




let NewCarouselComponent = class NewCarouselComponent {
    constructor(changeDetector, elRef, platformId) {
        this.changeDetector = changeDetector;
        this.elRef = elRef;
        this.platformId = platformId;
        this.carouselInitialized = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.isSwiperBeginning = false;
        this.isSwiperEnd = false;
        this.swiperInitialized = false;
        this.hasMoreData = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.cardItemClickEventPropagation = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            this.isBrowser = true;
        }
    }
    ngAfterViewInit() {
        this.initCarousel();
    }
    progagateCardItemClickEvent(e) {
        let index = 0;
        this.section.data.forEach((element, idx) => {
            if (element.id === e.id) {
                index = idx;
            }
        });
        let args = Object.assign({}, e, { index, section: this.section });
        this.cardItemClickEventPropagation.emit(args);
    }
    emitHasMoreData() {
        this.hasMoreData.emit(this.section);
    }
    ngOnChanges(changes) {
        if (changes.initialNumItems) {
            this.setInitialNumItems();
        }
        if (this.swiper) {
            this.initCarousel();
        }
    }
    setInitialNumItems() {
        if (this.section.displaytype !== 'card_carousel' &&
            this.section.type !== 'video' &&
            this.section.type !== 'bigbanner') {
            this.initialNumItems++;
        }
        else if (this.section.type === 'bigbanner') {
            this.initialNumItems--;
        }
    }
    initCarousel() {
        if (!this.isBrowser) {
            return;
        }
        const config = {
            spaceBetween: 10,
            direction: 'horizontal',
            slidesPerView: this.initialNumItems,
            slidesPerGroup: this.initialNumItems,
            //watchOverflow: true,
            navigation: {
                nextEl: this.next.nativeElement,
                prevEl: this.prev.nativeElement
            },
            simulateTouch: false,
            updateOnImagesReady: true,
            on: {
                init: () => {
                    this.emitCarouselInitializedEvent();
                }
            }
        };
        this.swiper = new swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_2__(this.carouselContainer.nativeElement, config);
        this.swiper.on('resize', () => {
            this.updateArrowState();
        });
        //I have no idea why, but I need to dispatch an initial resize event so the
        //initial arrow state is displayed like it should
        setTimeout(() => window.dispatchEvent(new Event('resize')));
    }
    emitCarouselInitializedEvent() {
        setTimeout(() => {
            this.carouselInitialized.emit(true);
        });
    }
    trackByFn(index, item) {
        return index;
    }
    /*calculateCarouselInitialHeight() {
      const bodyWidth = this.elRef.nativeElement.ownerDocument.body.offsetWidth;
      return ((bodyWidth-384)/this.initialNumItems).toString() + "px";
    }*/
    updateArrowState() {
        setTimeout(() => {
            this.isSwiperBeginning = this.swiper.isBeginning;
            this.isSwiperEnd = this.swiper.isEnd;
            window.dispatchEvent(new Event('scroll'));
            this.swiperInitialized = true;
            if (!this.changeDetector['destroyed']) {
                this.changeDetector.detectChanges();
            }
            setTimeout(() => {
                window.dispatchEvent(new MouseEvent('scroll'));
            }, 100);
        });
    }
    ngOnDestroy() {
        this.changeDetector.detach();
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewCarouselComponent.prototype, "section", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewCarouselComponent.prototype, "initialNumItems", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewCarouselComponent.prototype, "carouselInitialized", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('carouselContainer', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], NewCarouselComponent.prototype, "carouselContainer", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('prev', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], NewCarouselComponent.prototype, "prev", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('next', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], NewCarouselComponent.prototype, "next", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewCarouselComponent.prototype, "hasMoreData", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], NewCarouselComponent.prototype, "cardItemClickEventPropagation", void 0);
NewCarouselComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-new-carousel',
        template: __webpack_require__(/*! raw-loader!./new-carousel.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/new-carousel/new-carousel.component.html"),
        styles: [__webpack_require__(/*! ./new-carousel.component.scss */ "./src/app/core/components/new-section-builder/new-carousel/new-carousel.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"],
        Object])
], NewCarouselComponent);



/***/ }),

/***/ "./src/app/core/components/new-section-builder/new-section-builder.component.scss":
/*!****************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/new-section-builder.component.scss ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n@-webkit-keyframes hoverbounce {\n  0% {\n    -webkit-transform: translateX(0px);\n    transform: translateX(0px);\n  }\n  50% {\n    -webkit-transform: translateX(6px);\n    transform: translateX(6px);\n  }\n  100% {\n    -webkit-transform: translateX(0px);\n    transform: translateX(0px);\n  }\n}\n@keyframes hoverbounce {\n  0% {\n    -webkit-transform: translateX(0px);\n    transform: translateX(0px);\n  }\n  50% {\n    -webkit-transform: translateX(6px);\n    transform: translateX(6px);\n  }\n  100% {\n    -webkit-transform: translateX(0px);\n    transform: translateX(0px);\n  }\n}\n.hoverbounce, :host h2.sectionlink .section-deeplink-arrow:after {\n  -webkit-animation-duration: 400ms;\n  animation-duration: 400ms;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-animation-timing-function: ease-out;\n  animation-timing-function: ease-in-out;\n  animation-iteration-count: 1;\n  -webkit-animation-iteration-count: 1;\n}\n.dohoverbounce, :host h2.sectionlink a:hover .section-deeplink-arrow:after {\n  -webkit-animation-name: hoverbounce;\n          animation-name: hoverbounce;\n  -moz-animation-name: hoverbounce;\n}\n@-webkit-keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n:host .text-template {\n  background-color: rgba(0, 0, 0, 0.1);\n  padding: 2rem;\n  border-radius: 0.25rem;\n}\n:host .swiper-slide {\n  -ms-flex-negative: 0;\n      flex-shrink: 0;\n}\n:host .section-top-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-flow: row;\n          flex-flow: row;\n  -webkit-box-align: baseline;\n      -ms-flex-align: baseline;\n          align-items: baseline;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .section-wrapper {\n  -webkit-animation-name: fadeIn;\n  animation-name: fadeIn;\n  -webkit-animation-iteration-count: 1;\n  animation-iteration-count: 1;\n  -webkit-animation-duration: 0.3s;\n  animation-duration: 0.3s;\n  -webkit-animation-delay: 0;\n  animation-delay: 0;\n  -webkit-animation-timing-function: ease;\n  animation-timing-function: ease;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n}\n:host .search {\n  position: absolute;\n  top: 1.85em;\n  right: 0;\n}\n:host .arrow {\n  fill: #707070;\n  font-size: 1em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  padding-top: 1px;\n  border: solid 1px var(--sidebar-background);\n  margin-top: 0.4em;\n  padding: 0.8em 0.8em;\n  border-radius: 5px;\n  cursor: pointer;\n}\n:host .arrow.left {\n  margin-left: 5px;\n  margin-right: 2.5px;\n}\n:host .arrow.right svg {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n:host .arrow svg {\n  width: 1em;\n  height: 1em;\n}\n:host .arrow:lang(ar).left {\n  margin-right: 5px;\n  margin-left: 2.5px;\n}\n:host .arrow:lang(ar).left svg {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n:host .arrow:lang(ar).right svg {\n  -webkit-transform: rotate(0deg);\n      -ms-transform: rotate(0deg);\n          transform: rotate(0deg);\n}\n:host .section-tabs {\n  overflow: hidden;\n}\n:host .section-tabs ul {\n  padding-left: 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .section-tabs ul li {\n  margin: auto;\n  text-align: center;\n  font-size: 0.9em;\n  display: inline-block;\n  vertical-align: middle;\n  /*&:after {\n    content: \"-\";\n    display: inline-block;\n    vertical-align: middle;\n    margin: 0 0.6em;\n  }*/\n}\n:host .section-tabs ul li a {\n  color: #707070;\n  font-size: 1.1em;\n  margin-top: 0.5em;\n  padding: 0.6em 1em;\n  background: var(--sidebar-background);\n  border-radius: 0.3em;\n  display: block;\n}\n:host .section-tabs ul li a:hover, :host .section-tabs ul li a.active-tab {\n  text-decoration: none;\n}\n:host .section-tabs ul li a.active-tab {\n  font-weight: 600;\n  background: var(--active-tab-background);\n  color: var(--active-tab-color);\n  border-radius: 0.3em;\n}\n:host .section-tabs ul li:last-child::after {\n  display: none;\n}\n:host h2 {\n  font-size: 1.8em;\n  margin: 1em 0 0.5em 0;\n  padding: 0;\n  color: var(--title);\n  font-weight: 500;\n  pointer-events: none;\n}\n:host h2 a {\n  color: inherit;\n  text-decoration: none;\n  cursor: initial;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  overflow: hidden;\n}\n:host h2.sectionlink {\n  pointer-events: all;\n}\n:host h2.sectionlink .section-deeplink-arrow {\n  position: relative;\n  vertical-align: middle;\n  margin: 0.3em 0.2em 0 0.2em;\n  font-size: 0.7em;\n  -webkit-transition: margin 100ms ease-in;\n  transition: margin 100ms ease-in;\n}\n:host h2.sectionlink .section-deeplink-arrow:after {\n  display: inline-block;\n  content: \"〉\";\n  font-weight: bolder;\n}\n:host h2.sectionlink a {\n  cursor: pointer;\n  display: inline-block;\n  font-weight: bold;\n}\n:host h2.sectionlink a:hover {\n  color: var(--brand-purple);\n}\n:host .justify-flex-end {\n  -webkit-box-pack: end !important;\n      -ms-flex-pack: end !important;\n          justify-content: flex-end !important;\n}\n:host .more-button:hover {\n  color: var(--text-color) !important;\n  opacity: 1 !important;\n}\n:host .more-button:hover:before {\n  background: var(--text-color) !important;\n  opacity: 1 !important;\n}\n:host .more-button:hover:after {\n  background: var(--text-color) !important;\n  opacity: 1 !important;\n}\n:host .more-button {\n  color: #727272 !important;\n}\n:host .more-button:before {\n  background: #727272 !important;\n}\n:host .more-button:after {\n  background: #727272 !important;\n}\nhtml[lang=ar] :host .sectionlink a {\n  direction: rtl;\n}\nhtml[lang=ar] :host .sectionlink a .section-deeplink-arrow:after {\n  right: 0.5em;\n  left: initial;\n}\nhtml[lang=ar] :host .search {\n  left: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/new-section-builder/new-section-builder.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/new-section-builder.component.ts ***!
  \**************************************************************************************/
/*! exports provided: breakPoints, NewSectionBuilderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakPoints", function() { return breakPoints; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewSectionBuilderComponent", function() { return NewSectionBuilderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_explore_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/explore.actions */ "./src/app/core/redux/actions/explore.actions.ts");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../modules/player/actions/media.engine.actions */ "./src/app/core/modules/player/actions/media.engine.actions.ts");
/* harmony import */ var swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! swiper/dist/js/swiper.min.js */ "./node_modules/swiper/dist/js/swiper.min.js");
/* harmony import */ var swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _modules_player_player_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../modules/player/player.service */ "./src/app/core/modules/player/player.service.ts");












var breakPoints;
(function (breakPoints) {
    breakPoints["xs"] = "1000";
    breakPoints["sm"] = "1050";
    breakPoints["md"] = "1300";
    breakPoints["lg"] = "1800";
})(breakPoints || (breakPoints = {}));
let NewSectionBuilderComponent = class NewSectionBuilderComponent {
    constructor(store, activatedRoute, location, actionsSubject, elRef, changeDetectorRef, platformId, router, _playerServer) {
        this.store = store;
        this.activatedRoute = activatedRoute;
        this.location = location;
        this.actionsSubject = actionsSubject;
        this.elRef = elRef;
        this.changeDetectorRef = changeDetectorRef;
        this.platformId = platformId;
        this.router = router;
        this._playerServer = _playerServer;
        this.carouselInitialized = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.searchPaginationEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.displayTypeLookup = {
            list: 'list',
            bigrow: 'list',
            carousel: 'carousel',
            card_carousel: 'carousel',
            small_button: 'card',
            widenew: 'card',
            card: 'card',
            bigimages: 'card',
            private_profile: 'card',
            question: 'card',
            progress_card: 'progress_card'
        };
        this.sectionsTabs = [];
        this.shouldShowTopContainer = false;
        this.loadingSections = false;
        this.initialNumItems = 5;
        this.searchInputLayout = 'full';
        this.sectionBackup = new Map();
        this.page = 0;
        this.artistSearchActive = false;
        this.artistSearchLoading = false;
        this.hideSwiperButtons = false;
        this.swiperInitialized = false;
        this.isPodcastTagsSection = false;
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_6__["isPlatformBrowser"])(this.platformId)) {
            if (window.location.href.indexOf('/tag/127') >= 0) {
                this.isPodcastTagsSection = true;
            }
        }
    }
    onResize(firstCall = false) {
        let timeoutValue = firstCall ? 0 : 300;
        clearTimeout(this.resizeDebounceTimeout);
        this.resizeDebounceTimeout = setTimeout(() => {
            const bodyWidth = this.elRef.nativeElement.ownerDocument.body.offsetWidth;
            if (bodyWidth >= breakPoints.xs && bodyWidth < breakPoints.sm) {
                this.initialNumItems = 2;
            }
            else if (bodyWidth >= breakPoints.sm && bodyWidth < breakPoints.md) {
                this.initialNumItems = this.isView ? 2 : 3;
            }
            else if (bodyWidth >= breakPoints.md && bodyWidth < breakPoints.lg) {
                this.initialNumItems = this.isView ? 3 : 4;
            }
            else if (bodyWidth >= breakPoints.lg) {
                this.initialNumItems = 5;
            }
            this.changeDetectorRef.detectChanges();
        }, timeoutValue);
    }
    propagateCarouselInitializedEvent() {
        this.carouselInitialized.emit(true);
    }
    initCarousel() {
        const config = {
            spaceBetween: 10,
            direction: 'horizontal',
            slidesPerView: 'auto',
            //slidesPerGroup: this.initialNumItems,
            //watchOverflow: true,
            navigation: {
                nextEl: this.next.nativeElement,
                prevEl: this.prev.nativeElement
            },
            simulateTouch: false,
            updateOnImagesReady: true,
        };
        this.swiper = new swiper_dist_js_swiper_min_js__WEBPACK_IMPORTED_MODULE_10__(this.carouselContainer.nativeElement, config);
        setTimeout(() => {
            this.hideSwiperButtons = this.swiper.isBeginning && this.swiper.isEnd;
        });
    }
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_6__["isPlatformBrowser"])(this.platformId)) {
            this.onResize(true);
            if (this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_8__["CollectionTypes"].ARTIST) {
                this.initializeArtistPageListeners();
            }
            this.handleTopSectionVisibility();
            this.handleSearchInputLayout();
            this.routerSubscription = this.router.events.subscribe(val => {
                if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_5__["NavigationStart"]) {
                    this.clearLoadMoreTimeouts();
                }
            });
            if (this.type === 'artist') {
                this.initCarousel();
            }
        }
    }
    handleTopSectionVisibility() {
        const topSectionPages = ['artist', 'playlist', 'song', 'album'];
        this.shouldShowTopContainer = topSectionPages.indexOf(this.type) > -1;
    }
    handleSearchInputLayout() {
        this.searchInputLayout = 'compact';
    }
    filterSectionsByActiveSectionId() {
        if (this.activeSectionId) {
            this.sections = this.sections.map(section => {
                let newSection = Object.assign({}, section, { hidden: section.sectionid != this.activeSectionId });
                // When switching to album tab, we should switch the section to displaytype list
                if (newSection.type == 'album' && !newSection.hidden && newSection.group != 'series_similar') {
                    this.sectionBackup.set(section.sectionid, section);
                    newSection.displaytype = 'list';
                }
                return newSection;
            });
            this.changeDetectorRef.detectChanges();
        }
    }
    changeActiveSection(activeTab) {
        this.activeSectionId = activeTab.id;
        this.location.go(`/artist/${this.collectionMeta.id}/${activeTab.id}`);
        this.filterSectionsByActiveSectionId();
    }
    removeSectionFilter() {
        this.activeSectionId = null;
        this.location.go(`/artist/${this.collectionMeta.id}`);
        this.sections = this.sections.map(section => {
            let newSection = section;
            if (this.sectionBackup.get(section.sectionid)) {
                newSection = this.sectionBackup.get(section.sectionid);
            }
            return Object.assign({}, newSection, { hidden: false });
        });
        this.collectionMeta = Object.assign({}, this.collectionMeta, { page: 0 });
        this.page = 0;
        this.sectionBackup.clear();
        this.changeDetectorRef.detectChanges();
    }
    initializeArtistPageListeners() {
        if (this.type !== 'artist') {
            return;
        }
        this.sectionsTabs = this.sections.map(section => {
            return {
                id: section.sectionid,
                title: section.title
            };
        });
        this.sectionsTabs = this.sectionsTabs.filter(tab => tab.title);
        this.activatedRouteSubscription = this.activatedRoute.params.subscribe(params => {
            if (params['sectionId']) {
                this.activeSectionId = params.sectionId;
                const sectionIdExists = this.sectionsTabs.find((sectionTab) => sectionTab.id === this.activeSectionId);
                if (sectionIdExists) {
                    this.filterSectionsByActiveSectionId();
                }
                else {
                    // TODO: pagiante page, the section id might be in a subsequent part of the API response
                    this.removeSectionFilter();
                }
            }
        });
        this.changeDetectorRef.detectChanges();
    }
    onSearchInput(event) {
        this.searchTerm = event;
        if (this.type === 'artist') {
            this.artistSearchActive = true;
            this.artistSearchLoading = true;
            if (!this.untouchedSections) {
                this.untouchedSections = this.sections;
            }
            this.artistFilterSubscription = this.actionsSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_7__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_4__["CollectionActionTypes"].GetFilteredArtistSuccess))
                .subscribe(res => {
                const payload = res.payload;
                if (this.activeSectionId) {
                    this.removeSectionFilter();
                }
                this.sections = payload.sections;
                // TODO: remove when artist page get a ispodcast property
                this.sections = this.sections.map(s => (Object.assign({}, s, { displaytype: s.data[0] && s.data[0].is_podcast ? 'progress_card' : s.displaytype })));
                this.artistSearchLoading = false;
                this.changeDetectorRef.detectChanges();
            });
            this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_4__["SearchArtist"]({
                artistId: this.collectionMeta.id,
                query: this.searchTerm
            }));
            if (this.searchTerm.length === 0) {
                this.artistSearchActive = false;
                this.artistSearchLoading = false;
                this.sections = this.untouchedSections;
                setTimeout(() => {
                    this.initCarousel();
                }, 100);
                this.artistFilterSubscription.unsubscribe();
            }
        }
        else {
            if (this.searchTerm.length === 0) {
                this.sections = this.untouchedSections;
            }
            else {
                this.sections = this.sections.map(section => {
                    const originalSection = this.sectionBackup.get(section.sectionid) || section;
                    return Object.assign({}, originalSection, { data: originalSection.data.filter(item => {
                            const titleMatch = item.title
                                ? item.title
                                    .toUpperCase()
                                    .includes(this.searchTerm.toUpperCase())
                                : false;
                            const albumMatch = item.album
                                ? item.album
                                    .toUpperCase()
                                    .includes(this.searchTerm.toUpperCase())
                                : false;
                            const artistMatch = item.artist
                                ? item.artist
                                    .toUpperCase()
                                    .includes(this.searchTerm.toUpperCase())
                                : false;
                            const yearMatch = item.year
                                ? item.year
                                    .toUpperCase()
                                    .includes(this.searchTerm.toUpperCase())
                                : false;
                            const keywordMatch = item.keywords
                                ? item.keywords
                                    .join()
                                    .toUpperCase()
                                    .includes(this.searchTerm.toUpperCase())
                                : false;
                            return titleMatch || albumMatch || artistMatch || yearMatch || keywordMatch;
                        }) });
                });
            }
        }
        this.changeDetectorRef.detectChanges();
    }
    trackByFn(index, section) {
        if (section) {
            return section.sectionid;
        }
        else {
            return index;
        }
    }
    loadMoreViewSections() {
        // tslint:disable-next-line:no-unused-expression
        if (this.collectionMeta && !this.activeSectionId) {
            let { page } = this.collectionMeta;
            const { moreSections } = this.collectionMeta;
            if (moreSections > 0 && this.collectionMeta.page !== undefined && !this.isLikesOrDownloads) {
                this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_4__["GetPaginatedViewPage"]({
                    page: (++page).toString(),
                    type: this.type,
                    id: this.collectionMeta.id
                }));
            }
        }
    }
    loadMoreExploreSections() {
        if (this.collectionMeta) {
            let { page } = this.collectionMeta;
            const { moreSections } = this.collectionMeta;
            if (moreSections > 0) {
                this.store.dispatch(new _anghami_redux_actions_explore_actions__WEBPACK_IMPORTED_MODULE_3__["GetPaginatedHomePageNew"]({
                    page: (++page).toString()
                }));
            }
        }
    }
    handleListItemClick(e) {
        const collectionMeta = this.collectionMeta || {
            playmode: 'list'
        };
        let section = e.section;
        let index = e.index;
        if (this.sectionBackup.get(section.sectionid)) {
            section = this.sectionBackup.get(section.sectionid);
            index = section.data.findIndex(elem => elem.id === e.id);
        }
        const isVideo = e.item && e.item.videoonly ? true : e.section.type === 'queue' ? this._playerServer.angPlayer.videoOn : e.isVideo;
        const itemType = e.item && (e.item.type || e.item.generictype);
        if ((this.type === 'search' || this.type === 'generic') && itemType !== 'album') {
            this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_9__["PlaySongEngine"]({
                id: e.item.id,
                extras: e.item.extras
            }));
        }
        else if (section.type === 'song' || section.type === 'queue' || itemType === 'song' || e.cardItemType === 'song') {
            this.store.dispatch(new _modules_player_actions_media_engine_actions__WEBPACK_IMPORTED_MODULE_9__["PlayTrackEngine"]({
                queue: Object.assign({}, section, { data: section.data
                        .map(item => {
                        return Object.assign({}, item, { generictype: item.generictype ? item.generictype : section.type });
                    })
                        .filter(item => item.generictype === 'song' || item.generictype === 'video') }),
                list: collectionMeta,
                index: index.toString(),
                isVideo: isVideo
            }));
        }
    }
    ngOnDestroy() {
        if (this.activatedRouteSubscription) {
            this.activatedRouteSubscription.unsubscribe();
        }
        if (this.artistFilterSubscription) {
            this.artistFilterSubscription.unsubscribe();
        }
        if (this.routerSubscription) {
            this.routerSubscription.unsubscribe();
        }
    }
    loadMore(section) {
        if (this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_8__["CollectionTypes"].ARTIST) {
            let sectionToActivate = this.sectionsTabs.find((tab) => tab.id === section.sectionid);
            setTimeout(() => {
                this.changeActiveSection(sectionToActivate);
            }, 250);
        }
        if (section.initialNumItems < section.count) {
            this.sections = this.sections.map(sec => {
                if (sec.sectionid === section.sectionid) {
                    this.sectionBackup.set(sec.sectionid, sec);
                    return Object.assign({}, sec, { initialNumItems: sec.initialNumItems + 200, expanded: true });
                }
                return sec;
            });
            return;
        }
        if (section.type === 'tag') {
            if (this.initialNumItems < section.count) {
                this.sections = this.sections.map(sec => {
                    if (sec.sectionid === section.sectionid) {
                        this.sectionBackup.set(sec.sectionid, sec);
                        return Object.assign({}, sec, { initialNumItems: sec.count, expanded: true });
                    }
                    return sec;
                });
                return;
            }
        }
        if (section.type === 'playlist' && section.displaytype === 'bigimages') {
            if (this.initialNumItems < section.count) {
                this.sections = this.sections.map(sec => {
                    if (sec.sectionid === section.sectionid) {
                        this.sectionBackup.set(sec.sectionid, sec);
                        return Object.assign({}, sec, { initialNumItems: sec.count, expanded: true });
                    }
                    return sec;
                });
                return;
            }
        }
        if (this.fromSearch) {
            this.sendSearchPaginationEvent(section.sectionid);
            return;
        }
        if (!this.collectionMeta) {
            return;
        }
        this.loadingSections = true;
        if (this.page == 0 && !section.expanded) {
            this.sectionBackup.set(section.sectionid, section);
        }
        if (!this.isLikesOrDownloads) {
            this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_4__["GetPaginatedViewPage"]({
                page: (++this.page).toString(),
                type: this.type,
                id: this.collectionMeta.id,
                sectionId: section.sectionid
            }));
        }
        this.changeDetectorRef.detectChanges();
    }
    showLess(section) {
        this.sections = this.sections.map(sec => {
            if (sec.sectionid === section.sectionid) {
                return this.sectionBackup.get(sec.sectionid);
            }
            return sec;
        });
        this.changeDetectorRef.detectChanges();
    }
    sendSearchPaginationEvent(sectionId) {
        this.searchPaginationEvent.emit(sectionId);
    }
    formatQueueData() {
        this.sections[0] = Object.assign({}, this.sections[0], { displaytype: 'list', type: 'queue' });
    }
    checkAndAutoLoadList() {
        const songsSection = this.collectionMeta.sections.find(section => section.displaytype === 'list');
        if (songsSection && songsSection.moreData === 1) {
            this.loadMoreTimeout = setTimeout(() => {
                this.loadMore(songsSection);
            }, 2000);
        }
    }
    clearLoadMoreTimeouts() {
        if (this.loadMoreTimeout) {
            clearTimeout(this.loadMoreTimeout);
        }
        if (this.checkAndAutoLoadListTimeout) {
            clearTimeout(this.checkAndAutoLoadListTimeout);
        }
    }
    ngOnChanges(changes) {
        if (changes.sections) {
            this.searchTerm = '';
            this.untouchedSections = this.sections;
            this.initializeArtistPageListeners();
            this.handleSearchInputLayout();
            this.handleTopSectionVisibility();
            if (this.artistFilterSubscription) {
                this.artistFilterSubscription.unsubscribe();
            }
            this.loadingSections = false;
            this.sectionBackup.clear();
            if (this.untouchedSections) {
                this.untouchedSections.forEach(section => {
                    this.sectionBackup.set(section.sectionid, section);
                });
            }
            if (this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_8__["CollectionTypes"].PLAYLIST) {
                this.checkAndAutoLoadListTimeout = setTimeout(() => {
                    this.checkAndAutoLoadList();
                }, 3000);
            }
            this.filterSectionsByActiveSectionId();
        }
        if (changes.searchTerm && changes.searchTerm.currentValue !== undefined) {
            this.onSearchInput(changes.searchTerm.currentValue);
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewSectionBuilderComponent.prototype, "sections", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], NewSectionBuilderComponent.prototype, "searchTerm", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewSectionBuilderComponent.prototype, "collectionMeta", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewSectionBuilderComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], NewSectionBuilderComponent.prototype, "fromSearch", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], NewSectionBuilderComponent.prototype, "isSearchActiveTabSong", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], NewSectionBuilderComponent.prototype, "fromSearchEdgeContainer", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], NewSectionBuilderComponent.prototype, "isView", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewSectionBuilderComponent.prototype, "infiniteScrollLimit", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewSectionBuilderComponent.prototype, "isLikesOrDownloads", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewSectionBuilderComponent.prototype, "carouselInitialized", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], NewSectionBuilderComponent.prototype, "searchPaginationEvent", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('carouselContainer', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], NewSectionBuilderComponent.prototype, "carouselContainer", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('prev', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], NewSectionBuilderComponent.prototype, "prev", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('next', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], NewSectionBuilderComponent.prototype, "next", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('window:resize', ['$event']),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
], NewSectionBuilderComponent.prototype, "onResize", null);
NewSectionBuilderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-new-section-builder',
        template: __webpack_require__(/*! raw-loader!./new-section-builder.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/new-section-builder/new-section-builder.component.html"),
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
        styles: [__webpack_require__(/*! ./new-section-builder.component.scss */ "./src/app/core/components/new-section-builder/new-section-builder.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](6, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
        _angular_common__WEBPACK_IMPORTED_MODULE_6__["Location"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
        Object,
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
        _modules_player_player_service__WEBPACK_IMPORTED_MODULE_11__["PlayerService"]])
], NewSectionBuilderComponent);



/***/ }),

/***/ "./src/app/core/components/new-section-builder/new-section-builder.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/core/components/new-section-builder/new-section-builder.module.ts ***!
  \***********************************************************************************/
/*! exports provided: NewSectionBuilderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewSectionBuilderModule", function() { return NewSectionBuilderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _context_sheet_new_context_sheet_new_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../context-sheet-new/context-sheet-new.module */ "./src/app/core/components/context-sheet-new/context-sheet-new.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _new_section_builder_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./new-section-builder.component */ "./src/app/core/components/new-section-builder/new-section-builder.component.ts");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _card_section_card_section_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./card-section/card-section.component */ "./src/app/core/components/new-section-builder/card-section/card-section.component.ts");
/* harmony import */ var _list_section_list_section_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./list-section/list-section.component */ "./src/app/core/components/new-section-builder/list-section/list-section.component.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _core_directives_extras_extras_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/directives/extras/extras.module */ "./src/app/core/directives/extras/extras.module.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
/* harmony import */ var _core_components_jsonhp_button_jsonhp_button_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/components/jsonhp-button/jsonhp-button.module */ "./src/app/core/components/jsonhp-button/jsonhp-button.module.ts");
/* harmony import */ var _card_item_card_item_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./card-item/card-item.component */ "./src/app/core/components/new-section-builder/card-item/card-item.component.ts");
/* harmony import */ var _overlay_collection_controls_overlay_collection_controls_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../overlay-collection-controls/overlay-collection-controls.module */ "./src/app/core/components/overlay-collection-controls/overlay-collection-controls.module.ts");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _core_components_equalizer_equalizer_module__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../core/components/equalizer/equalizer.module */ "./src/app/core/components/equalizer/equalizer.module.ts");
/* harmony import */ var _new_carousel_new_carousel_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./new-carousel/new-carousel.component */ "./src/app/core/components/new-section-builder/new-carousel/new-carousel.component.ts");
/* harmony import */ var _search_input_search_input_module__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../search-input/search-input.module */ "./src/app/core/components/search-input/search-input.module.ts");
/* harmony import */ var _empty_search_empty_search_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../empty-search/empty-search.component */ "./src/app/core/components/empty-search/empty-search.component.ts");
/* harmony import */ var _auto_downloads_auto_downloads_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../auto-downloads/auto-downloads.component */ "./src/app/core/components/auto-downloads/auto-downloads.component.ts");
/* harmony import */ var ngx_virtual_scroller__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ngx-virtual-scroller */ "./node_modules/ngx-virtual-scroller/fesm2015/ngx-virtual-scroller.js");
/* harmony import */ var _question_item_question_item_module__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../question-item/question-item.module */ "./src/app/core/components/question-item/question-item.module.ts");
/* harmony import */ var _list_item_list_item_module__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./list-item/list-item.module */ "./src/app/core/components/new-section-builder/list-item/list-item.module.ts");

























let NewSectionBuilderModule = class NewSectionBuilderModule {
};
NewSectionBuilderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [
            _new_section_builder_component__WEBPACK_IMPORTED_MODULE_4__["NewSectionBuilderComponent"],
            _card_section_card_section_component__WEBPACK_IMPORTED_MODULE_7__["CardSectionComponent"],
            _list_section_list_section_component__WEBPACK_IMPORTED_MODULE_8__["ListSectionComponent"],
            _card_item_card_item_component__WEBPACK_IMPORTED_MODULE_14__["CardItemComponent"],
            _new_carousel_new_carousel_component__WEBPACK_IMPORTED_MODULE_18__["NewCarouselComponent"],
            _empty_search_empty_search_component__WEBPACK_IMPORTED_MODULE_20__["EmptySearchComponent"],
            _auto_downloads_auto_downloads_component__WEBPACK_IMPORTED_MODULE_21__["AutoDownloadsComponent"]
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_5__["PipesModule"],
            ngx_virtual_scroller__WEBPACK_IMPORTED_MODULE_22__["VirtualScrollerModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"],
            _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_9__["IconModule"],
            _core_components_jsonhp_button_jsonhp_button_module__WEBPACK_IMPORTED_MODULE_13__["JsonhpButtonModule"],
            _core_directives_extras_extras_module__WEBPACK_IMPORTED_MODULE_10__["ExtrasModule"],
            ng_lazyload_image__WEBPACK_IMPORTED_MODULE_11__["LazyLoadImageModule"],
            _context_sheet_new_context_sheet_new_module__WEBPACK_IMPORTED_MODULE_1__["ContextSheetNewModule"],
            _overlay_collection_controls_overlay_collection_controls_module__WEBPACK_IMPORTED_MODULE_15__["OverlayCollectionControlsModule"],
            _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_16__["LoadingModule"],
            _core_components_equalizer_equalizer_module__WEBPACK_IMPORTED_MODULE_17__["EqualizerModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__["NgbModule"],
            _search_input_search_input_module__WEBPACK_IMPORTED_MODULE_19__["SearchInputModule"],
            _question_item_question_item_module__WEBPACK_IMPORTED_MODULE_23__["QuestionItemModule"],
            _list_item_list_item_module__WEBPACK_IMPORTED_MODULE_24__["ListItemModule"]
        ],
        exports: [_new_section_builder_component__WEBPACK_IMPORTED_MODULE_4__["NewSectionBuilderComponent"]]
    })
], NewSectionBuilderModule);



/***/ }),

/***/ "./src/app/core/components/overlay-collection-controls/overlay-collection-controls.component.scss":
/*!********************************************************************************************************!*\
  !*** ./src/app/core/components/overlay-collection-controls/overlay-collection-controls.component.scss ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".overlay-container {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  z-index: 3;\n}\n.overlay-container > .overlay-content {\n  border-radius: 0.3em;\n  -webkit-transition: 0.2s linear;\n  transition: 0.2s linear;\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  display: none;\n  background: rgba(0, 0, 0, 0.4);\n}\n.overlay-container > .overlay-content > .controls {\n  color: white;\n  text-align: center;\n  width: 100%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: end;\n      -ms-flex-align: end;\n          align-items: flex-end;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  position: absolute;\n  bottom: 1em;\n  left: 0;\n  right: 0;\n  padding: 0;\n  margin: 0;\n}\n.overlay-container > .overlay-content > .controls li {\n  list-style-type: none;\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0 0.3em;\n}\n.overlay-container > .overlay-content > .controls .icon {\n  background: #fff;\n  border-radius: 50%;\n  color: #000;\n  width: 2.5em;\n  height: 2.5em;\n  position: relative;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n  display: block;\n}\n.overlay-container > .overlay-content > .controls .icon svg {\n  position: absolute;\n  -webkit-transform: translate(-50%, -50%);\n      -ms-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  top: 50%;\n  left: 50%;\n}\n.overlay-container > .overlay-content > .controls .icon.play {\n  background: var(--brand-purple);\n  color: #fff;\n}\n.overlay-container > .overlay-content > .controls .icon:hover {\n  -webkit-transform: scale(1.2);\n      -ms-transform: scale(1.2);\n          transform: scale(1.2);\n}\n.overlay-container:hover > .overlay-content, .overlay-container.open > .overlay-content {\n  display: block;\n}\n.overlay-container.artist > .overlay-content {\n  border-radius: 50%;\n}"

/***/ }),

/***/ "./src/app/core/components/overlay-collection-controls/overlay-collection-controls.component.ts":
/*!******************************************************************************************************!*\
  !*** ./src/app/core/components/overlay-collection-controls/overlay-collection-controls.component.ts ***!
  \******************************************************************************************************/
/*! exports provided: OverlayCollectionControlsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OverlayCollectionControlsComponent", function() { return OverlayCollectionControlsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");




let OverlayCollectionControlsComponent = class OverlayCollectionControlsComponent {
    constructor(platformId) {
        this.platformId = platformId;
        this.type = [];
        this.isContextSheet = false;
        this.overlayAction = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            this.isBrowser = true;
        }
    }
    ngOnInit() { }
    toggleForceKeepOverlay(val) {
        this.forceKeepOverlay = val;
    }
    dipatchAction($event, type) {
        if (!(this.type === _enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].VIDEO) || type === 'share') {
            if ($event) {
                $event.stopPropagation();
                $event.preventDefault();
            }
            this.overlayAction.emit(type);
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], OverlayCollectionControlsComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], OverlayCollectionControlsComponent.prototype, "isContextSheet", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], OverlayCollectionControlsComponent.prototype, "data", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], OverlayCollectionControlsComponent.prototype, "overlayAction", void 0);
OverlayCollectionControlsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-overlay-collection-controls',
        template: __webpack_require__(/*! raw-loader!./overlay-collection-controls.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/overlay-collection-controls/overlay-collection-controls.component.html"),
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewEncapsulation"].None,
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
        styles: [__webpack_require__(/*! ./overlay-collection-controls.component.scss */ "./src/app/core/components/overlay-collection-controls/overlay-collection-controls.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
], OverlayCollectionControlsComponent);



/***/ }),

/***/ "./src/app/core/components/overlay-collection-controls/overlay-collection-controls.module.ts":
/*!***************************************************************************************************!*\
  !*** ./src/app/core/components/overlay-collection-controls/overlay-collection-controls.module.ts ***!
  \***************************************************************************************************/
/*! exports provided: OverlayCollectionControlsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OverlayCollectionControlsModule", function() { return OverlayCollectionControlsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _overlay_collection_controls_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./overlay-collection-controls.component */ "./src/app/core/components/overlay-collection-controls/overlay-collection-controls.component.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
/* harmony import */ var _core_components_context_sheet_new_context_sheet_new_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/context-sheet-new/context-sheet-new.module */ "./src/app/core/components/context-sheet-new/context-sheet-new.module.ts");







let OverlayCollectionControlsModule = class OverlayCollectionControlsModule {
};
OverlayCollectionControlsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_overlay_collection_controls_component__WEBPACK_IMPORTED_MODULE_3__["OverlayCollectionControlsComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_4__["IconModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModule"],
            _core_components_context_sheet_new_context_sheet_new_module__WEBPACK_IMPORTED_MODULE_6__["ContextSheetNewModule"]
        ],
        exports: [_overlay_collection_controls_component__WEBPACK_IMPORTED_MODULE_3__["OverlayCollectionControlsComponent"]]
    })
], OverlayCollectionControlsModule);



/***/ }),

/***/ "./src/app/core/components/question-item/question-item.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/core/components/question-item/question-item.component.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".qstn {\n  min-height: 10em;\n  position: relative;\n  background-color: var(--bg-question-color);\n  color: var(--text-color);\n}\n\n.anghami-default-btn {\n  color: white;\n  background-color: transparent;\n  border: 1px solid white;\n}\n\n.action-button {\n  border: none !important;\n  padding: 0.5em 1.2em !important;\n  max-width: unset !important;\n}\n\n.close-icon {\n  position: absolute;\n  top: 4%;\n  right: 2%;\n}\n\n.bg-image {\n  background-repeat: no-repeat;\n  background-size: contain !important;\n  width: 100% !important;\n}\n\n.secondary {\n  color: #fff;\n  background-image: -webkit-gradient(linear, left top, right top, from(#0093fe), color-stop(#00a9fb), color-stop(#00baee), color-stop(#00c7db), to(#5fd2cb));\n  background-image: linear-gradient(to right, #0093fe, #00a9fb, #00baee, #00c7db, #5fd2cb);\n}\n\n.primary {\n  background-image: -webkit-gradient(linear, left top, right top, from(#e1418c), color-stop(#d6379b), color-stop(#c732ab), color-stop(#b035bc), to(#913ccd));\n  background-image: linear-gradient(to right, #e1418c, #d6379b, #c732ab, #b035bc, #913ccd);\n  color: #fff;\n}\n\n.purple-btn {\n  background-color: var(--brand-purple);\n  color: #fff;\n  padding: 0.3em 1.5em;\n}"

/***/ }),

/***/ "./src/app/core/components/question-item/question-item.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/question-item/question-item.component.ts ***!
  \**************************************************************************/
/*! exports provided: QuestionItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuestionItemComponent", function() { return QuestionItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _services_deeplinks_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/deeplinks.service */ "./src/app/core/services/deeplinks.service.ts");




let QuestionItemComponent = class QuestionItemComponent {
    constructor(deeplinkService) {
        this.deeplinkService = deeplinkService;
        this.show = true;
    }
    removeComponent() {
        this.show = false;
    }
    ngOnInit() { }
    triggerDeepLink(btn) {
        if (btn.backgroundurl) {
            this.deeplinkService
                .httpUrlParser(btn.backgroundurl)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["take"])(1))
                .subscribe(data => { });
        }
        if (!btn.noclose) {
            this.show = false;
        }
        if (btn.url) {
            if (btn.url.indexOf('askpermissions') > -1) {
                this.show = false;
            }
            else {
                this.deeplinkService.handleDeeplink(btn.url, true);
            }
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('type'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], QuestionItemComponent.prototype, "type", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('section'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], QuestionItemComponent.prototype, "section", void 0);
QuestionItemComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-question-item',
        template: __webpack_require__(/*! raw-loader!./question-item.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/question-item/question-item.component.html"),
        styles: [__webpack_require__(/*! ./question-item.component.scss */ "./src/app/core/components/question-item/question-item.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_3__["DeeplinksService"]])
], QuestionItemComponent);



/***/ }),

/***/ "./src/app/core/components/question-item/question-item.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/core/components/question-item/question-item.module.ts ***!
  \***********************************************************************/
/*! exports provided: QuestionItemModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuestionItemModule", function() { return QuestionItemModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _question_item_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./question-item.component */ "./src/app/core/components/question-item/question-item.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");




let QuestionItemModule = class QuestionItemModule {
};
QuestionItemModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"]],
        declarations: [_question_item_component__WEBPACK_IMPORTED_MODULE_2__["QuestionItemComponent"]],
        exports: [_question_item_component__WEBPACK_IMPORTED_MODULE_2__["QuestionItemComponent"]],
    })
], QuestionItemModule);



/***/ }),

/***/ "./src/app/core/directives/extras/extras.directive.ts":
/*!************************************************************!*\
  !*** ./src/app/core/directives/extras/extras.directive.ts ***!
  \************************************************************/
/*! exports provided: AnghamiExtrasDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AnghamiExtrasDirective", function() { return AnghamiExtrasDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");




let AnghamiExtrasDirective = class AnghamiExtrasDirective {
    constructor(store) {
        this.store = store;
    }
    click(event) {
        this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__["SetExtras"]({
            extras: this.extras
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], AnghamiExtrasDirective.prototype, "extras", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('click', ['$event']),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
], AnghamiExtrasDirective.prototype, "click", null);
AnghamiExtrasDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
        selector: '[anghamiExtras]'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"]])
], AnghamiExtrasDirective);



/***/ }),

/***/ "./src/app/core/directives/extras/extras.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/directives/extras/extras.module.ts ***!
  \*********************************************************/
/*! exports provided: ExtrasModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExtrasModule", function() { return ExtrasModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _extras_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./extras.directive */ "./src/app/core/directives/extras/extras.directive.ts");




let ExtrasModule = class ExtrasModule {
};
ExtrasModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_extras_directive__WEBPACK_IMPORTED_MODULE_3__["AnghamiExtrasDirective"]],
        exports: [_extras_directive__WEBPACK_IMPORTED_MODULE_3__["AnghamiExtrasDirective"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]]
    })
], ExtrasModule);



/***/ }),

/***/ "./src/app/core/redux/selectors/search.selector.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/redux/selectors/search.selector.ts ***!
  \*********************************************************/
/*! exports provided: selectSearchState, getSearchQuery, GetSearchTags, GetRecentSearches, getSearchResults, getSearchSuggestions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectSearchState", function() { return selectSearchState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSearchQuery", function() { return getSearchQuery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetSearchTags", function() { return GetSearchTags; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetRecentSearches", function() { return GetRecentSearches; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSearchResults", function() { return getSearchResults; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSearchSuggestions", function() { return getSearchSuggestions; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _reducers_search_reducer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../reducers/search.reducer */ "./src/app/core/redux/reducers/search.reducer.ts");


const selectSearchState = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createFeatureSelector"])('search');
const getSearchQuery = (state) => state.search.query;
const GetSearchTags = (state) => state.search.tags;
const GetRecentSearches = (state) => state.search.recentSearches;
const getSearchResults = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(selectSearchState, _reducers_search_reducer__WEBPACK_IMPORTED_MODULE_1__["getSearchResults"]);
const getSearchSuggestions = (state) => state.search.suggestions;


/***/ })

}]);