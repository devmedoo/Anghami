(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ambassador-ambassador-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/ambassador/ambassador.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/ambassador/ambassador.component.html ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header-banner\">\n  <div class=\"content d-flex flex-column align-items-end amb-header-container\">\n    <p class=\"title\" i18n=\"@@student_ambassador_header1\">\n      ARE YOU AN ALL-STAR ON CAMPUS?\n    </p>\n\n    <h5>\n      <p i18n=\"@@student_ambassador_header2\">\n        Kickstart your career and become the Student Brand Ambassador of Anghami\n        now!\n      </p>\n    </h5>\n\n    <a\n      class=\"btn default p-2 row justify-content-center col-8\"\n      target=\"_blank\"\n      href=\"https://anghami.typeform.com/to/rFDpM4\"\n    >\n      <span i18n=\"@@student_ambassador_headerBtn\">Become an Ambassador</span>\n    </a>\n  </div>\n</div>\n<div class=\"container\">\n  <div class=\"row justify-content-center\">\n    <div class=\"col-lg-12 landing-content-wrapper\">\n      <h1 class=\"d-flex justfiy-content-start\">\n        <b i18n=\"@@student_ambassador_title1\">HERE'S WHAT YOU NEED TO KNOW</b>\n      </h1>\n      <div class=\"d-flex justfiy-content-start flex-column\">\n        <h6 i18n=\"@@student_ambassador_section1_subtitle1\">\n          A Student Brand Ambassador is basically an advocate for Anghami inside\n          the university's campus.\n        </h6>\n        <h6 i18n=\"@@student_ambassador_section1_subtitle2\">\n          Someone who is hired to enbody the brand and represent it in the best\n          way possible.\n        </h6>\n      </div>\n      <ul class=\"d-flex flex-row justify-content-between amb-traits-list\">\n        <li\n          class=\"flex-grow-1 d-flex flex-column m-2 w-50 p-3 shadow amb-trait\"\n        >\n          <h3><b i18n=\"@@student_ambassador_criteria_title\">Criteria</b></h3>\n          <ul class=\"p-2\">\n            <li i18n=\"@@student_ambassador_criteria_1\">\n              Undergraduate student, starting from the second year.\n            </li>\n            <li i18n=\"@@student_ambassador_criteria_2\">\n              Familiar with technology, especially music streaming platforms.\n            </li>\n            <li i18n=\"@@student_ambassador_criteria_3\">\n              Well-connected with key influential groups and individuals inside\n              university.\n            </li>\n            <li i18n=\"@@student_ambassador_criteria_4\">\n              Highly aware of the university calendar, behind-the-scenes\n              activties and hotspots.\n            </li>\n            <li i18n=\"@@student_ambassador_criteria_5\">\n              Creative with an energic and entrepreneurial mindset.\n            </li>\n            <li i18n=\"@@student_ambassador_criteria_6\">\n              Flexible in working on and off campus.\n            </li>\n            <li i18n=\"@@student_ambassador_criteria_7\">\n              Self-motivated with strong judgement and instict.\n            </li>\n            <li i18n=\"@@student_ambassador_criteria_8\">\n              Fully passionate and committed to brand.\n            </li>\n          </ul>\n        </li>\n        <li\n          class=\"flex-grow-1 d-flex flex-column m-2 w-50 p-3 shadow amb-trait cyan\"\n        >\n          <h3>\n            <b i18n=\"@@student_ambassador_responsibilities_title\"\n              >Responsibilities</b\n            >\n          </h3>\n          <ul class=\"p-2\">\n            <li i18n=\"@@student_ambassador_responsibilities_1\">\n              Become the main contact between brand and university.\n            </li>\n            <li i18n=\"@@student_ambassador_responsibilities_2\">\n              Use your networking skills and connections to create brand buzz\n              all around campus.\n            </li>\n            <li i18n=\"@@student_ambassador_responsibilities_3\">\n              Educate and engage students on everything brand-related.\n            </li>\n            <li i18n=\"@@student_ambassador_responsibilities_4\">\n              Organize and activate unforgettable events on campus.\n            </li>\n            <li i18n=\"@@student_ambassador_responsibilities_5\">\n              Leverage your social media accounts with brand promotion and\n              engagement.\n            </li>\n          </ul>\n        </li>\n        <li\n          class=\"flex-grow-1 d-flex flex-column m-2 w-50 p-3 shadow amb-trait blue\"\n        >\n          <h3><b i18n=\"@@student_ambassador_rewards_title\">Rewards</b></h3>\n          <ul class=\"p-2\">\n            <li i18n=\"@@student_ambassador_rewards_1\">\n              Student Brand Ambassador certificate.\n            </li>\n            <li i18n=\"@@student_ambassador_rewards_2\">\n              Anghami on your résumé.\n            </li>\n            <li i18n=\"@@student_ambassador_rewards_3\">\n              Performance-based cash and exclusive opportunities.\n            </li>\n            <li i18n=\"@@student_ambassador_rewards_4\">\n              Invaluable experience with a major brand in community management.\n            </li>\n            <li i18n=\"@@student_ambassador_rewards_5\">\n              Top achievers receive a bonus.\n            </li>\n          </ul>\n        </li>\n      </ul>\n      <h5 class=\"text-center amb-trait-proof\">\n        <b\n          ><span i18n=\"@@student_ambassador_applynow_1\"\n            >If you think you are all that,\n          </span>\n          <a\n            class=\"amb-apply-now\"\n            target=\"_blank\"\n            href=\"https://anghami.typeform.com/to/rFDpM4\"\n            i18n=\"@@student_ambassador_applynow_2\"\n          >\n            apply now!</a\n          ></b\n        >\n      </h5>\n      <h1 class=\"text-center\">\n        <b i18n=\"@@student_ambassador_activations\"\n          >A GLIMPSE INTO OUR ACTIVATIONS</b\n        >\n      </h1>\n      <anghami-photo-gallery\n        [galleryImages]=\"state.images\"\n      ></anghami-photo-gallery>\n      <!-- <div class=\"anghami-rounded-tabs\">\n        <ul>\n          <li\n            class=\"selected col-6\"\n            (click)=\"switchTabs(1)\"\n            [ngClass]=\"{ selected: state.selectedTab === 1 }\"\n            i18n=\"@@student_ambassador_activations_btn_1\"\n          >\n            Photos\n          </li>\n          <li\n            class=\"col-6\"\n            (click)=\"switchTabs(2)\"\n            [ngClass]=\"{ selected: state.selectedTab === 2 }\"\n            i18n=\"@@student_ambassador_activations_btn_2\"\n          >\n            Videos\n          </li>\n        </ul>\n      </div> -->\n\n      <!-- <span [hidden]=\"state.selectedTab !== 1\"> -->\n      <div class=\"container-fluid amb-activations-list\">\n        <div class=\"row\">\n          <div\n            class=\"col-xl-2 col-lg-3 col-md-4 col-sm-4 padding05 mt-2 mb-2\"\n            *ngFor=\"let image of state.images; let index = index\"\n          >\n            <img\n              class=\"{{ index }} amb-act-img gallery-img\"\n              [src]=\"image.image\"\n            />\n          </div>\n        </div>\n      </div>\n      <!-- </span> -->\n\n      <!-- <span [hidden]=\"state.selectedTab !== 2\">\n        <div class=\"container-fluid\">\n          <div class=\"row\">\n            <div\n              class=\"col-xl-2 col-lg-3 col-md-4 col-sm-4 padding05 mt-2 mb-2\"\n              *ngFor=\"let video of state.videos\"\n            >\n              <img class=\"amb-act-img\" [src]=\"video\" />\n            </div>\n          </div>\n        </div>\n      </span> -->\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/modules/landing/ambassador/ambassador-routing.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/modules/landing/ambassador/ambassador-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: AmbassadorRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AmbassadorRoutingModule", function() { return AmbassadorRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ambassador_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ambassador.component */ "./src/app/modules/landing/ambassador/ambassador.component.ts");




var routes = [
    {
        path: '',
        component: _ambassador_component__WEBPACK_IMPORTED_MODULE_3__["AmbassadorComponent"]
    }
];
var AmbassadorRoutingModule = /** @class */ (function () {
    function AmbassadorRoutingModule() {
    }
    AmbassadorRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AmbassadorRoutingModule);
    return AmbassadorRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/ambassador/ambassador.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/modules/landing/ambassador/ambassador.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n:host .header-banner {\n  padding: 35em 0 0 0;\n  background-image: url('header.jpg');\n  background-repeat: no-repeat;\n  background-position: center 0;\n  background-size: cover;\n  background-color: var(--white);\n  height: 0;\n  min-height: 0;\n  margin: 0 0 3em 0;\n}\n:host .header-banner .content {\n  padding: 0;\n  position: absolute;\n  top: 9em;\n  right: 1em;\n  overflow: visible !important;\n  width: 90% !important;\n}\n:host .header-banner .content .title {\n  word-spacing: 0em;\n  word-spacing: 0em;\n  line-height: 1em;\n}\n:host .header-banner .content a {\n  max-width: 15em;\n}\n:host .amb-trait-proof {\n  margin: 2.5em 0;\n}\n:host .amb-traits-list {\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n}\n:host .amb-trait {\n  border-radius: 1em;\n}\n:host .amb-trait.cyan li:before {\n  color: var(--brand-cyan);\n}\n:host .amb-trait.cyan h3:before {\n  background-color: var(--brand-cyan);\n}\n:host .amb-trait.blue li:before {\n  color: var(--brand-blue-2);\n}\n:host .amb-trait.blue h3:before {\n  background-color: var(--brand-blue-2);\n}\n:host .amb-trait h3 {\n  position: relative;\n}\n:host .amb-trait h3:before {\n  content: \"\";\n  display: block;\n  width: 0.8em;\n  height: 0.1em;\n  background-color: var(--brand-purple);\n  margin: 0 0 0.35em 0;\n}\n:host .amb-trait li {\n  margin: 0 0 1em 0;\n  position: relative;\n}\n:host .amb-trait li:before {\n  content: \"○\";\n  display: inline-block;\n  margin: 0 0.25em;\n  color: var(--brand-purple);\n  position: absolute;\n  left: -1.25em;\n}\n:host .amb-apply-now {\n  color: var(--brand-purple) !important;\n  text-decoration: underline !important;\n}\n:host .anghami-rounded-tabs {\n  max-width: 20em;\n}\n:host .amb-act-img {\n  width: 100%;\n  display: block;\n  height: auto;\n  cursor: pointer;\n}\n:host .amb-activations-list,\n:host .amb-traits-list {\n  margin: 2em 0 0 0;\n}\n@media only screen and (min-width: 769px) {\n  :host .header-banner {\n    padding: 42em 0 0 0;\n  }\n  :host .header-banner .content {\n    right: 5em;\n    width: 33em !important;\n  }\n  :host .anghami-rounded-tabs {\n    max-width: 30em;\n  }\n  :host .amb-traits-list {\n    -ms-flex-wrap: nowrap;\n        flex-wrap: nowrap;\n  }\n}\nhtml[lang=ar] :host .landing-content-wrapper {\n  text-align: right;\n}\nhtml[lang=ar] :host .amb-header-container {\n  -webkit-box-align: start !important;\n      -ms-flex-align: start !important;\n          align-items: flex-start !important;\n}\nhtml[lang=ar] :host .amb-traits-list {\n  text-align: right;\n}\nhtml[lang=ar] :host .amb-trait li:before {\n  left: initial;\n  right: -1.25em;\n}"

/***/ }),

/***/ "./src/app/modules/landing/ambassador/ambassador.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/modules/landing/ambassador/ambassador.component.ts ***!
  \********************************************************************/
/*! exports provided: AmbassadorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AmbassadorComponent", function() { return AmbassadorComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");



var AmbassadorComponent = /** @class */ (function () {
    function AmbassadorComponent() {
        this.state = {
            selectedTab: 1,
            images: [
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-1.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-2.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-3.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-4.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-5.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-6.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-7.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-8.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-9.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-10.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-11.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-12.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-13.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-14.jpg" },
                { image: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN + "img/ambassador/photo-15.jpg" }
            ],
            videos: [
                '../../../../assets/img/ambassador/video-1.jpg',
                '../../../../assets/img/ambassador/video-2.jpg',
                '../../../../assets/img/ambassador/video-3.jpg'
            ]
        };
    }
    AmbassadorComponent.prototype.switchTabs = function (tab) {
        this.state.selectedTab = tab;
    };
    AmbassadorComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-ambassador',
            template: __webpack_require__(/*! raw-loader!./ambassador.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/ambassador/ambassador.component.html"),
            styles: [__webpack_require__(/*! ./ambassador.component.scss */ "./src/app/modules/landing/ambassador/ambassador.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AmbassadorComponent);
    return AmbassadorComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/ambassador/ambassador.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/modules/landing/ambassador/ambassador.module.ts ***!
  \*****************************************************************/
/*! exports provided: AmbassadorModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AmbassadorModule", function() { return AmbassadorModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ambassador_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ambassador-routing.module */ "./src/app/modules/landing/ambassador/ambassador-routing.module.ts");
/* harmony import */ var _ambassador_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ambassador.component */ "./src/app/modules/landing/ambassador/ambassador.component.ts");
/* harmony import */ var _core_components_photo_gallery_photo_gallery_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/photo-gallery/photo-gallery.module */ "./src/app/core/components/photo-gallery/photo-gallery.module.ts");






var AmbassadorModule = /** @class */ (function () {
    function AmbassadorModule() {
    }
    AmbassadorModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ambassador_routing_module__WEBPACK_IMPORTED_MODULE_3__["AmbassadorRoutingModule"], _core_components_photo_gallery_photo_gallery_module__WEBPACK_IMPORTED_MODULE_5__["PhotoGalleryModule"]],
            declarations: [_ambassador_component__WEBPACK_IMPORTED_MODULE_4__["AmbassadorComponent"]],
            exports: [_ambassador_component__WEBPACK_IMPORTED_MODULE_4__["AmbassadorComponent"]]
        })
    ], AmbassadorModule);
    return AmbassadorModule;
}());



/***/ })

}]);