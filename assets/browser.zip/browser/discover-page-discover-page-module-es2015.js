(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["discover-page-discover-page-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/discover-page/discover-page.component.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/discover-page/discover-page.component.html ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main\">\n    <div class=\"page-title discover-header\">\n        <h1 class=\"discover-head\" i18n=\"@@discover_people_title\">\n            Discover People\n        </h1>\n    </div >     \n    <anghami-discover></anghami-discover>\n</div>"

/***/ }),

/***/ "./src/app/modules/base/discover-page/discover-page-routing.module.ts":
/*!****************************************************************************!*\
  !*** ./src/app/modules/base/discover-page/discover-page-routing.module.ts ***!
  \****************************************************************************/
/*! exports provided: DiscoverPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscoverPageRoutingModule", function() { return DiscoverPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _discover_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./discover-page.component */ "./src/app/modules/base/discover-page/discover-page.component.ts");




const routes = [
    {
        path: '',
        component: _discover_page_component__WEBPACK_IMPORTED_MODULE_3__["DiscoverPageComponent"],
    }
];
let DiscoverPageRoutingModule = class DiscoverPageRoutingModule {
};
DiscoverPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        providers: [],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], DiscoverPageRoutingModule);



/***/ }),

/***/ "./src/app/modules/base/discover-page/discover-page.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/modules/base/discover-page/discover-page.component.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .discover-header {\n  margin-bottom: 0.5em;\n}\n:host .page-title {\n  margin: 0.7em 0 0.7em 0em;\n}\n:host .login-btn,\n:host .login-btn-circle {\n  display: inline !important;\n  vertical-align: middle;\n  margin: auto;\n  vertical-align: text-bottom;\n  margin: 0 2em 0 2em !important;\n}\n:host .login-btn:focus,\n:host .login-btn-circle:focus {\n  outline: none;\n}\n:host login-btn-txt {\n  font-size: 1em;\n}\n:host .login-btn-fb {\n  background: -webkit-gradient(linear, left top, right top, color-stop(0, var(--fb-light)), to(var(--fb-dark)));\n  background: linear-gradient(90deg, var(--fb-light) 0, var(--fb-dark));\n}\n:host .login-btn-fb i {\n  background-image: url('facebookicon.png');\n  margin-left: 0.3em !important;\n}\n@media only screen and (min-width: 1450px) {\n  :host .login-btn-fb i {\n    margin-left: 0.6em !important;\n  }\n}\n:host .login-btn-fb .login-btn-txt {\n  margin-left: 1em;\n}\n:host .login-btn {\n  vertical-align: middle;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  border-radius: 30px;\n  margin: 0.5em auto;\n  position: relative;\n  cursor: pointer;\n}\n:host .login-btn:not(.login-btn-small) {\n  font-family: var(--font-main-latin);\n  font-weight: bold;\n}\n:host .login-btn[disabled] {\n  cursor: initial;\n  border: 1px solid #ced4da !important;\n  color: #ced4da !important;\n}\n:host .login-btn.login-btn-big {\n  margin: 1em auto 1em auto;\n  padding: 0.75em;\n  width: 20%;\n  font-size: small;\n}\n:host .login-btn.login-btn-big:not(.login-btn-ifttt) {\n  min-width: 16em;\n}\n:host .login-btn.login-btn-big:not(.login-btn-fb):not(.login-btn-google):not(.login-btn-prpl) {\n  color: var(--text-color);\n}\n:host .login-btn:not(.login-entr-mbl) {\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host i {\n  position: absolute;\n  width: 1.4em;\n  height: 1.4em;\n  left: 1em;\n  top: 0;\n  bottom: 0;\n  margin: auto;\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: contain;\n}\n:host .login-btn-fb {\n  color: #fff;\n  border: none;\n}\nhtml[lang=ar] :host .page-title {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n}\nhtml[lang=ar] :host .discover-head {\n  text-align: right !important;\n  width: 100%;\n}"

/***/ }),

/***/ "./src/app/modules/base/discover-page/discover-page.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/modules/base/discover-page/discover-page.component.ts ***!
  \***********************************************************************/
/*! exports provided: DiscoverPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscoverPageComponent", function() { return DiscoverPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _core_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/services/auth.service */ "./src/app/core/services/auth.service.ts");




let DiscoverPageComponent = class DiscoverPageComponent {
    constructor(store, authService) {
        this.store = store;
        this.authService = authService;
    }
};
DiscoverPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "discover-page",
        template: __webpack_require__(/*! raw-loader!./discover-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/discover-page/discover-page.component.html"),
        styles: [__webpack_require__(/*! ./discover-page.component.scss */ "./src/app/modules/base/discover-page/discover-page.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"], _core_services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])
], DiscoverPageComponent);



/***/ }),

/***/ "./src/app/modules/base/discover-page/discover-page.module.ts":
/*!********************************************************************!*\
  !*** ./src/app/modules/base/discover-page/discover-page.module.ts ***!
  \********************************************************************/
/*! exports provided: DiscoverPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscoverPageModule", function() { return DiscoverPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _discover_page_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./discover-page-routing.module */ "./src/app/modules/base/discover-page/discover-page-routing.module.ts");
/* harmony import */ var _discover_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./discover-page.component */ "./src/app/modules/base/discover-page/discover-page.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _core_components_discover_discover_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/discover/discover.module */ "./src/app/core/components/discover/discover.module.ts");






let DiscoverPageModule = class DiscoverPageModule {
};
DiscoverPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _discover_page_routing_module__WEBPACK_IMPORTED_MODULE_1__["DiscoverPageRoutingModule"], _core_components_discover_discover_module__WEBPACK_IMPORTED_MODULE_5__["DiscoverModule"]],
        declarations: [_discover_page_component__WEBPACK_IMPORTED_MODULE_2__["DiscoverPageComponent"]],
        exports: [_discover_page_component__WEBPACK_IMPORTED_MODULE_2__["DiscoverPageComponent"]]
    })
], DiscoverPageModule);



/***/ })

}]);