(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modules-landing-landing-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/inner-header/inner-header.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  id=\"headerid\"\n  class=\"header\"\n  [ngStyle]=\"backgroundimage\"\n  [ngClass]=\"{ extra: backgroundHeader.extra, smallerHeader: smallerHeader }\"\n>\n  <img\n    class=\"logo\"\n    *ngIf=\"backgroundHeader.innerLogo\"\n    [src]=\"backgroundHeader.innerLogo\"\n  />\n  <div>\n    <ng-container *ngIf=\"!isapi\">\n      <h1 class=\"title\">{{ backgroundHeader?.title | translateInstant }}</h1>\n      <h5 class=\"subtitle \">\n        {{ backgroundHeader?.subtitle | translateInstant }}\n      </h5>\n    </ng-container>\n    <ng-container *ngIf=\"isapi\">\n      <div class=\"title\">{{ backgroundHeader?.title }}</div>\n      <h5 class=\"subtitle \">{{ backgroundHeader?.subtitle }}</h5>\n    </ng-container>\n  </div>\n  <img\n    *ngIf=\"isWave\"\n    class=\"wave\"\n    src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\"\n  />\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/landing.component.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/landing.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  class=\"landing-wrapper\"\n  [class.has-banner]=\"banner\"\n  [class.extrapadding]=\"isSolidFixed\"\n>\n  <nav class=\"navbar d-flex flex-row\" #navbar>\n    <a class=\"top-banner\" *ngIf=\"banner\" [href]=\"banner[locale].href\" (click)=\"tapBanner();\">\n      <img [src]=\"banner[locale].image_mobile\" class=\"mobile\" />\n      <img [src]=\"banner[locale].image\" class=\"desktop\" />\n    </a>\n    <div\n      class=\"navbar-main d-flex flex-grow-1 align-self-center justify-content-between align-items-center\"\n    >\n      <div class=\"anghami-logo\">\n        <a href=\"/\">\n          <img\n            *ngIf=\"locale !== 'ar'\"\n            #whiteLogo\n            class=\"ang-logo-img\"\n            [src]=\"env + 'anghami-logo-white.png'\"\n            lowsrc=\"env + 'anghami_white_logo.png'\"\n            alt=\"\"\n          />\n          <img\n            *ngIf=\"locale === 'ar'\"\n            #whiteLogo\n            class=\"ang-logo-img\"\n            [src]=\"env + 'logo-white-ar@2x.png'\"\n            lowsrc=\"env + 'logo-white-ar.png'\"\n            alt=\"\"\n          />\n        </a>\n      </div>\n      <div class=\"menu-links d-flex\">\n        <div class=\"os-store\">\n          <anghami-download-app\n            [type]=\"'link'\"\n            [solid]=\"isSolid\"\n          ></anghami-download-app>\n        </div>\n        <ul class=\"d-flex align-items-center\">\n          <li>\n            <a\n              href=\"https://play.anghami.com/home\"\n              i18n=\"@@landing_bar_playmusic\"\n              >Play music</a\n            >\n          </li>\n          <li>\n            <a href=\"https://www.anghami.com/help\" i18n=\"@@landing_help\"\n              >Help</a\n            >\n          </li>\n          <li class=\"dropdown\">\n            <a> <span i18n=\"@@landing_more\">More</span> &#x25BE;</a>\n            <ul class=\"dropdown-menu\">\n              <li>\n                <a href=\"https://www.anghami.com/about\" i18n=\"@@About\">About</a>\n              </li>\n              <li>\n                <a href=\"https://www.anghami.com/team\" i18n=\"@@Team\">Team</a>\n              </li>\n              <!-- <li><a href=\"#\" i18n=\"@@contact\">Contact us</a></li> -->\n              <li>\n                <a\n                  href=\"https://www.anghami.com/artist-connect\"\n                  i18n=\"@@Artist Connect\"\n                  >Artist Connect</a\n                >\n              </li>\n              <li>\n                <a href=\"https://www.anghami.com/advertise\" i18n=\"@@advertise\"\n                  >Advertise</a\n                >\n              </li>\n              <li>\n                <a href=\"https://www.anghami.com/press\" i18n=\"@@Press\">Press</a>\n              </li>\n              <li>\n                <a href=\"https://www.anghami.com/careers\" i18n=\"@@Careers\"\n                  >Careers</a\n                >\n              </li>\n            </ul>\n          </li>\n        </ul>\n      </div>\n      <div class=\"menu-actions d-flex align-items-center\">\n        <ng-container\n          *ngIf=\"(userLoggedIn$ | async) == true; else loggedOut\"\n        >\n          <ng-container *ngIf=\"(userData$ | async) as userData\">\n\n          <anghami-button *ngIf=\"userData.plantype !== '3'\" class=\"ml-3 mr-3\" size=\"narrow\" label=\"getAnghamiPlus\" link=\"https://www.anghami.com/plus\" layout=\"white\"\n            target=\"_blank\">\n          </anghami-button>\n            <anghami-user-navigation></anghami-user-navigation>\n          </ng-container>\n        </ng-container>\n        <ng-template #loggedOut>\n          <anghami-button  class=\"ml-3 mr-3\" label=\"getAnghamiPlus\" size=\"narrow\"\n            link=\"https://www.anghami.com/plus\" layout=\"white\" target=\"_blank\">\n          </anghami-button>\n          <span class=\"pointer-cursor\" (click)=\"openLoginDialog()\" i18n=\"@@landing_login\"\n            >Login</span\n          >\n          <span class=\"devider\"> | </span>\n          <span class=\"pointer-cursor\" (click)=\"openLoginDialog()\" i18n=\"@@landing_signup\"\n            >Signup</span>\n        </ng-template>\n      </div>\n\n          <div class=\"hamburger hamburger--squeeze\" (click)=\"toggleMenu()\" [class.active]=\"menuToggler\">\n            <div class=\"hamburger-box\">\n              <div class=\"hamburger-inner\">\n\n              </div>\n            </div>\n          </div>\n\n\n\n    </div>\n  </nav>\n  <div class=\"sidemenu\" [class.active]=\"menuToggler\">\n    <div class=\"row flex-column content\">\n      <div class=\"col-12 menu-link\">\n        <ng-container\n          *ngIf=\"(userLoggedIn$ | async) == true; else loggedOutMob\"\n        >\n          <a (click)=\"logout()\"><span i18n=\"@@Logout\">Logout</span></a>\n        </ng-container>\n        <ng-template #loggedOutMob>\n          <span class=\"pointer-cursor\" (click)=\"openLoginDialog()\" i18n=\"@@landing_login\"\n            >Login</span\n          >\n          <span class=\"devider\">|</span>\n          <span class=\"pointer-cursor\" (click)=\"openLoginDialog()\" i18n=\"@@landing_signup\"\n            >Signup</span\n          >\n        </ng-template>\n      </div>\n      <div class=\"col-12 menu-link\">\n        <a href=\"https://play.anghami.com/home\" i18n=\"@@landing_bar_playmusic\"\n          >Play Music</a\n        >\n      </div>\n      <div class=\"col-12 menu-link\">\n        <a href=\"https://www.anghami.com/help\" i18n=\"@@landing_help\">Help</a>\n      </div>\n\n  <div class=\"col-12 menu-link\">\n    <a href=\"https://www.anghami.com/products\" i18n=\"@@Download app\">Download App</a>\n  </div>\n  <div class=\"col-12 menu-link\">\n    <a href=\"https://www.anghami.com/plus\" i18n=\"@@landing_subscribe\">Subscribe</a>\n  </div>\n\n\n      <div class=\"col-12 road-map\">\n        <h2 i18n=\"@@useful_links\">useful links</h2>\n        <a href=\"https://www.anghami.com/gifts\" i18n=\"@@landing_sendgift\"\n          >send gift</a\n        >\n        <span> . </span>\n        <a href=\"https://www.anghami.com/redeem\" i18n=\"@@Redeem\">redeem</a>\n        <span> . </span>\n        <a href=\"https://www.anghami.com/legal\" i18n=\"@@Legal\">legal</a>\n        <span> . </span>\n        <a href=\"https://www.anghami.com/help\" i18n=\"@@Help\">help</a>\n      </div>\n      <div class=\"col-12 road-map\">\n        <h2 i18n=\"@@company\">company</h2>\n        <a href=\"https://www.anghami.com/about\" i18n=\"@@About\">about</a>\n        <span> . </span>\n        <a href=\"https://www.anghami.com/team\" i18n=\"@@Team\">team</a>\n        <span> . </span>\n        <a href=\"https://www.anghami.com/artist-connect\" i18n=\"@@Artist\"\n          >artist</a\n        >\n        <span> . </span>\n        <a href=\"https://www.anghami.com/advertise\" i18n=\"@@advertise\"\n          >advertise</a\n        >\n        <span> . </span>\n        <a href=\"https://www.anghami.com/press\" i18n=\"@@Press\">press</a>\n        <span> . </span>\n        <a href=\"https://www.anghami.com/careers\" i18n=\"@@Careers\">Careers</a>\n      </div>\n\n\n      <div class=\"col-12 road-map\">\n        <h2 i18n=\"@@language\">language</h2>\n        <select [(ngModel)]=\"selectedLanguage\" (ngModelChange)=\"onLanguageChange($event)\">\n          <option [ngValue]=\"'en'\">English</option>\n          <option [ngValue]=\"'ar'\">عربي</option>\n          <option [ngValue]=\"'fr'\">Français</option>\n        </select>\n      </div>\n    </div>\n  </div>\n\n  <router-outlet></router-outlet>\n\n  <footer>\n    <div class=\"container-fluid\">\n      <div class=\"row flex-column flex-md-row no-gutters\">\n        <div\n          class=\"col-12 col-md-4 mb-4 mb-md-0 flex-column align-items-start flex\"\n        >\n          <img\n            *ngIf=\"locale !== 'ar'\"\n            class=\"img-fluid ang-logo d-block\"\n            [src]=\"env + 'anghami-logo-colored.png'\"\n            lowsrc=\"{{ env + 'anghami-logo-colored.png' }}\"\n            alt=\"Anghami\"\n          />\n          <img\n            *ngIf=\"locale === 'ar'\"\n            class=\"img-fluid ang-logo d-block\"\n            [src]=\"env + 'anghami-official-colored-arabic@2x.png'\"\n            lowsrc=\"{{ env + 'anghami-official-colored-arabic.png' }}\"\n            alt=\"Anghami\"\n          />\n          <anghami-download-app\n            [type]=\"'footer'\"\n            *ngIf=\"os === 'web'\"\n          ></anghami-download-app>\n          <ul class=\"store-links-btns\">\n            <li class=\"d-inline-block\">\n              <a\n                href=\"https://play.google.com/store/apps/details?id=com.anghami&hl=en\"\n                target=\"_blank\"\n              >\n                <img\n                  class=\"img-fluid\"\n                  [src]=\"env + 'Play_store_B@2x.png'\"\n                  alt=\"Anghami on Android\"\n                />\n              </a>\n            </li>\n            <li class=\"d-inline-block\">\n              <a\n                href=\"https://itunes.apple.com/us/app/anghami-%D8%A7%D9%86%D8%BA%D8%A7%D9%85%D9%8A/id545395155?mt=8\"\n                target=\"_blank\"\n              >\n                <img\n                  class=\"img-fluid\"\n                  [src]=\"env + 'ios_store_B@2x.png'\"\n                  alt=\"Anghami on iOS\"\n                />\n              </a>\n            </li>\n            <li class=\"d-inline-block\">\n              <a\n                href=\"https://store.playstation.com/en-lb/product/EP8843-CUSA09723_00-WEBMAF000ANGHAMI\"\n                target=\"_blank\"\n              >\n                <img\n                  class=\"img-fluid\"\n                  [src]=\"env + 'PS_B@2x.png'\"\n                  alt=\"Anghami on Playstation\"\n                />\n              </a>\n            </li>\n          </ul>\n        </div>\n        <div class=\"col-12 col-md-4 mb-4 mb-md-0\">\n          <div class=\"row no-gutters\">\n            <div class=\"col-6 col-md-6 roadmap\">\n              <h3 i18n=\"@@company\">company</h3>\n              <ul>\n                <li class=\"link\">\n                  <a href=\"https://www.anghami.com/about\" i18n=\"@@About\"\n                    >about</a\n                  >\n                </li>\n                <li class=\"link\">\n                  <a href=\"https://www.anghami.com/team\" i18n=\"@@Team\">team</a>\n                </li>\n                <li class=\"link\">\n                  <a\n                    href=\"https://www.anghami.com/artist-connect\"\n                    i18n=\"@@Artist Connect\"\n                    >artist connect</a\n                  >\n                </li>\n                <li class=\"link\">\n                  <a href=\"https://www.anghami.com/advertise\" i18n=\"@@advertise\"\n                    >advertise</a\n                  >\n                </li>\n                <li class=\"link\">\n                  <a href=\"https://www.anghami.com/press\" i18n=\"@@Press\"\n                    >press</a\n                  >\n                </li>\n                <li class=\"link\">\n                  <a href=\"https://www.anghami.com/careers\" i18n=\"@@Careers\"\n                    >Careers</a\n                  >\n                </li>\n              </ul>\n            </div>\n            <div class=\"col-6 col-md-6 roadmap\">\n              <h3 i18n=\"@@useful_links\">useful links</h3>\n              <ul>\n                <li class=\"link\">\n                  <a href=\"https://www.anghami.com/products\" i18n=\"@@products\"\n                    >Products</a\n                  >\n                </li>\n                <li class=\"link\">\n                  <a\n                    href=\"https://www.anghami.com/gifts\"\n                    i18n=\"@@landing_sendgift\"\n                    >send gift</a\n                  >\n                </li>\n                <li class=\"link\">\n                  <a href=\"https://www.anghami.com/redeem\" i18n=\"@@Redeem\"\n                    >redeem</a\n                  >\n                </li>\n                <li class=\"link\">\n                  <a href=\"https://www.anghami.com/legal\" i18n=\"@@Legal\"\n                    >legal</a\n                  >\n                </li>\n                <li class=\"link\">\n                  <a href=\"https://www.anghami.com/help\" i18n=\"@@Help\">help</a>\n                </li>\n              </ul>\n            </div>\n          </div>\n        </div>\n        <div class=\"col-12 col-md-4\">\n          <div class=\"row no-gutters\">\n            <div class=\"col-12 roadmap\">\n              <h3 i18n=\"@@language\">language</h3>\n              <select\n                [(ngModel)]=\"selectedLanguage\"\n                (ngModelChange)=\"onLanguageChange($event)\"\n              >\n                <option [ngValue]=\"'en'\">English</option>\n                <option [ngValue]=\"'ar'\">عربي</option>\n                <option [ngValue]=\"'fr'\">Français</option>\n              </select>\n            </div>\n            <div class=\"col-12 roadmap socialize\">\n              <h3 i18n=\"@@Socialize\">socialize with us</h3>\n              <ul>\n                <li class=\"d-inline-block\">\n                  <a href=\"https://www.facebook.com/anghami\" target=\"_blank\">\n                    <img\n                      class=\"img-fluid\"\n                      [src]=\"env + 'facebook@2x.png'\"\n                      alt=\"\"\n                    />\n                  </a>\n                </li>\n                <li class=\"d-inline-block\">\n                  <a href=\"https://www.instagram.com/anghami\" target=\"_blank\">\n                    <img\n                      class=\"img-fluid\"\n                      [src]=\"env + 'Instagram@2x.png'\"\n                      alt=\"\"\n                    />\n                  </a>\n                </li>\n                <li class=\"d-inline-block\">\n                  <a href=\"https://twitter.com/anghami\" target=\"_blank\">\n                    <img\n                      class=\"img-fluid\"\n                      [src]=\"env + 'twitter@2x.png'\"\n                      alt=\"\"\n                    />\n                  </a>\n                </li>\n              </ul>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </footer>\n</div>\n<div *ngIf=\"cookieMessage\" class=\"cookie-container\">\n    <div class=\"cookie-text\" i18n=\"@@updated_privacy_policy\">\n      Cookies help us deliver our services. By continuing to use Anghami, you\n      agree to using the cookies described in our new Privacy Policy.\n    </div>\n    <div class=\"x-button\" (click)=\"checkForCookieCookie()\">\n      &times;\n    </div>\n</div>\n"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: -webkit-gradient(linear, left top, right top, from(#e03f8d), color-stop(#a22ccf), to(#2fa0df));\n  background: linear-gradient(to right, #e03f8d, #a22ccf, #2fa0df);\n  height: 30em;\n  background-size: cover !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    height: auto;\n    min-height: 15em;\n  }\n}\n:host .header.pringles {\n  background-size: cover !important;\n  background-position: center !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header.extra .title {\n  width: 60%;\n  margin: auto;\n}\n:host .header .logo {\n  max-width: 5em;\n  display: block;\n  margin: 1em auto;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n  }\n}\n:host .header .subtitle {\n  font-size: 1.2rem;\n  margin: auto;\n  font-weight: 200;\n  text-align: center;\n  padding-top: 0.5em;\n}\n@media (max-width: 768px) {\n  :host .header .subtitle {\n    width: 85%;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.ts ***!
  \************************************************************************/
/*! exports provided: InnerHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderComponent", function() { return InnerHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/mobile-detection.service */ "./src/app/core/services/mobile-detection.service.ts");



let InnerHeaderComponent = class InnerHeaderComponent {
    constructor(_mobileDetection, locale) {
        this._mobileDetection = _mobileDetection;
        this.locale = locale;
        this.locale =
            this.locale && this.locale !== null
                ? this.locale.indexOf('en') > -1
                    ? 'en'
                    : this.locale
                : 'en';
    }
    ngOnInit() {
        this._mobileDetection.verticalScreen.subscribe(isVertical => {
            if (this.backgroundHeader.mainimagemobile) {
                const image = isVertical
                    ? this.backgroundHeader.mainimagemobile
                    : this.backgroundHeader.mainimage;
                this.setBackgroundImage(image, this.backgroundHeader.backgroundcolor);
            }
        });
    }
    setBackgroundImage(img, color) {
        const backgroundcolor = color && color !== null && color !== ''
            ? color
            : 'linear-gradient(to right, #E03F8D, #A22CCF, #2FA0DF)';
        this.backgroundimage = Object.assign({}, this.backgroundimage, { background: 'url(' +
                img +
                ') 0% 0%,' + backgroundcolor });
    }
    ngOnChanges() {
        if (this.backgroundHeader && this.backgroundHeader !== null) {
            if (this.backgroundHeader.mainimage) {
                this.backgroundimage = {
                    'background-size': 'cover',
                };
                this.setBackgroundImage(this.backgroundHeader.mainimage);
            }
            if (this.backgroundHeader.type) {
                const headerElt = document.getElementById('headerid');
                if (headerElt && headerElt !== null) {
                    headerElt.classList.add(this.backgroundHeader.type);
                }
            }
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('backgroundHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "backgroundHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('smallerHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "smallerHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "isWave", void 0);
InnerHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-inner-header',
        template: __webpack_require__(/*! raw-loader!./inner-header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html"),
        styles: [__webpack_require__(/*! ./inner-header.component.scss */ "./src/app/core/components/inner-header/inner-header.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__["MobileDetectionService"], String])
], InnerHeaderComponent);



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.module.ts ***!
  \*********************************************************************/
/*! exports provided: InnerHeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderModule", function() { return InnerHeaderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.component */ "./src/app/core/components/inner-header/inner-header.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");





let InnerHeaderModule = class InnerHeaderModule {
};
InnerHeaderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__["PipesModule"]],
        declarations: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        exports: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], InnerHeaderModule);



/***/ }),

/***/ "./src/app/core/redux/effects/dialogs-landing.effects.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/redux/effects/dialogs-landing.effects.ts ***!
  \***************************************************************/
/*! exports provided: DialogsLandingEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DialogsLandingEffects", function() { return DialogsLandingEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _components_iframe_modal_iframe_modal_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/iframe-modal/iframe-modal.component */ "./src/app/core/components/iframe-modal/iframe-modal.component.ts");
/* harmony import */ var _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");








let DialogsLandingEffects = class DialogsLandingEffects {
    constructor(actions$, modalService) {
        this.actions$ = actions$;
        this.modalService = modalService;
        this.OpenIframeModal$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["DialogsActionTypes"].OpenIframeModal), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(action => action.payload), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(payload => {
            const ngbModalOptions = {
                size: 'lg',
                windowClass: 'iframe-dialog'
            };
            let modalRef = this.modalService.open(_components_iframe_modal_iframe_modal_component__WEBPACK_IMPORTED_MODULE_6__["IframeModalComponent"], ngbModalOptions);
            modalRef.componentInstance.data = payload;
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["from"])(modalRef.result).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(result => {
                return new _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["IframeModalClosed"]({ result });
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(err => {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new _actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["IframeModalDismissed"]({ err }));
            }));
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["Effect"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DialogsLandingEffects.prototype, "OpenIframeModal$", void 0);
DialogsLandingEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["Actions"],
        _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__["NgbModal"]])
], DialogsLandingEffects);



/***/ }),

/***/ "./src/app/core/services/mobile-detection.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/services/mobile-detection.service.ts ***!
  \***********************************************************/
/*! exports provided: MobileDetectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileDetectionService", function() { return MobileDetectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");





let MobileDetectionService = class MobileDetectionService {
    constructor(_cookie, utils) {
        this._cookie = _cookie;
        this.utils = utils;
        this.verticalScreen = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"]();
        if (this.utils.isBrowser()) {
            this.detectVerticalScreen();
            window.addEventListener('resize', () => {
                this.resizeThrottler();
            }, false);
        }
    }
    resizeThrottler() {
        if (this.utils.isBrowser()) {
            if (!this.resizeTimeout) {
                this.resizeTimeout = setTimeout(() => {
                    this.resizeTimeout = null;
                    this.detectVerticalScreen();
                }, 200);
            }
        }
    }
    detectVerticalScreen() {
        this.device = this._cookie.get('device');
        const width = window.innerWidth < 768 ? true : false;
        const ismobile = this.device && (this.device === 'android' || this.device === 'ios')
            ? true
            : false;
        this.verticalScreen.next(width || ismobile ? true : false);
    }
    getVerticalScreen() {
        return this.verticalScreen.asObservable();
    }
};
MobileDetectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_cookie__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
], MobileDetectionService);



/***/ }),

/***/ "./src/app/modules/landing/landing-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/modules/landing/landing-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: routes, LandingRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingRoutingModule", function() { return LandingRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _landing_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./landing.component */ "./src/app/modules/landing/landing.component.ts");




const routes = [
    {
        path: '',
        component: _landing_component__WEBPACK_IMPORTED_MODULE_3__["LandingComponent"],
        children: [
            {
                path: '',
                loadChildren: './home/home.module#HomeModule'
            },
            {
                path: 'activations/:type',
                loadChildren: './activations/activations.module#ActivationsModule',
                pathMatch: 'prefix'
            },
            {
                path: 'visa',
                redirectTo: 'activations/visa',
                pathMatch: 'full'
            },
            {
                path: 'manage-account',
                loadChildren: './manage-account/manage-account.module#ManageAccountModule',
                pathMatch: 'full'
            },
            {
                path: 'redeem',
                loadChildren: './redeem/redeem.module#RedeemModule',
                pathMatch: 'prefix'
            },
            {
                path: 'plus',
                loadChildren: './plus/plus.module#PlusModule',
                pathMatch: 'prefix'
            }, {
                path: 'import',
                loadChildren: './import-music/import-music.module#ImportMusicModule',
                pathMatch: 'full'
            }, {
                path: 'upgrade',
                redirectTo: 'plus',
                pathMatch: 'full'
            },
            {
                path: 'subscribe',
                redirectTo: 'plus',
            },
            {
                path: 'embed',
                loadChildren: './embed/embed.module#EmbedModule'
            },
            {
                path: 'embed/:type/:id',
                loadChildren: './embed/embed.module#EmbedModule'
            },
            {
                path: 'studentsoffer',
                loadChildren: './studentsoffer/studentsoffer.module#StudentsofferModule',
                pathMatch: 'prefix'
            },
            {
                path: 'giftland',
                loadChildren: './gifts/gifts.module#GiftsModule',
                pathMatch: 'prefix'
            },
            {
                path: 'giftland/:giftID',
                loadChildren: './gifts/gifts.module#GiftsModule',
                pathMatch: 'prefix'
            },
            {
                path: 'gift/:giftID',
                loadChildren: './gifts/gifts.module#GiftsModule',
                pathMatch: 'prefix'
            },
            {
                path: 'gift',
                loadChildren: './gifts/gifts.module#GiftsModule',
            },
            {
                path: 'gifts',
                loadChildren: './gifts/gifts.module#GiftsModule',
            },
            {
                path: 'redeem/:promo',
                loadChildren: './redeem/redeem.module#RedeemModule',
                pathMatch: 'prefix'
            },
            {
                path: 'promocode',
                loadChildren: './redeem/redeem.module#RedeemModule',
                pathMatch: 'prefix'
            },
            {
                path: 'promocode/:promo',
                loadChildren: './redeem/redeem.module#RedeemModule',
                pathMatch: 'prefix'
            },
            {
                path: 'accountactivate',
                loadChildren: './email-activation/email-activation.module#EmailActivationModule',
                pathMatch: 'full'
            },
            {
                path: 'subscriptioncheck',
                loadChildren: './check-subscription/check-subscription.module#CheckSubscriptionModule',
                pathMatch: 'full'
            },
            {
                path: 'download',
                loadChildren: './download-page/download-page.module#DownloadPageModule',
                pathMatch: 'full'
            },
            {
                path: 'fawry',
                loadChildren: './fawry/fawry.module#FawryModule',
                pathMatch: 'full'
            },
            {
                path: 'ambassador',
                loadChildren: './ambassador/ambassador.module#AmbassadorModule',
                pathMatch: 'full'
            },
            {
                path: 'artist-connect',
                loadChildren: './artist-connect/artist-connect.module#ArtistConnectModule',
                pathMatch: 'full'
            },
            {
                path: 'about',
                loadChildren: './about/about.module#AboutModule'
            },
            {
                path: 'legal',
                loadChildren: './legal/legal.module#LegalModule'
            },
            {
                path: 'anghami2019inmusic',
                loadChildren: './eoy2019/eoy2019.module#Eoy2019Module'
            },
            {
                path: 'advertise',
                loadChildren: './advertise/advertise.module#AdvertiseModule'
            },
            {
                path: 'team',
                loadChildren: './team/team.module#TeamModule'
            },
            {
                path: 'press',
                loadChildren: './press/press.module#PressModule'
            },
            {
                path: 'jobs',
                redirectTo: 'careers',
                pathMatch: 'full'
            },
            {
                path: 'subscribe',
                redirectTo: 'plus',
                pathMatch: 'full'
            },
            {
                path: 'careers',
                loadChildren: './careers/careers.module#CareersModule'
            },
            {
                path: 'anghamisessions',
                loadChildren: './sessions/sessions.module#SessionsModule'
            },
            {
                path: 'products',
                loadChildren: './products/products.module#ProductsModule'
            },
            {
                path: 'mcdonaldsarabia',
                loadChildren: './redeem/redeem.module#RedeemModule',
                pathMatch: 'full'
            },
            {
                path: 'mcdonaldsarabia/:promo',
                loadChildren: './redeem/redeem.module#RedeemModule',
                pathMatch: 'prefix'
            },
            {
                path: 'dfc30x30',
                loadChildren: './redeem/redeem.module#RedeemModule',
                pathMatch: 'full'
            },
            {
                path: 'cocacola',
                loadChildren: './redeem/redeem.module#RedeemModule',
                pathMatch: 'full'
            },
            {
                path: 'pringles',
                loadChildren: './redeem/redeem.module#RedeemModule',
                pathMatch: 'full'
            },
            {
                path: 'landing',
                loadChildren: './home/home.module#HomeModule'
            },
            {
                path: 'podcasts',
                loadChildren: './podcasts/podcasts.module#PodcastsModule'
            },
            {
                path: 'forgotpassword',
                loadChildren: './forgot-password/forgot-password.module#ForgotPasswordModule'
            },
            {
                path: 'resetpassword',
                loadChildren: './forgot-password/forgot-password.module#ForgotPasswordModule'
            },
        ]
    }
];
let LandingRoutingModule = class LandingRoutingModule {
};
LandingRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], LandingRoutingModule);



/***/ }),

/***/ "./src/app/modules/landing/landing.component.ts":
/*!******************************************************!*\
  !*** ./src/app/modules/landing/landing.component.ts ***!
  \******************************************************/
/*! exports provided: LandingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingComponent", function() { return LandingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../core/enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");














let LandingComponent = class LandingComponent {
    constructor(locale, render, document, store, cookieService, _utilService, _router, _cd) {
        this.locale = locale;
        this.render = render;
        this.document = document;
        this.store = store;
        this.cookieService = cookieService;
        this._utilService = _utilService;
        this._router = _router;
        this._cd = _cd;
        this.env = `${_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].assetsCDN}img/landing/`;
        this.menuToggler = false;
        this.cookieMessage = true;
        this.userLoggedIn$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_2__["getLoggedIn"]));
        this.userData$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_2__["getUser"]));
        this.cookieMessage = true;
        this.isSolidFixed = false;
    }
    set content(content) {
        this.navbar = content;
    }
    ngOnInit() {
        this.selectedLanguage = this.locale;
        this.os = this._utilService.getOSName();
        this.setLandingBanner();
        if (this.cookieService.get('cookieChecked')) {
            this.cookieMessage = false;
        }
        this.isSolidFixed = _core_enums_enums__WEBPACK_IMPORTED_MODULE_10__["fixedHeaderUrls"].find(elt => this._router.url.includes(elt)) ? true : false;
        if (this.isSolidFixed) {
            this.isSolid = true;
        }
    }
    setLandingBanner() {
        if (this._utilService.isBrowser()) {
            if (window.location.href.indexOf('/landing') > -1) {
                // this.banner = {
                //   ar: {
                //     href: 'https://play.anghami.com/artist/4760745',
                //     image:
                //       'https://phoenix.akamaized.net/adminupload/1555279177872.jpeg',
                //     image_mobile:
                //       'https://phoenix.akamaized.net/adminupload/1555279196036.jpeg'
                //   },
                //   fr: {
                //     href: 'https://play.anghami.com/artist/4760745',
                //     image:
                //       'https://phoenix.akamaized.net/adminupload/1555279258096.jpeg',
                //     image_mobile:
                //       'https://phoenix.akamaized.net/adminupload/1555279272012.jpeg'
                //   },
                //   en: {
                //     href: 'https://play.anghami.com/artist/4760745',
                //     image:
                //       'https://phoenix.akamaized.net/adminupload/1555279220681.jpeg',
                //     image_mobile:
                //       'https://phoenix.akamaized.net/adminupload/1555279239377.jpeg'
                //   },
                //   'en-US': {
                //     href: 'https://play.anghami.com/artist/4760745',
                //     image:
                //       'https://phoenix.akamaized.net/adminupload/1555279220681.jpeg',
                //     image_mobile:
                //       'https://phoenix.akamaized.net/adminupload/1555279239377.jpeg'
                //   }
                // };
                this.banner = undefined;
            }
        }
    }
    setLogo() {
        const logo = this.isSolid
            ? this.locale === 'ar'
                ? `${this.env}logo-colored-ar@2x.png`
                : `${this.env}anghami-logo-colored.png`
            : this.locale === 'ar'
                ? `${this.env}logo-white-ar@2x.png`
                : `${this.env}anghami-logo-white.png`;
        this.render.setAttribute(this.whiteLogo.nativeElement, 'src', logo);
    }
    ngAfterViewInit() {
        this._cd.detectChanges();
        setTimeout(() => {
            this.setHeaderElts();
        });
    }
    setHeaderElts() {
        if (!this.isSolidFixed && this.document) {
            this.render.listen('window', 'scroll', event => {
                // this.setParallaxElements(event);
                const doc = this.document.scrollingElement || this.document.documentElement;
                if (doc && doc.scrollTop > 50) {
                    this.render.addClass(this.navbar.nativeElement, 'solid');
                    this.isSolid = true;
                }
                else {
                    this.render.removeClass(this.navbar.nativeElement, 'solid');
                    this.isSolid = false;
                }
                this.setLogo();
            });
        }
        else {
            this.render.addClass(this.navbar.nativeElement, 'solid');
            this.setLogo();
        }
    }
    tapBanner() {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_10__["AmplitudeEvents"].tabHomePageBanner
        }));
    }
    toggleMenu() {
        this.menuToggler = !this.menuToggler;
    }
    onResize(event) {
        if (event.target.innerWidth > 767) {
            this.menuToggler = false;
        }
    }
    onLanguageChange(lang) {
        if (this._utilService.isBrowser()) {
            this.cookieService.put('userlanguageprod', lang, {
                domain: '.anghami.com'
            });
            setTimeout(() => {
                location.reload();
            }, 100);
        }
    }
    checkForCookieCookie() {
        this.cookieService.put('cookieChecked', 'true');
        this.cookieMessage = false;
    }
    logout() {
        this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_4__["Logout"]());
    }
    openLoginDialog() {
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_12__["OpenCustomDialog"]({
            type: _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_13__["DIALOG_TYPES"].LOGIN
        }));
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewChild"])('navbar', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ElementRef"]),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ElementRef"]])
], LandingComponent.prototype, "content", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewChild"])('whiteLogo', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ElementRef"])
], LandingComponent.prototype, "whiteLogo", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["HostListener"])('window:resize', ['$event']),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
], LandingComponent.prototype, "onResize", null);
LandingComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
        selector: 'anghami-landing',
        template: __webpack_require__(/*! raw-loader!./landing.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/landing.component.html"),
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewEncapsulation"].None,
        styles: [__webpack_require__(/*! ./landing.component.scss */ "./src/app/modules/landing/landing.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_5__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_6__["DOCUMENT"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String, _angular_core__WEBPACK_IMPORTED_MODULE_5__["Renderer2"],
        Document,
        _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"],
        ngx_cookie__WEBPACK_IMPORTED_MODULE_8__["CookieService"],
        _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_11__["Router"],
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ChangeDetectorRef"]])
], LandingComponent);



/***/ }),

/***/ "./src/app/modules/landing/landing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/modules/landing/landing.module.ts ***!
  \***************************************************/
/*! exports provided: LandingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingModule", function() { return LandingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _core_components_user_navigation_user_navigation_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../core/components/user-navigation/user-navigation.module */ "./src/app/core/components/user-navigation/user-navigation.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _landing_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./landing-routing.module */ "./src/app/modules/landing/landing-routing.module.ts");
/* harmony import */ var _landing_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./landing.component */ "./src/app/modules/landing/landing.component.ts");
/* harmony import */ var _core_components_header_header_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../core/components/header/header.module */ "./src/app/core/components/header/header.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../core/components/footer/footer.module */ "./src/app/core/components/footer/footer.module.ts");
/* harmony import */ var _core_components_download_app_download_app_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../core/components/download-app/download-app.module */ "./src/app/core/components/download-app/download-app.module.ts");
/* harmony import */ var _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../core/components/inner-header/inner-header.module */ "./src/app/core/components/inner-header/inner-header.module.ts");
/* harmony import */ var _anghami_services_landing_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/landing.service */ "./src/app/core/services/landing.service.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _anghami_redux_effects_external_pages_effects__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/redux/effects/external-pages.effects */ "./src/app/core/redux/effects/external-pages.effects.ts");
/* harmony import */ var _anghami_redux_effects_dialogs_effects__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @anghami/redux/effects/dialogs.effects */ "./src/app/core/redux/effects/dialogs.effects.ts");
/* harmony import */ var _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../core/components/button/button.module */ "./src/app/core/components/button/button.module.ts");
/* harmony import */ var _anghami_redux_effects_dialogs_landing_effects__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/redux/effects/dialogs-landing.effects */ "./src/app/core/redux/effects/dialogs-landing.effects.ts");

















let LandingModule = class LandingModule {
};
LandingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _landing_routing_module__WEBPACK_IMPORTED_MODULE_4__["LandingRoutingModule"],
            _core_components_header_header_module__WEBPACK_IMPORTED_MODULE_6__["HeaderModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"],
            _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_8__["FooterModule"],
            _core_components_download_app_download_app_module__WEBPACK_IMPORTED_MODULE_9__["DownloadAppModule"],
            _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_10__["InnerHeaderModule"],
            _core_components_user_navigation_user_navigation_module__WEBPACK_IMPORTED_MODULE_1__["UserNavigationModule"],
            _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_15__["ButtonModule"],
            _ngrx_effects__WEBPACK_IMPORTED_MODULE_12__["EffectsModule"].forFeature([
                _anghami_redux_effects_external_pages_effects__WEBPACK_IMPORTED_MODULE_13__["ExternalPagesEffects"],
                _anghami_redux_effects_dialogs_effects__WEBPACK_IMPORTED_MODULE_14__["DialogsEffects"],
                _anghami_redux_effects_dialogs_landing_effects__WEBPACK_IMPORTED_MODULE_16__["DialogsLandingEffects"]
            ])
        ],
        declarations: [_landing_component__WEBPACK_IMPORTED_MODULE_5__["LandingComponent"]],
        providers: [_anghami_services_landing_service__WEBPACK_IMPORTED_MODULE_11__["LandingService"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], LandingModule);



/***/ })

}]);