(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["activations-activations-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/activations/activations.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/activations/activations.component.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<anghami-inner-header [backgroundHeader]=\"innerHeader\"></anghami-inner-header>\n<anghami-white-box\n  [notice]=\"isNotice || initialloading\"\n  [loading]=\"initialloading\"\n>\n  <ng-container *ngIf=\"!initialloading\">\n    <ng-container *ngIf=\"!isplus && isLoggedIn && !isNotice\">\n      <div\n        *ngIf=\"showPayment; then paymentTemplate; else activationTemplate\"\n      ></div>\n    </ng-container>\n    <ng-container *ngIf=\"noticeDtls && noticeDtls !== null\">\n      <anghami-notice\n        [type]=\"noticetype\"\n        [notice]=\"noticeDtls\"\n        (submit)=\"handleNoticeAction($event)\"\n        (footerClick)=\"unsubscribe()\"\n      ></anghami-notice>\n    </ng-container>\n  </ng-container>\n  <ng-container *ngIf=\"initialloading\">\n    <anghami-loading class=\"loader\"></anghami-loading>\n  </ng-container>\n</anghami-white-box>\n<div class=\"space-2\"></div>\n<div class=\"footer-box\">\n  <div [innerHtml]=\"plan?.disclaimer\" class=\"disclaimer\"></div>\n</div>\n<ng-container *ngIf=\"benefitLst && benefitLst.length > 0\">\n  <div class=\"space-3\"></div>\n  <anghami-benefits [benefits]=\"benefitLst\"></anghami-benefits>\n</ng-container>\n<div class=\"space-3\"></div>\n<anghami-faq [showHelpCenter]=\"false\" [showQuestions]=\"showFAQ\"></anghami-faq>\n<ng-container *ngIf=\"showTerms\">\n  <div class=\"terms d-flex flex-column align-items-center\">\n    <h3 i18n=\"@@Terms & Conditions\">Terms & Conditions</h3>\n    <ul>\n      <li i18n=\"@@visa_t1\">\n        You should not be Plus for the past 90 days\n      </li>\n      <li i18n=\"@@visa_t2\">\n        You should be a resident of the MENA region\n      </li>\n      <li i18n=\"@@visa_t3\">\n        You should have a valid Visa Card\n      </li>\n      <li i18n=\"@@visa_t4\">\n        You should not have already had a free trial\n      </li>\n    </ul>\n  </div>\n</ng-container>\n<ng-template #activationTemplate>\n  <anghami-activation-code\n    (submit)=\"submitActivation($event)\"\n    [displaytype]=\"templateDisplayType\"\n    [type]=\"templateType\"\n    [activation]=\"activation\"\n    (clearError)=\"clearErr()\"\n    (selectOperator)=\"selectOperator($event)\"\n    [loading]=\"loading\"\n  ></anghami-activation-code>\n  <div class=\"err px-1 py-2\">\n    {{ errorMsg }}\n  </div>\n</ng-template>\n<ng-template #paymentTemplate>\n  <anghami-payment-form\n    *ngIf=\"!errorMsg || errorMsg == ''\"\n    [selectedPlan]=\"plan\"\n    [submitText]=\"plan?.planbutton\"\n    (success)=\"handleNoticeAction('successpayment')\"\n    [paymentverificationimg]=\"paymentInfoImg\"\n    [ngClass]=\"{ visa: paymentInfoImg ? true : false }\"\n  ></anghami-payment-form>\n</ng-template>\n"

/***/ }),

/***/ "./src/app/core/services/sub-operators.service.ts":
/*!********************************************************!*\
  !*** ./src/app/core/services/sub-operators.service.ts ***!
  \********************************************************/
/*! exports provided: SubOperatorsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubOperatorsService", function() { return SubOperatorsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/operators.actions */ "./src/app/core/redux/actions/operators.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");









let SubOperatorsService = class SubOperatorsService {
    constructor(_utilsService, _actionSubject, _store, platformId) {
        this._utilsService = _utilsService;
        this._actionSubject = _actionSubject;
        this._store = _store;
        this.platformId = platformId;
        this.msidnValidations = {};
        this.clearResultMessage();
    }
    clearResultMessage() {
        this.resultmsg = '';
    }
    getOperatorPlan(opdetails, isActivation) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_8__["isPlatformServer"])(this.platformId)) {
            return;
        }
        if (opdetails && opdetails !== null && Object.keys(opdetails).length > 0) {
            let appSidFromUrl = this._utilsService.getQueryFromUrl('appsid')
                || this._utilsService.getQueryFromUrl('sid');
            let params = {
                type: 'GEToperatorplan',
                output: 'jsonhp'
            };
            if (isActivation) {
                params['activation'] = opdetails.type;
            }
            else {
                params = Object.assign(params, opdetails);
            }
            if (appSidFromUrl) {
                params['appsid'] = appSidFromUrl;
            }
            const result = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["race"])(this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["OperatorsActionTypes"].GETOperatorSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(res => {
                return {
                    res: res.payload
                };
            })), this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["OperatorsActionTypes"].GETOperatorError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(res => {
                return {
                    res: res.payload
                };
            })));
            this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["GETOperator"](params));
            return result;
        }
    }
    autofillPhoneNumber(msidn) {
        let mobilenum = '';
        if (msidn && msidn != null && msidn !== '') {
            const msidncode = msidn.substring(0, 3);
            if (msidncode === this.msidnValidations['countrycode']) {
                mobilenum = msidn.replace(/^.{3}/g, '');
            }
        }
        return mobilenum;
    }
    checkOperatorValidationsExist(plan) {
        if (plan.min_digits && plan.min_digits !== null && plan.min_digits !== ''
            && plan.max_digits && plan.max_digits !== null && plan.max_digits !== ''
            && plan.country_code && plan.country_code !== null && plan.country_code !== '') {
            return true;
        }
        return false;
    }
    setMsidnDetails(plan) {
        let validations = {};
        if (this.checkOperatorValidationsExist(plan)) {
            validations = {
                min_digits: plan.min_digits,
                max_digits: plan.max_digits,
                countrycode: plan.country_code
            };
        }
        return validations;
    }
};
SubOperatorsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["ActionsSubject"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
        Object])
], SubOperatorsService);



/***/ }),

/***/ "./src/app/modules/landing/activations/activation-helper.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/modules/landing/activations/activation-helper.component.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/**\n * Swiper 4.5.1\n * Most modern mobile touch slider and framework with hardware accelerated transitions\n * http://www.idangero.us/swiper/\n *\n * Copyright 2014-2019 Vladimir Kharlampidi\n *\n * Released under the MIT License\n *\n * Released on: September 13, 2019\n */\n.swiper-container{margin-left:auto;margin-right:auto;position:relative;overflow:hidden;list-style:none;padding:0;z-index:1}\n.swiper-container-no-flexbox .swiper-slide{float:left}\n.swiper-container-vertical>.swiper-wrapper{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}\n.swiper-wrapper{position:relative;width:100%;height:100%;z-index:1;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-transition-property:-webkit-transform;transition-property:-webkit-transform;transition-property:transform;transition-property:transform, -webkit-transform;transition-property:transform,-webkit-transform;box-sizing:content-box}\n.swiper-container-android .swiper-slide,.swiper-wrapper{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}\n.swiper-container-multirow>.swiper-wrapper{-ms-flex-wrap:wrap;flex-wrap:wrap}\n.swiper-container-free-mode>.swiper-wrapper{-webkit-transition-timing-function:ease-out;transition-timing-function:ease-out;margin:0 auto}\n.swiper-slide{-ms-flex-negative:0;flex-shrink:0;width:100%;height:100%;position:relative;-webkit-transition-property:-webkit-transform;transition-property:-webkit-transform;transition-property:transform;transition-property:transform, -webkit-transform;transition-property:transform,-webkit-transform}\n.swiper-slide-invisible-blank{visibility:hidden}\n.swiper-container-autoheight,.swiper-container-autoheight .swiper-slide{height:auto}\n.swiper-container-autoheight .swiper-wrapper{-webkit-box-align:start;-ms-flex-align:start;align-items:flex-start;-webkit-transition-property:height,-webkit-transform;transition-property:height,-webkit-transform;transition-property:transform,height;transition-property:transform,height,-webkit-transform}\n.swiper-container-3d{-webkit-perspective:1200px;perspective:1200px}\n.swiper-container-3d .swiper-cube-shadow,.swiper-container-3d .swiper-slide,.swiper-container-3d .swiper-slide-shadow-bottom,.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top,.swiper-container-3d .swiper-wrapper{-webkit-transform-style:preserve-3d;transform-style:preserve-3d}\n.swiper-container-3d .swiper-slide-shadow-bottom,.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:10}\n.swiper-container-3d .swiper-slide-shadow-left{background-image:-webkit-gradient(linear,right top, left top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:linear-gradient(to left,rgba(0,0,0,.5),rgba(0,0,0,0))}\n.swiper-container-3d .swiper-slide-shadow-right{background-image:-webkit-gradient(linear,left top, right top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:linear-gradient(to right,rgba(0,0,0,.5),rgba(0,0,0,0))}\n.swiper-container-3d .swiper-slide-shadow-top{background-image:-webkit-gradient(linear,left bottom, left top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:linear-gradient(to top,rgba(0,0,0,.5),rgba(0,0,0,0))}\n.swiper-container-3d .swiper-slide-shadow-bottom{background-image:-webkit-gradient(linear,left top, left bottom,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:linear-gradient(to bottom,rgba(0,0,0,.5),rgba(0,0,0,0))}\n.swiper-container-wp8-horizontal,.swiper-container-wp8-horizontal>.swiper-wrapper{-ms-touch-action:pan-y;touch-action:pan-y}\n.swiper-container-wp8-vertical,.swiper-container-wp8-vertical>.swiper-wrapper{-ms-touch-action:pan-x;touch-action:pan-x}\n.swiper-button-next,.swiper-button-prev{position:absolute;top:50%;width:27px;height:44px;margin-top:-22px;z-index:10;cursor:pointer;background-size:27px 44px;background-position:center;background-repeat:no-repeat}\n.swiper-button-next.swiper-button-disabled,.swiper-button-prev.swiper-button-disabled{opacity:.35;cursor:auto;pointer-events:none}\n.swiper-button-prev,.swiper-container-rtl .swiper-button-next{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M0%2C22L22%2C0l2.1%2C2.1L4.2%2C22l19.9%2C19.9L22%2C44L0%2C22L0%2C22L0%2C22z'%20fill%3D'%23007aff'%2F%3E%3C%2Fsvg%3E\");left:10px;right:auto}\n.swiper-button-next,.swiper-container-rtl .swiper-button-prev{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M27%2C22L27%2C22L5%2C44l-2.1-2.1L22.8%2C22L2.9%2C2.1L5%2C0L27%2C22L27%2C22z'%20fill%3D'%23007aff'%2F%3E%3C%2Fsvg%3E\");right:10px;left:auto}\n.swiper-button-prev.swiper-button-white,.swiper-container-rtl .swiper-button-next.swiper-button-white{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M0%2C22L22%2C0l2.1%2C2.1L4.2%2C22l19.9%2C19.9L22%2C44L0%2C22L0%2C22L0%2C22z'%20fill%3D'%23ffffff'%2F%3E%3C%2Fsvg%3E\")}\n.swiper-button-next.swiper-button-white,.swiper-container-rtl .swiper-button-prev.swiper-button-white{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M27%2C22L27%2C22L5%2C44l-2.1-2.1L22.8%2C22L2.9%2C2.1L5%2C0L27%2C22L27%2C22z'%20fill%3D'%23ffffff'%2F%3E%3C%2Fsvg%3E\")}\n.swiper-button-prev.swiper-button-black,.swiper-container-rtl .swiper-button-next.swiper-button-black{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M0%2C22L22%2C0l2.1%2C2.1L4.2%2C22l19.9%2C19.9L22%2C44L0%2C22L0%2C22L0%2C22z'%20fill%3D'%23000000'%2F%3E%3C%2Fsvg%3E\")}\n.swiper-button-next.swiper-button-black,.swiper-container-rtl .swiper-button-prev.swiper-button-black{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M27%2C22L27%2C22L5%2C44l-2.1-2.1L22.8%2C22L2.9%2C2.1L5%2C0L27%2C22L27%2C22z'%20fill%3D'%23000000'%2F%3E%3C%2Fsvg%3E\")}\n.swiper-button-lock{display:none}\n.swiper-pagination{position:absolute;text-align:center;-webkit-transition:.3s opacity;transition:.3s opacity;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0);z-index:10}\n.swiper-pagination.swiper-pagination-hidden{opacity:0}\n.swiper-container-horizontal>.swiper-pagination-bullets,.swiper-pagination-custom,.swiper-pagination-fraction{bottom:10px;left:0;width:100%}\n.swiper-pagination-bullets-dynamic{overflow:hidden;font-size:0}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{-webkit-transform:scale(.33);-ms-transform:scale(.33);transform:scale(.33);position:relative}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-main{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-prev{-webkit-transform:scale(.66);-ms-transform:scale(.66);transform:scale(.66)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-prev-prev{-webkit-transform:scale(.33);-ms-transform:scale(.33);transform:scale(.33)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-next{-webkit-transform:scale(.66);-ms-transform:scale(.66);transform:scale(.66)}\n.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-next-next{-webkit-transform:scale(.33);-ms-transform:scale(.33);transform:scale(.33)}\n.swiper-pagination-bullet{width:8px;height:8px;display:inline-block;border-radius:100%;background:#000;opacity:.2}\nbutton.swiper-pagination-bullet{border:none;margin:0;padding:0;box-shadow:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}\n.swiper-pagination-clickable .swiper-pagination-bullet{cursor:pointer}\n.swiper-pagination-bullet-active{opacity:1;background:#007aff}\n.swiper-container-vertical>.swiper-pagination-bullets{right:10px;top:50%;-webkit-transform:translate3d(0,-50%,0);transform:translate3d(0,-50%,0)}\n.swiper-container-vertical>.swiper-pagination-bullets .swiper-pagination-bullet{margin:6px 0;display:block}\n.swiper-container-vertical>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic{top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);width:8px}\n.swiper-container-vertical>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{display:inline-block;-webkit-transition:.2s top,.2s -webkit-transform;transition:.2s top,.2s -webkit-transform;-webkit-transition:.2s transform,.2s top;transition:.2s transform,.2s top;-webkit-transition:.2s transform,.2s top,.2s -webkit-transform;transition:.2s transform,.2s top,.2s -webkit-transform}\n.swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet{margin:0 4px}\n.swiper-container-horizontal>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic{left:50%;-webkit-transform:translateX(-50%);-ms-transform:translateX(-50%);transform:translateX(-50%);white-space:nowrap}\n.swiper-container-horizontal>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{-webkit-transition:.2s left,.2s -webkit-transform;transition:.2s left,.2s -webkit-transform;-webkit-transition:.2s transform,.2s left;transition:.2s transform,.2s left;-webkit-transition:.2s transform,.2s left,.2s -webkit-transform;transition:.2s transform,.2s left,.2s -webkit-transform}\n.swiper-container-horizontal.swiper-container-rtl>.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{-webkit-transition:.2s right,.2s -webkit-transform;transition:.2s right,.2s -webkit-transform;-webkit-transition:.2s transform,.2s right;transition:.2s transform,.2s right;-webkit-transition:.2s transform,.2s right,.2s -webkit-transform;transition:.2s transform,.2s right,.2s -webkit-transform}\n.swiper-pagination-progressbar{background:rgba(0,0,0,.25);position:absolute}\n.swiper-pagination-progressbar .swiper-pagination-progressbar-fill{background:#007aff;position:absolute;left:0;top:0;width:100%;height:100%;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);-webkit-transform-origin:left top;-ms-transform-origin:left top;transform-origin:left top}\n.swiper-container-rtl .swiper-pagination-progressbar .swiper-pagination-progressbar-fill{-webkit-transform-origin:right top;-ms-transform-origin:right top;transform-origin:right top}\n.swiper-container-horizontal>.swiper-pagination-progressbar,.swiper-container-vertical>.swiper-pagination-progressbar.swiper-pagination-progressbar-opposite{width:100%;height:4px;left:0;top:0}\n.swiper-container-horizontal>.swiper-pagination-progressbar.swiper-pagination-progressbar-opposite,.swiper-container-vertical>.swiper-pagination-progressbar{width:4px;height:100%;left:0;top:0}\n.swiper-pagination-white .swiper-pagination-bullet-active{background:#fff}\n.swiper-pagination-progressbar.swiper-pagination-white{background:rgba(255,255,255,.25)}\n.swiper-pagination-progressbar.swiper-pagination-white .swiper-pagination-progressbar-fill{background:#fff}\n.swiper-pagination-black .swiper-pagination-bullet-active{background:#000}\n.swiper-pagination-progressbar.swiper-pagination-black{background:rgba(0,0,0,.25)}\n.swiper-pagination-progressbar.swiper-pagination-black .swiper-pagination-progressbar-fill{background:#000}\n.swiper-pagination-lock{display:none}\n.swiper-scrollbar{border-radius:10px;position:relative;-ms-touch-action:none;background:rgba(0,0,0,.1)}\n.swiper-container-horizontal>.swiper-scrollbar{position:absolute;left:1%;bottom:3px;z-index:50;height:5px;width:98%}\n.swiper-container-vertical>.swiper-scrollbar{position:absolute;right:3px;top:1%;z-index:50;width:5px;height:98%}\n.swiper-scrollbar-drag{height:100%;width:100%;position:relative;background:rgba(0,0,0,.5);border-radius:10px;left:0;top:0}\n.swiper-scrollbar-cursor-drag{cursor:move}\n.swiper-scrollbar-lock{display:none}\n.swiper-zoom-container{width:100%;height:100%;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;text-align:center}\n.swiper-zoom-container>canvas,.swiper-zoom-container>img,.swiper-zoom-container>svg{max-width:100%;max-height:100%;-o-object-fit:contain;object-fit:contain}\n.swiper-slide-zoomed{cursor:move}\n.swiper-lazy-preloader{width:42px;height:42px;position:absolute;left:50%;top:50%;margin-left:-21px;margin-top:-21px;z-index:10;-webkit-transform-origin:50%;-ms-transform-origin:50%;transform-origin:50%;-webkit-animation:swiper-preloader-spin 1s steps(12,end) infinite;animation:swiper-preloader-spin 1s steps(12,end) infinite}\n.swiper-lazy-preloader:after{display:block;content:'';width:100%;height:100%;background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%236c6c6c'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E\");background-position:50%;background-size:100%;background-repeat:no-repeat}\n.swiper-lazy-preloader-white:after{background-image:url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%23fff'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E\")}\n@-webkit-keyframes swiper-preloader-spin{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}\n@keyframes swiper-preloader-spin{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}\n.swiper-container .swiper-notification{position:absolute;left:0;top:0;pointer-events:none;opacity:0;z-index:-1000}\n.swiper-container-fade.swiper-container-free-mode .swiper-slide{-webkit-transition-timing-function:ease-out;transition-timing-function:ease-out}\n.swiper-container-fade .swiper-slide{pointer-events:none;-webkit-transition-property:opacity;transition-property:opacity}\n.swiper-container-fade .swiper-slide .swiper-slide{pointer-events:none}\n.swiper-container-fade .swiper-slide-active,.swiper-container-fade .swiper-slide-active .swiper-slide-active{pointer-events:auto}\n.swiper-container-cube{overflow:visible}\n.swiper-container-cube .swiper-slide{pointer-events:none;-webkit-backface-visibility:hidden;backface-visibility:hidden;z-index:1;visibility:hidden;-webkit-transform-origin:0 0;-ms-transform-origin:0 0;transform-origin:0 0;width:100%;height:100%}\n.swiper-container-cube .swiper-slide .swiper-slide{pointer-events:none}\n.swiper-container-cube.swiper-container-rtl .swiper-slide{-webkit-transform-origin:100% 0;-ms-transform-origin:100% 0;transform-origin:100% 0}\n.swiper-container-cube .swiper-slide-active,.swiper-container-cube .swiper-slide-active .swiper-slide-active{pointer-events:auto}\n.swiper-container-cube .swiper-slide-active,.swiper-container-cube .swiper-slide-next,.swiper-container-cube .swiper-slide-next+.swiper-slide,.swiper-container-cube .swiper-slide-prev{pointer-events:auto;visibility:visible}\n.swiper-container-cube .swiper-slide-shadow-bottom,.swiper-container-cube .swiper-slide-shadow-left,.swiper-container-cube .swiper-slide-shadow-right,.swiper-container-cube .swiper-slide-shadow-top{z-index:0;-webkit-backface-visibility:hidden;backface-visibility:hidden}\n.swiper-container-cube .swiper-cube-shadow{position:absolute;left:0;bottom:0;width:100%;height:100%;background:#000;opacity:.6;-webkit-filter:blur(50px);filter:blur(50px);z-index:0}\n.swiper-container-flip{overflow:visible}\n.swiper-container-flip .swiper-slide{pointer-events:none;-webkit-backface-visibility:hidden;backface-visibility:hidden;z-index:1}\n.swiper-container-flip .swiper-slide .swiper-slide{pointer-events:none}\n.swiper-container-flip .swiper-slide-active,.swiper-container-flip .swiper-slide-active .swiper-slide-active{pointer-events:auto}\n.swiper-container-flip .swiper-slide-shadow-bottom,.swiper-container-flip .swiper-slide-shadow-left,.swiper-container-flip .swiper-slide-shadow-right,.swiper-container-flip .swiper-slide-shadow-top{z-index:0;-webkit-backface-visibility:hidden;backface-visibility:hidden}\n.swiper-container-coverflow .swiper-wrapper{-ms-perspective:1200px}\n:host h5 {\n  text-align: center;\n  margin: auto;\n}\n:host h5.promotitle {\n  padding-top: 1em;\n  width: 50%;\n}\n:host .flex-block-center {\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n:host .promo .subtitle {\n  text-align: center;\n  font-size: 1em;\n  padding-top: 0.5em;\n}\n:host .promo .desc {\n  padding: 0 1em;\n  white-space: nowrap;\n}\n:host .margin1auto {\n  margin: 1em auto;\n}\n:host .space-3 {\n  height: 3em;\n}\n:host .err {\n  font-size: 0.9em;\n  color: red;\n}\n:host img.swiper-slide {\n  max-width: 6.5em;\n  width: inherit !important;\n}\n:host .swiper-box {\n  position: relative;\n  margin: 1em 3em;\n  width: 50%;\n}\n:host .swiper-container {\n  width: 80%;\n}\n:host .partners {\n  width: 90%;\n  margin: auto;\n}\n:host .partners .title {\n  font-size: 1.1em;\n  width: 12em;\n}\n:host .swiper-button-next, :host .swiper-button-prev {\n  -webkit-transform: scale(1.5);\n      -ms-transform: scale(1.5);\n          transform: scale(1.5);\n  outline: none;\n  opacity: 0.1;\n}\n:host .swiper-button-prev {\n  background-image: url(\"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/PjwhRE9DVFlQRSBzdmcgIFBVQkxJQyAnLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4nICAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkJz48c3ZnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDMyIDMyIiBoZWlnaHQ9IjMycHgiIGlkPSLQodC70L7QuV8xIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMycHgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxwYXRoIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTExLjI2MiwxNi43MTRsOS4wMDIsOC45OTkgIGMwLjM5NSwwLjM5NCwxLjAzNSwwLjM5NCwxLjQzMSwwYzAuMzk1LTAuMzk0LDAuMzk1LTEuMDM0LDAtMS40MjhMMTMuNDA3LDE2bDguMjg3LTguMjg1YzAuMzk1LTAuMzk0LDAuMzk1LTEuMDM0LDAtMS40MjkgIGMtMC4zOTUtMC4zOTQtMS4wMzYtMC4zOTQtMS40MzEsMGwtOS4wMDIsOC45OTlDMTAuODcyLDE1LjY3NSwxMC44NzIsMTYuMzI1LDExLjI2MiwxNi43MTR6IiBmaWxsPSIjMTIxMzEzIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGlkPSJDaGV2cm9uX1JpZ2h0Ii8+PGcvPjxnLz48Zy8+PGcvPjxnLz48Zy8+PC9zdmc+\");\n  left: -0.5em !important;\n}\n:host .swiper-button-next {\n  background-image: url(\"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/PjwhRE9DVFlQRSBzdmcgIFBVQkxJQyAnLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4nICAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkJz48c3ZnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDMyIDMyIiBoZWlnaHQ9IjMycHgiIGlkPSLQodC70L7QuV8xIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMycHgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxwYXRoIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTIxLjY5OCwxNS4yODZsLTkuMDAyLTguOTk5ICBjLTAuMzk1LTAuMzk0LTEuMDM1LTAuMzk0LTEuNDMxLDBjLTAuMzk1LDAuMzk0LTAuMzk1LDEuMDM0LDAsMS40MjhMMTkuNTUzLDE2bC04LjI4Nyw4LjI4NWMtMC4zOTUsMC4zOTQtMC4zOTUsMS4wMzQsMCwxLjQyOSAgYzAuMzk1LDAuMzk0LDEuMDM2LDAuMzk0LDEuNDMxLDBsOS4wMDItOC45OTlDMjIuMDg4LDE2LjMyNSwyMi4wODgsMTUuNjc1LDIxLjY5OCwxNS4yODZ6IiBmaWxsPSIjMTIxMzEzIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGlkPSJDaGV2cm9uX1JpZ2h0Ii8+PGcvPjxnLz48Zy8+PGcvPjxnLz48Zy8+PC9zdmc+\");\n  right: -0.5em !important;\n}\n:host .redeem-ul li {\n  display: table !important;\n  font-size: 1.1em;\n}\n:host .redeem-ul li .step {\n  display: table-cell;\n  background: -webkit-gradient(linear, left top, right top, from(#DC4190), to(#943DCB));\n  background: linear-gradient(to right, #DC4190, #943DCB);\n  border-radius: 50%;\n  width: 2em;\n  height: 2em;\n  vertical-align: middle;\n  text-align: center;\n  font-size: 1.5em !important;\n  color: white;\n}\n:host .redeem-ul ul {\n  width: 90%;\n  margin: auto;\n}\n::ng-deep .landing-wrapper {\n  background-size: 100% 35% !important;\n}\n.action-button-login {\n  display: inline-block !important;\n  width: unset !important;\n}\n.loader {\n  height: 3em;\n  margin: auto;\n  display: block;\n  position: relative !important;\n  top: unset !important;\n  left: unset !important;\n}\n.loader ::ng-deep .lds-ellipsis {\n  display: block;\n  height: 100%;\n  margin: auto;\n  width: 4.5em;\n}\n.loader ::ng-deep .lds-ellipsis div {\n  top: 1.5em !important;\n  width: 1.2em !important;\n  height: 1.2em !important;\n}\n.loader ::ng-deep .lds-ellipsis div:nth-child(1) {\n  left: 1em !important;\n  -webkit-animation: lds-ellipsis1 0.5s infinite !important;\n          animation: lds-ellipsis1 0.5s infinite !important;\n}\n.loader ::ng-deep .lds-ellipsis div:nth-child(2) {\n  left: 1em !important;\n  -webkit-animation: lds-ellipsis2 0.5s infinite !important;\n          animation: lds-ellipsis2 0.5s infinite !important;\n}\n.loader ::ng-deep .lds-ellipsis div:nth-child(3) {\n  left: 2.5em !important;\n  -webkit-animation: lds-ellipsis2 0.5s infinite !important;\n          animation: lds-ellipsis2 0.5s infinite !important;\n}\n.loader ::ng-deep .lds-ellipsis div:nth-child(4) {\n  left: 4.5em !important;\n  -webkit-animation: lds-ellipsis3 0.5s infinite !important;\n          animation: lds-ellipsis3 0.5s infinite !important;\n}"

/***/ }),

/***/ "./src/app/modules/landing/activations/activations-routing.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/modules/landing/activations/activations-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: routes, ActivationsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivationsRoutingModule", function() { return ActivationsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _activations_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./activations.component */ "./src/app/modules/landing/activations/activations.component.ts");




const routes = [
    {
        path: '',
        component: _activations_component__WEBPACK_IMPORTED_MODULE_3__["ActivationsComponent"]
    },
    {
        path: '/:type',
        component: _activations_component__WEBPACK_IMPORTED_MODULE_3__["ActivationsComponent"]
    }
];
let ActivationsRoutingModule = class ActivationsRoutingModule {
};
ActivationsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], ActivationsRoutingModule);



/***/ }),

/***/ "./src/app/modules/landing/activations/activations.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/modules/landing/activations/activations.component.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n@media (max-width: 768px) {\n  .terms {\n    width: 90%;\n    margin: auto;\n  }\n}\n.terms h3 {\n  margin-bottom: 1em !important;\n}\n.terms ul {\n  list-style: none;\n}\n.terms li {\n  height: 30px;\n}\n.terms ul li::before {\n  list-style-type: square !important;\n  font-size: 1.8em;\n  content: \"•\";\n  color: black;\n  font-weight: bold;\n  display: inline-block;\n  width: 0.8em;\n  margin-left: -1em;\n  vertical-align: middle;\n}\nhtml[lang=ar] :host ul {\n  text-align: right;\n}\nhtml[lang=ar] :host ul li::before {\n  margin-left: 0em;\n  margin-right: -1em;\n}\nhtml[lang=ar] :host .err {\n  margin-left: 0;\n  margin-right: 5em;\n  text-align: right;\n}\n.disclaimer {\n  font-size: 0.8em;\n  line-height: 1.5em;\n  margin: auto;\n  text-align: left;\n  color: #9aa3a8;\n  max-width: 65em;\n}\n.footer-box {\n  width: 80%;\n  margin: auto;\n}\n.benefits-box {\n  padding-bottom: 1em;\n}\n.benefits-box h1 {\n  text-align: center;\n  padding: 0.2em;\n}\n.err {\n  margin-left: 5em;\n}\n::ng-deep .landing-wrapper {\n  background-size: 100% 60% !important;\n}\n.visa ::ng-deep .payment-methods {\n  max-width: 5em !important;\n  margin: 1em auto !important;\n}"

/***/ }),

/***/ "./src/app/modules/landing/activations/activations.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/modules/landing/activations/activations.component.ts ***!
  \**********************************************************************/
/*! exports provided: ActivationsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivationsComponent", function() { return ActivationsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../app/core/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/plus.actions */ "./src/app/core/redux/actions/plus.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _core_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/promo.service */ "./src/app/core/services/promo.service.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _anghami_redux_selectors_plus_selectors__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/redux/selectors/plus.selectors */ "./src/app/core/redux/selectors/plus.selectors.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @anghami/services/sub-operators.service */ "./src/app/core/services/sub-operators.service.ts");


















let ActivationsComponent = class ActivationsComponent {
    constructor(locale, store, _actionSubject, _route, _router, _authService, _promoService, _operatorService, _translateService) {
        this.locale = locale;
        this.store = store;
        this._actionSubject = _actionSubject;
        this._route = _route;
        this._router = _router;
        this._authService = _authService;
        this._promoService = _promoService;
        this._operatorService = _operatorService;
        this._translateService = _translateService;
        this.initialloading = true;
        this.loading = false;
        this.activationType = '';
        this.isorange = false;
        this.isActivationPlus = false;
        this.innerHeader = {
            isbox: true
        };
        this.showFAQ = true;
        this.isNotice = false;
        this.showPayment = false;
        this.istelcos = false;
        this.isExtendedActivation = false;
        this.resendCount = 0;
        this.showTerms = false;
        this.noticetype = 'notice';
        this.isSuccess = false;
    }
    ngOnInit() {
        this.isLoggedIn = this._authService.isUserLoggedIn();
        this.queryParamsSub$ = this._route.params.subscribe(params => {
            this.activationType = params['type'];
            for (const key in _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["extendedActivations"]) {
                if (_core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["extendedActivations"][key] === this.activationType) {
                    this.isExtendedActivation = this._promoService.isExtendedActivation = true;
                }
            }
        });
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["AmplitudeEvents"].activationCampaignLanding,
            props: {
                activation: this.activationType
            }
        }));
        this.isorange =
            this.activationType.toLowerCase() === 'orangejordandsl' ||
                this.activationType.toLowerCase() === 'orangejordandslfamily';
        this.showTerms = this.activationType.toLowerCase() === 'visa';
        this.showFAQ =
            this.activationType.toLowerCase() === 'visa' || this.isExtendedActivation;
        if (this.isExtendedActivation) {
            this.istelcos = true;
        }
        if (this.isLoggedIn) {
            this.userAuth$ = this.store
                .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_app_core_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_4__["getUser"]))
                .subscribe(data => {
                if (data &&
                    data != null &&
                    Object.keys(data).length > 0 &&
                    !this.isSuccess) {
                    this.isplus = data.plantype === '3';
                    this.getActivationDetails();
                }
            });
        }
        else {
            this.initialloading = false;
            this.isNotice = true;
            this.noticeDtls = this._promoService.getNoticeType('login');
            this.getHeaderInfo({});
        }
    }
    getPlusActivationDetails() {
        /** TODO: fix it with Ryan */
        let observable = Object(rxjs__WEBPACK_IMPORTED_MODULE_12__["of"])({});
        if (this.isorange) {
            observable = this.checkBillingInfo();
        }
        observable.subscribe(() => {
            this.initialloading = false;
            this.isNotice = true;
            this.noticeDtls = this._promoService.getNoticeType('plus');
            if (this.isActivationPlus) {
                const footerDtls = this._promoService.getNoticeType('unsubscribe');
                this.noticeDtls = Object.assign({}, this.noticeDtls, footerDtls);
            }
            this.getHeaderInfo({});
        });
    }
    handleNoticeAction(type) {
        if (type === 'login') {
            this.login();
        }
        else if (type === 'proceedpayment') {
            this.showPaymentInfo();
        }
        else if (type === 'successpayment') {
            this.isNotice = true;
            this.noticetype = 'result';
            this.isSuccess = true;
            this._translateService.get('congrats_plus').subscribe(res => {
                this.noticeDtls = {
                    title: res,
                    imagesrc: 'https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/success.png'
                };
            });
        }
    }
    getTelcos() {
        this.store.dispatch(new _core_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_8__["GetTelcos"]({
            intent: this.activationType
        }));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_7__["ofType"])(_core_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_8__["AuthActionTypes"].GetTelcosSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe((res) => {
            const data = res.payload;
            if (this.activation && this.activation !== null) {
                this.activation = Object.assign({}, this.activation, { telcoLst: data.telcos });
            }
        });
    }
    getHeaderInfo(plan) {
        const header = _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["activationsHeader"][this.activationType];
        if (header && header !== null) {
            this.innerHeader = Object.assign({}, header);
        }
        else {
            this.innerHeader = Object.assign({}, _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["activationsHeader"]['default']);
        }
        if (!this.showPayment) {
            if (plan.title && plan.title != null && plan.title !== '') {
                this.innerHeader = Object.assign({}, this.innerHeader, { title: plan.title, isapi: true });
            }
            if (plan.subtitle && plan.subtitle != null && plan.subtitle !== '') {
                this.innerHeader = Object.assign({}, this.innerHeader, { subtitle: plan.subtitle, isapi: true });
            }
        }
        if (plan.topbanner &&
            plan.topbanner != null &&
            plan.topbanner !== '' &&
            !this.showPayment) {
            this.innerHeader = Object.assign({}, this.innerHeader, { mainimage: plan.topbanner });
        }
    }
    /**
     * TODO: add amplitude events
     */
    getActivationDetails() {
        const activationDtls = {
            type: this.activationType
        };
        this._operatorService
            .getOperatorPlan(activationDtls, true)
            .subscribe((result) => {
            if (result && result !== null) {
                const data = result.res && result.res !== null
                    ? result.res.data
                        ? result.res.data
                        : result.res
                    : null;
                this.handlingActivationResponse(data);
                if (this.istelcos) {
                    this.getTelcos();
                }
            }
        });
    }
    handlingActivationResponse(result) {
        if (result && result !== null) {
            this.initialloading = false;
            if (result.error) {
                this.getHeaderInfo({});
                // this.error = true;
                // this.errorMsg = result['error']['message']
                //   ? result['error']['message']
                //   : result['error']['_attributes']['message'];
                this.isNotice = true;
                this.noticeDtls = {
                    title: result['error']['message']
                        ? result['error']['message']
                        : result['error']['_attributes']['message']
                };
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
                    name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["AmplitudeEvents"].activationError,
                    props: {
                        activation: this.activationType,
                        message: this.errorMsg
                    }
                }));
            }
            else {
                this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
                    name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["AmplitudeEvents"].viewactivation,
                    props: {
                        activation: this.activationType
                    }
                }));
                if (result.plan) {
                    this.plan = JSON.parse(JSON.stringify(result.plan));
                    this.showPayment = this.plan.input_type === 'PAYMENT_INFO';
                    this.getHeaderInfo(this.plan);
                    /**
                     * TODO: change color (needed in case of Shukran)
                      if (!this.plan.color || this.plan.color == null || this.plan.color == "") {
                        this.plan.color = '#405FC6';
                      }
                    */
                    this.templateDisplayType = JSON.parse(JSON.stringify(this.plan.input_type));
                    this.templateType =
                        this.templateDisplayType === 'DEFAULT' ? 'operator' : null;
                    this.getActivationObject(this.plan).subscribe(data => {
                        this.activation = data;
                    });
                    if (this.isplus) {
                        this.getPlusActivationDetails();
                    }
                }
                if (result.features) {
                    this.benefitLst = JSON.parse(JSON.stringify(result.features));
                }
            }
        }
    }
    getActivationObject(plan) {
        let activation = {};
        let inputs = [];
        let mainlabel = '';
        let translatedInputs = [];
        let planbutton = '';
        if (plan && plan !== null && Object.keys(plan).length > 0) {
            if (this.templateDisplayType) {
                if (this.templateDisplayType === 'DEFAULT') {
                    if (this.templateType === 'operator') {
                        if (plan.planbutton === undefined ||
                            plan.planbutton === null ||
                            plan.planbutton === '') {
                            planbutton = 'continue';
                        }
                        inputs = [
                            {
                                placeholder: 'operatorplaceholder',
                                label: '',
                                id: 'msidn',
                                conditions: {
                                    type: 'tel',
                                    maxlength: '15',
                                    pattern: '^[0-9]*$'
                                }
                            }
                        ];
                    }
                    else if (this.templateType === 'verify') {
                        if (plan.planbutton === undefined ||
                            plan.planbutton === null ||
                            plan.planbutton === '') {
                            planbutton = 'verify';
                        }
                        inputs = [
                            {
                                placeholder: 'verification_code_placeholder',
                                label: '',
                                id: 'code',
                                conditions: {
                                    type: 'tel',
                                    maxlength: '10',
                                    pattern: 'd*'
                                }
                            }
                        ];
                    }
                }
                else if (this.templateDisplayType === 'OPERATOR_INFO') {
                    // mainlabel = 'orange_label_msg';
                    inputs = [
                        {
                            placeholder: 'orange_phone_placeholder',
                            label: 'orange_phonenumber',
                            id: 'msidn',
                            conditions: {
                                type: 'tel',
                                maxlength: '9',
                                pattern: '^[0-9]*$'
                            }
                        },
                        {
                            placeholder: 'national_id_placeholder',
                            label: 'national_id',
                            id: 'code',
                            conditions: {
                                type: 'all',
                                maxlength: '10',
                                pattern: '^[A-Za-z0-9]*$'
                            }
                        }
                    ];
                }
            }
            if (inputs && inputs !== null && inputs.length > 0) {
                translatedInputs = inputs.map(elt => {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_12__["forkJoin"])(elt.placeholder !== undefined &&
                        elt.placeholder !== null &&
                        elt.placeholder !== ''
                        ? this._translateService.get(elt.placeholder)
                        : Object(rxjs__WEBPACK_IMPORTED_MODULE_12__["of"])(''), elt.label !== undefined && elt.label !== null && elt.label !== ''
                        ? this._translateService.get(elt.label)
                        : Object(rxjs__WEBPACK_IMPORTED_MODULE_12__["of"])('')).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(translations => {
                        return Object.assign({}, elt, { placeholder: translations[0], label: translations[1] });
                    }));
                });
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_12__["forkJoin"])(mainlabel !== undefined && mainlabel !== null && mainlabel !== ''
                ? this._translateService.get(mainlabel)
                : Object(rxjs__WEBPACK_IMPORTED_MODULE_12__["of"])(''), planbutton !== undefined && planbutton !== null && planbutton !== ''
                ? this._translateService.get(planbutton)
                : Object(rxjs__WEBPACK_IMPORTED_MODULE_12__["of"])(''), ...translatedInputs).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(result => {
                return (activation = {
                    logoimg: plan.bigimage,
                    mainlabel: this.plan &&
                        this.plan !== null &&
                        this.plan.description &&
                        this.plan.description !== null &&
                        this.plan.description !== ''
                        ? this.plan.description
                        : result[0],
                    inputLst: result.slice(2),
                    action: plan.planbutton
                        ? plan.planbutton
                        : planbutton && planbutton !== null && planbutton !== ''
                            ? planbutton
                            : ''
                });
            }));
        }
    }
    /**
     * check if user is plus by getting his billing information
     * TODO: fix it and make it generic api call should be coming from getOperator
     */
    checkBillingInfo() {
        if (this.plan) {
            const params = {
                type: this.plan.api,
                check: 1
            };
            return this._promoService.activate(params).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])((result) => {
                if (result && result !== null) {
                    // const data = result.data;
                    if (result.error) {
                        if (result['error'].code === 66) {
                            this.isplus = true;
                            this.isActivationPlus = true;
                        }
                    }
                    else {
                        this.isplus = false;
                    }
                }
            }));
        }
    }
    clearErr() {
        this.errorMsg = '';
    }
    isEmpty(data) {
        let errcount = 0;
        if (data && data !== null) {
            Object.keys(data).forEach(elt => {
                if (data[elt].model === undefined ||
                    data[elt].model === null ||
                    data[elt].model === '') {
                    errcount++;
                }
            });
        }
        return errcount === 0;
    }
    submitActivation(data) {
        if (data && data !== null) {
            if (data.key && data.key !== null) {
                if (data.key === 'resend') {
                    this.resendCount++;
                    this.resend(data);
                }
                else if (data.key === 'verify') {
                    this.verify(data);
                }
                else {
                    this.activate(data);
                }
            }
            else {
                this.activate(data);
            }
        }
    }
    verify(data) {
        this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_plus_selectors__WEBPACK_IMPORTED_MODULE_15__["getOperator"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(res => {
            if (res && res !== null) {
                const params = {
                    type: res['type'],
                    msidn: res['msidn'],
                    telco: res['returnname'],
                    code: data.code,
                    key: data.key,
                    intent: this.activationType,
                    output: 'jsonhp',
                    planid: this.plan.id
                };
                this.activate(params);
            }
        });
    }
    resend(data) {
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["AmplitudeEvents"].resendVerificationCode
        }));
        this.activate(data, true);
    }
    submitAPI(params, type) {
        const apiparams = JSON.parse(JSON.stringify(params));
        delete apiparams.key;
        this._promoService.activate(apiparams).subscribe(result => {
            if (result && result !== null) {
                if (result.error) {
                    this.loading = false;
                    this.errorMsg =
                        result['error'].message || result['error']['_attributes'].message;
                    this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
                        name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["AmplitudeEvents"].activateCampaignFailure,
                        props: {
                            activation: this.activationType,
                            message: this.errorMsg
                        }
                    }));
                    if (result['error'].code === 50) {
                        this.isNotice = true;
                        this.noticeDtls = {
                            title: result['error'].message
                        };
                    }
                }
                else {
                    // might be result.data
                    this.loading = false;
                    const operatordetails = Object.assign({}, params, this.selectedTelco);
                    if (type === undefined || type === null || type !== 'verify') {
                        this.store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_6__["SetOperator"](operatordetails));
                    }
                    if (this.isExtendedActivation) {
                        this.handlingExtendedActivationResponse(operatordetails, result);
                    }
                    else {
                        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
                            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["AmplitudeEvents"].activateCampaignSuccess,
                            props: {
                                activation: this.activationType
                            }
                        }));
                        this._router.navigate(['/subscriptioncheck'], { queryParams: { success: 1 } });
                    }
                }
            }
        });
    }
    activate(data, resend) {
        if (data && data !== null && Object.keys(data).length > 0) {
            this.clearErr();
            if (this.isLoggedIn) {
                this.loading = true;
                if (!this.isEmpty(data)) {
                    let params = {};
                    if (this.templateDisplayType === 'DEFAULT' &&
                        this.templateType === 'verify' &&
                        data.key &&
                        data.key === 'verify') {
                        params = JSON.parse(JSON.stringify(data));
                    }
                    else {
                        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_10__["LogAmplitudeEvent"]({
                            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_3__["AmplitudeEvents"].clickActivateCampaign,
                            props: Object.assign({ activation: this.activationType }, data)
                        }));
                        let msidn;
                        if (data['msidn'] && data['msidn'] !== null) {
                            if (this.templateType !== 'verify') {
                                let mobile = JSON.parse(JSON.stringify(data['msidn']));
                                if (this.selectedTelco && this.selectedTelco.prefix === '') {
                                    while (mobile.charAt(0) === '0') {
                                        mobile = mobile.substr(1);
                                    }
                                }
                                msidn =
                                    this.selectedTelco &&
                                        this.selectedTelco !== null &&
                                        this.selectedTelco.prefix
                                        ? this.selectedTelco.prefix + mobile
                                        : mobile;
                            }
                            else {
                                msidn = data['msidn'];
                            }
                        }
                        params = Object.assign({ type: this.plan.api, command: '' }, data, { intent: this.activationType, msidn: msidn, planid: this.plan.id });
                        if (this.selectedTelco && this.selectedTelco !== null) {
                            params = Object.assign({}, params, { telco: this.selectedTelco.returnname });
                        }
                        if (resend) {
                            params = Object.assign({}, params, { resend: this.resendCount });
                        }
                    }
                    this.submitAPI(params);
                }
                else {
                    this._promoService
                        .getTranslations(['fields_required'])
                        .subscribe(res => {
                        this.errorMsg = res[0];
                        this.loading = false;
                    });
                }
            }
            else {
                this.login();
            }
        }
    }
    handlingExtendedActivationResponse(data, result) {
        if (this.templateDisplayType === 'DEFAULT') {
            if (this.templateType === 'operator') {
                this.templateType = 'verify';
                const plan = {
                    bigimage: this.selectedTelco && this.selectedTelco !== null
                        ? this.selectedTelco.image
                        : null
                };
                this.getActivationObject(plan).subscribe(res => {
                    this.activation = res;
                });
            }
            else if (this.templateType === 'verify' &&
                (data.key === undefined ||
                    data.key === null ||
                    (data.key && data.key !== 'resend'))) {
                if (result.data && result.data !== null) {
                    if ((result.data.extra &&
                        result.data.extra !== null &&
                        result.data.extra !== '') ||
                        (result.data.message &&
                            result.data.message !== null &&
                            result.data.message !== '')) {
                        this.isNotice = true;
                        this._translateService.get('proceed').subscribe(res => {
                            this.noticeDtls = {
                                title: result.data.extra || result.data.message,
                                action: 'proceedpayment',
                                actionbutton: res,
                                actionclass: this.isExtendedActivation
                                    ? 'ang-operator-btn'
                                    : 'ang-primary-colored-btn'
                            };
                        });
                        if (result.data.plan_id &&
                            result.data.plan_id !== null &&
                            result.data.plan_id !== '') {
                            this.plan.id = result.data.plan_id;
                        }
                        if (result.data.price &&
                            result.data.price !== null &&
                            result.data.result !== '') {
                            this.plan.price = result.data.price;
                        }
                    }
                    else {
                        this.showPaymentInfo();
                    }
                }
            }
        }
    }
    showPaymentInfo() {
        this.isNotice = false;
        this.noticeDtls = {};
        this.templateDisplayType = 'PAYMENT_INFO';
        this.showPayment = true;
        if (this.activationType.toLowerCase() === 'visa') {
            this.paymentInfoImg =
                'https://anghamiwebcdn.akamaized.net/web/assets/img/activations/verified-by-visa-large.png';
        }
        if (this.plan && this.plan.price && this.plan.price === '0') {
            this._translateService.get('free_for').subscribe(res => {
                this.plan.planbutton = res + ' ' + this.plan.duration;
            });
        }
        else {
            this._translateService.get('pay').subscribe(res => {
                this.plan.planbutton =
                    res +
                        ' ' +
                        this.plan.currency +
                        this.plan.price +
                        '/' +
                        this.plan.duration;
            });
        }
    }
    login() {
        this._promoService.login('activate', this.activationType);
    }
    unsubscribe() {
        if (this.isLoggedIn && this.plan) {
            this.initialloading = true;
            const params = {
                type: this.plan.api,
                command: 'DELETE',
                planid: this.plan.id
            };
            this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_7__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_6__["PlusActionTypes"].POSTactivationSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
                .subscribe(data => {
                this.initialloading = false;
                this.errorMsg = '';
                this.isSuccess = false;
                this.isNotice = false;
                this.isplus = false;
                this.noticeDtls = {};
                this._translateService
                    .get('unsubscribe_plus_success')
                    .subscribe(res => {
                    this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_16__["OpenDialog"]({
                        displaymode: 'toast',
                        title: res
                    }));
                });
            });
            this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_7__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_6__["PlusActionTypes"].POSTactivationError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
                .subscribe((data) => {
                this.loading = false;
                if (data['error']) {
                    this.errorMsg = data['error']['_attributes'].message;
                }
            });
            this.store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_6__["POSTactivation"](params));
        }
    }
    selectOperator(data) {
        this.selectedTelco = JSON.parse(JSON.stringify(data));
    }
    ngOnDestroy() {
        if (this.userAuth$) {
            this.userAuth$.unsubscribe();
        }
        if (this.queryParamsSub$) {
            this.queryParamsSub$.unsubscribe();
        }
    }
};
ActivationsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-activations',
        template: __webpack_require__(/*! raw-loader!./activations.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/activations/activations.component.html"),
        styles: [__webpack_require__(/*! ./activations.component.scss */ "./src/app/modules/landing/activations/activations.component.scss"), __webpack_require__(/*! ./activation-helper.component.scss */ "./src/app/modules/landing/activations/activation-helper.component.scss"), __webpack_require__(/*! ../redeem/promo.component.scss */ "./src/app/modules/landing/redeem/promo.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
        _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_11__["AuthService"],
        _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_13__["PromoService"],
        _anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_17__["SubOperatorsService"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__["TranslateService"]])
], ActivationsComponent);



/***/ }),

/***/ "./src/app/modules/landing/activations/activations.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/modules/landing/activations/activations.module.ts ***!
  \*******************************************************************/
/*! exports provided: ActivationsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivationsModule", function() { return ActivationsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _activations_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./activations.component */ "./src/app/modules/landing/activations/activations.component.ts");
/* harmony import */ var _activations_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./activations-routing.module */ "./src/app/modules/landing/activations/activations-routing.module.ts");
/* harmony import */ var _core_components_components_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/components.module */ "./src/app/core/components/components.module.ts");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.module */ "./src/app/core/components/inner-header/inner-header.module.ts");
/* harmony import */ var _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.module */ "./src/app/core/components/white-box/white-box.module.ts");
/* harmony import */ var _core_components_faq_faq_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/components/faq/faq.module */ "./src/app/core/components/faq/faq.module.ts");
/* harmony import */ var _core_components_notice_notice_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/components/notice/notice.module */ "./src/app/core/components/notice/notice.module.ts");
/* harmony import */ var _core_components_activation_code_activivaton_code_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/components/activation-code/activivaton-code.module */ "./src/app/core/components/activation-code/activivaton-code.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/components/payment-form/payment-form.module */ "./src/app/core/components/payment-form/payment-form.module.ts");
/* harmony import */ var _core_components_benefits_activation_benefits_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/components/benefits/activation-benefits.module */ "./src/app/core/components/benefits/activation-benefits.module.ts");















let ActivationsModule = class ActivationsModule {
};
ActivationsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _activations_routing_module__WEBPACK_IMPORTED_MODULE_4__["ActivationsRoutingModule"],
            _core_components_components_module__WEBPACK_IMPORTED_MODULE_5__["ComponentsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormsModule"],
            _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_6__["LoadingModule"],
            _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_7__["InnerHeaderModule"],
            _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_8__["WhiteBoxModule"],
            _core_components_faq_faq_module__WEBPACK_IMPORTED_MODULE_9__["FaqModule"],
            _core_components_notice_notice_module__WEBPACK_IMPORTED_MODULE_10__["NoticeModule"],
            _core_components_activation_code_activivaton_code_module__WEBPACK_IMPORTED_MODULE_11__["ActivationCodeModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ReactiveFormsModule"],
            _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_13__["PaymentFormModule"],
            _core_components_benefits_activation_benefits_module__WEBPACK_IMPORTED_MODULE_14__["ActivationBenefitsModule"]
        ],
        declarations: [_activations_component__WEBPACK_IMPORTED_MODULE_3__["ActivationsComponent"]],
        exports: [_activations_component__WEBPACK_IMPORTED_MODULE_3__["ActivationsComponent"]],
        providers: []
    })
], ActivationsModule);



/***/ })

}]);