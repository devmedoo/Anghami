(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["library-library-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/library/library-collection/library-collection.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/library/library-collection/library-collection.component.html ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main\" [ngClass]=\"{ empty: collectionMeta?.isempty }\">\n  <ng-container *ngIf=\"type && (isplus || type !== 'desktop-downloads')\">\n    <ng-container *ngIf=\"!collectionMeta?.isempty\">\n      <div class=\"view-side\">\n        <anghami-collection-header-side [collectionSections]=\"collectionSections\" [collectionMeta]=\"collectionMeta\"\n          [collectionType]=\"type\"></anghami-collection-header-side>\n      </div>\n      <div class=\"view-content\">\n        <div class=\"auto-downloads-btn float-right\" *ngIf=\"shouldShowAutoDownloadsComponent\">\n          <button class=\"anghami-primary-btn\" (click)=\"goToOnOtherDevices()\">\n            <span i18n=\"@@Downloads_on_other_devices\">Downloads on other devices</span>\n          </button>\n        </div>\n        <h1 style=\"padding-top: 0.25em;\">{{ collectionMeta.name || collectionMeta.title }}</h1>\n        <ng-container *ngIf=\"type === 'desktop-downloads'\">\n          <ng-container *ngIf=\"isDesktopClient && downloadQueue?.length > 0\">\n            <div class=\"download-queue-section\" (click)=\"goToDownloadQueuePage()\">\n              <div class=\"download-icon-container\">\n                <span>\n                  <anghami-icon class=\"icon download-icon\" [data]=\"'download'\" *ngIf=\"!downloadQueueState?.paused\">\n                  </anghami-icon>\n                  <anghami-icon class=\"icon download-icon\" [data]=\"'download-paused'\"\n                    *ngIf=\"downloadQueueState?.paused\">\n                  </anghami-icon>\n                </span>\n              </div>\n              <div class=\"download-queue-label\">\n                <span>\n                  <ng-container i18n=\"@@Downloading\">Downloading</ng-container>\n                  {{ translateNumber(downloadQueue.length) }}\n                  <ng-container i18n=\"@@Songs\" *ngIf=\"downloadQueue.length > 1\">\n                    Songs\n                  </ng-container>\n                  <ng-container i18n=\"@@Song\" *ngIf=\"downloadQueue.length === 1\">\n                    Song\n                  </ng-container>\n                </span>\n              </div>\n              <div class=\"arrow-container\">\n                <span>\n                  <anghami-icon class=\"icon arrow-left\" [data]=\"'arrow-left'\"></anghami-icon>\n                </span>\n              </div>\n              <div class=\"pause-label-container\">\n                <span class=\"pause-label\">\n                  {{ downloadQueueState?.paused ? 'Paused' : '' }}\n                </span>\n              </div>\n            </div>\n          </ng-container>\n          <ng-container *ngIf=\"\n                  collectionSections?.length > 0 &&\n                  collectionSections[0].data.length > 0\n                \">\n            <anghami-new-section-builder [sections]=\"collectionSections\" [searchTerm]=\"searchTerm\" #sectionBuilder\n              [type]=\"type\" [isView]=\"true\"></anghami-new-section-builder>\n          </ng-container>\n        </ng-container>\n        <ng-container *ngIf=\"type !== 'desktop-downloads'\">\n          <anghami-new-section-builder [collectionMeta]=\"collectionMeta\" [sections]=\"collectionSections\"\n            [searchTerm]=\"searchTerm\" #sectionBuilder [type]=\"type\" [isView]=\"true\"></anghami-new-section-builder>\n        </ng-container>\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"collectionMeta?.isempty\">\n      <anghami-empty-pages [type]=\"routeId\"></anghami-empty-pages>\n    </ng-container>\n  </ng-container>\n  <ng-container *ngIf=\"!isplus && type === 'desktop-downloads' && isDesktopClient\">\n    <anghami-empty-pages [type]=\"'downloads-free-user-img'\"></anghami-empty-pages>\n  </ng-container>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.html":
/*!*******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.html ***!
  \*******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main\">\n  <ng-container *ngIf=\"(sections$ | async) as sections\">\n    <ngb-tabset>\n      <ng-container *ngFor=\"let section of sections; let i = index\">\n        <ngb-tab [title]=\"section.text\" *ngIf=\"!section.isHidden\">\n          <ng-template ngbTabContent>\n            <div class=\"flex flex-end pt-4\">\n              <div class=\"create-playlist\" *ngIf=\"routeId === 'playlists'\" >\n                <div class=\"anghami-primary-btn\" (click)=\"createPlaylist()\">\n                  <span>+ </span>\n                  <span i18n=\"@@Create Playlist\">Create Playlist</span>\n                </div>\n              </div>\n              <anghami-search-input \n                (searchInput)=\"searchSection($event)\" \n                *ngIf=\"section && section.data && section.data.length > 0\"\n              ></anghami-search-input>\n            </div>\n            <ng-container *ngIf=\"!section?.isempty\">\n              <anghami-new-section-builder \n                class=\"anghami-sections\" \n                [searchTerm]=\"searchTerm\" \n                [sections]=\"[section]\" \n                [cardLength]=\"section.data.length\"\n                type=\"library\"\n              ></anghami-new-section-builder>\n            </ng-container>\n            <ng-container *ngIf=\"section?.isempty\">\n              <anghami-empty-pages [type]=\"getSectionType(section)\"></anghami-empty-pages>\n            </ng-container>\n          </ng-template>\n        </ngb-tab>\n      </ng-container>\n    </ngb-tabset>\n  </ng-container>\n</div>\n"

/***/ }),

/***/ "./src/app/modules/base/library/library-collection/library-collection.component.scss":
/*!*******************************************************************************************!*\
  !*** ./src/app/modules/base/library/library-collection/library-collection.component.scss ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".ang-main.empty {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n.ang-main .view-side {\n  width: 18em;\n  float: left;\n  padding: 1em;\n}\n.ang-main .view-content {\n  overflow: hidden;\n  padding: 1em;\n  position: relative;\n}\n.ang-main .download-queue-section {\n  display: inline-block;\n  width: 100%;\n  text-align: center;\n  cursor: pointer;\n  padding: 1em;\n  margin-top: 2em;\n  margin-bottom: 1em;\n  border-top: 1px solid var(--bg-white-secondary);\n  border-bottom: 1px solid var(--bg-white-secondary);\n}\n.ang-main .download-queue-section .icon {\n  display: inline-block;\n  vertical-align: middle;\n}\n.ang-main .download-queue-section .download-icon-container {\n  margin: 0 0.5em;\n  display: inline-block;\n}\n.ang-main .download-queue-section .download-icon-container ::ng-deep svg {\n  font-size: 1.5em;\n}\n.ang-main .download-queue-section .download-queue-label {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  font-weight: bold;\n  font-size: 1.1em;\n}\n.ang-main .download-queue-section .download-icon {\n  margin-right: 0.3em;\n  color: var(--download-icon-color);\n  position: relative;\n  bottom: 0.1em;\n}\n.ang-main .download-queue-section .arrow-container {\n  margin: 0 0.5em;\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  position: relative;\n  bottom: 0.06em;\n}\n.ang-main .download-queue-section .pause-label-container {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n}\n.ang-main .download-queue-section .pause-label-container .pause-label {\n  color: var(--download-icon-color);\n}\n.ang-main .download-queue-section .arrow-left {\n  font-size: 0.6em;\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n  margin-right: 0.2em;\n}\n.ang-main .auto-downloads-btn {\n  margin-top: 1.2em;\n}\n.ang-main .auto-downloads-btn button {\n  background-color: var(--search-background);\n}\n.ang-main .auto-downloads-btn button span {\n  color: var(--text-color);\n}\n.ang-main:lang(ar) .view-side {\n  float: right;\n}\n.ang-main:lang(ar) .view-content h1 {\n  text-align: right;\n}"

/***/ }),

/***/ "./src/app/modules/base/library/library-collection/library-collection.component.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/modules/base/library/library-collection/library-collection.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: LibraryCollectionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LibraryCollectionComponent", function() { return LibraryCollectionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/library.actions */ "./src/app/core/redux/actions/library.actions.ts");
/* harmony import */ var _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/mymusic.actions */ "./src/app/core/redux/actions/mymusic.actions.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/selectors/desktop-client.selectors */ "./src/app/core/redux/selectors/desktop-client.selectors.ts");
/* harmony import */ var _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/selectors/mymusic.selector */ "./src/app/core/redux/selectors/mymusic.selector.ts");
/* harmony import */ var _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/desktop-download.service */ "./src/app/core/services/desktop-download.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
















var LibraryCollectionComponent = /** @class */ (function () {
    function LibraryCollectionComponent(store, _route, _actionSubject, desktopDownloadsService, router, sectionService, utils, locale) {
        var _this = this;
        this.store = store;
        this._route = _route;
        this._actionSubject = _actionSubject;
        this.desktopDownloadsService = desktopDownloadsService;
        this.router = router;
        this.sectionService = sectionService;
        this.utils = utils;
        this.locale = locale;
        this.class = 'ang-view';
        this.downloadQueue = [];
        this.isDesktopClient = !!window['desktopClient'];
        this.downloadsEmpty = false;
        this.routeToSelectorMapping = {
            likes: _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_5__["getLikesCollectionState"],
            downloads: _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_5__["getDownloadsCollectionState"],
            albums: _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_5__["getLikedAlbumsCollectionState"]
        };
        this.routeToActionMapping = {
            albums: _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetLikedAlbums"],
            likes: _anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["GetFollowedPlaylists"]
        };
        this.routeToEmptyActionMapping = {
            likes: _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_2__["EmptyLikedSongsCollection"],
            downloads: _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_2__["EmptyDownloadsCollection"],
            albums: _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_2__["EmptyLikedAlbumsCollection"]
        };
        this.shouldShowAutoDownloadsComponent = false;
        this.routeId =
            this._route.snapshot['params'] &&
                this._route.snapshot['params'].collectionType
                ? this._route.snapshot['params'].collectionType
                : undefined;
        if (this.routeId && this.routeId !== null) {
            if (this.isDesktopClient && this.routeId === 'desktop-downloads') {
                this.collectionMeta = this.desktopDownloadsService.getDownloadsPageStruct();
                this.collectionSections = this.collectionMeta.sections;
                this.type = this.collectionMeta.list_type;
                this.downloadSection = {
                    displaytype: 'list',
                    type: 'song',
                    initialnumitems: 100,
                    data: [],
                    title: 'Downloads',
                    sectionid: 1
                };
                this.downloadQueueSubscription = this.store
                    .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_10__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_4__["getDownloadQueue"]))
                    .subscribe(function (response) {
                    _this.downloadQueue = response;
                });
                this.downloadListSubscription = this.desktopDownloadsService.desktopDownloads$.subscribe(function (response) {
                    var struct = _this.desktopDownloadsService.getDownloadsPageStruct();
                    _this.collectionMeta = struct;
                    _this.collectionSections = _this.collectionMeta.sections;
                });
                this.downloadQueueStateSubscription = this.store
                    .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_10__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_4__["downloadQueueState"]))
                    .subscribe(function (response) {
                    _this.downloadQueueState = response;
                });
                this.shouldShowAutoDownloadsComponent = true;
            }
            else {
                this.collectionMeta$ = this.store
                    .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_10__["select"])(this.routeToSelectorMapping[this.routeId]))
                    .subscribe(function (data) {
                    if (data && data !== null) {
                        _this.type = data.list_type;
                        _this.collectionMeta = JSON.parse(JSON.stringify(data));
                        _this.collectionSections = JSON.parse(JSON.stringify(data.sections));
                    }
                });
                this.actionSubjectSubscription = this._actionSubject
                    .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_9__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_12__["CollectionActionTypes"].GetCollectionSuccessNew))
                    .subscribe(function (res) {
                    var payload = res.payload;
                    if (payload.fromPaginatedRequest) {
                        _this.collectionMeta = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, payload.collectionMeta, { buttons: _this.collectionMeta.buttons });
                        if (payload.sections && payload.sections.length > 0) {
                            _this.collectionSections = _this.sectionService.checkAndMergeSections(_this.collectionSections, payload.sections);
                        }
                    }
                });
            }
            this.userDtls$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_10__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_3__["getUser"]));
            this.userDtls$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["take"])(2)).subscribe(function (data) {
                if (data && data !== null) {
                    _this.isplus = data.plantype && data.plantype === '3';
                }
            });
            this.likeCollectionSuccess$ = this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_9__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].UpdateLikedSongsPlaylist))
                .subscribe(function (action) {
                _this.store.dispatch(new _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_2__["UpdateLikedSongsCollection"](action.payload));
            });
            this.likeAlbumCollectionSuccess$ = this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_9__["ofType"])(_anghami_redux_actions_library_actions__WEBPACK_IMPORTED_MODULE_1__["LibraryActionTypes"].UpdateLikedAlbumsList))
                .subscribe(function (action) {
                _this.store.dispatch(new _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_2__["UpdateLikedAlbumsCollection"](action.payload));
            });
        }
    }
    LibraryCollectionComponent.prototype.searchSection = function (term) {
        this.searchTerm = term;
    };
    LibraryCollectionComponent.prototype.goToDownloadQueuePage = function () {
        this.router.navigateByUrl('/download-queue');
    };
    LibraryCollectionComponent.prototype.goToOnOtherDevices = function () {
        this.store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_14__["GoToDownloadsOnOtherDevices"]());
    };
    LibraryCollectionComponent.prototype.translateNumber = function (num) {
        var str = num.toString();
        if (this.locale === 'ar') {
            return this.utils.toArabicDigits(str);
        }
        return str;
    };
    LibraryCollectionComponent.prototype.ngOnDestroy = function () {
        if (this.collectionMeta$) {
            this.collectionMeta$.unsubscribe();
            this.store.dispatch(new this.routeToEmptyActionMapping[this.routeId]());
        }
        if (this.actionSubjectSubscription) {
            this.actionSubjectSubscription.unsubscribe();
        }
        if (this.likeCollectionSuccess$) {
            this.likeCollectionSuccess$.unsubscribe();
        }
        if (this.likeAlbumCollectionSuccess$) {
            this.likeAlbumCollectionSuccess$.unsubscribe();
        }
        if (this.downloadListSubscription) {
            this.downloadListSubscription.unsubscribe();
        }
        if (this.downloadQueueSubscription) {
            this.downloadQueueSubscription.unsubscribe();
        }
        if (this.downloadQueueStateSubscription) {
            this.downloadQueueStateSubscription.unsubscribe();
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_7__["HostBinding"])('attr.class'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], LibraryCollectionComponent.prototype, "class", void 0);
    LibraryCollectionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_7__["Component"])({
            selector: 'anghami-library-collection',
            template: __webpack_require__(/*! raw-loader!./library-collection.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/library/library-collection/library-collection.component.html"),
            styles: [__webpack_require__(/*! ./library-collection.component.scss */ "./src/app/modules/base/library/library-collection/library-collection.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](7, Object(_angular_core__WEBPACK_IMPORTED_MODULE_7__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_7__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_10__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_10__["ActionsSubject"],
            _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_6__["DesktopDownloadService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"],
            _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_13__["SectionService"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_15__["UtilService"], String])
    ], LibraryCollectionComponent);
    return LibraryCollectionComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/library/library-routing.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/modules/base/library/library-routing.module.ts ***!
  \****************************************************************/
/*! exports provided: LibraryRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LibraryRoutingModule", function() { return LibraryRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _library_library_resolver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../library/library.resolver */ "./src/app/modules/base/library/library.resolver.ts");
/* harmony import */ var _library_collection_library_collection_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./library-collection/library-collection.component */ "./src/app/modules/base/library/library-collection/library-collection.component.ts");
/* harmony import */ var _libraryTabbedCollection_libraryTabbedCollection_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./libraryTabbedCollection/libraryTabbedCollection.component */ "./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.ts");






var routes = [
    {
        path: 'likes',
        component: _library_collection_library_collection_component__WEBPACK_IMPORTED_MODULE_4__["LibraryCollectionComponent"],
        resolve: {
            viewData: _library_library_resolver__WEBPACK_IMPORTED_MODULE_3__["LibraryResolver"]
        }
    },
    {
        path: 'desktop-downloads',
        component: _library_collection_library_collection_component__WEBPACK_IMPORTED_MODULE_4__["LibraryCollectionComponent"]
    },
    {
        path: 'downloads',
        component: _library_collection_library_collection_component__WEBPACK_IMPORTED_MODULE_4__["LibraryCollectionComponent"],
        resolve: {
            viewData: _library_library_resolver__WEBPACK_IMPORTED_MODULE_3__["LibraryResolver"]
        }
    },
    {
        path: 'albums',
        component: _library_collection_library_collection_component__WEBPACK_IMPORTED_MODULE_4__["LibraryCollectionComponent"],
        resolve: {
            viewData: _library_library_resolver__WEBPACK_IMPORTED_MODULE_3__["LibraryResolver"]
        }
    },
    {
        path: 'playlists',
        component: _libraryTabbedCollection_libraryTabbedCollection_component__WEBPACK_IMPORTED_MODULE_5__["LibraryTabbedCollectionComponent"],
        resolve: {
            viewData: _library_library_resolver__WEBPACK_IMPORTED_MODULE_3__["LibraryResolver"]
        }
    },
    {
        path: 'artists',
        component: _libraryTabbedCollection_libraryTabbedCollection_component__WEBPACK_IMPORTED_MODULE_5__["LibraryTabbedCollectionComponent"],
        resolve: {
            viewData: _library_library_resolver__WEBPACK_IMPORTED_MODULE_3__["LibraryResolver"]
        }
    }
];
var LibraryRoutingModule = /** @class */ (function () {
    function LibraryRoutingModule() {
    }
    LibraryRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], LibraryRoutingModule);
    return LibraryRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/base/library/library.module.ts":
/*!********************************************************!*\
  !*** ./src/app/modules/base/library/library.module.ts ***!
  \********************************************************/
/*! exports provided: LibraryModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LibraryModule", function() { return LibraryModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _core_components_empty_pages_empty_pages_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/components/empty-pages/empty-pages.module */ "./src/app/core/components/empty-pages/empty-pages.module.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _core_components_search_input_search_input_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/search-input/search-input.module */ "./src/app/core/components/search-input/search-input.module.ts");
/* harmony import */ var _library_collection_library_collection_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./library-collection/library-collection.component */ "./src/app/modules/base/library/library-collection/library-collection.component.ts");
/* harmony import */ var _library_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./library-routing.module */ "./src/app/modules/base/library/library-routing.module.ts");
/* harmony import */ var _library_resolver__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./library.resolver */ "./src/app/modules/base/library/library.resolver.ts");
/* harmony import */ var _libraryTabbedCollection_libraryTabbedCollection_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./libraryTabbedCollection/libraryTabbedCollection.component */ "./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");
/* harmony import */ var _core_components_collection_header_side_collection_header_side_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/components/collection-header-side/collection-header-side.module */ "./src/app/core/components/collection-header-side/collection-header-side.module.ts");














var LibraryModule = /** @class */ (function () {
    function LibraryModule() {
    }
    LibraryModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _library_routing_module__WEBPACK_IMPORTED_MODULE_8__["LibraryRoutingModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__["NgbModule"],
                _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_5__["IconModule"],
                _core_components_empty_pages_empty_pages_module__WEBPACK_IMPORTED_MODULE_4__["EmptyPagesModule"],
                _core_components_search_input_search_input_module__WEBPACK_IMPORTED_MODULE_6__["SearchInputModule"],
                _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_12__["NewSectionBuilderModule"],
                _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_11__["PipesModule"],
                _core_components_collection_header_side_collection_header_side_module__WEBPACK_IMPORTED_MODULE_13__["CollectionHeaderSideModule"],
            ],
            declarations: [_libraryTabbedCollection_libraryTabbedCollection_component__WEBPACK_IMPORTED_MODULE_10__["LibraryTabbedCollectionComponent"], _library_collection_library_collection_component__WEBPACK_IMPORTED_MODULE_7__["LibraryCollectionComponent"]],
            providers: [_library_resolver__WEBPACK_IMPORTED_MODULE_9__["LibraryResolver"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], LibraryModule);
    return LibraryModule;
}());



/***/ }),

/***/ "./src/app/modules/base/library/library.resolver.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/base/library/library.resolver.ts ***!
  \**********************************************************/
/*! exports provided: LibraryResolver */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LibraryResolver", function() { return LibraryResolver; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/mymusic.actions */ "./src/app/core/redux/actions/mymusic.actions.ts");
/* harmony import */ var _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/selectors/mymusic.selector */ "./src/app/core/redux/selectors/mymusic.selector.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _core_services_utils_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/services/utils.service */ "./src/app/core/services/utils.service.ts");









var LibraryResolver = /** @class */ (function () {
    function LibraryResolver(store, platformId, utils) {
        this.store = store;
        this.platformId = platformId;
        this.utils = utils;
    }
    LibraryResolver.prototype.resolve = function (route, state) {
        var routeId = (state.url.split('/')).length >= 3 ? state.url.split('/')[2] : undefined || undefined;
        if (routeId !== undefined) {
            if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformServer"])(this.platformId)) {
                this.initViewData(routeId);
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
            }
            else {
                return this.waitForViewDataToLoad(routeId);
            }
        }
        else {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["empty"])();
        }
    };
    LibraryResolver.prototype.waitForViewDataToLoad = function (routeId) {
        var _this = this;
        var routeToSelectorMapping = {
            likes: _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_2__["getLikesCollectionState"],
            downloads: _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_2__["getDownloadsCollectionState"],
            albums: _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_2__["getLikedAlbumsCollectionState"],
            playlists: _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_2__["getFollowedPlaylistsCollectionState"],
            artists: _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_2__["getFollowedArtistsState"],
        };
        var mymusicCollectionStream$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["select"])(routeToSelectorMapping[routeId]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["filter"])(function (state) {
            if (state === undefined || state === null) {
                _this.initViewData(routeId);
                return false;
            }
            else {
                return true;
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1));
        return mymusicCollectionStream$;
    };
    LibraryResolver.prototype.initViewData = function (routeId) {
        if (routeId) {
            this.store.dispatch(new _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_1__["SetLibraryPlaylistCollection"](routeId));
        }
    };
    LibraryResolver = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
            Object,
            _core_services_utils_service__WEBPACK_IMPORTED_MODULE_8__["UtilService"]])
    ], LibraryResolver);
    return LibraryResolver;
}());



/***/ }),

/***/ "./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.scss":
/*!*****************************************************************************************************!*\
  !*** ./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.scss ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 100%;\n  max-width: unset !important;\n}\n:host .create-playlist {\n  margin-right: 2em;\n}\n.center-text {\n  margin: auto;\n  text-align: center;\n}\n.section-title {\n  font-size: 1.2em;\n  font-weight: 500;\n  padding: 1em;\n}\n.bottom-border {\n  border-bottom: 3px solid #a5a0a0;\n}\n.active-section {\n  border-width: 0px 0px 3px 0px;\n  border-style: solid;\n  -webkit-border-image: -webkit-gradient(linear, left top, right top, from(#913ccd), to(#e1418c)) 1 30%;\n  -webkit-border-image: linear-gradient(to right, #913ccd, #e1418c) 1 30%;\n       -o-border-image: linear-gradient(to right, #913ccd, #e1418c) 1 30%;\n          border-image: -webkit-gradient(linear, left top, right top, from(#913ccd), to(#e1418c)) 1 30%;\n          border-image: linear-gradient(to right, #913ccd, #e1418c) 1 30%;\n}\n.padding1 {\n  padding: 1em;\n}\n.anghami-buttons {\n  margin-bottom: 0em !important;\n}\n.anghami-buttons ::ng-deep .anghami-default-btn {\n  margin-bottom: 0 !important;\n}\n::ng-deep ul.nav-tabs {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center !important;\n      -ms-flex-pack: center !important;\n          justify-content: center !important;\n  cursor: pointer;\n  margin: -1em;\n}\n::ng-deep ul.nav-tabs .nav-link {\n  border: none !important;\n}\n::ng-deep ul .nav-item {\n  padding: 0 1em !important;\n}\n::ng-deep ul li a {\n  color: black;\n}\n::ng-deep ul li a.nav-link:hover {\n  border-color: white !important;\n}\n::ng-deep ul li a.nav-link.active {\n  color: var(--active-tab) !important;\n  font-weight: 600 !important;\n  border-color: white !important;\n  border-top: 0 !important;\n  border-bottom: 2px solid !important;\n}\n::ng-deep ul li a.nav-link.active:hover {\n  color: var(--active-tab) !important;\n}\nhtml[lang=ar] :host .create-playlist {\n  margin-right: 0em;\n  margin-left: 2em;\n}"

/***/ }),

/***/ "./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.ts":
/*!***************************************************************************************************!*\
  !*** ./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.ts ***!
  \***************************************************************************************************/
/*! exports provided: LibraryTabbedCollectionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LibraryTabbedCollectionComponent", function() { return LibraryTabbedCollectionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/selectors/mymusic.selector */ "./src/app/core/redux/selectors/mymusic.selector.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/selectors/library.selector */ "./src/app/core/redux/selectors/library.selector.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/mymusic.actions */ "./src/app/core/redux/actions/mymusic.actions.ts");











var LibraryTabbedCollectionComponent = /** @class */ (function () {
    function LibraryTabbedCollectionComponent(_route, _store, _router) {
        var _this = this;
        this._route = _route;
        this._store = _store;
        this._router = _router;
        this.routeToSelectorMapping = {
            artists: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__["getFollowedArtistsState"],
            playlists: _anghami_redux_selectors_library_selector__WEBPACK_IMPORTED_MODULE_6__["getFollowedPlaylistsState"],
        };
        var selector;
        var url = this._router.url.split('/');
        var path = url && url.length > 1 ? url[url.length - 1] : '';
        this.selected = 0;
        switch (path) {
            case 'artists':
                selector = _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_4__["getFollowedArtistsState"];
                break;
            case 'playlists':
                selector = _anghami_redux_selectors_mymusic_selector__WEBPACK_IMPORTED_MODULE_4__["getFollowedPlaylistsCollectionState"];
                break;
            default:
                throw 'Invalid route';
        }
        this.sections$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(selector), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(function (sections) {
            if (sections) {
                return sections.map(function (section) {
                    return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, section, { data: section.data.filter(function (elt) { return !elt.isHidden; }) });
                });
            }
            else {
                return [];
            }
        }));
        this.userDtls$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__["getUser"]));
        this.userDtls$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1)).subscribe(function (data) {
            if (data && data !== null) {
                _this.isplus = (data.plantype && data.plantype == 3);
            }
        });
    }
    LibraryTabbedCollectionComponent.prototype.searchSection = function (term) {
        this.searchTerm = term;
    };
    LibraryTabbedCollectionComponent.prototype.dispatchHeaderAction = function ($event) {
        switch ($event.actionType) {
            case _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["collectionActionsEnums"].MANAGEPLAYLIST: {
                this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_9__["OpenPlaylistManager"]({
                    type: _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["collectionActionsEnums"].MANAGEPLAYLIST
                }));
                break;
            }
            default: {
                //alert($event.actionType);
            }
        }
    };
    LibraryTabbedCollectionComponent.prototype.getSectionType = function (section) {
        var type = this.routeId;
        if (this.routeId === 'artists' && section && section.group === 'hidden') {
            type = 'muted-artists';
        }
        return type;
    };
    LibraryTabbedCollectionComponent.prototype.createPlaylist = function () {
        this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_9__["OpenPlaylistManager"]({ type: 'create' }));
    };
    LibraryTabbedCollectionComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.routeId = this._route.snapshot['params'] && this._route.snapshot['params'].collectionType
            ? this._route.snapshot['params'].collectionType : undefined;
        this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(this.routeToSelectorMapping[this.routeId]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["skip"])(1)).subscribe(function (data) {
            _this._store.dispatch(new _anghami_redux_actions_mymusic_actions__WEBPACK_IMPORTED_MODULE_10__["SetLibraryPlaylistCollection"](_this.routeId));
        });
    };
    LibraryTabbedCollectionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-library',
            template: __webpack_require__(/*! raw-loader!./libraryTabbedCollection.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.html"),
            host: { class: 'ang-view' },
            styles: [__webpack_require__(/*! ./libraryTabbedCollection.component.scss */ "./src/app/modules/base/library/libraryTabbedCollection/libraryTabbedCollection.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], LibraryTabbedCollectionComponent);
    return LibraryTabbedCollectionComponent;
}());



/***/ })

}]);