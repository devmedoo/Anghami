(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["products-products-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/products/products.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/products/products.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"products-wrapper\">\n  <div class=\"header-banner\">\n    <div class=\"content\" #headerContent>\n      <p class=\"title\">\n        <ng-container i18n=\"@@products_page_title1\">More Freedom</ng-container\n        ><br /><ng-container i18n=\"@@products_page_title2\"\n          >on the go</ng-container\n        >\n      </p>\n      <h4 class=\"sub-title\" i18n=\"@@landing_section2_subtitle\">\n        All the music you want. Anywhere. Anytime\n      </h4>\n    </div>\n    <!-- <div class=\"landing-wave\"></div> -->\n  </div>\n  <div class=\"virtual-height d-none d-md-block\" #virtualHeight></div>\n  <div\n    class=\"container-fluid dynamic-section-menu d-none d-md-block\"\n    #dynamicSectionMenu\n  >\n    <div class=\"row no-gutters align-items-center justify-content-between p-5\">\n      <div\n        (click)=\"goToSection('iphone-section')\"\n        class=\"col product-item\"\n        [class.selected]=\"selectedSection === 'phones-section'\"\n      >\n        <img\n          class=\"img-fluid\"\n          [src]=\"env2 + 'mobile@2x.png'\"\n          lowsrc=\"{{ env2 + 'mobile.png' }}\"\n          alt=\"\"\n        />\n        <p>Mobile & Tablets</p>\n      </div>\n      <div\n        (click)=\"goToSection('desktop-section')\"\n        class=\"col product-item\"\n        [class.selected]=\"selectedSection === 'desktop-section'\"\n      >\n        <img\n          class=\"img-fluid\"\n          [src]=\"env2 + 'laptop@2x.png'\"\n          lowsrc=\"{{ env2 + 'laptop.png' }}\"\n          alt=\"\"\n        />\n        <p>Desktop & Laptop</p>\n      </div>\n      <div\n        (click)=\"goToSection('speaker-section')\"\n        class=\"col product-item\"\n        [class.selected]=\"selectedSection === 'speaker-section'\"\n      >\n        <img\n          class=\"img-fluid\"\n          [src]=\"env2 + 'speakers@2x.png'\"\n          lowsrc=\"{{ env2 + 'speakers.png' }}\"\n          alt=\"\"\n        />\n        <p i18n=\"@@landing_section2_item3\">Speakers</p>\n      </div>\n      <div\n        (click)=\"goToSection('carplay-section')\"\n        class=\"col product-item\"\n        [class.selected]=\"selectedSection === 'carplay-section'\"\n      >\n        <img\n          class=\"img-fluid\"\n          [src]=\"env2 + 'car@2x.png'\"\n          lowsrc=\"{{ env2 + 'car.png' }}\"\n          alt=\"\"\n        />\n        <p i18n=\"@@landing_section2_item4\">Cars</p>\n      </div>\n      <div\n        (click)=\"goToSection('chromecast-section')\"\n        class=\"col product-item\"\n        [class.selected]=\"selectedSection === 'chromecast-section'\"\n      >\n        <img\n          class=\"img-fluid\"\n          [src]=\"env2 + 'chromecast@2x.png'\"\n          lowsrc=\"{{ env2 + 'chromecast.png' }}\"\n          alt=\"\"\n        />\n        <p i18n=\"@@landing_section2_item5\">Chromecast</p>\n      </div>\n      <div\n        (click)=\"goToSection('ps-section')\"\n        class=\"col product-item\"\n        [class.selected]=\"selectedSection === 'ps-section'\"\n      >\n        <img\n          [src]=\"env2 + 'playstation@2x.png'\"\n          lowsrc=\"{{ env2 + 'playstation.png' }}\"\n          alt=\"\"\n        />\n        <p i18n=\"@@landing_section2_item6\">Playstation</p>\n      </div>\n      <div\n        (click)=\"goToSection('wearables-section')\"\n        class=\"col product-item\"\n        [class.selected]=\"selectedSection === 'wearables-section'\"\n      >\n        <img\n          class=\"img-fluid\"\n          [src]=\"env2 + 'wearables@2x.png'\"\n          lowsrc=\"{{ env2 + 'wearables.png' }}\"\n          alt=\"\"\n        />\n        <p i18n=\"@@landing_section2_item7\">Wearables</p>\n      </div>\n      <div\n        (click)=\"goToSection('appletv-section')\"\n        class=\"col product-item\"\n        [class.selected]=\"selectedSection === 'appletv-section'\"\n      >\n        <img\n          class=\"img-fluid\"\n          [src]=\"env2 + 'AppleTV@2x.png'\"\n          lowsrc=\"{{ env2 + 'AppleTV.png' }}\"\n          alt=\"\"\n        />\n        <p i18n=\"@@landing_section2_item8\">Apple TV</p>\n      </div>\n      <div\n        (click)=\"goToSection('tv-section')\"\n        class=\"col product-item\"\n        [class.selected]=\"selectedSection === 'tv-section'\"\n      >\n        <img\n          class=\"img-fluid\"\n          [src]=\"env2 + 'TVs@2x.jpg'\"\n          lowsrc=\"{{ env2 + 'TVs@2x.jpg' }}\"\n          alt=\"\"\n        />\n        <p i18n=\"@@landing_section2_item9\">TV</p>\n      </div>      \n    </div>\n  </div>\n  <div class=\"container\">\n    <div\n      id=\"iphone-section\"\n      class=\"row product-section align-items-center\"\n      data-type=\"phones-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img class=\"img-fluid bg\" [src]=\"env + 'blue-shape@2x.png'\" alt=\"\" />\n          <img\n            class=\"img-fluid main\"\n            [src]=\"env + 'iphone-ipad@2x.png'\"\n            alt=\"\"\n          />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@iphone_title\">\n          ON YOUR IPHONE, IPAD\n        </h4>\n        <p i18n=\"@@iphone_subtitle\">\n          Dive into more music than you can imagine, on your iPhone and iPad.\n        </p>\n        <a\n          href=\"https://itunes.apple.com/us/app/anghami-%D8%A7%D9%86%D8%BA%D8%A7%D9%85%D9%8A/id545395155?mt=8\"\n        >\n          <img class=\"img-fluid\" [src]=\"env + 'app-store.png'\" alt=\"\" />\n        </a>\n      </div>\n    </div>\n    <div\n      class=\"row product-section align-items-center\"\n      data-type=\"phones-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img class=\"img-fluid bg\" [src]=\"env + 'red-shape@2x.png'\" alt=\"\" />\n          <img class=\"img-fluid main\" [src]=\"env + 'android@2x.png'\" alt=\"\" />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@android_title\">\n          ON YOUR ANDROID, TABLETS\n        </h4>\n        <p i18n=\"@@android_subtitle\">\n          Enjoy your favorite music on your Android device, tablet. All you have\n          to do is download the app on Google Play.\n        </p>\n        <a\n          href=\"https://play.google.com/store/apps/details?id=com.anghami&hl=en\"\n        >\n          <img class=\"img-fluid\" [src]=\"env + 'google-play-btn.png'\" alt=\"\" />\n        </a>\n      </div>\n    </div>\n    <div\n      id=\"desktop-section\"\n      class=\"row product-section align-items-center\"\n      data-type=\"desktop-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img class=\"img-fluid bg\" [src]=\"env + 'green-shape@2x.png'\" alt=\"\" />\n          <img class=\"img-fluid main\" [src]=\"env + 'desktop@2x.png'\" alt=\"\" />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@desktop_title\">\n          ON YOUR DESKTOP, LAPTOP\n        </h4>\n        <p i18n=\"@@desktop_subtitle\">\n          Open your browser, go to play.anghami.com, press play and turn up the\n          volume. You can also download our Desktop App and enjoy great music\n          experience on your computer.\n        </p>\n        <a\n          href=\"https://play.anghami.com/download\"\n        >\n          <img class=\"img-fluid\" [src]=\"env + 'desktop-app-btn.png'\" alt=\"\" />\n        </a>\n      </div>\n    </div>\n    <div\n      id=\"speaker-section\"\n      class=\"row product-section align-items-center\"\n      data-type=\"speaker-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img\n            class=\"img-fluid bg\"\n            [src]=\"env + 'purple-shape@2x.png'\"\n            alt=\"\"\n          />\n          <img class=\"img-fluid main\" [src]=\"env + 'speakers@2x.png'\" alt=\"\" />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@speakers_title\">\n          ON YOUR SPEAKERS\n        </h4>\n        <p i18n=\"@@speakers_subtitle\">\n          Anghami is availble on Samsung Wireless Audio 360, Sonos. Enjoy the\n          freedom to place your speaker anywhere, to sit anywhere in your room\n          and experience the same great sound quality from every angle.\n        </p>\n      </div>\n    </div>\n    <div\n      id=\"carplay-section\"\n      class=\"row product-section align-items-center\"\n      data-type=\"carplay-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img class=\"img-fluid bg\" [src]=\"env + 'blue-shape@2x.png'\" alt=\"\" />\n          <img class=\"img-fluid main\" [src]=\"env + 'carplay@2x.png'\" alt=\"\" />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@carplay_title\">ON CARPLAY</h4>\n        <p i18n=\"@@carplay_subtitle\">\n          With Anghami on CarPlay you can enjoy your playlists, mixes, albums\n          and more in select cars and car stereos.\n        </p>\n      </div>\n    </div>\n    <div\n      class=\"row product-section align-items-center\"\n      data-type=\"carplay-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img class=\"img-fluid bg\" [src]=\"env + 'red-shape@2x.png'\" alt=\"\" />\n          <img\n            class=\"img-fluid main\"\n            [src]=\"env + 'android auto@2x.png'\"\n            alt=\"\"\n          />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@androidauto_title\">\n          ON ANDROID AUTO\n        </h4>\n        <p i18n=\"@@androidauto_subtitle\">\n          With Android Auto let Anghami be your travel buddy and play your\n          favorite albums, artists, mixes directly from your dashboard.\n        </p>\n      </div>\n    </div>\n    <div\n      id=\"chromecast-section\"\n      class=\"row product-section align-items-center\"\n      data-type=\"chromecast-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img class=\"img-fluid bg\" [src]=\"env + 'green-shape@2x.png'\" alt=\"\" />\n          <img\n            class=\"img-fluid main\"\n            [src]=\"env + 'chromecast@2x.png'\"\n            alt=\"\"\n          />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@chromecast_title\">CHROMECAST</h4>\n        <p i18n=\"@@chromecast_subtitle\">\n          Anghami app will automatically recognize any Chromecasts on your local\n          network, prompting you to connect via a pop-up message.\n        </p>\n      </div>\n    </div>\n    <div\n      id=\"ps-section\"\n      class=\"row product-section align-items-center\"\n      data-type=\"ps-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img\n            class=\"img-fluid bg\"\n            [src]=\"env + 'purple-shape@2x.png'\"\n            alt=\"\"\n          />\n          <img class=\"img-fluid main\" [src]=\"env + 'PS@2x.png'\" alt=\"\" />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@playstation_title\">\n          ON YOUR PLAYSTATION\n        </h4>\n        <p i18n=\"@@playstation_subtitle\">\n          Enjoy music on your PlayStation without interrupting your game. As a\n          Angami subscriber, you can play your favorite artists, albums while\n          gaming.\n        </p>\n      </div>\n    </div>\n    <div\n      id=\"wearables-section\"\n      class=\"row product-section align-items-center\"\n      data-type=\"wearables-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img class=\"img-fluid bg\" [src]=\"env + 'blue-shape@2x.png'\" alt=\"\" />\n          <img\n            class=\"img-fluid main pt-5\"\n            [src]=\"env + 'wearables@2x.png'\"\n            alt=\"\"\n          />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@wearables_title\">\n          ON YOUR WAERABLES\n        </h4>\n        <p i18n=\"@@wearables_subtitle\">\n          Control your Anghami App from your wrist. Play your music, change the\n          volume and more on your watch.\n        </p>\n        <a\n          href=\"https://itunes.apple.com/us/app/anghami-%D8%A7%D9%86%D8%BA%D8%A7%D9%85%D9%8A/id545395155?mt=8\"\n          class=\"pr-4\"\n        >\n          <img class=\"img-fluid\" [src]=\"env + 'app-store.png'\" alt=\"\" />\n        </a>\n        <a\n          href=\"https://play.google.com/store/apps/details?id=com.anghami&hl=en\"\n        >\n          <img class=\"img-fluid\" [src]=\"env + 'google-play-btn.png'\" alt=\"\" />\n        </a>\n      </div>\n    </div>\n    <div\n      id=\"appletv-section\"\n      class=\"row product-section align-items-center\"\n      data-type=\"appletv-section\"\n    >\n      <div class=\"col-12 col-md-6\">\n        <div class=\"imgs-cntr\">\n          <img class=\"img-fluid bg\" [src]=\"env + 'red-shape@2x.png'\" alt=\"\" />\n          <img class=\"img-fluid main\" [src]=\"env + 'AppleTV@2x.png'\" alt=\"\" />\n        </div>\n      </div>\n      <div class=\"col-12 col-md-6 product-details\">\n        <h4 class=\"font-weight-bold\" i18n=\"@@appletv_title\">APPLE TV</h4>\n        <p i18n=\"@@appletv_subtitle\">\n          Enjoy the music you love in the heart of your home on your TV with\n          Apple TV. All your favorite artists right in your living room!\n        </p>\n      </div>\n    </div>\n    <div\n    id=\"tv-section\"\n    class=\"row product-section align-items-center\"\n    data-type=\"tv-section\"\n  >\n    <div class=\"col-12 col-md-6\">\n      <div class=\"imgs-cntr\">\n        <img class=\"img-fluid bg\" [src]=\"env + 'green-shape@2x.png'\" alt=\"\" />\n        <img\n          class=\"img-fluid main pt-5\"\n          [src]=\"env + 'SmartTV@2x.png'\"\n          alt=\"\"\n        />\n      </div>\n    </div>\n    <div class=\"col-12 col-md-6 product-details\">\n      <h4 class=\"font-weight-bold\" i18n=\"@@tvs_title\">\n        On TVs\n      </h4>\n      <p i18n=\"@@tvs_subtitle\">\n        Your living room is your new dance floor. Play your favorite songs, albums and playlists from your Samsung, Android and LG TVs and get that party started. \n      </p>\n    </div>\n  </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/modules/landing/products/products-routing.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/modules/landing/products/products-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: ProductsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsRoutingModule", function() { return ProductsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _products_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./products.component */ "./src/app/modules/landing/products/products.component.ts");




const routes = [
    {
        path: '',
        component: _products_component__WEBPACK_IMPORTED_MODULE_3__["ProductsComponent"]
    }
];
let ProductsRoutingModule = class ProductsRoutingModule {
};
ProductsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], ProductsRoutingModule);



/***/ }),

/***/ "./src/app/modules/landing/products/products.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/modules/landing/products/products.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.products-wrapper {\n  min-height: 1700px;\n}\n.products-wrapper .header-banner {\n  background-image: url('Webpage-product–header@2x.jpg');\n  height: 30em;\n}\n@media (max-width: 767.98px) {\n  .products-wrapper .header-banner {\n    height: auto;\n    min-height: 15em;\n    background-image: url('MOBILE–header–product@2x.jpg');\n  }\n}\n.products-wrapper .dynamic-section-menu {\n  position: relative;\n}\n.products-wrapper .dynamic-section-menu.fixed {\n  position: fixed;\n  top: 4em;\n  background-color: rgba(255, 255, 255, 0.9);\n  background-color: #fff;\n  box-shadow: 0px 1px 8px 0px rgba(199, 199, 199, 0.5);\n  z-index: 5;\n}\n.products-wrapper .dynamic-section-menu.fixed .row {\n  padding: 0.5rem 12rem !important;\n}\n.products-wrapper .dynamic-section-menu.fixed .product-item {\n  max-width: 7em;\n  padding: 0.5em 1rem;\n}\n.products-wrapper .dynamic-section-menu.fixed .product-item p {\n  font-size: 0.5rem;\n  margin-top: 0;\n}\n.products-wrapper .dynamic-section-menu .product-item {\n  cursor: pointer;\n  color: black;\n  padding: 1.5em;\n  text-align: center;\n  border-radius: 12px;\n  max-width: 8rem;\n}\n.products-wrapper .dynamic-section-menu .product-item.selected {\n  background-color: white;\n  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);\n}\n.products-wrapper .dynamic-section-menu .product-item.selected p {\n  font-weight: bold;\n}\n@media (max-width: 767.98px) {\n  .products-wrapper .dynamic-section-menu .product-item {\n    padding: 1em;\n    width: 7em;\n    margin: 0.5em;\n  }\n}\n.products-wrapper .dynamic-section-menu .product-item img {\n  width: 100%;\n}\n.products-wrapper .dynamic-section-menu .product-item p {\n  font-weight: normal;\n  margin-top: 1em;\n  margin-bottom: 0em;\n}\n@media (max-width: 767.98px) {\n  .products-wrapper .dynamic-section-menu .product-item p {\n    margin-top: 1em;\n    font-size: 0.9em;\n  }\n}\n.products-wrapper .product-section {\n  padding-bottom: 5rem;\n}\n.products-wrapper .product-section:nth-child(odd) .imgs-cntr .bg {\n  left: -8rem;\n}\n@media (max-width: 767.98px) {\n  .products-wrapper .product-section:nth-child(odd) .imgs-cntr .bg {\n    left: 0rem;\n  }\n}\n.products-wrapper .product-section:nth-child(even) {\n  -webkit-box-orient: horizontal !important;\n  -webkit-box-direction: reverse !important;\n      -ms-flex-direction: row-reverse !important;\n          flex-direction: row-reverse !important;\n}\n.products-wrapper .product-section:nth-child(even) .imgs-cntr .bg {\n  right: 1rem;\n}\n@media (max-width: 767.98px) {\n  .products-wrapper .product-section:nth-child(even) .imgs-cntr .bg {\n    right: 0rem;\n  }\n}\n.products-wrapper .product-section:nth-child(3) .imgs-cntr .main {\n  width: 90%;\n  padding-top: 6rem;\n}\n.products-wrapper .product-section:nth-child(5) .imgs-cntr .main {\n  padding-top: 5rem;\n}\n.products-wrapper .product-section:nth-child(6) .imgs-cntr .main {\n  padding-top: 5rem;\n}\n.products-wrapper .product-section:nth-child(7) .imgs-cntr .main {\n  padding-top: 8rem;\n}\n.products-wrapper .product-section:nth-child(8) .imgs-cntr .main {\n  padding-top: 5rem;\n}\n.products-wrapper .product-section:nth-child(10) .imgs-cntr .main {\n  padding-top: 6rem;\n}\n.products-wrapper .product-section .imgs-cntr {\n  position: relative;\n}\n@media (max-width: 767.98px) {\n  .products-wrapper .product-section .imgs-cntr {\n    text-align: center;\n    padding-top: 2rem;\n  }\n}\n.products-wrapper .product-section .imgs-cntr .main {\n  width: 75%;\n}\n.products-wrapper .product-section .imgs-cntr .bg {\n  position: absolute;\n  top: -1rem;\n  z-index: -10;\n}\n@media (max-width: 767.98px) {\n  .products-wrapper .product-section .product-details {\n    text-align: center;\n    padding-top: 4.5rem;\n  }\n}"

/***/ }),

/***/ "./src/app/modules/landing/products/products.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/modules/landing/products/products.component.ts ***!
  \****************************************************************/
/*! exports provided: ProductsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsComponent", function() { return ProductsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment_prod__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../environments/environment.prod */ "./src/environments/environment.prod.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");




let ProductsComponent = class ProductsComponent {
    constructor(render, document, elRef, platformId) {
        this.render = render;
        this.document = document;
        this.elRef = elRef;
        this.platformId = platformId;
        this.env = `${_environments_environment_prod__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN}img/products/`;
        this.env2 = `${_environments_environment_prod__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN}img/landing/`;
        this.os = '';
    }
    ngOnInit() {
        this.getOSName();
        if (Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["isDevMode"])()) {
            this.env = '../../../../assets/img/products/';
            this.env2 = '../../../../assets/img/landing/';
        }
    }
    ngAfterViewInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId) && this.document && this.document.scrollingElement) {
            let div_top;
            let section1;
            let section2;
            let section3;
            let section4;
            let section5;
            let section6;
            let section7;
            let section8;
            let dynamicMenuHeight;
            setTimeout(() => {
                div_top = this.dynamicSectionMenu.nativeElement.offsetTop;
                section1 = this.document.getElementById('iphone-section').offsetTop;
                section2 = this.document.getElementById('desktop-section').offsetTop;
                section3 = this.document.getElementById('speaker-section').offsetTop;
                section4 = this.document.getElementById('carplay-section').offsetTop;
                section5 = this.document.getElementById('chromecast-section').offsetTop;
                section6 = this.document.getElementById('ps-section').offsetTop;
                section7 = this.document.getElementById('wearables-section').offsetTop;
                section8 = this.document.getElementById('appletv-section').offsetTop;
                dynamicMenuHeight = this.dynamicSectionMenu.nativeElement.offsetHeight;
            }, 100);
            this.render.listen('window', 'scroll', event => {
                const scrollDistance = this.document.scrollingElement.scrollTop;
                if (scrollDistance > div_top) {
                    this.render.addClass(this.dynamicSectionMenu.nativeElement, 'fixed');
                    this.render.setStyle(this.virtualHeight.nativeElement, 'height', dynamicMenuHeight + 'px');
                }
                else {
                    this.render.removeClass(this.dynamicSectionMenu.nativeElement, 'fixed');
                    this.render.setStyle(this.virtualHeight.nativeElement, 'height', 0);
                }
                // Assign active class to nav links while scolling
                this.elRef.nativeElement
                    .querySelectorAll('.product-section')
                    .forEach(element => {
                    if (element.offsetTop - 170 <= scrollDistance) {
                        this.selectedSection = element.dataset.type;
                    }
                });
            });
        }
    }
    goToSection(section) {
        const scrollTo = this.document.getElementById(section).offsetTop;
        window.scrollTo({ left: 0, top: scrollTo - 170, behavior: 'smooth' });
    }
    getOSName() {
        if (window && window.navigator && window.navigator['userAgent']) {
            if (window.navigator.userAgent.indexOf('Windows') !== -1) {
                this.os = 'windows';
            }
            else if (window.navigator.userAgent.indexOf('Mac') !== -1) {
                this.os = 'mac';
            }
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('dynamicSectionMenu', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], ProductsComponent.prototype, "dynamicSectionMenu", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('virtualHeight', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], ProductsComponent.prototype, "virtualHeight", void 0);
ProductsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-products',
        template: __webpack_require__(/*! raw-loader!./products.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/products/products.component.html"),
        styles: [__webpack_require__(/*! ./products.component.scss */ "./src/app/modules/landing/products/products.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_3__["DOCUMENT"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"],
        Document,
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"],
        Object])
], ProductsComponent);



/***/ }),

/***/ "./src/app/modules/landing/products/products.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/modules/landing/products/products.module.ts ***!
  \*************************************************************/
/*! exports provided: ProductsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsModule", function() { return ProductsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _products_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./products-routing.module */ "./src/app/modules/landing/products/products-routing.module.ts");
/* harmony import */ var _products_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./products.component */ "./src/app/modules/landing/products/products.component.ts");





let ProductsModule = class ProductsModule {
};
ProductsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_products_component__WEBPACK_IMPORTED_MODULE_4__["ProductsComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _products_routing_module__WEBPACK_IMPORTED_MODULE_3__["ProductsRoutingModule"]]
    })
], ProductsModule);



/***/ })

}]);