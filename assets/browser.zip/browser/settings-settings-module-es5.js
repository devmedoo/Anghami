(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-settings-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/action-link/action-link.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/action-link/action-link.component.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n<ng-container *ngIf=\"!isEdit && !isVerify\">\n <span i18n=\"@@Change\" class=\"action-link\" (click)=\"submitChange.emit()\">Change</span>\n  </ng-container>\n  <ng-container *ngIf=\"isEdit && !isVerify\">\n    <span i18n=\"@@Edit\" class=\"action-link\" (click)=\"submitEdit.emit()\">Edit</span>\n  </ng-container>\n  <ng-container *ngIf=\"isVerify && !isEdit\">\n    <span i18n=\"@@Verify\" class=\"action-link\" (click)=\"submitVerify.emit()\">Verify</span>\n  </ng-container>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/audio-quality/audio-quality.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/audio-quality/audio-quality.component.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngFor=\"let item of audioQualitySet; let i = index\">\n  <div class=\"custom-control custom-radio\">\n    <input\n      class=\"custom-control-input\"\n      type=\"radio\"\n      [checked]=\"this.value == i\"\n      (change)=\"changeAudioQuality(i)\"\n    />\n    <label class=\"custom-control-label \" (click)=\"changeAudioQuality(i)\">\n      <span class=\"title\" [ngClass]=\"{ 'selected-title': this.value == i }\">{{\n        item.title\n      }}</span\n      ><br />\n      <span class=\"subtitle\">{{ item.subtitle }}</span\n      ><br />\n    </label>\n  </div>\n</ng-container>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/logs-modal/logs-modal.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/logs-modal/logs-modal.component.html ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"modal-header\">\n  <h4 class=\"modal-title\" i18n=\"@@Report a problem\">Report a problem</h4>\n  <button type=\"button\" class=\"close\" aria-label=\"Close\" (click)=\"activeModal.dismiss('Cross click')\">\n    <span aria-hidden=\"true\">&times;</span>\n  </button>\n</div>\n<div class=\"modal-body p-3\">\n  <label for=\"supportType\" i18n=\"@@help_ask_us\">How can we help you?</label>\n  <select class=\"form-control form-input\" id=\"supportType\" [(ngModel)]=\"supportType\" (ngModelChange)=\"clearErrMsg()\">\n    <option i18n=\"@@help_feature_request\">Feature Request</option>\n    <option i18n=\"@@help_feedback\">Feedback</option>\n    <option i18n=\"@@help_bug_report\">Bug Report</option>\n    <option i18n=\"@@help_account_issue\">Account Issue</option>\n    <option i18n=\"@@help_billing_sub_issue\">Billing or Subscription Issue</option>\n    <option i18n=\"@@help_music_suggestion\">Music Suggestion</option>\n    <option i18n=\"@@help_other\">Other</option>\n  </select>\n  <br />\n  <label for=\"userDescription\" i18n=\"@@help_tellus_more\">Tell us more</label>\n  <textarea class=\"form-control form-input\" id=\"userDescription\" rows=\"4\" [(ngModel)]=\"userDescription\"\n    (ngModelChange)=\"clearErrMsg()\"></textarea>\n  <br />\n  <p i18n=\"@@help_detailed_desc\">Please provide us with a detailed description and we will get back to you as soon as\n    possible.</p>\n  <div class=\"err\">{{ errorMsg }}</div>\n</div>\n<div class=\"modal-footer\">\n  <div class=\"send-btn flex-shrink-1\">\n    <button (click)=\"submitReport()\" class=\"anghami-primary-btn\" i18n=\"@@Submit\">\n      Submit\n    </button>\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/account-settings/account-settings.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/settings/account-settings/account-settings.component.html ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"white-box\" *ngIf=\"subscriptions && subscriptions.length > 0\">\n  <div class=\"flexbox flex-column\">\n    <div class=\"flexbox px-0 pb-2 pt-0 w-100\">\n      <span i18n=\"@@my_subscriptions\" class=\"label-fixed\">My Subscription</span>\n      <a href=\"https://www.anghami.com/manage-account\" target=\"_blank\">\n        <span i18n=\"@@manage_account\" class=\"action-link\">Manage my subscriptions</span>\n      </a>\n    </div>\n    <ng-container>\n      <div class=\"flexbox px-0 justify-content-start py-1 w-100\" *ngFor=\"let sub of subscriptions\">\n        <anghami-icon class=\"icon check\" [data]=\"'check'\"></anghami-icon>\n        <span class=\"sm-description sm-font\">{{ sub.plan_name }}</span>\n      </div>\n    </ng-container>\n  </div>\n</div>\n<div class=\"white-box\">\n  <div class=\"flexbox\" [ngClass]=\"{'pb-2': isVerifyMsidn}\">\n    <div i18n=\"@@Your phone number\" class=\"label-fixed width-6\" [ngClass]=\"{'pb-5e': isVerifyMsidn && errorMsg, 'pb-4e': isVerifyMsidn && !errorMsg}\">Your phone number</div>\n    <div class=\"flexbox py-0 px-0\" [ngClass]=\"{'w-50': !editPhonenumber, 'width-55': isVerifyMsidn}\">\n      <ng-container *ngIf=\"!editPhonenumber\">\n        <div class=\"flexbox py-0 px-0 w-100\">\n          <div>{{ user?.msidn }}</div>\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"editPhonenumber\">\n        <div class=\"flexbox justify-content-start px-0 py-0 w-100\">\n          <div [ngClass]=\"{'flexbox': isVerifyMsidn, 'flex-column': isVerifyMsidn, 'px-0': isVerifyMsidn, 'py-0': isVerifyMsidn, 'w-100': isVerifyMsidn}\">\n            <div class=\"msidn flexbox input-box-border py-2 w-100\">\n              <ng-container *ngIf=\"!isVerifyMsidn\">\n                <span class=\"inline-box login-input-flag\">\n                  <select (ngModelChange)=\"setTelco($event)\" [(ngModel)]=\"selectedtelco\">\n                    <option *ngFor=\"let telco of telcoLst\" [ngValue]=\"telco\">{{ telco?.operatorname }}</option>\n                  </select>\n                  <img class=\"logo telco\" [src]=\"selectedtelco?.image\" />\n                </span>\n                <div class=\"flexbox px-2 py-0\">\n                  <span class=\"prefix px-1\" *ngIf=\"selectedtelco?.prefix!==''\">+{{ selectedtelco?.prefix }}\n                  </span>\n                  <input *ngIf=\"isDeviceMobile\" placeholder=\"Please enter your mobile number\" i18n-placeholder=\"@@Please enter your mobile number\"\n                    class=\"hidden-input form-control\" type=\"tel\" pattern=\"^[0-9]*$\" maxLength=\"17\" required id=\"msidnId\" [(ngModel)]=\"msidnUpdated\"\n                    (ngModelChange)=\"clearError()\" />\n                  <!-- TODO: maxLength=\"17\" to be fixed -->\n                  <input *ngIf=\"!isDeviceMobile\" placeholder=\"Please enter your mobile number\" i18n-placeholder=\"@@Please enter your mobile number\"\n                    class=\"hidden-input form-control\" id=\"msidnId\" [(ngModel)]=\"msidnUpdated\" (ngModelChange)=\"clearError()\"\n                    (keypress)=\"handleConditions($event, msidnConditions)\" />\n                </div>\n              </ng-container>\n              <ng-container *ngIf=\"isVerifyMsidn\">\n                <!-- TODO: add translation for verification code placeholder -->\n                <input *ngIf=\"isDeviceMobile\" placeholder=\"Please enter your verification code\" i18n-placeholder=\"@@Please enter your mobile number\"\n                  class=\"hidden-input form-control\" id=\"msidnCodeId\" [(ngModel)]=\"msidnCode\" (ngModelChange)=\"clearError()\"\n                  pattern=\"\\d*\" [maxLength]=\"10\" />\n                <input *ngIf=\"!isDeviceMobile\" placeholder=\"Please enter your verification code\" i18n-placeholder=\"@@Please enter your mobile number\"\n                  class=\"hidden-input form-control\" id=\"msidnCodeId\" [(ngModel)]=\"msidnCode\" (ngModelChange)=\"clearError()\"\n                  (keypress)=\"handleConditions($event, msidnCodeConditions)\" />\n              </ng-container>\n            </div>\n            <div *ngIf=\"isVerifyMsidn || errorMsg\" class=\"px-0 py-0 flexbox flex-column w-100\">\n              <div class=\"flexbox flex-column py-2 px-2 w-100\">\n                <ng-container *ngIf=\"errorMsg\">\n                  <div class=\"sm-font err\">{{ errorMsg }}</div>\n                </ng-container>\n                <ng-container *ngIf=\"isVerifyMsidn\">\n                  <div class=\"flexbox justify-content-start px-0 py-0 w-100\">\n                    <span i18n=\"@@Didn't receive the code yet?\">Didn't receive the code yet?</span>&nbsp;\n                    <div *ngIf=\"disabledTimer>0\" class=\"retry\">\n                      <span i18n=\"@@Retry in\">Retry in</span>&nbsp;{{ disabledTimer }}\n                    </div>\n                  </div>\n                  <div class=\"flexbox justify-content-start py-0 px-0 w-100\">\n                    <div i18n=\"@@Resend\" class=\"pointer font-weight-bold\" [ngClass]=\"{'disabled': disabledTimer>0}\" (click)=\"resend()\">Resend</div>\n                  </div>\n                </ng-container>\n              </div>\n            </div>\n          </div>\n        </div>\n      </ng-container>\n    </div>\n    <div [ngClass]=\"{'pb-5e': isVerifyMsidn && errorMsg, 'pb-4e': isVerifyMsidn && !errorMsg}\">\n      <anghami-action-link [isEdit]=\"!editPhonenumber\" [isVerify]=\"isVerifyMsidn\" (submitVerify)=\"changePhonenumber('verify')\"\n        (submitChange)=\"changePhonenumber()\" (submitEdit)=\"editPhonenumber=true;editEmail=false;editPassword=false\"></anghami-action-link>\n    </div>\n  </div>\n  <hr>\n  <div class=\"flexbox\">\n    <div i18n=\"@@Change email\" class=\"label-fixed width-6\">Change email</div>\n    <div class=\"flexbox py-0 px-0\" [ngClass]=\"{'w-50': !editEmail, 'width-55': editEmail}\">\n      <ng-container *ngIf=\"!editEmail\">\n        <div class=\"flexbox py-0 px-0 w-100\">\n          <div>{{ user?.email }}</div>\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"editEmail\">\n        <div class=\"flexbox justify-content-start px-0 py-0 w-100\">\n          <div class=\"flexbox input-box-border py-0 w-100\">\n            <input placeholder=\"Please enter your email\" i18n-placeholder=\"@@Please enter your email\" class=\"hidden-input form-control py-2\"\n              id=\"emailid\" [(ngModel)]=\"emailUpdated\" />\n            <div class=\"cancel-change\" (click)=\"cancelChange()\">\n              <div aria-hidden=\"true\" class=\"close\">&times;</div>\n            </div>\n          </div>\n        </div>\n      </ng-container>\n    </div>\n    <div>\n      <anghami-action-link [isEdit]=\"!editEmail\" (submitChange)=\"changeEmail()\" (submitEdit)=\"editEmail=true;editPassword=false;editPhonenumber=false\"></anghami-action-link>\n    </div>\n  </div>\n  <hr>\n  <div class=\"flexbox align-items-start\">\n    <div i18n=\"@@Change password\" class=\"label-fixed pt-2 width-6\">Change password</div>\n    <div class=\"flexbox flex-column py-0 px-0\" [ngClass]=\"{'w-50': !editPassword}\">\n      <ng-container *ngIf=\"!editPassword\">\n        <div class=\"flexbox py-0 px-0 w-100 pt-2\">\n          <div>••••••••</div>\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"editPassword\">\n        <div class=\"flexbox py-0 px-0 w-100 pb-2\">\n          <div i18n=\"@@Current password\" class=\"nowrap mx-3 pb-25\">Current password</div>\n          <div>\n            <div class=\"flexbox input-box-border py-0\">\n              <input type=\"password\" class=\"hidden-input form-control py-2\" id=\"currentpassid\" [(ngModel)]=\"currentPassword\" autocomplete=\"on\"\n              />\n            </div>\n            <div class=\"action-link sm-font py-2 px-2\">\n              <a href=\"https://www.anghami.com/forgotpassword\">\n                <span class=\"action-link\" i18n=\"@@Forgot your Password?\">Forgot your password?</span>\n              </a>\n            </div>\n          </div>\n        </div>\n        <div class=\"flexbox py-0 px-0 w-100 pb-2\">\n          <div i18n=\"@@New password\" class=\"nowrap mx-3\">New password</div>\n          <div class=\"flexbox input-box-border py-0 justify-content-start\">\n            <input type=\"password\" class=\"hidden-input form-control py-2\" id=\"newpassid\" [(ngModel)]=\"updatedPassword\" (ngModelChange)=\"checkPasswordStrength(updatedPassword)\"\n            />\n            <div [ngClass]=\"passStrength\" class=\"sm-font font-weight-bold\">{{ passStrength }}</div>\n          </div>\n        </div>\n        <div class=\"flexbox py-0 px-0 w-100\">\n          <div i18n=\"@@confirm_password\" class=\"nowrap mx-3\">Confirm password</div>\n          <div class=\"flexbox input-box-border py-0 justify-content-start\" [ngClass]=\"{'input-err': matchErr}\">\n            <input type=\"password\" class=\"hidden-input form-control py-2\" id=\"confirmpassid\" [(ngModel)]=\"confirmPassword\" (ngModelChange)=\"checkPasswordMatch()\"\n            />\n          </div>\n        </div>\n      </ng-container>\n    </div>\n    <div class=\"pt-2\">\n      <anghami-action-link [isEdit]=\"!editPassword\" (submitChange)=\"changePassword()\" (submitEdit)=\"editPassword=true;editEmail=false;editPhonenumber=false\"></anghami-action-link>\n    </div>\n  </div>\n</div>\n<div class=\"white-box\">\n  <div class=\"flexbox\">\n    <span i18n=\"@@private_profile\" class=\"label-fixed\">Private Profile</span>\n    <label class=\"switch-updated\">\n      <input type=\"checkbox\" [(ngModel)]=\"!isPublicProfile\" (ngModelChange)=\"changeProfileStatus()\" />\n      <span class=\"slider round\"></span>\n    </label>\n  </div>\n  <hr>\n  <div class=\"flexbox pb-2\">\n    <span i18n=\"@@auto_stories_title\" class=\"label-fixed\">Auto-add stories</span>\n    <label class=\"switch-updated\">\n      <input type=\"checkbox\" [(ngModel)]=\"isAutoStories\" (ngModelChange)=\"autoAddStories()\" />\n      <span class=\"slider round\"></span>\n    </label>\n  </div>\n  <div class=\"flexbox pt-0\">\n    <div i18n=\"@@auto_stories_sub\" class=\"sub\">Music you recently played will be automatically added to your Stories</div>\n  </div>\n</div>\n<!-- <div class=\"white-box\" hidden=\"true\">\n  <div class=\"flexbox\">\n    <div class=\"flexbox justify-content-start px-0 py-0\">\n      <img class=\"icon\" src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/settings/google-icon.png\">\n      <span i18n=\"@@connect_google\" class=\"mx-3 label-fixed\">Connect to Google</span>\n    </div>\n    <span i18n=\"@@Connect\" class=\"action-link\" (click)=\"connectAccount('google')\">Connect</span>\n  </div>\n  <hr>\n  <div class=\"flexbox\">\n    <div class=\"flexbox justify-content-start px-0 py-0\">\n      <div class=\"fb-bgd\">\n        <anghami-icon\n          class=\"icon facebook\"\n          [data]=\"'facebook'\"\n        ></anghami-icon>\n      </div>\n      <span i18n=\"@@connect to facebook\" class=\"mx-3 label-fixed\">Connect to Facebook</span>\n    </div>\n    <span i18n=\"@@Connect\" class=\"action-link\" (click)=\"connectAccount('facebook')\">Connect</span>\n  </div>\n</div> -->"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/app-settings/app-settings.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/settings/app-settings/app-settings.component.html ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"white-box\">\n  <div class=\"flexbox no-padding\">\n    <div i18n=\"@@App Language\" class=\"label-fixed\">App Language</div>\n    <div class=\"flexbox language px-0 py-0\">\n      <div class=\"custom-control custom-radio\" *ngFor=\"let language of languagesLst\">\n        <input type=\"checkbox\" name=\"lang\" class=\"custom-control-input\" [checked]=\"selectedLang===language.code\"\n          [attr.disabled]=\"selectedLang===language.code? true : null\" (change)=\"changeLang(language)\"\n          [id]=\"'language-'+language.code\">\n        <label [for]=\"'language-'+language.code\" class=\"custom-control-label\">\n          {{ language.label }}\n        </label>\n      </div>\n    </div>\n  </div>\n  <hr>\n  <div class=\"flexbox arabic-letters no-padding\" *ngIf=\"selectedLang!=='ar'\">\n    <span i18n=\"@@Arabic songs show with\" class=\"label-fixed\">Arabic songs show with</span>\n    <div class=\"flexbox language px-0 py-0\">\n      <div class=\"custom-control custom-radio\" *ngFor=\"let letters of lettersLst\">\n        <input #displayLetter type=\"checkbox\" class=\"custom-control-input\" name=\"letters\" [id]=\"'letters-'+letters.code\"\n          [checked]=\"selectedDisplay==letters.code\" [attr.disabled]=\"selectedDisplay===letters.code? true : null\"\n          (change)=\"changeArabicDisplay(letters, displayLetter)\">\n        <label class=\"custom-control-label\" [for]=\"'letters-'+letters.code\">\n          {{ letters.label }}\n        </label>\n      </div>\n    </div>\n  </div>\n</div>\n<div class=\"white-box flexbox\">\n  <span i18n=\"@@dark_mode\" class=\"label-fixed\">Dark Mode</span>\n  <label class=\"switch\">\n    <input type=\"checkbox\" [(ngModel)]=\"isDarkMode\" (ngModelChange)=\"toggleDarkMode()\" [checked]=\"isDarkMode\"\n      (click)=\"toggleClick($event)\" />\n    <span class=\"slider round\"></span>\n  </label>\n</div>\n<div class=\"white-box\" *ngIf=\"isSWEnabled\">\n  <div class=\"flexbox pb-2\">\n    <span i18n=\"@@web_notifications_settings_title\" class=\"label-fixed\">Notifications</span>\n    <label class=\"switch\">\n      <input type=\"checkbox\" [(ngModel)]=\"isGrantedNotifications\" (ngModelChange)=\"toggleNotificationsPermission()\" [checked]=\"isGrantedNotifications\"\n        (click)=\"toggleClick($event)\" />\n      <span class=\"slider round\"></span>\n    </label>\n  </div>\n  <div class=\"flexbox pt-0\">\n    <div i18n=\"@@web_notifications_settings_desc\" class=\"sub\">Turn on receiving notifications on web and the Desktop App</div>\n  </div>\n</div>\n<ng-container *ngIf=\"isDesktopApp\">\n  <div class=\"white-box flexbox\" *ngIf=\"isMac && showAccessibilityClientButton\">\n    <!-- *ngIf=\"showAccessibilityClientButton\" -->\n    <div class=\"flexbox colm start px-0 py-0\">\n      <span i18n=\"@@enable_trusted_accessibility_client\" class=\"label-fixed\">Enable Anghami as trusted accessibility\n        client</span>\n      <span i18n=\"@@enable_trusted_accessibility_client_desc\" class=\"description py-1\">Allow Anghami to use keyboard\n        shortcuts</span>\n    </div>\n    <div class=\"flexbox colm end px-0 py-0\">\n      <span i18n=\"@@Enable\" class=\"action-link py-1\" (click)=\"enableTrustedAccessibilityClient()\">Enable</span>\n    </div>\n  </div>\n</ng-container>\n<div class=\"white-box flexbox\" [class.gray-scale-disabled]=\"checkingForUpdates\">\n  <div class=\"flexbox colm start px-0 py-0\">\n    <span i18n=\"@@check_updates\" class=\"label-fixed\">Check for updates</span>\n  </div>\n  <div class=\"flexbox colm end px-0 py-0\">\n    <span i18n=\"@@check\" class=\"action-link py-1\" (click)=\"checkForUpdates()\">Check</span>\n  </div>\n</div>\n<div class=\"white-box flexbox\">\n  <div class=\"flexbox colm start px-0 py-0\">\n    <span i18n=\"@@Clear cache\" class=\"label-fixed\">Clear Cache</span>\n  </div>\n  <div class=\"flexbox colm end px-0 py-0\">\n      <span i18n=\"@@Clear cache\" class=\"action-link py-1\" (click)=\"clearCache()\">Clear Cache</span>\n  </div>\n</div>\n<div class=\"white-box\">\n  <a href=\"https://support.anghami.com/hc/{{selectedLang}}\" target=\"_blank\" class=\"flexbox\">\n    <div class=\"flexbox justify-content-start px-0 py-0\">\n      <anghami-icon class=\"icon\" [data]=\"'help'\"></anghami-icon>\n      <span class=\"label-fixed px-2\" i18n=\"@@go_to_help_center\">Go to help center</span>\n    </div>\n    <anghami-icon class=\"icon arrow-left\" [data]=\"'arrow-left'\"></anghami-icon>\n  </a>\n</div>\n<div class=\"white-box flexbox pointer\" (click)=\"openLogReportModal()\">\n  <div class=\"flexbox justify-content-start px-0 py-0\">\n    <anghami-icon class=\"icon\" [data]=\"'report-problem'\"></anghami-icon>\n    <span class=\"label-fixed px-2\" i18n=\"@@Report a problem\">Report a problem</span>\n  </div>\n  <anghami-icon class=\"icon arrow-left\" [data]=\"'arrow-left'\"></anghami-icon>\n</div>\n<div class=\"white-box\">\n  <a href=\"https://www.anghami.com/gifts\" target=\"_blank\" class=\"flexbox\">\n    <div class=\"flexbox justify-content-start px-0 py-0\">\n      <anghami-icon class=\"icon\" [data]=\"'gift'\"></anghami-icon>\n      <span class=\"label-fixed px-2\" i18n=\"@@buy_gift\">Buy gift</span>\n    </div>\n    <anghami-icon class=\"icon arrow-left\" [data]=\"'arrow-left'\"></anghami-icon>\n  </a>\n</div>\n<div class=\"version p-2\" *ngIf=\"isDesktopApp\">\n  <span i18n=\"@@help_anghami_version\">Anghami Version</span> {{appVersion}}\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/music-settings/music-settings.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/settings/music-settings/music-settings.component.html ***!
  \**************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"!audioQuality\">\n  <div class=\"white-box flexbox cursor-btn\" (click)=\"audioQuality=true;showLfpublish=false;\">\n    <span\n      i18n=\"@@audio_quality\"\n      class=\"label-fixed\"\n    >Audio Quality</span>\n    <anghami-icon\n      class=\"icon arrow-left\"\n      [data]=\"'arrow-left'\"\n    ></anghami-icon>\n  </div>\n  <div class=\"white-box\" hidden=\"true\">\n    <div class=\"flexbox\">\n      <span i18n=\"dark_mode\">Auto Downloads</span>\n      <label class=\"switch\">\n        <input type=\"checkbox\" [(ngModel)]=\"musicSettings.isAutoDownload\" />\n        <span class=\"slider round\"></span>\n      </label>\n    </div>\n  </div>\n  <div class=\"white-box\">\n    <ng-container *ngIf=\"false\">\n      <div class=\"flexbox\">\n        <span i18n=\"@@Music recommendations\">Private music activity</span>\n        <label class=\"switch\">\n          <input\n            type=\"checkbox\"\n            [(ngModel)]=\"musicSettings.privatemusic\"\n            (ngModelChange)=\"changeMusicPreferences()\"\n          />\n          <span class=\"slider round\"></span>\n        </label>\n      </div>\n      <hr>\n      <div class=\"flexbox\">\n        <span i18n=\"@@Friends Activity\">Crossfade between songs</span>\n        <label class=\"switch\">\n          <input\n            type=\"checkbox\"\n            [(ngModel)]=\"musicSettings.crossfade\"\n            (ngModelChange)=\"changeMusicPreferences()\"\n          />\n          <span class=\"slider round\"></span>\n        </label>\n      </div>\n      <hr>\n      <div class=\"flexbox\">\n        <span i18n=\"@@Followed playlists updated\">Nonstop music</span>\n        <label class=\"switch\">\n          <input\n            type=\"checkbox\"\n            [(ngModel)]=\"musicSettings.nonstopmusic\"\n            (ngModelChange)=\"changeMusicPreferences()\"/>\n          <span class=\"slider round\"></span>\n        </label>\n      </div>\n      <hr>\n    </ng-container>\n    <div class=\"flexbox\">\n      <span i18n=\"@@Hide explicit songs\" class=\"label-fixed\">Hide explicit songs</span>\n      <label class=\"switch\">\n        <input\n          [disabled]=\"musicSettings.disableHideExplicitContent\"\n          type=\"checkbox\"\n          [(ngModel)]=\"musicSettings.explicit\"\n          (ngModelChange)=\"changeMusicPreferences()\"/>\n        <span class=\"slider round\"></span>\n      </label>\n    </div>\n  </div>\n  <div class=\"white-box\">\n    <div class=\"flexbox\">\n      <div class=\"flexbox justify-content-start px-0 py-0\">\n        <img class=\"icon\" src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/settings/spotify-icon.png\">\n        <span i18n=\"@@spotify_import\" class=\"mx-3 label-fixed\">Import Music from Spotify to Anghami</span>\n      </div>\n      <span i18n=\"@@Import\" class=\"action-link\" (click)=\"importMusic('spotify')\">Import</span>\n    </div>\n    <!-- <hr>\n    <div class=\"flexbox\">\n      <div class=\"flexbox justify-content-start px-0 py-0\">\n        <img class=\"icon\" src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/settings/youtube-icon.png\">\n        <span i18n=\"@@youtube_import\" class=\"mx-3 label-fixed\">Import Music from Youtube to Anghami</span>\n      </div>\n      <span i18n=\"@@Import\" class=\"action-link\" (click)=\"importMusic('youtube')\">Import</span>\n    </div> -->\n    <hr>\n    <div class=\"flexbox\">\n      <div class=\"flexbox justify-content-start px-0 py-0\">\n        <img class=\"icon\" src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/settings/deezer.png\">\n        <span i18n=\"@@deezer_import\" class=\"mx-3 label-fixed\">Import Music from Deezer to Anghami</span>\n      </div>\n      <span i18n=\"@@Import\" class=\"action-link\" (click)=\"importMusic('deezer')\">Import</span>\n    </div>\n  </div>\n  <div class=\"white-box\">\n    <ng-container *ngIf=\"false\">\n      <div class=\"flexbox\">\n        <span i18n=\"dark_mode\">Tweet as they play</span>\n        <label class=\"switch\">\n          <input type=\"checkbox\" [(ngModel)]=\"musicSettings.tweet\" />\n          <span class=\"slider round\"></span>\n        </label>\n      </div>\n      <hr>\n    </ng-container>\n    <div class=\"flexbox flex-column cursor-btn align-items-start\">\n      <div class=\"flexbox px-0 py-0 w-100\" (click)=\"showLfpublish=!showLfpublish\">\n        <span\n          i18n=\"@@Scrobble to Last.fm\"\n          class=\"label-fixed\"\n        >Scrobble to Last.fm</span>\n        <anghami-icon\n          class=\"icon arrow-left\"\n          [data]=\"'arrow-left'\"\n          [ngClass]=\"{'show-frm': showLfpublish}\"\n        ></anghami-icon>\n      </div>\n      <ng-container *ngIf=\"showLfpublish\">\n        <ng-container *ngIf=\"musicSettings.lfpublish\">\n          <div class=\"button-box max-width-55\">\n            <div\n              i18n=\"@@Disconnect\"\n              class=\"anghami-primary-btn\"\n              (click)=\"scrobbleLastFm()\">\n              Disconnect\n            </div>\n          </div>\n        </ng-container>\n        <ng-container *ngIf=\"!musicSettings.lfpublish\">\n          <form\n            class=\"flexbox px-0 py-0 pt-4 flex-column w-100\"\n            autocomplete=\"on\"\n            [formGroup]=\"lastfmForm\"\n          >\n            <div class=\"flexbox lastfmfrm px-0 py-0 w-100\">\n              <div class=\"flexbox px-0 py-0 w-100\">\n                <label i18n=\"@@username\" class=\"font-weight-bold\">Username</label>\n                <span\n                  class=\"mx-3 input-box-border\"\n                  [ngClass]=\"{'input-err': hasErr('username')}\"\n                >\n                  <input\n                    class=\"hidden-input form-control\"\n                    autocomplete=\"on\"\n                    placeholder=\"Enter your username\"\n                    i18n-placeholder=\"@@Enter your username\"\n                    autofocus=\"true\"\n                    required\n                    formControlName=\"username\"\n                  />\n                </span>\n              </div>\n              <div class=\"flexbox px-0 py-0 w-100\">\n                <label i18n=\"@@Password\" class=\"font-weight-bold\">Password</label>\n                <span class=\"mx-3 input-box-border\" [ngClass]=\"{'input-err': hasErr('password')}\">\n                  <input class=\"hidden-input form-control\" i18n-placeholder=\"@@Enter your password\" placeholder=\"Enter your password\" autocomplete=\"on\"\n                    type=\"password\" required formControlName=\"password\" />\n                </span>\n              </div>\n            </div>\n            <div i18n=\"@@Connect\" class=\"anghami-primary-btn mt-3\" (click)=\"scrobbleLastFm()\">\n              Connect\n            </div>\n            <div *ngIf=\"errorMsg && errorMsg !== ''\" class=\"pt-2 err sm-font\">{{ errorMsg }}</div>\n          </form>\n        </ng-container>\n      </ng-container>\n    </div>\n  </div>\n</ng-container>\n<ng-container *ngIf=\"audioQuality\">\n  <div class=\"flexbox justify-content-start max-width-55 m2-auto px-0 py-0\">\n    <div class=\"flexbox justify-content-start px-0 py-0 cursor-btn\" (click)=\"audioQuality=false\">\n      <anghami-icon class=\"icon arrow\" [data]=\"'arrow-left'\" (click)=\"audioQuality=true\"></anghami-icon>\n      <span class=\"md-font px-2 dark-gray\">\n        <span i18n=\"@@Music\">Music</span> / </span>\n    </div>\n    <span i18n=\"@@audio_quality\" class=\"font-weight-bold lg-font\">Audio Quality</span>\n  </div>\n  <div class=\"white-box\">\n    <div class=\"title label-fixed\" i18n=\"@@streaming\">Streaming</div>\n    <div class=\"subtitle description\" i18n=\"@@audioquality_desc\">The higher the quality, the more data it consumes. The lower the quality, the less data it consumes.</div>\n    <div class=\"audio-selector\">\n      <anghami-audio-quality [userAudioSettings]=\"userAudioStreamingSettings\" (audioChanged)=\"audioQualityChanged('stream', $event)\"></anghami-audio-quality>\n    </div>\n  </div>\n  <div class=\"white-box\">\n    <div class=\"title label-fixed\" i18n=\"@@Downloads\">Downloads</div>\n    <div class=\"subtitle description\" i18n=\"@@audioquality_desc\">The higher the quality, the more data it consumes. The lower the quality, the less data it consumes.</div>\n    <div class=\"audio-selector\">\n      <anghami-audio-quality [userAudioSettings]=\"userAudioDownloadSettings\" (audioChanged)=\"audioQualityChanged('download',$event)\"></anghami-audio-quality>\n    </div>\n  </div>\n</ng-container>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/notifications-settings/notifications-settings.component.html":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/settings/notifications-settings/notifications-settings.component.html ***!
  \******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"white-box\">\n  <div class=\"flexbox\">\n    <span i18n=\"@@Music recommendations\">Music recommendations</span>\n    <label class=\"switch\">\n      <input \n        type=\"checkbox\"\n        [(ngModel)]=\"notificationSettings.music\"\n        (ngModelChange)=\"changeUserPreferences()\"\n      />\n      <span class=\"slider round\"></span>\n    </label>\n  </div>\n  <hr>\n  <div class=\"flexbox\">\n    <span i18n=\"@@Friends Activity\">Friends Activity</span>\n    <label class=\"switch\">\n      <input\n        type=\"checkbox\"\n        [(ngModel)]=\"notificationSettings.friends\"\n        (ngModelChange)=\"changeUserPreferences()\"\n      />\n      <span class=\"slider round\"></span>\n    </label>\n  </div>\n  <hr>\n  <div class=\"flexbox\">\n    <span i18n=\"@@Followed playlists updated\">Followed playlists updated</span>\n    <label class=\"switch\">\n      <input \n        type=\"checkbox\"\n        [(ngModel)]=\"notificationSettings.playlists\"\n        (ngModelChange)=\"changeUserPreferences()\"/>\n      <span class=\"slider round\"></span>\n    </label>\n  </div>\n  <hr>\n  <div class=\"flexbox\">\n    <span i18n=\"@@special_offers_marketing\">Special offers and marketing</span>\n    <label class=\"switch\">\n      <input \n        type=\"checkbox\"\n        [(ngModel)]=\"notificationSettings.offers\"\n        (ngModelChange)=\"changeUserPreferences()\"/>\n      <span class=\"slider round\"></span>\n    </label>\n  </div>\n  <div class=\"flexbox\" hidden=\"true\">\n    <span>Chats and reactions</span> <!-- TODO: add i18n translations -->\n    <label class=\"switch\">\n      <input \n        type=\"checkbox\"\n        [(ngModel)]=\"notificationSettings.messaging_notifications\"\n        (ngModelChange)=\"changeUserPreferences()\"/>\n      <span class=\"slider round\"></span>\n    </label>\n  </div>\n</div>\n\n\n<div class=\"button-box max-width-55\">\n  <div \n    i18n=\"@@save_changes\"\n    class=\"save-btn\"\n    [ngClass]=\"{ 'disabled': !isUpdated }\" \n    (click)=\"saveChanges()\">\n    Save changes\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/settings.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/settings/settings.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main\">\n<ngb-tabset #settings=\"ngbTabset\" [activeId]=\"activeTab\" (tabChange)=\"changedTab($event)\">\n  <ngb-tab id=\"app-settings\">\n    <ng-template ngbTabTitle>\n      <span class=\"tab-label\" (click)=\"onAppTabLabelClick()\" >{{ 'app' | translate }}</span>\n    </ng-template>\n    <ng-template ngbTabContent>\n      <anghami-app-settings (submit)=\"appSettingsChange($event)\"></anghami-app-settings>\n    </ng-template>\n  </ngb-tab>\n  <ngb-tab id=\"account-settings\">\n    <ng-template ngbTabTitle>\n      <span\n        class=\"tab-label\"\n      >{{ 'account' | translate }}</span>\n    </ng-template>\n    <ng-template ngbTabContent>\n      <anghami-account-settings (submit)=\"accountPreferencesChange($event)\"></anghami-account-settings>\n    </ng-template>\n  </ngb-tab>\n  <ngb-tab id=\"music-settings\">\n    <ng-template ngbTabTitle>\n      <span\n        class=\"tab-label\"\n      >{{ 'music' | translate }}</span>\n    </ng-template>\n    <ng-template ngbTabContent>\n      <anghami-music-settings (submit)=\"musicPreferencesChange($event)\"></anghami-music-settings>\n    </ng-template>\n  </ngb-tab>\n  <ngb-tab id=\"notifications-settings\">\n    <ng-template ngbTabTitle>\n      <span \n        class=\"tab-label\"\n      >{{ 'notifications' | translate }}</span>\n    </ng-template>\n    <ng-template ngbTabContent>\n      <anghami-notifications-settings (submit)=\"notificationsChange($event)\"></anghami-notifications-settings>\n    </ng-template>\n  </ngb-tab>\n</ngb-tabset>\n</div>"

/***/ }),

/***/ "./src/app/core/components/action-link/action-link.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/core/components/action-link/action-link.component.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/core/components/action-link/action-link.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/core/components/action-link/action-link.component.ts ***!
  \**********************************************************************/
/*! exports provided: ActionLinkComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActionLinkComponent", function() { return ActionLinkComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ActionLinkComponent = /** @class */ (function () {
    function ActionLinkComponent() {
        this.submitEdit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.submitChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.submitVerify = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    ActionLinkComponent.prototype.ngOnInit = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], ActionLinkComponent.prototype, "submitEdit", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], ActionLinkComponent.prototype, "submitChange", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], ActionLinkComponent.prototype, "submitVerify", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ActionLinkComponent.prototype, "isEdit", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ActionLinkComponent.prototype, "isVerify", void 0);
    ActionLinkComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-action-link',
            template: __webpack_require__(/*! raw-loader!./action-link.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/action-link/action-link.component.html"),
            styles: [__webpack_require__(/*! ./action-link.component.scss */ "./src/app/core/components/action-link/action-link.component.scss"), __webpack_require__(/*! ../../../modules/base/settings/settings.component.scss */ "./src/app/modules/base/settings/settings.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ActionLinkComponent);
    return ActionLinkComponent;
}());



/***/ }),

/***/ "./src/app/core/components/audio-quality/audio-quality.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/core/components/audio-quality/audio-quality.component.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  max-width: 45em;\n  margin: 2em auto;\n  display: block;\n}\n:host label {\n  float: left;\n  padding: 0 1em;\n  text-align: center;\n}\n:host .title {\n  font-size: 1.1em;\n  color: var(--dark-gray);\n  font-weight: 300;\n}\n:host .subtitle {\n  font-size: 0.8em;\n  color: var(--dark-gray);\n}\n:host .selected-title {\n  color: var(--text-color);\n  font-weight: 600;\n}\n:host .custom-control-label {\n  vertical-align: middle !important;\n  color: var(--text-color-dark);\n}\n:host .custom-control-input:checked ~ .custom-control-label::before {\n  border-color: var(--brand-purple) !important;\n  background-color: var(--brand-purple) !important;\n}\n:host .custom-control {\n  margin: 0 1em;\n}\n:host .custom-control.custom-radio {\n  cursor: pointer !important;\n}\n:host .custom-control-label {\n  cursor: pointer !important;\n}\n:host .custom-control-label::before,\n:host .custom-control-label::after {\n  top: 0.1em !important;\n  cursor: pointer;\n}\n:host .custom-control-label {\n  vertical-align: middle !important;\n  color: var(--text-color-dark);\n  min-width: 5em;\n}\n:host .icon {\n  font-size: 1.2em;\n}\n:host .version {\n  color: var(--dark-gray-updated);\n  text-align: center;\n}"

/***/ }),

/***/ "./src/app/core/components/audio-quality/audio-quality.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/audio-quality/audio-quality.component.ts ***!
  \**************************************************************************/
/*! exports provided: AudioQualityComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AudioQualityComponent", function() { return AudioQualityComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");



var AudioQualityComponent = /** @class */ (function () {
    function AudioQualityComponent(_translateService) {
        this._translateService = _translateService;
        this.audioChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.audioQualitySet = [
            {
                title: this._translateService.instant('data_saver'),
                subtitle: '',
                code: '24'
            }, {
                title: this._translateService.instant('normal'),
                subtitle: '96 Kbps',
                code: '64'
            }, {
                title: this._translateService.instant('high'),
                subtitle: '160 Kbps',
                code: '128'
            }, {
                title: this._translateService.instant('pristine'),
                subtitle: '320 Kbps',
                code: '196'
            }
        ];
        this.filteredAudioQualitySet = [];
        this.value = 0;
        this.filteredAudioQualitySet = JSON.parse(JSON.stringify(this.audioQualitySet));
    }
    AudioQualityComponent.prototype.ngOnInit = function () {
    };
    AudioQualityComponent.prototype.ngOnChanges = function () {
        var _this = this;
        if (this.userAudioSettings) {
            this.filteredAudioQualitySet = this.audioQualitySet.filter(function (elt) { return _this.userAudioSettings.options.indexOf(elt.code) !== -1; });
            setTimeout(function () {
                _this.value = _this.filteredAudioQualitySet.findIndex(function (elt) { return elt.code === _this.userAudioSettings.default; });
            });
        }
    };
    AudioQualityComponent.prototype.changeAudioQuality = function (index) {
        this.value = index;
        var quality = this.filteredAudioQualitySet[index];
        this.audioChanged.emit(quality);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], AudioQualityComponent.prototype, "userAudioSettings", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], AudioQualityComponent.prototype, "audioChanged", void 0);
    AudioQualityComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-audio-quality',
            template: __webpack_require__(/*! raw-loader!./audio-quality.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/audio-quality/audio-quality.component.html"),
            styles: [__webpack_require__(/*! ./audio-quality.component.scss */ "./src/app/core/components/audio-quality/audio-quality.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"]])
    ], AudioQualityComponent);
    return AudioQualityComponent;
}());



/***/ }),

/***/ "./src/app/core/components/logs-modal/logs-modal.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/core/components/logs-modal/logs-modal.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".modal-header {\n  background-color: var(--modal-head-light) !important;\n}\n\n.modal-body {\n  background-color: var(--app-background);\n  margin-bottom: 0 !important;\n}\n\n.modal-footer {\n  background-color: var(--app-background);\n  border: none;\n}\n\n.close {\n  color: var(--text-color);\n}\n\n.err {\n  color: red;\n  font-weight: 600;\n  padding-top: 0.5em;\n}\n\nlabel {\n  font-weight: bold;\n}\n\n.form-input {\n  background-color: var(--gray-light-background);\n  color: var(--text-color);\n  border: 1px solid var(--input-light-gray) !important;\n  border-radius: 1.3em;\n  font-size: 1em;\n}\n\n.form-input:focus {\n  background-color: var(--gray-light-background);\n  box-shadow: none;\n  border: 1px solid #ced4da !important;\n  color: var(--text-color);\n}\n\nselect {\n  padding: 0 0.5em 0 0.5em;\n}\n\ntextarea {\n  padding: 0.5em;\n}\n\nhtml[lang=ar] :host .close {\n  margin: -1rem auto -1rem -1rem;\n}\n\nhtml[lang=ar] :host .modal-body {\n  text-align: right;\n}"

/***/ }),

/***/ "./src/app/core/components/logs-modal/logs-modal.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/core/components/logs-modal/logs-modal.component.ts ***!
  \********************************************************************/
/*! exports provided: LogsModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogsModalComponent", function() { return LogsModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_services_desktop_logs_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/desktop-logs.service */ "./src/app/core/services/desktop-logs.service.ts");
/* harmony import */ var _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/settings.actions */ "./src/app/core/redux/actions/settings.actions.ts");






var LogsModalComponent = /** @class */ (function () {
    function LogsModalComponent(locale, _store, _desktopLogsService, activeModal) {
        this.locale = locale;
        this._store = _store;
        this._desktopLogsService = _desktopLogsService;
        this.activeModal = activeModal;
    }
    LogsModalComponent.prototype.ngOnInit = function () {
    };
    LogsModalComponent.prototype.submitReport = function () {
        if (this.supportType === undefined || this.userDescription === undefined || this.supportType.trim() == '' || this.userDescription.trim() == '') {
            this.errorMsg =
                this.locale === 'ar'
                    ? 'املأ جميع الحقول'
                    : this.locale === 'fr'
                        ? 'Champs obligatoires'
                        : 'All fields required';
        }
        else {
            this._store.dispatch(new _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_5__["ReportProblem"]({
                supportType: this.supportType,
                userDescription: this.userDescription
            }));
            this.close();
        }
    };
    LogsModalComponent.prototype.clearErrMsg = function () {
        this.errorMsg = '';
    };
    LogsModalComponent.prototype.close = function () {
        this.activeModal.close();
    };
    LogsModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-logs-modal',
            template: __webpack_require__(/*! raw-loader!./logs-modal.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/logs-modal/logs-modal.component.html"),
            styles: [__webpack_require__(/*! ./logs-modal.component.scss */ "./src/app/core/components/logs-modal/logs-modal.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
            _anghami_services_desktop_logs_service__WEBPACK_IMPORTED_MODULE_4__["DesktopLogsService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__["NgbActiveModal"]])
    ], LogsModalComponent);
    return LogsModalComponent;
}());



/***/ }),

/***/ "./src/app/core/services/email.service.ts":
/*!************************************************!*\
  !*** ./src/app/core/services/email.service.ts ***!
  \************************************************/
/*! exports provided: EmailService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmailService", function() { return EmailService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var EmailService = /** @class */ (function () {
    function EmailService() {
        /**
         * Password with strength 'medium' should consist of
         * 1 numeric value
         * 1 upper case letter
         * 1 lower case letter
         */
        // requires a lower letter and a capital letter | number | special character
        this.mediumRegx1 = /^(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{5,30}$/;
        this.mediumRegx2 = /^(?=.*[a-z])(?=.*\d)(?!.*\s).{5,30}$/;
        this.mediumRegx3 = /^(?=.*[a-z])(?=.*\W)(?!.*\s).{5,30}$/;
        // requires a lower character and a capital letter, a number, and a special character
        this.strongRegx = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?!.*\s).{5,30}$/;
    }
    EmailService.prototype.strength = function (val) {
        var strength = '';
        if (val && val !== null && val !== '') {
            strength = 'weak';
            if (val.match(this.mediumRegx1) !== null ||
                val.match(this.mediumRegx2 !== null) ||
                val.match(this.mediumRegx3) !== null) {
                strength = 'medium';
            }
            if (val.match(this.strongRegx) !== null) {
                strength = 'strong';
            }
            return strength;
        }
    };
    EmailService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], EmailService);
    return EmailService;
}());



/***/ }),

/***/ "./src/app/modules/base/settings/account-settings/account-settings.component.scss":
/*!****************************************************************************************!*\
  !*** ./src/app/modules/base/settings/account-settings/account-settings.component.scss ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "select {\n  cursor: pointer;\n}\n\n.login-input-flag {\n  -webkit-box-pack: start !important;\n      -ms-flex-pack: start !important;\n          justify-content: flex-start !important;\n  width: unset !important;\n}\n\n.login-input-flag img {\n  width: 2em !important;\n  height: 2em !important;\n}\n\n.login-input-flag select {\n  width: 100% !important;\n}\n\n.input-box-border {\n  max-width: 20em;\n}\n\n.input-box-border.msidn {\n  max-width: unset;\n}\n\ninput::-webkit-input-placeholder {\n  font-size: 0.9em !important;\n}\n\ninput:-moz-placeholder {\n  /* Firefox 18- */\n  font-size: 0.9em !important;\n}\n\ninput::-moz-placeholder {\n  /* Firefox 19+ */\n  font-size: 0.9em !important;\n}\n\ninput:-ms-input-placeholder {\n  font-size: 0.9em !important;\n}\n\n.cancel-change {\n  position: relative;\n  background-color: var(--close-bgd);\n  border-radius: 50%;\n  width: 1.5em;\n  height: 1.5em;\n  cursor: pointer;\n}\n\n.cancel-change .close {\n  color: var(--close-dark-gray);\n  text-align: center;\n  margin: 0 auto;\n  font-size: 1.1em;\n  line-height: 1.4em;\n  font-weight: 100;\n  width: 100%;\n}\n\n.fb-bgd {\n  background-color: #3B5998;\n  border-radius: 50%;\n}\n\n.facebook {\n  stroke: white;\n  fill: white;\n}\n\n.facebook ::ng-deep svg {\n  margin: 0.25em;\n}\n\n.prefix {\n  font-weight: 600;\n  font-size: 1.1em;\n}\n\n.slider {\n  background-color: var(--slider-background);\n}\n\n.min-w-5 {\n  min-width: 5em;\n}\n\n.nowrap {\n  white-space: nowrap;\n}\n\n.weak {\n  color: orange;\n}\n\n.medium {\n  color: #90ee90;\n}\n\n.strong {\n  color: green;\n}\n\n.pb-25 {\n  padding-bottom: 2.5em !important;\n}\n\n.pb-5e {\n  padding-bottom: 5em !important;\n}\n\n.pb-4e {\n  padding-bottom: 4em !important;\n}\n\n.width-6 {\n  width: 6em !important;\n}\n\n.width-55 {\n  width: 55%;\n}\n\n.sub {\n  font-size: 0.9em;\n}"

/***/ }),

/***/ "./src/app/modules/base/settings/account-settings/account-settings.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/modules/base/settings/account-settings/account-settings.component.ts ***!
  \**************************************************************************************/
/*! exports provided: AccountSettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountSettingsComponent", function() { return AccountSettingsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/actions/plus.actions */ "./src/app/core/redux/actions/plus.actions.ts");
/* harmony import */ var _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/services/promo.service */ "./src/app/core/services/promo.service.ts");
/* harmony import */ var _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/settings.actions */ "./src/app/core/redux/actions/settings.actions.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_services_email_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/services/email.service */ "./src/app/core/services/email.service.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../core/enums/enums */ "./src/app/core/enums/enums.ts");















var AccountSettingsComponent = /** @class */ (function () {
    function AccountSettingsComponent(_store, _utilService, _actionSubject, _promoService, _authService, _emailService) {
        this._store = _store;
        this._utilService = _utilService;
        this._actionSubject = _actionSubject;
        this._promoService = _promoService;
        this._authService = _authService;
        this._emailService = _emailService;
        this.submit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.editPhonenumber = false;
        this.editEmail = false;
        this.editPassword = false;
        this.isVerifyMsidn = false;
        this.telcoLst = [];
        this.msidnCodeConditions = {
            maxlength: 10
        };
        this.msidnConditions = {
            maxlength: 17,
            type: 'tel'
        };
        this.errorMsg = '';
        this.disabledTimer = 0;
        this.matchErr = false;
        this.isPublicProfile = true;
        this.isAutoStories = false;
    }
    AccountSettingsComponent.prototype.ngOnInit = function () {
        this.isDeviceMobile = this._utilService.detectmob();
        var isloggedin = this._authService.isUserLoggedIn();
        if (isloggedin) {
            this.getUserInfo();
            this.getUserProfile();
        }
    };
    AccountSettingsComponent.prototype.enableTimer = function () {
        var _this = this;
        this.disabledTimer = 60;
        this.timer = setInterval(function () {
            if (_this.disabledTimer > 0) {
                _this.disabledTimer--;
            }
            else {
                clearInterval(_this.timer);
            }
        }, 1000);
    };
    AccountSettingsComponent.prototype.clearError = function () {
        this.errorMsg = '';
    };
    AccountSettingsComponent.prototype.handleConditions = function (evt, conditions) {
        this._promoService.handleConditions(evt, conditions);
    };
    AccountSettingsComponent.prototype.changePhonenumber = function (type) {
        var params = {
            'msidn': this.selectedtelco.prefix + this.msidnUpdated,
        };
        if (type && type === 'verify') {
            if (this.msidnCode && this.msidnCode !== '') {
                params['code'] = this.msidnCode;
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                    name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__["AmplitudeEvents"].verifyPhoneNumber,
                    props: {
                        code: this.msidnCode,
                        msidn: this.msidnUpdated,
                        telco: this.selectedtelco
                            ? this.selectedtelco.returnname
                            : ''
                    }
                }));
                this.dispatchVERIFYmsidn(params);
            }
            else {
                this.errorMsg = 'Wrong PIN Code';
            }
        }
        else {
            if (this.msidnUpdated && this.msidnUpdated !== '') {
                params['telco'] = this.selectedtelco && this.selectedtelco !== null
                    ? this.selectedtelco.returnname
                    : '';
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                    name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__["AmplitudeEvents"].changePhoneNumber,
                    props: {
                        msidn: this.msidnUpdated,
                        telco: this.selectedtelco
                            ? this.selectedtelco.returnname
                            : ''
                    }
                }));
                this.dispatchVERIFYmsidn(params);
            }
            else {
                this.errorMsg = 'Phone Number Is Required';
            }
        }
    };
    AccountSettingsComponent.prototype.dispatchVERIFYmsidn = function (params) {
        var _this = this;
        this._store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_8__["VERIFYmsidn"](params));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_8__["PlusActionTypes"].VERIFYmsidnSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            var data = res.payload;
            _this.isVerifyMsidn = params['code'] && params['code'] !== null && params['code'] !== ''
                ? false
                : true;
            if (!_this.isVerifyMsidn) {
                _this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                    name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__["AmplitudeEvents"].verifyPhoneNumberSuccess
                }));
                _this.editPhonenumber = false;
                _this.user.msidn = JSON.parse(JSON.stringify(_this.msidnUpdated));
            }
            else {
                _this.enableTimer();
            }
        });
    };
    AccountSettingsComponent.prototype.changeEmail = function () {
        var _this = this;
        if (this.emailUpdated && this.emailUpdated !== '' && this.emailUpdated !== this.user.email) {
            var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))/;
            var valid = this.emailUpdated.match(regex);
            if (valid !== null) {
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                    name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__["AmplitudeEvents"].changeEmail,
                    props: {
                        email: this.emailUpdated
                    }
                }));
                this._store.dispatch(new _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_10__["UpdateEmail"]({
                    email: this.emailUpdated
                }));
                this._actionSubject
                    .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_10__["SettingsActionTypes"].UpdateEmailSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
                    .subscribe(function (res) {
                    var response = res.payload;
                    if (response.status === 'ok') {
                        _this.editEmail = false;
                        _this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__["AmplitudeEvents"].changeEmailSuccess
                        }));
                    }
                });
            }
        }
        else {
            // TODO: add error message
        }
    };
    AccountSettingsComponent.prototype.checkPasswordStrength = function () {
        if (this.updatedPassword && this.updatedPassword !== '') {
            this.passStrength = this._emailService.strength(this.updatedPassword);
        }
    };
    AccountSettingsComponent.prototype.checkPasswordMatch = function () {
        this.matchErr = !(this.updatedPassword === this.confirmPassword);
    };
    AccountSettingsComponent.prototype.changePassword = function () {
        var _this = this;
        if (this.updatedPassword !== undefined && this.updatedPassword === this.confirmPassword) {
            this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__["AmplitudeEvents"].changePassword
            }));
            this._store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_5__["UpdatePassword"]({
                old: this.currentPassword,
                new: this.updatedPassword
            }));
            this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_5__["AuthActionTypes"].UpdatePasswordSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
                .subscribe(function (res) {
                var response = res.payload;
                if (response.status === 'ok') {
                    _this.editPassword = false;
                    _this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
                        name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__["AmplitudeEvents"].changePasswordSuccess
                    }));
                }
            });
        }
        else {
            // TODO: add error message
        }
    };
    AccountSettingsComponent.prototype.changeProfileStatus = function () {
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__["AmplitudeEvents"].changeProfileStatus,
            props: {
                ispublic: !this.isPublicProfile
            }
        }));
        this._store.dispatch(new _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_10__["TogglePrivateProfile"]({ ispublic: !this.isPublicProfile ? 1 : 0 }));
    };
    // TODO: check what to do on success
    AccountSettingsComponent.prototype.autoAddStories = function () {
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_13__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_14__["AmplitudeEvents"].turnAutomaticStories,
            props: {
                auto_stories: this.isAutoStories
            }
        }));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_10__["SettingsActionTypes"].PostUserPreferencesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            var response = res.payload;
            if (response.status === 'ok') {
            }
        });
        this.submit.emit({
            'type': 'POSTuserpreferences',
            'auto_stories': this.isAutoStories === true ? '1' : '0'
        });
    };
    AccountSettingsComponent.prototype.getUserInfo = function () {
        var _this = this;
        this.getUserSub$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_3__["getUser"])).subscribe(function (data) {
            if (data && data !== null) {
                _this.user = JSON.parse(JSON.stringify(data));
                _this.msidnUpdated = _this.user.msidn;
                _this.emailUpdated = JSON.parse(JSON.stringify(_this.user.email));
                _this.isAutoStories = (_this.user.auto_stories == '1');
                _this.getTelcos();
                _this.getSubscriptions();
            }
        });
    };
    AccountSettingsComponent.prototype.getUserProfile = function () {
        var _this = this;
        this._store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_5__["GetUserProfile"]());
        this.getUserProfile$ = this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_5__["AuthActionTypes"].GetUserProfileSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (data) {
            if (data && data !== null) {
                var response = data.payload;
                _this.isPublicProfile =
                    (response.ispublic === '1' ||
                        response.ispublic === 1 ||
                        response.ispublic === 'true');
            }
        });
    };
    AccountSettingsComponent.prototype.getTelcos = function () {
        var _this = this;
        this._store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_5__["GetTelcos"]({}));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_5__["AuthActionTypes"].GetTelcosSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            var data = res.payload;
            if (data && data.telcos && data.telcos !== null && data.telcos.length > 0) {
                _this.telcoLst = JSON.parse(JSON.stringify(data.telcos));
                _this.selectedtelco = _this.telcoLst.find(function (elt) { return elt.selected === 1; })
                    ? _this.telcoLst.find(function (elt) { return elt.selected === 1; })
                    : _this.telcoLst[0];
                if (_this.user.msidn.startsWith(_this.selectedtelco.prefix)) {
                    _this.msidnUpdated = _this.user.msidn.slice(_this.selectedtelco.prefix.length);
                }
            }
        });
    };
    AccountSettingsComponent.prototype.getSubscriptions = function () {
        var _this = this;
        var params = {
            show_plus: 1
        };
        if (this.user.socketsessionid) {
            params['appsid'] = this.user.socketsessionid;
        }
        this._store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_8__["GETPurchases"](params));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_8__["PlusActionTypes"].GETPurchaseSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1))
            .subscribe(function (res) {
            var data = res.payload.data;
            if (data.purchases && data.purchases !== null && data.purchases.length > 0) {
                _this.subscriptions = JSON.parse(JSON.stringify(data.purchases));
            }
            else {
                _this.subscriptions = [];
            }
        });
    };
    AccountSettingsComponent.prototype.setTelco = function (operator) {
        this.selectedtelco = operator;
    };
    AccountSettingsComponent.prototype.cancelChange = function () {
        this.editEmail = false;
    };
    AccountSettingsComponent.prototype.ngOnDestroy = function () {
        if (this.getUserSub$) {
            this.getUserSub$.unsubscribe();
        }
        if (this.getUserProfile$) {
            this.getUserProfile$.unsubscribe();
        }
    };
    AccountSettingsComponent.prototype.resend = function () {
        this.enableTimer();
        this.changePhonenumber();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], AccountSettingsComponent.prototype, "submit", void 0);
    AccountSettingsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-account-settings',
            template: __webpack_require__(/*! raw-loader!./account-settings.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/account-settings/account-settings.component.html"),
            styles: [__webpack_require__(/*! ./account-settings.component.scss */ "./src/app/modules/base/settings/account-settings/account-settings.component.scss"), __webpack_require__(/*! ../settings.component.scss */ "./src/app/modules/base/settings/settings.component.scss"), __webpack_require__(/*! ../../../login/components/login-landing/login-shared.scss */ "./src/app/modules/login/components/login-landing/login-shared.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
            _anghami_services_promo_service__WEBPACK_IMPORTED_MODULE_9__["PromoService"],
            _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_11__["AuthService"],
            _anghami_services_email_service__WEBPACK_IMPORTED_MODULE_12__["EmailService"]])
    ], AccountSettingsComponent);
    return AccountSettingsComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/settings/app-settings/app-settings.component.scss":
/*!********************************************************************************!*\
  !*** ./src/app/modules/base/settings/app-settings/app-settings.component.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".custom-control-input:checked ~ .custom-control-label::before {\n  border-color: var(--brand-purple) !important;\n  background-color: var(--brand-purple) !important;\n}\n\n.custom-control {\n  margin: 0 2em;\n}\n\n.language {\n  -webkit-box-pack: start !important;\n      -ms-flex-pack: start !important;\n          justify-content: flex-start !important;\n  width: 50%;\n}\n\n.language .custom-control.custom-radio {\n  cursor: pointer !important;\n}\n\n.language .custom-control-label {\n  cursor: pointer !important;\n}\n\n@media (max-width: 1024px) {\n  .language {\n    width: unset !important;\n  }\n}\n\n.custom-control-label::before, .custom-control-label::after {\n  top: 0.1em !important;\n  cursor: pointer;\n}\n\n.custom-control-label {\n  vertical-align: middle !important;\n  color: var(--text-color-dark);\n}\n\n.icon {\n  font-size: 1.2em;\n}\n\n.version {\n  color: var(--dark-gray-updated);\n  text-align: center;\n}"

/***/ }),

/***/ "./src/app/modules/base/settings/app-settings/app-settings.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/modules/base/settings/app-settings/app-settings.component.ts ***!
  \******************************************************************************/
/*! exports provided: AppSettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppSettingsComponent", function() { return AppSettingsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _anghami_redux_selectors_layout_selector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/selectors/layout.selector */ "./src/app/core/redux/selectors/layout.selector.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _anghami_redux_actions_layout_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/layout.actions */ "./src/app/core/redux/actions/layout.actions.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/redux/selectors/desktop-client.selectors */ "./src/app/core/redux/selectors/desktop-client.selectors.ts");
/* harmony import */ var _anghami_services_settings_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/services/settings.service */ "./src/app/core/services/settings.service.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm5/ngx-cookie.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _anghami_services_layout_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @anghami/services/layout.service */ "./src/app/core/services/layout.service.ts");
/* harmony import */ var _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @anghami/redux/actions/settings.actions */ "./src/app/core/redux/actions/settings.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _core_components_logs_modal_logs_modal_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../../core/components/logs-modal/logs-modal.component */ "./src/app/core/components/logs-modal/logs-modal.component.ts");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/fesm5/service-worker.js");
/* harmony import */ var _anghami_services_service_worker_service__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @anghami/services/service-worker.service */ "./src/app/core/services/service-worker.service.ts");
























var AppSettingsComponent = /** @class */ (function () {
    function AppSettingsComponent(_store, _translateService, _utilService, _settingsService, _authService, _changeDetector, _cookieService, _layoutService, modalService, _actionSubject, _swPush, _serviceWorkerService) {
        this._store = _store;
        this._translateService = _translateService;
        this._utilService = _utilService;
        this._settingsService = _settingsService;
        this._authService = _authService;
        this._changeDetector = _changeDetector;
        this._cookieService = _cookieService;
        this._layoutService = _layoutService;
        this.modalService = modalService;
        this._actionSubject = _actionSubject;
        this._swPush = _swPush;
        this._serviceWorkerService = _serviceWorkerService;
        this.checkingForUpdates = false;
        this.submit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.languagesLst = [
            {
                label: 'English',
                code: 'en'
            }, {
                label: 'عربي',
                code: 'ar'
            }, {
                label: 'Français',
                code: 'fr'
            }
        ];
        this.lettersLst = [
            {
                code: 0,
                label: this._translateService.instant('english_letters')
            }, {
                code: 1,
                label: this._translateService.instant('arabic_letters')
            }
        ];
        this.isDarkMode = false;
        this.isSWEnabled = false;
        this.isGrantedNotifications = false;
        this.showAccessibilityClientButton = false;
    }
    AppSettingsComponent.prototype.ngOnInit = function () {
        this.isDesktopApp = !!window['desktopClient'];
        this.isMac = window['desktopClient'] && window['desktopClient'].platform
            ? window['desktopClient'].platform.name === 'Mac'
            : false;
        this.isLoggedin = this._authService.isUserLoggedIn();
        this.getUserInfo();
        if (this.isDesktopApp) {
            this.appVersion = window['desktopClient'].appVersion;
            this.getTrustedAccessibilityClientState();
        }
        this.getSWRegistration();
    };
    AppSettingsComponent.prototype.ngAfterViewChecked = function () {
        this.getDarkModeState();
        this._changeDetector.detectChanges();
    };
    AppSettingsComponent.prototype.ngOnDestroy = function () {
        if (this.darkModeSub$) {
            this.darkModeSub$.unsubscribe();
        }
        if (this.getUserSub$) {
            this.getUserSub$.unsubscribe();
        }
    };
    AppSettingsComponent.prototype.getTrustedAccessibilityClientState = function () {
        var _this = this;
        this._store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_11__["getTrustedAccessibilityClientState"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(function (response) {
            _this.showAccessibilityClientButton = response.shouldShow;
        });
    };
    AppSettingsComponent.prototype.getSWRegistration = function () {
        var _this = this;
        if (navigator.serviceWorker && this._swPush.isEnabled) {
            navigator.serviceWorker.getRegistrations().then(function (registrationList) {
                _this.isSWEnabled = registrationList && registrationList.length > 0;
                if (_this.isSWEnabled) {
                    _this.isGrantedNotifications = Notification && Notification['permission'] === 'granted';
                }
            });
        }
    };
    AppSettingsComponent.prototype.getDarkModeState = function () {
        var _this = this;
        this.darkModeSub$ = this._store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_layout_selector__WEBPACK_IMPORTED_MODULE_4__["getDarkmodeState"]))
            .subscribe(function (data) {
            _this.isDarkMode = data;
        });
    };
    AppSettingsComponent.prototype.getUserInfo = function () {
        var _this = this;
        this.getUserSub$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__["getUser"])).subscribe(function (data) {
            if (data && data !== null) {
                _this.user = JSON.parse(JSON.stringify(data));
                _this.selectedLang = _this._cookieService.get('userlanguageprod')
                    ? _this._cookieService.get('userlanguageprod')
                    : 'en';
                _this.selectedDisplay = _this.user.arabicletters
                    ? _this.user.arabicletters
                    : 0;
            }
            else {
                _this.selectedLang = _this._cookieService.get('userlanguageprod')
                    ? _this._cookieService.get('userlanguageprod')
                    : 'en';
                _this.selectedDisplay = 0;
            }
        });
    };
    AppSettingsComponent.prototype.changeLang = function (lang) {
        if (lang && lang !== null) {
            this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_15__["LogAmplitudeEvent"]({
                name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].changeAppLang,
                props: { lang: lang.code }
            }));
            this.selectedLang = lang.code;
            this.submit.emit({
                'userlang': {
                    'lang': this.selectedLang
                }
            });
        }
    };
    AppSettingsComponent.prototype.changeArabicDisplay = function (display, elt) {
        var _this = this;
        if (display && display !== null) {
            if (!this.isLoggedin) {
                setTimeout(function () {
                    _this.selectedDisplay = 0;
                    if (display.code === 1) {
                        elt.checked = false;
                    }
                    _this._changeDetector.detectChanges();
                }, 1000);
            }
            else {
                this.selectedDisplay = display.code;
            }
            var params = {
                'arabicletters': (this.selectedDisplay === 1)
            };
            this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_15__["LogAmplitudeEvent"]({
                name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].changeArabicLetters,
                props: { letters: display.code }
            }));
            this.submit.emit({ 'arabicDisplay': params });
        }
    };
    AppSettingsComponent.prototype.toggleNotificationsPermission = function () {
        if (this.isGrantedNotifications) {
            window.localStorage.removeItem('prompt-pushnotif');
            this._serviceWorkerService.registerNotifications();
        }
        else {
            this._serviceWorkerService.unregisterNotifications(true);
        }
    };
    AppSettingsComponent.prototype.toggleDarkMode = function () {
        var _this = this;
        if (!this.isLoggedin) {
            setTimeout(function () {
                _this.isDarkMode = !_this.isDarkMode;
            });
        }
        var darkmode = {
            value: this.isDarkMode
        };
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_15__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].toggleDarkmode,
            props: { darkmode: darkmode }
        }));
        this._store.dispatch(new _anghami_redux_actions_layout_actions__WEBPACK_IMPORTED_MODULE_6__["ToggleDarkmode"](darkmode));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_19__["ofType"])(_anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_18__["SettingsActionTypes"].PostUserPreferencesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(function (action) {
            var response = action.payload;
            if (response && response.status === 'ok') {
                _this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["OpenDialog"]({
                    title: _this._translateService.instant('preferences_updated_success'),
                    displaymode: 'toast'
                }));
            }
        });
    };
    AppSettingsComponent.prototype.checkForUpdates = function () {
        var _this = this;
        this.checkingForUpdates = true;
        var updateDialog = {
            displaymode: 'toast',
            title: this._translateService.instant('check_for_updates_toast')
        };
        this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["OpenDialog"](updateDialog));
        setTimeout(function () {
            _this._store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_10__["CheckForUpdates"](true));
            _this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_11__["getCheckForUpdatesState"])).subscribe(function (resp) {
                _this.checkingForUpdates = resp;
            });
        }, 1500);
    };
    AppSettingsComponent.prototype.clearCache = function () {
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_15__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_16__["AmplitudeEvents"].clearCache
        }));
        var dialog = {
            displaymode: 'toast',
            title: this._translateService.instant('clear_cache')
        };
        this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["OpenDialog"](dialog));
        this._utilService.clearSwCache();
        setTimeout(function () {
            window.location.reload();
        }, 500);
    };
    AppSettingsComponent.prototype.enableTrustedAccessibilityClient = function () {
        this._store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_10__["EmitMessageToDesktopClient"]({
            message: 'main-show-accesibility-prompt',
            payload: {}
        }));
    };
    AppSettingsComponent.prototype.openLogReportModal = function () {
        this.modalService.open(_core_components_logs_modal_logs_modal_component__WEBPACK_IMPORTED_MODULE_21__["LogsModalComponent"], {
            size: 'lg',
            windowClass: 'modal-holder logs-modal'
        });
    };
    AppSettingsComponent.prototype.showToastIfNotLoggedIn = function () {
        this._settingsService.showToastIfNotLoggedIn(this.isLoggedin);
    };
    /**
     * Check article for reason why this is needed
     * https://medium.com/code-divoire/ng-bootstrap-modalservice-and-expressionchangedafterithasbeencheckederror-7b21cbf6c74a
     */
    AppSettingsComponent.prototype.toggleClick = function (event) {
        event.srcElement.blur();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], AppSettingsComponent.prototype, "submit", void 0);
    AppSettingsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-app-settings',
            template: __webpack_require__(/*! raw-loader!./app-settings.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/app-settings/app-settings.component.html"),
            styles: [__webpack_require__(/*! ./app-settings.component.scss */ "./src/app/modules/base/settings/app-settings/app-settings.component.scss"), __webpack_require__(/*! ../settings.component.scss */ "./src/app/modules/base/settings/settings.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_8__["UtilService"],
            _anghami_services_settings_service__WEBPACK_IMPORTED_MODULE_12__["SettingsService"],
            _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_13__["AuthService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
            ngx_cookie__WEBPACK_IMPORTED_MODULE_14__["CookieService"],
            _anghami_services_layout_service__WEBPACK_IMPORTED_MODULE_17__["LayoutService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_20__["NgbModal"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
            _angular_service_worker__WEBPACK_IMPORTED_MODULE_22__["SwPush"],
            _anghami_services_service_worker_service__WEBPACK_IMPORTED_MODULE_23__["ServiceWorkerService"]])
    ], AppSettingsComponent);
    return AppSettingsComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/settings/music-settings/music-settings.component.scss":
/*!************************************************************************************!*\
  !*** ./src/app/modules/base/settings/music-settings/music-settings.component.scss ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".arrow ::ng-deep svg {\n  fill: var(--dark-gray);\n}\n\n.title {\n  padding: 2em;\n  padding-bottom: 0.5em;\n}\n\n.subtitle {\n  padding: 0 2.8em;\n  padding-top: 0;\n}\n\n.cursor-btn {\n  cursor: pointer;\n}\n\n.show-frm {\n  -webkit-transform: rotate(270deg) !important;\n      -ms-transform: rotate(270deg) !important;\n          transform: rotate(270deg) !important;\n}\n\n.login-form {\n  margin: 1em auto;\n}\n\n@media (max-width: 678px) {\n  .flexbox.lastfmfrm {\n    -webkit-box-orient: vertical !important;\n    -webkit-box-direction: normal !important;\n        -ms-flex-direction: column !important;\n            flex-direction: column !important;\n  }\n}\n\n.audio-selector {\n  width: 90%;\n  margin: auto;\n}\n\nanghami-audio-quality {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n\nhtml[lang=ar] :host .title,\nhtml[lang=ar] :host .subtitle {\n  text-align: right;\n}"

/***/ }),

/***/ "./src/app/modules/base/settings/music-settings/music-settings.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/modules/base/settings/music-settings/music-settings.component.ts ***!
  \**********************************************************************************/
/*! exports provided: MusicSettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MusicSettingsComponent", function() { return MusicSettingsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm5/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_services_import_music_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/services/import-music.service */ "./src/app/core/services/import-music.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");















var MusicSettingsComponent = /** @class */ (function () {
    function MusicSettingsComponent(_actionsSubject, _store, _authService, _route, _translateService, fb, _cookieService, _utilService, _importMusicService, platformId) {
        this._actionsSubject = _actionsSubject;
        this._store = _store;
        this._authService = _authService;
        this._route = _route;
        this._translateService = _translateService;
        this.fb = fb;
        this._cookieService = _cookieService;
        this._utilService = _utilService;
        this._importMusicService = _importMusicService;
        this.platformId = platformId;
        this.submit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.deviceName = this._utilService.getOSName();
        this.musicSettings = {
            explicit: false,
            disableHideExplicitContent: false,
            lfpublish: false,
        };
        this.lastfmForm = this.fb.group({
            username: [
                null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_10__["Validators"].pattern(/^([a-zA-Z0-9_]+|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4})$/i), _angular_forms__WEBPACK_IMPORTED_MODULE_10__["Validators"].required])
            ],
            password: [
                null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_10__["Validators"].minLength(5), _angular_forms__WEBPACK_IMPORTED_MODULE_10__["Validators"].required])
            ]
        }),
            this.audioQuality = false;
        this.isLoggedin = false;
        this.showLfpublish = false;
    }
    MusicSettingsComponent.prototype.ngOnInit = function () {
        this.isDesktopApp = !!window['desktopClient'];
        this.isLoggedin = this._authService.isUserLoggedIn();
        this.getUserInfo();
    };
    MusicSettingsComponent.prototype.ngOnDestroy = function () {
        if (this.getUserSub$) {
            this.getUserSub$.unsubscribe();
        }
    };
    MusicSettingsComponent.prototype.clearErr = function () {
        var count = 0;
        for (var key in this.lastfmForm.controls) {
            if (!this.lastfmForm.controls[key].valid) {
                count++;
            }
        }
        if (count === 0) {
            this.errorMsg = '';
        }
    };
    MusicSettingsComponent.prototype.hasErr = function (type) {
        this.clearErr();
        return this.lastfmForm.controls[type].touched && !this.lastfmForm.controls[type].valid;
    };
    MusicSettingsComponent.prototype.getUserInfo = function () {
        var _this = this;
        this.getUserSub$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_9__["getUser"])).subscribe(function (data) {
            if (data && data !== null) {
                _this.user = JSON.parse(JSON.stringify(data));
                _this.musicSettings.lfpublish = (_this.user.lfpublish === 'true' || data.lfpublish === true);
                _this.musicSettings.explicit = (_this.user.explicit === 'hide');
                _this.musicSettings.disableHideExplicitContent = _this.user.disable_explicit_content == 1 ? true : false;
                if (data.email && data.email !== null) {
                    _this.lastfmForm.controls.username.setValue(data.email);
                }
                if (_this.user.audioQuality && _this.user.audioQuality !== null) {
                    _this.AudioQualityfreeOptions = _this.user.audioQuality.freeUsersOptions
                        && _this.user.audioQuality.freeUsersOptions !== null
                        ? _this.user.audioQuality.freeUsersOptions.split(',')
                        : [];
                    _this.setAudioQuality('download');
                    _this.setAudioQuality('stream');
                }
            }
        });
    };
    MusicSettingsComponent.prototype.importMusic = function (type) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_14__["isPlatformBrowser"])(this.platformId) && this.isLoggedin && type && type !== null) {
            if (!!window['desktopClient']) {
                window.open("https://www.anghami.com/import?sid=" + this.user.socketsessionid + "&" + type + "=true");
            }
            else {
                this._importMusicService.handleImportMusic(type, null);
            }
        }
    };
    MusicSettingsComponent.prototype.changeMusicPreferences = function () {
        if (this.musicSettings && this.musicSettings !== null) {
            var musicPreferenceObj = {};
            for (var key in this.musicSettings) {
                if (this.musicSettings.hasOwnProperty(key)) {
                    if (key === 'explicit') {
                        musicPreferenceObj[key] = this.musicSettings[key] === true
                            ? 'hide'
                            : 'show';
                    }
                }
            }
            musicPreferenceObj['type'] = 'POSTuserpreferences';
            this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_3__["LogAmplitudeEvent"]({
                name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["AmplitudeEvents"].musicPreference,
                props: musicPreferenceObj
            }));
            this.submit.emit({ 'musicsettings': musicPreferenceObj });
        }
    };
    MusicSettingsComponent.prototype.setAudioQuality = function (type) {
        if (type === 'stream') {
            var streamingOptions = this.user.audioQuality.streamOptions
                && this.user.audioQuality.streamOptions !== null
                ? this.user.audioQuality.streamOptions.split(',')
                : [];
            this.userAudioStreamingSettings = {
                options: streamingOptions,
                default: this.user.stream_hq && this.user.stream_hq !== null && this.user.stream_hq !== ''
                    ? this.user.stream_hq + ''
                    : this.user.audioQuality.streamDefaultValue
            };
        }
        else if (type === 'download') {
            var downloadOptions = this.user.audioQuality.downloadOptions
                && this.user.audioQuality.downloadOptions !== null
                ? this.user.audioQuality.downloadOptions.split(',')
                : [];
            this.userAudioDownloadSettings = {
                options: downloadOptions,
                default: this.user.download_hq && this.user.download_hq !== null && this.user.download_hq !== ''
                    ? this.user.download_hq + ''
                    : this.user.audioQuality.downloadDefaultValue
            };
        }
    };
    /**
     * Check if it's the same as the one already saved in cookie
     */
    MusicSettingsComponent.prototype.isAudioQualitySaved = function (type, code) {
        var cookieHq = this._cookieService.get(type + '_hq');
        var valid = false;
        if (cookieHq) {
            valid = (cookieHq === code);
        }
        return valid;
    };
    MusicSettingsComponent.prototype.audioQualityChanged = function (type, event) {
        var isplus = this.user && this.user.plantype === '3';
        var valid = type === 'download'
            ? !this.isDesktopApp
                ? false
                : isplus
                    ? true
                    : this.AudioQualityfreeOptions.includes(event.code)
            : !isplus
                ? this.AudioQualityfreeOptions.includes(event.code)
                : true;
        var cookieValidation = this.isAudioQualitySaved(type, event.code);
        if (!cookieValidation) {
            if (!valid) {
                this.audioQualityDialog(type);
                this.setAudioQuality(type);
            }
            else if (valid) {
                var audioQualityObj = {
                    type: 'POSTusercustompreference',
                    setting: type + '_hq',
                    value: event.code + ''
                };
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_3__["LogAmplitudeEvent"]({
                    name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["AmplitudeEvents"].setAudioQuality,
                    props: {
                        settings: type + '_hq',
                        value: event.code
                    }
                }));
                this.submit.emit({
                    'audioquality': audioQualityObj
                });
            }
        }
    };
    MusicSettingsComponent.prototype.scrobbleLastFm = function () {
        var params = {};
        if (this.musicSettings.lfpublish) {
            params = {
                publish: 'false',
                action: 'setting',
            };
        }
        else {
            if (this.lastfmForm.status === 'VALID') {
                params = {
                    publish: 'true',
                    action: 'add',
                    username: this.lastfmForm.value.username,
                    password: this.lastfmForm.value.password
                };
            }
            else {
                // TODO: add error message + translations
                this.errorMsg = 'Invalid username and/or password';
                return;
            }
        }
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_3__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_4__["AmplitudeEvents"].scrobbleLastfm,
            props: params
        }));
        this.submit.emit({ 'lastfm': params });
    };
    MusicSettingsComponent.prototype.audioQualityDialog = function (type) {
        if (type === 'download' && !this.isDesktopApp) {
            this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__["OpenCustomDialog"]({
                type: 'desktop_download_plus'
            }));
        }
        else {
            this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__["OpenCustomDialog"]({
                type: 'plus.feature.discovered.web'
            }));
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], MusicSettingsComponent.prototype, "submit", void 0);
    MusicSettingsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-music-settings',
            template: __webpack_require__(/*! raw-loader!./music-settings.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/music-settings/music-settings.component.html"),
            styles: [__webpack_require__(/*! ./music-settings.component.scss */ "./src/app/modules/base/settings/music-settings/music-settings.component.scss"), __webpack_require__(/*! ../settings.component.scss */ "./src/app/modules/base/settings/settings.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](9, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormBuilder"],
            ngx_cookie__WEBPACK_IMPORTED_MODULE_11__["CookieService"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_12__["UtilService"],
            _anghami_services_import_music_service__WEBPACK_IMPORTED_MODULE_13__["ImportMusicService"],
            Object])
    ], MusicSettingsComponent);
    return MusicSettingsComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/settings/notifications-settings/notifications-settings.component.scss":
/*!****************************************************************************************************!*\
  !*** ./src/app/modules/base/settings/notifications-settings/notifications-settings.component.scss ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .flexbox {\n  padding: 1em;\n}\n:host hr {\n  margin: 0;\n}\n:host .save-btn {\n  background: var(--brand-purple);\n  float: right;\n  color: #fff;\n  padding: 0.5em 1.2em;\n  border-radius: 3em;\n  cursor: pointer;\n}\nhtml[lang=ar] :host .save-btn {\n  float: left;\n}"

/***/ }),

/***/ "./src/app/modules/base/settings/notifications-settings/notifications-settings.component.ts":
/*!**************************************************************************************************!*\
  !*** ./src/app/modules/base/settings/notifications-settings/notifications-settings.component.ts ***!
  \**************************************************************************************************/
/*! exports provided: NotificationsSettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationsSettingsComponent", function() { return NotificationsSettingsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/settings.actions */ "./src/app/core/redux/actions/settings.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");









var NotificationsSettingsComponent = /** @class */ (function () {
    function NotificationsSettingsComponent(_store, _actionSubject) {
        this._store = _store;
        this._actionSubject = _actionSubject;
        this.submit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.notificationSettings = {
            music: false,
            friends: false,
            offers: false,
            playlists: false,
        };
        this.notificationString = '';
        this.notificationOldString = '';
        this.isUpdated = false;
    }
    NotificationsSettingsComponent.prototype.ngOnInit = function () {
        this.getUserInfo();
    };
    NotificationsSettingsComponent.prototype.ngOnDestroy = function () {
        if (this.getUserSub$) {
            this.getUserSub$.unsubscribe();
        }
        if (this.postUserPreferencesSuccess$) {
            this.postUserPreferencesSuccess$.unsubscribe();
        }
    };
    NotificationsSettingsComponent.prototype.changeUserPreferences = function () {
        this.notificationString = this.getUserPreferences();
        this.checkUpdate();
    };
    NotificationsSettingsComponent.prototype.checkUpdate = function () {
        var oldArr = this.notificationOldString && this.notificationOldString !== null
            ? this.notificationOldString.split(',')
            : [];
        var newArr = this.notificationString && this.notificationString !== null
            ? this.notificationString.split(',')
            : [];
        this.isUpdated = (oldArr && newArr && !this.checkArrEqual(oldArr, newArr));
    };
    NotificationsSettingsComponent.prototype.checkArrEqual = function (oldArr, newArr) {
        if (oldArr === newArr) {
            return true;
        }
        if (oldArr == null || newArr == null) {
            return false;
        }
        if (oldArr.length !== newArr.length) {
            return false;
        }
        var sortedOldArr = JSON.parse(JSON.stringify(oldArr)).sort();
        var clonedNewArr = JSON.parse(JSON.stringify(newArr)).sort();
        for (var i = 0; i < sortedOldArr.length; i++) {
            if (sortedOldArr[i] !== clonedNewArr[i]) {
                return false;
            }
        }
        return true;
    };
    NotificationsSettingsComponent.prototype.getUserPreferences = function () {
        var result = '';
        if (this.notificationSettings && this.notificationSettings !== null) {
            var notificationsArr = [];
            for (var key in this.notificationSettings) {
                if (this.notificationSettings.hasOwnProperty(key) && this.notificationSettings[key] === true) {
                    notificationsArr.push(key);
                }
            }
            if (notificationsArr && notificationsArr.length > 0) {
                result = notificationsArr.join(',');
            }
            else {
                result = '';
            }
        }
        return result;
    };
    NotificationsSettingsComponent.prototype.getUserInfo = function () {
        var _this = this;
        this.getUserSub$ = this._store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_3__["getUser"])).subscribe(function (data) {
            if (data && data !== null && data.pushpermissions) {
                for (var _i = 0, _a = Object.keys(data.pushpermissions); _i < _a.length; _i++) {
                    var key = _a[_i];
                    _this.notificationSettings[key] = data.pushpermissions[key] === '1';
                }
                _this.notificationOldString = _this.getUserPreferences();
                _this.changeUserPreferences();
            }
        });
    };
    NotificationsSettingsComponent.prototype.saveChanges = function () {
        var _this = this;
        if (this.isUpdated) {
            this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_4__["LogAmplitudeEvent"]({
                name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_5__["AmplitudeEvents"].notificationsChanged,
                props: {
                    notifs: this.notificationString
                }
            }));
            this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_7__["ofType"])(_anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_6__["SettingsActionTypes"].PostUserPreferencesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1))
                .subscribe(function (res) {
                var response = res.payload;
                if (response.status === 'ok') {
                    _this.isUpdated = false;
                }
            });
            this.submit.emit(this.notificationString);
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], NotificationsSettingsComponent.prototype, "submit", void 0);
    NotificationsSettingsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-notifications-settings',
            template: __webpack_require__(/*! raw-loader!./notifications-settings.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/notifications-settings/notifications-settings.component.html"),
            styles: [__webpack_require__(/*! ./notifications-settings.component.scss */ "./src/app/modules/base/settings/notifications-settings/notifications-settings.component.scss"), __webpack_require__(/*! ../settings.component.scss */ "./src/app/modules/base/settings/settings.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"]])
    ], NotificationsSettingsComponent);
    return NotificationsSettingsComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/settings/settings-routing.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/modules/base/settings/settings-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: SettingsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsRoutingModule", function() { return SettingsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _settings_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings.component */ "./src/app/modules/base/settings/settings.component.ts");




var routes = [
    {
        path: '',
        component: _settings_component__WEBPACK_IMPORTED_MODULE_3__["SettingsComponent"]
    }
];
var SettingsRoutingModule = /** @class */ (function () {
    function SettingsRoutingModule() {
    }
    SettingsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], SettingsRoutingModule);
    return SettingsRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/base/settings/settings.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/modules/base/settings/settings.component.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".white-box {\n  margin: 0.5em auto;\n  min-width: 5em;\n  border: 1px solid var(--box-border);\n  border-radius: 0.5em;\n  box-shadow: 3px 5px 20px -10px var(--border-shadow-border);\n  display: block;\n  background-color: var(--light-background);\n  position: relative;\n  max-width: 55em;\n  margin-top: 2em;\n}\n\nhr {\n  color: var(--hr-box);\n  border-color: var(--hr-box);\n  margin: 0 2em;\n}\n\n.one-line {\n  white-space: nowrap;\n}\n\na {\n  color: var(--text-color);\n}\n\na:hover {\n  text-decoration: none;\n}\n\n.flexbox {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  padding: 2em;\n}\n\n.flexbox.colm {\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n\n.flexbox.start {\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n}\n\n.flexbox.end {\n  -webkit-box-align: end;\n      -ms-flex-align: end;\n          align-items: flex-end;\n}\n\n.label-fixed {\n  white-space: nowrap;\n  font-weight: 600;\n  font-size: 1.1em;\n}\n\n.input-box-border {\n  border: 1px solid var(--border-light);\n  border-radius: 3em;\n  padding: 0.75em 1.5em;\n}\n\n.action-link {\n  cursor: pointer;\n  color: #0099F5;\n  font-size: 1.1em;\n}\n\n.button-box {\n  margin: 1em auto;\n}\n\n.m2-auto {\n  margin: 2em auto;\n}\n\n.sm-font {\n  font-size: 0.9em;\n}\n\n.md-font {\n  font-size: 1.2em;\n}\n\n.lg-font {\n  font-size: 1.5em;\n}\n\n.check {\n  font-size: 0.6em;\n  color: #0099F5;\n}\n\n.input-err {\n  border-color: red !important;\n}\n\n.err {\n  color: red;\n}\n\n.sm-description {\n  color: var(--dark-gray);\n  padding: 0 0.5em;\n}\n\n.disabled {\n  opacity: 0.5;\n  cursor: not-allowed !important;\n}\n\n.description {\n  font-size: 0.8em;\n  color: var(--dark-gray-updated);\n}\n\n.dark-gray {\n  color: var(--text-color-dark);\n}\n\n.arrow-left {\n  font-size: 0.6em;\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n  cursor: pointer;\n}\n\n.pointer {\n  cursor: pointer;\n}\n\n.arrow {\n  font-size: 0.5em;\n  cursor: pointer;\n}\n\n.max-width-55 {\n  max-width: 55em;\n}\n\n.no-padding {\n  padding-right: 0em;\n}\n\n.tab-label {\n  font-size: 1.2em;\n  font-weight: 300;\n  color: var(--text-color-light);\n}\n\nimg.icon {\n  max-width: 2em;\n}\n\n::ng-deep ul .nav-link.active, ::ng-deep ul .nav-link.selected {\n  border-bottom: 2px solid var(--text-color) !important;\n}\n\n::ng-deep ul .nav-link.active .tab-label, ::ng-deep ul .nav-link.selected .tab-label {\n  font-size: 1.3em;\n  font-weight: 600;\n  color: var(--text-color) !important;\n}\n\nhtml[lang=ar] :host .no-padding {\n  padding-right: 2em;\n  padding-left: 0;\n}\n\nhtml[lang=ar] :host .arrow-left {\n  -webkit-transform: rotate(360deg);\n      -ms-transform: rotate(360deg);\n          transform: rotate(360deg);\n}\n\n/* The switch - the box around the slider */\n\n.switch, .switch-updated {\n  position: relative;\n  display: inline-block;\n  width: 35px;\n  height: 18px;\n  margin-bottom: 0 !important;\n}\n\n/* Hide default HTML checkbox */\n\n.switch input, .switch-updated input {\n  opacity: 0;\n  width: 0;\n  height: 0;\n}\n\ninput {\n  background: var(--gray-light-background);\n  color: var(--text-color);\n}\n\n::ng-deep input {\n  background: var(--light-background);\n  color: var(--text-color);\n}\n\n.hidden-input {\n  width: 100%;\n  height: 100%;\n  border: none;\n  outline: none;\n  padding: 0;\n  color: var(--text-color);\n  font-size: 1.1em;\n  width: 15em;\n  background: var(--light-background);\n}\n\n@media (max-width: 768px) {\n  .hidden-input {\n    font-size: 0.9em;\n  }\n}\n\n.hidden-input:focus {\n  box-shadow: unset !important;\n}\n\n/* The slider */\n\n.slider {\n  position: absolute;\n  cursor: pointer;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background-color: var(--slider-background);\n}\n\n.slider:before {\n  position: absolute;\n  content: \"\";\n  height: 16px;\n  width: 16px;\n  left: 1.5px;\n  bottom: 1px;\n  background-color: white;\n  -webkit-transition: 0.4s;\n  transition: 0.4s;\n}\n\ninput:checked + .slider {\n  background-color: var(--brand-purple);\n}\n\ninput:checked + .slider:before {\n  -webkit-transform: translateX(15px);\n  -ms-transform: translateX(15px);\n  transform: translateX(15px);\n  left: 3px;\n}\n\n/* Rounded sliders */\n\n.slider.round {\n  border-radius: 20px;\n}\n\n.slider.round:before {\n  border-radius: 50%;\n}"

/***/ }),

/***/ "./src/app/modules/base/settings/settings.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/modules/base/settings/settings.component.ts ***!
  \*************************************************************/
/*! exports provided: SettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsComponent", function() { return SettingsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/settings.actions */ "./src/app/core/redux/actions/settings.actions.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_services_settings_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/services/settings.service */ "./src/app/core/services/settings.service.ts");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/modules/player/actions/player.actions */ "./src/app/core/modules/player/actions/player.actions.ts");
/* harmony import */ var _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @anghami/redux/actions/desktop-client.actions */ "./src/app/core/redux/actions/desktop-client.actions.ts");
/* harmony import */ var _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
















var REQUIRED_CLICKS_FOR_DEVTOOLS = 7;
var SettingsComponent = /** @class */ (function () {
    function SettingsComponent(_store, _actionSubject, _translateService, _route, _authService, _settingsService, _changeDetector, utils) {
        this._store = _store;
        this._actionSubject = _actionSubject;
        this._translateService = _translateService;
        this._route = _route;
        this._authService = _authService;
        this._settingsService = _settingsService;
        this._changeDetector = _changeDetector;
        this.utils = utils;
        this.class = 'ang-view';
        this.appLabelClickNumber = 0; // Used for desktop app devtools toggle logic
        this.appSettings = {};
    }
    SettingsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.isLoggedin = this._authService.isUserLoggedIn();
        this.routeParam$ = this._route.queryParams.subscribe(function (queryParams) {
            if (queryParams && queryParams !== null) {
                if (queryParams.code) {
                    _this.activeTab = 'music-settings';
                }
                else if (queryParams.story) {
                    _this.activeTab = 'account-settings';
                }
            }
        });
    };
    SettingsComponent.prototype.ngOnDestroy = function () {
        if (this.postUserPreferencesSuccess$) {
            this.postUserPreferencesSuccess$.unsubscribe();
        }
        if (this.routeParam$) {
            this.routeParam$.unsubscribe();
        }
    };
    SettingsComponent.prototype.saveChanges = function () {
        var _this = this;
        var userPreferencesObject = {};
        if (this.notifications && Object.keys(this.notifications).length > 0) {
            userPreferencesObject['notifications'] = this.notifications;
        }
        if (this.musicPreferences &&
            Object.keys(this.musicPreferences).length > 0) {
            userPreferencesObject['musicPreferences'] = this.musicPreferences;
        }
        if (this.appSettings && Object.keys(this.appSettings).length > 0) {
            userPreferencesObject['appSettings'] = this.appSettings;
        }
        if (this.accountSettings && Object.keys(this.accountSettings).length > 0) {
            userPreferencesObject['accountSettings'] = this.accountSettings;
        }
        this.postUserPreferencesSuccess$ = this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_2__["SettingsActionTypes"].PostUserPreferencesSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["take"])(1))
            .subscribe(function (action) {
            var response = action.payload;
            if (response && response.status === 'ok') {
                _this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__["OpenDialog"]({
                    title: _this._translateService.instant('preferences_updated_success'),
                    displaymode: 'toast'
                }));
                if (userPreferencesObject.appSettings &&
                    userPreferencesObject.appSettings.userlang) {
                    _this.utils.clearSwCache();
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                }
                if (userPreferencesObject.notifications ||
                    userPreferencesObject.musicPreferences) {
                    if (userPreferencesObject.musicPreferences &&
                        userPreferencesObject.musicPreferences.audioquality) {
                        var quality = userPreferencesObject.musicPreferences.audioquality.value;
                        var type = userPreferencesObject.musicPreferences.audioquality.setting;
                        _this._store.dispatch(new _core_modules_player_actions_player_actions__WEBPACK_IMPORTED_MODULE_12__["UpdateAudioQuality"]([
                            {
                                quality: quality,
                                type: type
                            }
                        ]));
                    }
                    _this._store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_10__["AuthenticateUser"]());
                }
            }
            else if (response && response.responseData.error) {
                _this.errorMsg = response.responseData.error.message;
            }
        });
        this.postUserPreferencesError$ = this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_2__["SettingsActionTypes"].PostUserPreferencesError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["take"])(1))
            .subscribe(function (action) {
            var response = action.payload;
            if (response && response.error) {
                _this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__["OpenDialog"](response));
            }
        });
        this._store.dispatch(new _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_2__["PostUserPreferences"](userPreferencesObject)); // { type: type, value: value }
    };
    SettingsComponent.prototype.notificationsChange = function (event) {
        this.clearPreferences('notifications');
        this.notifications = {
            type: 'POSTuserpreferences',
            pushoptions: event
        };
        this.saveChanges();
    };
    SettingsComponent.prototype.musicPreferencesChange = function (event) {
        this.clearPreferences('music');
        this.musicPreferences = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, event);
        if (event['lastfm'] !== undefined && event['lastfm'] !== null) {
            this.scrobbleLastFm(event['lastfm']);
        }
        else {
            this.saveChanges();
        }
    };
    SettingsComponent.prototype.appSettingsChange = function (event) {
        this.clearPreferences('app');
        this.appSettings = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, event);
        this.saveChanges();
    };
    SettingsComponent.prototype.accountPreferencesChange = function (event) {
        this.clearPreferences('account');
        this.accountSettings = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, event);
        this.saveChanges();
    };
    SettingsComponent.prototype.clearPreferences = function (type) {
        this.notifications =
            type !== 'notifications' ? undefined : this.notifications;
        this.musicPreferences =
            type !== 'music' ? undefined : this.musicPreferences;
        this.appSettings = type !== 'app' ? undefined : this.appSettings;
        this.accountSettings = type !== 'account' ? undefined : this.accountSettings;
    };
    SettingsComponent.prototype.scrobbleLastFm = function (params) {
        this._store.dispatch(new _anghami_redux_actions_settings_actions__WEBPACK_IMPORTED_MODULE_2__["ScrobbleLastFM"](params));
    };
    SettingsComponent.prototype.showToastIfNotLoggedIn = function () {
        if (!this.isLoggedin) {
            this._settingsService.showToastIfNotLoggedIn(this.isLoggedin);
            this.loginDialog();
        }
    };
    SettingsComponent.prototype.loginDialog = function () {
        this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_5__["OpenCustomDialog"]({
            type: _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_14__["DIALOG_TYPES"].LOGIN
        }));
    };
    SettingsComponent.prototype.changedTab = function (event) {
        var _this = this;
        var activetab = event.nextId;
        if (!this.isLoggedin) {
            this._settingsService.showToastIfNotLoggedIn(this.isLoggedin);
            this.loginDialog();
            activetab = 'app-settings';
        }
        setTimeout(function () {
            _this.settings.select(activetab);
        });
    };
    SettingsComponent.prototype.onAppTabLabelClick = function () {
        // Desktop app devtools toggle logic
        this.appLabelClickNumber++;
        if (this.appLabelClickNumber === REQUIRED_CLICKS_FOR_DEVTOOLS && !!window['desktopClient']) {
            this._store.dispatch(new _anghami_redux_actions_desktop_client_actions__WEBPACK_IMPORTED_MODULE_13__["EmitMessageToDesktopClient"]({
                message: 'devtools-open',
                payload: {}
            }));
            this.appLabelClickNumber = 0;
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('attr.class'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SettingsComponent.prototype, "class", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('settings', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SettingsComponent.prototype, "settings", void 0);
    SettingsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-settings',
            template: __webpack_require__(/*! raw-loader!./settings.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/settings/settings.component.html"),
            styles: [__webpack_require__(/*! ./settings.component.scss */ "./src/app/modules/base/settings/settings.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["ActionsSubject"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"],
            _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_8__["AuthService"],
            _anghami_services_settings_service__WEBPACK_IMPORTED_MODULE_9__["SettingsService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_15__["UtilService"]])
    ], SettingsComponent);
    return SettingsComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/settings/settings.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/base/settings/settings.module.ts ***!
  \**********************************************************/
/*! exports provided: SettingsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsModule", function() { return SettingsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _settings_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings-routing.module */ "./src/app/modules/base/settings/settings-routing.module.ts");
/* harmony import */ var _settings_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./settings.component */ "./src/app/modules/base/settings/settings.component.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _app_settings_app_settings_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-settings/app-settings.component */ "./src/app/modules/base/settings/app-settings/app-settings.component.ts");
/* harmony import */ var _account_settings_account_settings_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./account-settings/account-settings.component */ "./src/app/modules/base/settings/account-settings/account-settings.component.ts");
/* harmony import */ var _music_settings_music_settings_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./music-settings/music-settings.component */ "./src/app/modules/base/settings/music-settings/music-settings.component.ts");
/* harmony import */ var _notifications_settings_notifications_settings_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./notifications-settings/notifications-settings.component */ "./src/app/modules/base/settings/notifications-settings/notifications-settings.component.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _core_components_audio_quality_audio_quality_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/components/audio-quality/audio-quality.component */ "./src/app/core/components/audio-quality/audio-quality.component.ts");
/* harmony import */ var _core_components_action_link_action_link_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/components/action-link/action-link.component */ "./src/app/core/components/action-link/action-link.component.ts");
/* harmony import */ var _core_components_logs_modal_logs_modal_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../core/components/logs-modal/logs-modal.component */ "./src/app/core/components/logs-modal/logs-modal.component.ts");
/* harmony import */ var _anghami_services_import_music_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/services/import-music.service */ "./src/app/core/services/import-music.service.ts");
/* harmony import */ var _anghami_services_settings_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @anghami/services/settings.service */ "./src/app/core/services/settings.service.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _anghami_redux_effects_settings_effects__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @anghami/redux/effects/settings.effects */ "./src/app/core/redux/effects/settings.effects.ts");
/* harmony import */ var _anghami_services_layout_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @anghami/services/layout.service */ "./src/app/core/services/layout.service.ts");
/* harmony import */ var _anghami_redux_effects_layout_effects__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @anghami/redux/effects/layout.effects */ "./src/app/core/redux/effects/layout.effects.ts");






















var SettingsModule = /** @class */ (function () {
    function SettingsModule() {
    }
    SettingsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _settings_routing_module__WEBPACK_IMPORTED_MODULE_3__["SettingsRoutingModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbTabsetModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbAccordionModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"].forChild(),
                _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_12__["IconModule"],
                _ngrx_effects__WEBPACK_IMPORTED_MODULE_18__["EffectsModule"].forFeature([
                    _anghami_redux_effects_settings_effects__WEBPACK_IMPORTED_MODULE_19__["SettingsEffects"],
                    _anghami_redux_effects_layout_effects__WEBPACK_IMPORTED_MODULE_21__["LayoutEffects"],
                ])
            ],
            declarations: [
                _settings_component__WEBPACK_IMPORTED_MODULE_4__["SettingsComponent"],
                _app_settings_app_settings_component__WEBPACK_IMPORTED_MODULE_8__["AppSettingsComponent"],
                _account_settings_account_settings_component__WEBPACK_IMPORTED_MODULE_9__["AccountSettingsComponent"],
                _music_settings_music_settings_component__WEBPACK_IMPORTED_MODULE_10__["MusicSettingsComponent"],
                _notifications_settings_notifications_settings_component__WEBPACK_IMPORTED_MODULE_11__["NotificationsSettingsComponent"],
                _core_components_audio_quality_audio_quality_component__WEBPACK_IMPORTED_MODULE_13__["AudioQualityComponent"],
                _core_components_action_link_action_link_component__WEBPACK_IMPORTED_MODULE_14__["ActionLinkComponent"],
                _core_components_logs_modal_logs_modal_component__WEBPACK_IMPORTED_MODULE_15__["LogsModalComponent"]
            ],
            entryComponents: [_core_components_logs_modal_logs_modal_component__WEBPACK_IMPORTED_MODULE_15__["LogsModalComponent"]],
            exports: [_settings_component__WEBPACK_IMPORTED_MODULE_4__["SettingsComponent"]],
            providers: [_anghami_services_import_music_service__WEBPACK_IMPORTED_MODULE_16__["ImportMusicService"], _anghami_services_settings_service__WEBPACK_IMPORTED_MODULE_17__["SettingsService"], _anghami_services_layout_service__WEBPACK_IMPORTED_MODULE_20__["LayoutService"],],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], SettingsModule);
    return SettingsModule;
}());



/***/ })

}]);