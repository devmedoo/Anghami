(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["download-page-download-page-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/download-page/download-page.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/download-page/download-page.component.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header\">\n  <h1 class=\"title\" i18n=\"@@download_landing_title\">Thank you for downloading the Anghami desktop app</h1>\n  <h1 class=\"mobile-title\" [ngClass]=\"{'no-extra-margin': isMobile}\" i18n=\"@@download_landing_button_long\">Download Anghami Desktop app</h1>\n  <img class=\"wave\" src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\" />\n  <div class='mobile-download-button' *ngIf=\"!isMobile\"> \n    <a [attr.href]=\"downloadLink\" i18n=\"@@download_landing_button_short\"> Download Now </a> </div>\n</div>\n<span class='redownload' *ngIf=\"!isMobile\"><span i18n=\"@@download_landing_problem_downloading\" >Problem Downloading? </span> \n  <a [attr.href]=\"downloadLink\" i18n=\"@@Download_landing_problem_tryagain\">Try Again</a></span>\n\n<div class='row'>\n  <div class='col-lg-12'>\n    <h2 i18n=\"@@download_landing_subtitle\">Perks Of Having The Desktop App</h2>\n    <div class=\"benefits-container\">\n      <div class=\"benefit\">\n        <div class=\"figure miniplayer\"></div>\n        <div class='benefit-description'>\n          <h5 i18n=\"@@download_landing_subtitle_player\">Mini player for a simpler view</h5>\n          <p i18n=\"@@download_landing_subtitle_description_player\">You can minimize your full screen view to have a better control on\n            your\n            music</p>\n        </div>\n      </div>\n      <div class=\"benefit\">\n        <div class=\"figure uploadmusic\"></div>\n        <div class='benefit-description'>\n          <h5 i18n=\"@@download_landing_subtitle_upload\">Upload your music</h5>\n          <p i18n=\"@@download_landing_subtitle_description_upload\">You can minimize your full screen view to have a better control on\n            your\n            music</p>\n        </div>\n      </div>\n      <div class=\"benefit\">\n        <div class=\"figure downloadoffline\"></div>\n        <div class='benefit-description'>\n          <h5 i18n=\"@@download_landing_subtitle_offline\">Download songs & play them offline</h5>\n          <p i18n=\"@@download_landing_subtitle_description_offline\">No internet no problem! Keep on playing</p>\n        </div>\n      </div>\n      <div class=\"benefit\">\n        <div class=\"figure keyboardhotkeys\"></div>\n        <div class='benefit-description'>\n          <h5 i18n=\"@@download_landing_subtitle_keyboard\">Keyboard Hot keys</h5>\n          <p i18n=\"@@download_landing_subtitle_description_keyboard\">Play, pause, skip and control volume right from your keyboard</p>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n<div class='row'>\n  <div class=\"bottom-flex\">\n    <h3 i18n=\"@@download_landing_available_everywhere\"> Anghami Available everywhere.</h3>\n    <img src='../../../../assets/img/desktop-app-perks/everywhere.png' />\n    <h3 i18n=\"@@download_landing_devices\">Get the app on iOS, Android & Windows</h3>\n    <div class='getit-on'>\n        <a href=\"https://itunes.apple.com/us/app/anghami-%D8%A7%D9%86%D8%BA%D8%A7%D9%85%D9%8A/id545395155?mt=8\">\n          <img class=\"app-figure\" [src]=\"env + 'app-store.png'\" alt=\"\" />\n          <!-- <div class=\"figure app-store\"></div> -->\n        </a>\n        <a href=\"https://play.google.com/store/apps/details?id=com.anghami&hl=en\">\n          <img class=\"app-figure middle\" [src]=\"env + 'google-play-btn.png'\" alt=\"\" />\n          <!-- <div class=\"figure google-play\"></div> -->\n        </a>\n        <a href=\"https://desktop.anghami.com/win64/AnghamiSetup.zip\">\n          <img class=\"app-figure microsoft\" [src]=\"env + 'microsoft-button.png'\" alt=\"\" />\n          <!-- <div class=\"figure microsoft\"></div> -->\n        </a>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/modules/landing/download-page/download-page-routing.module.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/modules/landing/download-page/download-page-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: routes, DownloadPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadPageRoutingModule", function() { return DownloadPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _download_page_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./download-page.component */ "./src/app/modules/landing/download-page/download-page.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var routes = [
    {
        path: '',
        component: _download_page_component__WEBPACK_IMPORTED_MODULE_1__["DownloadPageComponent"]
    }
];
var DownloadPageRoutingModule = /** @class */ (function () {
    function DownloadPageRoutingModule() {
    }
    DownloadPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"]]
        })
    ], DownloadPageRoutingModule);
    return DownloadPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/download-page/download-page.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/modules/landing/download-page/download-page.component.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  color: black;\n}\n:host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  font-family: var(--font-main-latin);\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: transparent -webkit-gradient(linear, left top, left bottom, from(#CE2DAD), to(#884BD7)) 0% 0% no-repeat padding-box;\n  background: transparent linear-gradient(180deg, #CE2DAD 0%, #884BD7 100%) 0% 0% no-repeat padding-box;\n  height: 35em;\n  background-size: 100%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  text-align: center;\n}\n@media (max-width: 600px) {\n  :host .header {\n    background-size: cover;\n    max-height: 25em;\n    background-position: center right !important;\n  }\n  :host .header h1 {\n    font-size: 2em;\n    margin-top: 6em;\n  }\n  :host .header .no-extra-margin {\n    margin-top: 1em !important;\n  }\n  :host .header .mobile-download-button {\n    display: block !important;\n    width: 15em;\n    background: white;\n    z-index: 10;\n    margin: auto;\n    margin-top: 9em;\n    text-align: center;\n    height: 3em;\n    line-height: 3em;\n    font-weight: bold;\n    box-shadow: 0px 3px 6px #00000029;\n    border-radius: 17px;\n    cursor: pointer;\n    color: black;\n  }\n}\n@media (max-width: 600px) and (max-width: 348px) {\n  :host .header .mobile-download-button {\n    margin-top: 7em;\n  }\n}\n@media (max-width: 600px) {\n  :host .header .mobile-download-button a {\n    text-decoration: none;\n    color: black;\n  }\n}\n@media (max-width: 600px) {\n  :host .header .mobile-title {\n    display: block !important;\n    padding: 0em 0.5em;\n  }\n}\n@media (max-width: 600px) {\n  :host .header .title {\n    display: none !important;\n  }\n}\n:host .header .mobile-download-button {\n  display: none;\n}\n:host .header .mobile-title {\n  display: none;\n}\n:host .header .title {\n  display: block;\n}\n:host .header .wave {\n  width: 150%;\n  position: absolute;\n  bottom: -0.1em;\n  right: 0em;\n}\n:host .redownload {\n  text-align: center;\n  width: 100%;\n  margin: auto;\n  display: block;\n  margin-top: 1em;\n  font-size: 1.2em;\n}\n@media (max-width: 768px) {\n  :host .redownload {\n    display: none;\n  }\n}\n:host .row {\n  width: 95%;\n  margin: auto;\n  margin-top: 8em;\n  margin-bottom: 4em;\n}\n:host .row .col-lg-12 {\n  margin-left: none;\n  margin-right: none;\n  text-align: center;\n}\n:host .row .col-lg-12 h2 {\n  margin-bottom: 1.5em;\n}\n@media (max-width: 600px) {\n  :host .row {\n    width: 90%;\n  }\n}\n:host .benefits-container {\n  text-align: center;\n}\n:host .benefits-container .benefit {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0.5em 1.5em;\n  max-width: 16em;\n}\n:host .benefits-container .benefit h5 {\n  font-size: 1.2em;\n}\n:host .benefits-container .benefit .figure {\n  width: 15em;\n  height: 15em;\n  background-repeat: no-repeat;\n  background-size: 100%;\n  background-position: center center;\n}\n:host .benefits-container .benefit .figure.miniplayer {\n  background-image: url('mini player.png');\n}\n:host .benefits-container .benefit .figure.uploadmusic {\n  background-image: url('Upload your music.png');\n}\n:host .benefits-container .benefit .figure.downloadoffline {\n  background-image: url('Download.png');\n}\n:host .benefits-container .benefit .figure.keyboardhotkeys {\n  background-image: url('Keyboard Hot keys.png');\n}\n@media (max-width: 600px) {\n  :host .benefits-container .benefit {\n    max-width: 10em;\n  }\n  :host .benefits-container .benefit .figure {\n    width: 10em;\n    height: 10em;\n  }\n}\n:host .bottom-flex {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -ms-flex-line-pack: center;\n      align-content: center;\n  margin: auto;\n  text-align: center;\n}\n:host .bottom-flex h3 {\n  margin-top: 1em;\n  margin-bottom: 1em;\n}\n:host .bottom-flex img {\n  width: 32em;\n  margin: auto;\n  margin-top: 0.2em;\n}\n@media (max-width: 600px) {\n  :host .bottom-flex h3 {\n    font-size: 1.7em;\n  }\n  :host .bottom-flex img {\n    width: 25em;\n  }\n}\n:host .bottom-flex .getit-on .app-figure {\n  width: 12.875em;\n  height: 3.9em;\n  background-repeat: no-repeat;\n  background-size: 100%;\n  background-position: center center;\n}\n:host .bottom-flex .getit-on .app-figure.microsoft {\n  border-radius: 5px;\n}\n:host .bottom-flex .getit-on .app-figure.middle {\n  margin-right: 0.5em;\n  margin-left: 0.5em;\n}\n@media (max-width: 600px) {\n  :host .bottom-flex .getit-on .app-figure {\n    width: 10em;\n    height: auto;\n  }\n  :host .bottom-flex .getit-on .app-figure.microsoft {\n    height: 2.98em;\n    margin-top: 0.3em;\n  }\n}"

/***/ }),

/***/ "./src/app/modules/landing/download-page/download-page.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/modules/landing/download-page/download-page.component.ts ***!
  \**************************************************************************/
/*! exports provided: DownloadPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadPageComponent", function() { return DownloadPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment_prod__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../environments/environment.prod */ "./src/environments/environment.prod.ts");




var DownloadPageComponent = /** @class */ (function () {
    function DownloadPageComponent(_utilService) {
        this._utilService = _utilService;
        this.env = _environments_environment_prod__WEBPACK_IMPORTED_MODULE_3__["environment"].assetsCDN + "img/products/";
        this.isMobile = this._utilService.detectmob();
    }
    DownloadPageComponent.prototype.ngOnInit = function () {
        if (this._utilService.isServer()) {
            return;
        }
        if (!this.isMobile) {
            if (window && window.navigator && window.navigator.userAgent.indexOf('Mac') !== -1) {
                this.downloadLink = 'https://desktop.anghami.com/mac/Anghami-Installer.zip';
            }
            else {
                this.downloadLink = 'https://desktop.anghami.com/win64/AnghamiSetup.zip';
            }
            window.location.href = this.downloadLink;
        }
    };
    DownloadPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'anghami-download-page',
            template: __webpack_require__(/*! raw-loader!./download-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/download-page/download-page.component.html"),
            styles: [__webpack_require__(/*! ./download-page.component.scss */ "./src/app/modules/landing/download-page/download-page.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilService"]])
    ], DownloadPageComponent);
    return DownloadPageComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/download-page/download-page.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/modules/landing/download-page/download-page.module.ts ***!
  \***********************************************************************/
/*! exports provided: DownloadPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadPageModule", function() { return DownloadPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _download_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./download-page.component */ "./src/app/modules/landing/download-page/download-page.component.ts");
/* harmony import */ var _download_page_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./download-page-routing.module */ "./src/app/modules/landing/download-page/download-page-routing.module.ts");





var DownloadPageModule = /** @class */ (function () {
    function DownloadPageModule() {
    }
    DownloadPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [_download_page_routing_module__WEBPACK_IMPORTED_MODULE_4__["DownloadPageRoutingModule"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]],
            exports: [_download_page_component__WEBPACK_IMPORTED_MODULE_3__["DownloadPageComponent"]],
            declarations: [_download_page_component__WEBPACK_IMPORTED_MODULE_3__["DownloadPageComponent"]],
            providers: [],
        })
    ], DownloadPageModule);
    return DownloadPageModule;
}());



/***/ })

}]);