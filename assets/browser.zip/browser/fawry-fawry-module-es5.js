(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["fawry-fawry-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/fawry/fawry.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/fawry/fawry.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"page-fawry\">\n  <div class=\"header\">\n      <h1 class=\"title\">\n        <ng-container i18n=\"@@Anghami Plus available at Fawry\"> Anghami Plus available at Fawry </ng-container>\n      </h1>\n      <h2 i18n=\"@@Music anytime, anywhere.\">Music anytime, anywhere.</h2>\n     \n  </div>\n    <div class=\"group\">\n      <div class=\"grouptitle\" i18n=\"@@Music anytime, anywhere.\">\n        Anghami Plus vouchers\n      </div>\n      <div class=\"cards-cont\">\n          <img src=\"https://anghamiwebcdn.akamaized.net/assets/img/fawry/card1.png\">\n          <img src=\"https://anghamiwebcdn.akamaized.net/assets/img/fawry/card2.png\">\n          <img src=\"https://anghamiwebcdn.akamaized.net/assets/img/fawry/card3.png\">\n          <img src=\"https://anghamiwebcdn.akamaized.net/assets/img/fawry/card4.png\">\n      </div>\n    </div>\n\n\n  <div class=\"features\">\n    <h2 class=\"title\" i18n=\"@@How to redeem your voucher\">\n      How to redeem your voucher\n    </h2>\n    <div class=\"steps-container\">\n      <div class=\"step\">\n        <img src=\"https://anghamiwebcdn.akamaized.net/assets/img/fawry/s1.png\">\n        <span i18n=\"@@Go to anghami.com/redeem\">\n          Go to anghami.com/redeem\n        </span>\n      </div>\n      <div class=\"step\">\n        <img src=\"https://anghamiwebcdn.akamaized.net/assets/img/fawry/s2.png\">\n        <span i18n=\"@@Login with your Anghami account\">\n          Login with your Anghami account\n        </span>\n      </div>\n      <div class=\"step\">\n        <img src=\"https://anghamiwebcdn.akamaized.net/assets/img/fawry/s3.png\">\n        <span i18n=\"@@Enter the code\">\n          Enter the code\n        </span>\n      </div>\n    </div>\n    <div [routerLink]=\"['/redeem']\" routerLinkActive=\"router-link-active\"  class=\"btn btn-primary\"  i18n=\"@@Redeem your voucher\">\n        Redeem your voucher\n    </div>\n    <!-- <div i18n=\"@@fawry_disclaimer\" class=\"disclaimer py-1\">Valid for first time Fawry users only</div> -->\n  </div>\n  <div class=\"locator\">\n    <div class=\"group\">\n      <div class=\"grouptitle\" i18n=\"@@Store locator\">Store locator</div>\n      <div class=\"iframe-container\">\n        <iframe width=\"560\" height=\"315\" [src]=\"iframeSrouce\"></iframe>\n      </div>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/modules/landing/fawry/fawry-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/modules/landing/fawry/fawry-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: routes, FawryRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FawryRoutingModule", function() { return FawryRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _fawry_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fawry.component */ "./src/app/modules/landing/fawry/fawry.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var routes = [
    {
        path: '',
        component: _fawry_component__WEBPACK_IMPORTED_MODULE_1__["FawryComponent"]
    }
];
var FawryRoutingModule = /** @class */ (function () {
    function FawryRoutingModule() {
    }
    FawryRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"]]
        })
    ], FawryRoutingModule);
    return FawryRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/fawry/fawry.component.scss":
/*!************************************************************!*\
  !*** ./src/app/modules/landing/fawry/fawry.component.scss ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".page-fawry .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: url(\"https://anghamiwebcdn.akamaized.net/assets/img/headers/fawry/fawry-header.jpg\");\n  height: 30em;\n  background-size: cover;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  .page-fawry .header {\n    background-size: cover;\n    min-height: 20em;\n    background-position: center center !important;\n  }\n  .page-fawry .header .title {\n    font-size: 2em;\n  }\n  .page-fawry .header h3 {\n    font-size: 1.2em;\n    margin-top: 1.5em;\n  }\n}\n.page-fawry .header .title {\n  font-weight: bold;\n  text-align: center;\n}\n.page-fawry .header .title span {\n  font-size: 0.6em;\n  display: block;\n  margin: auto;\n  padding: 0.5em;\n  text-align: center;\n}\n.page-fawry .header h3 {\n  font-size: 1.5em;\n  font-weight: normal;\n  margin-top: 2em;\n}\n.page-fawry .header .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}\n.page-fawry .group {\n  display: block;\n  width: 70%;\n  margin: auto;\n  padding: 2em;\n}\n.page-fawry .group .grouptitle {\n  font-size: 2em;\n  margin-bottom: 1em;\n  border-bottom: 1px solid rgba(0, 0, 0, 0.25);\n  width: 95%;\n}\n.page-fawry .group .cards-cont {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin: auto;\n  width: 100%;\n}\n.page-fawry .group .cards-cont img {\n  width: 20%;\n  margin-right: 1em;\n  margin-right: 2em;\n  border-radius: 12px;\n  margin-left: 2em;\n}\n@media (max-width: 768px) {\n  .page-fawry .group {\n    width: 100%;\n  }\n  .page-fawry .group .cards-cont {\n    -ms-flex-wrap: wrap;\n        flex-wrap: wrap;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n  }\n  .page-fawry .group .cards-cont img {\n    width: 15em;\n    margin-bottom: 1.5em;\n  }\n}\n.page-fawry .features {\n  background: #f5f5f5;\n  margin-top: 1.5em;\n  padding-top: 1.5em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.page-fawry .features .title {\n  color: #92278f;\n  text-align: center;\n  font-size: 2.5em;\n  font-weight: normal;\n}\n.page-fawry .features .steps-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 60%;\n  margin: auto;\n}\n.page-fawry .features .steps-container .step {\n  padding: 2em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.page-fawry .features .steps-container .step img {\n  width: 80%;\n}\n.page-fawry .features .steps-container .step span {\n  font-weight: bold;\n  font-size: 1em;\n  display: block;\n  margin: auto;\n  text-align: center;\n}\n.page-fawry .features .btn {\n  padding: 0.7em 1.8em;\n  font-size: 1.2em;\n  margin-top: 1.5em;\n  border-radius: 2em;\n  width: 14em;\n  background: #8d00f2;\n  color: #FFF;\n  border: 1px solid var(--btn-border-color);\n  cursor: pointer;\n}\n.page-fawry .features .btn:hover {\n  -webkit-transition: all 0.2s ease !important;\n  transition: all 0.2s ease !important;\n  width: 15em;\n}\n@media (max-width: 768px) {\n  .page-fawry .features {\n    padding-top: 1em;\n  }\n  .page-fawry .features .title {\n    font-size: 2.2em;\n  }\n  .page-fawry .features .steps-container {\n    width: 80%;\n    -ms-flex-wrap: wrap;\n        flex-wrap: wrap;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n  }\n  .page-fawry .features .steps-container .step img {\n    width: 15em;\n  }\n  .page-fawry .features .steps-container .step span {\n    margin: 0;\n    margin-left: 1em;\n  }\n}\n.page-fawry .locator {\n  height: 50em;\n}\n.page-fawry .locator .group .grouptitle {\n  font-size: 2em;\n  width: 100%;\n  border-bottom: 1px solid rgba(0, 0, 0, 0.25);\n  line-height: 2em;\n  margin: 1em 0.5em 0.25em 0.5em;\n}\n.page-fawry .locator .iframe-container {\n  position: absolute;\n  width: 100%;\n  left: 0;\n  right: 0;\n}\n.page-fawry .locator .iframe-container iframe {\n  display: block;\n  margin: auto;\n  width: 100%;\n  height: 35em;\n  border: 0;\n}\n.page-fawry .disclaimer {\n  font-size: 0.9em;\n  margin-bottom: 2em;\n}"

/***/ }),

/***/ "./src/app/modules/landing/fawry/fawry.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/landing/fawry/fawry.component.ts ***!
  \**********************************************************/
/*! exports provided: FawryComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FawryComponent", function() { return FawryComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");



var FawryComponent = /** @class */ (function () {
    function FawryComponent(locale, sanitizer) {
        this.locale = locale;
        this.sanitizer = sanitizer;
        this.language = this.locale
            ? this.locale.indexOf('en') > -1
                ? 'en'
                : this.locale
            : 'en';
        if (this.language === 'ar') {
            this.iframeSrouce = this.sanitizer.bypassSecurityTrustResourceUrl('https://froms.fawryretail.com:9443/demos/MyFawryMap.aspx?lng=ar');
        }
        else {
            this.iframeSrouce = this.sanitizer.bypassSecurityTrustResourceUrl('https://froms.fawryretail.com:9443/demos/MyFawryMap.aspx?lng=en');
        }
    }
    FawryComponent.prototype.ngOnInit = function () { };
    FawryComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-fawry',
            template: __webpack_require__(/*! raw-loader!./fawry.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/fawry/fawry.component.html"),
            styles: [__webpack_require__(/*! ./fawry.component.scss */ "./src/app/modules/landing/fawry/fawry.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"]])
    ], FawryComponent);
    return FawryComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/fawry/fawry.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/modules/landing/fawry/fawry.module.ts ***!
  \*******************************************************/
/*! exports provided: FawryModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FawryModule", function() { return FawryModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _fawry_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./fawry-routing.module */ "./src/app/modules/landing/fawry/fawry-routing.module.ts");
/* harmony import */ var _fawry_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./fawry.component */ "./src/app/modules/landing/fawry/fawry.component.ts");







var FawryModule = /** @class */ (function () {
    function FawryModule() {
    }
    FawryModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _fawry_routing_module__WEBPACK_IMPORTED_MODULE_5__["FawryRoutingModule"],
                _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_3__["LoadingModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateModule"],
            ],
            declarations: [_fawry_component__WEBPACK_IMPORTED_MODULE_6__["FawryComponent"]],
            exports: [_fawry_component__WEBPACK_IMPORTED_MODULE_6__["FawryComponent"]]
        })
    ], FawryModule);
    return FawryModule;
}());



/***/ })

}]);