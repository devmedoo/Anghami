(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["about-about-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/inner-header/inner-header.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  id=\"headerid\"\n  class=\"header\"\n  [ngStyle]=\"backgroundimage\"\n  [ngClass]=\"{ extra: backgroundHeader.extra, smallerHeader: smallerHeader }\"\n>\n  <img\n    class=\"logo\"\n    *ngIf=\"backgroundHeader.innerLogo\"\n    [src]=\"backgroundHeader.innerLogo\"\n  />\n  <div>\n    <ng-container *ngIf=\"!isapi\">\n      <h1 class=\"title\">{{ backgroundHeader?.title | translateInstant }}</h1>\n      <h5 class=\"subtitle \">\n        {{ backgroundHeader?.subtitle | translateInstant }}\n      </h5>\n    </ng-container>\n    <ng-container *ngIf=\"isapi\">\n      <div class=\"title\">{{ backgroundHeader?.title }}</div>\n      <h5 class=\"subtitle \">{{ backgroundHeader?.subtitle }}</h5>\n    </ng-container>\n  </div>\n  <img\n    *ngIf=\"isWave\"\n    class=\"wave\"\n    src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\"\n  />\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/about/about.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/about/about.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<anghami-inner-header [backgroundHeader]=\"innerHeader\"></anghami-inner-header>\n<section class=\"full-row-layout\">\n  <div class=\"container\" *ngIf=\"locale != 'ar'\">\n    <div class=\"row\">\n      <div class=\"col-lg-12\">\n\n              \n\n\n        <h1 class=\"landing-page-title\">\n          About Anghami <span>— get to know us</span>\n        </h1>\n\n\n\n\n        <p class=\"text-justify\">\n          In a region where music is dominated by piracy, Anghami comes to fill\n          this gap by offering a legal music alternative in an enjoyable way\n          while making sure to implement a model that fairly remunerates artists\n          and labels.\n        </p>\n        <p class=\"text-justify\">\n          Introducing Anghami: the future of digital music consumption and the\n          first service of its kind in the Middle East & North Africa.\n        </p>\n        <p class=\"text-justify\">\n          Anghami is the leading Music platform in the Middle East which\n          provides a seamless experience to listen to unlimited music on-the-go\n          on your mobile. With millions of songs to search from, stream,\n          download and share, Anghami makes listening to music enjoyable again.\n        </p>\n        <p class=\"text-justify\">\n          Anghami is your music hub from which you can instantly play any Arabic\n          and International song or album wherever you are - in your car, at the\n          gym, or on the beach. You can also discover new music from your\n          favorite artists, share your favorite tracks in real-time with friends\n          on social networks, and download as many songs as you’d like for\n          offline play. Flights will never feel as long again!\n        </p>\n        <p class=\"text-justify\">\n          Anghami features licensed content from leading Arabic labels such as\n          Platinum Records, Mazzika, Melody and many others. Anghami also\n          features music from the major International labels such as Universal,\n          Sony, EMI, Warner and is continuously licensing new content to bring\n          you a complete experience from major aggregators to name a few\n          Believe, ArpuPlus, MT2, Info2cell…\n        </p>\n        <p class=\"text-justify\">\n          Free unlimited music is now available with you anywhere you go, across\n          devices and geographies. Now, that’s the future of music.\n        </p>\n        <p class=\"text-justify\">\n          Founded in 2012 by Eddy Maroun and Elie Habib, a team of music and\n          tech fanatics, Anghami is a Cayman Islands limited liability company\n          with affiliates and offices in Beirut and Dubai. It caters mainly for\n          the Middle East and North African audience and is available across the\n          continent bringing unlimited music to the Arab diaspora.\n        </p>\n        <p class=\"text-justify\">\n          Eddy has over 10 years of experience working in the entertainment,\n          music and mobile industry. Throughout his career, he has built close\n          relationships with music labels and mobile operators, and enchanted\n          audiences around the region with his keyboard.\n        </p>\n        <p class=\"text-justify\">\n          Elie is a tech guru who has launched several startups in the mobile\n          space. He has vast experience heading and building large platforms to\n          telcos and building strategic relationships with operators.\n        </p>\n        <p class=\"text-justify\">\n          In October 2012, Anghami inked an exclusive strategic partnership with\n          the leading MBC Group (www.mbc.net), the Middle East’s #1 media group\n          bringing the largest media exposure ever for a similar music service.\n          The combined efforts aim to driving more value and revenues to the\n          music industry to win over piracy.\n        </p>\n        <p class=\"text-justify\">\n          Anghami is funded and supported by regional VC firm “Middle East\n          Venture Partners” (www.mevp.com) leading the largest digital music\n          investment ever in the Middle-East.\n        </p>\n        <p class=\"text-justify\">\n          Anghami, today, is the number 1 Music platform in MENA region with the\n          largest catalog comprising of more than 30 Million songs available for\n          more than 70 Million users.\n        </p>\n      </div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-lg-12\">\n        <p>\n          Partner with us:\n          <a class=\"link\" href=\"mailto:partner@anghami.com\"\n            >partner@anghami.com</a\n          >\n        </p>\n        <p>\n          Advertise with us:\n          <a class=\"link\" href=\"mailto:advertise@anghami.com\"\n            >advertise@anghami.com</a\n          >\n        </p>\n      </div>\n    </div>\n  </div>\n  <div class=\"container\" *ngIf=\"locale == 'ar'\">\n    <div class=\"row\">\n      <div class=\"col-lg-12\">\n        <h1 class=\"landing-page-title\">عن أنغامي <span>— من نحن؟</span></h1>\n        <p class=\"text-justify\">\n          في منطقةٍ تسيطر فيها القرصنة على قطاع الموسيقى، تأتي “ أنغامي ” لتكسر\n          هذا النمط وتقدّم بديلاً موسيقيًا قانونيًا، بأسلوبٍ ممتع يضمن حقوق\n          الفنّانين وشركات الإنتاج.\n        </p>\n        <p class=\"text-justify\">\n          “ أنغامي ” هي أوّل خدمة من نوعها في الشرق الأوسط وشمال أفريقيا. تعكس\n          صورة مستقبل سوق الموسيقى الرقميّة وتتصدّر قائمة المنصّات الموسيقيّة في\n          المنطقة. تتيح لمستخدميها الاستماع إلى الموسيقى بطريقةٍ فعّالة ولا\n          محدودة عبر هواتفهم الذكيّة. بفضل تطبيق “ أنغامي ” وتقنيّاته المتطوّرة\n          في البحث والبثّ والتحميل والمشاركة، صار الاستماع إلى الموسيقى متعةً لا\n          تُضاهى!\n        </p>\n        <p class=\"text-justify\">\n          “ أنغامي ” هي مَقصِدُكم إذا أردتم الاستماع مباشرةً إلى أيّ أغنية أو\n          ألبوم، عربي أو عالمي، سواء كنتم في سيّارتكم، في النادي الرياضي أو على\n          شاطئ البحر. يمكنكم أيضًا إكتشاف الإصدارات الحديثة لفنّانيكم المفضّلين\n          ومشاركة أغنياتكم المفضّلة مع أصدقائكم عبر وسائل التواصل الإجتماعي. هذا\n          ليس كلّ شيء، فباستطاعتكم كذلك تحميل قدر ما تشاؤون من أغنيات والاستماع\n          إليها لاحقًا حتّى لو كنتم غير متّصلين بالإنترنت. وهكذا لن تشعروا\n          بالملل بعد الآن خلال رحلاتكم الطويلة!\n        </p>\n        <p class=\"text-justify\">\n          تتميّز “ أنغامي ” بمكتبتها الموسيقيّة المرخّصة والمستمدّة من كبرى\n          شركات الإنتاج العربيّة ك Platinum Records وMazzika وMelody وغيرها،\n          إضافةً إلى شركات الإنتاج العالميّة الرائدة مثل Universal وSony وEMI\n          وWarner. مع العلم بأنّ عمليّة الترخيص متواصلة لإدخال مزيدٍ من الأعمال\n          الموسيقيّة وإتاحة الفرصة أمام المستخدمين للاستمتاع بتجربة موسيقيّة\n          متكاملة، وذلك من خلال منصّات مثل Believe وArpuPlus وMT2 وInfo2Cell.\n          باختصار، فإنّ الموسيقى المجّانيّة اللامحدودة صارت رفيقتكم الدائمة\n          أينما كنتم. هذا هو مستقبل الموسيقى!\n        </p>\n        <p class=\"text-justify\">\n          في عام 2012 أسّس إدي مارون وإيلي حبيب إلى جانب مجموعة من عشّاق\n          الموسيقى والتكنولوجيا، شركة “ أنغامي ” وهي شركة ذات مسؤوليّة محدودة\n          مسجّلة في جزر الكايمان ولها مكاتب في بيروت ودبي. تغطّي “ أنغامي ”\n          منطقة الشرق الأوسط وشمال أفريقيا، كما أنّها متوفّرة حول العالم لتقديم\n          الموسيقى غير المحدودة للجاليات العربيّة.\n        </p>\n        <p class=\"text-justify\">\n          عمل إدي مارون لأكثر من عشر سنوات في مجال الترفيه والموسيقى وقطاع\n          الاتّصالات. خلال مسيرته المهنيّة، وطّد إدي علاقته بشركات الإنتاج\n          الموسيقي وشركات تشغيل الهواتف الخلويّة. كما أنّه أبدع في العزف على آلة\n          الkeyboard\n        </p>\n        <p class=\"text-justify\">\n          أسّس إيلي حبيب، وهو عاشقٌ للتكنولوجيا، عددًا من الشركات الناشئة في\n          مجال الهاتف المحمول. إكتسب بذلك خبرة كبيرة في إنشاء وريادة المنصّات\n          الواسعة وشركات الاتّصال، إلى جانب بناء علاقات استراتيجيّة مع مشغّلي\n          قطاع الاتّصالات.\n        </p>\n        <p class=\"text-justify\">\n          في شهر تشرين الأوّل من عام 2012، أطلقت “ أنغامي ” تعاونًا استراتيجيًا\n          إستثنائيًا مع مجموعة MBC الرائدة ( www.mbc.net )، وهي المجموعة\n          الإعلاميّة الأولى التي تعرض عددًا من إنتاجاتها عبر خدمة موسيقيّة ك“\n          أنغامي ”. الجهود المشتركة بين MBC و“ أنغامي ” تهدف إلى رفع القيمة\n          المعنويّة والمداخيل المادّيّة للصناعة الموسيقيّة، وبالتالي إلى\n          الانتصار على القرصنة.\n        </p>\n        <p class=\"text-justify\">\n          تموّل “ أنغامي ” وتدعمها شركة VC الإقليميّة Middle East Venture\n          Partners ( www.mevp.com ) وهي بذلك تقود أوسع استثمار في مجال الموسيقى\n          الرقميّة في منطقة الشرق الأوسط.\n        </p>\n        <p class=\"text-justify\">\n          تُعتبر “ أنغامي ” اليوم المنصّة الموسيقيّة الأولى في منطقة الشرق\n          الأوسط وشمال أفريقيا، مع مكتبتها الموسيقيّة الضخمة الّتي تحوي أكثر من\n          30 مليون أغنية متوفّرة لأكثر من 70 مليون مستخدِمًا.\n        </p>\n      </div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-lg-12\">\n        <p class=\"text-justify\">\n          لمعرفة المزيد حول كيفية الشراكة معنا:\n          <a class=\"link\" href=\"mailto:partner@anghami.com\"\n            >partner@anghami.com</a\n          >\n        </p>\n        <p class=\"text-justify\">\n          لمعرفة المزيد حول كيفية الإعلان معنا:\n          <a class=\"link\" href=\"mailto:advertise@anghami.com\"\n            >advertise@anghami.com</a\n          >\n        </p>\n      </div>\n    </div>\n  </div>\n</section>"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: -webkit-gradient(linear, left top, right top, from(#e03f8d), color-stop(#a22ccf), to(#2fa0df));\n  background: linear-gradient(to right, #e03f8d, #a22ccf, #2fa0df);\n  height: 30em;\n  background-size: cover !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    height: auto;\n    min-height: 15em;\n  }\n}\n:host .header.pringles {\n  background-size: cover !important;\n  background-position: center !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header.extra .title {\n  width: 60%;\n  margin: auto;\n}\n:host .header .logo {\n  max-width: 5em;\n  display: block;\n  margin: 1em auto;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n  }\n}\n:host .header .subtitle {\n  font-size: 1.2rem;\n  margin: auto;\n  font-weight: 200;\n  text-align: center;\n  padding-top: 0.5em;\n}\n@media (max-width: 768px) {\n  :host .header .subtitle {\n    width: 85%;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.ts ***!
  \************************************************************************/
/*! exports provided: InnerHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderComponent", function() { return InnerHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/mobile-detection.service */ "./src/app/core/services/mobile-detection.service.ts");



let InnerHeaderComponent = class InnerHeaderComponent {
    constructor(_mobileDetection, locale) {
        this._mobileDetection = _mobileDetection;
        this.locale = locale;
        this.locale =
            this.locale && this.locale !== null
                ? this.locale.indexOf('en') > -1
                    ? 'en'
                    : this.locale
                : 'en';
    }
    ngOnInit() {
        this._mobileDetection.verticalScreen.subscribe(isVertical => {
            if (this.backgroundHeader.mainimagemobile) {
                const image = isVertical
                    ? this.backgroundHeader.mainimagemobile
                    : this.backgroundHeader.mainimage;
                this.setBackgroundImage(image, this.backgroundHeader.backgroundcolor);
            }
        });
    }
    setBackgroundImage(img, color) {
        const backgroundcolor = color && color !== null && color !== ''
            ? color
            : 'linear-gradient(to right, #E03F8D, #A22CCF, #2FA0DF)';
        this.backgroundimage = Object.assign({}, this.backgroundimage, { background: 'url(' +
                img +
                ') 0% 0%,' + backgroundcolor });
    }
    ngOnChanges() {
        if (this.backgroundHeader && this.backgroundHeader !== null) {
            if (this.backgroundHeader.mainimage) {
                this.backgroundimage = {
                    'background-size': 'cover',
                };
                this.setBackgroundImage(this.backgroundHeader.mainimage);
            }
            if (this.backgroundHeader.type) {
                const headerElt = document.getElementById('headerid');
                if (headerElt && headerElt !== null) {
                    headerElt.classList.add(this.backgroundHeader.type);
                }
            }
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('backgroundHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "backgroundHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('smallerHeader'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "smallerHeader", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], InnerHeaderComponent.prototype, "isWave", void 0);
InnerHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-inner-header',
        template: __webpack_require__(/*! raw-loader!./inner-header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html"),
        styles: [__webpack_require__(/*! ./inner-header.component.scss */ "./src/app/core/components/inner-header/inner-header.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__["MobileDetectionService"], String])
], InnerHeaderComponent);



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.module.ts ***!
  \*********************************************************************/
/*! exports provided: InnerHeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderModule", function() { return InnerHeaderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.component */ "./src/app/core/components/inner-header/inner-header.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");





let InnerHeaderModule = class InnerHeaderModule {
};
InnerHeaderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__["PipesModule"]],
        declarations: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        exports: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], InnerHeaderModule);



/***/ }),

/***/ "./src/app/core/services/mobile-detection.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/services/mobile-detection.service.ts ***!
  \***********************************************************/
/*! exports provided: MobileDetectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileDetectionService", function() { return MobileDetectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");





let MobileDetectionService = class MobileDetectionService {
    constructor(_cookie, utils) {
        this._cookie = _cookie;
        this.utils = utils;
        this.verticalScreen = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"]();
        if (this.utils.isBrowser()) {
            this.detectVerticalScreen();
            window.addEventListener('resize', () => {
                this.resizeThrottler();
            }, false);
        }
    }
    resizeThrottler() {
        if (this.utils.isBrowser()) {
            if (!this.resizeTimeout) {
                this.resizeTimeout = setTimeout(() => {
                    this.resizeTimeout = null;
                    this.detectVerticalScreen();
                }, 200);
            }
        }
    }
    detectVerticalScreen() {
        this.device = this._cookie.get('device');
        const width = window.innerWidth < 768 ? true : false;
        const ismobile = this.device && (this.device === 'android' || this.device === 'ios')
            ? true
            : false;
        this.verticalScreen.next(width || ismobile ? true : false);
    }
    getVerticalScreen() {
        return this.verticalScreen.asObservable();
    }
};
MobileDetectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_cookie__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
], MobileDetectionService);



/***/ }),

/***/ "./src/app/modules/landing/about/about.component.scss":
/*!************************************************************!*\
  !*** ./src/app/modules/landing/about/about.component.scss ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/modules/landing/about/about.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/landing/about/about.component.ts ***!
  \**********************************************************/
/*! exports provided: AboutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutComponent", function() { return AboutComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AboutComponent = class AboutComponent {
    constructor(locale) {
        this.locale = locale;
        this.innerHeader = {};
        this.innerHeader.mainimage =
            'https://anghamiwebcdn.akamaized.net/46416840_512744722560620_624021429137965056_o.jpg';
    }
};
AboutComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-landing-home',
        template: __webpack_require__(/*! raw-loader!./about.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/about/about.component.html"),
        styles: [__webpack_require__(/*! ./about.component.scss */ "./src/app/modules/landing/about/about.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
], AboutComponent);



/***/ }),

/***/ "./src/app/modules/landing/about/about.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/modules/landing/about/about.module.ts ***!
  \*******************************************************/
/*! exports provided: AboutModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutModule", function() { return AboutModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _about_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./about.component */ "./src/app/modules/landing/about/about.component.ts");
/* harmony import */ var _about_route__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./about.route */ "./src/app/modules/landing/about/about.route.ts");
/* harmony import */ var _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.module */ "./src/app/core/components/inner-header/inner-header.module.ts");








let AboutModule = class AboutModule {
};
AboutModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
            _about_route__WEBPACK_IMPORTED_MODULE_6__["AboutRoutingModule"],
            _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_7__["InnerHeaderModule"],
        ],
        declarations: [_about_component__WEBPACK_IMPORTED_MODULE_5__["AboutComponent"]],
        exports: [_about_component__WEBPACK_IMPORTED_MODULE_5__["AboutComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], AboutModule);



/***/ }),

/***/ "./src/app/modules/landing/about/about.route.ts":
/*!******************************************************!*\
  !*** ./src/app/modules/landing/about/about.route.ts ***!
  \******************************************************/
/*! exports provided: routes, AboutRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutRoutingModule", function() { return AboutRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _about_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./about.component */ "./src/app/modules/landing/about/about.component.ts");




const routes = [
    {
        path: '',
        component: _about_component__WEBPACK_IMPORTED_MODULE_3__["AboutComponent"]
    }
];
let AboutRoutingModule = class AboutRoutingModule {
};
AboutRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        providers: []
    })
], AboutRoutingModule);



/***/ })

}]);