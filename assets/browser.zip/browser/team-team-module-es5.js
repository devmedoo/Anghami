(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["team-team-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/button/button.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "  <a \n  class=\"anghami_btn {{layout}} {{size}}\"\n  (click)=\"clickHandler($event)\"\n  [href]=\"link\"\n  [attr.target]=\"target\"\n  [class.loading]=\"loading\">\n  <span *ngIf=\"!loading\">\n    {{label_locale}}\n  </span>\n    \n    <div class=\"spinner-border text-light\" role=\"status\" *ngIf=\"loading\">\n      <span class=\"sr-only\">Loading...</span>\n    </div>\n  </a>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/inner-header/inner-header.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  id=\"headerid\"\n  class=\"header\"\n  [ngStyle]=\"backgroundimage\"\n  [ngClass]=\"{ extra: backgroundHeader.extra, smallerHeader: smallerHeader }\"\n>\n  <img\n    class=\"logo\"\n    *ngIf=\"backgroundHeader.innerLogo\"\n    [src]=\"backgroundHeader.innerLogo\"\n  />\n  <div>\n    <ng-container *ngIf=\"!isapi\">\n      <h1 class=\"title\">{{ backgroundHeader?.title | translateInstant }}</h1>\n      <h5 class=\"subtitle \">\n        {{ backgroundHeader?.subtitle | translateInstant }}\n      </h5>\n    </ng-container>\n    <ng-container *ngIf=\"isapi\">\n      <div class=\"title\">{{ backgroundHeader?.title }}</div>\n      <h5 class=\"subtitle \">{{ backgroundHeader?.subtitle }}</h5>\n    </ng-container>\n  </div>\n  <img\n    *ngIf=\"isWave\"\n    class=\"wave\"\n    src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\"\n  />\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/team/team.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/team/team.component.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<anghami-inner-header [backgroundHeader]=\"innerHeader\"></anghami-inner-header>\n<section class=\"full-row-layout\">\n  <div class=\"container\">\n    <div class=\"row\">\n      <div class=\"col-lg-12\">\n        <h1 class=\"landing-page-title\">\n          <ng-container i18n=\"@@Team\">Team</ng-container>\n          <span> - </span>\n          <span i18n=\"@@team_title\"\n            >We are a growing startup headquartered in Beirut Lebanon with offices in Dubai, Cairo, Riyadh</span\n          >\n        </h1>\n      </div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-lg-12 text-center\">\n        <div class=\"embed-responsive embed-responsive-16by9\">\n          <iframe\n            class=\"embed-responsive-item\"\n            width=\"560\"\n            height=\"315\"\n            src=\"https://www.youtube.com/embed/euXa9wJ1T70?rel=0\"\n            frameborder=\"0\"\n            allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\"\n            allowfullscreen\n          ></iframe>\n        </div>\n            <anghami-button class=\"mt-5\" label=\"weAreHiring\" link=\"https://www.anghami.com/careers\" layout=\"purple_gradient\"\n              target=\"_self\">\n            </anghami-button>\n      </div>\n\n      \n\n\n    </div>\n    <div class=\"row\">\n      <div class=\"col-lg-12 text-center\">\n        <ng-container *ngIf=\"(team$ | async) as team\">\n          <div\n            class=\"member\"\n            *ngFor=\"let member of team['sections'][0]['data']\"\n          >\n            <div class=\"img-container\">\n              <img [lazyLoad]=\"member.image\" [attr.alt]=\"member.name\" />\n            </div>\n            <h5>{{ member.name }}</h5>\n            <p>{{ member.role }}</p>\n          </div>\n        </ng-container>\n      </div>\n    </div>\n  </div>\n</section>\n"

/***/ }),

/***/ "./src/app/core/components/button/button-labels.enum.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button-labels.enum.ts ***!
  \**************************************************************/
/*! exports provided: ButtonLabelsEN, ButtonLabelsFR, ButtonLabelsAR */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsEN", function() { return ButtonLabelsEN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsFR", function() { return ButtonLabelsFR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsAR", function() { return ButtonLabelsAR; });
var ButtonLabelsEN;
(function (ButtonLabelsEN) {
    ButtonLabelsEN["learnMore"] = "Learn more";
    ButtonLabelsEN["sendGift"] = "Send gift";
    ButtonLabelsEN["goToHelpCenter"] = "Go to help center";
    ButtonLabelsEN["getAnghamiPlus"] = "Get Anghami Plus";
    ButtonLabelsEN["giftAnghamiPlus"] = "Gift Anghami Plus";
    ButtonLabelsEN["login"] = "Login";
    ButtonLabelsEN["manageAccount"] = "Manage Account";
    ButtonLabelsEN["subscribe"] = "Subscribe";
    ButtonLabelsEN["weAreHiring"] = "We're hiring";
    ButtonLabelsEN["haveApp"] = "Continue in app";
})(ButtonLabelsEN || (ButtonLabelsEN = {}));
var ButtonLabelsFR;
(function (ButtonLabelsFR) {
    ButtonLabelsFR["learnMore"] = "Renseignez - vous";
    ButtonLabelsFR["sendGift"] = "Envoyer un cadeau";
    ButtonLabelsFR["goToHelpCenter"] = "Aller au centre d'aide";
    ButtonLabelsFR["getAnghamiPlus"] = "Obtiens Anghami Plus";
    ButtonLabelsFR["giftAnghamiPlus"] = "Offrez Anghami Plus";
    ButtonLabelsFR["subscribe"] = "S'abonner";
    ButtonLabelsFR["login"] = "Connexion";
    ButtonLabelsFR["manageAccount"] = "Gestion du compte";
    ButtonLabelsFR["weAreHiring"] = "Nous recrutons";
    ButtonLabelsFR["haveApp"] = "Continuer depuis l'appli";
})(ButtonLabelsFR || (ButtonLabelsFR = {}));
var ButtonLabelsAR;
(function (ButtonLabelsAR) {
    ButtonLabelsAR["learnMore"] = "\u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0645\u0632\u064A\u062F";
    ButtonLabelsAR["sendGift"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u062A\u0643";
    ButtonLabelsAR["goToHelpCenter"] = "\u0627\u0630\u0647\u0628 \u0627\u0644\u0649 \u0642\u0633\u0645 \u0627\u0644\u0645\u0633\u0627\u0639\u062F\u0629";
    ButtonLabelsAR["getAnghamiPlus"] = "\u0625\u062D\u0635\u0644 \u0639\u0644\u0649 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u0633";
    ButtonLabelsAR["giftAnghamiPlus"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u0629 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u064E\u0633";
    ButtonLabelsAR["subscribe"] = "\u0627\u0634\u062A\u0631\u0643";
    ButtonLabelsAR["login"] = "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644";
    ButtonLabelsAR["manageAccount"] = "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u062D\u0633\u0627\u0628";
    ButtonLabelsAR["weAreHiring"] = "\u0646\u0648\u0638\u0651\u0641 \u0627\u0644\u0622\u0646!";
    ButtonLabelsAR["haveApp"] = "\u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0645\u0646 \u0627\u0644\u062A\u0637\u0628\u064A\u0642";
})(ButtonLabelsAR || (ButtonLabelsAR = {}));


/***/ }),

/***/ "./src/app/core/components/button/button.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: inline-block;\n}\n:host a {\n  text-decoration: none;\n  cursor: pointer;\n  color: #FFF;\n  padding: 1.2em 2.5em;\n  border-radius: 3em;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n  display: inline-block;\n}\n:host a.narrow {\n  padding: 0.8em 2.5em;\n}\n:host a .spinner-border {\n  width: 1.5rem;\n  height: 1.5rem;\n  vertical-align: middle;\n  margin-top: -0.1em;\n}\n:host a.loading {\n  padding: 1.2em 4em;\n}\n:host a.purple_gradient {\n  background-image: -webkit-gradient(linear, left top, right top, from(#e1418c), color-stop(#d6379b), color-stop(#c732ab), color-stop(#b035bc), to(#913ccd));\n  background-image: linear-gradient(to right, #e1418c, #d6379b, #c732ab, #b035bc, #913ccd);\n}\n:host a.white {\n  background: #FFF;\n  color: #000;\n}\n:host a.blue_gradient {\n  background: -webkit-gradient(linear, left top, right top, from(#0093fe), to(#5fd2cb));\n  background: linear-gradient(90deg, #0093fe 0%, #5fd2cb 100%);\n}\n:host a.purple {\n  background: #8d00f2;\n}\n:host a.blue {\n  background: #007ffe;\n  background: -webkit-gradient(linear, left top, right top, from(#007ffe), to(#01b5ff));\n  background: linear-gradient(90deg, #007ffe 0%, #01b5ff 100%);\n}\n:host:hover a:not(.loading) {\n  -webkit-transform: translateY(-2px);\n      -ms-transform: translateY(-2px);\n          transform: translateY(-2px);\n  opacity: 0.9;\n  box-shadow: 0px 3px 5px 0px rgba(0, 0, 0, 0.24);\n}"

/***/ }),

/***/ "./src/app/core/components/button/button.component.ts":
/*!************************************************************!*\
  !*** ./src/app/core/components/button/button.component.ts ***!
  \************************************************************/
/*! exports provided: ButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonComponent", function() { return ButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button-labels.enum */ "./src/app/core/components/button/button-labels.enum.ts");




var ButtonComponent = /** @class */ (function () {
    function ButtonComponent(router, locale) {
        this.router = router;
        this.locale = locale;
        this.label = '';
        this.layout = '';
        this.loading = false;
        this.link = '';
        this.target = '';
        this.size = '';
        this.hidden = false;
    }
    ButtonComponent.prototype.ngOnInit = function () {
        if (!this.label.length) {
            this.hidden = true;
        }
        var pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsEN"];
        if (this.locale === "ar") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsAR"];
        }
        else if (this.locale === "fr") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsFR"];
        }
        this.label_locale = pack[this.label] || this.label;
    };
    ButtonComponent.prototype.clickHandler = function (e) {
        if (this.target === "router") {
            e.preventDefault();
            this.router.navigateByUrl(this.link);
        }
        if (this.target === "none") {
            e.preventDefault();
            return;
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "label", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "layout", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], ButtonComponent.prototype, "loading", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "link", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "target", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ButtonComponent.prototype, "size", void 0);
    ButtonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-button',
            template: __webpack_require__(/*! raw-loader!./button.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html"),
            styles: [__webpack_require__(/*! ./button.component.scss */ "./src/app/core/components/button/button.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], String])
    ], ButtonComponent);
    return ButtonComponent;
}());



/***/ }),

/***/ "./src/app/core/components/button/button.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/components/button/button.module.ts ***!
  \*********************************************************/
/*! exports provided: ButtonModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonModule", function() { return ButtonModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button.component */ "./src/app/core/components/button/button.component.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");





var ButtonModule = /** @class */ (function () {
    function ButtonModule() {
    }
    ButtonModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateModule"]],
            declarations: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
            exports: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]],
        })
    ], ButtonModule);
    return ButtonModule;
}());



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: -webkit-gradient(linear, left top, right top, from(#e03f8d), color-stop(#a22ccf), to(#2fa0df));\n  background: linear-gradient(to right, #e03f8d, #a22ccf, #2fa0df);\n  height: 30em;\n  background-size: cover !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    height: auto;\n    min-height: 15em;\n  }\n}\n:host .header.pringles {\n  background-size: cover !important;\n  background-position: center !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header.extra .title {\n  width: 60%;\n  margin: auto;\n}\n:host .header .logo {\n  max-width: 5em;\n  display: block;\n  margin: 1em auto;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n  }\n}\n:host .header .subtitle {\n  font-size: 1.2rem;\n  margin: auto;\n  font-weight: 200;\n  text-align: center;\n  padding-top: 0.5em;\n}\n@media (max-width: 768px) {\n  :host .header .subtitle {\n    width: 85%;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.ts ***!
  \************************************************************************/
/*! exports provided: InnerHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderComponent", function() { return InnerHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/mobile-detection.service */ "./src/app/core/services/mobile-detection.service.ts");



var InnerHeaderComponent = /** @class */ (function () {
    function InnerHeaderComponent(_mobileDetection, locale) {
        this._mobileDetection = _mobileDetection;
        this.locale = locale;
        this.locale =
            this.locale && this.locale !== null
                ? this.locale.indexOf('en') > -1
                    ? 'en'
                    : this.locale
                : 'en';
    }
    InnerHeaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._mobileDetection.verticalScreen.subscribe(function (isVertical) {
            if (_this.backgroundHeader.mainimagemobile) {
                var image = isVertical
                    ? _this.backgroundHeader.mainimagemobile
                    : _this.backgroundHeader.mainimage;
                _this.setBackgroundImage(image, _this.backgroundHeader.backgroundcolor);
            }
        });
    };
    InnerHeaderComponent.prototype.setBackgroundImage = function (img, color) {
        var backgroundcolor = color && color !== null && color !== ''
            ? color
            : 'linear-gradient(to right, #E03F8D, #A22CCF, #2FA0DF)';
        this.backgroundimage = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.backgroundimage, { background: 'url(' +
                img +
                ') 0% 0%,' + backgroundcolor });
    };
    InnerHeaderComponent.prototype.ngOnChanges = function () {
        if (this.backgroundHeader && this.backgroundHeader !== null) {
            if (this.backgroundHeader.mainimage) {
                this.backgroundimage = {
                    'background-size': 'cover',
                };
                this.setBackgroundImage(this.backgroundHeader.mainimage);
            }
            if (this.backgroundHeader.type) {
                var headerElt = document.getElementById('headerid');
                if (headerElt && headerElt !== null) {
                    headerElt.classList.add(this.backgroundHeader.type);
                }
            }
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('backgroundHeader'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InnerHeaderComponent.prototype, "backgroundHeader", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('smallerHeader'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InnerHeaderComponent.prototype, "smallerHeader", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InnerHeaderComponent.prototype, "isWave", void 0);
    InnerHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-inner-header',
            template: __webpack_require__(/*! raw-loader!./inner-header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html"),
            styles: [__webpack_require__(/*! ./inner-header.component.scss */ "./src/app/core/components/inner-header/inner-header.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__["MobileDetectionService"], String])
    ], InnerHeaderComponent);
    return InnerHeaderComponent;
}());



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.module.ts ***!
  \*********************************************************************/
/*! exports provided: InnerHeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderModule", function() { return InnerHeaderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.component */ "./src/app/core/components/inner-header/inner-header.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");





var InnerHeaderModule = /** @class */ (function () {
    function InnerHeaderModule() {
    }
    InnerHeaderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__["PipesModule"]],
            declarations: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
            exports: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], InnerHeaderModule);
    return InnerHeaderModule;
}());



/***/ }),

/***/ "./src/app/core/services/landing.service.ts":
/*!**************************************************!*\
  !*** ./src/app/core/services/landing.service.ts ***!
  \**************************************************/
/*! exports provided: LandingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingService", function() { return LandingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../core/enums/enums */ "./src/app/core/enums/enums.ts");









var LandingService = /** @class */ (function () {
    function LandingService(http, store, locale) {
        this.http = http;
        this.store = store;
        this.locale = locale;
    }
    LandingService.prototype.getLandingPage = function () {
        var date = new Date().getTime();
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('timestamp', date.toString())
            .set('type', 'GETLandingpagev2');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["timeout"])(3000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    };
    LandingService.prototype.getTeamMembers = function () {
        var date = new Date().getTime();
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETTeam');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    };
    LandingService.prototype.getPress = function () {
        var date = new Date().getTime();
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETPress');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                var newdata = data.sections[0].data.map(function (item) {
                    return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, item, { excerpt: item.excerpt.substring(0, 150) + '...' });
                });
                data.sections[0].data = newdata;
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    };
    LandingService.prototype.getSesssionsInfo = function () {
        var date = new Date().getTime();
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETongroundeventinfo')
            .set('event_name', 'anghamisessions');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
        }));
    };
    LandingService.prototype.SubmitSessionInfo = function (info) {
        var date = new Date().getTime();
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'POSTongroundeventattender.view');
        for (var key in info) {
            if (info.hasOwnProperty(key)) {
                body = body.set(key, info[key]);
            }
        }
        return this.http.get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        });
    };
    LandingService.prototype.getWebPurchaseOptions = function (params) {
        var date = new Date().getTime();
        var appSidFromUrl = this.getQueryFromUrl('appsid') || this.getQueryFromUrl('sid');
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETwebpurchaseoptions')
            .set('studentsoffer', '1');
        if (appSidFromUrl) {
            body = body.set("sid", appSidFromUrl);
        }
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err);
        }));
    };
    LandingService.prototype.getQueryFromUrl = function (variable) {
        var query = window.location.search.substring(1);
        var vars = query.split('&');
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split('=');
            if (decodeURIComponent(pair[0]) == variable) {
                return decodeURIComponent(pair[1]);
            }
        }
        return null;
    };
    LandingService.prototype.postStudentsOfferProfileUpdates = function (params) {
        var _this = this;
        var date = new Date().getTime();
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        var successevent;
        var failevent;
        var appSidFromUrl = this.getQueryFromUrl('appsid') || this.getQueryFromUrl('sid');
        if (appSidFromUrl) {
            body = body.set('sid', appSidFromUrl);
        }
        if (params.email) {
            body = body.set('type', 'POSTaddemail').set('email', params.email);
            successevent = _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].studentOfferEmailSuccess;
            failevent = _core_enums_enums__WEBPACK_IMPORTED_MODULE_8__["AmplitudeEvents"].studentOfferEmailFail;
        }
        else if (params.birthdate) {
            successevent = 'studentOfferEmailSuccess';
            failevent = 'studentOfferEmailFail';
            body = body
                .set('type', 'UPDATEprofile')
                .set('birthdate', params.birthdate);
        }
        else if (params.card_number && params.cardholder_name) {
            successevent = 'studentOfferISICSuccess';
            failevent = 'studentOfferISICFail';
            body = body
                .set('type', 'POSTisicmembership')
                .set('card_number', params.card_number)
                .set('cardholder_name', params.cardholder_name);
        }
        else {
            return;
        }
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                _this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: failevent,
                    props: {
                        details: data
                    }
                }));
            }
            else {
                _this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                    name: successevent,
                    props: {
                        details: data
                    }
                }));
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) {
            _this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_6__["LogAmplitudeEvent"]({
                name: failevent,
                props: {
                    details: err
                }
            }));
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err);
        }));
    };
    LandingService.prototype.validateEmailToken = function (params) {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        if (params && params !== null) {
            body = body.set('type', 'POSTvalidatemailtoken');
            for (var _i = 0, _a = Object.keys(params); _i < _a.length; _i++) {
                var key = _a[_i];
                body = body.set(key, params[key]);
            }
        }
        return this.http.post("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    LandingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"], String])
    ], LandingService);
    return LandingService;
}());



/***/ }),

/***/ "./src/app/core/services/mobile-detection.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/services/mobile-detection.service.ts ***!
  \***********************************************************/
/*! exports provided: MobileDetectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileDetectionService", function() { return MobileDetectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm5/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");





var MobileDetectionService = /** @class */ (function () {
    function MobileDetectionService(_cookie, utils) {
        var _this = this;
        this._cookie = _cookie;
        this.utils = utils;
        this.verticalScreen = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"]();
        if (this.utils.isBrowser()) {
            this.detectVerticalScreen();
            window.addEventListener('resize', function () {
                _this.resizeThrottler();
            }, false);
        }
    }
    MobileDetectionService.prototype.resizeThrottler = function () {
        var _this = this;
        if (this.utils.isBrowser()) {
            if (!this.resizeTimeout) {
                this.resizeTimeout = setTimeout(function () {
                    _this.resizeTimeout = null;
                    _this.detectVerticalScreen();
                }, 200);
            }
        }
    };
    MobileDetectionService.prototype.detectVerticalScreen = function () {
        this.device = this._cookie.get('device');
        var width = window.innerWidth < 768 ? true : false;
        var ismobile = this.device && (this.device === 'android' || this.device === 'ios')
            ? true
            : false;
        this.verticalScreen.next(width || ismobile ? true : false);
    };
    MobileDetectionService.prototype.getVerticalScreen = function () {
        return this.verticalScreen.asObservable();
    };
    MobileDetectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_cookie__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
    ], MobileDetectionService);
    return MobileDetectionService;
}());



/***/ }),

/***/ "./src/app/modules/landing/team/team.component.ts":
/*!********************************************************!*\
  !*** ./src/app/modules/landing/team/team.component.ts ***!
  \********************************************************/
/*! exports provided: TeamComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamComponent", function() { return TeamComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _core_services_landing_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/services/landing.service */ "./src/app/core/services/landing.service.ts");




var TeamComponent = /** @class */ (function () {
    function TeamComponent(locale, store, landingservice) {
        this.locale = locale;
        this.store = store;
        this.landingservice = landingservice;
        this.innerHeader = [];
        this.innerHeader.mainimage =
            'https://anghamiwebcdn.akamaized.net/46416840_512744722560620_624021429137965056_o.jpg';
    }
    TeamComponent.prototype.ngOnInit = function () {
        this.team$ = this.landingservice.getTeamMembers();
    };
    TeamComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-landing-home',
            template: __webpack_require__(/*! raw-loader!./team.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/team/team.component.html"),
            styles: ["\n      .btn {\n        margin: 2em auto;\n      }\n      .btn a {\n        display: block;\n        padding: 0.7em 3em;\n        color: #fff;\n        text-decoration: none;\n      }\n      .member {\n        display: inline-block;\n        vertical-align: top;\n        width: 12em;\n        margin: 0.5em;\n        text-align: center;\n      }\n      .member .img-container {\n        width: 12em;\n        height: 12em;\n        background: #eee;\n        border-radius: 50%;\n      }\n      .member img {\n        opacity: 0;\n        transition: opacity 200ms ease;\n        transition-delay: 300ms;\n        display: block;\n        width: 12em;\n        height: 12em;\n        border-radius: 50%;\n      }\n      .member img.ng-lazyloaded {\n        opacity: 1;\n      }\n      .member h5 {\n        margin-top: 1em;\n      }\n    "]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String, _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _core_services_landing_service__WEBPACK_IMPORTED_MODULE_3__["LandingService"]])
    ], TeamComponent);
    return TeamComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/team/team.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/modules/landing/team/team.module.ts ***!
  \*****************************************************/
/*! exports provided: TeamModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamModule", function() { return TeamModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _team_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./team.component */ "./src/app/modules/landing/team/team.component.ts");
/* harmony import */ var _team_route__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./team.route */ "./src/app/modules/landing/team/team.route.ts");
/* harmony import */ var _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.module */ "./src/app/core/components/inner-header/inner-header.module.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/components/button/button.module */ "./src/app/core/components/button/button.module.ts");










var TeamModule = /** @class */ (function () {
    function TeamModule() {
    }
    TeamModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
                _team_route__WEBPACK_IMPORTED_MODULE_6__["TeamRoutingModule"],
                _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_7__["InnerHeaderModule"],
                ng_lazyload_image__WEBPACK_IMPORTED_MODULE_8__["LazyLoadImageModule"],
                _core_components_button_button_module__WEBPACK_IMPORTED_MODULE_9__["ButtonModule"]
            ],
            declarations: [_team_component__WEBPACK_IMPORTED_MODULE_5__["TeamComponent"]],
            exports: [_team_component__WEBPACK_IMPORTED_MODULE_5__["TeamComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], TeamModule);
    return TeamModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/team/team.route.ts":
/*!****************************************************!*\
  !*** ./src/app/modules/landing/team/team.route.ts ***!
  \****************************************************/
/*! exports provided: routes, TeamRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamRoutingModule", function() { return TeamRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _team_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./team.component */ "./src/app/modules/landing/team/team.component.ts");




var routes = [
    {
        path: '',
        component: _team_component__WEBPACK_IMPORTED_MODULE_3__["TeamComponent"]
    }
];
var TeamRoutingModule = /** @class */ (function () {
    function TeamRoutingModule() {
    }
    TeamRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
            providers: []
        })
    ], TeamRoutingModule);
    return TeamRoutingModule;
}());



/***/ })

}]);