(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~explore-explore-module~pdj-pdj-module~view-view-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/music-language-selector/music-language-selector.component.html":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/music-language-selector/music-language-selector.component.html ***!
  \**************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"btn-group\" *ngIf=\"user.musiclanguage !== undefined\">\n  <div class=\"btn-group\" ngbDropdown role=\"group\" aria-label=\"Music Language Selector\" #musicLangTooltip=\"ngbDropdown\"\n    (openChange)=\"toggled($event)\">\n    <button class=\"btn row align-items-center flex flex-nowrap flex-row\"\n      [ngClass]=\"{ 'show-overlay': showMusicTooltip }\" ngbDropdownToggle>\n      <ng-container *ngIf=\"user.musiclanguage == 0\">\n        <span class=\"padding03\" i18n=\"@@Arabic + Intl\">Arabic + International</span>\n      </ng-container>\n      <ng-container *ngIf=\"user.musiclanguage == 1\">\n        <span class=\"padding03\" i18n=\"@@Arabic\">Arabic</span>\n      </ng-container>\n      <ng-container *ngIf=\"user.musiclanguage == 2\">\n        <span class=\"padding03\" i18n=\"@@International\">International</span>\n      </ng-container>\n      <!-- <ng-container *ngIf=\"user.musiclanguage == 3\">\n        <span class=\"padding03\" i18n=\"@@Ramadan\">Ramadan</span>\n      </ng-container> -->\n      <anghami-icon class=\"icon arrow-down\" [data]=\"'arrow-down'\"></anghami-icon>\n    </button>\n    <div class=\"dropdown-menu\" ngbDropdownMenu *ngIf=\"!showMusicTooltip\">\n      <button class=\"dropdown-item\" i18n=\"@@Arabic + Intl\" *ngIf=\"user.musiclanguage != 0 && languageSelectorOptions.indexOf(0) > -1\" (click)=\"select(0)\">\n        Arabic + International\n      </button>\n      <button class=\"dropdown-item\" i18n=\"@@Arabic\" *ngIf=\"user.musiclanguage != 1  && languageSelectorOptions.indexOf(1) > -1\" (click)=\"select(1)\">\n        Arabic\n      </button>\n      <button class=\"dropdown-item\" i18n=\"@@International\" *ngIf=\"user.musiclanguage != 2 && languageSelectorOptions.indexOf(2) > -1\" (click)=\"select(2)\">\n        International\n      </button>\n      <!-- <button\n        class=\"dropdown-item\"\n        i18n=\"@@Ramadan\"\n        *ngIf=\"user.musiclanguage != 3\"\n        (click)=\"select(3)\"\n      >\n        Ramadan\n      </button> -->\n    </div>\n    <ng-container *ngIf=\"showMusicTooltip\">\n      <div class=\"dropdown-menu music-tooltip\" ngbDropdownMenu>\n        <div class=\"tooltip-arrow bottom\"></div>\n        <div class=\"tooltip-header\" i18n=\"@@ramadan_kareem\">Ramadan Kareem</div>\n        <p>\n          {{ musicTooptipText }}\n        </p>\n      </div>\n    </ng-container>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/core/components/music-language-selector/music-language-selector.component.scss":
/*!************************************************************************************************!*\
  !*** ./src/app/core/components/music-language-selector/music-language-selector.component.scss ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .btn {\n  font-size: 1em;\n  color: var(--text-color);\n  border-radius: 3em;\n  background: var(--sidebar-background);\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n}\n:host .btn:after {\n  display: none;\n}\n:host .dropdown-menu {\n  background-color: var(--light-background);\n}\n:host .dropdown-menu .dropdown-item {\n  font-size: 0.9em;\n  padding: 0.2rem 0.8rem;\n  cursor: pointer;\n  color: var(--text-color);\n}\n:host .dropdown-menu.music-tooltip {\n  min-width: 15em;\n  padding: 0.75em;\n  top: calc(32px + 1em) !important;\n  background-color: white;\n  left: 50% !important;\n  -webkit-transform: translateX(-50%) !important;\n      -ms-transform: translateX(-50%) !important;\n          transform: translateX(-50%) !important;\n}\n:host .dropdown-menu.music-tooltip.show {\n  opacity: 1;\n}\n:host .padding03 {\n  padding: 0 0.3em;\n}\n:host .arrow-down ::ng-deep svg {\n  width: 0.8em;\n  height: 0.8em;\n}\n:host .tooltip-arrow {\n  position: absolute;\n  top: -1em;\n  right: 0;\n  left: 0;\n  margin: auto;\n  width: 0;\n  height: 0;\n  border-style: solid;\n}\n:host .tooltip-arrow.bottom {\n  border-width: 0 1em 1em 1em;\n  border-color: transparent transparent #007bff transparent;\n  border-bottom-color: white;\n}\n:host .tooltip-header {\n  font-size: 0.9em;\n  color: var(--brand-purple);\n  font-weight: 600;\n}\n:host p {\n  font-size: 0.8em;\n  padding-top: 0.5em;\n  padding-bottom: 0;\n  margin-bottom: 0;\n}\n.btn-group .show-overlay {\n  background-color: white !important;\n  box-shadow: unset !important;\n  color: black !important;\n}\nhtml[lang=ar] :host .tooltip-header, html[lang=ar] :host p {\n  text-align: right;\n}"

/***/ }),

/***/ "./src/app/core/components/music-language-selector/music-language-selector.component.ts":
/*!**********************************************************************************************!*\
  !*** ./src/app/core/components/music-language-selector/music-language-selector.component.ts ***!
  \**********************************************************************************************/
/*! exports provided: MusicLanguageSelectorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MusicLanguageSelectorComponent", function() { return MusicLanguageSelectorComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/search.actions */ "./src/app/core/redux/actions/search.actions.ts");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _anghami_redux_actions_pdj_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/pdj.actions */ "./src/app/core/redux/actions/pdj.actions.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _enums_enums__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm5/ngx-cookie.js");
/* harmony import */ var _anghami_redux_actions_explore_actions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/redux/actions/explore.actions */ "./src/app/core/redux/actions/explore.actions.ts");

















var MusicLanguageSelectorComponent = /** @class */ (function () {
    function MusicLanguageSelectorComponent(store, config, router, _utilsService, _translateSrvice, document, _cookieService, changeDetector, locale) {
        this.store = store;
        this.config = config;
        this.router = router;
        this._utilsService = _utilsService;
        this._translateSrvice = _translateSrvice;
        this.document = document;
        this._cookieService = _cookieService;
        this.changeDetector = changeDetector;
        this.locale = locale;
        this.languageSelectorOptions = [0, 1, 2];
        config.placement = 'bottom-right';
        this.show = true;
        this.user = {
            musiclanguage: this._utilsService.getCookie('musiclanguage') || 0
        };
        this.showMusicTooltip = false;
    }
    MusicLanguageSelectorComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.usersubs = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_9__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_5__["getUser"]))
            .subscribe(function (data) {
            if (data) {
                _this.user = data;
                _this.changeDetector.detectChanges();
            }
        });
        if (this.locale === 'ar') {
            this.config.placement = 'bottom-left';
        }
    };
    MusicLanguageSelectorComponent.prototype.handleMusicTooltip = function () {
        var tooltip = this._cookieService.get('hidetooltip');
        if (tooltip !== undefined && tooltip !== null) {
            this.showMusicTooltip = false;
        }
        else {
            this.showMusicTooltip = true;
            var key = this.user && this.user.musiclanguage === 3 ? 'ramadan_mode_on' : 'ramadan_mode_off';
            this.musicTooptipText = this._translateSrvice.instant(key);
            this.document.body.classList.add('overlay-class');
            this.changeDetector.detectChanges();
            this.musicLangTooltip.open();
        }
    };
    MusicLanguageSelectorComponent.prototype.toggled = function (event) {
        if (!event && this.showMusicTooltip) {
            this.showMusicTooltip = false;
            this.document.body.classList.remove('overlay-class');
            var date = new Date();
            date.setDate(new Date().getDate() + 365);
            this._cookieService.put('hidetooltip', 'true', {
                expires: date
            });
            this.changeDetector.detectChanges();
        }
    };
    MusicLanguageSelectorComponent.prototype.select = function (value) {
        this.store.dispatch(new _redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_11__["LogAmplitudeEvent"]({
            name: _enums_enums__WEBPACK_IMPORTED_MODULE_10__["AmplitudeEvents"].musicChanged,
            props: {
                lang: value
            }
        }));
        this.store.dispatch(new _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_2__["UpdateUserAuth"]({
            property: 'musiclanguage',
            value: value
        }));
        this.storeNewMusicLang(value);
        this.updateViewBasedOnRoute();
    };
    MusicLanguageSelectorComponent.prototype.storeNewMusicLang = function (value) {
        this._utilsService.setCookie('musiclanguage', value, 365);
    };
    MusicLanguageSelectorComponent.prototype.updateViewBasedOnRoute = function () {
        var url = decodeURIComponent(this.router.url);
        if (url === '/home') {
            this.store.dispatch(new _anghami_redux_actions_explore_actions__WEBPACK_IMPORTED_MODULE_16__["GetHomePageNew"]());
        }
        else if (url === '/personal-dj') {
            this.store.dispatch(new _anghami_redux_actions_pdj_actions__WEBPACK_IMPORTED_MODULE_4__["GetPDJNew"]());
        }
        else if (url.indexOf('/tag/') > -1) {
            var parts = url.split('/');
            this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__["GetCollectionDataNew"]({
                collectionType: 'tag',
                collectionId: parts[2]
            }));
        }
        else if (url.indexOf('/hashtag/') > -1) {
            var parts = url.split('/');
            this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__["GetCollectionDataNew"]({
                collectionType: 'hashtag',
                collectionId: parts[2]
            }));
        }
        this.store.dispatch(new _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_1__["LoadSearchTags"]());
    };
    MusicLanguageSelectorComponent.prototype.ngOnDestroy = function () {
        if (this.usersubs) {
            this.usersubs.unsubscribe();
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
    ], MusicLanguageSelectorComponent.prototype, "languageSelectorOptions", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"])('musicLangTooltip', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], MusicLanguageSelectorComponent.prototype, "musicLangTooltip", void 0);
    MusicLanguageSelectorComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
            selector: 'anghami-music-language-selector',
            template: __webpack_require__(/*! raw-loader!./music-language-selector.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/music-language-selector/music-language-selector.component.html"),
            providers: [_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbDropdownConfig"]],
            styles: [__webpack_require__(/*! ./music-language-selector.component.scss */ "./src/app/core/components/music-language-selector/music-language-selector.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](5, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_14__["DOCUMENT"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](8, Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_6__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_9__["Store"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbDropdownConfig"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_12__["UtilService"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__["TranslateService"], Object, ngx_cookie__WEBPACK_IMPORTED_MODULE_15__["CookieService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_6__["ChangeDetectorRef"], String])
    ], MusicLanguageSelectorComponent);
    return MusicLanguageSelectorComponent;
}());



/***/ }),

/***/ "./src/app/core/components/music-language-selector/music-language-selector.module.ts":
/*!*******************************************************************************************!*\
  !*** ./src/app/core/components/music-language-selector/music-language-selector.module.ts ***!
  \*******************************************************************************************/
/*! exports provided: MusicLanguageSelectorModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MusicLanguageSelectorModule", function() { return MusicLanguageSelectorModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _music_language_selector_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./music-language-selector.component */ "./src/app/core/components/music-language-selector/music-language-selector.component.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _icon_icon_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");






var MusicLanguageSelectorModule = /** @class */ (function () {
    function MusicLanguageSelectorModule() {
    }
    MusicLanguageSelectorModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_music_language_selector_component__WEBPACK_IMPORTED_MODULE_3__["MusicLanguageSelectorComponent"]],
            exports: [_music_language_selector_component__WEBPACK_IMPORTED_MODULE_3__["MusicLanguageSelectorComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["NgbModule"],
                _icon_icon_module__WEBPACK_IMPORTED_MODULE_5__["IconModule"]
            ]
        })
    ], MusicLanguageSelectorModule);
    return MusicLanguageSelectorModule;
}());



/***/ }),

/***/ "./src/app/core/components/placeholders/placeholders.scss":
/*!****************************************************************!*\
  !*** ./src/app/core/components/placeholders/placeholders.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".shine {\n  background: var(--placeholder-primary);\n  background-image: -webkit-gradient(linear, left top, right top, from(var(--placeholder-primary)), color-stop(20%, var(--placeholder-secondary)), color-stop(40%, var(--placeholder-primary)), to(var(--placeholder-secondary)));\n  background-image: linear-gradient(to right, var(--placeholder-primary) 0%, var(--placeholder-secondary) 20%, var(--placeholder-primary) 40%, var(--placeholder-secondary) 100%);\n  background-repeat: no-repeat;\n  background-size: 200% 200%;\n  display: inline-block;\n  position: relative;\n}\n\n.placeholder-track {\n  margin-top: 1em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n\n.placeholder-track .small {\n  margin: 0.5em;\n}\n\n.placeholder-video {\n  margin: 1em 0.5em 0 0.5em;\n  width: 18em;\n  display: inline-block;\n  vertical-align: middle;\n}\n\n.placeholder-video .box {\n  margin: 0.5em;\n  width: 18em;\n  height: 10em;\n}\n\n.placeholder-video .placeholder-line {\n  width: 100%;\n}\n\n.placeholder-video .placeholder-line.short {\n  width: 10em;\n}\n\n.placeholder-box {\n  width: 18em;\n  height: 18em;\n  border-radius: 0.8em;\n  margin-top: 0.5em;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n}\n\n.placeholder-box.small {\n  width: 4em;\n  height: 4em;\n}\n\n.placeholder-line {\n  height: 1em;\n  margin-top: 0.5em;\n  width: 25em;\n  border-radius: 0.5em;\n}\n\n.placeholder-line.short {\n  width: 18em;\n}\n\n.placeholder-title {\n  display: block !important;\n  width: 18em;\n  height: 2em;\n  border-radius: 2em;\n  margin-top: 0.5em;\n}\n\n.placeholder-title.short {\n  width: 14em;\n}\n\n@-webkit-keyframes placeholderShimmer {\n  0% {\n    background-position: -468px 0;\n  }\n  100% {\n    background-position: 468px 0;\n  }\n}"

/***/ }),

/***/ "./src/app/core/redux/actions/pdj.actions.ts":
/*!***************************************************!*\
  !*** ./src/app/core/redux/actions/pdj.actions.ts ***!
  \***************************************************/
/*! exports provided: PDJActionTypes, GetPDJNew, GetPDJSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDJActionTypes", function() { return PDJActionTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetPDJNew", function() { return GetPDJNew; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetPDJSuccess", function() { return GetPDJSuccess; });
var PDJActionTypes;
(function (PDJActionTypes) {
    PDJActionTypes["GetPDJNew"] = "[Pdj] Get PDJ New";
    PDJActionTypes["GetPDJSuccess"] = "[Pdj] Get PDJ Success";
})(PDJActionTypes || (PDJActionTypes = {}));
var GetPDJNew = /** @class */ (function () {
    function GetPDJNew(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = PDJActionTypes.GetPDJNew;
    }
    return GetPDJNew;
}());

var GetPDJSuccess = /** @class */ (function () {
    function GetPDJSuccess(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = PDJActionTypes.GetPDJSuccess;
    }
    return GetPDJSuccess;
}());



/***/ })

}]);