(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["download-queue-download-queue-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/download-queue/download-queue.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/download-queue/download-queue.component.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main\">\n  <div class=\"download-queue-actions\">\n    <div class=\"anghami-default-btn\" (click)=\"onResumeClick()\" *ngIf=\"downloadQueueState?.paused\">\n      <span i18n=\"@@resume\">Resume</span>\n    </div>\n    <div class=\"anghami-default-btn\" (click)=\"onPauseClick()\" *ngIf=\"!downloadQueueState?.paused\">\n      <span i18n=\"@@Pause\">Pause</span>\n    </div>\n    <div class=\"anghami-default-btn\" (click)=\"onCancelClick()\">\n      <span i18n=\"@@Cancel\">Cancel</span>\n    </div>\n  </div>\n  <div>\n    <anghami-new-section-builder #sectionBuilder [sections]=\"[downloadSection]\" #sectionBuilder>\n    </anghami-new-section-builder>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/modules/base/download-queue/download-queue-routing.module.ts":
/*!******************************************************************************!*\
  !*** ./src/app/modules/base/download-queue/download-queue-routing.module.ts ***!
  \******************************************************************************/
/*! exports provided: DownloadQueueRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadQueueRoutingModule", function() { return DownloadQueueRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _download_queue_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./download-queue.component */ "./src/app/modules/base/download-queue/download-queue.component.ts");




const routes = [
    {
        path: '',
        component: _download_queue_component__WEBPACK_IMPORTED_MODULE_3__["DownloadQueueComponent"]
    }
];
let DownloadQueueRoutingModule = class DownloadQueueRoutingModule {
};
DownloadQueueRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], DownloadQueueRoutingModule);



/***/ }),

/***/ "./src/app/modules/base/download-queue/download-queue.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/modules/base/download-queue/download-queue.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .ang-main {\n  margin: 1em;\n}\n:host .ang-main .download-queue-actions {\n  width: 16em;\n  margin-left: auto;\n}\n:host .ang-main .anghami-default-btn {\n  width: 7em;\n  display: inline-block;\n  margin: 0.4em;\n}"

/***/ }),

/***/ "./src/app/modules/base/download-queue/download-queue.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/modules/base/download-queue/download-queue.component.ts ***!
  \*************************************************************************/
/*! exports provided: DownloadQueueComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadQueueComponent", function() { return DownloadQueueComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/redux/selectors/desktop-client.selectors */ "./src/app/core/redux/selectors/desktop-client.selectors.ts");
/* harmony import */ var _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/desktop-download.service */ "./src/app/core/services/desktop-download.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");










let DownloadQueueComponent = class DownloadQueueComponent {
    constructor(store, desktopDownloadService, router, _actionsSubject, translationService) {
        this.store = store;
        this.desktopDownloadService = desktopDownloadService;
        this.router = router;
        this._actionsSubject = _actionsSubject;
        this.translationService = translationService;
        this.downloadSection = {
            displaytype: 'list',
            type: 'song',
            initialNumItems: 100,
            data: [],
            title: 'Downloading',
            sectionid: 1
        };
        this.downloadQueueSubscription = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_2__["getDownloadQueue"]))
            .subscribe((response) => {
            if (response.length === 0) {
                this.router.navigateByUrl('/desktop-downloads');
                return;
            }
            const newData = response.map(item => {
                return Object.assign({}, item, { isInDownloadQueue: true });
            });
            this.downloadSection = Object.assign({}, this.downloadSection, { data: newData, count: newData.length });
        });
        this.downloadQueueStateSubscription = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["select"])(_anghami_redux_selectors_desktop_client_selectors__WEBPACK_IMPORTED_MODULE_2__["downloadQueueState"]))
            .subscribe(response => {
            this.downloadQueueState = response;
        });
    }
    ngOnInit() { }
    onPauseClick() {
        this.desktopDownloadService.pauseDownloadQueue();
    }
    onResumeClick() {
        this.desktopDownloadService.resumeDownloadQueue();
    }
    onCancelClick() {
        const message = this.translationService.instant('stop_downloading_songs');
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_1__["OpenConfirmationModal"]({
            type: 'confirm',
            question: message
        }));
        this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_1__["DialogsActionTypes"].ConfirmationModalAnswer), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1))
            .subscribe(action => {
            const response = action.payload;
            if (response && response.type === 'confirm') {
                this.desktopDownloadService.clearDownloadQueue();
                this.router.navigateByUrl('/desktop-downloads');
            }
        });
    }
    ngOnDestroy() {
        if (this.downloadQueueSubscription) {
            this.downloadQueueSubscription.unsubscribe();
        }
        if (this.downloadQueueStateSubscription) {
            this.downloadQueueStateSubscription.unsubscribe();
        }
    }
    ngOnChanges(SimpleChanges) { }
};
DownloadQueueComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'anghami-download-queue',
        template: __webpack_require__(/*! raw-loader!./download-queue.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/download-queue/download-queue.component.html"),
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ChangeDetectionStrategy"].Default,
        host: { class: 'ang-view' },
        styles: [__webpack_require__(/*! ./download-queue.component.scss */ "./src/app/modules/base/download-queue/download-queue.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"],
        _anghami_services_desktop_download_service__WEBPACK_IMPORTED_MODULE_3__["DesktopDownloadService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_7__["ActionsSubject"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslateService"]])
], DownloadQueueComponent);



/***/ }),

/***/ "./src/app/modules/base/download-queue/download-queue.module.ts":
/*!**********************************************************************!*\
  !*** ./src/app/modules/base/download-queue/download-queue.module.ts ***!
  \**********************************************************************/
/*! exports provided: DownloadQueueModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadQueueModule", function() { return DownloadQueueModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _download_queue_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./download-queue.component */ "./src/app/modules/base/download-queue/download-queue.component.ts");
/* harmony import */ var _download_queue_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./download-queue-routing.module */ "./src/app/modules/base/download-queue/download-queue-routing.module.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");






let DownloadQueueModule = class DownloadQueueModule {
};
DownloadQueueModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _download_queue_routing_module__WEBPACK_IMPORTED_MODULE_4__["DownloadQueueRoutingModule"], _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_5__["NewSectionBuilderModule"]],
        declarations: [_download_queue_component__WEBPACK_IMPORTED_MODULE_3__["DownloadQueueComponent"]],
        exports: [_download_queue_component__WEBPACK_IMPORTED_MODULE_3__["DownloadQueueComponent"]]
    })
], DownloadQueueModule);



/***/ })

}]);