(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["gifts-gifts-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/button/button.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "  <a \n  class=\"anghami_btn {{layout}} {{size}}\"\n  (click)=\"clickHandler($event)\"\n  [href]=\"link\"\n  [attr.target]=\"target\"\n  [class.loading]=\"loading\">\n  <span *ngIf=\"!loading\">\n    {{label_locale}}\n  </span>\n    \n    <div class=\"spinner-border text-light\" role=\"status\" *ngIf=\"loading\">\n      <span class=\"sr-only\">Loading...</span>\n    </div>\n  </a>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/gifts/gifts.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/gifts/gifts.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<img src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/plus/left_corner.png\" class=\"left-corner\">\n<ng-container *ngIf=\"ispurchase && !isloading && !issuccess\">\n  <h1 i18n=\"@@anghami_gifts\">Anghami Gifts</h1>\n  <h2 i18n=\"@@gifts_sub1\">Share the music world with your friends. \\nOffer them unlimited downloads, offline, ad-free music and much more.</h2>\n  <ng-container *ngIf=\"cardsLst && cardsLst.length > 0\">\n    <div class=\"vertical-space sm\"></div>\n    <div class=\"cards cards-wrapper\">\n      <div class=\"flexbox colls card-list-wrap\"\n        *ngFor=\"let card of cardsLst;let i=index\">\n        <div class=\"header-title my-2\" i18n=\"@@anghami_gift_cta\" [ngClass]=\"{'invisible': i!==0}\">Choose your gift</div>\n        <div\n          [ngStyle]=\"card?.bgd\"\n          [ngClass]=\"{'faded': showCC && !card?.isSelected}\"\n          class=\"flex-card card py-3 mx-3 my-2\"\n          (click)=\"$event.stopPropagation();$event.preventDefault();onCardSelection(card, i)\">\n          <div class=\"d-flex flex-column px-4 py-2 alignItems top-details\">\n            <span class=\"title uppercase\">{{ card?.duration}}</span>\n            <span class=\"subtitle uppercase\" i18n=\"@@Anghami Plus\">ANGHAMI PLUS</span>\n          </div>\n          <div class=\"flexbox between px-4 sub-direction price-wrap\">\n            <div class=\"price\">{{ card?.currency }} {{ card?.price | number:'1.0-2' }}</div>\n          </div>\n        </div>\n        <div\n          class=\"desc-sm\"\n          [ngClass]=\"{'hidden': showCC}\"\n          i18n=\"@@gift_card_desc\">\n          This card is virtual. You will receive a link for the gift so you can send it to the recipient.\n        </div>\n        <div\n          class=\"ang-operator-btn\"\n          [ngClass]=\"{'hidden': showCC}\"\n          (click)=\"$event.stopPropagation();$event.preventDefault();onCardSelection(card, i)\"\n        ><span i18n=\"@@buy\">Buy</span> {{ card?.duration }}</div>\n      </div>\n      <div class=\"flexbox colls card-one-wrap\">\n        <div\n          [ngStyle]=\"selectedPlan?.bgd\"\n          class=\"flex-card card py-3 mx-3 my-2\">\n          <div class=\"d-flex flex-column mx-3 my-1 alignItems\">\n            <img class=\"ang-icon\" [src]=\"env + 'anghami-icon-white.png'\">\n          </div>\n          <div class=\"flexbox colls end sub-direction bottom-details mx-3\">\n            <div i18n=\"@@Anghami Plus\" class=\"uppercase font-weight-bold\">Anghami Plus</div>\n            <div class=\"uppercase\" i18n=\"@@gift_card\">Gift Card</div>\n          </div>\n        </div>\n        <div class=\"flexbox mt-4 justify-content-center\" [ngClass]=\"{'disable-cards': disableCards}\">\n          <ng-container *ngFor=\"let card of cardsLst;let i=index\">\n            <div class=\"flexbox colls px-3\">\n              <label\n                class=\"container\"\n                (click)=\"$event.stopPropagation();$event.preventDefault();onCardSelection(card, i)\">\n                <input type=\"checkbox\" [(ngModel)]=\"card.isSelected\">\n                <span class=\"checkmark\"></span>\n              </label>\n              <div class=\"text-center price-details mt-4 mb-3\">\n                <div>{{ card?.duration }}</div>\n                <div>For {{ card?.currency }} <span class=\"font-weight-bold\">{{ card?.price | number:'1.0-2' }}</span></div>\n              </div>\n            </div>\n          </ng-container>\n        </div>\n        <div\n          class=\"desc-sm\"\n          [ngClass]=\"{'hidden': (showCC && !card?.isSelected && !isMobile), 'hidden': disableCards}\"\n          i18n=\"@@gift_card_desc\">\n          This card is virtual. You will receive a link for the gift so you can send it to the recipient.\n        </div>\n        <div\n          class=\"ang-operator-btn\"\n          [ngClass]=\"{'hidden': (showCC && !card?.isSelected && !isMobile), 'hidden': disableCards}\"\n          (click)=\"$event.stopPropagation();$event.preventDefault();showCC=true;disableCards=true;\">\n          <span i18n=\"@@buy_now\">Buy Now</span>\n        </div>\n      </div>\n    </div>\n    <div *ngIf=\"errMsg === null || errMsg !== ''\" class=\"err py-2\">{{ errMsg }}</div>\n    <ng-container *ngIf=\"showCC\">\n      <div class=\"payment py-3\">\n        <anghami-payment-form\n          [selectedPlan]=\"selectedPlan\"\n          [submitText]=\"selectedPlan?.planbutton\"\n          (success)=\"successPayment($event)\"\n        ></anghami-payment-form>\n      </div>\n    </ng-container>\n    <div class=\"vertical-space md\"></div>\n    <anghami-features [features]=\"benefitsLst\" (subscribeEvent)=\"goToSubscribe()\"></anghami-features>\n  </ng-container>\n</ng-container>\n<ng-container *ngIf=\"isloading && !ispurchase && !issuccess\">\n  <h4 i18n=\"@@gifts_wrapping\">Wrapping your gift</h4>\n  <img [lazyLoad]=\"'https://anghamiwebcdn.akamaized.net/web/assets/img/gift/gift-loading.png'\" class=\"gift-img\">\n</ng-container>\n<ng-container *ngIf=\"issuccess && !ispurchase && !isloading\">\n  <h4 *ngIf=\"selectedGift\" i18n=\"@@gifts_delivered_1\">Your gift is ready.</h4>\n  <h6><span i18n=\"@@gifts_delivered_2\">Send this link now to share the music</span>\n    <br>\n\n        <span>https://anghami.com/redeem/{{selectedGift?.giftcode}}</span>\n\n    <!-- <a\n      href=\"https://anghami.com/redeem/{{selectedGift?.giftcode}}\"\n      target=\"_blank\">https://anghami.com/redeem/{{selectedGift?.giftcode}}</a> -->\n  </h6>\n  <img [lazyLoad]=\"'https://anghamiwebcdn.akamaized.net/web/assets/img/gift/gift-result.png'\" class=\"gift-img\">\n</ng-container>\n"

/***/ }),

/***/ "./src/app/core/components/button/button-labels.enum.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button-labels.enum.ts ***!
  \**************************************************************/
/*! exports provided: ButtonLabelsEN, ButtonLabelsFR, ButtonLabelsAR */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsEN", function() { return ButtonLabelsEN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsFR", function() { return ButtonLabelsFR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonLabelsAR", function() { return ButtonLabelsAR; });
var ButtonLabelsEN;
(function (ButtonLabelsEN) {
    ButtonLabelsEN["learnMore"] = "Learn more";
    ButtonLabelsEN["sendGift"] = "Send gift";
    ButtonLabelsEN["goToHelpCenter"] = "Go to help center";
    ButtonLabelsEN["getAnghamiPlus"] = "Get Anghami Plus";
    ButtonLabelsEN["giftAnghamiPlus"] = "Gift Anghami Plus";
    ButtonLabelsEN["login"] = "Login";
    ButtonLabelsEN["manageAccount"] = "Manage Account";
    ButtonLabelsEN["subscribe"] = "Subscribe";
    ButtonLabelsEN["weAreHiring"] = "We're hiring";
    ButtonLabelsEN["haveApp"] = "Continue in app";
})(ButtonLabelsEN || (ButtonLabelsEN = {}));
var ButtonLabelsFR;
(function (ButtonLabelsFR) {
    ButtonLabelsFR["learnMore"] = "Renseignez - vous";
    ButtonLabelsFR["sendGift"] = "Envoyer un cadeau";
    ButtonLabelsFR["goToHelpCenter"] = "Aller au centre d'aide";
    ButtonLabelsFR["getAnghamiPlus"] = "Obtiens Anghami Plus";
    ButtonLabelsFR["giftAnghamiPlus"] = "Offrez Anghami Plus";
    ButtonLabelsFR["subscribe"] = "S'abonner";
    ButtonLabelsFR["login"] = "Connexion";
    ButtonLabelsFR["manageAccount"] = "Gestion du compte";
    ButtonLabelsFR["weAreHiring"] = "Nous recrutons";
    ButtonLabelsFR["haveApp"] = "Continuer depuis l'appli";
})(ButtonLabelsFR || (ButtonLabelsFR = {}));
var ButtonLabelsAR;
(function (ButtonLabelsAR) {
    ButtonLabelsAR["learnMore"] = "\u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0645\u0632\u064A\u062F";
    ButtonLabelsAR["sendGift"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u062A\u0643";
    ButtonLabelsAR["goToHelpCenter"] = "\u0627\u0630\u0647\u0628 \u0627\u0644\u0649 \u0642\u0633\u0645 \u0627\u0644\u0645\u0633\u0627\u0639\u062F\u0629";
    ButtonLabelsAR["getAnghamiPlus"] = "\u0625\u062D\u0635\u0644 \u0639\u0644\u0649 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u0633";
    ButtonLabelsAR["giftAnghamiPlus"] = "\u0623\u0631\u0633\u0644 \u0647\u062F\u064A\u0629 \u0623\u0646\u063A\u0627\u0645\u064A \u0628\u0644\u064E\u0633";
    ButtonLabelsAR["subscribe"] = "\u0627\u0634\u062A\u0631\u0643";
    ButtonLabelsAR["login"] = "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644";
    ButtonLabelsAR["manageAccount"] = "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u062D\u0633\u0627\u0628";
    ButtonLabelsAR["weAreHiring"] = "\u0646\u0648\u0638\u0651\u0641 \u0627\u0644\u0622\u0646!";
    ButtonLabelsAR["haveApp"] = "\u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0645\u0646 \u0627\u0644\u062A\u0637\u0628\u064A\u0642";
})(ButtonLabelsAR || (ButtonLabelsAR = {}));


/***/ }),

/***/ "./src/app/core/components/button/button.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/core/components/button/button.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: inline-block;\n}\n:host a {\n  text-decoration: none;\n  cursor: pointer;\n  color: #FFF;\n  padding: 1.2em 2.5em;\n  border-radius: 3em;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n  display: inline-block;\n}\n:host a.narrow {\n  padding: 0.8em 2.5em;\n}\n:host a .spinner-border {\n  width: 1.5rem;\n  height: 1.5rem;\n  vertical-align: middle;\n  margin-top: -0.1em;\n}\n:host a.loading {\n  padding: 1.2em 4em;\n}\n:host a.purple_gradient {\n  background-image: -webkit-gradient(linear, left top, right top, from(#e1418c), color-stop(#d6379b), color-stop(#c732ab), color-stop(#b035bc), to(#913ccd));\n  background-image: linear-gradient(to right, #e1418c, #d6379b, #c732ab, #b035bc, #913ccd);\n}\n:host a.white {\n  background: #FFF;\n  color: #000;\n}\n:host a.blue_gradient {\n  background: -webkit-gradient(linear, left top, right top, from(#0093fe), to(#5fd2cb));\n  background: linear-gradient(90deg, #0093fe 0%, #5fd2cb 100%);\n}\n:host a.purple {\n  background: #8d00f2;\n}\n:host a.blue {\n  background: #007ffe;\n  background: -webkit-gradient(linear, left top, right top, from(#007ffe), to(#01b5ff));\n  background: linear-gradient(90deg, #007ffe 0%, #01b5ff 100%);\n}\n:host:hover a:not(.loading) {\n  -webkit-transform: translateY(-2px);\n      -ms-transform: translateY(-2px);\n          transform: translateY(-2px);\n  opacity: 0.9;\n  box-shadow: 0px 3px 5px 0px rgba(0, 0, 0, 0.24);\n}"

/***/ }),

/***/ "./src/app/core/components/button/button.component.ts":
/*!************************************************************!*\
  !*** ./src/app/core/components/button/button.component.ts ***!
  \************************************************************/
/*! exports provided: ButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonComponent", function() { return ButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button-labels.enum */ "./src/app/core/components/button/button-labels.enum.ts");




let ButtonComponent = class ButtonComponent {
    constructor(router, locale) {
        this.router = router;
        this.locale = locale;
        this.label = '';
        this.layout = '';
        this.loading = false;
        this.link = '';
        this.target = '';
        this.size = '';
        this.hidden = false;
    }
    ngOnInit() {
        if (!this.label.length) {
            this.hidden = true;
        }
        let pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsEN"];
        if (this.locale === "ar") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsAR"];
        }
        else if (this.locale === "fr") {
            pack = _button_labels_enum__WEBPACK_IMPORTED_MODULE_3__["ButtonLabelsFR"];
        }
        this.label_locale = pack[this.label] || this.label;
    }
    clickHandler(e) {
        if (this.target === "router") {
            e.preventDefault();
            this.router.navigateByUrl(this.link);
        }
        if (this.target === "none") {
            e.preventDefault();
            return;
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "label", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "layout", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
], ButtonComponent.prototype, "loading", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "link", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "target", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ButtonComponent.prototype, "size", void 0);
ButtonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-button',
        template: __webpack_require__(/*! raw-loader!./button.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/button/button.component.html"),
        styles: [__webpack_require__(/*! ./button.component.scss */ "./src/app/core/components/button/button.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], String])
], ButtonComponent);



/***/ }),

/***/ "./src/app/core/components/button/button.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/components/button/button.module.ts ***!
  \*********************************************************/
/*! exports provided: ButtonModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonModule", function() { return ButtonModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button.component */ "./src/app/core/components/button/button.component.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");





let ButtonModule = class ButtonModule {
};
ButtonModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateModule"]],
        declarations: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
        exports: [_button_component__WEBPACK_IMPORTED_MODULE_3__["ButtonComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]],
    })
], ButtonModule);



/***/ }),

/***/ "./src/app/core/components/ramadan/choose-qarii/choose-qarii.component.scss":
/*!**********************************************************************************!*\
  !*** ./src/app/core/components/ramadan/choose-qarii/choose-qarii.component.scss ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n  min-width: 50em;\n  position: relative;\n}\n:host.ramadan {\n  background-image: url(\"https://anghamiwebcdn.akamaized.net/assets/img/ramadan/ramadan-bgd-web.png\");\n}\n@media (max-width: 768px) {\n  :host {\n    min-width: 0em;\n  }\n}\n:host .box {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 75%;\n  margin: auto;\n}\n@media (max-width: 768px) {\n  :host .box {\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    width: 90%;\n    margin: 1em auto;\n  }\n}\n:host .logo {\n  max-width: 15em;\n  display: block;\n  margin: auto;\n}\n:host h5 {\n  width: 70%;\n  margin: auto;\n  text-align: center;\n  margin-bottom: 3.5em;\n  color: white;\n}\n@media (max-width: 768px) {\n  :host h5 {\n    margin-bottom: 0;\n  }\n}\n:host .white-box {\n  background-color: white;\n  width: 13em;\n  height: 15em;\n  border-radius: 0.5em;\n  position: relative;\n  margin: auto 0.5em;\n}\n@media (max-width: 768px) {\n  :host .white-box {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between;\n    height: 7em;\n    width: 80%;\n    margin: 0.5em auto;\n  }\n}\n:host .white-box img {\n  border-radius: 50%;\n  width: 7em;\n  height: 7em;\n  position: absolute;\n  left: 0;\n  right: 0;\n  margin: auto;\n  top: -3.5em;\n  border: 1px solid white;\n}\n@media (max-width: 768px) {\n  :host .white-box img {\n    top: unset;\n    left: 1em;\n    right: 0;\n    margin: unset;\n    position: relative;\n    width: 6em;\n    height: 6em;\n  }\n}\n:host .white-box .title {\n  margin-top: 4.5em;\n  text-align: center;\n  font-size: 1.2em;\n  width: 85%;\n  margin-right: auto;\n  margin-left: auto;\n  color: black;\n  font-weight: 500;\n}\n@media (max-width: 768px) {\n  :host .white-box .title {\n    margin-top: 0;\n  }\n}\n:host .white-box .anghami-primary-btn, :host .white-box .anghami-default-btn {\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 1em;\n  width: 70%;\n  margin: auto;\n}\n@media (max-width: 768px) {\n  :host .white-box .anghami-primary-btn, :host .white-box .anghami-default-btn {\n    display: none;\n  }\n}\n:host .white-box .anghami-default-btn {\n  border-color: var(--brand-purple);\n  color: var(--brand-purple);\n}\n:host .disclaimer {\n  font-size: 1em;\n  text-decoration: underline;\n  cursor: pointer;\n  margin: auto;\n  text-align: center;\n  color: white;\n}\n@media (max-width: 768px) {\n  :host .disclaimer {\n    padding-top: 0 !important;\n  }\n}\n@media (min-width: 769px) {\n  :host label.container {\n    display: none;\n  }\n}\n/* Customize the label (the container) */\n.container {\n  display: block;\n  position: relative;\n  padding-left: 2.5em;\n  cursor: pointer;\n  font-size: 22px;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n  color: white;\n  font-size: 1em;\n}\nlabel.container {\n  margin-bottom: 0 !important;\n}\n/* Hide the browser's default checkbox */\n.container input {\n  position: absolute;\n  opacity: 0;\n  cursor: pointer;\n}\n/* Create a custom checkbox */\n.checkmark {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  height: 2em;\n  width: 2em;\n  background-color: transparent;\n  border: 1px solid #979797;\n  border-radius: 50%;\n  margin: auto;\n}\n/* On mouse-over, add a grey background color */\n/* When the checkbox is checked, add a blue background */\n.container input:checked ~ .checkmark {\n  background-color: var(--brand-purple);\n  border-color: white;\n}\n/* Create the checkmark/indicator (hidden when not checked) */\n.checkmark:after {\n  content: \"\";\n  position: absolute;\n  display: none;\n}\n/* Show the checkmark when checked */\n.container input:checked ~ .checkmark:after {\n  display: block;\n}\n/* Style the checkmark/indicator */\n.container .checkmark:after {\n  left: 0.7em;\n  top: 0.3em;\n  width: 0.5em;\n  height: 1em;\n  border: solid white;\n  border-width: 0px 2px 2px 0;\n  -webkit-transform: rotate(45deg);\n      -ms-transform: rotate(45deg);\n          transform: rotate(45deg);\n}"

/***/ }),

/***/ "./src/app/core/services/mobile-detection.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/services/mobile-detection.service.ts ***!
  \***********************************************************/
/*! exports provided: MobileDetectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileDetectionService", function() { return MobileDetectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm2015/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");





let MobileDetectionService = class MobileDetectionService {
    constructor(_cookie, utils) {
        this._cookie = _cookie;
        this.utils = utils;
        this.verticalScreen = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"]();
        if (this.utils.isBrowser()) {
            this.detectVerticalScreen();
            window.addEventListener('resize', () => {
                this.resizeThrottler();
            }, false);
        }
    }
    resizeThrottler() {
        if (this.utils.isBrowser()) {
            if (!this.resizeTimeout) {
                this.resizeTimeout = setTimeout(() => {
                    this.resizeTimeout = null;
                    this.detectVerticalScreen();
                }, 200);
            }
        }
    }
    detectVerticalScreen() {
        this.device = this._cookie.get('device');
        const width = window.innerWidth < 768 ? true : false;
        const ismobile = this.device && (this.device === 'android' || this.device === 'ios')
            ? true
            : false;
        this.verticalScreen.next(width || ismobile ? true : false);
    }
    getVerticalScreen() {
        return this.verticalScreen.asObservable();
    }
};
MobileDetectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_cookie__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
], MobileDetectionService);



/***/ }),

/***/ "./src/app/modules/landing/gifts/gifts-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/modules/landing/gifts/gifts-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: routes, GiftsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GiftsRoutingModule", function() { return GiftsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _gifts_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./gifts.component */ "./src/app/modules/landing/gifts/gifts.component.ts");




const routes = [
    {
        path: '',
        component: _gifts_component__WEBPACK_IMPORTED_MODULE_3__["GiftsComponent"]
    }
];
let GiftsRoutingModule = class GiftsRoutingModule {
};
GiftsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], GiftsRoutingModule);



/***/ }),

/***/ "./src/app/modules/landing/gifts/gifts.component.scss":
/*!************************************************************!*\
  !*** ./src/app/modules/landing/gifts/gifts.component.scss ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  margin: 1em;\n}\n:host .left-corner {\n  position: absolute;\n  max-width: 35em;\n  left: -23em;\n  z-index: -1;\n  top: -10em;\n}\n@media (max-width: 768px) {\n  :host .left-corner {\n    max-width: 30em;\n    left: -20em;\n    top: -15em;\n  }\n}\n:host .card {\n  width: 22em;\n  height: 14em;\n  border: 1px solid #EEEEEE;\n  border-radius: 0.3em !important;\n  box-shadow: 5px 5px 30px -5px lightgrey;\n  color: white;\n}\n:host .card.faded {\n  opacity: 0.5;\n}\n:host .vertical-space.sm {\n  height: 3em;\n}\n@media (max-width: 768px) {\n  :host .vertical-space.sm {\n    height: 0;\n  }\n}\n:host .vertical-space.md {\n  height: 6em;\n}\n:host .sub-direction {\n  -webkit-box-pack: end !important;\n      -ms-flex-pack: end !important;\n          justify-content: flex-end !important;\n}\n:host .ang-icon {\n  max-width: 4em;\n}\n@media (min-width: 769px) {\n  :host .ang-icon {\n    display: none !important;\n  }\n}\n:host .bottom-details {\n  font-size: 1.3em;\n}\n@media (min-width: 769px) {\n  :host .bottom-details {\n    display: none !important;\n  }\n}\n:host .uppercase {\n  text-transform: uppercase;\n}\n:host .title {\n  font-size: 1.8em;\n  font-weight: 600;\n  line-height: 1em;\n}\n@media (max-width: 768px) {\n  :host .price-wrap, :host .top-details, :host .header-title, :host .card-list-wrap {\n    display: none !important;\n  }\n}\n@media (min-width: 769px) {\n  :host .card-one-wrap {\n    display: none !important;\n  }\n}\n:host .price {\n  font-size: 1.7em;\n  font-weight: 300;\n  white-space: nowrap;\n}\n:host .subtitle {\n  font-size: 1.2em;\n  font-weight: 600;\n}\n@media (max-width: 550px) {\n  :host .cards-wrapper {\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n  }\n}\n:host .flexbox {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .flexbox.colls {\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n:host .flexbox.card-wrap {\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n}\n:host .flexbox.between {\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n:host .flexbox.end {\n  -webkit-box-align: end;\n      -ms-flex-align: end;\n          align-items: flex-end;\n}\n:host .flex-card, :host .cards-wrapper {\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n:host .flex-card.cards, :host .flex-card.colm, :host .cards-wrapper.cards, :host .cards-wrapper.colm {\n  -webkit-box-pack: center !important;\n      -ms-flex-pack: center !important;\n          justify-content: center !important;\n}\n:host .flex-card.card, :host .cards-wrapper.card {\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n:host .flex-card.start, :host .cards-wrapper.start {\n  -webkit-box-align: start !important;\n      -ms-flex-align: start !important;\n          align-items: flex-start !important;\n}\n:host .flex-card.ang-activation-btn, :host .cards-wrapper.ang-activation-btn {\n  -webkit-box-pack: center !important;\n      -ms-flex-pack: center !important;\n          justify-content: center !important;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  text-align: center;\n  max-width: 9em;\n  padding: 0.7em 1.2em;\n  margin: auto;\n}\n:host .flex-card.ang-activation-btn.continue, :host .cards-wrapper.ang-activation-btn.continue {\n  margin: unset !important;\n}\n:host label.container {\n  display: block !important;\n}\n:host .err {\n  text-align: center;\n  color: red;\n  font-size: 0.9em;\n  font-weight: 500;\n}\n:host .desc-sm {\n  font-size: 0.9em;\n  max-width: 20em;\n  padding: 0.5em 0;\n  padding-bottom: 1em;\n  margin: auto;\n  text-align: center;\n  color: #A0A0A0;\n}\n:host .ang-operator-btn {\n  margin: auto;\n}\n:host .hidden {\n  display: none !important;\n}\n:host .header-title {\n  font-size: 1.6em;\n  font-weight: 500;\n  margin-left: 1em;\n}\n:host .invisible {\n  visibility: hidden;\n}\n:host .container input:checked ~ .checkmark {\n  background-color: white;\n}\n:host .container .checkmark::after {\n  border-color: #25AE88 !important;\n}\n:host .checkmark {\n  border-color: #707070 !important;\n  right: 0;\n}\n:host label.container {\n  color: black !important;\n  cursor: pointer;\n}\n:host .container .checkmark:after {\n  left: 0.4em;\n  top: 0.4em;\n  border: 1px solid #707070 !important;\n  border-radius: 50%;\n  border-width: 0.5em;\n  width: 1em;\n  height: 1em;\n  background-color: #707070;\n}\n@media (max-width: 360px) {\n  :host .container .checkmark:after {\n    left: 0.4em;\n  }\n}\n@media (min-width: 361px) and (max-width: 414px) {\n  :host .container .checkmark:after {\n    left: 0.45em;\n  }\n}\n:host .price-details {\n  font-size: 1.4em;\n}\n:host h1 {\n  margin: auto;\n  padding: 0;\n  font-size: 2.2em;\n  text-align: center;\n  font-weight: 500;\n  text-transform: uppercase;\n}\n@media (max-width: 768px) {\n  :host h1 {\n    margin: 1em auto !important;\n  }\n}\n:host h2 {\n  margin: 0.5em auto 1em auto;\n  font-size: 1.2em;\n  text-align: center;\n  font-weight: normal;\n  width: 50%;\n  padding: 0.5em 0em;\n}\n@media (max-width: 768px) {\n  :host h2 {\n    width: 70%;\n  }\n}\n:host .user-form, :host .payment {\n  width: 75%;\n  margin: auto;\n  max-width: 50em;\n}\n@media (max-width: 768px) {\n  :host .user-form, :host .payment {\n    width: 100% !important;\n  }\n}\n:host .disable-cards {\n  opacity: 0.3;\n}\n:host .user-form label {\n  color: #92278F;\n}\n:host .user-form input {\n  border: none;\n  border-bottom: 1px solid #C4C4C4;\n  border-radius: 0;\n}\n:host .user-form .form-control:focus {\n  box-shadow: none;\n  border-color: var(--brand-purple);\n}\n:host .user-form .form-control {\n  padding: 0;\n}\n:host .user-form .form-control::-webkit-input-placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n:host .user-form .form-control::-moz-placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n:host .user-form .form-control:-ms-input-placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n:host .user-form .form-control::-ms-input-placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n:host .user-form .form-control::placeholder {\n  font-size: 0.8em;\n  vertical-align: middle;\n}\n:host .spacer {\n  width: 8em;\n}\n:host .mrt-3 {\n  margin-top: 3em;\n}\n:host .gift-img {\n  max-width: 18em;\n  background: white;\n  display: block;\n  margin: 2em auto 0 auto;\n}\n:host h4 {\n  margin: 3em auto;\n  text-align: center;\n  margin-bottom: 1em;\n}\n:host h6 {\n  margin: 1em auto;\n  text-align: center;\n}\n:host .highlighted {\n  font-weight: 600;\n  color: var(--brand-purple);\n}\n:host .alignItems {\n  -webkit-box-align: end !important;\n      -ms-flex-align: end !important;\n          align-items: flex-end !important;\n}\n::ng-deep .landing-wrapper {\n  background-size: 100% 35% !important;\n}\nhtml[lang=ar] :host {\n  margin: 2em;\n}\nhtml[lang=ar] :host .alignItems {\n  -webkit-box-align: start !important;\n      -ms-flex-align: start !important;\n          align-items: flex-start !important;\n}\nhtml[lang=ar] :host .sub-direction {\n  direction: ltr !important;\n}\nhtml[lang=ar] :host .header-title {\n  margin-left: 0 !important;\n  margin-right: 1em;\n}\nhtml[lang=ar] :host .card-list-wrap {\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n}\n@media (min-width: 769px) {\n  html[lang=ar] :host h1 {\n    margin: 1em auto !important;\n  }\n}"

/***/ }),

/***/ "./src/app/modules/landing/gifts/gifts.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/landing/gifts/gifts.component.ts ***!
  \**********************************************************/
/*! exports provided: GiftsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GiftsComponent", function() { return GiftsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/plus.actions */ "./src/app/core/redux/actions/plus.actions.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _core_enums_enums__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/auth.service */ "./src/app/core/services/auth.service.ts");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _anghami_services_subscription_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @anghami/services/subscription.service */ "./src/app/core/services/subscription.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @anghami/services/mobile-detection.service */ "./src/app/core/services/mobile-detection.service.ts");


















let GiftsComponent = class GiftsComponent {
    constructor(_store, _actionSubject, fb, _translateService, route, router, _authService, _subscriptionService, _utilService, _mobileDetection) {
        this._store = _store;
        this._actionSubject = _actionSubject;
        this.fb = fb;
        this._translateService = _translateService;
        this.route = route;
        this.router = router;
        this._authService = _authService;
        this._subscriptionService = _subscriptionService;
        this._utilService = _utilService;
        this._mobileDetection = _mobileDetection;
        this.env = `${_environments_environment__WEBPACK_IMPORTED_MODULE_15__["environment"].assetsCDN}img/`;
        this.cardsLst = [];
        this.benefitsLst = [];
        this.showCC = false;
        this.showGiftFrm = false;
        this.errMsg = '';
        this.ispurchase = true;
        this.isloading = false;
        this.issuccess = false;
        this.isloggedin = false;
        this.isCardSelected = false;
        if (!this._utilService.detectmob()) {
            this._mobileDetection.verticalScreen.subscribe(isVertical => {
                this.isMobile = isVertical;
                if (this.isMobile && this.cardsLst.length > 0) {
                    this.onCardSelection(this.cardsLst[0], 0);
                }
            });
        }
        else {
            this.isMobile = true;
        }
        this.disableCards = false;
    }
    ngOnInit() {
        this.isloggedin = this._authService.isUserLoggedIn();
        if (this.route.snapshot && this.route.snapshot.params['giftID']) {
            this.router.navigate(['/redeem', this.route.snapshot.params['giftID']]);
            return;
        }
        // TODO: start sending new features
        // this._actionSubject
        //   .pipe(
        //     ofType<GETPlusFeaturesSuccess>(PlusActionTypes.GETPlusFeaturesSuccess),
        //     take(1)
        //   )
        //   .subscribe((res: any) => {
        //     if (res && res !== null) {
        //       const data = res.payload.data;
        //       this.benefitsLst = data;
        //     }
        //   });
        // this._store.dispatch(new GETPlusFeatures());
        this.benefitsLst = this._subscriptionService.getFeaturesLst();
        this._store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_5__["GETGifts"]());
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_5__["PlusActionTypes"].GETGiftsSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1))
            .subscribe((res) => {
            if (res && res !== null) {
                this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_8__["LogAmplitudeEvent"]({
                    name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_9__["AmplitudeEvents"].giftlandLanding
                }));
                const data = res.payload;
                if (data && data !== null && data.plans && data.plans !== null) {
                    data.plans.forEach(elt => {
                        const plan = Object.assign({}, Object.assign({}, elt, { isSelected: false, bgd: {
                                'background-image': "url('" + elt.background_image_url + "')",
                                'background-repeat': 'no-repeat',
                                'background-size': 'cover',
                                'background-position': 'center'
                            } }));
                        this.cardsLst.push(plan);
                    });
                    // Case of mobile we need a plan selected
                    if (this.isMobile) {
                        this.onCardSelection(this.cardsLst[0], 0);
                    }
                }
            }
        });
    }
    back(type) {
        if (type === 'userForm') {
            this.showCC = false;
            this.showGiftFrm = false;
        }
        else if (type === 'paymentForm') {
            this.showGiftFrm = true;
            this.showCC = false;
        }
    }
    setSelected(index, val) {
        return (this.cardsLst[index] = Object.assign({}, this.cardsLst[index], { isSelected: val }));
    }
    onCardSelection(card, index) {
        if (this.isloggedin || this.isMobile) {
            this.selectCard(card, index);
        }
        if (!this.isloggedin) {
            this._store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_12__["OpenCustomDialog"]({
                type: _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_13__["DIALOG_TYPES"].LOGIN
            }));
        }
    }
    selectCard(card, index) {
        this.errMsg = '';
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_8__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_9__["AmplitudeEvents"].selectGiftCard,
            props: {
                card: JSON.stringify(card)
            }
        }));
        for (let i = 0; i < this.cardsLst.length; i++) {
            if (i !== index) {
                this.cardsLst[i] = this.setSelected(i, false);
            }
            else {
                if (this.isMobile) {
                    if (!this.selectedPlan || this.selectedPlan.planid !== this.cardsLst[i].planid) {
                        this.cardsLst[i] = this.setSelected(i, true);
                    }
                }
                else {
                    this.cardsLst[i] = this.setSelected(i, !card.isSelected);
                }
            }
        }
        if (this.cardsLst[index].isSelected) {
            this.selectedPlan = Object.assign({}, this.cardsLst[index], { type: 'POSTpurchaseconsumable', planbutton: this._translateService.instant('confirm_payment'), extradetails: {
                    method: 'card',
                    source: 'gift'
                } });
            if (!this.isMobile) {
                this.showCC = true;
            }
        }
        else {
            this.showCC = false;
            this.selectedPlan = {};
        }
    }
    setLoading() {
        this.isloading = true;
        this.issuccess = false;
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_8__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_9__["AmplitudeEvents"].showGiftLoading
        }));
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_5__["PlusActionTypes"].GETpurchasedGiftsSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1))
            .subscribe((res) => {
            if (res && res !== null) {
                const payload = res.payload;
                if (payload && payload.sections) {
                    const gift = payload.sections.find(elt => elt.type === 'gift');
                    this.selectedGift =
                        gift.data && gift.data !== null
                            ? gift.data.find(elt => elt.id === this.giftid)
                            : {};
                    setTimeout(() => {
                        this.setSuccess();
                    }, 2000);
                }
            }
        });
        this._store.dispatch(new _anghami_redux_actions_plus_actions__WEBPACK_IMPORTED_MODULE_5__["GETpurchasedGifts"]());
    }
    setSuccess() {
        this.isloading = false;
        this.issuccess = true;
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_8__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_9__["AmplitudeEvents"].showGiftSuccess,
            props: {
                giftid: this.giftid
            }
        }));
    }
    successPayment(data) {
        this.giftid = data && data.params ? data.params : data.gift_id;
        this._store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_8__["LogAmplitudeEvent"]({
            name: _core_enums_enums__WEBPACK_IMPORTED_MODULE_9__["AmplitudeEvents"].giftSuccessPayment
        }));
        this.ispurchase = false;
        this.setLoading();
    }
};
GiftsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-gifts',
        template: __webpack_require__(/*! raw-loader!./gifts.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/gifts/gifts.component.html"),
        styles: [__webpack_require__(/*! ../../../core/components/ramadan/choose-qarii/choose-qarii.component.scss */ "./src/app/core/components/ramadan/choose-qarii/choose-qarii.component.scss"), __webpack_require__(/*! ./gifts.component.scss */ "./src/app/modules/landing/gifts/gifts.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_10__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"],
        _anghami_services_auth_service__WEBPACK_IMPORTED_MODULE_11__["AuthService"],
        _anghami_services_subscription_service__WEBPACK_IMPORTED_MODULE_14__["SubscriptionService"],
        _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_16__["UtilService"],
        _anghami_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_17__["MobileDetectionService"]])
], GiftsComponent);



/***/ }),

/***/ "./src/app/modules/landing/gifts/gifts.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/modules/landing/gifts/gifts.module.ts ***!
  \*******************************************************/
/*! exports provided: GiftsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GiftsModule", function() { return GiftsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/components/footer/footer.module */ "./src/app/core/components/footer/footer.module.ts");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");
/* harmony import */ var _gifts_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./gifts-routing.module */ "./src/app/modules/landing/gifts/gifts-routing.module.ts");
/* harmony import */ var _gifts_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./gifts.component */ "./src/app/modules/landing/gifts/gifts.component.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/components/payment-form/payment-form.module */ "./src/app/core/components/payment-form/payment-form.module.ts");
/* harmony import */ var _core_components_benefits_activation_benefits_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/components/benefits/activation-benefits.module */ "./src/app/core/components/benefits/activation-benefits.module.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _core_components_features_features_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/components/features/features.module */ "./src/app/core/components/features/features.module.ts");














let GiftsModule = class GiftsModule {
};
GiftsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _gifts_routing_module__WEBPACK_IMPORTED_MODULE_7__["GiftsRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _core_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_4__["FooterModule"],
            _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_5__["LoadingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_9__["IconModule"],
            _core_components_payment_form_payment_form_module__WEBPACK_IMPORTED_MODULE_10__["PaymentFormModule"],
            _core_components_benefits_activation_benefits_module__WEBPACK_IMPORTED_MODULE_11__["ActivationBenefitsModule"],
            ng_lazyload_image__WEBPACK_IMPORTED_MODULE_12__["LazyLoadImageModule"],
            _core_components_features_features_module__WEBPACK_IMPORTED_MODULE_13__["FeaturesModule"]
        ],
        declarations: [_gifts_component__WEBPACK_IMPORTED_MODULE_8__["GiftsComponent"]],
        exports: [_gifts_component__WEBPACK_IMPORTED_MODULE_8__["GiftsComponent"]]
    })
], GiftsModule);



/***/ })

}]);