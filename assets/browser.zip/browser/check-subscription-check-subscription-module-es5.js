(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["check-subscription-check-subscription-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/inner-header/inner-header.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  id=\"headerid\"\n  class=\"header\"\n  [ngStyle]=\"backgroundimage\"\n  [ngClass]=\"{ extra: backgroundHeader.extra, smallerHeader: smallerHeader }\"\n>\n  <img\n    class=\"logo\"\n    *ngIf=\"backgroundHeader.innerLogo\"\n    [src]=\"backgroundHeader.innerLogo\"\n  />\n  <div>\n    <ng-container *ngIf=\"!isapi\">\n      <h1 class=\"title\">{{ backgroundHeader?.title | translateInstant }}</h1>\n      <h5 class=\"subtitle \">\n        {{ backgroundHeader?.subtitle | translateInstant }}\n      </h5>\n    </ng-container>\n    <ng-container *ngIf=\"isapi\">\n      <div class=\"title\">{{ backgroundHeader?.title }}</div>\n      <h5 class=\"subtitle \">{{ backgroundHeader?.subtitle }}</h5>\n    </ng-container>\n  </div>\n  <img\n    *ngIf=\"isWave\"\n    class=\"wave\"\n    src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\"\n  />\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/white-box/white-box.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"wrapper-box\" [ngClass]=\"{'loader': loading, 'notice': notice, 'brand': brand}\">\n  <div class=\"white-box\" [ngClass]=\"{'notice': notice}\">\n    <ng-content></ng-content>\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/check-subscription/check-subscription.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/check-subscription/check-subscription.component.html ***!
  \****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header\" [ngClass]=\"{'result': !isSuccess}\">\n  <ng-container *ngIf=\"isSuccess\">\n    <h1 class=\"title\" i18n=\"@@congrats_plus\">Congrats! You're now on Anghami Plus</h1>\n    <img class=\"logo\" src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/activations/subscribe-success.png\" />\n  </ng-container>\n  <img class=\"wave\" src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/wave-bgd.png\" />\n</div>\n\n<ng-container *ngIf=\"!isSuccess && message !== ''\">\n  <anghami-white-box\n    [notice]=\"isloading\"\n    [loading]=\"isloading\"\n    class=\"h-100 w-100 ang-white-box\"\n  >\n    <img src=\"https://anghamiwebcdn.akamaized.net/web2/assets/img/plus/success.png\">\n    <div class=\"message\">\n      <div class=\"subtitle\" i18n=\"@@rbt_result\">{{ message }}</div>\n    </div>\n  </anghami-white-box>\n</ng-container>\n\n<ng-container *ngIf=\"isSuccess\">\n  <div class=\"row\">\n    <div class=\"col-lg-12\">\n      <div class=\"benefits-container\">\n        <h3 i18n=\"@@benefit_from_plus_features\">Benefit form all this awesome features with Anghami Plus</h3>\n        <div class=\"benefit\">\n          <div class=\"figure downloads\"></div>\n          <div class='benefit-description'>\n            <h5 i18n=\"@@landing_plus_downloads_title\">Unlimited Downloads</h5>\n            <p i18n=\"@@landing_plus_downloads_subtitle\">Download any song. Play it offline. Save Data.</p>\n          </div>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure nointerruption\"></div>\n          <div class='benefit-description'>\n            <h5 i18n=\"@@landing_plus_noads_title\">No more ads.</h5>\n            <p i18n=\"@@landing_plus_noads_subtitle\">Enjoy all the music you want without any interruption.</p>\n          </div>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure hq\"></div>\n          <div class='benefit-description'>\n            <h5 i18n=\"@@landing_plus_hq_title\">High quality music</h5>\n            <p i18n=\"@@landing_plus_hq_subtitle\">The sound quality is 5x better (with *Dolby 320 Kbps*)</p>\n          </div>\n        </div>\n\n        <div class=\"benefit\">\n          <div class=\"figure lyrics\"></div>\n          <div class='benefit-description'>\n            <h5 i18n=\"@@landing_plus_lyrics_title\">Unlock the Lyrics</h5>\n            <p>Sing along with your favorite songs.</p>\n          </div>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure skiprepeat\"></div>\n          <div class='benefit-description'>\n            <h5 i18n=\"@@landing_plus_restrictions_title\">Restriction-free music.</h5>\n            <p i18n=\"@@landing_plus_restrictions_subtitle\">Go to the previous song or the next one. Repeat the one you\n              love.\n              Scrub to your favorite part.</p>\n          </div>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure import\"></div>\n          <div class='benefit-description'>\n            <h5 i18n=\"@@landing_plus_import_title\">Bring your music to Anghami.</h5>\n            <p i18n=\"@@landing_plus_import_subtitle\">Import any song that’s not on Anghami via the desktop app.</p>\n          </div>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure boost\"></div>\n          <div class='benefit-description'>\n            <h5 i18n=\"@@landing_plus_boost_title\">Boost your sound</h5>\n            <p i18n=\"@@landing_plus_boost_subtitle\">Connect multiple devices together to play the same music at the same\n              time.</p>\n          </div>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure connect\"></div>\n          <div class='benefit-description'>\n            <h5 i18n=\"@@landing_plus_connectphone_title\">Connect Phones. Control music.</h5>\n            <p i18n=\"@@landing_plus_connectphone_subtitle\">Connect phones remotely without bluetooth and control your\n              music.\n            </p>\n          </div>\n        </div>\n        <div class=\"benefit\">\n          <div class=\"figure exclusive\"></div>\n          <div class='benefit-description'>\n            <h5 i18n=\"@@landing_plus_exclusive_title\">Exclusive music</h5>\n            <p i18n=\"@@landing_plus_exclusive_subtitle\">Be the first to play the latest songs of your favorite artists,\n              exclusively.</p>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ng-container>"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: -webkit-gradient(linear, left top, right top, from(#e03f8d), color-stop(#a22ccf), to(#2fa0df));\n  background: linear-gradient(to right, #e03f8d, #a22ccf, #2fa0df);\n  height: 30em;\n  background-size: cover !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    height: auto;\n    min-height: 15em;\n  }\n}\n:host .header.pringles {\n  background-size: cover !important;\n  background-position: center !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header.extra .title {\n  width: 60%;\n  margin: auto;\n}\n:host .header .logo {\n  max-width: 5em;\n  display: block;\n  margin: 1em auto;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n  }\n}\n:host .header .subtitle {\n  font-size: 1.2rem;\n  margin: auto;\n  font-weight: 200;\n  text-align: center;\n  padding-top: 0.5em;\n}\n@media (max-width: 768px) {\n  :host .header .subtitle {\n    width: 85%;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}"

/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.component.ts ***!
  \************************************************************************/
/*! exports provided: InnerHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderComponent", function() { return InnerHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/mobile-detection.service */ "./src/app/core/services/mobile-detection.service.ts");



var InnerHeaderComponent = /** @class */ (function () {
    function InnerHeaderComponent(_mobileDetection, locale) {
        this._mobileDetection = _mobileDetection;
        this.locale = locale;
        this.locale =
            this.locale && this.locale !== null
                ? this.locale.indexOf('en') > -1
                    ? 'en'
                    : this.locale
                : 'en';
    }
    InnerHeaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._mobileDetection.verticalScreen.subscribe(function (isVertical) {
            if (_this.backgroundHeader.mainimagemobile) {
                var image = isVertical
                    ? _this.backgroundHeader.mainimagemobile
                    : _this.backgroundHeader.mainimage;
                _this.setBackgroundImage(image, _this.backgroundHeader.backgroundcolor);
            }
        });
    };
    InnerHeaderComponent.prototype.setBackgroundImage = function (img, color) {
        var backgroundcolor = color && color !== null && color !== ''
            ? color
            : 'linear-gradient(to right, #E03F8D, #A22CCF, #2FA0DF)';
        this.backgroundimage = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.backgroundimage, { background: 'url(' +
                img +
                ') 0% 0%,' + backgroundcolor });
    };
    InnerHeaderComponent.prototype.ngOnChanges = function () {
        if (this.backgroundHeader && this.backgroundHeader !== null) {
            if (this.backgroundHeader.mainimage) {
                this.backgroundimage = {
                    'background-size': 'cover',
                };
                this.setBackgroundImage(this.backgroundHeader.mainimage);
            }
            if (this.backgroundHeader.type) {
                var headerElt = document.getElementById('headerid');
                if (headerElt && headerElt !== null) {
                    headerElt.classList.add(this.backgroundHeader.type);
                }
            }
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('backgroundHeader'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InnerHeaderComponent.prototype, "backgroundHeader", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('smallerHeader'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InnerHeaderComponent.prototype, "smallerHeader", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InnerHeaderComponent.prototype, "isWave", void 0);
    InnerHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-inner-header',
            template: __webpack_require__(/*! raw-loader!./inner-header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/inner-header/inner-header.component.html"),
            styles: [__webpack_require__(/*! ./inner-header.component.scss */ "./src/app/core/components/inner-header/inner-header.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_mobile_detection_service__WEBPACK_IMPORTED_MODULE_2__["MobileDetectionService"], String])
    ], InnerHeaderComponent);
    return InnerHeaderComponent;
}());



/***/ }),

/***/ "./src/app/core/components/inner-header/inner-header.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/core/components/inner-header/inner-header.module.ts ***!
  \*********************************************************************/
/*! exports provided: InnerHeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InnerHeaderModule", function() { return InnerHeaderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.component */ "./src/app/core/components/inner-header/inner-header.component.ts");
/* harmony import */ var _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/pipes/pipes.module */ "./src/app/core/pipes/pipes.module.ts");





var InnerHeaderModule = /** @class */ (function () {
    function InnerHeaderModule() {
    }
    InnerHeaderModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _core_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__["PipesModule"]],
            declarations: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
            exports: [_core_components_inner_header_inner_header_component__WEBPACK_IMPORTED_MODULE_3__["InnerHeaderComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], InnerHeaderModule);
    return InnerHeaderModule;
}());



/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .wrapper-box {\n  display: inline-block;\n  margin: auto;\n  width: 100%;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box {\n    width: 90%;\n  }\n}\n:host .wrapper-box.loader {\n  width: 40% !important;\n}\n:host .wrapper-box.notice {\n  width: unset;\n}\n@media (max-width: 768px) {\n  :host .wrapper-box.notice {\n    width: 90%;\n  }\n}\n:host .wrapper-box.brand .white-box {\n  margin-top: -5.5em !important;\n}\n:host .white-box {\n  margin: auto;\n  min-width: 5em;\n  border: 1px solid #EEEEEE;\n  border-radius: 0.5em;\n  box-shadow: 5px 5px 30px -5px lightgrey;\n  padding: 1.5em;\n  display: block;\n  background-color: white;\n  position: relative;\n  max-width: 55em;\n  margin-top: -8em;\n}\n@media (max-width: 768px) {\n  :host .white-box {\n    margin-top: -3em;\n  }\n}\n:host .white-box.notice {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-top: -5em;\n  padding: 2em;\n}"

/***/ }),

/***/ "./src/app/core/components/white-box/white-box.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.component.ts ***!
  \******************************************************************/
/*! exports provided: WhiteBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxComponent", function() { return WhiteBoxComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var WhiteBoxComponent = /** @class */ (function () {
    function WhiteBoxComponent() {
    }
    WhiteBoxComponent.prototype.ngOnInit = function () { };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], WhiteBoxComponent.prototype, "notice", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], WhiteBoxComponent.prototype, "loading", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], WhiteBoxComponent.prototype, "brand", void 0);
    WhiteBoxComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-white-box',
            template: __webpack_require__(/*! raw-loader!./white-box.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/white-box/white-box.component.html"),
            styles: [__webpack_require__(/*! ./white-box.component.scss */ "./src/app/core/components/white-box/white-box.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], WhiteBoxComponent);
    return WhiteBoxComponent;
}());



/***/ }),

/***/ "./src/app/core/components/white-box/white-box.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/core/components/white-box/white-box.module.ts ***!
  \***************************************************************/
/*! exports provided: WhiteBoxModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhiteBoxModule", function() { return WhiteBoxModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.component */ "./src/app/core/components/white-box/white-box.component.ts");




var WhiteBoxModule = /** @class */ (function () {
    function WhiteBoxModule() {
    }
    WhiteBoxModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
            declarations: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
            exports: [_core_components_white_box_white_box_component__WEBPACK_IMPORTED_MODULE_3__["WhiteBoxComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], WhiteBoxModule);
    return WhiteBoxModule;
}());



/***/ }),

/***/ "./src/app/core/services/mobile-detection.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/services/mobile-detection.service.ts ***!
  \***********************************************************/
/*! exports provided: MobileDetectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileDetectionService", function() { return MobileDetectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie */ "./node_modules/ngx-cookie/fesm5/ngx-cookie.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");





var MobileDetectionService = /** @class */ (function () {
    function MobileDetectionService(_cookie, utils) {
        var _this = this;
        this._cookie = _cookie;
        this.utils = utils;
        this.verticalScreen = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"]();
        if (this.utils.isBrowser()) {
            this.detectVerticalScreen();
            window.addEventListener('resize', function () {
                _this.resizeThrottler();
            }, false);
        }
    }
    MobileDetectionService.prototype.resizeThrottler = function () {
        var _this = this;
        if (this.utils.isBrowser()) {
            if (!this.resizeTimeout) {
                this.resizeTimeout = setTimeout(function () {
                    _this.resizeTimeout = null;
                    _this.detectVerticalScreen();
                }, 200);
            }
        }
    };
    MobileDetectionService.prototype.detectVerticalScreen = function () {
        this.device = this._cookie.get('device');
        var width = window.innerWidth < 768 ? true : false;
        var ismobile = this.device && (this.device === 'android' || this.device === 'ios')
            ? true
            : false;
        this.verticalScreen.next(width || ismobile ? true : false);
    };
    MobileDetectionService.prototype.getVerticalScreen = function () {
        return this.verticalScreen.asObservable();
    };
    MobileDetectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_cookie__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])
    ], MobileDetectionService);
    return MobileDetectionService;
}());



/***/ }),

/***/ "./src/app/core/services/sub-operators.service.ts":
/*!********************************************************!*\
  !*** ./src/app/core/services/sub-operators.service.ts ***!
  \********************************************************/
/*! exports provided: SubOperatorsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubOperatorsService", function() { return SubOperatorsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/operators.actions */ "./src/app/core/redux/actions/operators.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");









var SubOperatorsService = /** @class */ (function () {
    function SubOperatorsService(_utilsService, _actionSubject, _store, platformId) {
        this._utilsService = _utilsService;
        this._actionSubject = _actionSubject;
        this._store = _store;
        this.platformId = platformId;
        this.msidnValidations = {};
        this.clearResultMessage();
    }
    SubOperatorsService.prototype.clearResultMessage = function () {
        this.resultmsg = '';
    };
    SubOperatorsService.prototype.getOperatorPlan = function (opdetails, isActivation) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_8__["isPlatformServer"])(this.platformId)) {
            return;
        }
        if (opdetails && opdetails !== null && Object.keys(opdetails).length > 0) {
            var appSidFromUrl = this._utilsService.getQueryFromUrl('appsid')
                || this._utilsService.getQueryFromUrl('sid');
            var params = {
                type: 'GEToperatorplan',
                output: 'jsonhp'
            };
            if (isActivation) {
                params['activation'] = opdetails.type;
            }
            else {
                params = Object.assign(params, opdetails);
            }
            if (appSidFromUrl) {
                params['appsid'] = appSidFromUrl;
            }
            var result = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["race"])(this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["OperatorsActionTypes"].GETOperatorSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(function (res) {
                return {
                    res: res.payload
                };
            })), this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["OperatorsActionTypes"].GETOperatorError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(function (res) {
                return {
                    res: res.payload
                };
            })));
            this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["GETOperator"](params));
            return result;
        }
    };
    SubOperatorsService.prototype.autofillPhoneNumber = function (msidn) {
        var mobilenum = '';
        if (msidn && msidn != null && msidn !== '') {
            var msidncode = msidn.substring(0, 3);
            if (msidncode === this.msidnValidations['countrycode']) {
                mobilenum = msidn.replace(/^.{3}/g, '');
            }
        }
        return mobilenum;
    };
    SubOperatorsService.prototype.checkOperatorValidationsExist = function (plan) {
        if (plan.min_digits && plan.min_digits !== null && plan.min_digits !== ''
            && plan.max_digits && plan.max_digits !== null && plan.max_digits !== ''
            && plan.country_code && plan.country_code !== null && plan.country_code !== '') {
            return true;
        }
        return false;
    };
    SubOperatorsService.prototype.setMsidnDetails = function (plan) {
        var validations = {};
        if (this.checkOperatorValidationsExist(plan)) {
            validations = {
                min_digits: plan.min_digits,
                max_digits: plan.max_digits,
                countrycode: plan.country_code
            };
        }
        return validations;
    };
    SubOperatorsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["ActionsSubject"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
            Object])
    ], SubOperatorsService);
    return SubOperatorsService;
}());



/***/ }),

/***/ "./src/app/modules/landing/check-subscription/check-subscription-routing.module.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/modules/landing/check-subscription/check-subscription-routing.module.ts ***!
  \*****************************************************************************************/
/*! exports provided: routes, CheckSubscriptionRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckSubscriptionRoutingModule", function() { return CheckSubscriptionRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _check_subscription_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./check-subscription.component */ "./src/app/modules/landing/check-subscription/check-subscription.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var routes = [
    {
        path: '',
        component: _check_subscription_component__WEBPACK_IMPORTED_MODULE_1__["CheckSubscriptionComponent"]
    }
];
var CheckSubscriptionRoutingModule = /** @class */ (function () {
    function CheckSubscriptionRoutingModule() {
    }
    CheckSubscriptionRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"]]
        })
    ], CheckSubscriptionRoutingModule);
    return CheckSubscriptionRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/check-subscription/check-subscription.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/modules/landing/check-subscription/check-subscription.component.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .smallerHeader {\n  height: 25em !important;\n}\n@media (max-width: 575.98px) {\n  :host .smallerHeader {\n    height: 15em !important;\n    min-height: 15em !important;\n  }\n}\n:host .ang-white-box img {\n  max-width: 4em;\n}\n:host .ang-white-box .message {\n  font-size: 1.2em;\n  padding: 0 1em;\n  text-align: center;\n}\n:host .header {\n  position: relative;\n  color: white;\n  background-repeat: no-repeat !important;\n  background-position: top;\n  background: transparent -webkit-gradient(linear, left top, left bottom, from(#00BDFE), to(#0031F5)) 0% 0% no-repeat padding-box;\n  background: transparent linear-gradient(180deg, #00BDFE 0%, #0031F5 100%) 0% 0% no-repeat padding-box;\n  height: 35em;\n  background-size: 100%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n@media (max-width: 768px) {\n  :host .header {\n    background-size: cover;\n    min-height: 20em;\n    background-position: center right !important;\n  }\n}\n:host .header.result .title {\n  margin-top: 0 !important;\n}\n@media (max-width: 768px) {\n  :host .header.extra {\n    background-position: center !important;\n  }\n}\n:host .header .logo {\n  max-width: 30em;\n  display: block;\n  z-index: 2;\n}\n:host .header .title {\n  font-weight: bold;\n  text-align: center;\n  font-size: 2.25em;\n  margin-top: 10em;\n}\n@media (max-width: 768px) {\n  :host .header .title {\n    width: 90%;\n    margin: auto;\n    font-size: 1.75em;\n    margin-top: 10em;\n  }\n}\n:host .wave {\n  width: 100%;\n  position: absolute;\n  bottom: -0.1em;\n  left: 0;\n  right: 0;\n}\n:host .row {\n  width: 85%;\n  margin: auto;\n  margin-top: 12em;\n  margin-bottom: 4em;\n}\n@media (max-width: 768px) {\n  :host .row {\n    width: 90%;\n  }\n}\n:host .benefits-container {\n  text-align: center;\n  padding: 0 1em;\n}\n:host .benefits-container h3 {\n  margin-bottom: 1.5em;\n}\n@media (max-width: 768px) {\n  :host .benefits-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    text-align: left;\n  }\n  :host .benefits-container p {\n    font-size: 1.1em;\n  }\n  :host .benefits-container h3 {\n    font-size: 1.4em;\n  }\n}\n:host .benefits-container .benefit {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0.5em;\n  max-width: 16em;\n}\n@media (max-width: 768px) {\n  :host .benefits-container .benefit {\n    max-width: 35em;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n  }\n  :host .benefits-container .benefit .benefit-description {\n    margin-left: 2em;\n  }\n}\n:host .benefits-container .benefit h5 {\n  font-size: 1.2em;\n}\n:host .benefits-container .benefit .figure {\n  width: 8em;\n  height: 10em;\n  background-repeat: no-repeat;\n  background-size: 100%;\n  background-position: center center;\n}\n@media (max-width: 768px) {\n  :host .benefits-container .benefit .figure {\n    max-width: 10em;\n  }\n}\n:host .benefits-container .benefit .figure.downloads {\n  background-image: url('8992@2x.png');\n}\n:host .benefits-container .benefit .figure.nointerruption {\n  background-image: url('8993@2x.png');\n}\n:host .benefits-container .benefit .figure.hq {\n  background-image: url('8996@2x.png');\n}\n@media (max-width: 768px) {\n  :host .benefits-container .benefit .figure.hq {\n    width: 8.6em !important;\n  }\n}\n:host .benefits-container .benefit .figure.lyrics {\n  background-image: url('9002@2x.png');\n}\n@media (max-width: 768px) {\n  :host .benefits-container .benefit .figure.lyrics {\n    width: 6em !important;\n  }\n}\n:host .benefits-container .benefit .figure.skiprepeat {\n  background-image: url('8995@2x.png');\n}\n@media (max-width: 768px) {\n  :host .benefits-container .benefit .figure.skiprepeat {\n    width: 15em !important;\n  }\n}\n:host .benefits-container .benefit .figure.import {\n  background-image: url('8999@2x.png');\n}\n:host .benefits-container .benefit .figure.import {\n  background-image: url('8999@2x.png');\n}\n:host .benefits-container .benefit .figure.boost {\n  background-image: url('8998@2x.png');\n}\n@media (max-width: 768px) {\n  :host .benefits-container .benefit .figure.boost {\n    width: 10em !important;\n  }\n}\n:host .benefits-container .benefit .figure.connect {\n  background-image: url('8997@2x.png');\n}\n:host .benefits-container .benefit .figure.exclusive {\n  background-image: url('8994@2x.png');\n}"

/***/ }),

/***/ "./src/app/modules/landing/check-subscription/check-subscription.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/modules/landing/check-subscription/check-subscription.component.ts ***!
  \************************************************************************************/
/*! exports provided: CheckSubscriptionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckSubscriptionComponent", function() { return CheckSubscriptionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/services/sub-operators.service */ "./src/app/core/services/sub-operators.service.ts");
/* harmony import */ var _anghami_services_gtmConversion_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/gtmConversion.service */ "./src/app/core/services/gtmConversion.service.ts");





var CheckSubscriptionComponent = /** @class */ (function () {
    function CheckSubscriptionComponent(_route, _subOperatorsService, _gtmConversion) {
        this._route = _route;
        this._subOperatorsService = _subOperatorsService;
        this._gtmConversion = _gtmConversion;
        this.isloading = true;
        this.message = '';
    }
    CheckSubscriptionComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._route.queryParams.subscribe(function (params) {
            _this.isSuccess = (params['success'] == 1);
            if (!_this.isSuccess) {
                _this.message = _this._subOperatorsService.resultmsg;
            }
            if (params['operator'] && params['operator'] !== null) {
                _this.initTracking(params['operator']);
            }
        });
    };
    CheckSubscriptionComponent.prototype.initTracking = function (operator) {
        if (operator.toLowerCase() === 'stc') {
            this._gtmConversion.reportTwitterConversion(operator);
            this._gtmConversion.reportFacebookConversion(operator);
            this._gtmConversion.reportSnapConversion(operator);
        }
    };
    CheckSubscriptionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-check-subscription',
            template: __webpack_require__(/*! raw-loader!./check-subscription.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/check-subscription/check-subscription.component.html"),
            styles: [__webpack_require__(/*! ./check-subscription.component.scss */ "./src/app/modules/landing/check-subscription/check-subscription.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_3__["SubOperatorsService"],
            _anghami_services_gtmConversion_service__WEBPACK_IMPORTED_MODULE_4__["GtmConversionService"]])
    ], CheckSubscriptionComponent);
    return CheckSubscriptionComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/check-subscription/check-subscription.module.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/modules/landing/check-subscription/check-subscription.module.ts ***!
  \*********************************************************************************/
/*! exports provided: CheckSubscriptionModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckSubscriptionModule", function() { return CheckSubscriptionModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _check_subscription_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./check-subscription-routing.module */ "./src/app/modules/landing/check-subscription/check-subscription-routing.module.ts");
/* harmony import */ var _check_subscription_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./check-subscription.component */ "./src/app/modules/landing/check-subscription/check-subscription.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/inner-header/inner-header.module */ "./src/app/core/components/inner-header/inner-header.module.ts");
/* harmony import */ var _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/white-box/white-box.module */ "./src/app/core/components/white-box/white-box.module.ts");







var CheckSubscriptionModule = /** @class */ (function () {
    function CheckSubscriptionModule() {
    }
    CheckSubscriptionModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            declarations: [
                _check_subscription_component__WEBPACK_IMPORTED_MODULE_2__["CheckSubscriptionComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _check_subscription_routing_module__WEBPACK_IMPORTED_MODULE_1__["CheckSubscriptionRoutingModule"],
                _core_components_inner_header_inner_header_module__WEBPACK_IMPORTED_MODULE_5__["InnerHeaderModule"],
                _core_components_white_box_white_box_module__WEBPACK_IMPORTED_MODULE_6__["WhiteBoxModule"]
            ],
            exports: [
                _check_subscription_component__WEBPACK_IMPORTED_MODULE_2__["CheckSubscriptionComponent"]
            ],
        })
    ], CheckSubscriptionModule);
    return CheckSubscriptionModule;
}());



/***/ })

}]);