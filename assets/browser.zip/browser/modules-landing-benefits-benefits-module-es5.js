(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modules-landing-benefits-benefits-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/benefits/benefits.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/benefits/benefits.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"heading-img\">\n  <img class=\"heading-img-background\" [src]=\"assetsEnv + 'Bg.jpg'\" />\n</div>\n<div class=\"wrapper\">\n  <img\n    class=\"heading-ang-logo\"\n    src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/landing/anghami-logo-white.png\"\n  />\n  <img class=\"heading-img-phones\" [src]=\"assetsEnv + 'phones.png'\" />\n  <div class=\"heading-text\" i18n=\"@@staticlanding_title\">\n    This summer, play millions of songs. Anytime, anywhere.\n  </div>\n  <div class=\"heading-paragraph\" i18n=\"@@staticlanding_subtitle\">\n    Enjoy Arabic & International songs, follow your favorite artists be the\n    first to play their latest. Create playlists for every minute of your day.\n  </div>\n  <div>\n    <button\n      class=\"subscribe-btn\"\n      (click)=\"subscribe()\"\n      i18n=\"@@staticlanding_button\"\n    >\n      Subscribe Now\n    </button>\n  </div>\n  <div class=\"terms-and-conditions\" i18n=\"@@staticlanding_benefits_buttonsub\">\n    Terms and Conditions apply. Cancel anytime.\n  </div>\n  <div>\n    <img [src]=\"assetsEnv + 'Arrow.png'\" />\n  </div>\n  <div class=\"benefits-title\" i18n=\"@@staticlanding_benefits_title\">\n    With Anghami Plus, you can benefit from\n  </div>\n  <div class=\"benefits-container\">\n    <div class=\"lg-row\">\n      <div class=\"benefits-section\">\n        <div class=\"benefits-img-container\">\n          <img [src]=\"assetsEnv + 'Download@2x.png'\" />\n        </div>\n        <div class=\"benefits-text-container\" i18n=\"@@staticlanding_benefit1\">\n          Download from millions of songs & play them offline\n        </div>\n      </div>\n      <div class=\"benefits-section\">\n        <div class=\"benefits-img-container\">\n          <img [src]=\"assetsEnv + 'No ads@2x.png'\" />\n        </div>\n        <div class=\"benefits-text-container\" i18n=\"@@staticlanding_benefit2\">\n          Music with no ads and no interruptions\n        </div>\n      </div>\n      <div class=\"benefits-section\">\n        <div class=\"benefits-img-container\">\n          <img [src]=\"assetsEnv + 'Lyrics@2x.png'\" />\n        </div>\n        <div class=\"benefits-text-container\" i18n=\"@@staticlanding_benefit3\">\n          Sing along with lyrics\n        </div>\n      </div>\n    </div>\n    <div class=\"lg-row\">\n      <div class=\"benefits-section\">\n        <div class=\"benefits-img-container\">\n          <img [src]=\"assetsEnv + 'Skip@2x.png'\" />\n        </div>\n        <div class=\"benefits-text-container\" i18n=\"@@staticlanding_benefit4\">\n          Rewind to the beginning or scrub to your favorite part.\n        </div>\n      </div>\n      <div class=\"benefits-section\">\n        <div class=\"benefits-img-container\">\n          <img [src]=\"assetsEnv + 'Repeat@2x.png'\" />\n        </div>\n        <div class=\"benefits-text-container\" i18n=\"@@staticlanding_benefit5\">\n          Repeat all the songs you love as much as you want\n        </div>\n      </div>\n      <div class=\"benefits-section\">\n        <div class=\"benefits-img-container\">\n          <img [src]=\"assetsEnv + 'Import@2x.png'\" />\n        </div>\n        <div class=\"benefits-text-container\" i18n=\"@@staticlanding_benefit6\">\n          Import the music you want to your account\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"lg-display-none\">\n    <div>\n      <button\n        class=\"subscribe-btn\"\n        i18n=\"@@staticlanding_benefits_button\"\n        (click)=\"subscribe()\"\n      >\n        Subscribe to Anghami Plus\n      </button>\n    </div>\n    <div class=\"terms-and-conditions\" i18n=\"@@staticlanding_benefits_buttonsub\">\n      Terms and Conditions apply. Cancel anytime.\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/modules/landing/benefits/benefits.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/modules/landing/benefits/benefits.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@import url(\"https://fonts.googleapis.com/css?family=Lato\");\n:host .wrapper {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  font-family: Lato, sans-serif;\n}\n:host .heading-img .heading-img-background {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  width: 100%;\n  z-index: -1;\n}\n:host .heading-ang-logo {\n  width: 200px;\n  margin-top: 60px;\n}\n:host .heading-img-phones {\n  margin-top: 60px;\n}\n:host .heading-text {\n  max-width: 500px;\n  font-family: Lato, sans-serif;\n  font-size: 30px;\n  margin-top: 30px;\n  text-align: center;\n  line-height: 30px;\n}\n:host .heading-paragraph {\n  margin-top: 18px;\n  font-size: 14px;\n  text-align: center;\n  max-width: 400px;\n}\n:host .subscribe-btn {\n  margin-top: 20px;\n  background-image: -webkit-gradient(linear, left top, right top, from(#0084ff), to(#00b0f6)), -webkit-gradient(linear, left top, left bottom, from(#0084ff), to(#00b0f6));\n  background-image: linear-gradient(90deg, #0084ff, #00b0f6), linear-gradient(180deg, #0084ff, #00b0f6);\n  padding: 9px 15px;\n  color: white;\n  box-shadow: 0 0 5px 1px rgba(0, 0, 0, 0.32);\n  border: none;\n  border-radius: 20px;\n  font-weight: 700;\n  font-size: 14px;\n}\n:host .terms-and-conditions {\n  max-width: 300px;\n  font-family: Lato, sans-serif;\n  color: #727272;\n  font-size: 12px;\n  text-align: center;\n  margin-top: 7px;\n  margin-bottom: 40px;\n}\n:host .benefits-title {\n  margin-top: 40px;\n  margin-bottom: 40px;\n  padding-top: 1px;\n  padding-bottom: 1px;\n  font-family: Lato, sans-serif;\n  font-size: 19px;\n  font-weight: 700;\n  text-align: center;\n}\n:host .benefits-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  max-width: 313px;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n:host .benefits-container .benefits-section {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n  margin-bottom: 22px;\n}\n:host .benefits-container .benefits-section .benefits-img-container img {\n  max-width: 55px;\n}\n:host .benefits-container .benefits-section .benefits-text-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  padding-bottom: 10px;\n  border-bottom: 1px solid #d8d8d8;\n  font-family: Lato, sans-serif;\n  font-size: 16px;\n  margin-left: 15px;\n}\n@media only screen and (min-width: 769px) {\n  :host .lg-display-none {\n    display: none;\n  }\n}\n@media only screen and (min-width: 769px) {\n  :host .lg-row {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n  }\n  :host .lg-row .benefits-section {\n    margin-left: 15px;\n    margin-right: 15px;\n  }\n  :host .lg-row .benefits-text-container {\n    min-width: 270px;\n  }\n}\n@media only screen and (min-width: 319px) and (max-width: 755px) {\n  :host .heading-img-phones {\n    max-width: 310px;\n    margin-top: 15px !important;\n  }\n  :host .heading-ang-logo {\n    margin-top: 15px !important;\n    width: 150px !important;\n  }\n}\n@media only screen and (min-width: 756px) and (max-width: 1458px) {\n  :host .heading-img-phones {\n    max-width: 600px;\n    margin-top: 30px !important;\n  }\n  :host .heading-ang-logo {\n    margin-top: 30px !important;\n  }\n}\n@media only screen and (min-width: 1459px) {\n  :host .heading-img-phones {\n    max-width: 700px;\n    margin-top: 30px !important;\n  }\n  :host .heading-ang-logo {\n    margin-top: 30px !important;\n  }\n}\nhtml[lang=ar] :host .benefits-text-container {\n  text-align: right;\n  padding-right: 10px;\n}"

/***/ }),

/***/ "./src/app/modules/landing/benefits/benefits.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/modules/landing/benefits/benefits.component.ts ***!
  \****************************************************************/
/*! exports provided: BenefitsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BenefitsComponent", function() { return BenefitsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");




var BenefitsComponent = /** @class */ (function () {
    function BenefitsComponent(route) {
        this.route = route;
        this.assetsEnv = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].assetsCDN + "img/static-subscribe/";
    }
    BenefitsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.queryParams.subscribe(function (params) {
            if (params.planid) {
                _this.planid = params.planid;
            }
        });
    };
    BenefitsComponent.prototype.subscribe = function () {
        window.location.href = this.planid
            ? 'https://plus.anghami.com/subscribe/' + this.planid
            : 'https://plus.anghami.com';
    };
    BenefitsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-benefits-components',
            template: __webpack_require__(/*! raw-loader!./benefits.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/benefits/benefits.component.html"),
            styles: [__webpack_require__(/*! ./benefits.component.scss */ "./src/app/modules/landing/benefits/benefits.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], BenefitsComponent);
    return BenefitsComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/benefits/benefits.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/modules/landing/benefits/benefits.module.ts ***!
  \*************************************************************/
/*! exports provided: BenefitsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BenefitsModule", function() { return BenefitsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _benefits_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./benefits.component */ "./src/app/modules/landing/benefits/benefits.component.ts");
/* harmony import */ var _benefits_route__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./benefits.route */ "./src/app/modules/landing/benefits/benefits.route.ts");







var BenefitsModule = /** @class */ (function () {
    function BenefitsModule() {
    }
    BenefitsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"], _benefits_route__WEBPACK_IMPORTED_MODULE_6__["BenefitsRoutingModule"]],
            declarations: [_benefits_component__WEBPACK_IMPORTED_MODULE_5__["BenefitsComponent"]],
            exports: [_benefits_component__WEBPACK_IMPORTED_MODULE_5__["BenefitsComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], BenefitsModule);
    return BenefitsModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/benefits/benefits.route.ts":
/*!************************************************************!*\
  !*** ./src/app/modules/landing/benefits/benefits.route.ts ***!
  \************************************************************/
/*! exports provided: routes, BenefitsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BenefitsRoutingModule", function() { return BenefitsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _benefits_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./benefits.component */ "./src/app/modules/landing/benefits/benefits.component.ts");




var routes = [
    {
        path: '',
        component: _benefits_component__WEBPACK_IMPORTED_MODULE_3__["BenefitsComponent"]
    }
];
var BenefitsRoutingModule = /** @class */ (function () {
    function BenefitsRoutingModule() {
    }
    BenefitsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
            providers: []
        })
    ], BenefitsRoutingModule);
    return BenefitsRoutingModule;
}());



/***/ })

}]);