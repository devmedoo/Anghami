(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["search-search-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/search/search.component.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/search/search.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main search-component\">\n  <div class=\"row margin0\">\n    <div\n      class=\"col-md-12 search-tabs-container\"\n      *ngIf=\"(currentSearchTabs$ | async)?.length !== 0\"\n    >\n      <ng-container *ngFor=\"let item of (currentSearchTabs$ | async)\">\n        <div\n          class=\"search-tabs-tab\"\n          [ngClass]=\"{ selected: item.searchgroup === activeTab }\"\n        >\n          <a\n            href=\"javascript:void(0)\"\n            (click)=\"changeActiveSection(item.searchgroup)\"\n            >{{ item.title }}</a\n          >\n        </div>\n      </ng-container>\n    </div>\n  </div>\n\n  <ng-container *ngIf=\"searchReady\">\n    <anghami-new-section-builder\n      [sections]=\"currentSearchSection$ | async\"\n      [fromSearch]=\"true\"\n      [isSearchActiveTabSong]=\"isSearchActiveTabSong\"\n      (searchPaginationEvent)=\"handleButtonClicked($event)\"\n      [type]=\"'search'\"\n    ></anghami-new-section-builder>\n  </ng-container>\n</div>\n"

/***/ }),

/***/ "./src/app/core/services/search.service.ts":
/*!*************************************************!*\
  !*** ./src/app/core/services/search.service.ts ***!
  \*************************************************/
/*! exports provided: SearchService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchService", function() { return SearchService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");







let SearchService = class SearchService {
    constructor(http, sectionService) {
        this.http = http;
        this.sectionService = sectionService;
        this.DEFAULT_SEARCH_ACTIVE_TAB = 'top';
    }
    performSearch(query, searchType = this.DEFAULT_SEARCH_ACTIVE_TAB, isEdgeSearch = 'false', page = '0', sectionid = null) {
        const musiclanguage = '1';
        const count = isEdgeSearch ? '' : '18';
        let body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETtabsearch')
            .set('output', 'jsonhp')
            .set('query', query)
            .set('edge', isEdgeSearch)
            .set('musiclanguage', musiclanguage)
            .set('searchtype', searchType)
            .set('page', page)
            .set('count', count);
        if (sectionid) {
            body = body.set('sectionid', sectionid);
        }
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getSearchConfig() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETsearchconfiguration')
            .set('output', 'jsonhp');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                let values = data.searchgroups.filter(section => section.searchgroup != 'userplaylist');
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(values);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getTags() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETdisplaytags');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getSearchSuggestions() {
        const body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETplaylistrecommendations')
            .set('output', 'jsonhp');
        return this.http
            .get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL}`, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(data => {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                const recentSearches = [];
                for (var i = 0; i < 10; i++) {
                    recentSearches.push(data[i]);
                }
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(recentSearches);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err)));
    }
    getEdgeSearchResults(searchPayload) {
        return this.performSearch(searchPayload.query, searchPayload.searchType, searchPayload.edge).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(searchResponse => {
            let enhancedSections = this.sectionService.enhanceSections(searchResponse);
            enhancedSections = enhancedSections.filter(section => section.group === 'tops');
            return enhancedSections[0].data.slice(0, 5);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(err => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err)));
    }
};
SearchService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
        _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_6__["SectionService"]])
], SearchService);



/***/ }),

/***/ "./src/app/modules/base/search/search-routing.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/modules/base/search/search-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: routes, SearchRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchRoutingModule", function() { return SearchRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _search_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.component */ "./src/app/modules/base/search/search.component.ts");




const routes = [
    {
        path: '',
        children: [{ path: '', component: _search_component__WEBPACK_IMPORTED_MODULE_3__["SearchComponent"] }]
    }
];
let SearchRoutingModule = class SearchRoutingModule {
};
SearchRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], SearchRoutingModule);



/***/ }),

/***/ "./src/app/modules/base/search/search.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/modules/base/search/search.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ::ng-deep a.profile {\n  padding: 1em !important;\n}\n:host .margin0 {\n  margin: 0 !important;\n}\n:host .search-tabs-container {\n  background-color: var(--light-white);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-line-pack: justify;\n      align-content: space-between;\n  padding: 0 !important;\n  margin-bottom: 0.5em;\n  border-radius: 3em;\n}\n:host .search-tabs-container .search-tabs-tab {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  text-align: center;\n  padding: 0.3em 0;\n}\n:host .search-tabs-container .search-tabs-tab a {\n  color: var(--text-color-light);\n  line-height: 2.7em;\n  text-decoration: none;\n  font-size: 1em;\n}\n:host .search-tabs-container .search-tabs-tab a:hover {\n  color: var(--active-tab);\n}\n:host .search-tabs-container .search-tabs-tab.selected {\n  border: none;\n  background-size: 100% 2px;\n}\n:host .search-tabs-container .search-tabs-tab.selected a {\n  color: var(--active-tab);\n  font-weight: bold;\n}"

/***/ }),

/***/ "./src/app/modules/base/search/search.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/modules/base/search/search.component.ts ***!
  \*********************************************************/
/*! exports provided: SearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchComponent", function() { return SearchComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _core_services_search_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/services/search.service */ "./src/app/core/services/search.service.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_redux_selectors_search_selector__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/selectors/search.selector */ "./src/app/core/redux/selectors/search.selector.ts");
/* harmony import */ var _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/search.actions */ "./src/app/core/redux/actions/search.actions.ts");











let SearchComponent = class SearchComponent {
    constructor(activeRoute, searchService, store, router, sectionService, _utilsService) {
        this.activeRoute = activeRoute;
        this.searchService = searchService;
        this.store = store;
        this.router = router;
        this.sectionService = sectionService;
        this._utilsService = _utilsService;
        this.hostClass = 'ang-view max-width-none';
        this.DEFAULT_SEARCH_ACTIVE_TAB = 'top';
        this._searchSource = new rxjs__WEBPACK_IMPORTED_MODULE_4__["ReplaySubject"]();
        this._searchTabsSource = new rxjs__WEBPACK_IMPORTED_MODULE_4__["ReplaySubject"]();
        this.lastSearchResponse = {
            sections: [],
            refreshgroups: []
        };
        this.searchPaginationPageCount = 0;
        this.moreLoadedData = [];
        this.searchReady = false;
        this.currentSearchSection$ = this._searchSource.asObservable();
        this.currentSearchTabs$ = this._searchTabsSource.asObservable();
        this.loading = false;
        this.collapsableClicked = new Map();
        this.moreClicked = new Map();
        let routeParams = this.activeRoute.snapshot.params;
        this.searchQuery = routeParams['query'];
        this.activeTab =
            routeParams['searchGroup'] || this.DEFAULT_SEARCH_ACTIVE_TAB;
        this.routeSub$ = this.router.events.subscribe(val => {
            if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationStart"]) {
                if (val.url.indexOf('search') === -1) {
                    return;
                }
                let newURLParameters = val.url.split('/');
                const newQuery = this._utilsService.decodeSearchQuery(newURLParameters[newURLParameters.length - 2]);
                const newSection = newURLParameters[newURLParameters.length - 1];
                if (this.searchQuery != newQuery) {
                    this.searchQuery = newQuery;
                    this.clearLastSearchResponse();
                    this.changeActiveSection(newSection);
                }
                if (this.activeTab != newSection) {
                    this.changeActiveSection(newSection);
                }
            }
        });
    }
    ngOnInit() {
        this.performSearch();
        this.handleNavigation();
        this.loadSearchConfiguration();
        this.searchOperationSubscription = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_search_selector__WEBPACK_IMPORTED_MODULE_9__["getSearchResults"]))
            .subscribe(response => {
            if (this.searchQuery === response.query &&
                response &&
                !this.moreClicked.get(this.activeTab)) {
                this.loading = false;
                const newResponse = Object.assign({}, response);
                this.appendSectionToSections(newResponse);
                this.updateRefreshGroups(newResponse);
                if (this.activeTab === 'song') {
                    this.isSearchActiveTabSong = true;
                    this.changeActiveSection(this.activeTab, true);
                }
                else {
                    this.changeActiveSection(this.activeTab);
                }
            }
            else if (this.searchQuery != response.query) {
                this.clearLastSearchResponse();
            }
        });
    }
    changeActiveSection(newSection, paginate = false) {
        this.activeTab = newSection;
        this.changeURL();
        this.isSearchActiveTabSong = this.activeTab === 'song';
        let filteredSectionList = this.getCurrentSection();
        if (filteredSectionList.length !== 0) {
            this.searchReady = true;
            this._searchSource.next(filteredSectionList);
        }
        else {
            this.performSectionSearch(newSection);
        }
        if (!paginate) {
            this.searchPaginationPageCount = 0;
        }
    }
    handleButtonClicked(sectionId) {
        if (!this.collapsableClicked.has(sectionId)) {
            this.moreClicked.set(this.activeTab, true);
            const decodedQuery = this._utilsService.decodeSearchQuery(this.searchQuery);
            this.searchPaginationPageCount += 1;
            this.searchService
                .performSearch(decodedQuery, this.activeTab, 'false', this.searchPaginationPageCount.toString(), sectionId)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
                .subscribe(resp => {
                this.loading = false;
                if (resp.sections &&
                    resp.sections.length > 0 &&
                    resp.sections[0].count > 0) {
                    this.addResponseToSection(resp);
                }
                else {
                    this.removeMoreButton(sectionId);
                }
                this._searchSource.next(this.getCurrentSection());
            });
        }
        else {
            this.handleSimilarClicked(sectionId);
            this._searchSource.next(this.getCurrentSection());
        }
    }
    handleSimilarClicked(sectionId) {
        var newSections = [];
        this.lastSearchResponse.sections.map(section => {
            if (section.sectionid == sectionId) {
                var isExpanded = this.collapsableClicked.get(sectionId);
                this.collapsableClicked.set(sectionId, !this.collapsableClicked.get(sectionId));
                newSections.push(Object.assign({}, section, { initialNumItems: isExpanded ? 1 : section.count, collapsableTitle: isExpanded
                        ? section.expandbutton
                        : section.collapsebutton }));
            }
            else {
                newSections.push(section);
            }
        });
        this.lastSearchResponse.sections = newSections;
    }
    appendSectionToSections(newResponse) {
        if (this.activeTab == 'top' &&
            !newResponse.sections.some(e => e.searchgroup === 'top') &&
            !this.lastSearchResponse.sections.some(e => e.searchgroup === 'top' && e.data.length > 0)) {
            this.lastSearchResponse = JSON.parse(JSON.stringify(this.loadEmptyTop(newResponse)));
        }
        else {
            if (this.lastSearchResponse.sections.length != 0) {
                newResponse.sections = this.updateSections(newResponse);
                this.lastSearchResponse = newResponse;
            }
            else {
                newResponse = JSON.parse(JSON.stringify(newResponse));
                newResponse.sections = this.handleExpandingSections(newResponse.sections);
                this.lastSearchResponse = newResponse;
            }
        }
    }
    addResponseToSection(resp) {
        const enhanced = this.sectionService.enhanceSections(resp);
        this.lastSearchResponse.sections = this.sectionService.checkAndMergeSections(this.lastSearchResponse.sections, enhanced);
    }
    updateSections(newResponse) {
        var sections = this.lastSearchResponse.sections;
        newResponse.sections.some(section => {
            let elementFound = sections.find(item => {
                return (item.searchgroup === section.searchgroup &&
                    item.sectionid === section.sectionid);
            });
            elementFound
                ? (sections[sections.indexOf(elementFound)] = section)
                : sections.push(section);
        });
        return this.handleExpandingSections(sections);
    }
    handleExpandingSections(sections) {
        sections.some(section => {
            if (section.collapsebutton) {
                if (!this.collapsableClicked.has(section.sectionid)) {
                    this.collapsableClicked.set(section.sectionid, false);
                }
                sections[sections.indexOf(section)] = Object.assign({}, section, { alltitle: null, collapsableTitle: !this.collapsableClicked.get(section.sectionid)
                        ? section.expandbutton
                        : section.collapsebutton, initialNumItems: !this.collapsableClicked.get(section.sectionid)
                        ? section.initialNumItems
                        : section.count });
            }
        });
        return sections;
    }
    performSearch() {
        const searchPayload = {
            query: this.searchQuery,
            edge: 0
        };
        if (!this.loading) {
            this.loading = true;
            this.store.dispatch(new _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_10__["Search"](searchPayload));
        }
    }
    performSectionSearch(newSection) {
        const searchPayload = {
            query: this.searchQuery,
            edge: 0,
            searchType: newSection
        };
        if (!this.loading) {
            this.loading = true;
            this.store.dispatch(new _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_10__["Search"](searchPayload));
        }
    }
    loadSearchConfiguration() {
        this.searchService
            .getSearchConfig()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(response => {
            this._searchTabsSource.next(response);
        });
    }
    changeURL() {
        const encodedQuery = this._utilsService.encodeSearchQuery(this.searchQuery);
        this.router.navigateByUrl(`/search/${encodedQuery}/${this.activeTab}`);
    }
    handlePlaylistMoreData(section) {
        if (section.searchgroup == 'playlist') {
            if (this.refreshGroups.indexOf('playlist') !== -1) {
                return 1;
            }
            return 0;
        }
        else if (this.refreshGroups.indexOf('playlist') !== -1 &&
            section.searchgroup == 'userplaylist') {
            return 1;
        }
    }
    removeMoreButton(sectionId) {
        this.lastSearchResponse.sections = this.lastSearchResponse.sections.map(section => {
            if (section.searchgroup === this.activeTab &&
                sectionId === section.sectionid) {
                return Object.assign({}, section, { moreData: 0 });
            }
            else if (this.activeTab == 'playlist' &&
                section.searchgroup == 'userplaylist') {
                return Object.assign({}, section, { moreData: 0 });
            }
            else {
                return section;
            }
        });
    }
    updateRefreshGroups(newResponse) {
        if (newResponse.refreshgroups.length != 0 && !this.refreshGroups) {
            this.refreshGroups = newResponse.refreshgroups;
        }
        this.lastSearchResponse.sections = this.lastSearchResponse.sections.map(section => {
            let moreData;
            if (section.searchgroup == 'playlist' ||
                section.searchgroup == 'userplaylist') {
                moreData = this.handlePlaylistMoreData(section);
            }
            else {
                moreData =
                    this.refreshGroups.indexOf(section.searchgroup) !== -1 &&
                        section.data.length > 0 &&
                        !section.collapsebutton
                        ? 1
                        : 0;
            }
            moreData === 1 && this.moreClicked.set(this.activeTab, false);
            return Object.assign({}, section, { moreData: moreData });
        });
    }
    getCurrentSection() {
        if (this.activeTab == 'playlist') {
            return this.getPlaylistFilteredSection();
        }
        else {
            return this.getFilteredSection();
        }
    }
    getFilteredSection(activeTab = this.activeTab) {
        return this.lastSearchResponse.sections.filter(section => section.searchgroup === activeTab);
    }
    getPlaylistFilteredSection() {
        let playlists = this.lastSearchResponse.sections.filter(section => section.searchgroup === 'playlist' ||
            (section.group == 'playlists' && section.text))[0];
        let userPlaylists = this.lastSearchResponse.sections.filter(section => section.searchgroup === 'userplaylist' ||
            (section.group == 'userplaylists' && section.text))[0];
        if (playlists) {
            if (playlists.data.length > 0) {
                playlists = Object.assign({}, playlists, { title: 'Playlists' });
            }
        }
        if (userPlaylists) {
            if (userPlaylists.data.length > 0) {
                userPlaylists = Object.assign({}, userPlaylists, { title: 'User playlists' });
            }
        }
        if (playlists && userPlaylists) {
            if (playlists.data.length == 0) {
                return [userPlaylists];
            }
            else if (userPlaylists.data.length == 0) {
                return [playlists];
            }
            else {
                return [playlists, userPlaylists];
            }
        }
        else if (userPlaylists) {
            return [userPlaylists];
        }
        else if (playlists) {
            return [playlists];
        }
        else {
            return [];
        }
    }
    ngOnDestroy() {
        if (this.navigationSubscription) {
            this.navigationSubscription.unsubscribe();
        }
        if (this.searchOperationSubscription) {
            this.searchOperationSubscription.unsubscribe();
        }
        if (this.routeSub$) {
            this.routeSub$.unsubscribe();
        }
    }
    handleNavigation() {
        this.navigationSubscription = this.router.events.subscribe((e) => {
            // If it is a NavigationEnd event re-initalise the params (search-query, active-tab etc..)
            if (e instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]) {
                const routeParams = this.activeRoute.snapshot.params;
                if (this.searchQuery != routeParams['query']) {
                    this.clearLastSearchResponse();
                    this.searchQuery = routeParams['query'];
                }
                this.activeTab =
                    routeParams['searchGroup'] || this.DEFAULT_SEARCH_ACTIVE_TAB;
            }
        });
    }
    clearLastSearchResponse() {
        this.moreClicked.clear();
        this.collapsableClicked.clear();
        this.lastSearchResponse = {
            sections: [],
            refreshgroups: []
        };
    }
    loadEmptyTop(newResponse) {
        var emptyTopSection = {
            type: 'text',
            group: 'tops',
            count: 0,
            text: '',
            bigtext: 1,
            centertext: 1,
            data: [],
            displaytype: 'bigrow',
            initialNumItems: 0,
            page: 0,
            searchgroup: 'top',
            sectionid: 1,
            textcolor: '787878'
        };
        var temp = JSON.parse(JSON.stringify(newResponse));
        temp.sections.push(emptyTopSection);
        return temp;
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], SearchComponent.prototype, "hostClass", void 0);
SearchComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-search',
        template: __webpack_require__(/*! raw-loader!./search.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/search/search.component.html"),
        styles: [__webpack_require__(/*! ./search.component.scss */ "./src/app/modules/base/search/search.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _core_services_search_service__WEBPACK_IMPORTED_MODULE_6__["SearchService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_7__["SectionService"],
        _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_8__["UtilService"]])
], SearchComponent);



/***/ }),

/***/ "./src/app/modules/base/search/search.module.ts":
/*!******************************************************!*\
  !*** ./src/app/modules/base/search/search.module.ts ***!
  \******************************************************/
/*! exports provided: SearchModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchModule", function() { return SearchModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _search_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.component */ "./src/app/modules/base/search/search.component.ts");
/* harmony import */ var _search_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./search-routing.module */ "./src/app/modules/base/search/search-routing.module.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");






let SearchModule = class SearchModule {
};
SearchModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _search_routing_module__WEBPACK_IMPORTED_MODULE_4__["SearchRoutingModule"], _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_5__["NewSectionBuilderModule"]],
        declarations: [_search_component__WEBPACK_IMPORTED_MODULE_3__["SearchComponent"]],
        exports: [_search_component__WEBPACK_IMPORTED_MODULE_3__["SearchComponent"]]
    })
], SearchModule);



/***/ })

}]);