(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["search-search-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/search/search.component.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/search/search.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ang-main search-component\">\n  <div class=\"row margin0\">\n    <div\n      class=\"col-md-12 search-tabs-container\"\n      *ngIf=\"(currentSearchTabs$ | async)?.length !== 0\"\n    >\n      <ng-container *ngFor=\"let item of (currentSearchTabs$ | async)\">\n        <div\n          class=\"search-tabs-tab\"\n          [ngClass]=\"{ selected: item.searchgroup === activeTab }\"\n        >\n          <a\n            href=\"javascript:void(0)\"\n            (click)=\"changeActiveSection(item.searchgroup)\"\n            >{{ item.title }}</a\n          >\n        </div>\n      </ng-container>\n    </div>\n  </div>\n\n  <ng-container *ngIf=\"searchReady\">\n    <anghami-new-section-builder\n      [sections]=\"currentSearchSection$ | async\"\n      [fromSearch]=\"true\"\n      [isSearchActiveTabSong]=\"isSearchActiveTabSong\"\n      (searchPaginationEvent)=\"handleButtonClicked($event)\"\n      [type]=\"'search'\"\n    ></anghami-new-section-builder>\n  </ng-container>\n</div>\n"

/***/ }),

/***/ "./src/app/core/services/search.service.ts":
/*!*************************************************!*\
  !*** ./src/app/core/services/search.service.ts ***!
  \*************************************************/
/*! exports provided: SearchService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchService", function() { return SearchService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");







var SearchService = /** @class */ (function () {
    function SearchService(http, sectionService) {
        this.http = http;
        this.sectionService = sectionService;
        this.DEFAULT_SEARCH_ACTIVE_TAB = 'top';
    }
    SearchService.prototype.performSearch = function (query, searchType, isEdgeSearch, page, sectionid) {
        if (searchType === void 0) { searchType = this.DEFAULT_SEARCH_ACTIVE_TAB; }
        if (isEdgeSearch === void 0) { isEdgeSearch = 'false'; }
        if (page === void 0) { page = '0'; }
        if (sectionid === void 0) { sectionid = null; }
        var musiclanguage = '1';
        var count = isEdgeSearch ? '' : '18';
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETtabsearch')
            .set('output', 'jsonhp')
            .set('query', query)
            .set('edge', isEdgeSearch)
            .set('musiclanguage', musiclanguage)
            .set('searchtype', searchType)
            .set('page', page)
            .set('count', count);
        if (sectionid) {
            body = body.set('sectionid', sectionid);
        }
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    SearchService.prototype.getSearchConfig = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETsearchconfiguration')
            .set('output', 'jsonhp');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                var values = data.searchgroups.filter(function (section) { return section.searchgroup != 'userplaylist'; });
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(values);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    SearchService.prototype.getTags = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETdisplaytags');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    SearchService.prototype.getSearchSuggestions = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('type', 'GETplaylistrecommendations')
            .set('output', 'jsonhp');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(data.error);
            }
            else {
                var recentSearches = [];
                for (var i = 0; i < 10; i++) {
                    recentSearches.push(data[i]);
                }
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(recentSearches);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    SearchService.prototype.getEdgeSearchResults = function (searchPayload) {
        var _this = this;
        return this.performSearch(searchPayload.query, searchPayload.searchType, searchPayload.edge).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (searchResponse) {
            var enhancedSections = _this.sectionService.enhanceSections(searchResponse);
            enhancedSections = enhancedSections.filter(function (section) { return section.group === 'tops'; });
            return enhancedSections[0].data.slice(0, 5);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(err); }));
    };
    SearchService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_6__["SectionService"]])
    ], SearchService);
    return SearchService;
}());



/***/ }),

/***/ "./src/app/modules/base/search/search-routing.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/modules/base/search/search-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: routes, SearchRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchRoutingModule", function() { return SearchRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _search_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.component */ "./src/app/modules/base/search/search.component.ts");




var routes = [
    {
        path: '',
        children: [{ path: '', component: _search_component__WEBPACK_IMPORTED_MODULE_3__["SearchComponent"] }]
    }
];
var SearchRoutingModule = /** @class */ (function () {
    function SearchRoutingModule() {
    }
    SearchRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], SearchRoutingModule);
    return SearchRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/base/search/search.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/modules/base/search/search.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ::ng-deep a.profile {\n  padding: 1em !important;\n}\n:host .margin0 {\n  margin: 0 !important;\n}\n:host .search-tabs-container {\n  background-color: var(--light-white);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-line-pack: justify;\n      align-content: space-between;\n  padding: 0 !important;\n  margin-bottom: 0.5em;\n  border-radius: 3em;\n}\n:host .search-tabs-container .search-tabs-tab {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  text-align: center;\n  padding: 0.3em 0;\n}\n:host .search-tabs-container .search-tabs-tab a {\n  color: var(--text-color-light);\n  line-height: 2.7em;\n  text-decoration: none;\n  font-size: 1em;\n}\n:host .search-tabs-container .search-tabs-tab a:hover {\n  color: var(--active-tab);\n}\n:host .search-tabs-container .search-tabs-tab.selected {\n  border: none;\n  background-size: 100% 2px;\n}\n:host .search-tabs-container .search-tabs-tab.selected a {\n  color: var(--active-tab);\n  font-weight: bold;\n}"

/***/ }),

/***/ "./src/app/modules/base/search/search.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/modules/base/search/search.component.ts ***!
  \*********************************************************/
/*! exports provided: SearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchComponent", function() { return SearchComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _core_services_search_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/services/search.service */ "./src/app/core/services/search.service.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var _anghami_redux_selectors_search_selector__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/selectors/search.selector */ "./src/app/core/redux/selectors/search.selector.ts");
/* harmony import */ var _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/actions/search.actions */ "./src/app/core/redux/actions/search.actions.ts");











var SearchComponent = /** @class */ (function () {
    function SearchComponent(activeRoute, searchService, store, router, sectionService, _utilsService) {
        var _this = this;
        this.activeRoute = activeRoute;
        this.searchService = searchService;
        this.store = store;
        this.router = router;
        this.sectionService = sectionService;
        this._utilsService = _utilsService;
        this.hostClass = 'ang-view max-width-none';
        this.DEFAULT_SEARCH_ACTIVE_TAB = 'top';
        this._searchSource = new rxjs__WEBPACK_IMPORTED_MODULE_4__["ReplaySubject"]();
        this._searchTabsSource = new rxjs__WEBPACK_IMPORTED_MODULE_4__["ReplaySubject"]();
        this.lastSearchResponse = {
            sections: [],
            refreshgroups: []
        };
        this.searchPaginationPageCount = 0;
        this.moreLoadedData = [];
        this.searchReady = false;
        this.currentSearchSection$ = this._searchSource.asObservable();
        this.currentSearchTabs$ = this._searchTabsSource.asObservable();
        this.loading = false;
        this.collapsableClicked = new Map();
        this.moreClicked = new Map();
        var routeParams = this.activeRoute.snapshot.params;
        this.searchQuery = routeParams['query'];
        this.activeTab =
            routeParams['searchGroup'] || this.DEFAULT_SEARCH_ACTIVE_TAB;
        this.routeSub$ = this.router.events.subscribe(function (val) {
            if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationStart"]) {
                if (val.url.indexOf('search') === -1) {
                    return;
                }
                var newURLParameters = val.url.split('/');
                var newQuery = _this._utilsService.decodeSearchQuery(newURLParameters[newURLParameters.length - 2]);
                var newSection = newURLParameters[newURLParameters.length - 1];
                if (_this.searchQuery != newQuery) {
                    _this.searchQuery = newQuery;
                    _this.clearLastSearchResponse();
                    _this.changeActiveSection(newSection);
                }
                if (_this.activeTab != newSection) {
                    _this.changeActiveSection(newSection);
                }
            }
        });
    }
    SearchComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.performSearch();
        this.handleNavigation();
        this.loadSearchConfiguration();
        this.searchOperationSubscription = this.store
            .pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["select"])(_anghami_redux_selectors_search_selector__WEBPACK_IMPORTED_MODULE_9__["getSearchResults"]))
            .subscribe(function (response) {
            if (_this.searchQuery === response.query &&
                response &&
                !_this.moreClicked.get(_this.activeTab)) {
                _this.loading = false;
                var newResponse = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, response);
                _this.appendSectionToSections(newResponse);
                _this.updateRefreshGroups(newResponse);
                if (_this.activeTab === 'song') {
                    _this.isSearchActiveTabSong = true;
                    _this.changeActiveSection(_this.activeTab, true);
                }
                else {
                    _this.changeActiveSection(_this.activeTab);
                }
            }
            else if (_this.searchQuery != response.query) {
                _this.clearLastSearchResponse();
            }
        });
    };
    SearchComponent.prototype.changeActiveSection = function (newSection, paginate) {
        if (paginate === void 0) { paginate = false; }
        this.activeTab = newSection;
        this.changeURL();
        this.isSearchActiveTabSong = this.activeTab === 'song';
        var filteredSectionList = this.getCurrentSection();
        if (filteredSectionList.length !== 0) {
            this.searchReady = true;
            this._searchSource.next(filteredSectionList);
        }
        else {
            this.performSectionSearch(newSection);
        }
        if (!paginate) {
            this.searchPaginationPageCount = 0;
        }
    };
    SearchComponent.prototype.handleButtonClicked = function (sectionId) {
        var _this = this;
        if (!this.collapsableClicked.has(sectionId)) {
            this.moreClicked.set(this.activeTab, true);
            var decodedQuery = this._utilsService.decodeSearchQuery(this.searchQuery);
            this.searchPaginationPageCount += 1;
            this.searchService
                .performSearch(decodedQuery, this.activeTab, 'false', this.searchPaginationPageCount.toString(), sectionId)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
                .subscribe(function (resp) {
                _this.loading = false;
                if (resp.sections &&
                    resp.sections.length > 0 &&
                    resp.sections[0].count > 0) {
                    _this.addResponseToSection(resp);
                }
                else {
                    _this.removeMoreButton(sectionId);
                }
                _this._searchSource.next(_this.getCurrentSection());
            });
        }
        else {
            this.handleSimilarClicked(sectionId);
            this._searchSource.next(this.getCurrentSection());
        }
    };
    SearchComponent.prototype.handleSimilarClicked = function (sectionId) {
        var _this = this;
        var newSections = [];
        this.lastSearchResponse.sections.map(function (section) {
            if (section.sectionid == sectionId) {
                var isExpanded = _this.collapsableClicked.get(sectionId);
                _this.collapsableClicked.set(sectionId, !_this.collapsableClicked.get(sectionId));
                newSections.push(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, section, { initialNumItems: isExpanded ? 1 : section.count, collapsableTitle: isExpanded
                        ? section.expandbutton
                        : section.collapsebutton }));
            }
            else {
                newSections.push(section);
            }
        });
        this.lastSearchResponse.sections = newSections;
    };
    SearchComponent.prototype.appendSectionToSections = function (newResponse) {
        if (this.activeTab == 'top' &&
            !newResponse.sections.some(function (e) { return e.searchgroup === 'top'; }) &&
            !this.lastSearchResponse.sections.some(function (e) { return e.searchgroup === 'top' && e.data.length > 0; })) {
            this.lastSearchResponse = JSON.parse(JSON.stringify(this.loadEmptyTop(newResponse)));
        }
        else {
            if (this.lastSearchResponse.sections.length != 0) {
                newResponse.sections = this.updateSections(newResponse);
                this.lastSearchResponse = newResponse;
            }
            else {
                newResponse = JSON.parse(JSON.stringify(newResponse));
                newResponse.sections = this.handleExpandingSections(newResponse.sections);
                this.lastSearchResponse = newResponse;
            }
        }
    };
    SearchComponent.prototype.addResponseToSection = function (resp) {
        var enhanced = this.sectionService.enhanceSections(resp);
        this.lastSearchResponse.sections = this.sectionService.checkAndMergeSections(this.lastSearchResponse.sections, enhanced);
    };
    SearchComponent.prototype.updateSections = function (newResponse) {
        var sections = this.lastSearchResponse.sections;
        newResponse.sections.some(function (section) {
            var elementFound = sections.find(function (item) {
                return (item.searchgroup === section.searchgroup &&
                    item.sectionid === section.sectionid);
            });
            elementFound
                ? (sections[sections.indexOf(elementFound)] = section)
                : sections.push(section);
        });
        return this.handleExpandingSections(sections);
    };
    SearchComponent.prototype.handleExpandingSections = function (sections) {
        var _this = this;
        sections.some(function (section) {
            if (section.collapsebutton) {
                if (!_this.collapsableClicked.has(section.sectionid)) {
                    _this.collapsableClicked.set(section.sectionid, false);
                }
                sections[sections.indexOf(section)] = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, section, { alltitle: null, collapsableTitle: !_this.collapsableClicked.get(section.sectionid)
                        ? section.expandbutton
                        : section.collapsebutton, initialNumItems: !_this.collapsableClicked.get(section.sectionid)
                        ? section.initialNumItems
                        : section.count });
            }
        });
        return sections;
    };
    SearchComponent.prototype.performSearch = function () {
        var searchPayload = {
            query: this.searchQuery,
            edge: 0
        };
        if (!this.loading) {
            this.loading = true;
            this.store.dispatch(new _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_10__["Search"](searchPayload));
        }
    };
    SearchComponent.prototype.performSectionSearch = function (newSection) {
        var searchPayload = {
            query: this.searchQuery,
            edge: 0,
            searchType: newSection
        };
        if (!this.loading) {
            this.loading = true;
            this.store.dispatch(new _anghami_redux_actions_search_actions__WEBPACK_IMPORTED_MODULE_10__["Search"](searchPayload));
        }
    };
    SearchComponent.prototype.loadSearchConfiguration = function () {
        var _this = this;
        this.searchService
            .getSearchConfig()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
            .subscribe(function (response) {
            _this._searchTabsSource.next(response);
        });
    };
    SearchComponent.prototype.changeURL = function () {
        var encodedQuery = this._utilsService.encodeSearchQuery(this.searchQuery);
        this.router.navigateByUrl("/search/" + encodedQuery + "/" + this.activeTab);
    };
    SearchComponent.prototype.handlePlaylistMoreData = function (section) {
        if (section.searchgroup == 'playlist') {
            if (this.refreshGroups.indexOf('playlist') !== -1) {
                return 1;
            }
            return 0;
        }
        else if (this.refreshGroups.indexOf('playlist') !== -1 &&
            section.searchgroup == 'userplaylist') {
            return 1;
        }
    };
    SearchComponent.prototype.removeMoreButton = function (sectionId) {
        var _this = this;
        this.lastSearchResponse.sections = this.lastSearchResponse.sections.map(function (section) {
            if (section.searchgroup === _this.activeTab &&
                sectionId === section.sectionid) {
                return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, section, { moreData: 0 });
            }
            else if (_this.activeTab == 'playlist' &&
                section.searchgroup == 'userplaylist') {
                return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, section, { moreData: 0 });
            }
            else {
                return section;
            }
        });
    };
    SearchComponent.prototype.updateRefreshGroups = function (newResponse) {
        var _this = this;
        if (newResponse.refreshgroups.length != 0 && !this.refreshGroups) {
            this.refreshGroups = newResponse.refreshgroups;
        }
        this.lastSearchResponse.sections = this.lastSearchResponse.sections.map(function (section) {
            var moreData;
            if (section.searchgroup == 'playlist' ||
                section.searchgroup == 'userplaylist') {
                moreData = _this.handlePlaylistMoreData(section);
            }
            else {
                moreData =
                    _this.refreshGroups.indexOf(section.searchgroup) !== -1 &&
                        section.data.length > 0 &&
                        !section.collapsebutton
                        ? 1
                        : 0;
            }
            moreData === 1 && _this.moreClicked.set(_this.activeTab, false);
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, section, { moreData: moreData });
        });
    };
    SearchComponent.prototype.getCurrentSection = function () {
        if (this.activeTab == 'playlist') {
            return this.getPlaylistFilteredSection();
        }
        else {
            return this.getFilteredSection();
        }
    };
    SearchComponent.prototype.getFilteredSection = function (activeTab) {
        if (activeTab === void 0) { activeTab = this.activeTab; }
        return this.lastSearchResponse.sections.filter(function (section) { return section.searchgroup === activeTab; });
    };
    SearchComponent.prototype.getPlaylistFilteredSection = function () {
        var playlists = this.lastSearchResponse.sections.filter(function (section) {
            return section.searchgroup === 'playlist' ||
                (section.group == 'playlists' && section.text);
        })[0];
        var userPlaylists = this.lastSearchResponse.sections.filter(function (section) {
            return section.searchgroup === 'userplaylist' ||
                (section.group == 'userplaylists' && section.text);
        })[0];
        if (playlists) {
            if (playlists.data.length > 0) {
                playlists = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, playlists, { title: 'Playlists' });
            }
        }
        if (userPlaylists) {
            if (userPlaylists.data.length > 0) {
                userPlaylists = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, userPlaylists, { title: 'User playlists' });
            }
        }
        if (playlists && userPlaylists) {
            if (playlists.data.length == 0) {
                return [userPlaylists];
            }
            else if (userPlaylists.data.length == 0) {
                return [playlists];
            }
            else {
                return [playlists, userPlaylists];
            }
        }
        else if (userPlaylists) {
            return [userPlaylists];
        }
        else if (playlists) {
            return [playlists];
        }
        else {
            return [];
        }
    };
    SearchComponent.prototype.ngOnDestroy = function () {
        if (this.navigationSubscription) {
            this.navigationSubscription.unsubscribe();
        }
        if (this.searchOperationSubscription) {
            this.searchOperationSubscription.unsubscribe();
        }
        if (this.routeSub$) {
            this.routeSub$.unsubscribe();
        }
    };
    SearchComponent.prototype.handleNavigation = function () {
        var _this = this;
        this.navigationSubscription = this.router.events.subscribe(function (e) {
            // If it is a NavigationEnd event re-initalise the params (search-query, active-tab etc..)
            if (e instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]) {
                var routeParams = _this.activeRoute.snapshot.params;
                if (_this.searchQuery != routeParams['query']) {
                    _this.clearLastSearchResponse();
                    _this.searchQuery = routeParams['query'];
                }
                _this.activeTab =
                    routeParams['searchGroup'] || _this.DEFAULT_SEARCH_ACTIVE_TAB;
            }
        });
    };
    SearchComponent.prototype.clearLastSearchResponse = function () {
        this.moreClicked.clear();
        this.collapsableClicked.clear();
        this.lastSearchResponse = {
            sections: [],
            refreshgroups: []
        };
    };
    SearchComponent.prototype.loadEmptyTop = function (newResponse) {
        var emptyTopSection = {
            type: 'text',
            group: 'tops',
            count: 0,
            text: '',
            bigtext: 1,
            centertext: 1,
            data: [],
            displaytype: 'bigrow',
            initialNumItems: 0,
            page: 0,
            searchgroup: 'top',
            sectionid: 1,
            textcolor: '787878'
        };
        var temp = JSON.parse(JSON.stringify(newResponse));
        temp.sections.push(emptyTopSection);
        return temp;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SearchComponent.prototype, "hostClass", void 0);
    SearchComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-search',
            template: __webpack_require__(/*! raw-loader!./search.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/search/search.component.html"),
            styles: [__webpack_require__(/*! ./search.component.scss */ "./src/app/modules/base/search/search.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _core_services_search_service__WEBPACK_IMPORTED_MODULE_6__["SearchService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_7__["SectionService"],
            _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_8__["UtilService"]])
    ], SearchComponent);
    return SearchComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/search/search.module.ts":
/*!******************************************************!*\
  !*** ./src/app/modules/base/search/search.module.ts ***!
  \******************************************************/
/*! exports provided: SearchModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchModule", function() { return SearchModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _search_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.component */ "./src/app/modules/base/search/search.component.ts");
/* harmony import */ var _search_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./search-routing.module */ "./src/app/modules/base/search/search-routing.module.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");






var SearchModule = /** @class */ (function () {
    function SearchModule() {
    }
    SearchModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _search_routing_module__WEBPACK_IMPORTED_MODULE_4__["SearchRoutingModule"], _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_5__["NewSectionBuilderModule"]],
            declarations: [_search_component__WEBPACK_IMPORTED_MODULE_3__["SearchComponent"]],
            exports: [_search_component__WEBPACK_IMPORTED_MODULE_3__["SearchComponent"]]
        })
    ], SearchModule);
    return SearchModule;
}());



/***/ })

}]);