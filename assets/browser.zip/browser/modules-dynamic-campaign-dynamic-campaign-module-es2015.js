(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modules-dynamic-campaign-dynamic-campaign-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/dynamic-campaign/dynamic-campaign.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/dynamic-campaign/dynamic-campaign.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"campaign-container\">\n  <div class=\"campaign-header\">\n    <!-- <div class=\"campaign-header-background\">\n      <img [src]=\"env + 'Web-Header.jpg'\" />\n    </div> -->\n    <div class=\"campaign-header-top\">\n      <img class=\"anghami-logo\" [src]=\"env + 'anghami-official-white@2x.png'\" />\n      <img\n        class=\"coldplay-badge d-none .d-sm-none d-md-block d-lg-block\"\n        [src]=\"env + 'Image-165@2x.png'\"\n      />\n    </div>\n    <div class=\"container\">\n      <div class=\"campaign-header-content\" *ngIf=\"title\">\n        <h1 class=\"section_title\">\n          {{ title }}\n        </h1>\n        <div class=\"campaign-header-subtitle\">\n          {{ subtitle }}\n        </div>\n        <div class=\"campaign-btn-container\">\n          <button class=\"campaign-btn playfair\" (click)=\"handlePlanButtonClick()\">{{ button_text }}</button>\n        </div>\n      </div>\n    </div>\n    <div class=\"mobile_badge\">\n      <img\n        class=\"coldplay-badge d-block  d-md-none d-lg-none\"\n        [src]=\"env + 'Image-165@2x.png'\"\n      />\n    </div>\n  </div>\n  <div class=\"campaign-details\">\n    <div class=\"container\">\n      <div class=\"row\">\n        <div class=\"col-lg-6 col-md-4 col-sm-12\">\n          <div class=\"description\">\n            <div\n              class=\"section_title text-left\"\n              i18n=\"@@coldplay_jordan_landing_concert\"\n            >\n              The Concert\n            </div>\n            <div class=\"text-left\" i18n=\"@@coldplay_jordan_landing_description\">\n              Everyday Life – Live in Jordan will take place in Amman, Jordan\n              and mirror the two halves of the 52-minute double album: Sunrise\n              and Sunset. The Sunrise concert will begin at 4am GMT, with the\n              Sunset concert following at 2pm GMT. These will mark the band’s\n              first ever performances in Jordan.\n            </div>\n          </div>\n        </div>\n        <div class=\"col-lg-6 col-md-8 col-sm-12\">\n          <div class=\"d-flex\">\n            <div\n              class=\"concert-detail\"\n              [ngStyle]=\"{\n                'background-image': 'url(' + env + 'frame_2@2x.png' + ')'\n              }\"\n            >\n              <img class=\"sun-moon\" [src]=\"env + 'sun-moon.png'\" />\n              <div class=\"detail-big playfair\">\n                <!-- <ng-container i18n=\"@@coldplay_jordan_landing_nov24\"\n                  >NOV 24\n                </ng-container> -->\n                <!-- <br /> -->\n                <ng-container i18n=\"@@coldplay_jordan_landing_nov24\"\n                  >NOV 23\n                </ng-container>\n              </div>\n              <!-- <div class=\"detail-small\">Sunrise Concert</div>\n      <div class=\"detail-small\">Sunset Concert</div> -->\n            </div>\n            \n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div\n    class=\"campaign-songs\"\n    [ngStyle]=\"{\n      'background-image': 'url(' + env + 'Pattern-bg@2x.jpg' + ')'\n    }\"\n  >\n    <div class=\"container\">\n      <div class=\"section_title\" i18n=\"@@coldplay_jordan_landing_listen\">\n        Warm up on Anghami\n      </div>\n      <div class=\"row\">\n        <div class=\"songs-container\">\n          <div class=\"song\">\n            <a\n              class=\"song-coverart\"\n              href=\"https://play.anghami.com/song/60469945\"\n              [ngStyle]=\"{\n                'background-image':\n                  'url(https://angartwork.akamaized.net/?id=104286391&size=640)'\n              }\"\n            ></a>\n            <a\n              class=\"song-title\"\n              target=\"_blank\"\n              href=\"https://play.anghami.com/song/60469945\"\n              >Orphans</a\n            >\n            <a\n              class=\"song-artist\"\n              target=\"_blank\"\n              href=\"https://play.anghami.com/artist/4757\"\n              >Coldplay</a\n            >\n          </div>\n          <div class=\"song\">\n            <a\n              class=\"song-coverart\"\n              href=\"https://play.anghami.com/song/60469953\"\n              [ngStyle]=\"{\n                'background-image':\n                  'url(https://angartwork.akamaized.net/?id=104056079&size=640)'\n              }\"\n            ></a>\n            <a\n              class=\"song-title\"\n              target=\"_blank\"\n              href=\"https://play.anghami.com/song/60469953\"\n              >Arabesque</a\n            >\n            <a\n              class=\"song-artist\"\n              target=\"_blank\"\n              href=\"https://play.anghami.com/artist/4757\"\n              >Coldplay</a\n            >\n          </div>\n          <div class=\"song\">\n            <a\n              class=\"song-coverart\"\n              href=\"https://play.anghami.com/video/60469953\"\n              [ngStyle]=\"{\n                'background-image':\n                  'url(https://angartwork.akamaized.net/?id=105410665&size=640)'\n              }\"\n            ></a>\n            <a\n              class=\"song-title\"\n              target=\"_blank\"\n              href=\"https://play.anghami.com/video/60469953\"\n              >Everyday Life</a\n            >\n            <a\n              class=\"song-artist\"\n              target=\"_blank\"\n              href=\"https://play.anghami.com/artist/4757\"\n              >Coldplay</a\n            >\n          </div>\n        </div>\n      </div>\n      <div class=\"row\">\n        <div class=\"campaign-btn-container\">\n          <a\n            class=\"campaign-btn detail-big playfair black\"\n            target=\"_blank\"\n            href=\"https://play.anghami.com/artist/4757\"\n            i18n=\"@@coldplay_jordan_landing_artist\"\n          >\n            More from Coldplay\n          </a>\n        </div>\n      </div>\n    </div>\n    <div\n      class=\"campaign-subscribe\"\n      [ngStyle]=\"{\n        'background-image': 'url(' + env + 'gold_bg.jpg' + ')'\n      }\"\n    >\n      <div class=\"campaign-header-content\" *ngIf=\"title\">\n        <div class=\"section_title playfair\">\n          {{ title }}\n        </div>\n        <div class=\"campaign-btn-container\">\n          <button class=\"campaign-btn detail-big playfair black\" (click)=\"handlePlanButtonClick()\">\n           {{ button_text }}\n          </button>\n        </div>\n      </div>\n    </div>\n    <footer>\n      <strong>Terms & Condition Apply</strong>\n      <strong>All Rights Reserved</strong>\n    </footer>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/core/services/sub-operators.service.ts":
/*!********************************************************!*\
  !*** ./src/app/core/services/sub-operators.service.ts ***!
  \********************************************************/
/*! exports provided: SubOperatorsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubOperatorsService", function() { return SubOperatorsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/utils.service */ "./src/app/core/services/utils.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/redux/actions/operators.actions */ "./src/app/core/redux/actions/operators.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm2015/effects.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");









let SubOperatorsService = class SubOperatorsService {
    constructor(_utilsService, _actionSubject, _store, platformId) {
        this._utilsService = _utilsService;
        this._actionSubject = _actionSubject;
        this._store = _store;
        this.platformId = platformId;
        this.msidnValidations = {};
        this.clearResultMessage();
    }
    clearResultMessage() {
        this.resultmsg = '';
    }
    getOperatorPlan(opdetails, isActivation) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_8__["isPlatformServer"])(this.platformId)) {
            return;
        }
        if (opdetails && opdetails !== null && Object.keys(opdetails).length > 0) {
            let appSidFromUrl = this._utilsService.getQueryFromUrl('appsid')
                || this._utilsService.getQueryFromUrl('sid');
            let params = {
                type: 'GEToperatorplan',
                output: 'jsonhp'
            };
            if (isActivation) {
                params['activation'] = opdetails.type;
            }
            else {
                params = Object.assign(params, opdetails);
            }
            if (appSidFromUrl) {
                params['appsid'] = appSidFromUrl;
            }
            const result = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["race"])(this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["OperatorsActionTypes"].GETOperatorSuccess), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(res => {
                return {
                    res: res.payload
                };
            })), this._actionSubject
                .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_6__["ofType"])(_anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["OperatorsActionTypes"].GETOperatorError), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(res => {
                return {
                    res: res.payload
                };
            })));
            this._store.dispatch(new _anghami_redux_actions_operators_actions__WEBPACK_IMPORTED_MODULE_5__["GETOperator"](params));
            return result;
        }
    }
    autofillPhoneNumber(msidn) {
        let mobilenum = '';
        if (msidn && msidn != null && msidn !== '') {
            const msidncode = msidn.substring(0, 3);
            if (msidncode === this.msidnValidations['countrycode']) {
                mobilenum = msidn.replace(/^.{3}/g, '');
            }
        }
        return mobilenum;
    }
    checkOperatorValidationsExist(plan) {
        if (plan.min_digits && plan.min_digits !== null && plan.min_digits !== ''
            && plan.max_digits && plan.max_digits !== null && plan.max_digits !== ''
            && plan.country_code && plan.country_code !== null && plan.country_code !== '') {
            return true;
        }
        return false;
    }
    setMsidnDetails(plan) {
        let validations = {};
        if (this.checkOperatorValidationsExist(plan)) {
            validations = {
                min_digits: plan.min_digits,
                max_digits: plan.max_digits,
                countrycode: plan.country_code
            };
        }
        return validations;
    }
};
SubOperatorsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["ActionsSubject"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"],
        Object])
], SubOperatorsService);



/***/ }),

/***/ "./src/app/modules/dynamic-campaign/dynamic-campaign-routing.module.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/modules/dynamic-campaign/dynamic-campaign-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: routes, DynamicCampaignRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DynamicCampaignRoutingModule", function() { return DynamicCampaignRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _dynamic_campaign_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dynamic-campaign.component */ "./src/app/modules/dynamic-campaign/dynamic-campaign.component.ts");




const routes = [
    {
        path: '',
        component: _dynamic_campaign_component__WEBPACK_IMPORTED_MODULE_3__["DynamicCampaignComponent"]
    }
];
let DynamicCampaignRoutingModule = class DynamicCampaignRoutingModule {
};
DynamicCampaignRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], DynamicCampaignRoutingModule);



/***/ }),

/***/ "./src/app/modules/dynamic-campaign/dynamic-campaign.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/modules/dynamic-campaign/dynamic-campaign.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@import \"https://fonts.google.com/specimen/Playfair+Display\";\n:host body {\n  background-color: #fff;\n}\n.section_title {\n  font-size: 2rem;\n  font-weight: bold;\n  text-align: center;\n  max-width: 46rem;\n  line-height: 2.7rem;\n  font-family: \"Playfair Display\", serif;\n  font-weight: bold;\n  margin: auto;\n}\n@media (max-width: 768px) {\n  .section_title {\n    font-size: 1.5rem;\n    line-height: normal;\n    text-align: left;\n  }\n}\n.container {\n  max-width: 1024px;\n}\n.playfair {\n  font-family: \"Playfair Display\", serif;\n  font-weight: bold;\n}\n.campaign-container {\n  text-align: center;\n}\n.campaign-btn-container {\n  display: block;\n  width: 100%;\n  padding: 1rem;\n  text-align: center;\n}\n.campaign-btn {\n  background: #FFD805 0% 0% no-repeat padding-box;\n  border: 1px solid #FFD805;\n  box-shadow: 0px 3px 6px #00000029;\n  border-radius: 44px;\n  margin: 1.5rem auto;\n  padding: 0.5rem 2rem;\n  font-size: 1.2rem;\n  font-weight: bold;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n  text-decoration: none;\n  display: inline-block;\n}\n.campaign-btn:hover {\n  background: #000;\n  color: #FFD805;\n}\n.campaign-btn:active {\n  border: 1px solid #000;\n  background: #FFD805 0% 0% no-repeat padding-box;\n  color: #000;\n}\n.campaign-btn.black {\n  background: #000 0% 0% no-repeat padding-box;\n  border: 1px solid #000;\n  color: #FFF;\n}\n.campaign-btn.black:hover {\n  background: #FFD805;\n  color: #000;\n}\n.campaign-btn.black:active {\n  border: 1px solid #FFD805;\n  background: #FFD805;\n  color: #000;\n}\n.campaign-container .campaign-header {\n  background-image: url('Banner-Web@2x.jpg');\n  background-position: center bottom;\n  background-repeat: no-repeat;\n  background-size: cover;\n  position: relative;\n}\n@media (max-width: 480px) {\n  .campaign-container .campaign-header {\n    background-image: url('Banner-Mobile@2x.jpg');\n  }\n}\n.campaign-container .campaign-header .section_title,\n.campaign-container .campaign-header .campaign-header-subtitle {\n  color: #FFF;\n}\n.campaign-container .campaign-header .mobile_badge {\n  position: absolute;\n  bottom: -2em;\n  left: 50%;\n  margin-left: -6em;\n}\n.campaign-container .campaign-header .mobile_badge img {\n  width: 12em;\n}\n.campaign-container .campaign-header-background {\n  width: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: -1;\n  max-height: 31rem;\n  overflow: hidden;\n}\n.campaign-container .campaign-header-background img {\n  width: 100%;\n}\n.campaign-container .campaign-header-top {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  padding: 2rem 1rem;\n}\n@media (max-width: 768px) {\n  .campaign-container .campaign-header-top {\n    padding: 1rem;\n  }\n}\n.campaign-container .campaign-header-top .anghami-logo {\n  width: 14rem;\n  -ms-flex-item-align: start;\n      align-self: flex-start;\n}\n@media (max-width: 768px) {\n  .campaign-container .campaign-header-top .anghami-logo {\n    width: 10em;\n  }\n}\n.campaign-container .campaign-header-top .coldplay-badge {\n  width: 14rem;\n  -ms-flex-item-align: start;\n      align-self: flex-start;\n}\n.campaign-container .campaign-header-content {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding: 2rem;\n}\n.campaign-container .campaign-header-content .campaign-header-subtitle {\n  font-size: 1rem;\n  text-align: center;\n  max-width: 30rem;\n  margin-top: 0.5rem;\n}\n@media (max-width: 768px) {\n  .campaign-container .campaign-header-content .campaign-header-subtitle {\n    font-size: 0.9rem;\n    text-align: left;\n  }\n}\n.campaign-container .campaign-header-content .campaign-header-btn-container {\n  text-align: center;\n}\n.campaign-container .campaign-details {\n  background: #fff;\n  padding-top: 2rem;\n  padding-bottom: 3rem;\n}\n.campaign-container .campaign-details .description {\n  max-width: 20rem;\n}\n.campaign-container .campaign-details .description .description-title {\n  font-size: 3rem;\n  font-weight: bold;\n}\n.campaign-container .campaign-details .concert-detail {\n  background-size: 100%;\n  background-repeat: no-repeat;\n  width: 20rem;\n  height: 15rem;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding-top: 3rem;\n  margin: 0.5rem;\n}\n.campaign-container .campaign-details .concert-detail .sun-moon {\n  width: 4rem;\n}\n.campaign-container .campaign-details .concert-detail .location {\n  width: 1.5rem;\n}\n.campaign-container .campaign-details .concert-detail .detail-big {\n  font-size: 1.5rem;\n  margin-top: 1rem;\n}\n.campaign-container .campaign-songs {\n  padding-top: 3rem;\n}\n.campaign-container .campaign-songs .campaign-songs-title {\n  font-size: 3rem;\n  font-weight: bold;\n}\n.campaign-container .campaign-songs .songs-container {\n  margin-top: 1rem;\n  width: 100%;\n  padding: 0 1rem;\n  white-space: nowrap;\n  overflow: auto;\n}\n.campaign-container .campaign-songs .song {\n  margin: 0.5rem;\n  text-align: left;\n  display: inline-block;\n  vertical-align: top;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n}\n.campaign-container .campaign-songs .song:hover {\n  opacity: 0.8;\n}\n.campaign-container .campaign-songs .song .song-coverart {\n  width: 17rem;\n  height: 10rem;\n  border-radius: 0.8em;\n  background-color: black;\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: cover;\n  display: block;\n}\n.campaign-container .campaign-songs .song .song-title {\n  font-size: 1.3rem;\n  font-weight: bold;\n  color: #000;\n  display: block;\n  text-align: left;\n}\n.campaign-container .campaign-songs .song .song-artist {\n  font-size: 0.8rem;\n  color: #000;\n  display: block;\n  text-align: left;\n}\nfooter {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  padding: 2rem;\n  background: #FFF;\n}"

/***/ }),

/***/ "./src/app/modules/dynamic-campaign/dynamic-campaign.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/modules/dynamic-campaign/dynamic-campaign.component.ts ***!
  \************************************************************************/
/*! exports provided: DynamicCampaignComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DynamicCampaignComponent", function() { return DynamicCampaignComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/deeplinks.service */ "./src/app/core/services/deeplinks.service.ts");
/* harmony import */ var _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../core/enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm2015/store.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/selectors/auth.selector */ "./src/app/core/redux/selectors/auth.selector.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/services/sub-operators.service */ "./src/app/core/services/sub-operators.service.ts");












let DynamicCampaignComponent = class DynamicCampaignComponent {
    constructor(_operatorsService, _deeplinksService, store, platformId) {
        this._operatorsService = _operatorsService;
        this._deeplinksService = _deeplinksService;
        this.store = store;
        this.platformId = platformId;
        this.env = `${_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].assetsCDN}img/coldplay/`;
        this.userData$ = this.store.pipe(Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["select"])(_anghami_redux_selectors_auth_selector__WEBPACK_IMPORTED_MODULE_8__["getUser"]));
    }
    ngOnInit() {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_9__["isPlatformBrowser"])(this.platformId)) {
            this._operatorsService
                .getOperatorPlan({ type: 'coldplay_2019' }, true)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["withLatestFrom"])(this.userData$), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1))
                .subscribe((res) => {
                const response = res[0];
                if (response && response.res && response.res.data) {
                    const data = response.res.data;
                    this.title = data.plan.title;
                    this.subtitle = data.plan.subtitle;
                    this.button_text = data.plan.button_text;
                    this.button_redirect_url = data.plan.button_redirect_url;
                    this.button_background_url = data.plan.button_background_url;
                }
            });
        }
        else {
            this._operatorsService
                .getOperatorPlan({ type: 'coldplay_2019' }, true)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1))
                .subscribe((response) => {
                if (response && response.res && response.res.data) {
                    const data = response.res.data;
                    this.title = data.plan.title;
                    this.subtitle = data.plan.subtitle;
                    this.button_text = data.plan.button_text;
                    this.button_redirect_url = data.plan.button_redirect_url;
                    this.button_background_url = data.plan.button_background_url;
                }
            });
        }
    }
    handlePlanButtonClick() {
        if (this.button_redirect_url.indexOf('login') > -1) {
            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_7__["OpenCustomDialog"]({
                type: _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_5__["DIALOG_TYPES"].LOGIN
            }));
            return;
        }
        if (this.button_background_url) {
            const url = this.button_background_url.replace('/v1', '');
            this._deeplinksService
                .handleDeeplink(url)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1))
                .subscribe(data => {
                window.location.href = this.button_redirect_url
                    ? this.button_redirect_url
                    : window.location.href;
            });
        }
        else {
            window.location.href = this.button_redirect_url
                ? this.button_redirect_url
                : window.location.href;
        }
    }
};
DynamicCampaignComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'anghami-dynamic-campaign',
        template: __webpack_require__(/*! raw-loader!./dynamic-campaign.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/dynamic-campaign/dynamic-campaign.component.html"),
        styles: [__webpack_require__(/*! ./dynamic-campaign.component.scss */ "./src/app/modules/dynamic-campaign/dynamic-campaign.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_anghami_services_sub_operators_service__WEBPACK_IMPORTED_MODULE_10__["SubOperatorsService"],
        _anghami_services_deeplinks_service__WEBPACK_IMPORTED_MODULE_4__["DeeplinksService"],
        _ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"],
        Object])
], DynamicCampaignComponent);



/***/ }),

/***/ "./src/app/modules/dynamic-campaign/dynamic-campaign.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/modules/dynamic-campaign/dynamic-campaign.module.ts ***!
  \*********************************************************************/
/*! exports provided: DynamicCampaignModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DynamicCampaignModule", function() { return DynamicCampaignModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _dynamic_campaign_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dynamic-campaign.component */ "./src/app/modules/dynamic-campaign/dynamic-campaign.component.ts");
/* harmony import */ var _dynamic_campaign_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./dynamic-campaign-routing.module */ "./src/app/modules/dynamic-campaign/dynamic-campaign-routing.module.ts");





let DynamicCampaignModule = class DynamicCampaignModule {
};
DynamicCampaignModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_dynamic_campaign_component__WEBPACK_IMPORTED_MODULE_3__["DynamicCampaignComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _dynamic_campaign_routing_module__WEBPACK_IMPORTED_MODULE_4__["DynamicCampaignRoutingModule"]
        ]
    })
], DynamicCampaignModule);



/***/ })

}]);