(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["advertise-advertise-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/advertise/advertise.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/advertise/advertise.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"advertise-wrapper\">\n  <div class=\"header-banner\">\n    <div class=\"content\" #headerContent>\n      <h1 class=\"title\">\n        <ng-container i18n=\"@@advertise_universe_experience_title\"\n          >A UNIVERSE OF EXPERIENCES</ng-container\n        >\n      </h1>\n      <h4 class=\"sub-title\" i18n=\"@@advertise_universe_experience_subtitle\">\n        Let’s take your brand places\n      </h4>\n    </div>\n  </div>\n\n  <section class=\"full-row-layout relative\">\n    <div class=\"container\">\n      <div class=\"row flippable\">\n        <div class=\"column secondary\">\n          <div class=\"numbers-card-col\">\n            <div class=\"numbers-card c1\">\n              <div class=\"number\">73M+</div>\n              <p i18n=\"@@advertise_num_users\">Registered Users worldwide</p>\n            </div>\n            <div class=\"numbers-card c3\">\n              <div class=\"number\">2M+</div>\n              <p i18n=\"@@advertise_num_artists\">\n                Arabic and International Artists\n              </p>\n            </div>\n          </div>\n          <div class=\"numbers-card-col\">\n            <div class=\"numbers-card c2\">\n              <div class=\"number\">30M+</div>\n              <p i18n=\"@@advertise_num_songs\">Arabic and International Songs</p>\n            </div>\n            <div class=\"numbers-card c4\">\n              <div class=\"number\">1B+</div>\n              <p i18n=\"@@advertise_num_streams\">Streams per month</p>\n            </div>\n          </div>\n        </div>\n        <div class=\"column primary\">\n          <div class=\"onsided-title\">\n            <h2 i18n=\"@@advertise_why_anghami_title\">Why Anghami?</h2>\n            <p i18n=\"@@advertise_why_anghamisubtitle\">\n              Anghami is your brand’s gateway to a world of music & technology\n              throughout the day and across all devices.\n            </p>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"container-fluid regions-container\">\n      <div class=\"gradient-wave\">\n        <img src=\"../../../../../assets/img/advertise/test.png\" />\n      </div>\n      <div class=\"row\">\n        <div class=\"region\">\n          <img src=\"../../../assets/img/advertise/maps/gcc@2x.png\" />\n          <div class=\"label\">\n            <h4>29%</h4>\n            <span i18n=\"@@advertise_gcc\">GCC</span>\n          </div>\n        </div>\n        <div class=\"region\">\n          <img src=\"../../../assets/img/advertise/maps/levant@2x.png\" />\n          <div class=\"label\">\n            <h4>21%</h4>\n            <span i18n=\"@@advertise_levant\">Levant</span>\n          </div>\n        </div>\n        <div class=\"region\">\n          <img src=\"../../../assets/img/advertise/maps/north-africa@2x.png\" />\n          <div class=\"label\">\n            <h4>42%</h4>\n            <span i18n=\"@@advertise_north_africa\">North Africa</span>\n          </div>\n        </div>\n        <div class=\"region\">\n          <img src=\"../../../assets/img/advertise/maps/row@2x.png\" />\n          <div class=\"label\">\n            <h4>8%</h4>\n            <span i18n=\"@@advertise_row\">Row</span>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>\n\n  <section class=\"full-row-layout\">\n    <div class=\"text-center\">\n      <h2 i18n=\"@@advertise_data_points\" class=\"forcewidth\">\n        10,221,429,925 DATA POINTS GATHERED EACH MONTH\n      </h2>\n      <!-- <p>Allowing us to reach the right user at the right time</p> -->\n    </div>\n    <div class=\"graph-bars-outer\">\n      <img src=\"../../../../assets/img/advertise/datachart.png\" />\n      <!-- <ul class=\"graph-bars\">\n        <ng-container *ngFor=\"let in of counter(10); let i = index\">\n          <li class=\"sm\"></li>\n          <li class=\"md\"></li>\n          <li class=\"lg\"></li>\n          <li class=\"xl\">\n            <div class=\"details top\" *ngIf=\"i == 0\">\n              <img\n                src=\"../../../assets/img/advertise/datapoints/1.png\"\n                width=\"50\"\n              />\n              <div class=\"data\">\n                <strong>First Heartbreak</strong>\n                <div><small>Mar 2013</small></div>\n              </div>\n            </div>\n            <div class=\"details top\" *ngIf=\"i == 2\">\n              <img\n                src=\"../../../assets/img/advertise/datapoints/2.png\"\n                width=\"50\"\n              />\n              <div class=\"data\">\n                <strong>Ran 20KM</strong>\n                <div><small>JUN 2014</small></div>\n              </div>\n            </div>\n            <div class=\"details bottom\" *ngIf=\"i == 4\">\n              <img\n                src=\"../../../assets/img/advertise/datapoints/3.png\"\n                width=\"20\"\n              />\n              <div class=\"data\">\n                <strong>Partied All Night</strong>\n                <div><small>JAN 2015</small></div>\n              </div>\n            </div>\n            <div class=\"details top\" *ngIf=\"i == 5\">\n              <img\n                src=\"../../../assets/img/advertise/datapoints/4.png\"\n                width=\"50\"\n              />\n              <div class=\"data\">\n                <strong>Traveled To Peru</strong>\n                <div><small>Feb 2016</small></div>\n              </div>\n            </div>\n            <div class=\"details bottom\" *ngIf=\"i == 7\">\n              <img\n                src=\"../../../assets/img/advertise/datapoints/5.png\"\n                width=\"50\"\n              />\n              <div class=\"data\">\n                <strong>Got A New Phone</strong>\n                <div><small>JUL 2017</small></div>\n              </div>\n            </div>\n          </li>\n          <li class=\"lg\"></li>\n          <li class=\"md\"></li>\n          <li class=\"sm\"></li>\n        </ng-container>\n      </ul> -->\n    </div>\n    <img\n      class=\"day-to-night\"\n      src=\"../../../../assets/img/advertise/daytonight.png\"\n    />\n  </section>\n\n  <section class=\"full-row-layout\">\n    <div class=\"text-center\">\n      <h2>WHAT WE DO</h2>\n    </div>\n    <div class=\"container\">\n      <div class=\"anghami-rounded-tabs\">\n        <ul>\n          <li\n            class=\"selected\"\n            (click)=\"switchTabs(1)\"\n            [ngClass]=\"{ selected: selectedTab === 1 }\"\n            i18n=\"@@advertise_media_solution\"\n          >\n            Media Solutions\n          </li>\n          <li\n            (click)=\"switchTabs(2)\"\n            [ngClass]=\"{ selected: selectedTab === 2 }\"\n            i18n=\"@@advertise_content_solution\"\n          >\n            Content Solutions\n          </li>\n          <li\n            (click)=\"switchTabs(3)\"\n            [ngClass]=\"{ selected: selectedTab === 3 }\"\n            i18n=\"@@advertise_technology_solutions\"\n          >\n            Technology Solutions\n          </li>\n        </ul>\n      </div>\n\n      <ng-container *ngIf=\"selectedTab == 3\">\n        <div class=\"row\">\n          <div class=\"offset-lg-2 col-lg-4 col-sm-12 solution-item\">\n            <img [src]=\"env + 'customized-solutions.png'\" />\n            <h5 i18n=\"@@advertise_customized_solutions_title\">\n              CUSTOMIZED SOLUTIONS\n            </h5>\n            <p i18n=\"@@advertise_customized_solutions_subtitle\">\n              Embark users on a fully customized branded experience.\n            </p>\n          </div>\n          <div class=\"col-lg-4 col-sm-12 solution-item\">\n            <img [src]=\"env + 'object-scanning.png'\" />\n            <h5 i18n=\"@@advertise_object_scanning_title\">OBJECT SCANNING</h5>\n            <p i18n=\"@@advertise_object_scanning_subtitle\">\n              Link offline to online. Users will scan an object to unlock your\n              branded experiences.\n            </p>\n          </div>\n        </div>\n      </ng-container>\n\n      <ng-container *ngIf=\"selectedTab == 2\">\n        <div class=\"row\">\n          <div class=\"offset-lg-2 col-lg-4 col-sm-12 solution-item\">\n            <img [src]=\"env + 'content-sponsorship.png'\" />\n            <h5 i18n=\"@@advertise_content_sponsorship_title\">\n              CONTENT SPONSORSHIP\n            </h5>\n            <p i18n=\"@@advertise_content_sponsorship_subtitle\">\n              Join users in their very own world by sponsoring their favorite\n              music.\n            </p>\n          </div>\n          <div class=\"col-lg-4 col-sm-12 solution-item\">\n            <img [src]=\"env + 'content-creation.png'\" />\n            <h5 i18n=\"@@advertise_content_creation_title\">CONTENT CREATION</h5>\n            <p i18n=\"@@advertise_content_creation_subtitle\">\n              Boost the sound of your brand by creating your own musical\n              content.\n            </p>\n          </div>\n        </div>\n      </ng-container>\n\n      <ng-container *ngIf=\"selectedTab == 1\">\n        <div class=\"row\">\n          <div class=\"column secondary\">\n            <div class=\"onsided-title start\">\n              <h2 i18n=\"@@advertise_multisensory_title\">\n                A MULTISENSORY EXPERIENCE\n              </h2>\n              <p i18n=\"@@advertise_multisensory_subtitle\">\n                Create an Audio identity for your brand using the power of audio\n                while tapping into the moment even when the screen is off.\n              </p>\n              <small\n                >Source: Impact of Audio – IAB & Edison Research 2016</small\n              >\n            </div>\n            <div class=\"percentange-circle\">\n              <div class=\"percentage-item\">\n                <div class=\"c100 p65 green\">\n                  <span>65%</span>\n                  <div class=\"slice\">\n                    <div class=\"bar\"></div>\n                    <div class=\"fill\"></div>\n                  </div>\n                </div>\n                <div class=\"mt-2\" i18n=\"@@advertise_visual_purchase_intent\">\n                  Increase in users’ purchase intent\n                </div>\n              </div>\n              <div class=\"percentage-item\">\n                <div class=\"c100 p45 pink\">\n                  <span>45%</span>\n                  <div class=\"slice\">\n                    <div class=\"bar\"></div>\n                    <div class=\"fill\"></div>\n                  </div>\n                </div>\n                <div class=\"mt-2\" i18n=\"@@advertise_visual_visit_website\">\n                  Of users are more likely to visit website\n                </div>\n              </div>\n              <div class=\"percentage-item\">\n                <div class=\"c100 p42 purple\">\n                  <span>42%</span>\n                  <div class=\"slice\">\n                    <div class=\"bar\"></div>\n                    <div class=\"fill\"></div>\n                  </div>\n                </div>\n                <div class=\"mt-2\" i18n=\"@@advertise_new_product\">\n                  Of users consider the new product or service\n                </div>\n              </div>\n            </div>\n          </div>\n          <div class=\"column primary\">\n            <div class=\"img-container\">\n              <img src=\"../../../assets/img/advertise/devices@2x.png\" />\n            </div>\n          </div>\n        </div>\n\n        <div class=\"row flippable\">\n          <div class=\"column secondary\">\n            <div class=\"img-container\">\n              <img src=\"../../../assets/img/advertise/devices_2@2x.png\" />\n            </div>\n          </div>\n          <div class=\"column primary\">\n            <div class=\"onsided-title\">\n              <h2 i18n=\"@@advertise_video_title\">ADAPTIVE VIDEO FORMAT</h2>\n              <p i18n=\"@@advertise_video_subtitle\">\n                Animate your brand and bring it to life with the proper sounds\n                and visuals by using adaptive video formats.\n              </p>\n              <small\n                >Source: The Six Second Ad Experience - FREEWHEEL 2018</small\n              >\n              <div class=\"percentange-circle\">\n                <div class=\"percentage-item\">\n                  <div class=\"c100 p45 green\">\n                    <span>45%</span>\n                    <div class=\"slice\">\n                      <div class=\"bar\"></div>\n                      <div class=\"fill\"></div>\n                    </div>\n                  </div>\n                  <div class=\"mt-2\" i18n=\"@@advertise_visual_purchase_intent\">\n                    Increase in users’ engagement\n                  </div>\n                </div>\n                <div class=\"percentage-item\">\n                  <div class=\"c100 p33 pink\">\n                    <span>33%</span>\n                    <div class=\"slice\">\n                      <div class=\"bar\"></div>\n                      <div class=\"fill\"></div>\n                    </div>\n                  </div>\n                  <div class=\"mt-2\">\n                    Increase in brand favorability\n                  </div>\n                </div>\n                <div class=\"percentage-item\">\n                  <div class=\"c100 p38 purple\">\n                    <span>38%</span>\n                    <div class=\"slice\">\n                      <div class=\"bar\"></div>\n                      <div class=\"fill\"></div>\n                    </div>\n                  </div>\n                  <div class=\"mt-2\" i18n=\"@@advertise_visual_purchase_intent\">\n                    Increase in purchase intent\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </ng-container>\n\n      <div class=\"row\">\n        <div class=\"notice-circle\" i18n=\"@@advertise_media_solution_text\">\n          Our media solutions helps your brand deliver premium content while\n          insuring a brand safe environment.\n        </div>\n      </div>\n    </div>\n  </section>\n\n  <section class=\"full-row-layout\">\n    <div class=\"container\">\n      <div class=\"row\">\n        <div\n          class=\"card col-lg-4 col-sm-6\"\n          *ngFor=\"let item of successStories\"\n          (click)=\"openVideo(content, item.youtube)\"\n        >\n          <div class=\"card-img-top\">\n            <div class=\"vid-overlay\"></div>\n            <img\n              class=\"img-responsive\"\n              [src]=\"item.image\"\n              [attr.alt]=\"item.title\"\n            />\n          </div>\n\n          <div class=\"card-body\">\n            <h5 class=\"card-title font-weight-bold\">{{ item.title }}</h5>\n            <p class=\"card-text\">\n              {{ item.description }}\n            </p>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>\n\n  <section class=\"full-row-layout\" id=\"getintouch\" #getintouch>\n    <div class=\"container\">\n      <div class=\"text-center\">\n        <h2>GET IN TOUCH</h2>\n        <p i18n=\"@@advertise_get_in_touch_subtitle\">\n          We will provide you with creative ad solutions to speak to your target\n          audience and help you reach your business objectives\n        </p>\n      </div>\n      <div class=\"row justify-content-center\">\n        <div class=\"col-lg-12 landing-content-wrapper\">\n          <form\n            autocomplete=\"on\"\n            [formGroup]=\"userForm\"\n            (ngSubmit)=\"submitForm()\"\n            class=\"ang-form\n          \"\n          >\n            <div class=\"col-6 d-inline-block\">\n              <input\n                [class.ang-error]=\"hasErr('firstName')\"\n                class=\"ang-input\"\n                type=\"text\"\n                placeholder=\"First Name\"\n                required\n                autocomplete=\"on\"\n                formControlName=\"firstName\"\n                i18n-placeholder=\"@@First name\"\n              />\n            </div>\n\n            <div class=\"col-6 d-inline-block\">\n              <input\n                [class.ang-error]=\"hasErr('lastName')\"\n                class=\"ang-input\"\n                type=\"text\"\n                placeholder=\"Last Name\"\n                required\n                autocomplete=\"on\"\n                formControlName=\"lastName\"\n                i18n-placeholder=\"@@Last name\"\n              />\n            </div>\n\n            <div class=\"col-6 d-inline-block\">\n              <input\n                [class.ang-error]=\"hasErr('email')\"\n                class=\"ang-input\"\n                type=\"email\"\n                placeholder=\"Email\"\n                required\n                autocomplete=\"on\"\n                formControlName=\"email\"\n                i18n-placeholder=\"@@Email\"\n              />\n            </div>\n\n            <div class=\"col-6 d-inline-block\">\n              <input\n                [class.ang-error]=\"hasErr('companyName')\"\n                class=\"ang-input\"\n                type=\"text\"\n                placeholder=\"Company Name\"\n                required\n                autocomplete=\"on\"\n                formControlName=\"companyName\"\n                i18n-placeholder=\"@@Company Name\"\n              />\n            </div>\n\n            <div class=\"col-6 d-inline-block\">\n              <input\n                [class.ang-error]=\"hasErr('mobileNumber')\"\n                class=\"ang-input\"\n                type=\"text\"\n                placeholder=\"Mobile Number\"\n                required\n                autocomplete=\"on\"\n                formControlName=\"mobileNumber\"\n                i18n-placeholder=\"@@Mobile Number\"\n              />\n            </div>\n\n            <div class=\"col-6 d-inline-block\">\n              <input\n                [class.ang-error]=\"hasErr('country')\"\n                class=\"ang-input\"\n                type=\"text\"\n                placeholder=\"Country\"\n                required\n                autocomplete=\"on\"\n                formControlName=\"country\"\n                i18n-placeholder=\"@@Country\"\n              />\n            </div>\n            <button\n              class=\"submit-btn ang-primary-colored-btn p-2 row justify-content-center col-3\"\n              type=\"submit\"\n              (click)=\"submitForm()\"\n            >\n              <span i18n=\"@@Send\">Send</span>\n            </button>\n          </form>\n        </div>\n      </div>\n    </div>\n  </section>\n</div>\n\n<ng-template #content let-c=\"close\" let-d=\"dismiss\">\n  <div class=\"modal-body\">\n    <div class=\"embed-responsive embed-responsive-16by9\">\n      <iframe\n        class=\"embed-responsive-item\"\n        [src]=\"cleanURL(selectedVideo)\"\n        allowfullscreen\n      ></iframe>\n    </div>\n  </div>\n</ng-template>"

/***/ }),

/***/ "./src/app/core/redux/actions/external-pages.actions.ts":
/*!**************************************************************!*\
  !*** ./src/app/core/redux/actions/external-pages.actions.ts ***!
  \**************************************************************/
/*! exports provided: ExternalPagesActionTypes, SubscribeCampaign, SubmitAdvertisePage, getWebPurchaseOptions, getWebPurchaseOptionsSuccess, submitStudentsOfferData, submitStudentsOfferDataSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExternalPagesActionTypes", function() { return ExternalPagesActionTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscribeCampaign", function() { return SubscribeCampaign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubmitAdvertisePage", function() { return SubmitAdvertisePage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWebPurchaseOptions", function() { return getWebPurchaseOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWebPurchaseOptionsSuccess", function() { return getWebPurchaseOptionsSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitStudentsOfferData", function() { return submitStudentsOfferData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitStudentsOfferDataSuccess", function() { return submitStudentsOfferDataSuccess; });
/*
 * Created Date: Thursday September 6th 2018
 * Author: Siraj Tahra
 * Email: siraj.tahra@anghami.com
 * -----
 * Copyright (c) 2018 Anghami
 */
var ExternalPagesActionTypes;
(function (ExternalPagesActionTypes) {
    ExternalPagesActionTypes["SubscribeCampaign"] = "[Auth] Subscribe Campaign";
    ExternalPagesActionTypes["SubmitAdvertisePage"] = "[Auth] Submit Advertise Page";
    ExternalPagesActionTypes["getWebPurchaseOptions"] = "[Landing] Get Web Purchase Options";
    ExternalPagesActionTypes["getWebPurchaseOptionsSuccess"] = "[Landing] Get Web Purchase Options Success";
    ExternalPagesActionTypes["submitStudentsOfferData"] = "[Landing] Submit Students Offer Data";
    ExternalPagesActionTypes["submitStudentsOfferDataSuccess"] = "[Landing] Submit Students Offer Success";
})(ExternalPagesActionTypes || (ExternalPagesActionTypes = {}));
var SubscribeCampaign = /** @class */ (function () {
    function SubscribeCampaign(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.SubscribeCampaign;
    }
    return SubscribeCampaign;
}());

var SubmitAdvertisePage = /** @class */ (function () {
    function SubmitAdvertisePage(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.SubmitAdvertisePage;
    }
    return SubmitAdvertisePage;
}());

var getWebPurchaseOptions = /** @class */ (function () {
    function getWebPurchaseOptions(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.getWebPurchaseOptions;
    }
    return getWebPurchaseOptions;
}());

var getWebPurchaseOptionsSuccess = /** @class */ (function () {
    function getWebPurchaseOptionsSuccess(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.getWebPurchaseOptionsSuccess;
    }
    return getWebPurchaseOptionsSuccess;
}());

var submitStudentsOfferData = /** @class */ (function () {
    function submitStudentsOfferData(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.submitStudentsOfferData;
    }
    return submitStudentsOfferData;
}());

var submitStudentsOfferDataSuccess = /** @class */ (function () {
    function submitStudentsOfferDataSuccess(payload) {
        if (payload === void 0) { payload = null; }
        this.payload = payload;
        this.type = ExternalPagesActionTypes.submitStudentsOfferDataSuccess;
    }
    return submitStudentsOfferDataSuccess;
}());



/***/ }),

/***/ "./src/app/core/services/advertise.service.ts":
/*!****************************************************!*\
  !*** ./src/app/core/services/advertise.service.ts ***!
  \****************************************************/
/*! exports provided: AdvertiseService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdvertiseService", function() { return AdvertiseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _anghami_services_custom_encoder__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/services/custom-encoder */ "./src/app/core/services/custom-encoder.ts");







var AdvertiseService = /** @class */ (function () {
    function AdvertiseService(http) {
        this.http = http;
    }
    AdvertiseService.prototype.getAdvertisePage = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('type', 'GETbrandpage');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["empty"])();
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(err); }));
    };
    AdvertiseService.prototype.subscribeCampaign = function (params) {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]({ encoder: new _anghami_services_custom_encoder__WEBPACK_IMPORTED_MODULE_6__["CustomEncoder"]() })
            .set('type', 'POSTsubscribecampaign')
            .set('campaign', params.campaign)
            .set('fullname', params.name)
            .set('msidn', params.msidn)
            .set('extravalue', params.extravalue)
            .set('email', params.email);
        return this.http.post("" + _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].API_URL, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["exhaustMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])({
                    title: data.error.message || 'An error has occured. Please try again!',
                    displaymode: 'toast'
                });
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["of"])(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, data, { title: params.extravalue === null
                        ? "Maybe you'll attend the next one :)"
                        : 'Thank you for submitting the form!', displaymode: 'toast' }));
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(err); }));
    };
    AdvertiseService.prototype.submitAdvertisePage = function (params) {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]({ encoder: new _anghami_services_custom_encoder__WEBPACK_IMPORTED_MODULE_6__["CustomEncoder"]() })
            .set('type', 'GETbrandpage')
            .set('firstname', params.firstName)
            .set('lastname', params.lastName)
            .set('email', params.email)
            .set('company', params.company)
            .set('country', params.country)
            .set('phone', params.phone);
        return this.http.post("" + _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].API_URL, body).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["exhaustMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])({
                    title: data.error.message || 'An error has occured. Please try again!',
                    displaymode: 'toast'
                });
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["of"])(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, data, { title: data.message || 'Thank you for submitting the form!', displaymode: 'toast', onSuccess: params.onSuccess }));
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(err); }));
    };
    AdvertiseService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({ providedIn: 'root' }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], AdvertiseService);
    return AdvertiseService;
}());



/***/ }),

/***/ "./src/app/core/services/custom-encoder.ts":
/*!*************************************************!*\
  !*** ./src/app/core/services/custom-encoder.ts ***!
  \*************************************************/
/*! exports provided: CustomEncoder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomEncoder", function() { return CustomEncoder; });
var CustomEncoder = /** @class */ (function () {
    function CustomEncoder() {
    }
    CustomEncoder.prototype.encodeKey = function (key) {
        return encodeURIComponent(key);
    };
    CustomEncoder.prototype.encodeValue = function (value) {
        return encodeURIComponent(value);
    };
    CustomEncoder.prototype.decodeKey = function (key) {
        return decodeURIComponent(key);
    };
    CustomEncoder.prototype.decodeValue = function (value) {
        return decodeURIComponent(value);
    };
    return CustomEncoder;
}());



/***/ }),

/***/ "./src/app/modules/landing/advertise/advertise.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/modules/landing/advertise/advertise.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".rect-auto,\n.c100.p51 .slice,\n.c100.p52 .slice,\n.c100.p53 .slice,\n.c100.p54 .slice,\n.c100.p55 .slice,\n.c100.p56 .slice,\n.c100.p57 .slice,\n.c100.p58 .slice,\n.c100.p59 .slice,\n.c100.p60 .slice,\n.c100.p61 .slice,\n.c100.p62 .slice,\n.c100.p63 .slice,\n.c100.p64 .slice,\n.c100.p65 .slice,\n.c100.p66 .slice,\n.c100.p67 .slice,\n.c100.p68 .slice,\n.c100.p69 .slice,\n.c100.p70 .slice,\n.c100.p71 .slice,\n.c100.p72 .slice,\n.c100.p73 .slice,\n.c100.p74 .slice,\n.c100.p75 .slice,\n.c100.p76 .slice,\n.c100.p77 .slice,\n.c100.p78 .slice,\n.c100.p79 .slice,\n.c100.p80 .slice,\n.c100.p81 .slice,\n.c100.p82 .slice,\n.c100.p83 .slice,\n.c100.p84 .slice,\n.c100.p85 .slice,\n.c100.p86 .slice,\n.c100.p87 .slice,\n.c100.p88 .slice,\n.c100.p89 .slice,\n.c100.p90 .slice,\n.c100.p91 .slice,\n.c100.p92 .slice,\n.c100.p93 .slice,\n.c100.p94 .slice,\n.c100.p95 .slice,\n.c100.p96 .slice,\n.c100.p97 .slice,\n.c100.p98 .slice,\n.c100.p99 .slice,\n.c100.p100 .slice {\n  clip: rect(auto, auto, auto, auto);\n}\n\n.pie,\n.c100 .bar,\n.c100.p51 .fill,\n.c100.p52 .fill,\n.c100.p53 .fill,\n.c100.p54 .fill,\n.c100.p55 .fill,\n.c100.p56 .fill,\n.c100.p57 .fill,\n.c100.p58 .fill,\n.c100.p59 .fill,\n.c100.p60 .fill,\n.c100.p61 .fill,\n.c100.p62 .fill,\n.c100.p63 .fill,\n.c100.p64 .fill,\n.c100.p65 .fill,\n.c100.p66 .fill,\n.c100.p67 .fill,\n.c100.p68 .fill,\n.c100.p69 .fill,\n.c100.p70 .fill,\n.c100.p71 .fill,\n.c100.p72 .fill,\n.c100.p73 .fill,\n.c100.p74 .fill,\n.c100.p75 .fill,\n.c100.p76 .fill,\n.c100.p77 .fill,\n.c100.p78 .fill,\n.c100.p79 .fill,\n.c100.p80 .fill,\n.c100.p81 .fill,\n.c100.p82 .fill,\n.c100.p83 .fill,\n.c100.p84 .fill,\n.c100.p85 .fill,\n.c100.p86 .fill,\n.c100.p87 .fill,\n.c100.p88 .fill,\n.c100.p89 .fill,\n.c100.p90 .fill,\n.c100.p91 .fill,\n.c100.p92 .fill,\n.c100.p93 .fill,\n.c100.p94 .fill,\n.c100.p95 .fill,\n.c100.p96 .fill,\n.c100.p97 .fill,\n.c100.p98 .fill,\n.c100.p99 .fill,\n.c100.p100 .fill {\n  position: absolute;\n  border: 0.08em solid #98ffdb;\n  width: 0.84em;\n  height: 0.84em;\n  clip: rect(0em, 0.5em, 1em, 0em);\n  border-radius: 50%;\n  -webkit-transform: rotate(0deg);\n  -ms-transform: rotate(0deg);\n  transform: rotate(0deg);\n}\n\n.pie-fill,\n.c100.p51 .bar:after,\n.c100.p51 .fill,\n.c100.p52 .bar:after,\n.c100.p52 .fill,\n.c100.p53 .bar:after,\n.c100.p53 .fill,\n.c100.p54 .bar:after,\n.c100.p54 .fill,\n.c100.p55 .bar:after,\n.c100.p55 .fill,\n.c100.p56 .bar:after,\n.c100.p56 .fill,\n.c100.p57 .bar:after,\n.c100.p57 .fill,\n.c100.p58 .bar:after,\n.c100.p58 .fill,\n.c100.p59 .bar:after,\n.c100.p59 .fill,\n.c100.p60 .bar:after,\n.c100.p60 .fill,\n.c100.p61 .bar:after,\n.c100.p61 .fill,\n.c100.p62 .bar:after,\n.c100.p62 .fill,\n.c100.p63 .bar:after,\n.c100.p63 .fill,\n.c100.p64 .bar:after,\n.c100.p64 .fill,\n.c100.p65 .bar:after,\n.c100.p65 .fill,\n.c100.p66 .bar:after,\n.c100.p66 .fill,\n.c100.p67 .bar:after,\n.c100.p67 .fill,\n.c100.p68 .bar:after,\n.c100.p68 .fill,\n.c100.p69 .bar:after,\n.c100.p69 .fill,\n.c100.p70 .bar:after,\n.c100.p70 .fill,\n.c100.p71 .bar:after,\n.c100.p71 .fill,\n.c100.p72 .bar:after,\n.c100.p72 .fill,\n.c100.p73 .bar:after,\n.c100.p73 .fill,\n.c100.p74 .bar:after,\n.c100.p74 .fill,\n.c100.p75 .bar:after,\n.c100.p75 .fill,\n.c100.p76 .bar:after,\n.c100.p76 .fill,\n.c100.p77 .bar:after,\n.c100.p77 .fill,\n.c100.p78 .bar:after,\n.c100.p78 .fill,\n.c100.p79 .bar:after,\n.c100.p79 .fill,\n.c100.p80 .bar:after,\n.c100.p80 .fill,\n.c100.p81 .bar:after,\n.c100.p81 .fill,\n.c100.p82 .bar:after,\n.c100.p82 .fill,\n.c100.p83 .bar:after,\n.c100.p83 .fill,\n.c100.p84 .bar:after,\n.c100.p84 .fill,\n.c100.p85 .bar:after,\n.c100.p85 .fill,\n.c100.p86 .bar:after,\n.c100.p86 .fill,\n.c100.p87 .bar:after,\n.c100.p87 .fill,\n.c100.p88 .bar:after,\n.c100.p88 .fill,\n.c100.p89 .bar:after,\n.c100.p89 .fill,\n.c100.p90 .bar:after,\n.c100.p90 .fill,\n.c100.p91 .bar:after,\n.c100.p91 .fill,\n.c100.p92 .bar:after,\n.c100.p92 .fill,\n.c100.p93 .bar:after,\n.c100.p93 .fill,\n.c100.p94 .bar:after,\n.c100.p94 .fill,\n.c100.p95 .bar:after,\n.c100.p95 .fill,\n.c100.p96 .bar:after,\n.c100.p96 .fill,\n.c100.p97 .bar:after,\n.c100.p97 .fill,\n.c100.p98 .bar:after,\n.c100.p98 .fill,\n.c100.p99 .bar:after,\n.c100.p99 .fill,\n.c100.p100 .bar:after,\n.c100.p100 .fill {\n  -webkit-transform: rotate(180deg);\n  -ms-transform: rotate(180deg);\n  transform: rotate(180deg);\n}\n\n.c100 {\n  position: relative;\n  font-size: 120px;\n  width: 1em;\n  height: 1em;\n  border-radius: 50%;\n  display: inline-block;\n  vertical-align: top;\n  margin: auto;\n  background-color: #e6e6e6;\n}\n\n.c100 *,\n.c100 *:before,\n.c100 *:after {\n  box-sizing: content-box;\n}\n\n.c100.center {\n  float: none;\n  margin: 0 auto;\n}\n\n.c100.big {\n  font-size: 240px;\n}\n\n.c100.small {\n  font-size: 80px;\n}\n\n.c100 > span {\n  position: absolute;\n  width: 100%;\n  z-index: 1;\n  left: 0;\n  top: 0;\n  width: 5em;\n  line-height: 5em;\n  font-size: 0.2em;\n  color: #000;\n  display: block;\n  text-align: center;\n  white-space: nowrap;\n  -webkit-transition-property: all;\n  transition-property: all;\n  -webkit-transition-duration: 0.2s;\n  transition-duration: 0.2s;\n  -webkit-transition-timing-function: ease-out;\n  transition-timing-function: ease-out;\n}\n\n.c100:after {\n  position: absolute;\n  top: 0.08em;\n  left: 0.08em;\n  display: block;\n  content: \" \";\n  border-radius: 50%;\n  background-color: #fff;\n  width: 0.84em;\n  height: 0.84em;\n  -webkit-transition-property: all;\n  transition-property: all;\n  -webkit-transition-duration: 0.2s;\n  transition-duration: 0.2s;\n  -webkit-transition-timing-function: ease-in;\n  transition-timing-function: ease-in;\n}\n\n.c100 .slice {\n  position: absolute;\n  width: 1em;\n  height: 1em;\n  clip: rect(0em, 1em, 1em, 0.5em);\n}\n\n.c100.p1 .bar {\n  -webkit-transform: rotate(3.6deg);\n  -ms-transform: rotate(3.6deg);\n  transform: rotate(3.6deg);\n}\n\n.c100.p2 .bar {\n  -webkit-transform: rotate(7.2deg);\n  -ms-transform: rotate(7.2deg);\n  transform: rotate(7.2deg);\n}\n\n.c100.p3 .bar {\n  -webkit-transform: rotate(10.8deg);\n  -ms-transform: rotate(10.8deg);\n  transform: rotate(10.8deg);\n}\n\n.c100.p4 .bar {\n  -webkit-transform: rotate(14.4deg);\n  -ms-transform: rotate(14.4deg);\n  transform: rotate(14.4deg);\n}\n\n.c100.p5 .bar {\n  -webkit-transform: rotate(18deg);\n  -ms-transform: rotate(18deg);\n  transform: rotate(18deg);\n}\n\n.c100.p6 .bar {\n  -webkit-transform: rotate(21.6deg);\n  -ms-transform: rotate(21.6deg);\n  transform: rotate(21.6deg);\n}\n\n.c100.p7 .bar {\n  -webkit-transform: rotate(25.2deg);\n  -ms-transform: rotate(25.2deg);\n  transform: rotate(25.2deg);\n}\n\n.c100.p8 .bar {\n  -webkit-transform: rotate(28.8deg);\n  -ms-transform: rotate(28.8deg);\n  transform: rotate(28.8deg);\n}\n\n.c100.p9 .bar {\n  -webkit-transform: rotate(32.4deg);\n  -ms-transform: rotate(32.4deg);\n  transform: rotate(32.4deg);\n}\n\n.c100.p10 .bar {\n  -webkit-transform: rotate(36deg);\n  -ms-transform: rotate(36deg);\n  transform: rotate(36deg);\n}\n\n.c100.p11 .bar {\n  -webkit-transform: rotate(39.6deg);\n  -ms-transform: rotate(39.6deg);\n  transform: rotate(39.6deg);\n}\n\n.c100.p12 .bar {\n  -webkit-transform: rotate(43.2deg);\n  -ms-transform: rotate(43.2deg);\n  transform: rotate(43.2deg);\n}\n\n.c100.p13 .bar {\n  -webkit-transform: rotate(46.8deg);\n  -ms-transform: rotate(46.8deg);\n  transform: rotate(46.8deg);\n}\n\n.c100.p14 .bar {\n  -webkit-transform: rotate(50.4deg);\n  -ms-transform: rotate(50.4deg);\n  transform: rotate(50.4deg);\n}\n\n.c100.p15 .bar {\n  -webkit-transform: rotate(54deg);\n  -ms-transform: rotate(54deg);\n  transform: rotate(54deg);\n}\n\n.c100.p16 .bar {\n  -webkit-transform: rotate(57.6deg);\n  -ms-transform: rotate(57.6deg);\n  transform: rotate(57.6deg);\n}\n\n.c100.p17 .bar {\n  -webkit-transform: rotate(61.2deg);\n  -ms-transform: rotate(61.2deg);\n  transform: rotate(61.2deg);\n}\n\n.c100.p18 .bar {\n  -webkit-transform: rotate(64.8deg);\n  -ms-transform: rotate(64.8deg);\n  transform: rotate(64.8deg);\n}\n\n.c100.p19 .bar {\n  -webkit-transform: rotate(68.4deg);\n  -ms-transform: rotate(68.4deg);\n  transform: rotate(68.4deg);\n}\n\n.c100.p20 .bar {\n  -webkit-transform: rotate(72deg);\n  -ms-transform: rotate(72deg);\n  transform: rotate(72deg);\n}\n\n.c100.p21 .bar {\n  -webkit-transform: rotate(75.6deg);\n  -ms-transform: rotate(75.6deg);\n  transform: rotate(75.6deg);\n}\n\n.c100.p22 .bar {\n  -webkit-transform: rotate(79.2deg);\n  -ms-transform: rotate(79.2deg);\n  transform: rotate(79.2deg);\n}\n\n.c100.p23 .bar {\n  -webkit-transform: rotate(82.8deg);\n  -ms-transform: rotate(82.8deg);\n  transform: rotate(82.8deg);\n}\n\n.c100.p24 .bar {\n  -webkit-transform: rotate(86.4deg);\n  -ms-transform: rotate(86.4deg);\n  transform: rotate(86.4deg);\n}\n\n.c100.p25 .bar {\n  -webkit-transform: rotate(90deg);\n  -ms-transform: rotate(90deg);\n  transform: rotate(90deg);\n}\n\n.c100.p26 .bar {\n  -webkit-transform: rotate(93.6deg);\n  -ms-transform: rotate(93.6deg);\n  transform: rotate(93.6deg);\n}\n\n.c100.p27 .bar {\n  -webkit-transform: rotate(97.2deg);\n  -ms-transform: rotate(97.2deg);\n  transform: rotate(97.2deg);\n}\n\n.c100.p28 .bar {\n  -webkit-transform: rotate(100.8deg);\n  -ms-transform: rotate(100.8deg);\n  transform: rotate(100.8deg);\n}\n\n.c100.p29 .bar {\n  -webkit-transform: rotate(104.4deg);\n  -ms-transform: rotate(104.4deg);\n  transform: rotate(104.4deg);\n}\n\n.c100.p30 .bar {\n  -webkit-transform: rotate(108deg);\n  -ms-transform: rotate(108deg);\n  transform: rotate(108deg);\n}\n\n.c100.p31 .bar {\n  -webkit-transform: rotate(111.6deg);\n  -ms-transform: rotate(111.6deg);\n  transform: rotate(111.6deg);\n}\n\n.c100.p32 .bar {\n  -webkit-transform: rotate(115.2deg);\n  -ms-transform: rotate(115.2deg);\n  transform: rotate(115.2deg);\n}\n\n.c100.p33 .bar {\n  -webkit-transform: rotate(118.8deg);\n  -ms-transform: rotate(118.8deg);\n  transform: rotate(118.8deg);\n}\n\n.c100.p34 .bar {\n  -webkit-transform: rotate(122.4deg);\n  -ms-transform: rotate(122.4deg);\n  transform: rotate(122.4deg);\n}\n\n.c100.p35 .bar {\n  -webkit-transform: rotate(126deg);\n  -ms-transform: rotate(126deg);\n  transform: rotate(126deg);\n}\n\n.c100.p36 .bar {\n  -webkit-transform: rotate(129.6deg);\n  -ms-transform: rotate(129.6deg);\n  transform: rotate(129.6deg);\n}\n\n.c100.p37 .bar {\n  -webkit-transform: rotate(133.2deg);\n  -ms-transform: rotate(133.2deg);\n  transform: rotate(133.2deg);\n}\n\n.c100.p38 .bar {\n  -webkit-transform: rotate(136.8deg);\n  -ms-transform: rotate(136.8deg);\n  transform: rotate(136.8deg);\n}\n\n.c100.p39 .bar {\n  -webkit-transform: rotate(140.4deg);\n  -ms-transform: rotate(140.4deg);\n  transform: rotate(140.4deg);\n}\n\n.c100.p40 .bar {\n  -webkit-transform: rotate(144deg);\n  -ms-transform: rotate(144deg);\n  transform: rotate(144deg);\n}\n\n.c100.p41 .bar {\n  -webkit-transform: rotate(147.6deg);\n  -ms-transform: rotate(147.6deg);\n  transform: rotate(147.6deg);\n}\n\n.c100.p42 .bar {\n  -webkit-transform: rotate(151.2deg);\n  -ms-transform: rotate(151.2deg);\n  transform: rotate(151.2deg);\n}\n\n.c100.p43 .bar {\n  -webkit-transform: rotate(154.8deg);\n  -ms-transform: rotate(154.8deg);\n  transform: rotate(154.8deg);\n}\n\n.c100.p44 .bar {\n  -webkit-transform: rotate(158.4deg);\n  -ms-transform: rotate(158.4deg);\n  transform: rotate(158.4deg);\n}\n\n.c100.p45 .bar {\n  -webkit-transform: rotate(162deg);\n  -ms-transform: rotate(162deg);\n  transform: rotate(162deg);\n}\n\n.c100.p46 .bar {\n  -webkit-transform: rotate(165.6deg);\n  -ms-transform: rotate(165.6deg);\n  transform: rotate(165.6deg);\n}\n\n.c100.p47 .bar {\n  -webkit-transform: rotate(169.2deg);\n  -ms-transform: rotate(169.2deg);\n  transform: rotate(169.2deg);\n}\n\n.c100.p48 .bar {\n  -webkit-transform: rotate(172.8deg);\n  -ms-transform: rotate(172.8deg);\n  transform: rotate(172.8deg);\n}\n\n.c100.p49 .bar {\n  -webkit-transform: rotate(176.4deg);\n  -ms-transform: rotate(176.4deg);\n  transform: rotate(176.4deg);\n}\n\n.c100.p50 .bar {\n  -webkit-transform: rotate(180deg);\n  -ms-transform: rotate(180deg);\n  transform: rotate(180deg);\n}\n\n.c100.p51 .bar {\n  -webkit-transform: rotate(183.6deg);\n  -ms-transform: rotate(183.6deg);\n  transform: rotate(183.6deg);\n}\n\n.c100.p52 .bar {\n  -webkit-transform: rotate(187.2deg);\n  -ms-transform: rotate(187.2deg);\n  transform: rotate(187.2deg);\n}\n\n.c100.p53 .bar {\n  -webkit-transform: rotate(190.8deg);\n  -ms-transform: rotate(190.8deg);\n  transform: rotate(190.8deg);\n}\n\n.c100.p54 .bar {\n  -webkit-transform: rotate(194.4deg);\n  -ms-transform: rotate(194.4deg);\n  transform: rotate(194.4deg);\n}\n\n.c100.p55 .bar {\n  -webkit-transform: rotate(198deg);\n  -ms-transform: rotate(198deg);\n  transform: rotate(198deg);\n}\n\n.c100.p56 .bar {\n  -webkit-transform: rotate(201.6deg);\n  -ms-transform: rotate(201.6deg);\n  transform: rotate(201.6deg);\n}\n\n.c100.p57 .bar {\n  -webkit-transform: rotate(205.2deg);\n  -ms-transform: rotate(205.2deg);\n  transform: rotate(205.2deg);\n}\n\n.c100.p58 .bar {\n  -webkit-transform: rotate(208.8deg);\n  -ms-transform: rotate(208.8deg);\n  transform: rotate(208.8deg);\n}\n\n.c100.p59 .bar {\n  -webkit-transform: rotate(212.4deg);\n  -ms-transform: rotate(212.4deg);\n  transform: rotate(212.4deg);\n}\n\n.c100.p60 .bar {\n  -webkit-transform: rotate(216deg);\n  -ms-transform: rotate(216deg);\n  transform: rotate(216deg);\n}\n\n.c100.p61 .bar {\n  -webkit-transform: rotate(219.6deg);\n  -ms-transform: rotate(219.6deg);\n  transform: rotate(219.6deg);\n}\n\n.c100.p62 .bar {\n  -webkit-transform: rotate(223.2deg);\n  -ms-transform: rotate(223.2deg);\n  transform: rotate(223.2deg);\n}\n\n.c100.p63 .bar {\n  -webkit-transform: rotate(226.8deg);\n  -ms-transform: rotate(226.8deg);\n  transform: rotate(226.8deg);\n}\n\n.c100.p64 .bar {\n  -webkit-transform: rotate(230.4deg);\n  -ms-transform: rotate(230.4deg);\n  transform: rotate(230.4deg);\n}\n\n.c100.p65 .bar {\n  -webkit-transform: rotate(234deg);\n  -ms-transform: rotate(234deg);\n  transform: rotate(234deg);\n}\n\n.c100.p66 .bar {\n  -webkit-transform: rotate(237.6deg);\n  -ms-transform: rotate(237.6deg);\n  transform: rotate(237.6deg);\n}\n\n.c100.p67 .bar {\n  -webkit-transform: rotate(241.2deg);\n  -ms-transform: rotate(241.2deg);\n  transform: rotate(241.2deg);\n}\n\n.c100.p68 .bar {\n  -webkit-transform: rotate(244.8deg);\n  -ms-transform: rotate(244.8deg);\n  transform: rotate(244.8deg);\n}\n\n.c100.p69 .bar {\n  -webkit-transform: rotate(248.4deg);\n  -ms-transform: rotate(248.4deg);\n  transform: rotate(248.4deg);\n}\n\n.c100.p70 .bar {\n  -webkit-transform: rotate(252deg);\n  -ms-transform: rotate(252deg);\n  transform: rotate(252deg);\n}\n\n.c100.p71 .bar {\n  -webkit-transform: rotate(255.6deg);\n  -ms-transform: rotate(255.6deg);\n  transform: rotate(255.6deg);\n}\n\n.c100.p72 .bar {\n  -webkit-transform: rotate(259.2deg);\n  -ms-transform: rotate(259.2deg);\n  transform: rotate(259.2deg);\n}\n\n.c100.p73 .bar {\n  -webkit-transform: rotate(262.8deg);\n  -ms-transform: rotate(262.8deg);\n  transform: rotate(262.8deg);\n}\n\n.c100.p74 .bar {\n  -webkit-transform: rotate(266.4deg);\n  -ms-transform: rotate(266.4deg);\n  transform: rotate(266.4deg);\n}\n\n.c100.p75 .bar {\n  -webkit-transform: rotate(270deg);\n  -ms-transform: rotate(270deg);\n  transform: rotate(270deg);\n}\n\n.c100.p76 .bar {\n  -webkit-transform: rotate(273.6deg);\n  -ms-transform: rotate(273.6deg);\n  transform: rotate(273.6deg);\n}\n\n.c100.p77 .bar {\n  -webkit-transform: rotate(277.2deg);\n  -ms-transform: rotate(277.2deg);\n  transform: rotate(277.2deg);\n}\n\n.c100.p78 .bar {\n  -webkit-transform: rotate(280.8deg);\n  -ms-transform: rotate(280.8deg);\n  transform: rotate(280.8deg);\n}\n\n.c100.p79 .bar {\n  -webkit-transform: rotate(284.4deg);\n  -ms-transform: rotate(284.4deg);\n  transform: rotate(284.4deg);\n}\n\n.c100.p80 .bar {\n  -webkit-transform: rotate(288deg);\n  -ms-transform: rotate(288deg);\n  transform: rotate(288deg);\n}\n\n.c100.p81 .bar {\n  -webkit-transform: rotate(291.6deg);\n  -ms-transform: rotate(291.6deg);\n  transform: rotate(291.6deg);\n}\n\n.c100.p82 .bar {\n  -webkit-transform: rotate(295.2deg);\n  -ms-transform: rotate(295.2deg);\n  transform: rotate(295.2deg);\n}\n\n.c100.p83 .bar {\n  -webkit-transform: rotate(298.8deg);\n  -ms-transform: rotate(298.8deg);\n  transform: rotate(298.8deg);\n}\n\n.c100.p84 .bar {\n  -webkit-transform: rotate(302.4deg);\n  -ms-transform: rotate(302.4deg);\n  transform: rotate(302.4deg);\n}\n\n.c100.p85 .bar {\n  -webkit-transform: rotate(306deg);\n  -ms-transform: rotate(306deg);\n  transform: rotate(306deg);\n}\n\n.c100.p86 .bar {\n  -webkit-transform: rotate(309.6deg);\n  -ms-transform: rotate(309.6deg);\n  transform: rotate(309.6deg);\n}\n\n.c100.p87 .bar {\n  -webkit-transform: rotate(313.2deg);\n  -ms-transform: rotate(313.2deg);\n  transform: rotate(313.2deg);\n}\n\n.c100.p88 .bar {\n  -webkit-transform: rotate(316.8deg);\n  -ms-transform: rotate(316.8deg);\n  transform: rotate(316.8deg);\n}\n\n.c100.p89 .bar {\n  -webkit-transform: rotate(320.4deg);\n  -ms-transform: rotate(320.4deg);\n  transform: rotate(320.4deg);\n}\n\n.c100.p90 .bar {\n  -webkit-transform: rotate(324deg);\n  -ms-transform: rotate(324deg);\n  transform: rotate(324deg);\n}\n\n.c100.p91 .bar {\n  -webkit-transform: rotate(327.6deg);\n  -ms-transform: rotate(327.6deg);\n  transform: rotate(327.6deg);\n}\n\n.c100.p92 .bar {\n  -webkit-transform: rotate(331.2deg);\n  -ms-transform: rotate(331.2deg);\n  transform: rotate(331.2deg);\n}\n\n.c100.p93 .bar {\n  -webkit-transform: rotate(334.8deg);\n  -ms-transform: rotate(334.8deg);\n  transform: rotate(334.8deg);\n}\n\n.c100.p94 .bar {\n  -webkit-transform: rotate(338.4deg);\n  -ms-transform: rotate(338.4deg);\n  transform: rotate(338.4deg);\n}\n\n.c100.p95 .bar {\n  -webkit-transform: rotate(342deg);\n  -ms-transform: rotate(342deg);\n  transform: rotate(342deg);\n}\n\n.c100.p96 .bar {\n  -webkit-transform: rotate(345.6deg);\n  -ms-transform: rotate(345.6deg);\n  transform: rotate(345.6deg);\n}\n\n.c100.p97 .bar {\n  -webkit-transform: rotate(349.2deg);\n  -ms-transform: rotate(349.2deg);\n  transform: rotate(349.2deg);\n}\n\n.c100.p98 .bar {\n  -webkit-transform: rotate(352.8deg);\n  -ms-transform: rotate(352.8deg);\n  transform: rotate(352.8deg);\n}\n\n.c100.p99 .bar {\n  -webkit-transform: rotate(356.4deg);\n  -ms-transform: rotate(356.4deg);\n  transform: rotate(356.4deg);\n}\n\n.c100.p100 .bar {\n  -webkit-transform: rotate(360deg);\n  -ms-transform: rotate(360deg);\n  transform: rotate(360deg);\n}\n\n.c100.purple .bar,\n.c100.purple .fill {\n  border-color: #913ccd !important;\n}\n\n.c100.pink .bar,\n.c100.pink .fill {\n  border-color: #ff647c !important;\n}\n\n:host .header-banner {\n  background-image: url('advertise-banner.jpg');\n}\n\n:host .forcewidth {\n  max-width: 18em;\n  margin: auto;\n}\n\n:host .ang-input {\n  border: none;\n  background-color: var(--white);\n  margin: 1em 0;\n  padding: 1em 2em;\n  -webkit-appearance: none;\n  box-shadow: 0 0 15px rgba(128, 128, 128, 0.25);\n  -webkit-box-shadow: 0 0 15px rgba(128, 128, 128, 0.25);\n  border-radius: 2em;\n  width: 100%;\n}\n\n:host .ang-input:-moz-placeholder, :host .ang-input::-webkit-input-placeholder, :host .ang-input:-ms-input-placeholder {\n  color: var(--text-color-light);\n}\n\n:host .ang-input {\n  color: var(--text-color-light);\n}\n\n:host .submit-btn {\n  margin: 1em auto;\n}\n\n:host input::-webkit-outer-spin-button,\n:host input::-webkit-inner-spin-button {\n  /* display: none; <- Crashes Chrome on hover */\n  opacity: 0;\n  -webkit-appearance: none;\n  -moz-appearance: none;\n}\n\n:host .ang-form {\n  margin: 2em auto 2em auto;\n  max-width: 50em;\n}\n\n:host .ang-error {\n  border: 1px solid red !important;\n}\n\n:host .numbers-card-col {\n  display: inline-block;\n  vertical-align: top;\n}\n\n:host .numbers-card-col:nth-child(2) {\n  margin-top: 2em;\n}\n\n@media (max-width: 991.98px) {\n  :host .numbers-card-col:nth-child(2) {\n    margin: 0;\n  }\n}\n\n:host .numbers-card-col .numbers-card {\n  width: 12em;\n  height: 12em;\n  box-shadow: 0px 0px 22px 5px rgba(0, 0, 0, 0.08);\n  border-radius: 0.2em;\n  background: #fff;\n  text-align: center;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  vertical-align: top;\n  padding: 0 0.5em;\n  margin: 1.5em 1em;\n}\n\n@media (max-width: 991.98px) {\n  :host .numbers-card-col .numbers-card {\n    width: 10em;\n    height: 10em;\n  }\n}\n\n:host .numbers-card-col .numbers-card .number {\n  font-size: 3em;\n  font-weight: bolder;\n}\n\n:host .numbers-card-col .numbers-card.c1 .number {\n  color: #64d7c8;\n}\n\n:host .numbers-card-col .numbers-card.c2 .number {\n  color: #913ccd;\n}\n\n:host .numbers-card-col .numbers-card.c3 .number {\n  color: #913ccd;\n}\n\n:host .numbers-card-col .numbers-card.c4 .number {\n  color: #32aadc;\n}\n\n:host .regions-container {\n  position: relative;\n  margin-top: 4em;\n}\n\n:host .regions-container .row {\n  max-width: 1140px;\n  margin: auto;\n}\n\n:host .gradient-wave {\n  z-index: -1;\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: -10em;\n  height: 40em;\n}\n\n:host .gradient-wave img {\n  height: 100%;\n  display: block;\n}\n\n@media (min-width: 1200px) {\n  :host .gradient-wave img {\n    width: 100%;\n  }\n}\n\n:host .region {\n  position: relative;\n  text-align: center;\n  padding-top: 0.5em;\n  padding-bottom: 0.5em;\n  position: relative;\n  width: 100%;\n  padding-right: 15px;\n  padding-left: 15px;\n  -webkit-box-flex: 0;\n      -ms-flex: 0 0 25%;\n          flex: 0 0 25%;\n  max-width: 25%;\n}\n\n:host .region img {\n  max-width: 10em;\n}\n\n@media (max-width: 767.98px) {\n  :host .region {\n    -webkit-box-flex: 0;\n        -ms-flex: 0 0 50%;\n            flex: 0 0 50%;\n    max-width: 50%;\n  }\n}\n\n:host .region .label {\n  position: absolute;\n  margin-top: -2em;\n  left: 0;\n  right: 0;\n  top: 50%;\n}\n\n:host .region .label h4,\n:host .region .label span {\n  color: #fff;\n  text-align: center;\n}\n\n:host .region .label h4 {\n  font-weight: bold;\n}\n\n:host .graph-bars-outer {\n  overflow-x: scroll;\n}\n\n:host .graph-bars-outer img {\n  height: auto;\n  display: block;\n  margin: auto;\n  width: 200%;\n  padding: 0 1em;\n}\n\n:host .graph-bars-outer .graph-bars {\n  white-space: nowrap;\n  overflow-x: auto;\n  text-align: center;\n  margin: 0 auto;\n  height: 15em;\n  padding: 4em 0;\n}\n\n:host .graph-bars-outer .graph-bars li {\n  width: 0.4em;\n  border-radius: 0.3em;\n  margin: 0.5em;\n  background-color: #e1e1e2;\n  list-style-type: none;\n  display: inline-block;\n  vertical-align: middle;\n  position: relative;\n}\n\n:host .graph-bars-outer .graph-bars li.sm {\n  height: 1em;\n}\n\n:host .graph-bars-outer .graph-bars li.md {\n  height: 2em;\n}\n\n:host .graph-bars-outer .graph-bars li.lg {\n  height: 3em;\n}\n\n:host .graph-bars-outer .graph-bars li.xl {\n  height: 5em;\n  background-color: #913ccd;\n}\n\n:host .graph-bars-outer .graph-bars li.xl:nth-child(odd) {\n  height: 6em;\n}\n\n:host .graph-bars-outer .graph-bars li .details {\n  position: absolute;\n}\n\n:host .graph-bars-outer .graph-bars li .details img,\n:host .graph-bars-outer .graph-bars li .details .data {\n  display: inline-block;\n  vertical-align: top;\n  text-align: start;\n}\n\n:host .graph-bars-outer .graph-bars li .details .data {\n  padding: 0 0.8em;\n}\n\n:host .graph-bars-outer .graph-bars li .details.top {\n  top: -4em;\n}\n\n:host .graph-bars-outer .graph-bars li .details.bottom {\n  bottom: -4em;\n}\n\n:host .day-to-night {\n  width: 95%;\n  height: auto;\n  display: block;\n  margin: 1em auto 5em auto;\n}\n\n:host .notice-circle {\n  border: 1px solid #e6e6e6;\n  border-radius: 3em;\n  padding: 1em 2em;\n  margin: 2em auto;\n  text-align: center;\n  font-size: 0.9em;\n  max-width: 35em;\n}\n\n@media (max-width: 767.98px) {\n  :host .notice-circle {\n    max-width: 100%;\n    margin: 2em;\n  }\n}\n\n:host .card .card-body {\n  padding: 1em 0.2em;\n}\n\n:host .card .card-img-top {\n  position: relative;\n  overflow: hidden;\n}\n\n:host .card .card-img-top img {\n  display: block;\n  width: 100%;\n  margin: auto;\n}\n\n:host .card .card-img-top .vid-overlay {\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  background-image: url('videoicon.png');\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: 3em;\n  background-color: rgba(0, 0, 0, 0.7);\n  display: none;\n}\n\n:host .card:hover {\n  background: none;\n}\n\n:host .card:hover .card-img-top .vid-overlay {\n  display: block;\n}\n\n:host .solution-item {\n  text-align: center;\n}\n\n:host .solution-item img {\n  max-width: 100%;\n  display: block;\n  margin: auto;\n}\n\n:host .solution-item h5 {\n  font-weight: bold;\n  font-size: 1.15rem;\n}\n\n:host .percentange-circle .percentage-item {\n  display: inline-block;\n  vertical-align: top;\n  text-align: center;\n  max-width: 10em;\n  margin-top: 1em;\n}\n\n@media (max-width: 767.98px) {\n  :host .percentange-circle .percentage-item {\n    max-width: 8em;\n  }\n  :host .percentange-circle .percentage-item .c100 {\n    -webkit-transform: scale(0.8);\n        -ms-transform: scale(0.8);\n            transform: scale(0.8);\n  }\n}\n\n@media (min-width: 768px) {\n  :host .graph-bars-outer {\n    overflow: initial;\n  }\n  :host .graph-bars-outer img {\n    width: 80%;\n    padding: initial;\n  }\n  :host .day-to-night {\n    width: 82%;\n  }\n}"

/***/ }),

/***/ "./src/app/modules/landing/advertise/advertise.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/modules/landing/advertise/advertise.component.ts ***!
  \******************************************************************/
/*! exports provided: AdvertiseComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdvertiseComponent", function() { return AdvertiseComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_services_advertise_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../core/services/advertise.service */ "./src/app/core/services/advertise.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @anghami/redux/actions/external-pages.actions */ "./src/app/core/redux/actions/external-pages.actions.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");











var AdvertiseComponent = /** @class */ (function () {
    function AdvertiseComponent(fb, advertiseService, config, modalService, sanitizer, store, platformId) {
        this.fb = fb;
        this.advertiseService = advertiseService;
        this.modalService = modalService;
        this.sanitizer = sanitizer;
        this.store = store;
        this.platformId = platformId;
        this.selectedTab = 1;
        this.successStories = [];
        this.env = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].assetsCDN + "img/advertise/";
        this.formTypes = [
            'firstName',
            'lastName',
            'email',
            'companyName',
            'mobileNumber',
            'country'
            // 'industry',
            // 'businessObjectives'
        ];
        this.userForm = this.fb.group({
            firstName: [
                null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required])
            ],
            lastName: [
                null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required])
            ],
            email: [
                null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].email, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required])
            ],
            companyName: [
                null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required])
            ],
            mobileNumber: [
                null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].pattern(/^\+*[0-9]{7,}$/),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required
                ])
            ],
            country: [
                null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].minLength(2), _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required])
            ]
        });
    }
    AdvertiseComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.advertiseService
            .getAdvertisePage()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1))
            .subscribe(function (data) {
        });
        this.fillSuccessStories();
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_10__["isPlatformBrowser"])(this.platformId)) {
            setTimeout(function () {
                if (_this.getintouch) {
                    if (window.location.href.indexOf('?s=getintouch') > -1) {
                        var top_1 = _this.getintouch.nativeElement.offsetTop;
                        window.scrollTo(0, top_1 - 100);
                    }
                }
            }, 1000);
        }
    };
    AdvertiseComponent.prototype.counter = function (i) {
        return new Array(i);
    };
    AdvertiseComponent.prototype.switchTabs = function (id) {
        this.selectedTab = id;
    };
    AdvertiseComponent.prototype.fillSuccessStories = function () {
        this.successStories = [
            {
                id: 0,
                title: 'McCafe',
                description: 'McCafe launches their new coffee range with personalization.',
                image: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].assetsCDN + 'img/advertise/success-stories/mcafe.jpg',
                youtube: '9v5YpwWbi0g'
            },
            {
                id: 1,
                title: 'Maggi',
                description: 'Maggi takes the cooking experience to a new level.',
                image: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].assetsCDN + 'img/advertise/success-stories/maggi.jpg',
                youtube: 'ZRlh2t4ejr4'
            },
            {
                id: 2,
                title: 'Oreo',
                description: 'Oreo gifts music & chocolate on Christmas. ',
                image: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].assetsCDN + 'img/advertise/success-stories/oero.jpg',
                youtube: '_hr9Stg9-ME'
            },
            {
                id: 3,
                title: 'Close Up',
                description: 'Closeup attracts a digital population using the power of music.',
                image: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].assetsCDN + 'img/advertise/success-stories/closeup.jpg',
                youtube: 'cU1itEol_U0'
            },
            {
                id: 4,
                title: 'Lipton',
                description: 'Lipton wakes people up to their favorite music.',
                image: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].assetsCDN + 'img/advertise/success-stories/lipton.jpg',
                youtube: '8Ss-K0Jbobc'
            },
            {
                id: 5,
                title: 'Cadbury 5star',
                description: 'Cadbury 5star invites users to sing along with them.',
                image: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].assetsCDN + 'img/advertise/success-stories/cadbury.jpg',
                youtube: '6WX3wJ5Br6k'
            },
            {
                id: 6,
                title: 'Close Up',
                description: 'Closeup celebrates people’s smiles on Valentine. ',
                image: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].assetsCDN + 'img/advertise/success-stories/closeup2.jpg',
                youtube: 'c4Z5TDzqglY'
            },
            {
                id: 7,
                title: 'Nescafe',
                description: 'Nescafe becomes the students’ favorite studying companion.',
                image: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].assetsCDN + 'img/advertise/success-stories/nescafe.jpg',
                youtube: '6kfz1Rb2bqs'
            }
        ];
    };
    AdvertiseComponent.prototype.openVideo = function (content, video) {
        var _this = this;
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_10__["isPlatformBrowser"])(this.platformId)) {
            if (video && video !== '') {
                this.selectedVideo = "https://www.youtube.com/embed/" + video + "?rel=0";
                setTimeout(function () {
                    _this.modalService.open(content, { size: 'lg', centered: true });
                }, 500);
            }
        }
    };
    AdvertiseComponent.prototype.cleanURL = function (url) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    };
    AdvertiseComponent.prototype.inputTouched = function () {
        var _this = this;
        this.formTypes.forEach(function (prop) {
            if (_this.userForm.controls[prop].status === 'INVALID') {
                _this.userForm.controls[prop].markAsTouched();
            }
        });
    };
    AdvertiseComponent.prototype.submitForm = function () {
        if (this.userForm.status === 'VALID') {
            this.store.dispatch(new _anghami_redux_actions_external_pages_actions__WEBPACK_IMPORTED_MODULE_9__["SubmitAdvertisePage"]({
                email: this.userForm.value.email,
                firstName: this.userForm.value.firstName,
                lastName: this.userForm.value.lastName,
                phone: this.userForm.value.mobileNumber,
                country: this.userForm.value.country,
                company: this.userForm.value.companyName,
                onSuccess: this.clearForm.bind(this)
            }));
        }
        else {
            this.inputTouched();
        }
    };
    AdvertiseComponent.prototype.clearForm = function () {
        var _this = this;
        this.formTypes.forEach(function (prop) {
            _this.userForm.controls[prop].setValue('');
            _this.userForm.controls[prop].markAsUntouched();
        });
    };
    AdvertiseComponent.prototype.hasErr = function (type) {
        return (this.userForm.controls[type].touched &&
            !this.userForm.controls[type].valid);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('getintouch', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], AdvertiseComponent.prototype, "getintouch", void 0);
    AdvertiseComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-landing-home',
            template: __webpack_require__(/*! raw-loader!./advertise.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/advertise/advertise.component.html"),
            providers: [_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModalConfig"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModal"]],
            styles: [__webpack_require__(/*! ./advertise.component.scss */ "./src/app/modules/landing/advertise/advertise.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](6, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"],
            _core_services_advertise_service__WEBPACK_IMPORTED_MODULE_2__["AdvertiseService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModalConfig"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModal"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_8__["Store"],
            Object])
    ], AdvertiseComponent);
    return AdvertiseComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/advertise/advertise.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/modules/landing/advertise/advertise.module.ts ***!
  \***************************************************************/
/*! exports provided: AdvertiseModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdvertiseModule", function() { return AdvertiseModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _advertise_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./advertise.component */ "./src/app/modules/landing/advertise/advertise.component.ts");
/* harmony import */ var _advertise_route__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./advertise.route */ "./src/app/modules/landing/advertise/advertise.route.ts");







var AdvertiseModule = /** @class */ (function () {
    function AdvertiseModule() {
    }
    AdvertiseModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
                _advertise_route__WEBPACK_IMPORTED_MODULE_6__["AdvertiseRoutingModule"]
            ],
            declarations: [_advertise_component__WEBPACK_IMPORTED_MODULE_5__["AdvertiseComponent"]],
            exports: [_advertise_component__WEBPACK_IMPORTED_MODULE_5__["AdvertiseComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
        })
    ], AdvertiseModule);
    return AdvertiseModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/advertise/advertise.route.ts":
/*!**************************************************************!*\
  !*** ./src/app/modules/landing/advertise/advertise.route.ts ***!
  \**************************************************************/
/*! exports provided: routes, AdvertiseRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdvertiseRoutingModule", function() { return AdvertiseRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _advertise_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./advertise.component */ "./src/app/modules/landing/advertise/advertise.component.ts");




var routes = [
    {
        path: '',
        component: _advertise_component__WEBPACK_IMPORTED_MODULE_3__["AdvertiseComponent"]
    }
];
var AdvertiseRoutingModule = /** @class */ (function () {
    function AdvertiseRoutingModule() {
    }
    AdvertiseRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
            providers: []
        })
    ], AdvertiseRoutingModule);
    return AdvertiseRoutingModule;
}());



/***/ })

}]);