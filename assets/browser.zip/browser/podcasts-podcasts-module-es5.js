(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["podcasts-podcasts-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/podcasts/podcasts.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/podcasts/podcasts.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"podcasts-wrapper\">\n  <div class=\"header-banner\">\n    <div class=\"content\" #headerContent>\n      <h1 class=\"title\" [innerHTML]=\"podcastTitleTranslation\"></h1>\n      <h4 class=\"sub-title\" [innerHTML]=\"podcastSubtitleTranslation\"></h4>\n      <div class=\"d-flex flex-row justify-content-end\">\n        <a [routerLink]=\"['/tag/127']\" class=\"btn default\">\n          <span i18n=\"@@podcast_button\">Start discovering</span>\n        </a>\n      </div>\n    </div>\n    <!-- <div class=\"landing-wave\"></div> -->\n  </div>\n  <div class=\"podcasts-content-section podcasts-body-padding\">\n    <h2 class=\"text-center text-uppercase font-weight-bold pb-2 text-body\" i18n=\"@@podcast_youlove_section\">\n      ALL THE PODCASTS YOU LOVE\n    </h2>\n    <div class=\"container\" *ngIf=\"isPlatformBrowser\">\n      <!-- <div plyr [plyrDriver]=\"\" [plyrOptions]=\"options\" [plyrSources]=\"sources\"\n        [plyrPoster]=\"env + 'podcasts-video-thumbnail.jpg'\" [plyrTitle]=\"''\" (plyrInit)=\"setPlyr($event)\"\n        (plyrPlay)=\"played()\"></div> -->\n    </div>\n  </div>\n  <div class=\"podcasts-content-section podcasts-body-padding\">\n    <h2 class=\"text-center text-uppercase font-weight-bold pb-2 text-body\" i18n=\"@@podcast_podcasters_section\">\n      MEET THE PODCASTERS\n    </h2>\n    <div class=\"podcasts-body-padding w-100\" *ngIf=\"playlists\">\n      <anghami-new-section-builder [sections]=\"podcasters\">\n      </anghami-new-section-builder>\n    </div>\n  </div>\n  <div class=\"podcasts-on-the-go\">\n    <img [src]=\"env + 'on-the-go-image-desktop.png'\" class=\"on-the-go-img\" />\n    <div class=\"on-the-go-text podcasts-body-padding\">\n      <div class=\"on-the-go-title all-caps\" i18n=\"@@podcast_onthego_section_title\">\n        PODCASTS ON THE GO\n      </div>\n      <div class=\"on-the-go-subtitle\" i18n=\"@@podcast_onthego_section_subtitle\">\n        Listen anywhere, anytime\n      </div>\n    </div>\n  </div>\n  <div class=\"podcasts-content-section podcasts-body-padding\">\n    <h2 class=\"text-center text-uppercase font-weight-bold pb-2 text-body\" i18n=\"@@podcast_topshows_title\">\n      DISCOVER THE TOP SHOWS\n    </h2>\n    <div class=\"podcasts-content-subtitle\" i18n=\"@@podcast_topshows_subtitle\">\n      Hundreds of shows and many categories\n    </div>\n    <div class=\"podcasts-body-padding w-100\" *ngIf=\"playlists\">\n      <anghami-new-section-builder [sections]=\"playlists\">\n      </anghami-new-section-builder>\n    </div>\n  </div>\n  <div class=\"podcasts-cards-container\">\n    <div class=\"podcasts-cards-left podcasts-body-padding\">\n      <img [src]=\"env + 'shape-desktop.png'\" class=\"podcasts-cards-left-img podcasts-sm-hide\" />\n      <img [src]=\"env + 'shape-mobile.png'\" class=\"podcasts-cards-left-img podcasts-lg-hide\" />\n      <div class=\"podcasts-cards-left-title all-caps\" [innerHTML]=\"uniqueExperienceTranslation\"></div>\n      <div class=\"podcasts-cards-left-subtitle\" i18n=\"@@podcast_audioexperience_subtitle\">\n        On mobile, web and more\n      </div>\n    </div>\n    <div class=\"podcasts-cards-right\">\n      <div class=\"podcasts-cards-row podcasts-lg-translate-row\">\n        <div class=\"podcasts-card text-body\">\n          <img [src]=\"env + 'ar-en-podcast.png'\" />\n          <div i18n=\"@@podcast_benefit1\">Arabic & English Podcasts</div>\n        </div>\n        <div class=\"podcasts-card text-body\">\n          <img [src]=\"env + 'variety.png'\" />\n          <div i18n=\"@@podcast_benefit2\">Variety of categories</div>\n        </div>\n        <div class=\"podcasts-card text-body\">\n          <img [src]=\"env + 'favorite.png'\" />\n          <div i18n=\"@@podcast_benefit3\">Follow your favorite podcasters</div>\n        </div>\n      </div>\n      <div class=\"podcasts-cards-row\">\n        <div class=\"podcasts-card text-body\">\n          <img [src]=\"env + 'around-the-world.png'\" />\n          <div i18n=\"@@podcast_benefit4\">\n            Podcasts from MENA & around the world\n          </div>\n        </div>\n        <div class=\"podcasts-card text-body\">\n          <img [src]=\"env + 'reminder.png'\" />\n          <div i18n=\"@@podcast_benefit5\">\n            Reminders to continue your episodes\n          </div>\n        </div>\n        <div class=\"podcasts-card text-body\">\n          <img [src]=\"env + 'switch.png'\" />\n          <div i18n=\"@@podcast_benefit6\">Switch seamlessly web to mobile</div>\n        </div>\n      </div>\n      <div class=\"podcasts-cards-row\">\n        <div class=\"podcasts-card text-body\">\n          <img [src]=\"env + 'new-episode.png'\" />\n          <div i18n=\"@@podcast_benefit7\">New Episode Notifications</div>\n        </div>\n        <div class=\"podcasts-card text-body\">\n          <img [src]=\"env + 'on-car.png'\" />\n          <div i18n=\"@@podcast_benefit8\">Play on CarPlay</div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/modules/landing/podcasts/podcasts-routing.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/modules/landing/podcasts/podcasts-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: PodcastsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PodcastsRoutingModule", function() { return PodcastsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _podcasts_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./podcasts.component */ "./src/app/modules/landing/podcasts/podcasts.component.ts");




var routes = [
    {
        path: '',
        component: _podcasts_component__WEBPACK_IMPORTED_MODULE_3__["PodcastsComponent"]
    }
];
var PodcastsRoutingModule = /** @class */ (function () {
    function PodcastsRoutingModule() {
    }
    PodcastsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], PodcastsRoutingModule);
    return PodcastsRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/podcasts/podcasts.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/modules/landing/podcasts/podcasts.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@-webkit-keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n.podcasts-header-img-wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  z-index: -1;\n  overflow: hidden;\n  color: #000;\n}\n.podcasts-header-img {\n  width: 100%;\n}\n.all-caps {\n  text-transform: uppercase;\n}\n.plyr__video-wrapper {\n  min-width: 100%;\n}\n.podcasts-wrapper .podcasts-header-text {\n  width: 100%;\n  color: white;\n}\n.podcasts-wrapper .podcasts-header-text .podcasts-header-title {\n  text-align: right;\n  font-weight: bold;\n}\n.podcasts-wrapper .podcasts-header-text .podcasts-header-subtitle {\n  text-align: right;\n  margin-top: 1rem;\n  font-size: 1.15rem;\n  font-weight: 300;\n  opacity: 0.8;\n}\n.podcasts-wrapper .podcasts-header-text .podcasts-header-btn {\n  float: right;\n  margin-top: 2rem;\n  font-size: 1rem;\n  color: white;\n}\n.podcasts-wrapper .podcasts-content-section {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.podcasts-wrapper .podcasts-content-section .podcasts-content-title {\n  text-align: center;\n  color: black;\n  font-weight: bold;\n}\n.podcasts-wrapper .podcasts-content-section .podcasts-content-subtitle {\n  text-align: center;\n  color: black;\n}\n.podcasts-wrapper .podcasts-on-the-go {\n  margin-top: 1rem;\n  position: relative;\n  width: 100%;\n  text-align: right;\n  color: white;\n}\n.podcasts-wrapper .podcasts-on-the-go .on-the-go-img {\n  position: absolute;\n  width: 100%;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: -1;\n}\n.podcasts-wrapper .podcasts-on-the-go .on-the-go-text {\n  padding-top: 18%;\n  margin-bottom: 18%;\n}\n.podcasts-wrapper .podcasts-on-the-go .on-the-go-text .on-the-go-title {\n  font-weight: bold;\n}\n.sub-title {\n  font-weight: 300;\n}\n@media only screen and (max-width: 764px) {\n  .header-banner {\n    background-image: url(\"https://anghamiwebcdn.akamaized.net/web/assets/img/podcasts/podcasts-landing-mobile.png\");\n    background-color: white !important;\n  }\n\n  .landing-wave {\n    display: none;\n  }\n\n  .podcasts-header-text {\n    padding: 5em 1em 2em;\n  }\n\n  .podcasts-header-img-wrapper {\n    max-height: 30rem;\n    overflow: hidden;\n  }\n\n  .podcasts-body-padding {\n    padding-left: 0.75rem;\n    padding-right: 0.75rem;\n  }\n\n  .podcasts-header-title {\n    font-size: 3.5em;\n    font-weight: 900;\n    text-transform: uppercase;\n  }\n\n  .podcasts-header {\n    font-size: 1rem;\n  }\n\n  .podcasts-content-section {\n    margin-top: 1.875rem;\n  }\n  .podcasts-content-section .podcasts-content-title {\n    margin-top: 0.75rem;\n    font-size: 1.875rem;\n    line-height: 2.3rem;\n  }\n  .podcasts-content-section .podcasts-content-subtitle {\n    font-weight: 500;\n    font-size: 1.5em;\n  }\n\n  .podcasts-cards-container {\n    margin-top: 0.75rem;\n    position: relative;\n  }\n  .podcasts-cards-container .podcasts-cards-left {\n    text-align: center;\n    color: white;\n  }\n  .podcasts-cards-container .podcasts-cards-left .podcasts-cards-left-img {\n    position: absolute;\n    z-index: -1;\n    left: 0;\n    max-width: 100%;\n  }\n  .podcasts-cards-container .podcasts-cards-left .podcasts-cards-left-title {\n    font-weight: 700;\n    font-size: 2em;\n    line-height: 1em;\n    padding-top: 3rem;\n  }\n  .podcasts-cards-container .podcasts-cards-left .podcasts-cards-left-subtitle {\n    font-weight: 500;\n    font-size: 1.5em;\n  }\n  .podcasts-cards-container .podcasts-cards-right .podcasts-cards-row {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    margin-top: 1.875rem;\n  }\n  .podcasts-cards-container .podcasts-cards-right .podcasts-cards-row .podcasts-card {\n    box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);\n    margin-left: 0.5rem;\n    margin-right: 0.5rem;\n    border-radius: 0.5rem;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    width: 6.5rem;\n    padding-left: 1rem;\n    padding-right: 1rem;\n    padding-bottom: 0.5rem;\n    background-color: white;\n  }\n  .podcasts-cards-container .podcasts-cards-right .podcasts-cards-row .podcasts-card img {\n    width: 4rem;\n  }\n  .podcasts-cards-container .podcasts-cards-right .podcasts-cards-row .podcasts-card div {\n    max-width: 4rem;\n    text-align: center;\n    font-weight: bold;\n    font-size: 0.9em;\n  }\n\n  .on-the-go-title {\n    font-size: 1.2rem;\n    line-height: 2.3rem;\n  }\n\n  .on-the-go-subtitle {\n    font-size: 1rem;\n    line-height: 0.875rem;\n    margin-top: 0.25rem;\n  }\n\n  .podcasts-first-margin {\n    margin-top: 9rem;\n  }\n\n  .podcasts-sm-hide {\n    display: none;\n  }\n\n  .sub-title {\n    font-size: 1.5em;\n  }\n}\n@media only screen and (min-width: 765px) {\n  .header-banner {\n    background-image: url(\"https://anghamiwebcdn.akamaized.net/web/assets/img/podcasts/podcasts-landing.png\");\n    background-color: white !important;\n    min-height: 44em !important;\n    background-position: left;\n  }\n\n  .podcasts-wrapper {\n    padding-bottom: 28rem;\n  }\n\n  .podcasts-header-img-wrapper {\n    max-height: 52em;\n    overflow: hidden;\n  }\n\n  .podcasts-header-text {\n    padding: 15.3em 2em 2em;\n  }\n\n  .wave {\n    position: absolute;\n    bottom: -13em;\n    left: 0;\n    right: 0;\n    width: 100%;\n  }\n\n  .podcasts-header-img {\n    min-height: 34rem;\n    min-width: 1241px;\n  }\n\n  .podcasts-body-padding {\n    padding-left: 8.33%;\n    padding-right: 8.33%;\n  }\n\n  .podcasts-header-title {\n    text-transform: uppercase;\n    font-size: 4em;\n    font-weight: 900;\n  }\n\n  .podcasts-content-section {\n    margin-top: 3rem;\n  }\n  .podcasts-content-section .podcasts-content-title {\n    margin-top: 1rem;\n    font-size: 2.5rem;\n  }\n  .podcasts-content-section .podcasts-content-subtitle {\n    font-weight: 500;\n    font-size: 1.5em;\n  }\n\n  .podcasts-cards-container {\n    margin-top: 1rem;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    position: relative;\n  }\n  .podcasts-cards-container .podcasts-cards-left {\n    width: 40%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    color: white;\n  }\n  .podcasts-cards-container .podcasts-cards-left .podcasts-cards-left-img {\n    position: absolute;\n    z-index: -1;\n    left: 0;\n    top: 6rem;\n  }\n  .podcasts-cards-container .podcasts-cards-left .podcasts-cards-left-title {\n    font-weight: 700;\n    font-size: 3em;\n    line-height: 1em;\n    padding-top: 10rem;\n  }\n  .podcasts-cards-container .podcasts-cards-left .podcasts-cards-left-subtitle {\n    font-weight: 300;\n    font-size: 1.25em;\n    opacity: 0.8;\n  }\n  .podcasts-cards-container .podcasts-cards-right {\n    width: 60%;\n  }\n  .podcasts-cards-container .podcasts-cards-right .podcasts-cards-row {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    margin-top: 1.875rem;\n  }\n  .podcasts-cards-container .podcasts-cards-right .podcasts-cards-row .podcasts-card {\n    box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);\n    margin-left: 1rem;\n    margin-right: 1rem;\n    border-radius: 0.5rem;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    width: 12em;\n    padding-top: 0.625rem;\n    padding-left: 1.625rem;\n    padding-right: 1.625rem;\n    padding-bottom: 1rem;\n    background-color: white;\n  }\n  .podcasts-cards-container .podcasts-cards-right .podcasts-cards-row .podcasts-card img {\n    width: 5rem;\n  }\n  .podcasts-cards-container .podcasts-cards-right .podcasts-cards-row .podcasts-card div {\n    max-width: 10rem;\n    text-align: center;\n    font-weight: bold;\n    font-size: 0.85rem;\n  }\n\n  .on-the-go-title {\n    font-size: 3em;\n  }\n\n  .on-the-go-subtitle {\n    margin-top: 1rem;\n    font-size: 1.35em;\n    opacity: 0.8;\n    font-weight: 300;\n  }\n\n  .podcasts-first-margin {\n    margin-top: 14rem;\n  }\n\n  .podcasts-lg-hide {\n    display: none;\n  }\n\n  .podcasts-lg-translate-row {\n    -webkit-transform: translateX(-5rem);\n        -ms-transform: translateX(-5rem);\n            transform: translateX(-5rem);\n  }\n}\n@media only screen and (min-width: 375px) {\n  .podcasts-first-margin {\n    margin-top: 14rem;\n  }\n}\n@media only screen and (min-width: 660px) {\n  .podcasts-first-margin {\n    margin-top: 16.5rem;\n  }\n}\n@media (max-width: 767.98px) {\n  .landing-wrapper .header-banner {\n    min-height: 39em !important;\n    padding: 8em 0 4em !important;\n  }\n}\n@media only screen and (min-width: 764px) {\n  html[lang=ar] .podcasts-cards-left-img {\n    position: absolute;\n    z-index: -1;\n    right: 0;\n    -webkit-transform: rotateY(180deg);\n            transform: rotateY(180deg);\n    max-width: 100%;\n  }\n}"

/***/ }),

/***/ "./src/app/modules/landing/podcasts/podcasts.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/modules/landing/podcasts/podcasts.component.ts ***!
  \****************************************************************/
/*! exports provided: PodcastsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PodcastsComponent", function() { return PodcastsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @anghami/redux/actions/analytics.actions */ "./src/app/core/redux/actions/analytics.actions.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../app/core/enums/enums */ "./src/app/core/enums/enums.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");











var PodcastsComponent = /** @class */ (function () {
    function PodcastsComponent(http, store, _translationService, platformId) {
        this.http = http;
        this.store = store;
        this._translationService = _translationService;
        this.platformId = platformId;
        this.env = '../../../../assets/img/podcasts/';
    }
    PodcastsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.store.dispatch(new _anghami_redux_actions_analytics_actions__WEBPACK_IMPORTED_MODULE_1__["LogAmplitudeEvent"]({
            name: _app_core_enums_enums__WEBPACK_IMPORTED_MODULE_9__["AmplitudeEvents"].land_on_podcasts
        }));
        this.isPlatformBrowser = Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["isPlatformBrowser"])(this.platformId);
        this.initializeTranslations();
        this.getTopPodcasts()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1))
            .subscribe(function (res) {
            if (res.sections && res.sections.length > 0) {
                _this.formatPodcastDataForDisplay(res);
            }
        });
    };
    PodcastsComponent.prototype.played = function () {
        //this.hlsjsDriver.load(this.sources[0].src);
    };
    PodcastsComponent.prototype.setPlyr = function ($event) {
    };
    PodcastsComponent.prototype.initializeTranslations = function () {
        this.uniqueExperienceTranslation = this._translationService.instant('podcasts_unique_experience');
        this.podcastSubtitleTranslation = this._translationService.instant('podcasts_subtitle');
        this.podcastTitleTranslation = this._translationService.instant('podcasts_title');
    };
    PodcastsComponent.prototype.goToPodcastsPage = function () {
        window.location.href = 'https://play.anghami.com/tag/127';
    };
    PodcastsComponent.prototype.getTopPodcasts = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]()
            .set('type', 'GETtoppodcasts')
            .set('tagid', '127');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_10__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["throwError"])(data.error);
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["throwError"])(err); }));
    };
    PodcastsComponent.prototype.formatPodcastDataForDisplay = function (podcastData) {
        for (var i = 0; i < podcastData.sections.length; i++) {
            podcastData.sections[i].displaytype = 'carousel';
            podcastData.sections[i].group = 'old_header';
            podcastData.sections[i].type = 'genericitem';
            delete podcastData.sections[i].initialNumItems;
        }
        this.podcasters = [podcastData.sections[0]];
        this.playlists = [podcastData.sections[1], podcastData.sections[2]];
        this.podcasters[0].data = this.podcasters[0].data.map(function (item) {
            item.coverArtImage =
                'https://angartwork.akamaized.net/webp/?id=' +
                    item.ArtistArt +
                    '&size=640';
            item.playerlink = true;
            item.href = '/artist/' + item.id;
            return item;
        });
        for (var i = 0; i < this.playlists.length; i++) {
            this.playlists[i].data = this.playlists[i].data.map(function (item) {
                item.coverArtImage =
                    'https://angartwork.akamaized.net/webp/?id=' +
                        item.coverArt +
                        '&size=640';
                item.playerlink = true;
                item.href = '/album/' + item.id;
                return item;
            });
        }
    };
    PodcastsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'anghami-podcasts',
            template: __webpack_require__(/*! raw-loader!./podcasts.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/podcasts/podcasts.component.html"),
            encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewEncapsulation"].None,
            styles: [__webpack_require__(/*! ./podcasts.component.scss */ "./src/app/modules/landing/podcasts/podcasts.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateService"],
            Object])
    ], PodcastsComponent);
    return PodcastsComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/podcasts/podcasts.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/modules/landing/podcasts/podcasts.module.ts ***!
  \*************************************************************/
/*! exports provided: PodcastsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PodcastsModule", function() { return PodcastsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _podcasts_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./podcasts.component */ "./src/app/modules/landing/podcasts/podcasts.component.ts");
/* harmony import */ var _podcasts_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./podcasts-routing.module */ "./src/app/modules/landing/podcasts/podcasts-routing.module.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");
/* harmony import */ var _core_modules_player_player_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/modules/player/player.service */ "./src/app/core/modules/player/player.service.ts");
/* harmony import */ var _anghami_services_collection_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/collection.service */ "./src/app/core/services/collection.service.ts");








var PodcastsModule = /** @class */ (function () {
    function PodcastsModule() {
    }
    PodcastsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_podcasts_component__WEBPACK_IMPORTED_MODULE_3__["PodcastsComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _podcasts_routing_module__WEBPACK_IMPORTED_MODULE_4__["PodcastsRoutingModule"],
                _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_5__["NewSectionBuilderModule"]
            ],
            providers: [
                _core_modules_player_player_service__WEBPACK_IMPORTED_MODULE_6__["PlayerService"],
                _anghami_services_collection_service__WEBPACK_IMPORTED_MODULE_7__["CollectionService"]
            ]
        })
    ], PodcastsModule);
    return PodcastsModule;
}());



/***/ })

}]);