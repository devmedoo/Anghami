(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pdj-pdj-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/core/components/placeholders/pdj-placeholder/pdj-placeholder.component.html":
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/components/placeholders/pdj-placeholder/pdj-placeholder.component.html ***!
  \***********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n\n<div class=\"placeholder-title short shine m-1\"></div>\n\n<div class=\"d-flex\">\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n\n</div>\n\n\n<div class=\"placeholder-title short shine m-1\"></div>\n\n<div class=\"d-flex\">\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n\n</div>\n\n\n<div class=\"placeholder-title short shine m-1\"></div>\n\n<div class=\"d-flex\">\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n  <div class=\"placeholder-box shine m-1\"></div>\n\n</div>\n\n\n\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/pdj/pdj-slider/pdj-slider.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/pdj/pdj-slider/pdj-slider.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section\n  #slides\n  *ngFor=\"let slide of data; let i = index\"\n  [ngClass]=\"i === 0 ? 'active' : ''\"\n  [style.background-image]=\"'url(' + slide.image + ')'\"\n>\n  <div class=\"pdj-slider-info\">\n    <h3 *ngIf=\"slide.supertitle\">{{ slide.supertitle }}</h3>\n    <a [routerLink]=\"[slide.href]\">\n      <h1>\n        <span>{{ slide.title }}</span> <span>&#9002;</span>\n      </h1>\n    </a>\n    <h4>{{ slide.subtitle }}</h4>\n  </div>\n</section>\n<ul>\n  <li\n    #dots\n    (click)=\"checkFocus(i)\"\n    *ngFor=\"let slide of data; let i = index\"\n    [ngClass]=\"i === 0 ? 'active' : ''\"\n  ></li>\n</ul>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/base/pdj/pdj.component.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/base/pdj/pdj.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ng-container *ngIf=\"sectionsHaveCarousel\">\n  <div class=\"ang-main\" *ngIf=\"!carouselInitialized\">\n    <div class=\"container-fluid\">\n      <div class=\"page-title\">\n        <h1 i18n=\"@@personaldj\">\n          Personal DJ\n        </h1>\n      </div>\n      <anghami-pdj-placeholder></anghami-pdj-placeholder>\n    </div>\n  </div>\n</ng-container>\n<ng-container *ngIf=\"!sectionsHaveCarousel\">\n  <div class=\"ang-main\" *ngIf=\"!sections\">\n    <div class=\"container-fluid\">\n      <div class=\"page-title\">\n        <h1 i18n=\"@@personaldj\">\n          Personal DJ\n        </h1>\n      </div>\n           <anghami-pdj-placeholder></anghami-pdj-placeholder>\n\n    </div>\n  </div>\n</ng-container>\n<div class=\"ang-main\">\n  <div class=\"container-fluid\">\n    <div class=\"page-title\">\n      <h1 i18n=\"@@personaldj\">\n        Personal DJ\n      </h1>\n\n      <anghami-music-language-selector></anghami-music-language-selector>\n    </div>\n    <ng-container *ngIf=\"header && header.length > 0\">\n      <anghami-pdj-slider [data]=\"header\"></anghami-pdj-slider>\n    </ng-container>\n\n    <ng-container *ngIf=\"sections\">\n      <anghami-new-section-builder\n        [sections]=\"sections\"\n        (carouselInitialized)=\"setCarouselInitializationState($event)\"\n      ></anghami-new-section-builder>\n    </ng-container>\n  </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/rxjs-compat/_esm5/observable/interval.js":
/*!***************************************************************!*\
  !*** ./node_modules/rxjs-compat/_esm5/observable/interval.js ***!
  \***************************************************************/
/*! exports provided: interval */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "interval", function() { return rxjs__WEBPACK_IMPORTED_MODULE_0__["interval"]; });


//# sourceMappingURL=interval.js.map

/***/ }),

/***/ "./src/app/core/components/placeholders/pdj-placeholder/pdj-placeholder.component.ts":
/*!*******************************************************************************************!*\
  !*** ./src/app/core/components/placeholders/pdj-placeholder/pdj-placeholder.component.ts ***!
  \*******************************************************************************************/
/*! exports provided: PdjPlaceholderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PdjPlaceholderComponent", function() { return PdjPlaceholderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var PdjPlaceholderComponent = /** @class */ (function () {
    function PdjPlaceholderComponent() {
    }
    PdjPlaceholderComponent.prototype.ngOnInit = function () {
    };
    PdjPlaceholderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-pdj-placeholder',
            template: __webpack_require__(/*! raw-loader!./pdj-placeholder.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/components/placeholders/pdj-placeholder/pdj-placeholder.component.html"),
            styles: [__webpack_require__(/*! ../placeholders.scss */ "./src/app/core/components/placeholders/placeholders.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], PdjPlaceholderComponent);
    return PdjPlaceholderComponent;
}());



/***/ }),

/***/ "./src/app/core/redux/effects/pdj.effects.ts":
/*!***************************************************!*\
  !*** ./src/app/core/redux/effects/pdj.effects.ts ***!
  \***************************************************/
/*! exports provided: PDJEffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDJEffects", function() { return PDJEffects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _services_pdj_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/pdj.service */ "./src/app/core/services/pdj.service.ts");
/* harmony import */ var _actions_collection_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _actions_pdj_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../actions/pdj.actions */ "./src/app/core/redux/actions/pdj.actions.ts");
/* harmony import */ var _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/services/section.service */ "./src/app/core/services/section.service.ts");









var PDJEffects = /** @class */ (function () {
    function PDJEffects(actions$, pdjService, sectionService) {
        var _this = this;
        this.actions$ = actions$;
        this.pdjService = pdjService;
        this.sectionService = sectionService;
        this.getPDJNew$ = this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["ofType"])(_actions_pdj_actions__WEBPACK_IMPORTED_MODULE_7__["PDJActionTypes"].GetPDJNew), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function () {
            return _this.pdjService.getPDJ().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (response) { return response; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (response) {
                response = JSON.parse(JSON.stringify(response));
                response.sections.unshift({
                    data: response.headers,
                    type: 'pdjHeaders',
                    displaytype: 'carousel'
                });
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _actions_collection_actions__WEBPACK_IMPORTED_MODULE_6__["GetCollectionSuccessNew"]({
                    sections: _this.sectionService.enhanceSections(response),
                    sectionType: 'pdj',
                    collectionMeta: response
                }));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _actions_collection_actions__WEBPACK_IMPORTED_MODULE_6__["GetCollectionError"](err));
            }));
        }));
    }
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Effect"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PDJEffects.prototype, "getPDJNew$", void 0);
    PDJEffects = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_effects__WEBPACK_IMPORTED_MODULE_2__["Actions"],
            _services_pdj_service__WEBPACK_IMPORTED_MODULE_5__["PDJService"],
            _anghami_services_section_service__WEBPACK_IMPORTED_MODULE_8__["SectionService"]])
    ], PDJEffects);
    return PDJEffects;
}());



/***/ }),

/***/ "./src/app/core/services/pdj.service.ts":
/*!**********************************************!*\
  !*** ./src/app/core/services/pdj.service.ts ***!
  \**********************************************/
/*! exports provided: PDJService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDJService", function() { return PDJService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");






var PDJService = /** @class */ (function () {
    function PDJService(http, locale) {
        this.http = http;
        this.locale = locale;
    }
    PDJService.prototype.getPDJ = function () {
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('type', 'GETdisplaytags');
        return this.http
            .get("" + _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].API_URL, {
            params: body
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (data) {
            if (data.error) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                    title: data.error.message || 'An error has occured',
                    displaymode: 'toast'
                });
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(data);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err); }));
    };
    PDJService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], String])
    ], PDJService);
    return PDJService;
}());



/***/ }),

/***/ "./src/app/modules/base/pdj/pdj-routing.module.ts":
/*!********************************************************!*\
  !*** ./src/app/modules/base/pdj/pdj-routing.module.ts ***!
  \********************************************************/
/*! exports provided: PDJRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDJRoutingModule", function() { return PDJRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _pdj_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pdj.component */ "./src/app/modules/base/pdj/pdj.component.ts");
/* harmony import */ var _pdj_resolver__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pdj.resolver */ "./src/app/modules/base/pdj/pdj.resolver.ts");





var routes = [
    {
        path: '',
        component: _pdj_component__WEBPACK_IMPORTED_MODULE_3__["PDJComponent"],
        resolve: { viewData: _pdj_resolver__WEBPACK_IMPORTED_MODULE_4__["PDJResolver"] }
    }
];
var PDJRoutingModule = /** @class */ (function () {
    function PDJRoutingModule() {
    }
    PDJRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            providers: [_pdj_resolver__WEBPACK_IMPORTED_MODULE_4__["PDJResolver"]],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], PDJRoutingModule);
    return PDJRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/base/pdj/pdj-slider/pdj-slider.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/modules/base/pdj/pdj-slider/pdj-slider.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  width: 100%;\n  overflow: hidden;\n  margin: auto;\n  position: relative;\n  height: 20em;\n  display: block;\n}\n:host section {\n  width: 100%;\n  height: 100%;\n  display: none;\n  position: relative;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center center;\n  border-radius: 0.5em;\n}\n:host section.active {\n  display: block;\n}\n:host section div {\n  position: absolute;\n  left: 1em;\n  bottom: 3em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n}\n:host section div a {\n  cursor: pointer;\n  text-decoration: none;\n}\n:host section div h1 {\n  font-size: 2em;\n  margin: 0.4em 0;\n  position: relative;\n}\n:host section div h1 span:last-child {\n  margin: 0 0 0 0.7em;\n  font-size: 0.7em;\n  vertical-align: middle;\n}\n:host section div h3 {\n  color: var(--text-color);\n  background-color: var(--light-background);\n  font-size: 1em;\n  border-radius: 0.2em;\n  padding: 0.2em;\n  font-weight: bold;\n  margin: 0;\n  font-weight: bold;\n}\n:host section div h4 {\n  font-size: 1em;\n  margin: 0 1em 0 0;\n  font-weight: 100;\n}\n:host section div h1,\n:host section div h4 {\n  color: var(--light-background);\n}\n:host .pdj-slider-info h1,\n:host .pdj-slider-info h4,\n:host .pdj-slider-info span {\n  color: #e8e8e8 !important;\n}\n:host ul {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  list-style: none;\n  position: absolute;\n  bottom: 1em;\n  padding: 0;\n  margin: 0;\n  width: 100%;\n}\n:host ul li {\n  width: 12px;\n  height: 12px;\n  background-color: var(--light-background);\n  border-radius: 50%;\n  margin: 0 0.25em;\n  cursor: pointer;\n}\n:host ul li:hover, :host ul li.active {\n  background-color: #494949;\n}\nhtml[lang=ar] :host section div {\n  left: initial;\n  right: 1em;\n}\nhtml[lang=ar] :host section div a {\n  direction: rtl;\n}\nhtml[lang=ar] :host section div h1 span:last-child {\n  margin: 0 0.7em 0 0;\n  vertical-align: initial;\n}\nhtml[lang=ar] :host section div h4 {\n  margin: 0 0 0 1em;\n  text-align: right;\n}\nhtml[lang=ar] :host section div h3 {\n  padding: 0.2em 0.2em 0 0.2em;\n}"

/***/ }),

/***/ "./src/app/modules/base/pdj/pdj-slider/pdj-slider.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/modules/base/pdj/pdj-slider/pdj-slider.component.ts ***!
  \*********************************************************************/
/*! exports provided: PDJSliderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDJSliderComponent", function() { return PDJSliderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_observable_interval__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/observable/interval */ "./node_modules/rxjs-compat/_esm5/observable/interval.js");



var PDJSliderComponent = /** @class */ (function () {
    function PDJSliderComponent(renderer) {
        this.renderer = renderer;
    }
    PDJSliderComponent.prototype.ngAfterViewInit = function () {
        if (typeof window === 'object' &&
            typeof window['Array'] === 'function' &&
            window['Array'](this.data) &&
            this.data.length > 0) {
            this.startSlideInterval();
        }
    };
    PDJSliderComponent.prototype.startSlideInterval = function () {
        this.data = this.data.map(function (item) {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, item, { href: item.deeplink &&
                    decodeURIComponent(item.deeplink.replace('anghami:/', '')) });
        });
        this.state = {
            previousSlide: undefined,
            previousDot: undefined,
            slideIndex: 0,
            slideInterval: Object(rxjs_observable_interval__WEBPACK_IMPORTED_MODULE_2__["interval"])(7000).subscribe(this.slideIntervalFn.bind(this))
        };
        this.checkFocus(this.state.slideIndex, true);
    };
    PDJSliderComponent.prototype.slideIntervalFn = function () {
        this.checkFocus(this.state.slideIndex === this.data.length - 1
            ? 0
            : this.state.slideIndex + 1);
    };
    PDJSliderComponent.prototype.checkFocus = function (index, cancelCheck) {
        if (!cancelCheck && index === this.state.slideIndex) {
            return;
        }
        this.focusSlide(index);
    };
    PDJSliderComponent.prototype.focusSlide = function (index) {
        this.state.slideIndex = index;
        this.slidesArray = this.slides.toArray();
        this.dotsArray = this.dots.toArray();
        /*
         * If you press browser's back button, the first element will only be active on top of other elements
         * so this is to fix an issue if the user pressed the back button to reach this page, and so the slider can have normal behaviour
         */
        if (index === 1) {
            this.renderer.removeClass(this.slidesArray[0].nativeElement, 'active');
            this.renderer.removeClass(this.dotsArray[0].nativeElement, 'active');
        }
        if (typeof this.state.previousSlide !== 'undefined') {
            this.renderer.removeClass(this.state.previousSlide, 'active');
        }
        if (typeof this.state.previousDot !== 'undefined') {
            this.renderer.removeClass(this.state.previousDot, 'active');
        }
        this.renderer.addClass(this.slidesArray[this.state.slideIndex].nativeElement, 'active');
        delete this.state.previousSlide;
        this.state.previousSlide = this.slidesArray[this.state.slideIndex].nativeElement;
        this.renderer.addClass(this.dotsArray[this.state.slideIndex].nativeElement, 'active');
        delete this.state.previousDot;
        this.state.previousDot = this.dotsArray[this.state.slideIndex].nativeElement;
    };
    PDJSliderComponent.prototype.ngOnDestroy = function () {
        if (typeof this.state !== 'undefined') {
            if (typeof this.state.slideInterval !== 'undefined') {
                this.state.slideInterval.unsubscribe();
                delete this.state.slideInterval;
            }
            if (typeof this.state.previousDot !== 'undefined') {
                delete this.state.previousDot;
            }
            if (typeof this.state.previousSlide !== 'undefined') {
                delete this.state.previousSlide;
            }
            if (typeof this.state.slideIndex !== 'undefined') {
                delete this.state.slideIndex;
            }
            delete this.state;
        }
        delete this.data;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('slides'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PDJSliderComponent.prototype, "slides", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('dots'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PDJSliderComponent.prototype, "dots", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PDJSliderComponent.prototype, "data", void 0);
    PDJSliderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-pdj-slider',
            template: __webpack_require__(/*! raw-loader!./pdj-slider.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/pdj/pdj-slider/pdj-slider.component.html"),
            styles: [__webpack_require__(/*! ./pdj-slider.component.scss */ "./src/app/modules/base/pdj/pdj-slider/pdj-slider.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]])
    ], PDJSliderComponent);
    return PDJSliderComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/pdj/pdj.component.scss":
/*!*****************************************************!*\
  !*** ./src/app/modules/base/pdj/pdj.component.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .page-title {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  margin: 0.7em 0 0.7em 0em;\n}\n:host .page-title h1 {\n  font-size: 2.2rem;\n}\n:host .page-title anghami-music-language-selector {\n  margin: 0.41em 0em 0 1.4em;\n}\nhtml[lang=ar] :host anghami-music-language-selector {\n  margin: 0.11em 2em 0 1em;\n}"

/***/ }),

/***/ "./src/app/modules/base/pdj/pdj.component.ts":
/*!***************************************************!*\
  !*** ./src/app/modules/base/pdj/pdj.component.ts ***!
  \***************************************************/
/*! exports provided: PDJComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDJComponent", function() { return PDJComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");








var PDJ_KEY = Object(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["makeStateKey"])('pdj');
var PDJComponent = /** @class */ (function () {
    function PDJComponent(store, _actionsSubject, state, platformId) {
        var _this = this;
        this.store = store;
        this._actionsSubject = _actionsSubject;
        this.state = state;
        this.platformId = platformId;
        this.carouselInitialized = false;
        this.actionSubjectSub$ = this._actionsSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__["ofType"])(_anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_4__["CollectionActionTypes"].GetCollectionSuccessNew))
            .subscribe(function (res) {
            if (res.payload.sectionType === 'pdj') {
                _this.sections = res.payload.sections;
                _this.header = _this.sections[0];
                if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_6__["isPlatformServer"])(_this.platformId)) {
                    var collectionData = {
                        sections: _this.sections,
                        header: _this.header
                    };
                    _this.state.set(PDJ_KEY, collectionData);
                }
                _this.sectionsHaveCarousel = _this.checkIfSectionsHaveCarousel(_this.sections);
            }
        });
    }
    PDJComponent.prototype.ngOnInit = function () {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_6__["isPlatformBrowser"])(this.platformId)) {
            var collectionData = this.state.get(PDJ_KEY, null);
            if (collectionData) {
                this.sections = collectionData.sections;
                this.header = collectionData.header;
                this.state.remove(PDJ_KEY);
                this.sectionsHaveCarousel = this.checkIfSectionsHaveCarousel(this.sections);
            }
        }
    };
    PDJComponent.prototype.setCarouselInitializationState = function (e) {
        this.carouselInitialized = true;
    };
    PDJComponent.prototype.checkIfSectionsHaveCarousel = function (sections) {
        for (var i = 0; i < sections.length; i++) {
            if (sections[i].displaytype === 'carousel' || sections[i].displaytype === 'carousel') {
                return true;
            }
        }
        return false;
    };
    PDJComponent.prototype.ngOnDestroy = function () {
        this.actionSubjectSub$.unsubscribe();
    };
    PDJComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-pdj',
            template: __webpack_require__(/*! raw-loader!./pdj.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/base/pdj/pdj.component.html"),
            host: { class: 'ang-view' },
            styles: [__webpack_require__(/*! ./pdj.component.scss */ "./src/app/modules/base/pdj/pdj.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["TransferState"],
            Object])
    ], PDJComponent);
    return PDJComponent;
}());



/***/ }),

/***/ "./src/app/modules/base/pdj/pdj.module.ts":
/*!************************************************!*\
  !*** ./src/app/modules/base/pdj/pdj.module.ts ***!
  \************************************************/
/*! exports provided: PDJModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDJModule", function() { return PDJModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _pdj_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pdj-routing.module */ "./src/app/modules/base/pdj/pdj-routing.module.ts");
/* harmony import */ var _pdj_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pdj.component */ "./src/app/modules/base/pdj/pdj.component.ts");
/* harmony import */ var _pdj_slider_pdj_slider_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pdj-slider/pdj-slider.component */ "./src/app/modules/base/pdj/pdj-slider/pdj-slider.component.ts");
/* harmony import */ var _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/new-section-builder/new-section-builder.module */ "./src/app/core/components/new-section-builder/new-section-builder.module.ts");
/* harmony import */ var _core_components_music_language_selector_music_language_selector_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/music-language-selector/music-language-selector.module */ "./src/app/core/components/music-language-selector/music-language-selector.module.ts");
/* harmony import */ var _core_components_placeholders_pdj_placeholder_pdj_placeholder_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/components/placeholders/pdj-placeholder/pdj-placeholder.component */ "./src/app/core/components/placeholders/pdj-placeholder/pdj-placeholder.component.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _anghami_redux_effects_pdj_effects__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @anghami/redux/effects/pdj.effects */ "./src/app/core/redux/effects/pdj.effects.ts");
/* harmony import */ var _anghami_services_pdj_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @anghami/services/pdj.service */ "./src/app/core/services/pdj.service.ts");












var PDJModule = /** @class */ (function () {
    function PDJModule() {
    }
    PDJModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _pdj_routing_module__WEBPACK_IMPORTED_MODULE_3__["PDJRoutingModule"], _core_components_new_section_builder_new_section_builder_module__WEBPACK_IMPORTED_MODULE_6__["NewSectionBuilderModule"], _core_components_music_language_selector_music_language_selector_module__WEBPACK_IMPORTED_MODULE_7__["MusicLanguageSelectorModule"], _ngrx_effects__WEBPACK_IMPORTED_MODULE_9__["EffectsModule"].forFeature([_anghami_redux_effects_pdj_effects__WEBPACK_IMPORTED_MODULE_10__["PDJEffects"]])],
            declarations: [_pdj_component__WEBPACK_IMPORTED_MODULE_4__["PDJComponent"], _pdj_slider_pdj_slider_component__WEBPACK_IMPORTED_MODULE_5__["PDJSliderComponent"], _core_components_placeholders_pdj_placeholder_pdj_placeholder_component__WEBPACK_IMPORTED_MODULE_8__["PdjPlaceholderComponent"]],
            providers: [_anghami_services_pdj_service__WEBPACK_IMPORTED_MODULE_11__["PDJService"]],
            exports: [_pdj_component__WEBPACK_IMPORTED_MODULE_4__["PDJComponent"]]
        })
    ], PDJModule);
    return PDJModule;
}());



/***/ }),

/***/ "./src/app/modules/base/pdj/pdj.resolver.ts":
/*!**************************************************!*\
  !*** ./src/app/modules/base/pdj/pdj.resolver.ts ***!
  \**************************************************/
/*! exports provided: PDJResolver */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDJResolver", function() { return PDJResolver; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/collection.actions */ "./src/app/core/redux/actions/collection.actions.ts");
/* harmony import */ var _anghami_redux_actions_pdj_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/redux/actions/pdj.actions */ "./src/app/core/redux/actions/pdj.actions.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");






var PDJResolver = /** @class */ (function () {
    function PDJResolver(store) {
        this.store = store;
    }
    PDJResolver.prototype.resolve = function () {
        this.initViewData();
        return this.waitForViewDataToLoad();
    };
    PDJResolver.prototype.waitForViewDataToLoad = function () {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["of"])();
    };
    PDJResolver.prototype.initViewData = function () {
        var _this = this;
        setTimeout(function () {
            _this.store.dispatch(new _anghami_redux_actions_pdj_actions__WEBPACK_IMPORTED_MODULE_4__["GetPDJNew"]());
            _this.store.dispatch(new _anghami_redux_actions_collection_actions__WEBPACK_IMPORTED_MODULE_3__["ResetLibrarySection"]());
        });
    };
    PDJResolver = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["Store"]])
    ], PDJResolver);
    return PDJResolver;
}());



/***/ })

}]);