(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["import-music-import-music-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/import-music/import-music.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/import-music/import-music.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"title\" i18n=\"@@fetching_data\">Fetching your data</div>\n<img src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/loading-bars.gif\">"

/***/ }),

/***/ "./src/app/modules/landing/import-music/import-music-routing.module.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/modules/landing/import-music/import-music-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: routes, ImportMusicRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportMusicRoutingModule", function() { return ImportMusicRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _import_music_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./import-music.component */ "./src/app/modules/landing/import-music/import-music.component.ts");




var routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: _import_music_component__WEBPACK_IMPORTED_MODULE_3__["ImportMusicComponent"]
            }
        ]
    }
];
var ImportMusicRoutingModule = /** @class */ (function () {
    function ImportMusicRoutingModule() {
    }
    ImportMusicRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], ImportMusicRoutingModule);
    return ImportMusicRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/import-music/import-music.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/modules/landing/import-music/import-music.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  margin-top: 6em;\n  min-height: 40vh;\n}\n:host .title {\n  font-size: 2em;\n  font-weight: 500;\n}\n:host img {\n  max-width: 6em;\n}"

/***/ }),

/***/ "./src/app/modules/landing/import-music/import-music.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/modules/landing/import-music/import-music.component.ts ***!
  \************************************************************************/
/*! exports provided: ImportMusicComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportMusicComponent", function() { return ImportMusicComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @anghami/redux/actions/auth.actions */ "./src/app/core/redux/actions/auth.actions.ts");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/effects */ "./node_modules/@ngrx/effects/fesm5/effects.js");
/* harmony import */ var _anghami_services_import_music_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @anghami/services/import-music.service */ "./src/app/core/services/import-music.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/enums/dialog-custom-types.enum */ "./src/app/core/enums/dialog-custom-types.enum.ts");










var ImportMusicComponent = /** @class */ (function () {
    function ImportMusicComponent(_actionSubject, _importMusicService, _route, store, platformId) {
        this._actionSubject = _actionSubject;
        this._importMusicService = _importMusicService;
        this._route = _route;
        this.store = store;
        this.platformId = platformId;
    }
    ImportMusicComponent.prototype.ngOnInit = function () {
        var _this = this;
        var type = (this._route.snapshot.queryParams.youtube &&
            this._route.snapshot.queryParams.youtube !== null &&
            this._route.snapshot.queryParams.youtube.match(/^true$/) !== null)
            ? 'youtube'
            : (this._route.snapshot.queryParams.deezer &&
                this._route.snapshot.queryParams.deezer !== null &&
                this._route.snapshot.queryParams.deezer.match(/^true$/) !== null)
                ? 'deezer'
                : 'spotify';
        if (type === 'youtube') {
            this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_8__["OpenDialogByName"](_core_enums_dialog_custom_types_enum__WEBPACK_IMPORTED_MODULE_9__["DIALOG_TYPES"].FEATURE_NOT_AVAILABLE));
            return;
        }
        var code = this._route.snapshot.queryParams['code'];
        this._actionSubject
            .pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["ofType"])(_anghami_redux_actions_auth_actions__WEBPACK_IMPORTED_MODULE_3__["AuthActionTypes"].AuthenticateSuccess))
            .subscribe(function (action) {
            var response = action.payload;
            if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_7__["isPlatformBrowser"])(_this.platformId) && response && response !== null && response.user) {
                _this._importMusicService.handleImportMusic(type, code);
            }
        });
    };
    ImportMusicComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'anghami-import-music',
            template: __webpack_require__(/*! raw-loader!./import-music.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/import-music/import-music.component.html"),
            styles: [__webpack_require__(/*! ./import-music.component.scss */ "./src/app/modules/landing/import-music/import-music.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngrx_store__WEBPACK_IMPORTED_MODULE_2__["ActionsSubject"],
            _anghami_services_import_music_service__WEBPACK_IMPORTED_MODULE_5__["ImportMusicService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_2__["Store"],
            Object])
    ], ImportMusicComponent);
    return ImportMusicComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/import-music/import-music.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/modules/landing/import-music/import-music.module.ts ***!
  \*********************************************************************/
/*! exports provided: ImportMusicModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportMusicModule", function() { return ImportMusicModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _import_music_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./import-music.component */ "./src/app/modules/landing/import-music/import-music.component.ts");
/* harmony import */ var _import_music_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./import-music-routing.module */ "./src/app/modules/landing/import-music/import-music-routing.module.ts");
/* harmony import */ var _anghami_services_import_music_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @anghami/services/import-music.service */ "./src/app/core/services/import-music.service.ts");





var ImportMusicModule = /** @class */ (function () {
    function ImportMusicModule() {
    }
    ImportMusicModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _import_music_routing_module__WEBPACK_IMPORTED_MODULE_3__["ImportMusicRoutingModule"]
            ],
            declarations: [_import_music_component__WEBPACK_IMPORTED_MODULE_2__["ImportMusicComponent"]],
            providers: [_anghami_services_import_music_service__WEBPACK_IMPORTED_MODULE_4__["ImportMusicService"]]
        })
    ], ImportMusicModule);
    return ImportMusicModule;
}());



/***/ })

}]);