(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["artist-connect-artist-connect-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/artist-connect/artist-connect.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/artist-connect/artist-connect.component.html ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header-banner\">\n  <div class=\"content\" #headerContent>\n    <h1 class=\"title\">\n      <ng-container>Introduce your music to the world</ng-container>\n    </h1>\n    <h4 class=\"sub-title\">\n      Upload your music for free, monetize it and reach the most audience possible.\n    </h4>\n    <button class=\"anghami-primary-btn header-button\" (click)=\"openDashboard()\">\n      Let's Go\n    </button>\n  </div>\n</div>\n\n<div class=\"artist-body\">\n  <section class=\"container features\">\n    <div class=\"row no-gutters\">\n      <div\n        class=\"col-12 feature d-flex flex-column flex-md-row align-items-center\"\n      >\n        <img\n          [lazyLoad]=\"\n            'https://anghamiwebcdn.akamaized.net/web/assets/img/artist-connect/publish-music.png'\n          \"\n        />\n        <div class=\"info align-self-center\">\n          <h2>SHARE YOUR MUSIC FOR FREE</h2>\n          <p>\n            Uploading your music is now easier than ever. Publish your songs and choose your convenient release date and time—totally free of charge!\n          </p>\n        </div>\n      </div>\n      <div\n        class=\"col-12 feature d-flex flex-column flex-md-row align-items-center\"\n      >\n        <img\n          [lazyLoad]=\"\n            'https://anghamiwebcdn.akamaized.net/web/assets/img/artist-connect/podcast.png'\n          \"\n        />\n        <div class=\"info align-self-center\">\n          <img class=\"new-image\" [lazyLoad]=\"\n          'https://anghamiwebcdn.akamaized.net/web/assets/img/artist-connect/new-en.png'\n        \">\n          <h2>PODCASTING ON ANGHAMI</h2>\n          <p>\n            Calling all podcasters: Submit your episodes by adding your RSS feed and get them published on Anghami within 24 hours.\n          </p>\n        </div>\n      </div>\n      <div\n        class=\"col-12 feature d-flex flex-column flex-md-row align-items-center\"\n      >\n        <img\n          [lazyLoad]=\"\n            'https://anghamiwebcdn.akamaized.net/web/assets/img/artist-connect/manage-artist-profile.png'\n          \"\n        />\n        <div class=\"info align-self-center\">\n          <h2>MANAGE YOUR ARTIST PROFILE</h2>\n          <p>\n            Create an account, take control of your library and update your music info. Whenever you hit 5K followers and 50K plays, your account will be verified instantly.\n          </p>\n        </div>\n      </div>\n      <div\n        class=\"col-12 feature d-flex flex-column flex-md-row align-items-center\"\n      >\n        <img\n          [lazyLoad]=\"\n            'https://anghamiwebcdn.akamaized.net/web/assets/img/artist-connect/audience.png'\n          \"\n        />\n        <div class=\"info align-self-center\">\n          <h2>GET TO KNOW YOUR AUDIENCE</h2>\n          <p>\n            Explore a wide diversity of insights about your audience and get to know how they discovered your music\n          </p>\n        </div>\n      </div>\n      <div\n        class=\"col-12 feature d-flex flex-column flex-md-row align-items-center\"\n      >\n        <img\n          [lazyLoad]=\"\n            'https://anghamiwebcdn.akamaized.net/web/assets/img/artist-connect/measure.png'\n          \"\n        />\n        <div class=\"info align-self-center\">\n          <h2>MEASURE YOUR RELEASE STATS, DAILY</h2>\n          <p>Need to know how your music is performing? A full analytical report is provided on a daily basis so you can check your streams, your top countries, your top streamed songs and much more.\n          </p>\n        </div>\n      </div>\n      <div\n        class=\"col-12 feature d-flex flex-column flex-md-row align-items-center\"\n      >\n        <img\n          [lazyLoad]=\"\n            'https://anghamiwebcdn.akamaized.net/web/assets/img/artist-connect/financial.png'\n          \"\n        />\n        <div class=\"info align-self-center\">\n          <h2>LET’S TALK MONEY</h2>\n          <p>\n            As a label or self-produced artist, you can check out your detailed financial reports. Request your payment, and we’ll take care of the rest.\n          </p>\n        </div>\n      </div>\n    </div>\n  </section>\n\n  <h2 class=\"text-uppercase font-weight-bold centered\">Who we deal with</h2>\n\n  <div class=\"container mainContent\">\n    <div class=\"row labelsRow\">\n      <div class=\"labelsSection\" *ngFor=\"let list of list\">\n        <div class=\"box-listing\" [ngClass]=\"{'add-margin': list.content.length < 5}\">\n          <label class=\"label-label\">{{ list.listName }}</label>\n          <div class=\"label-container\">\n            <div *ngFor=\"let label of list.content\" class=\"imageLabel\">\n              <img [lazyLoad]=\"label.image\" />\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"dashboard-banner\">\n    <h1 class=\"title\">\n      <ng-container>LET’S GET THIS STARTED</ng-container>\n    </h1>\n    <h4 class=\"sub-title\">\n      Upload your music for FREE, get paid, engage with your audience\n    </h4>\n    <span class=\"dashboard-buttons\">\n      <button\n        class=\"anghami-primary-btn claim-button\"\n        (click)=\"openDashboard()\"\n      >\n        Claim Your Artist Profile\n      </button>\n      <h4 class=\"sub-title\">OR</h4>\n      <button\n        class=\"anghami-primary-btn create-button\"\n        (click)=\"openDashboard()\"\n      >\n        Create Your Artist Page\n      </button>\n    </span>\n  </div>\n\n  <anghami-faq\n    [showHelpCenter]=\"false\"\n    [showQuestions]=\"showFAQ\"\n    [key]=\"showFAQ\"\n    [ignorear]=\"true\"\n  ></anghami-faq>\n\n  <div class=\"twitter-footer\">\n    <anghami-icon class=\"icon twitter\" [data]=\"'twitter'\"></anghami-icon>\n    <span class=\"twitter-text\">\n      Follow &nbsp;\n      <a href=\"https://twitter.com/anghami4artists\"> @Anghami4Artists </a>\n    </span>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/core/services/artist-connect.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/services/artist-connect.service.ts ***!
  \*********************************************************/
/*! exports provided: ArtistConnectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArtistConnectService", function() { return ArtistConnectService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");





var ArtistConnectService = /** @class */ (function () {
    function ArtistConnectService(http, locale) {
        this.http = http;
        this.locale = locale;
    }
    ArtistConnectService.prototype.getLabelList = function () {
        var _this = this;
        return this.http
            .get("https://anghamiwebcdn.akamaized.net/assets/external-files/artist-connect.json", {
            params: {}
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function (data) {
            var list = data;
            if (_this.locale.indexOf("en") == -1) {
                list.forEach(function (current) {
                    current.listName = current["listName-" + this.locale];
                });
            }
            return data.error ? Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])() : Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(list);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(function (err) { return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(err); }));
    };
    ArtistConnectService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], String])
    ], ArtistConnectService);
    return ArtistConnectService;
}());



/***/ }),

/***/ "./src/app/modules/landing/artist-connect/artist-connect-routing.module.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/modules/landing/artist-connect/artist-connect-routing.module.ts ***!
  \*********************************************************************************/
/*! exports provided: ArtistConnectRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArtistConnectRoutingModule", function() { return ArtistConnectRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _artist_connect_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./artist-connect.component */ "./src/app/modules/landing/artist-connect/artist-connect.component.ts");




var routes = [
    {
        path: '',
        component: _artist_connect_component__WEBPACK_IMPORTED_MODULE_3__["ArtistConnectComponent"]
    }
];
var ArtistConnectRoutingModule = /** @class */ (function () {
    function ArtistConnectRoutingModule() {
    }
    ArtistConnectRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], ArtistConnectRoutingModule);
    return ArtistConnectRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/artist-connect/artist-connect.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/modules/landing/artist-connect/artist-connect.component.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@-webkit-keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-20px);\n    -ms-transform: translateY(-20px);\n    transform: translateY(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInDownBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-20px);\n    -ms-transform: translateX(-20px);\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInLeftBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(20px);\n    -ms-transform: translateX(20px);\n    transform: translateX(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes fadeInRightBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(20px);\n    -ms-transform: translateY(20px);\n    transform: translateY(20px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes fadeInUpBig {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    opacity: 1;\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInDown {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(-2000px);\n    -ms-transform: translateY(-2000px);\n    transform: translateY(-2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@-webkit-keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInLeft {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(-2000px);\n    -ms-transform: translateX(-2000px);\n    transform: translateX(-2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@keyframes slideInRight {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateX(2000px);\n    -ms-transform: translateX(2000px);\n    transform: translateX(2000px);\n  }\n  100% {\n    -webkit-transform: translateX(0);\n    -ms-transform: translateX(0);\n    transform: translateX(0);\n  }\n}\n@-webkit-keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@keyframes slideInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n    -ms-transform: translateY(2000px);\n    transform: translateY(2000px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n    -ms-transform: translateY(0);\n    transform: translateY(0);\n  }\n}\n@media (max-width: 767.98px) {\n  :host nav {\n    padding: 0 1rem;\n  }\n  :host nav > .navbar-main .menu-links,\n:host nav > .navbar-main .menu-actions {\n    display: none !important;\n  }\n  :host nav > .navbar-main > .nav-toggle {\n    display: block;\n  }\n  :host .header-banner {\n    width: 100%;\n  }\n  :host .header-banner > .content {\n    width: 100% !important;\n    padding: 15em 2em 2em 0 !important;\n    top: 8em;\n    right: 1em;\n  }\n  :host .header-banner > .content > .title {\n    font-size: 3.5em !important;\n  }\n  :host .artist-body {\n    top: -15em !important;\n    position: relative;\n  }\n  :host .dashboard-banner {\n    min-height: 50em !important;\n    padding: 15em 0em 0em 0em !important;\n    background-size: unset !important;\n  }\n  :host .dashboard-banner .title {\n    font-size: 3.5em !important;\n  }\n  :host .dashboard-banner .sub-title {\n    font-size: 1rem !important;\n  }\n  :host .dashboard-banner .dashboard-buttons {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -ms-flex-line-pack: stretch;\n        align-content: stretch;\n    margin-top: 2em;\n  }\n  :host .label-container {\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n  }\n  :host .label-label {\n    margin-left: 1.5em !important;\n  }\n}\n@media (max-width: 991.98px) {\n  :host .dashboard-banner {\n    padding: 15em 0 !important;\n  }\n}\n@media (max-width: 1199.98px) {\n  :host .dashboard-banner {\n    padding: 15em 0 !important;\n  }\n}\n:host .add-margin {\n  margin-right: 2em;\n}\n:host .artist-body {\n  top: -8em;\n  position: relative;\n}\n:host .header-banner {\n  min-width: 100%;\n  min-height: 62em !important;\n  top: -8em;\n  background-image: url(\"https://anghamiwebcdn.akamaized.net/web/assets/img/artist-connect/header.png\");\n  background-color: transparent;\n}\n:host .header-banner > .content > .title {\n  text-transform: uppercase;\n  font-size: 5em;\n  font-weight: 1000;\n}\n:host .header-banner > .content > .sub-title {\n  font-weight: 400;\n}\n:host .header-banner > .content {\n  display: block;\n  color: white;\n  text-align: right;\n  overflow: hidden;\n  width: 50%;\n  padding: 10em 7em 2em 0;\n}\n:host .header-button {\n  margin-top: 1em;\n  font-size: 1.5em;\n  background: transparent -webkit-gradient(linear, right top, left top, from(#913ccd), to(#e1418c)) 0% 0% no-repeat padding-box;\n  background: transparent linear-gradient(270deg, #913ccd 0%, #e1418c 100%) 0% 0% no-repeat padding-box;\n  min-width: 12em;\n}\n:host .mainContent {\n  margin: 1em auto;\n}\n:host .labelsSection {\n  display: inline-block;\n  vertical-align: top;\n}\n:host .imageLabel {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  border: 1px solid #dedede;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n:host .imageLabel img {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  max-width: 100%;\n  max-height: 100%;\n  width: 7em;\n  height: auto;\n  -webkit-filter: grayscale(100%);\n}\n:host .imageLabel img:hover {\n  -webkit-filter: grayscale(0%);\n}\n:host .page-internal .imageLabel {\n  display: inline-block;\n  margin: 0.5em;\n}\n:host .imageLabel {\n  display: inline-block;\n  margin: 0.5em;\n}\n:host label {\n  display: block !important;\n}\n:host .centered {\n  margin-top: 3em;\n  text-align: center;\n}\n:host .label-label {\n  font-size: 1.5rem;\n  font-weight: 500;\n  padding: 1.5em 0 0em 0em;\n}\n:host .imageLabel {\n  width: 8em;\n  height: 8em;\n  padding: 0.5em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n:host .features > .title {\n  text-align: center;\n  font-weight: bold;\n  font-size: 2.3em;\n  margin-bottom: 1em;\n}\n:host .features .feature {\n  padding: 0em 1em;\n}\n@media (max-width: 767.98px) {\n  :host .features .feature {\n    padding: 0em 1em;\n  }\n}\n:host .features .feature img {\n  width: 27em;\n}\n:host .features .feature .info {\n  max-width: 30em;\n}\n@media (max-width: 767.98px) {\n  :host .features .feature .info {\n    text-align: center !important;\n    padding-top: 1em;\n  }\n}\n:host .features .feature .info h2 {\n  font-weight: bold;\n}\n:host .features .feature .info p {\n  font-weight: 300;\n}\n@media (min-width: 768px) {\n  :host .features .feature:nth-child(even) {\n    -webkit-box-orient: horizontal !important;\n    -webkit-box-direction: reverse !important;\n        -ms-flex-direction: row-reverse !important;\n            flex-direction: row-reverse !important;\n  }\n}\n:host .features .feature:nth-child(even) .info {\n  text-align: right;\n  padding-right: 1em;\n}\n:host .features .feature:nth-child(odd) .info {\n  text-align: left;\n  padding-left: 1em;\n}\n:host .dashboard-banner {\n  color: white;\n  min-width: 100%;\n  min-height: 57em;\n  background-image: url(\"https://anghamiwebcdn.akamaized.net/web/assets/img/artist-connect/wave.png\");\n  background-color: transparent;\n  padding: 20em 0em;\n  text-align: center;\n  background-repeat: no-repeat;\n  background-size: 100%;\n}\n:host .dashboard-banner .title {\n  font-size: 5em;\n  font-weight: 700;\n}\n:host .dashboard-banner h4 {\n  margin: 1em 1em;\n}\n:host .dashboard-buttons {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: baseline;\n      -ms-flex-align: baseline;\n          align-items: baseline;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n}\n:host .label-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n}\n:host .create-button {\n  background: white;\n  color: black;\n  border: 2px solid white;\n}\n:host .claim-button {\n  background: none;\n  border: 2px solid white;\n}\n:host .thumbnail_container {\n  position: relative;\n  width: 25%;\n  padding-bottom: 25%;\n  background: green;\n  float: left;\n}\n:host .thumbnail {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  background: red;\n  text-align: center;\n}\n:host .thumbnail img {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  margin: auto;\n}\n:host .blue {\n  background: blue;\n}\n:host img {\n  max-height: 100%;\n  max-width: 100%;\n}\n:host .twitter-footer {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: stretch;\n      -ms-flex-align: stretch;\n          align-items: stretch;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n}\n:host .twitter {\n  font-size: 2em;\n  color: #00acee;\n}\n:host .twitter-text {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n:host .new-image {\n  width: 5em !important;\n}\nhtml[lang=ar] :host {\n  direction: ltr !important;\n}\nhtml[lang=ar] :host ::ng-deep .header-banner {\n  -webkit-box-pack: end !important;\n  -ms-flex-pack: end !important;\n  justify-content: flex-end !important;\n}\nhtml[lang=ar] :host ::ng-deep .btn-link {\n  text-align: left !important;\n  direction: ltr !important;\n}"

/***/ }),

/***/ "./src/app/modules/landing/artist-connect/artist-connect.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/modules/landing/artist-connect/artist-connect.component.ts ***!
  \****************************************************************************/
/*! exports provided: ArtistConnectComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArtistConnectComponent", function() { return ArtistConnectComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _anghami_services_artist_connect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @anghami/services/artist-connect.service */ "./src/app/core/services/artist-connect.service.ts");



var ArtistConnectComponent = /** @class */ (function () {
    function ArtistConnectComponent(locale, artistConnectService) {
        var _this = this;
        this.locale = locale;
        this.artistConnectService = artistConnectService;
        this.artistConnectService
            .getLabelList()
            .toPromise()
            .then(function (response) {
            _this.list = response;
        });
        this.showFAQ = "artistconnect";
    }
    ArtistConnectComponent.prototype.openDashboard = function () {
        window.location.href = "https://dash.anghami.com/#/core/signup";
    };
    ArtistConnectComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "anghami-artist-connect",
            template: __webpack_require__(/*! raw-loader!./artist-connect.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/artist-connect/artist-connect.component.html"),
            styles: [__webpack_require__(/*! ./artist-connect.component.scss */ "./src/app/modules/landing/artist-connect/artist-connect.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String, _anghami_services_artist_connect_service__WEBPACK_IMPORTED_MODULE_2__["ArtistConnectService"]])
    ], ArtistConnectComponent);
    return ArtistConnectComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/artist-connect/artist-connect.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/modules/landing/artist-connect/artist-connect.module.ts ***!
  \*************************************************************************/
/*! exports provided: ArtistConnectModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArtistConnectModule", function() { return ArtistConnectModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _artist_connect_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./artist-connect-routing.module */ "./src/app/modules/landing/artist-connect/artist-connect-routing.module.ts");
/* harmony import */ var _artist_connect_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./artist-connect.component */ "./src/app/modules/landing/artist-connect/artist-connect.component.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/index.js");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(ng_lazyload_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _core_components_faq_faq_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/components/faq/faq.module */ "./src/app/core/components/faq/faq.module.ts");
/* harmony import */ var _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/components/icon/icon.module */ "./src/app/core/components/icon/icon.module.ts");
/* harmony import */ var _core_services_artist_connect_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/services/artist-connect.service */ "./src/app/core/services/artist-connect.service.ts");









var ArtistConnectModule = /** @class */ (function () {
    function ArtistConnectModule() {
    }
    ArtistConnectModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _artist_connect_routing_module__WEBPACK_IMPORTED_MODULE_3__["ArtistConnectRoutingModule"],
                ng_lazyload_image__WEBPACK_IMPORTED_MODULE_5__["LazyLoadImageModule"],
                _core_components_faq_faq_module__WEBPACK_IMPORTED_MODULE_6__["FaqModule"],
                _core_components_icon_icon_module__WEBPACK_IMPORTED_MODULE_7__["IconModule"]
            ],
            providers: [_core_services_artist_connect_service__WEBPACK_IMPORTED_MODULE_8__["ArtistConnectService"]],
            declarations: [_artist_connect_component__WEBPACK_IMPORTED_MODULE_4__["ArtistConnectComponent"]],
            exports: [_artist_connect_component__WEBPACK_IMPORTED_MODULE_4__["ArtistConnectComponent"]]
        })
    ], ArtistConnectModule);
    return ArtistConnectModule;
}());



/***/ })

}]);