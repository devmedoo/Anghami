(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["embed-embed-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/modules/landing/embed/embed.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modules/landing/embed/embed.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"embed-container\">\n  <div class=\"header\">\n    <div class=\"title-desc\">\n      <span class='title' i18n=\"@@widget_title\"> Add a Widget to your website </span>\n\n      <p i18n=\"@@widget_subtitle\"> Here’s a guide to using the embedded players and icons that we’ve designed to help\n        you share your music with\n        the\n        world </p>\n    </div>\n    <div class=\"images\">\n      <img src=\"https://anghamiwebcdn.akamaized.net/web/assets/img/embed/embed-header-image.png\" />\n    </div>\n  </div>\n  <div class=\"body-container\">\n    <div class=\"input-section\">\n      <span class=\"sub-title\" i18n=\"@@widget_music_title\">Pick the music you want to share </span>\n      <span class=\"sub-desc\" i18n=\"@@widget_music_subtitle\">Copy the link of a song, album, playlist or artist</span>\n\n      <input type='text' class='link-input' placeholder=\"https://play.anghami.com/artist/48826\"\n        (change)=\"handleLinkChange($event)\" />\n      <span class='error-message' *ngIf=\"errorMessage\" i18n=\"@@widget_music_error\">Please make sure you enter a valid\n        anghami link </span>\n    </div>\n    <div class=\"input-section\">\n      <span class=\"sub-title\" i18n=\"@@widget_language_title\">Choose your language</span>\n      <div class=\"select-options\">\n        <div *ngFor=\"let lang of languages\" class=\"option\"\n          [ngClass]=\"{'selected': lang.value === widgetObject.language}\" (click)=\"languageChange(lang.value)\">\n          {{lang.text}}</div>\n      </div>\n    </div>\n    <div class=\"input-section\">\n      <span class=\"sub-title\" i18n=\"@@widget_theme_title\">Pick your theme</span>\n      <div class=\"select-options\">\n        <div class=\"option\" [ngClass]=\"{'selected': themes[0].value === widgetObject.theme}\"\n          (click)=\"themeChange(themes[0].value)\">{{themes[0].translation[language]}}</div>\n        <div class=\"option\"\n          [ngClass]=\"{'selected': widgetObject.theme === 'fulltrans' || widgetObject.theme === 'transdark' || widgetObject.theme === 'translight'}\"\n          (click)=\"themeChange(themes[1].value)\">{{themes[1].translation[language]}}</div>\n        <ng-container\n          *ngIf=\"widgetObject.theme === 'fulltrans' || widgetObject.theme === 'transdark' || widgetObject.theme === 'translight' \">\n          <div *ngFor=\"let theme of transpThemes\" class=\"option wider\"\n            [ngClass]=\"{'selected': theme.value === widgetObject.theme}\" (click)=\"themeChange(theme.value)\">\n            {{theme.translation[language]}}\n          </div>\n        </ng-container>\n        <div class=\"option\" [ngClass]=\"{'selected': themes[2].value === widgetObject.theme}\"\n          (click)=\"themeChange(themes[2].value)\">{{themes[2].translation[language]}}</div>\n      </div>\n    </div>\n    <div class=\"input-section\">\n      <span class=\"sub-title\" i18n=\"@@widget_template_title\">Choose a template</span>\n      <!-- <span class=\"sub-desc\" i18n=\"@@widget_template_subtitle\">A preview of your widget</span> -->\n      <div class=\"select-options without-width\">\n        <div class=\"image-option\" [ngClass]=\"{'selected': view.type === widgetObject.view}\" *ngFor=\"let view of views\"\n          (click)=\"viewChange(view)\">\n          <img [src]=\"view.img\" alt=\"{{view.type}}-view\" />\n        </div>\n      </div>\n    </div>\n    <div *ngIf=\"generatedLink\" class='input-section'>\n      <span class=\"sub-title\" i18n=\"@@Preview\">Preview</span>\n      <span class=\"sub-desc\" i18n=\"@@widget_template_subtitle\">A preview of your widget</span>\n      <iframe [src]=\"generatedLink\" scrolling=\"no\" frameborder=\"0\" [width]=\"widgetObject.width\"\n        [height]=\"widgetObject.height\"></iframe>\n    </div>\n    <div class=\"generate-button\" (click)=\"generateResult()\" i18n=\"@@widget_template_button\">Generate Code</div>\n    <div *ngIf=\"generatedContent\" class='generated-result-container'>\n      <span class=\"sub-desc\" i18n=\"@@widget_code_title\">Copy and paste this code on your website</span>\n      <div contenteditable=\"true\" class='generated-result' (click)=\"copyText()\">\n        {{generatedContent}}\n      </div>\n      <div class='flex-end'>\n        <div class=\"copy-button\" (click)=\"copyText()\" i18n=\"@@widget_code_button\">Copy Code</div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/modules/landing/embed/embed-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/modules/landing/embed/embed-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: routes, EmbedRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmbedRoutingModule", function() { return EmbedRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _embed_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./embed.component */ "./src/app/modules/landing/embed/embed.component.ts");




var routes = [
    {
        path: '',
        component: _embed_component__WEBPACK_IMPORTED_MODULE_3__["EmbedComponent"]
    }
];
var EmbedRoutingModule = /** @class */ (function () {
    function EmbedRoutingModule() {
    }
    EmbedRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], EmbedRoutingModule);
    return EmbedRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/landing/embed/embed.component.scss":
/*!************************************************************!*\
  !*** ./src/app/modules/landing/embed/embed.component.scss ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".embed-container {\n  font-family: Roboto;\n  padding: 0em 5em 0em 10em;\n}\n.embed-container .header {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-top: 10em;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n.embed-container .header .title-desc {\n  width: 30%;\n}\n.embed-container .header .title-desc .title {\n  color: var(--brand-purple);\n  text-transform: capitalize;\n  font-size: 5em;\n  font-weight: bold;\n}\n.embed-container .header .title-desc p {\n  font-size: 1.8em;\n  margin-top: 1em;\n}\n.embed-container .header .images {\n  width: 60%;\n}\n.embed-container .header .images img {\n  width: 70%;\n  margin: 0 auto;\n}\n.embed-container .header:lang(ar) {\n  text-align: right;\n}\n.embed-container .body-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: left;\n      -ms-flex-pack: left;\n          justify-content: left;\n  margin-top: 3em;\n}\n.embed-container .body-container .input-section {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  margin-bottom: 3em;\n}\n.embed-container .body-container .input-section .sub-title {\n  font-weight: bold;\n  font-size: 1.4em;\n}\n.embed-container .body-container .input-section .sub-desc {\n  font-weight: 1.1em;\n  color: #717171;\n  margin-top: 0.2em;\n}\n.embed-container .body-container .input-section input {\n  background: #FFFFFF 0% 0% no-repeat padding-box;\n  border: 1px solid #D3D3D3;\n  border-radius: 13px;\n  opacity: 1;\n  width: 50em;\n  height: 3em;\n  padding: 1em;\n  color: #000;\n  margin-top: 1em;\n}\n.embed-container .body-container .input-section input::-webkit-input-placeholder {\n  color: #C4C4C4;\n}\n.embed-container .body-container .input-section input::-moz-placeholder {\n  color: #C4C4C4;\n}\n.embed-container .body-container .input-section input:-ms-input-placeholder {\n  color: #C4C4C4;\n}\n.embed-container .body-container .input-section input::-ms-input-placeholder {\n  color: #C4C4C4;\n}\n.embed-container .body-container .input-section input::placeholder {\n  color: #C4C4C4;\n}\n.embed-container .body-container .input-section input:focus::-webkit-input-placeholder {\n  color: transparent;\n}\n.embed-container .body-container .input-section input:focus::-moz-placeholder {\n  color: transparent;\n}\n.embed-container .body-container .input-section input:-moz-placeholder {\n  color: transparent;\n}\n.embed-container .body-container .input-section .error-message {\n  color: red;\n  margin: 0.5em 0em 0em 1em;\n}\n.embed-container .body-container .input-section .select-options {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin-top: 2em;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n}\n.embed-container .body-container .input-section .select-options .option {\n  border: 1px solid #707070;\n  border-radius: 25px;\n  width: 6em;\n  height: 3em;\n  text-align: center;\n  line-height: 3em;\n  color: black;\n  background: white;\n  margin-left: 1em;\n  cursor: pointer;\n}\n.embed-container .body-container .input-section .select-options .option.wider {\n  border-radius: 20px;\n  width: 10em;\n  background: #EEEEEE;\n  border: 1px solid #e4e1e1;\n  color: #4B4B4B;\n}\n.embed-container .body-container .input-section .select-options .option.selected {\n  background: #4B4B4B 0% 0% no-repeat padding-box;\n  color: white;\n  cursor: default;\n}\n.embed-container .body-container .input-section .select-options .option.selected.wider {\n  background: #a1a0a0 0% 0% no-repeat padding-box;\n  color: white;\n  font-weight: bold;\n}\n.embed-container .body-container .input-section .select-options .image-option {\n  margin-right: 1.2em;\n  cursor: pointer;\n  padding: 1em;\n  border: 1px solid #F5F5F5;\n  border-radius: 17px;\n  height: auto;\n  display: table;\n}\n.embed-container .body-container .input-section .select-options .image-option img {\n  width: 13em;\n}\n.embed-container .body-container .input-section .select-options .image-option.selected {\n  box-shadow: 0px 0px 10px #00000057;\n}\n.embed-container .body-container .input-section .without-width {\n  width: 90% !important;\n  -webkit-box-pack: start !important;\n      -ms-flex-pack: start !important;\n          justify-content: flex-start !important;\n}\n.embed-container .body-container .input-section iframe {\n  margin-top: 2em;\n  border-radius: 10px;\n}\n.embed-container .body-container .generate-button {\n  background: #8D00F2 0% 0% no-repeat padding-box;\n  border-radius: 32px;\n  width: 15em;\n  height: 3.5em;\n  font-size: 1.1em;\n  color: white;\n  text-align: center;\n  line-height: 3.5em;\n  font-weight: bold;\n  cursor: pointer;\n}\n.embed-container .body-container .generated-result-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  margin-top: 3em;\n  width: 70%;\n  min-width: 25em;\n  max-width: 50em;\n}\n.embed-container .body-container .generated-result-container .generated-result {\n  height: auto;\n  margin-top: 1em;\n  background: #F7F7F7;\n  padding: 1em;\n  border-radius: 10px;\n  color: #181818;\n}\n.embed-container .body-container .generated-result-container .flex-end {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n}\n.embed-container .body-container .generated-result-container .copy-button {\n  background: #8D00F2 0% 0% no-repeat padding-box;\n  border-radius: 32px;\n  width: 8em;\n  height: 2.5em;\n  font-size: 1.1em;\n  color: white;\n  text-align: center;\n  line-height: 2.5em;\n  margin-top: 1em;\n  cursor: pointer;\n}\n.embed-container .body-container:lang(ar) {\n  text-align: right;\n}\n@media screen and (max-width: 1700px) {\n  .embed-container {\n    padding: 0em 6em;\n  }\n  .embed-container .header .title-desc {\n    width: 40%;\n  }\n  .embed-container .header .title-desc .title {\n    font-size: 3em;\n  }\n  .embed-container .header .title-desc p {\n    font-size: 1.6em;\n  }\n  .embed-container .header .images img {\n    width: 90%;\n  }\n  .embed-container .body-container .select-options .image-option img {\n    width: 20em;\n  }\n}\n@media screen and (max-width: 850px) {\n  .embed-container {\n    padding: 0em 3em;\n  }\n  .embed-container .header {\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n  }\n  .embed-container .header .title-desc {\n    width: 90%;\n    text-align: center;\n  }\n  .embed-container .header .images {\n    width: 90%;\n  }\n  .embed-container .header .images img {\n    width: 100%;\n  }\n  .embed-container .body-container input {\n    width: 90% !important;\n  }\n  .embed-container .body-container .image-option {\n    margin-bottom: 1.2em;\n  }\n  .embed-container .body-container .select-options {\n    margin-top: 1em;\n  }\n  .embed-container .body-container .select-options .option {\n    margin-top: 1em;\n  }\n  .embed-container .without-width {\n    width: 90% !important;\n    -webkit-box-pack: start !important;\n        -ms-flex-pack: start !important;\n            justify-content: flex-start !important;\n    -ms-flex-wrap: wrap;\n        flex-wrap: wrap;\n  }\n  .embed-container .generate-button {\n    margin-left: 0.1em;\n  }\n  .embed-container .generated-result-container {\n    width: 80%;\n  }\n}\n@media screen and (max-width: 400px) {\n  .embed-container iframe {\n    width: 100% !important;\n  }\n  .embed-container .header .images {\n    margin-left: 0em;\n  }\n  .embed-container .header .images img {\n    max-width: 100%;\n    display: block;\n    margin: auto;\n    height: auto;\n  }\n  .embed-container .body-container .select-options {\n    margin-top: 1em;\n  }\n  .embed-container .body-container .select-options .option {\n    margin-top: 1em;\n  }\n}"

/***/ }),

/***/ "./src/app/modules/landing/embed/embed.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/modules/landing/embed/embed.component.ts ***!
  \**********************************************************/
/*! exports provided: EmbedComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmbedComponent", function() { return EmbedComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/enums/collection-types.enum */ "./src/app/core/enums/collection-types.enum.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_services_copy_to_clipboard_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/services/copy-to-clipboard.service */ "./src/app/core/services/copy-to-clipboard.service.ts");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "./node_modules/@ngrx/store/fesm5/store.js");
/* harmony import */ var _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @anghami/redux/actions/dialogs.actions */ "./src/app/core/redux/actions/dialogs.actions.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");








var EmbedComponent = /** @class */ (function () {
    function EmbedComponent(sanitizer, copyToClipboard, store, _route, locale) {
        this.sanitizer = sanitizer;
        this.copyToClipboard = copyToClipboard;
        this.store = store;
        this._route = _route;
        this.locale = locale;
        this.languages = [
            { text: 'English', value: 'en' },
            { text: 'عربي', value: 'ar' },
            { text: 'Français', value: 'fr' }
        ];
        this.themes = [
            { text: 'Dark', value: 'fulldark', translation: { ar: 'داكن', en: 'Dark', fr: 'Sombre' } },
            { text: 'Color', value: 'fulltrans', translation: { ar: 'ملوّن', en: 'Color', fr: 'Coloré' } },
            { text: 'White', value: 'fulllight', translation: { ar: 'فاتح', en: 'Light', fr: 'Claire' } },
        ];
        this.transpThemes = [
            { text: 'Dark Color', value: 'transdark', translation: { ar: 'لون داكن', en: 'Dark Color', fr: 'Couleur Sombre' } },
            { text: 'Full Color', value: 'fulltrans', translation: { ar: 'لون مُحدّد', en: 'Full Color', fr: 'Couleur Complète' } },
            { text: 'White Color', value: 'translight', translation: { ar: 'لون فاتح', en: 'Light Color', fr: 'Couleur Claire' } },
        ];
        this.originalViews = [
            { type: 'list', img: 'https://anghamiwebcdn.akamaized.net/web/assets/img/embed/List.png', width: 600, height: 450 },
            { type: 'narrow', img: 'https://anghamiwebcdn.akamaized.net/web/assets/img/embed/Big.png', width: 440, height: 600 },
            { type: 'wide', img: 'https://anghamiwebcdn.akamaized.net/web/assets/img/embed/Wide.png', width: 600, height: 190 }
        ];
        this.views = [];
        this.errorMessage = null;
        this.language = 'en';
        this.widgetObject = {
            type: _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].ARTIST,
            id: '48826',
            theme: 'fulldark',
            language: 'en',
            view: 'list',
            height: 450,
            width: 600
        };
        this.views = this.originalViews.slice();
        this.generate();
    }
    EmbedComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.language = this.locale
            ? this.locale.indexOf('en') > -1
                ? 'en'
                : this.locale
            : 'en';
        this.routeParam$ = this._route.params.subscribe(function (params) {
            if (params && params !== null && params.type && params.id) {
                _this.handleTypeAndID(params.type, params.id);
            }
        });
    };
    EmbedComponent.prototype.handleLinkChange = function (event) {
        // https://play.anghami.com/artist/48826
        var link = event.target.value.toString();
        var anghamiLinkIndex = link.search('play.anghami.com/');
        // 'https://'.length = 8
        if (anghamiLinkIndex >= 0 && anghamiLinkIndex < 9) {
            this.errorMessage = null;
            // 'play.anghami.com/'.length = 17
            var contentLink = link.slice(17 + anghamiLinkIndex);
            var contentType = contentLink.split('/')[0];
            var contentID = contentLink.split('/')[1];
            this.handleTypeAndID(contentType, contentID);
        }
        else {
            this.errorMessage = 'That\'s not an anghami link';
        }
    };
    EmbedComponent.prototype.handleTypeAndID = function (type, id) {
        this.widgetObject.id = id;
        switch (type) {
            case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].ALBUM:
            case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].PLAYLIST: {
                this.views = this.originalViews.slice(0, 1).slice();
                this.viewChange(this.originalViews[0]);
                this.widgetObject.type = type;
                break;
            }
            case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].ARTIST: {
                this.views = this.originalViews.slice();
                this.viewChange(this.originalViews[0]);
                this.widgetObject.type = _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].ARTIST;
                break;
            }
            case _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].SONG: {
                this.views = this.originalViews.slice(1).slice();
                this.viewChange(this.originalViews[2]);
                this.widgetObject.type = _core_enums_collection_types_enum__WEBPACK_IMPORTED_MODULE_2__["CollectionTypes"].SONG;
                break;
            }
            default: {
                this.errorMessage = 'Content not valid';
                break;
            }
        }
        this.generate();
    };
    EmbedComponent.prototype.themeChange = function (theme) {
        this.widgetObject.theme = theme;
        this.generate();
    };
    EmbedComponent.prototype.languageChange = function (language) {
        this.widgetObject.language = language;
        this.generate();
    };
    EmbedComponent.prototype.viewChange = function (view) {
        this.widgetObject.view = view.type;
        this.widgetObject.width = view.width;
        this.widgetObject.height = view.height;
        this.generate();
    };
    EmbedComponent.prototype.generate = function (safe) {
        if (safe === void 0) { safe = true; }
        // Generate Iframe, old one
        // tslint:disable-next-line: max-line-length
        var link = "https://widget.anghami.com/" + this.widgetObject.type + "/" + this.widgetObject.id + "/?theme=" + this.widgetObject.theme + "&&layout=" + this.widgetObject.view + "&&lang=" + this.widgetObject.language;
        if (safe) {
            this.generatedLink = this.sanitizer.bypassSecurityTrustResourceUrl(link);
        }
        else {
            return link;
        }
    };
    EmbedComponent.prototype.generateResult = function () {
        // tslint:disable-next-line: max-line-length
        this.generatedContent = " <iframe src=\"" + this.generate(false) + "\" scrolling=\"no\" frameborder=\"0\" width=" + this.widgetObject.width + " height=" + this.widgetObject.height + " ></iframe>\n    ";
    };
    EmbedComponent.prototype.copyText = function () {
        this.copyToClipboard.copy(this.generatedContent);
        var contentDiv = document.getElementsByClassName('generated-result')[0];
        var range = document.createRange();
        range.selectNodeContents(contentDiv);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        // After copying show toast saying text has been copied to clipboard
        var dialog = {
            displaymode: 'toast',
            title: this.locale === 'ar'
                ? 'نسخ إلى الحافظة'
                : this.locale === 'fr'
                    ? 'copié dans le presse-papier'
                    : 'Copied to clipboard'
        };
        this.store.dispatch(new _anghami_redux_actions_dialogs_actions__WEBPACK_IMPORTED_MODULE_6__["OpenDialog"](dialog));
    };
    EmbedComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'anghami-embed',
            template: __webpack_require__(/*! raw-loader!./embed.component.html */ "./node_modules/raw-loader/index.js!./src/app/modules/landing/embed/embed.component.html"),
            styles: [__webpack_require__(/*! ./embed.component.scss */ "./src/app/modules/landing/embed/embed.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_3__["LOCALE_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["DomSanitizer"],
            _core_services_copy_to_clipboard_service__WEBPACK_IMPORTED_MODULE_4__["CopyToClipboardService"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"], Object])
    ], EmbedComponent);
    return EmbedComponent;
}());



/***/ }),

/***/ "./src/app/modules/landing/embed/embed.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/modules/landing/embed/embed.module.ts ***!
  \*******************************************************/
/*! exports provided: EmbedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmbedModule", function() { return EmbedModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/components/loading/loading.module */ "./src/app/core/components/loading/loading.module.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _embed_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./embed-routing.module */ "./src/app/modules/landing/embed/embed-routing.module.ts");
/* harmony import */ var _embed_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./embed.component */ "./src/app/modules/landing/embed/embed.component.ts");
/* harmony import */ var _anghami_services_copy_to_clipboard_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @anghami/services/copy-to-clipboard.service */ "./src/app/core/services/copy-to-clipboard.service.ts");








var EmbedModule = /** @class */ (function () {
    function EmbedModule() {
    }
    EmbedModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _embed_routing_module__WEBPACK_IMPORTED_MODULE_5__["EmbedRoutingModule"],
                _core_components_loading_loading_module__WEBPACK_IMPORTED_MODULE_3__["LoadingModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateModule"],
            ],
            providers: [_anghami_services_copy_to_clipboard_service__WEBPACK_IMPORTED_MODULE_7__["CopyToClipboardService"]],
            declarations: [_embed_component__WEBPACK_IMPORTED_MODULE_6__["EmbedComponent"]],
            exports: [_embed_component__WEBPACK_IMPORTED_MODULE_6__["EmbedComponent"]]
        })
    ], EmbedModule);
    return EmbedModule;
}());



/***/ })

}]);